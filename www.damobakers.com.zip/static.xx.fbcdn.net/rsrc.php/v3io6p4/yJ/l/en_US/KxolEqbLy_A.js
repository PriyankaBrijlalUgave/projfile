if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ObjectFlip", [], (function(a, b, c, d, e, f) {
    function a(a) {
        return Object.keys(a).reduce(function(b, c) {
            var d = a[c];
            d != null && (b[d] = c);
            return b
        }, {})
    }
    f["default"] = a
}), 66);
__d("AdsCountries", ["AdsCountriesConfig", "ObjectFlip", "objectKeys"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("ObjectFlip")(c("AdsCountriesConfig").countries);

    function a(a) {
        a = a.toUpperCase();
        return c("AdsCountriesConfig").countriesWithCities.indexOf(a) != -1
    }

    function b(a) {
        a = a.toUpperCase();
        return c("AdsCountriesConfig").countriesWithRegions.indexOf(a) != -1
    }

    function d(a) {
        a = a.toUpperCase();
        return c("AdsCountriesConfig").countriesToCurrencies[a]
    }

    function e(a) {
        return c("AdsCountriesConfig").countriesToTerritories[a.toUpperCase()]
    }
    f = c("objectKeys")(h || {}).sort().map(function(a) {
        return {
            code: h[a],
            name: a
        }
    });
    g.countryIDsByNames = h;
    g.countries = c("AdsCountriesConfig").countries;
    g.hasCities = a;
    g.hasRegions = b;
    g.getCurrencyByCountry = d;
    g.getTerritoriesByCountry = e;
    g.sortedCountries = f
}), 98);
__d("AbstractCalendarPager.react", ["fbt", "Focus", "LocalDate", "ReactDOM", "prop-types", "react", "uniqueID"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = d("react").Component;

    function j(a, b) {
        if (!a) return !1;
        var c = b.focusDate.startOfMonth();
        b = c.addMonths(b.count);
        return c.isBeforeOrEqual(a) && b.isAfter(a)
    }

    function k(a, b) {
        var c = a.focusDate,
            d = a.rangeSelectDate,
            e = a.selectDate;
        return {
            cursor: j(b.cursor, a) && b.cursor || j(e, a) && e || j(d, a) && d || c,
            buttonFocused: b.buttonFocused != null ? b.buttonFocused : !1,
            prevCount: b.prevCount,
            prevFocusDate: b.prevFocusDate,
            prevRangeSelectDate: b.prevRangeSelectDate,
            prevSelectDate: b.prevSelectDate
        }
    }

    function l(a, b) {
        return !!(a && b && a.equals(b))
    }

    function m(a, b) {
        return a.getMonth() === b.getMonth() && a.getYear() === b.getYear()
    }

    function n(a, b) {
        return b.count !== a.count || b.focusDate !== a.focusDate || b.rangeSelectDate !== a.rangeSelectDate || b.selectDate !== a.selectDate
    }
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            var e;
            e = a.call(this, b) || this;
            e.$5 = function(a) {
                e.setState({
                    cursor: a
                }), e.$4 = a, e.props.onSelectDateChange && e.props.onSelectDateChange(a)
            };
            e.$6 = function(a) {
                if (e.props.limitPagerToRestraints && !e.$7(a)) return;
                var b;
                if (!j(a, {
                        focusDate: e.props.focusDate,
                        count: e.props.count
                    })) {
                    b = e.$8(e.props.focusDate.isBefore(a) ? 1 : -1);
                    var c = {
                        focusDate: b,
                        count: e.props.count
                    };
                    j(a, c) || (b = a)
                }
                e.setState({
                    cursor: a
                }, function() {
                    b ? (e.$3 = b, e.props.onFocusDateChange(b)) : e.$1 && d("Focus").set(e.$1)
                })
            };
            e.$9 = function(a) {
                e.$1 = a ? d("ReactDOM").findDOMNode(a) : null, e.props.setupFocusRef && e.props.setupFocusRef(e.$1)
            };
            e.$10 = function() {
                e.props.onFocusDateChange(e.$8(-1))
            };
            e.$11 = function() {
                e.props.onFocusDateChange(e.$8(1))
            };
            e.$12 = function(a) {
                a.preventDefault()
            };
            e.$18 = function() {
                e.setState({
                    buttonFocused: !0
                })
            };
            e.$17 = function() {
                e.setState({
                    buttonFocused: !1
                })
            };
            e.$21 = function(a) {
                return i.jsxs("div", {
                    className: e.props.classNames.calendarWrapper,
                    children: [e.$14(a), e.$20(a)]
                }, a.key)
            };
            e.$2 = c("uniqueID")();
            e.state = k(b, {
                prevCount: b.count,
                prevFocusDate: b.focusDate,
                prevRangeSelectDate: b.rangeSelectDate,
                prevSelectDate: b.selectDate
            });
            return e
        }
        b.getDerivedStateFromProps = function(a, b) {
            var c = {
                count: b.prevCount,
                focusDate: b.prevFocusDate,
                rangeSelectDate: b.prevRangeSelectDate,
                selectDate: b.prevSelectDate
            };
            return n(a, c) ? k(a, babelHelpers["extends"]({}, b, {
                prevCount: a.count,
                prevFocusDate: a.focusDate,
                prevRangeSelectDate: a.rangeSelectDate,
                prevSelectDate: a.selectDate
            })) : null
        };
        var e = b.prototype;
        e.componentDidUpdate = function(a, b) {
            b = this.props;
            if (n(a, b)) {
                var c = !m(b.focusDate, a.focusDate) && this.$3 && this.$3.equals(b.focusDate);
                a = !l(a.selectDate, b.selectDate) && l(this.$4, b.selectDate);
                this.$3 = null;
                this.$4 = null;
                c && (this.$1 && d("Focus").set(this.$1));
                a && (this.$1 && d("Focus").setWithoutOutline(this.$1))
            }
        };
        e.$8 = function(a) {
            return this.props.focusDate.startOfMonth().addMonths(a)
        };
        e.canPageByMonthDelta = function(a) {
            return !this.props.limitPagerToRestraints ? !0 : this.$7(this.$8(a))
        };
        e.$7 = function(a) {
            var b = a.getMonth();
            a = a;
            while (a.getMonth() === b) {
                if (this.$13(a)) return !0;
                a = a.addDays(1)
            }
            return !1
        };
        e.$13 = function(a) {
            return !this.props.dateRestraints || this.props.dateRestraints.every(function(b) {
                return b(a)
            })
        };
        e.canPagePrev = function() {
            return this.canPageByMonthDelta(-1)
        };
        e.canPageNext = function() {
            return this.canPageByMonthDelta(1)
        };
        e.$14 = function(a) {
            return i.jsx("h2", {
                className: this.props.classNames.monthHeader,
                id: a.headerId,
                children: this.$15(a)
            }, a.key)
        };
        e.$15 = function(a) {
            return h._("{month} {year}", [h._param("month", i.jsx("span", {
                className: this.props.classNames.month,
                children: a.focusDate.format("F", {
                    skipPatternLocalization: !0
                })
            })), h._param("year", i.jsx("span", {
                className: this.props.classNames.year,
                children: a.focusDate.getYear()
            }))])
        };
        e.$16 = function() {
            return i.cloneElement(this.props.leftButton, {
                disabled: !this.canPagePrev(),
                label: h._("Previous month"),
                labelIsHidden: !0,
                onBlur: this.$17,
                onClick: this.$10,
                onFocus: this.$18,
                onMouseDown: this.$12,
                tabIndex: 0
            })
        };
        e.$19 = function() {
            return i.cloneElement(this.props.rightButton, {
                disabled: !this.canPageNext(),
                label: h._("Next month"),
                labelIsHidden: !0,
                onBlur: this.$17,
                onClick: this.$11,
                onFocus: this.$18,
                onMouseDown: this.$12,
                tabIndex: 0
            })
        };
        e.$20 = function(a) {
            var b = this.props;
            return i.createElement(b.calendarType, {
                "aria-labelledby": a.headerId,
                allowDuplicateSelection: b.allowDuplicateSelection,
                allowVariableRowCount: b.allowVariableRowCount,
                dateRestraints: b.dateRestraints,
                dayInnerFormatter: b.dayInnerFormatter,
                dayRenderer: b.dayRenderer,
                defaultCursor: this.state.cursor,
                focusDate: a.focusDate,
                highlightedDates: b.highlightedDates,
                hoveredDates: b.hoveredDates,
                highlightedTimes: b.highlightedTimes,
                onCursorChange: this.$6,
                onMouseOverDay: b.onMouseOverDay,
                onMouseOutDay: b.onMouseOutDay,
                onFocusDateChange: b.onFocusDateChange,
                onSelectDateChange: this.$5,
                rangeSelectDate: b.rangeSelectDate,
                selectDate: b.selectDate,
                selectedWeekStart: b.selectedWeekStart,
                selectedWeekEnd: b.selectedWeekEnd,
                setupFocusRef: this.$9,
                showDaysOutsideOfMonth: b.showDaysOutsideOfMonth
            })
        };
        e.$22 = function() {
            var a = [],
                b = this.props,
                c = b.count;
            b = b.showPreviousMonthByDefault;
            var d = b && c > 1 ? c - 1 : c;
            b = b ? -1 : 0;
            for (var b = b; b < d; b++) {
                var e = this.$8(b),
                    f = e.getMonth() + "-" + e.getYear();
                a.push({
                    focusDate: e,
                    headerId: this.$2 + "-" + f,
                    key: c > 1 ? f : "1"
                })
            }
            return a
        };
        e.render = function() {
            var a = this.$22(),
                b = babelHelpers["extends"]({}, this.props);
            delete b.allowDuplicateSelection;
            delete b.allowVariableRowCount;
            delete b.calendarType;
            delete b.classNames;
            delete b.count;
            delete b.dateRestraints;
            delete b.dayInnerFormatter;
            delete b.dayRenderer;
            delete b.focusDate;
            delete b.highlightedTimes;
            delete b.highlightedDates;
            delete b.hoveredDates;
            delete b.leftButton;
            delete b.limitPagerToRestraints;
            delete b.onFocusDateChange;
            delete b.onSelectDateChange;
            delete b.rangeSelectDate;
            delete b.rightButton;
            delete b.selectDate;
            delete b.selectedDateStart;
            delete b.selectedDateEnd;
            delete b.setupFocusRef;
            delete b.showPreviousMonthByDefault;
            return i.jsxs("div", babelHelpers["extends"]({}, b, {
                "data-count": this.props.count,
                children: [i.jsxs("div", {
                    className: this.props.classNames.buttonsWrapper,
                    children: [this.$16(), this.$19()]
                }), i.jsx("div", {
                    className: this.props.classNames.main,
                    children: a.map(this.$21, this)
                }), i.jsx("div", {
                    "aria-atomic": "true",
                    "aria-live": "polite",
                    className: "accessible_elem",
                    children: this.state.buttonFocused ? this.$15(a[0]) : ""
                })]
            }))
        };
        return b
    }(a);
    b.propTypes = {
        allowDuplicateSelection: c("prop-types").bool,
        allowVariableRowCount: c("prop-types").bool,
        calendarType: c("prop-types").oneOfType([c("prop-types").func, c("prop-types").object]).isRequired,
        classNames: c("prop-types").shape({
            buttonsWrapper: c("prop-types").string,
            calendarWrapper: c("prop-types").string,
            main: c("prop-types").string,
            month: c("prop-types").string,
            monthHeader: c("prop-types").string,
            year: c("prop-types").string
        }),
        count: c("prop-types").number,
        dayRenderer: c("prop-types").func,
        dateRestraints: c("prop-types").array,
        dayInnerFormatter: c("prop-types").func,
        focusDate: c("prop-types").instanceOf(c("LocalDate")).isRequired,
        highlightedDates: c("prop-types").array,
        highlightedTimes: c("prop-types").array,
        hoveredDates: c("prop-types").array,
        leftButton: c("prop-types").node.isRequired,
        limitPagerToRestraints: c("prop-types").bool,
        onFocusDateChange: c("prop-types").func.isRequired,
        onMouseOverDay: c("prop-types").func,
        onMouseOutDay: c("prop-types").func,
        onSelectDateChange: c("prop-types").func,
        rangeSelectDate: c("prop-types").instanceOf(c("LocalDate")),
        renderExplicitRangeLabel: c("prop-types").bool,
        rightButton: c("prop-types").node.isRequired,
        selectDate: c("prop-types").instanceOf(c("LocalDate")),
        selectedWeekStart: c("prop-types").instanceOf(c("LocalDate")),
        selectedWeekEnd: c("prop-types").instanceOf(c("LocalDate")),
        setupFocusRef: c("prop-types").func,
        showPreviousMonthByDefault: c("prop-types").bool
    };
    b.defaultProps = {
        classNames: {},
        count: 1
    };
    g["default"] = b
}), 98);
__d("ImmutableServerCallableWrapper", ["immutable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("immutable")
}), 98);
__d("Currency", ["CurrencyConfig"], (function(a, b, c, d, e, f, g) {
    var h = {
        iso: "",
        format: "",
        symbol: "",
        offset: 1,
        name: ""
    };

    function i(a) {
        return a != null && c("CurrencyConfig").allCurrenciesByCode[a] ? c("CurrencyConfig").allCurrenciesByCode[a] : h
    }

    function a(a) {
        return i(a).format
    }

    function b(a) {
        return i(a).iso
    }

    function d(a) {
        return i(a).name
    }

    function e(a) {
        return i(a).offset
    }

    function g(a) {
        return i(a).symbol
    }
    f.exports = {
        getFormat: a,
        getISO: b,
        getName: d,
        getOffset: e,
        getSymbol: g
    }
}), 34);
__d("isCurrencyWithSymbolAndThousandsSeparators", ["CurrencyConfig", "distinctArray"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a, b) {
        b === void 0 && (b = ",");
        var c = i().find(function(b) {
            return a.startsWith(b)
        });
        if (c == null || c === "") return !1;
        c = a.slice(c.length);
        return c != null && j(c, b)
    }
    var h = null;

    function i() {
        h = h || (g || (g = b("distinctArray")))(Object.values(b("CurrencyConfig").allCurrenciesByCode).map(function(a) {
            return a != null && typeof a === "object" ? String(a.symbol) : null
        }).filter(Boolean));
        return h
    }

    function j(a, b) {
        return new RegExp("^\\d{1,3}(" + b + "\\d{3})*(.d+)?$").test(a)
    }
    e.exports = a
}), null);
__d("AdsCurrencyFormatter", ["Currency", "NumberFormatConfig", "intlNumUtils", "isCurrencyWithSymbolAndThousandsSeparators"], (function(a, b, c, d, e, f) {
    function g(a) {
        return Math.round(Math.log(a) / Math.LN10)
    }

    function h(a, c, d) {
        var e = b("Currency").getFormat(a) || "{symbol}{amount}",
            f = b("Currency").getSymbol(a) || "";
        e = e.replace("{symbol}", f).replace("{amount}", c);
        return d === !0 ? e + " " + b("Currency").getISO(a) : e
    }

    function i(a, c, d, e) {
        e === void 0 && (e = !0);
        a = b("Currency").getOffset(a) || 100;
        e = e ? g(a) : 0;
        return d === !0 ? b("intlNumUtils").formatNumberWithThousandDelimiters(c / a, e) : b("intlNumUtils").formatNumber(c / a, e)
    }

    function j(a, b, c, d, e, f) {
        e === void 0 && (e = !0);
        f === void 0 && (f = !1);
        f = (f && b > 0 ? "+" : "") + i(a, b, d, e);
        return h(a, f, c)
    }

    function k(a, b) {
        return j(a, b)
    }

    function a(a, b, c, d) {
        return i(a, b, c, d)
    }

    function c(a, b) {
        return j(a, b, !0)
    }

    function d(a, c) {
        return i(a, c) + " " + b("Currency").getISO(a)
    }

    function f(a, b, c) {
        c === void 0 && (c = !0);
        return j(a, b, !1, !0, c)
    }

    function l(a, c) {
        a = b("Currency").getOffset(a) || 100;
        var d = g(a);
        while (c !== 0 && Math.round(Math.abs(c) * Math.pow(10, d) / a) < 1) d++;
        return d
    }

    function m(a, c) {
        var d = b("Currency").getOffset(a) || 100;
        d = b("intlNumUtils").formatNumberWithThousandDelimiters(c / d, l(a, c));
        return h(a, d, !1)
    }

    function n(a, c, d) {
        var e = b("Currency").getOffset(a) || 100;
        return h(a, b("intlNumUtils").formatNumberWithThousandDelimiters(c / e, Math.max(d, l(a, c))))
    }

    function o(a, b, c) {
        return q(a, b, c, !0)
    }

    function p(a, b, c) {
        return q(a, b, c, !1)
    }

    function q(a, c, d, e) {
        var f = b("Currency").getOffset(a) || 100,
            i = g(f);
        i && c % f === 0 && (i = 0);
        d = d === !0 ? b("intlNumUtils").formatNumberWithThousandDelimiters(c / f, i) : b("intlNumUtils").formatNumber(c / f, i);
        return e === !0 ? h(a, d, !1) : d
    }

    function r(a, b, c) {
        return u(k(a, b), k(a, c))
    }

    function s(a, b, c, d) {
        if (d - c < b) return k(a, d);
        else return r(a, c, d)
    }
    var t = "\u2013";

    function u(a, b) {
        return a + t + b
    }

    function v(a, b, c) {
        return w(a, b, c) || 0
    }

    function w(a, c, d) {
        a = b("Currency").getOffset(a);
        c = b("intlNumUtils").parseNumberRaw(c, d, b("NumberFormatConfig").numberDelimiter);
        return c == null ? null : Math.round(c * a)
    }

    function x(a, c) {
        a = b("Currency").getOffset(a);
        a = g(a);
        c = b("intlNumUtils").parseNumber(c) || 0;
        return +c.toFixed(a)
    }

    function y(a, c, d) {
        return v(a, c, d != null && d != "" ? d : b("NumberFormatConfig").decimalSeparator)
    }

    function z(a, c, d) {
        return w(a, c, d != null && d != "" ? d : b("NumberFormatConfig").decimalSeparator)
    }

    function A(a, b, c, d, e, f) {
        e === void 0 && (e = !0);
        f === void 0 && (f = !1);
        return j(a, b, c, d, e, f)
    }

    function B(a, c) {
        var d = 100;
        a = b("Currency").getOffset(a) || d;
        return c / d * a
    }

    function C(a, c) {
        var d = b("Currency").getOffset(a) || 100,
            e = b("Currency").getSymbol(a);
        d = c / d;
        var f = "";
        if (d > 1e6) d /= 1e6, f = "M";
        else if (d > 1e3) d /= 1e3, f = "K";
        else return q(a, c, !0, !0);
        d = Math.round(d * 10) / 10;
        a = b("intlNumUtils").formatNumber(d, 1);
        return e + a + f
    }
    e.exports = {
        formatCurrency: k,
        formatCurrencyAtLeastOneSigFig: m,
        formatCurrencyFullFormat: A,
        formatCurrencyNoSymbol: a,
        formatCurrencyRange: r,
        formatCurrencyRangeWithThreshold: s,
        formatCurrencyWithAtLeastNumberOfDecimalPlacesAndOneSigFig: n,
        formatCurrencyWithISO: c,
        formatCurrencyWithISONoSymbol: d,
        formatCurrencyWithLargerNumber: C,
        formatCurrencyWithNumberDelimiters: f,
        formatCurrencyWithOptionalDecimals: o,
        formatCurrencyWithOptionalDecimalsNoSymbol: p,
        formatRange: u,
        isCurrencyWithSymbolAndThousandsSeparators: b("isCurrencyWithSymbolAndThousandsSeparators"),
        parseCurrency: y,
        parseOptionalCurrency: z,
        parsePECurrency: x,
        replaceWithSymbol: h,
        replaceOffsetFactorFromAmount: B
    }
}), null);
__d("Cache", ["DateConsts", "TimeSlice"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.has = function(a) {
            return this.$1.has(a)
        };
        b.get = function(a, b) {
            a = this.__getRaw(a);
            return !a ? b : a.$2
        };
        b.getAll = function(a, b) {
            var c = this,
                d = new Map();
            a.forEach(function(a) {
                return d.set(a, c.get(a, b))
            });
            return d
        };
        b["delete"] = function(a) {
            var b = this.__getRaw(a);
            b && b.$3 && clearTimeout(b.$3);
            return this.$1["delete"](a)
        };
        b.clear = function() {
            this.$1.forEach(function(a) {
                a && a.$3 && clearTimeout(a.$3)
            }), this.$1.clear()
        };
        b.set = function(a, b, e, f) {
            if (!this.shouldUpdate(a, e)) return !1;
            var g = this.__getRaw(a);
            g || (g = this.__getNewRawObject());
            delete g.$2;
            delete g.$4;
            g.$3 && clearTimeout(g.$3);
            delete g.$3;
            g.$2 = b;
            e != null && (g.$4 = e);
            f != null && f >= 0 && (g.$3 = setTimeout(c("TimeSlice").guard(this["delete"].bind(this, a), "Cache expiration timeout"), f * d("DateConsts").MS_PER_SEC * d("DateConsts").SEC_PER_MIN));
            this.__setRaw(a, g);
            return !0
        };
        b.shouldUpdate = function(a, b) {
            a = this.__getRaw(a);
            return a == null || a.$4 == null || b == null || b > a.$4
        };
        b.size = function() {
            return this.$1.size
        };
        b.__getRaw = function(a) {
            return this.$1.get(a)
        };
        b.__setRaw = function(a, b) {
            this.$1.set(a, b)
        };
        b.__getNewRawObject = function() {
            return {
                $2: null,
                $3: null,
                $4: null,
                $5: null,
                $6: null
            }
        };
        b.__keys = function() {
            return this.$1.keys()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("range", [], (function(a, b, c, d, e, f) {
    function a(a, b, c) {
        c = c == null || c === 0 ? a < b ? 1 : -1 : c;
        var d = -1;
        b = Math.max(Math.ceil((b - a) / c), 0);
        var e = Array(b);
        a = a;
        while (b--) e[++d] = a, a += c;
        return e
    }
    f["default"] = a
}), 66);
__d("DateHelpers", ["range"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = a.getDayOfWeek();
        b === 0 && (b = 7);
        b = Math.floor((a.getDayOfYear() - b + 11) / 7);
        b < 1 ? b = h(a.subtractYears(1)) : b > h(a) && (b = 1);
        return b
    }

    function h(a) {
        var b = a.getYear();
        a = a.startOfYear();
        a = a.getDayOfWeek();
        return a === 4 || a === 3 && i(b) ? 53 : 52
    }

    function i(a) {
        return a % 4 === 0 && a % 100 !== 0 || a % 400 === 0
    }

    function b(a, b, d) {
        switch (b) {
            case 2:
                return i(d) ? c("range")(1, 30).includes(a) : c("range")(1, 29).includes(a);
            case 4:
            case 6:
            case 9:
            case 11:
                return c("range")(1, 31).includes(a);
            default:
                return c("range")(1, 32).includes(a)
        }
    }
    g.getISOWeekNumber = a;
    g.isLeapYear = i;
    g.isValidDate = b
}), 98);
__d("AbstractCalendar.react", ["fbt", "DateFormatConfig", "DateHelpers", "List.react", "LocalDate", "RTLKeys", "joinClasses", "prop-types", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = 7,
        k = 6,
        l = "start",
        m = "mid",
        n = "end",
        o = "only";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$1 = function(a) {
                c.props.onCursorChange && c.props.onCursorChange(a)
            }, c.$2 = function(a) {
                if (!c.props.interactive) return;
                (c.props.allowDuplicateSelection || !c.isDateSelected(a)) && c.isDateValid(a) && (c.props.onSelectDateChange && c.props.onSelectDateChange(a))
            }, c.isDateSelected = function(a) {
                return !!c.props.selectDate && a.equals(c.props.selectDate)
            }, c.isDateHighlighted = function(a) {
                return !!c.props.highlightedDates && c.props.highlightedDates.some(function(b) {
                    return a.equals(b)
                })
            }, c.isDateValid = function(a) {
                return !c.props.dateRestraints || c.props.dateRestraints.every(function(b) {
                    return b(a)
                })
            }, c.$3 = function(a, b, d) {
                c.props.showWeekNumbers && b.unshift(c.$4(d)), a.push(b)
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var e = b.prototype;
        e.isDateHovered = function(a) {
            return !!this.props.hoveredDates && this.props.hoveredDates.some(function(b) {
                return a.equals(b)
            })
        };
        e.$4 = function(a) {
            if (this.props.weekStart === 6 && a.getDayOfWeek() === 0 || this.props.weekStart === 5 && [6, 0].indexOf(a.getDayOfWeek()) !== -1) {
                var b = 7 - this.props.weekStart;
                a = a.addDays(b)
            }
            b = this.props.classNames || {};
            a = d("DateHelpers").getISOWeekNumber(a);
            return i.jsx("div", {
                className: b.weekNumber,
                role: "rowheader",
                children: a
            }, "weekNumber")
        };
        e.render = function() {
            var a = this,
                b = this.props.showDaysOutsideOfMonth,
                d = this.props.focusDate,
                e = this.props.weeklyView,
                f = this.props.weekStart,
                g = e ? d.startOfWeek().addDays((f + 1) % 7) : d.startOfMonth();
            d = this.props.selectDate;
            var q = null,
                r = null;
            this.props.rangeSelectDate !== null && (q = this.props.rangeSelectDate);
            var s = !1;
            if (d && q) {
                var t = d.min(q);
                d = d.max(q);
                r = {
                    startDate: t,
                    endDate: d,
                    hasDuration: !t.equals(d)
                }
            } else this.props.selectedWeekStart && this.props.selectedWeekEnd && (r = {
                startDate: this.props.selectedWeekStart,
                endDate: this.props.selectedWeekEnd,
                hasDuration: !this.props.selectedWeekStart.equals(this.props.selectedWeekEnd)
            }, s = !0);
            var u = [],
                v = [];
            q = e || b ? 0 : (g.getDayOfWeek() + 6 - f) % 7;
            var w = this.props.classNames || {};
            for (var t = 0; t < q; ++t) v.push(i.jsx("span", {
                className: w.spacer,
                role: "gridcell"
            }, t));
            var x = e ? g.addWeeks(1) : g.addMonths(1);
            d = x;
            var y = g;
            if (b) {
                g = g.subtractDays((g.getDayOfWeek() + 6 - f) % 7);
                q = (f + 1) % 7;
                t = (x.getDayOfWeek() - q + 7) % 7;
                d = t === 0 ? x : x.subtractDays(t).addWeeks(1)
            }
            q = function() {
                var c = g;
                g = g.addDays(1);
                var d = g.getMonth() > c.getMonth() || c.getMonth() === 12 && g.getMonth() === 1,
                    h = (v.length + 1) % 7,
                    k = !1,
                    q = !1;
                b ? (k = c.getDayOfWeek() === (f + 1) % 7, q = c.getDayOfWeek() === f % 7) : (k = h === 1 || !e && c.getDayOfMonth() === 1, q = h === 0 || !e && d);
                h = null;
                d = null;
                if (a.props.multipleHighlightedRanges) {
                    var t = a.props.multipleHighlightedRanges.find(function(a) {
                        return c.isAfterOrEqual(a.startDate) && c.isBeforeOrEqual(a.endDate)
                    });
                    t ? r = {
                        startDate: t.startDate,
                        endDate: t.endDate,
                        hasDuration: !t.startDate.equals(t.endDate)
                    } : r = null
                }
                r && (c.isAfter(r.startDate) && c.isBefore(r.endDate) ? h = m : c.equals(r.startDate) ? h = l : c.equals(r.endDate) && (h = n), !r.hasDuration ? d = o : q ? d = k || h == l ? o : n : k ? d = h == n ? o : l : d = m);
                t = a.props.defaultCursor && a.props.defaultCursor.equals(c);
                v.push(i.jsx(p, {
                    date: c,
                    dayClassNames: a.props.dayClassNames,
                    dayInnerClassNames: a.props.dayInnerClassNames,
                    dayInnerFormatter: a.props.dayInnerFormatter,
                    dayRenderer: a.props.dayRenderer,
                    focused: c.equals(a.props.focusDate),
                    grayed: c.isBefore(y) || c.isAfterOrEqual(x),
                    highlighted: a.isDateHighlighted(c),
                    hovered: a.isDateHovered(c),
                    isRowStart: k,
                    isRowEnd: q,
                    isSelectedWeekRange: s,
                    onCursorChange: a.$1,
                    onMouseOver: a.props.onMouseOverDay,
                    onMouseOut: a.props.onMouseOutDay,
                    onSelect: a.$2,
                    rangePosition: h,
                    setupFocusRef: t ? a.props.setupFocusRef : void 0,
                    rowPosition: d,
                    selected: a.isDateSelected(c),
                    tabIndex: t ? 0 : -1,
                    valid: a.isDateValid(c)
                }, c));
                if (q && !e) {
                    if (v.length < j) {
                        k = j - v.length;
                        for (var h = 0; h < k; h++) v.push(i.jsx("span", {
                            className: w.spacer,
                            role: "gridcell"
                        }, h))
                    }
                    a.$3(u, v, c);
                    v = []
                }
            };
            while (g.isBefore(d)) q();
            v.length && this.$3(u, v, g);
            if (!this.props.allowVariableRowCount)
                for (var t = u.length; t < k; ++t) u.push(i.jsx("span", {
                    className: w.spacer,
                    role: "gridcell"
                }, t));
            u = u.map(function(a, b) {
                return i.jsx("div", {
                    className: w.row,
                    role: "row",
                    children: a
                }, b)
            });
            q = [];
            this.props.showWeekNumbers && q.push(i.jsx("li", {
                "aria-label": h._("Week number"),
                className: w.weekNumberHeading,
                role: "columnheader",
                children: h._("Wk")
            }, "title"));
            d = c("DateFormatConfig").shortDayNames;
            this.props.useDayInitials && (d = d.map(function(a) {
                if (a.length === 1 || /[A-Za-z]/.test(a.charAt(0))) return a.charAt(0).toUpperCase();
                else return a
            }));
            for (var t = 0; t < j; ++t) q.push(i.jsx("li", {
                className: w.dayName,
                role: "columnheader",
                style: this.props.dayNameStyle,
                children: d[(f + t) % 7]
            }, t));
            d = babelHelpers["extends"]({}, this.props);
            delete d.allowVariableRowCount;
            delete d.allowDuplicateSelection;
            delete d.classNames;
            delete d.dayClassNames;
            delete d.dayInnerClassNames;
            delete d.dayInnerFormatter;
            delete d.dayNameStyle;
            delete d.dayRenderer;
            delete d.dateRestraints;
            delete d.defaultCursor;
            delete d.focusDate;
            delete d.highlightedDates;
            delete d.interactive;
            delete d.isRowStart;
            delete d.isRowEnd;
            delete d.onCursorChange;
            delete d.onSelectDateChange;
            delete d.rangeSelectDate;
            delete d.selectDate;
            delete d.selectedWeekStart;
            delete d.selectedWeekEnd;
            delete d.setupFocusRef;
            delete d.showWeekNumbers;
            delete d.hoveredDates;
            delete d.weeklyView;
            delete d.weekStart;
            delete d.onMouseOverDay;
            delete d.onMouseOutDay;
            delete d.onFocusDateChange;
            delete d.highlightedTimes;
            delete d.showDaysOutsideOfMonth;
            return i.jsxs("div", babelHelpers["extends"]({}, d, {
                className: c("joinClasses")(this.props.className, w.root, this.props.interactive ? w.interactive : null, this.props.showWeekNumbers ? w.weekNumbers : null),
                role: "grid",
                children: [i.jsx(c("List.react"), {
                    className: w.dayNames,
                    border: "none",
                    direction: "horizontal",
                    role: "row",
                    spacing: "none",
                    children: q
                }), i.jsx("div", {
                    className: w.monthViewDayGrid,
                    children: u
                })]
            }))
        };
        return b
    }(i.Component);
    a.propTypes = {
        allowVariableRowCount: c("prop-types").bool,
        allowDuplicateSelection: c("prop-types").bool,
        classNames: c("prop-types").shape({
            dayName: c("prop-types").string,
            dayNames: c("prop-types").string,
            interactive: c("prop-types").string,
            monthViewDayGrid: c("prop-types").string,
            root: c("prop-types").string,
            row: c("prop-types").string,
            spacer: c("prop-types").string
        }),
        dayClassNames: c("prop-types").shape({
            day: c("prop-types").string,
            dayInRange: c("prop-types").string,
            dayRangeEndpoint: c("prop-types").string,
            dayRangeLeft: c("prop-types").string,
            dayRangeOnly: c("prop-types").string,
            dayRangeRight: c("prop-types").string,
            dayValid: c("prop-types").string,
            dayInvalid: c("prop-types").string
        }),
        dayInnerClassNames: c("prop-types").shape({
            dayInner: c("prop-types").string,
            dayInnerFocused: c("prop-types").string,
            dayInnerHighlighted: c("prop-types").string,
            dayInnerHovered: c("prop-types").string,
            dayInnerSelected: c("prop-types").string,
            dayInnerNotSelected: c("prop-types").string
        }),
        dayInnerFormatter: c("prop-types").func,
        dayNameStyle: c("prop-types").object,
        dayRenderer: c("prop-types").func,
        dateRestraints: c("prop-types").arrayOf(c("prop-types").func),
        defaultCursor: c("prop-types").instanceOf(c("LocalDate")),
        focusDate: c("prop-types").instanceOf(c("LocalDate")).isRequired,
        highlightedDates: c("prop-types").arrayOf(c("prop-types").instanceOf(c("LocalDate"))),
        hoveredDates: c("prop-types").arrayOf(c("prop-types").instanceOf(c("LocalDate"))),
        interactive: c("prop-types").bool,
        onCursorChange: c("prop-types").func,
        onMouseOverDay: c("prop-types").func,
        onMouseOutDay: c("prop-types").func,
        onSelectDateChange: c("prop-types").func,
        rangeSelectDate: c("prop-types").instanceOf(c("LocalDate")),
        selectDate: c("prop-types").instanceOf(c("LocalDate")),
        selectedWeekStart: c("prop-types").instanceOf(c("LocalDate")),
        selectedWeekEnd: c("prop-types").instanceOf(c("LocalDate")),
        setupFocusRef: c("prop-types").func,
        showWeekNumbers: c("prop-types").bool,
        weeklyView: c("prop-types").bool
    };
    a.defaultProps = {
        allowDuplicateSelection: !1,
        allowVariableRowCount: !0,
        classNames: {},
        dayClassNames: {},
        dayInnerClassNames: {},
        interactive: !0,
        rangeSelectDate: null,
        showWeekNumbers: !1,
        weeklyView: !1,
        weekStart: c("DateFormatConfig").weekStart
    };
    var p = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a() {
            var a, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (a = d = b.call.apply(b, [this].concat(f)) || this, d.$2 = function(a) {
                switch (a.keyCode) {
                    case c("RTLKeys").RETURN:
                    case c("RTLKeys").SPACE:
                        a.preventDefault();
                        d.$3();
                        break;
                    case c("RTLKeys").getLeft():
                        a.preventDefault();
                        d.$4(-1);
                        break;
                    case c("RTLKeys").getRight():
                        a.preventDefault();
                        d.$4(1);
                        break;
                    case c("RTLKeys").UP:
                        a.preventDefault();
                        d.$4(-7);
                        break;
                    case c("RTLKeys").DOWN:
                        a.preventDefault();
                        d.$4(7);
                        break;
                    case c("RTLKeys").HOME:
                        a.preventDefault();
                        d.$5(d.props.date.startOfMonth());
                        break;
                    case c("RTLKeys").END:
                        a.preventDefault();
                        d.$5(d.props.date.startOfMonth().addMonths(1).subtractDays(1));
                        break;
                    case c("RTLKeys").PAGE_UP:
                        a.preventDefault();
                        d.$6(a.ctrlKey || a.altKey ? -12 : -1);
                        break;
                    case c("RTLKeys").PAGE_DOWN:
                        a.preventDefault();
                        d.$6(a.ctrlKey || a.altKey ? 12 : 1);
                        break
                }
            }, d.$5 = function(a) {
                d.props.onCursorChange(a)
            }, d.$4 = function(a) {
                d.$5(d.props.date.addDays(a))
            }, d.$6 = function(a) {
                d.$5(d.props.date.addMonths(a))
            }, d.$7 = function(a) {
                a.preventDefault()
            }, d.$8 = function(a) {
                d.props.onMouseOut && d.props.onMouseOut(d.props.date)
            }, d.$9 = function(a) {
                d.props.onMouseOver && d.props.onMouseOver(d.props.date)
            }, d.$3 = function() {
                d.props.valid && d.props.onSelect(d.props.date)
            }, a) || babelHelpers.assertThisInitialized(d)
        }
        var d = a.prototype;
        d.$1 = function(a) {
            return c("joinClasses").apply(this, Object.keys(a).filter(function(b) {
                return b != "undefined" && a[b]
            }))
        };
        d.render = function() {
            var a, b = this.props,
                c = b.dayRenderer,
                d = b.isRowStart,
                e = b.isRowEnd;
            b = babelHelpers.objectWithoutPropertiesLoose(b, ["dayRenderer", "isRowStart", "isRowEnd"]);
            var f = b.rowPosition,
                g = b.rangePosition,
                h = b.isSelectedWeekRange;
            if (c != null) return c({
                date: b.date,
                focusRef: b.setupFocusRef,
                isGrayed: b.grayed,
                isHighlighted: b.highlighted,
                isRowStart: d,
                isRowEnd: e,
                isSelected: b.selected,
                isValid: b.valid,
                onClick: this.$3,
                onKeydown: this.$2,
                rangePosition: g,
                tabIndex: b.tabIndex
            });
            c = b.dayClassNames;
            d = b.dayInnerClassNames;
            e = g == l || g == m && f == l;
            var j = g == n || g == m && f == n;
            f = f == o;
            h = (g == l || g == n) && !h;
            e = (a = {}, a[c.day] = !0, a[c.dayInRange] = g, a[c.dayRangeEndpoint] = h, a[c.dayRangeLeft] = e, a[c.dayRangeOnly] = f, a[c.dayRangeRight] = j, a[c.dayValid] = b.valid, a[c.dayInvalid] = !b.valid, a);
            j = (f = {}, f[d.dayInner] = !0, f[d.dayInnerSelected] = b.selected, f[d.dayInnerNotSelected] = !b.selected && !h, f[d.dayInnerFocused] = b.focused, f[d.dayInnerGrayed] = b.grayed, f[d.dayInnerHighlighted] = b.highlighted, f[d.dayInnerHovered] = b.hovered, f[d.dayInnerRangeEndpoint] = h, f);
            c = {};
            b.dayInnerFormatter && (c = b.dayInnerFormatter(b.date, {
                focused: b.focused,
                highlighted: b.highlighted,
                hovered: b.hovered,
                rangePosition: b.rangePosition,
                selected: b.selected,
                valid: b.valid
            }));
            return i.jsx("span", {
                "aria-selected": b.selected || g != null,
                className: this.$1(e),
                "data-sigil": b.valid ? "touchable" : null,
                role: "gridcell",
                style: c,
                children: i.jsx("span", {
                    "aria-disabled": !b.valid,
                    "aria-pressed": b.selected ? !0 : void 0,
                    className: this.$1(j),
                    onMouseDown: this.$7,
                    onMouseOver: this.$9,
                    onMouseOut: this.$8,
                    onClick: this.$3,
                    onKeyDown: this.$2,
                    ref: this.props.setupFocusRef,
                    role: "button",
                    tabIndex: b.tabIndex,
                    children: this.props.date.getDayOfMonth()
                })
            })
        };
        return a
    }(i.Component);
    p.propTypes = {
        date: c("prop-types").instanceOf(c("LocalDate")).isRequired,
        dayInnerFormatter: c("prop-types").func,
        dayRenderer: c("prop-types").func,
        focused: c("prop-types").bool,
        grayed: c("prop-types").bool,
        highlighted: c("prop-types").bool,
        hovered: c("prop-types").bool,
        isRowStart: c("prop-types").bool,
        isRowEnd: c("prop-types").bool,
        isSelectedWeekRange: c("prop-types").bool,
        onCursorChange: c("prop-types").func.isRequired,
        onSelect: c("prop-types").func.isRequired,
        rangePosition: c("prop-types").oneOf([l, m, n]),
        rowPosition: c("prop-types").oneOf([l, m, n, o]),
        selected: c("prop-types").bool,
        setupFocusRef: c("prop-types").func,
        tabIndex: c("prop-types").number,
        valid: c("prop-types").bool
    };
    g["default"] = a
}), 98);
__d("ObserveResize.react", ["useResizeObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.onResize;
        a = a.children;
        b = c("useResizeObserver")(b);
        return a(b)
    }
    g["default"] = a
}), 98);
__d("SimpleObjectsPool", ["invariant"], (function(a, b, c, d, e, f, g) {
    a = function() {
        "use strict";

        function a(a) {
            this.$1 = a, this.$2 = []
        }
        var b = a.prototype;
        b.get = function() {
            if (this.$2.length) return this.$2.pop();
            else {
                var a = this.$1;
                return new a()
            }
        };
        b.put = function(a) {
            a instanceof this.$1 || g(0, 4227), this.$2.push(a)
        };
        return a
    }();
    e.exports = a
}), null);
__d("PersistentAnimationFrame", ["SimpleObjectsPool", "Visibility", "cancelAnimationFrame", "requestAnimationFrame"], (function(a, b, c, d, e, f) {
    var g = 16,
        h, i = {},
        j = !0;

    function k() {
        h || (h = new(b("SimpleObjectsPool"))(l));
        return h
    }
    var l = function() {
        "use strict";

        function a() {
            var a = this;
            this.$1 = function() {
                a.callback(), a.$2(), k().put(a)
            }
        }
        a.request = function(a) {
            return !a ? 0 : k().get().request(a)
        };
        a.cancel = function(a) {
            if (a === 0) return;
            a = i[String(a)];
            a && a.cancel()
        };
        var c = a.prototype;
        c.request = function(a) {
            j && m();
            this.callback = a;
            this.hidden = b("Visibility").isHidden();
            this.hidden ? this.intID = setTimeout(this.$1, g) : this.intID = b("requestAnimationFrame")(this.$1);
            this.strID = String(this.intID);
            i[this.strID] = this;
            return this.intID
        };
        c.cancel = function() {
            this.strID && (this.hidden ? clearTimeout(this.intID) : b("cancelAnimationFrame")(this.intID), this.$2(), k().put(this))
        };
        c.$2 = function() {
            delete i[this.strID], delete this.intID, delete this.strID, delete this.callback, delete this.hidden
        };
        return a
    }();

    function m() {
        var a;
        j = !1;
        (a = b("Visibility")).addListener(a.HIDDEN, n);
        a.addListener(a.VISIBLE, n)
    }

    function n() {
        Object.keys(i).forEach(function(a) {
            a = i[a];
            var b = a.callback;
            a.cancel();
            b()
        })
    }
    e.exports = l
}), null);
__d("requestPersistentAnimationFrame", ["PersistentAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("PersistentAnimationFrame").request
}), 98);
__d("ResizeEventHandler", ["requestPersistentAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            var b = this;
            this.$1 = !1;
            this.$2 = !1;
            this.handleEvent = function() {
                b.$2 === !1 && (b.$2 = !0, c("requestPersistentAnimationFrame")(b.$4))
            };
            this.$4 = function() {
                b.$2 = !1, b.$1 === !1 && b.$3()
            };
            this.$3 = a
        }
        var b = a.prototype;
        b.cancel = function() {
            this.$1 = !0
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("ResponsiveBlock.react", ["cx", "ObserveResize.react", "ResizeEventHandler", "joinClasses", "mergeRefs", "react"], (function(a, b, c, d, e, f, g, h) {
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = d = a.call.apply(a, [this].concat(f)) || this, d.$1 = null, d.$2 = null, d.$3 = null, d.$4 = new(c("ResizeEventHandler"))(function() {
                if (d.$1 == null) return;
                var a = d.$1.offsetWidth,
                    b = d.$1.offsetHeight;
                (a !== d.$3 || b !== d.$2) && (d.$3 = a, d.$2 = b, d.props.onResize(a, b))
            }), d.$5 = function(a, b) {
                b instanceof HTMLElement && (d.$1 = b, d.$4.handleEvent())
            }, b) || babelHelpers.assertThisInitialized(d)
        }
        var d = b.prototype;
        d.componentWillUnmount = function() {
            this.$4.cancel()
        };
        d.render = function() {
            var a = this.props;
            a.onResize;
            var b = a.className,
                d = a.children,
                e = a.forwardedRef,
                f = babelHelpers.objectWithoutPropertiesLoose(a, ["onResize", "className", "children", "forwardedRef"]);
            return i.jsx(c("ObserveResize.react"), {
                onResize: this.$5,
                children: function(a) {
                    return i.jsx("div", babelHelpers["extends"]({}, f, {
                        className: c("joinClasses")("_4u-c", b),
                        ref: c("mergeRefs")(a, e),
                        children: d
                    }))
                }
            })
        };
        return b
    }(i.Component);
    g["default"] = a
}), 98);
__d("SimpleFBAuthenticatedXHRRequest", ["invariant", "CurrentUser", "DTSG", "DTSGUtils", "ServerJSDefine", "SprinkleConfig", "StaticSiteData", "XHRRequest", "isFacebookURI", "uniqueRequestID"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(c, d) {
            var e;
            c = a.call(this, c) || this;
            e = (e = {}, e[b("StaticSiteData").jsmod_key] = b("ServerJSDefine").getLoadedModuleHash(), e.__req = b("uniqueRequestID")(), e.__a = 1, e.__user = b("CurrentUser").getID(), e);
            a.prototype.setData.call(babelHelpers.assertThisInitialized(c), babelHelpers["extends"]({}, d, e));
            return c
        }
        var d = c.prototype;
        d.send = function() {
            var c = this;
            if (!b("isFacebookURI")(this.getURI())) return a.prototype.send.call(this);
            if (b("DTSG").getCachedToken) {
                var d = b("DTSG").getCachedToken();
                if (d) return this.sendOnDTSGToken(d);
                else {
                    b("DTSG").getToken().done(function(a) {
                        return c.sendOnDTSGToken(a)
                    });
                    return this
                }
            } else this.sendOnDTSGToken(b("DTSG").getToken())
        };
        d.sendOnDTSGToken = function(c) {
            if (c) {
                a.prototype.setData.call(this, babelHelpers["extends"]({}, this.getData(), {
                    fb_dtsg: c
                }));
                if (b("SprinkleConfig").param_name) {
                    var d;
                    a.prototype.setData.call(this, babelHelpers["extends"]({}, this.getData(), (d = {}, d[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(c), d)))
                }
            }
            return a.prototype.send.call(this)
        };
        d.setData = function(a) {
            g(0, 5518)
        };
        c.parseResponse = function(a) {
            return JSON.parse(a.substr(9))
        };
        c.getPayload = function(a) {
            a = c.parseResponse(a).payload;
            return a.payload ? a.payload : a
        };
        return c
    }(b("XHRRequest"));
    e.exports = a
}), null);
__d("XFantailLogController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ajax/fantail/", {
        service: {
            type: "String",
            required: !0
        }
    })
}), null);
__d("FantailLogQueue", ["ChannelClientID", "CircularBuffer", "PHPQuerySerializer", "SimpleFBAuthenticatedXHRRequest", "XFantailLogController", "destroyOnUnload", "setIntervalAcrossTransitions", "sprintf"], (function(a, b, c, d, e, f, g) {
    var h = {
        DEBUG: "debug",
        INFO: "info",
        WARN: "warn",
        ERROR: "error"
    };
    a = function() {
        function a(a) {
            this.$2 = a, this.$3 = new(c("CircularBuffer"))(200), c("setIntervalAcrossTransitions")(this.$4.bind(this), 30 * 1e3), c("destroyOnUnload")(this.$4.bind(this))
        }
        a.get = function(b) {
            a.$1 = a.$1 || {};
            a.$1[b] = a.$1[b] || new a(b);
            return a.$1[b]
        };
        var b = a.prototype;
        b.debug = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            this.$5.apply(this, [h.DEBUG, a].concat(c))
        };
        b.info = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            this.$5.apply(this, [h.INFO, a].concat(c))
        };
        b.warn = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            this.$5.apply(this, [h.WARN, a].concat(c))
        };
        b.error = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            this.$5.apply(this, [h.ERROR, a].concat(c))
        };
        b.$5 = function(a, b) {
            for (var e = arguments.length, f = new Array(e > 2 ? e - 2 : 0), g = 2; g < e; g++) f[g - 2] = arguments[g];
            var h = c("sprintf").apply(void 0, [b].concat(f));
            this.$3.write({
                log_time: Date.now(),
                log: h,
                severity: a,
                device_id: d("ChannelClientID").getID()
            })
        };
        b.$4 = function() {
            var a = this.$3.read();
            if (a.length > 0) {
                var b = {
                    log_time: [],
                    log: [],
                    severity: [],
                    device_id: []
                };
                a.forEach(function(a) {
                    b.log_time.push(a.log_time), b.log.push(a.log), b.severity.push(a.severity), b.device_id.push(a.device_id)
                });
                this.$3.clear();
                a = c("XFantailLogController").getURIBuilder().setString("service", this.$2).getURI();
                new(c("SimpleFBAuthenticatedXHRRequest"))(a, b).setMethod("POST").setDataSerializer(d("PHPQuerySerializer").serialize).setRequestHeader("Content-Type", "application/x-www-form-urlencoded").send()
            }
        };
        return a
    }();
    g["default"] = a
}), 98);