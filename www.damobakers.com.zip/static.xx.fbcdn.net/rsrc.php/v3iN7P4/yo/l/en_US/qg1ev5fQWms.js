if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometProfilePhotoForActor_actor.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        };
        return {
            argumentDefinitions: [{
                defaultValue: !1,
                kind: "LocalArgument",
                name: "allowProfileVideo"
            }, {
                defaultValue: !0,
                kind: "LocalArgument",
                name: "displayAvailability"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "height"
            }, {
                defaultValue: !0,
                kind: "LocalArgument",
                name: "linkToUnseenStory"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "width"
            }],
            kind: "Fragment",
            metadata: null,
            name: "CometProfilePhotoForActor_actor",
            selections: [{
                args: null,
                kind: "FragmentSpread",
                name: "ProfileCometProfileLink_actor"
            }, {
                args: [{
                    kind: "Variable",
                    name: "enabled",
                    variableName: "linkToUnseenStory"
                }],
                kind: "FragmentSpread",
                name: "useActorStoryStatus_actor"
            }, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "url",
                    storageKey: null
                }],
                type: "Entity",
                abstractKey: "__isEntity"
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            }, a, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            }, {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "height",
                    variableName: "height"
                }, {
                    kind: "Variable",
                    name: "scale",
                    variableName: "scale"
                }, {
                    kind: "Variable",
                    name: "width",
                    variableName: "width"
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "uri",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "width",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "height",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "scale",
                    storageKey: null
                }],
                storageKey: null
            }, {
                condition: "displayAvailability",
                kind: "Condition",
                passingValue: !0,
                selections: [{
                    kind: "InlineFragment",
                    selections: [{
                        kind: "ClientExtension",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "availability",
                            storageKey: null
                        }]
                    }],
                    type: "User",
                    abstractKey: null
                }]
            }, {
                condition: "allowProfileVideo",
                kind: "Condition",
                passingValue: !0,
                selections: [{
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "ProfileVideo",
                        kind: "LinkedField",
                        name: "profile_video",
                        plural: !1,
                        selections: [a, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "CometProfileVideoSection_profileVideo"
                        }],
                        storageKey: null
                    }],
                    type: "Profile",
                    abstractKey: "__isProfile"
                }]
            }],
            type: "Actor",
            abstractKey: "__isActor"
        }
    }();
    e.exports = a
}), null);
__d("useActorStoryStatus_actor.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            b = {
                alias: null,
                args: null,
                concreteType: "Story",
                kind: "LinkedField",
                name: "first_story_to_show",
                plural: !1,
                selections: [a, {
                    alias: null,
                    args: null,
                    concreteType: "StoryCardSeenState",
                    kind: "LinkedField",
                    name: "story_card_seen_state",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_seen_by_viewer",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            };
        return {
            argumentDefinitions: [{
                defaultValue: !0,
                kind: "LocalArgument",
                name: "enabled"
            }],
            kind: "Fragment",
            metadata: null,
            name: "useActorStoryStatus_actor",
            selections: [{
                condition: "enabled",
                kind: "Condition",
                passingValue: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "__typename",
                    storageKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "pages_story_bucket_v2",
                        plural: !1,
                        selections: [a, b],
                        storageKey: null
                    }],
                    type: "Page",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: [{
                            kind: "Literal",
                            name: "first",
                            value: 1
                        }],
                        concreteType: "DirectInboxBroadcastBucketConnection",
                        kind: "LinkedField",
                        name: "story_bucket",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "DirectMessageThreadBucket",
                            kind: "LinkedField",
                            name: "nodes",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "should_show_close_friend_badge",
                                storageKey: null
                            }, a, b],
                            storageKey: null
                        }],
                        storageKey: "story_bucket(first:1)"
                    }],
                    type: "User",
                    abstractKey: null
                }]
            }],
            type: "Actor",
            abstractKey: "__isActor"
        }
    }();
    e.exports = a
}), null);
__d("CometTextWithEntitiesRelay_textWithEntities$normalization.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "length",
                storageKey: null
            },
            b = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "offset",
                storageKey: null
            },
            c = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            e = [{
                kind: "Literal",
                name: "delight_surface",
                value: "COMMENT"
            }],
            f = [c],
            g = {
                kind: "InlineFragment",
                selections: f,
                type: "Node",
                abstractKey: "__isNode"
            },
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            i = [c, h],
            j = {
                alias: null,
                args: null,
                concreteType: "WorkForeignEntityInfo",
                kind: "LinkedField",
                name: "work_foreign_entity_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }],
                storageKey: null
            };
        return {
            kind: "SplitOperation",
            metadata: {},
            name: "CometTextWithEntitiesRelay_textWithEntities$normalization",
            selections: [{
                alias: null,
                args: null,
                concreteType: "DelightAtRange",
                kind: "LinkedField",
                name: "delight_ranges",
                plural: !0,
                selections: [a, b, {
                    alias: null,
                    args: null,
                    concreteType: "TextDelightCampaign",
                    kind: "LinkedField",
                    name: "campaign",
                    plural: !1,
                    selections: [c, d, {
                        alias: null,
                        args: e,
                        concreteType: "TextDelightStylePair",
                        kind: "LinkedField",
                        name: "delight_styles",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "style",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "value",
                            storageKey: null
                        }],
                        storageKey: 'delight_styles(delight_surface:"COMMENT")'
                    }, {
                        alias: null,
                        args: e,
                        concreteType: "DelightsAnimation",
                        kind: "LinkedField",
                        name: "delight_asset",
                        plural: !1,
                        selections: f,
                        storageKey: 'delight_asset(delight_surface:"COMMENT")'
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "text_enrichment_url",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "ImageAtRange",
                kind: "LinkedField",
                name: "image_ranges",
                plural: !0,
                selections: [a, b, {
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "entity_with_image",
                    plural: !1,
                    selections: [d, {
                        alias: null,
                        args: [{
                            kind: "Variable",
                            name: "scale",
                            variableName: "scale"
                        }],
                        concreteType: "Image",
                        kind: "LinkedField",
                        name: "image",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "height",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "scale",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "uri",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "width",
                            storageKey: null
                        }],
                        storageKey: null
                    }, g],
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "InlineStyleAtRange",
                kind: "LinkedField",
                name: "inline_style_ranges",
                plural: !0,
                selections: [a, b, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "inline_style",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "AggregatedEntitiesAtRange",
                kind: "LinkedField",
                name: "aggregated_ranges",
                plural: !0,
                selections: [a, b, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "count",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "sample_entities",
                    plural: !0,
                    selections: [d, {
                        kind: "InlineFragment",
                        selections: i,
                        type: "User",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: i,
                        type: "Page",
                        abstractKey: null
                    }, g],
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "EntityAtRange",
                kind: "LinkedField",
                name: "ranges",
                plural: !0,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "entity",
                    plural: !1,
                    selections: [d, {
                        kind: "TypeDiscriminator",
                        abstractKey: "__isEntity"
                    }, {
                        alias: null,
                        args: [{
                            kind: "Literal",
                            name: "site",
                            value: "comet"
                        }],
                        kind: "ScalarField",
                        name: "url",
                        storageKey: 'url(site:"comet")'
                    }, {
                        alias: "mobileUrl",
                        args: [{
                            kind: "Literal",
                            name: "site",
                            value: "mobile"
                        }],
                        kind: "ScalarField",
                        name: "url",
                        storageKey: 'url(site:"mobile")'
                    }, {
                        kind: "InlineFragment",
                        selections: [c, {
                            kind: "InlineFragment",
                            selections: [{
                                alias: "profile_url",
                                args: null,
                                kind: "ScalarField",
                                name: "url",
                                storageKey: null
                            }],
                            type: "Entity",
                            abstractKey: "__isEntity"
                        }],
                        type: "Actor",
                        abstractKey: "__isActor"
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            args: null,
                            documentName: "CometTextWithEntitiesRelay_textWithEntities",
                            fragmentName: "GroupsCometHashtagsStoryMessageHashtagLink_hashtag",
                            fragmentPropName: "hashtag",
                            kind: "ModuleImport"
                        }],
                        type: "GroupHashtag",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            args: null,
                            documentName: "CometTextWithEntitiesRelay_textWithEntities",
                            fragmentName: "PagesCometPageLink_page",
                            fragmentPropName: "page",
                            kind: "ModuleImport"
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "category_type",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "verification_status",
                            storageKey: null
                        }, c, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "is_verified",
                            storageKey: null
                        }],
                        type: "Page",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "external_url",
                            storageKey: null
                        }],
                        type: "ExternalUrl",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "time_index",
                            storageKey: null
                        }],
                        type: "VideoTimeIndex",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "web_link",
                            plural: !1,
                            selections: [d, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "url",
                                storageKey: null
                            }, {
                                kind: "InlineFragment",
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "fbclid",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "lynx_mode",
                                    storageKey: null
                                }],
                                type: "ExternalWebLink",
                                abstractKey: null
                            }],
                            storageKey: null
                        }],
                        type: "WebLinkable",
                        abstractKey: "__isWebLinkable"
                    }, {
                        kind: "InlineFragment",
                        selections: [j, {
                            alias: null,
                            args: null,
                            concreteType: "WorkUserInfo",
                            kind: "LinkedField",
                            name: "work_info",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "is_active_account",
                                storageKey: null
                            }],
                            storageKey: null
                        }],
                        type: "User",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [j, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "is_multi_company_group",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "work_official_status",
                            storageKey: null
                        }],
                        type: "Group",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "Group",
                            kind: "LinkedField",
                            name: "target_group",
                            plural: !1,
                            selections: [{
                                args: null,
                                documentName: "CometTitleSentenceGroupJoinButtonRenderer_entity",
                                fragmentName: "CometFeedStoryCommunityAttributionTitleJoinButton_group",
                                fragmentPropName: "group",
                                kind: "ModuleImport"
                            }, c],
                            storageKey: null
                        }],
                        type: "TitleSentenceGroupJoinButton",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "deep_link_number",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "Page",
                            kind: "LinkedField",
                            name: "page",
                            plural: !1,
                            selections: [{
                                alias: "use_whatsapp_deeplinks_plugin",
                                args: [{
                                    kind: "Literal",
                                    name: "gk_name",
                                    value: "bmxm_ctwa_perf_page_launch_h22022"
                                }],
                                concreteType: "EntGKCheck",
                                kind: "LinkedField",
                                name: "gk_check",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "passes_gk",
                                    storageKey: null
                                }],
                                storageKey: 'gk_check(gk_name:"bmxm_ctwa_perf_page_launch_h22022")'
                            }, c],
                            storageKey: null
                        }],
                        type: "PageWhatsAppNumber",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [h, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "ticker_symbol",
                            storageKey: null
                        }],
                        type: "KGTickerNode",
                        abstractKey: null
                    }, g],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "entity_is_weak_reference",
                    storageKey: null
                }, a, b],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "ColorAtRange",
                kind: "LinkedField",
                name: "color_ranges",
                plural: !0,
                selections: [a, b, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "hex_rgb_color_with_pound_key",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "text",
                storageKey: null
            }]
        }
    }();
    e.exports = a
}), null);
__d("CometDensityAwarenessContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = !1;
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("useAfterPaint", ["cancelAnimationFrame", "react", "requestAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect;

    function a(a) {
        h(function() {
            var b = null,
                d = c("requestAnimationFrame")(function() {
                    d = c("requestAnimationFrame")(function() {
                        b = a()
                    })
                });
            return function() {
                c("cancelAnimationFrame")(d), b && b()
            }
        }, [a])
    }
    g["default"] = a
}), 98);
__d("useSimpleImpression", ["HiddenSubtreePassiveContext", "react", "useAfterPaint", "useDynamicCallbackDANGEROUS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useContext,
        j = b.useRef;

    function a(a) {
        var b = i(c("HiddenSubtreePassiveContext")),
            d = j(!0),
            e = c("useDynamicCallbackDANGEROUS")(a);
        a = h(function() {
            var a = function(a) {
                a = a.hiddenOrBackgrounded_FIXME;
                a === !1 && d.current === !0 && e();
                a = b.getCurrentState();
                d.current = a.hiddenOrBackgrounded_FIXME
            };
            a(b.getCurrentState());
            var c = b.subscribeToChanges(a);
            return function() {
                return c.remove()
            }
        }, [b, e]);
        c("useAfterPaint")(a)
    }
    g["default"] = a
}), 98);
__d("BaseAspectRatioContainer.react", ["react", "stylex", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.aspectRatio,
            d = a.children,
            e = a.contentStyle,
            f = a.style,
            g = a.testid;
        g = a.xstyle;
        if (b <= 0) throw c("unrecoverableViolation")("Aspect ratio must be a non-zero, positive number: " + b, "comet_ui");
        return h.jsx("div", {
            className: c("stylex")(i.container, g),
            "data-testid": void 0,
            style: babelHelpers["extends"]({}, f, {
                paddingTop: 100 / b + "%"
            }),
            children: d != null && h.jsx("div", {
                className: c("stylex")(i.content, e),
                children: d
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var i = {
        container: {
            height: "xqtp20y",
            position: "x1n2onr6",
            width: "xh8yej3"
        },
        content: {
            alignItems: "x1qjc9v5",
            borderBottomStyle: "x1q0q8m5",
            borderBottomWidth: "x1qhh985",
            borderEndStyle: "xu3j5b3",
            borderEndWidth: "xcfux6l",
            borderStartStyle: "x26u7qi",
            borderStartWidth: "xm0m39n",
            borderTopStyle: "x13fuv20",
            borderTopWidth: "x972fbf",
            bottom: "x1ey2m1c",
            boxSizing: "x9f619",
            display: "x78zum5",
            end: "xds687c",
            flexDirection: "xdt5ytf",
            flexGrow: "x1iyjqo2",
            flexShrink: "xs83m0k",
            justifyContent: "x1qughib",
            marginBottom: "xat24cr",
            marginEnd: "x11i5rnm",
            marginStart: "x1mh8g0r",
            marginTop: "xdj266r",
            minHeight: "x2lwn1j",
            minWidth: "xeuugli",
            paddingBottom: "x18d9i69",
            paddingEnd: "x4uap5",
            paddingStart: "xkhd6sd",
            paddingTop: "xexx8yu",
            position: "x10l6tqk",
            start: "x17qophe",
            top: "x13vifvy",
            zIndex: "x1ja2u2z"
        }
    };
    g["default"] = a
}), 98);
__d("CometAspectRatioContainer.react", ["BaseAspectRatioContainer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react"), g["default"] = c("BaseAspectRatioContainer.react")
}), 98);
__d("BaseHovercardTriggerWrapper.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.display;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["display"]);
        return b === "inline" ? h.jsx("span", babelHelpers["extends"]({}, a, {
            className: "xt0psk2"
        })) : h.jsx("div", babelHelpers["extends"]({}, a, {
            className: b === "inline-block" ? "x1rg5ohu" : ""
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSuppressHovercards", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = h.createContext(!1);

    function a(a) {
        a = a.children;
        return h.jsx(j.Provider, {
            value: !0,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        return i(j)
    }
    g.CometSuppressHovercardsContext = j;
    g.CometSuppressHovercardsProvider = a;
    g.useIsHovercardSuppressed = b
}), 98);
__d("useBaseHovercardTrigger", ["BaseContextualLayer.react", "BaseHovercardTriggerWrapper.react", "CometErrorBoundary.react", "CometHeroInteractionContextPassthrough.react", "CometPlaceholder.react", "FocusInertRegion.react", "FocusWithinHandler.react", "HiddenSubtreeContextProvider.react", "focusScopeQueries", "react", "stylex", "useCometDisplayTimingTrackerForInteraction", "useCometPrerenderer", "useDelayedState", "useFadeEffect"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useRef,
        l = b.useState,
        m = 300,
        n = 50,
        o = {
            disablePointerEvents: {
                pointerEvents: "x47corl"
            },
            hovercard: {
                opacity: "xg01cxk",
                transitionDuration: "x1ebt8du",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1dhq9h"
            },
            hovercardVisible: {
                opacity: "x1hc1fzr",
                transitionDuration: "xhb22t3",
                transitionTimingFunction: "xls3em1"
            }
        };

    function a(a) {
        var b = a.children,
            e = a.display,
            f = a.fallback,
            g = a.onLoadEntryPoint,
            p = a.onVisibilityChange,
            q = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "display", "fallback", "onLoadEntryPoint", "onVisibilityChange"]);
        a = c("useDelayedState")(!1);
        var r = a[0],
            s = a[1];
        a = l(!1);
        var t = a[0],
            u = a[1];
        a = l(!1);
        var v = a[0],
            w = a[1];
        a = l(!1);
        var x = a[0],
            y = a[1];
        a = l(!1);
        var z = a[0],
            A = a[1],
            B = x && z && !v,
            C = k(null),
            D = k(null),
            E = c("useCometDisplayTimingTrackerForInteraction")("HoverCard"),
            F = i(function() {
                s(!1), u(!1), w(!0)
            }, [s]),
            G = i(function(a) {
                a.key === "Escape" && F()
            }, [F]),
            H = r || t || B,
            I = k(H);
        j(function() {
            I.current !== H && (p && p(H)), I.current = H
        }, [H, p]);
        a = c("useFadeEffect")(H);
        var J = a[0],
            K = a[1],
            L = a[2];
        x = c("useCometPrerenderer")("tooltip", H);
        z = x[0].shouldPrerender;
        var M = z === void 0 ? !1 : z,
            N = x[1],
            O = x[2],
            P = i(function() {
                g && g()
            }, [g]),
            Q = function(a) {
                r || (s(!0, m), P()), !B && !t && N(a)
            },
            R = function() {
                s(!1, n), O()
            },
            S = function() {
                u(!1)
            },
            T = function() {
                u(!1)
            },
            U = function() {
                t || (u(!0), P())
            },
            V = function() {
                w(!1), P()
            };
        v = function(a) {
            return h.jsxs(c("BaseHovercardTriggerWrapper.react"), {
                display: e,
                onKeyDown: G,
                onMouseEnter: Q,
                onMouseLeave: R,
                onTouchCancel: S,
                onTouchEnd: T,
                onTouchStart: U,
                children: [h.jsx(c("FocusWithinHandler.react"), {
                    onFocusChange: y,
                    onFocusVisibleChange: A,
                    onFocusWithin: V,
                    children: b(C)
                }), (B || t || M || J) && h.jsx(c("CometHeroInteractionContextPassthrough.react"), {
                    clear: !0,
                    children: h.jsx(c("CometErrorBoundary.react"), {
                        children: h.jsx(c("CometPlaceholder.react"), {
                            fallback: null,
                            children: h.jsx(c("BaseContextualLayer.react"), babelHelpers["extends"]({
                                align: "middle",
                                contextRef: C,
                                hidden: !H && M,
                                imperativeRef: D,
                                ref: E,
                                xstyle: !H && J ? o.disablePointerEvents : void 0
                            }, q, {
                                children: h.jsx(c("HiddenSubtreeContextProvider.react"), {
                                    isHidden: !H && M,
                                    children: h.jsx("div", {
                                        className: c("stylex")(o.hovercard, K && o.hovercardVisible),
                                        ref: L,
                                        children: h.jsx(c("FocusInertRegion.react"), {
                                            focusQuery: d("focusScopeQueries").tabbableScopeQuery,
                                            children: f != null ? h.jsx(c("CometPlaceholder.react"), {
                                                fallback: f,
                                                children: a
                                            }) : a
                                        })
                                    })
                                })
                            }))
                        })
                    })
                })]
            })
        };
        return [v, F]
    }
    g["default"] = a
}), 98);
__d("CometHovercardTrigger.react", ["BaseHovercardTriggerWrapper.react", "CometHovercardSettingsContext", "CometRelay", "CometSuppressHovercards", "gkx", "react", "useBaseHovercardTrigger", "useCometRelayEntrypointContextualEnvironmentProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useRef,
        l = c("gkx")("4028"),
        m = {};

    function n(a) {
        var b = a.popoverEntryPoint,
            e = a.popoverOtherProps;
        e = e === void 0 ? m : e;
        var f = a.popoverProps;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["popoverEntryPoint", "popoverOtherProps", "popoverProps"]);
        var g = c("useCometRelayEntrypointContextualEnvironmentProvider")();
        g = d("CometRelay").useEntryPointLoader(g, b);
        b = g[0];
        var j = g[1];
        g = i(function() {
            j(f)
        }, [j, f]);
        a = c("useBaseHovercardTrigger")(babelHelpers["extends"]({}, a, {
            onLoadEntryPoint: g
        }));
        g = a[0];
        return g(h.jsx(h.Fragment, {
            children: b != null && h.jsx(d("CometRelay").EntryPointContainer, {
                entryPointReference: b,
                props: e
            })
        }))
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        var b = j(c("CometHovercardSettingsContext"));
        b = b.hovercardInteractionPreference;
        b = d("CometSuppressHovercards").useIsHovercardSuppressed() || l && b === 1;
        var e = k(null);
        return b ? h.jsx(c("BaseHovercardTriggerWrapper.react"), {
            display: a.display,
            children: a.children(e)
        }) : h.jsx(n, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometFocusGroupContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        FocusContainer: null,
        FocusItem: null
    });
    g["default"] = b
}), 98);
__d("CometHovercardGroupContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        groupID: void 0
    });
    c = b;
    g["default"] = c
}), 98);
__d("ActorHovercardContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useActorHovercardContext", ["ActorHovercardContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(c("ActorHovercardContext"));
        return (a = a) != null ? a : "DEFAULT"
    }
    g["default"] = a
}), 98);
__d("ActorHovercard.react", ["CometDangerouslySuppressInteractiveElementsContext", "CometEntryPointPopoverTrigger.react", "CometHovercardGroupContext", "CometHovercardQueryRenderer.entrypoint", "CometHovercardSettingsContext", "CometHovercardTrigger.react", "CometPopoverLoadingState.react", "CometPressable.react", "react", "useActorHovercardContext"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useRef,
        k = {
            displayBlock: {
                display: "x1lliihq"
            },
            displayInline: {
                display: "xt0psk2"
            },
            displayInlineBlock: {
                display: "x1rg5ohu"
            },
            fitContent: {
                height: "xg7h5cd"
            }
        };

    function a(a) {
        var b = a.actorID,
            d = a.align;
        d = d === void 0 ? "middle" : d;
        var e = a.children,
            f = a.display,
            g = a.position;
        g = g === void 0 ? "above" : g;
        var l = a.showHovercardOnClick;
        l = l === void 0 ? !1 : l;
        var m = babelHelpers.objectWithoutPropertiesLoose(a, ["actorID", "align", "children", "display", "position", "showHovercardOnClick"]);
        a = c("useActorHovercardContext")();
        var n = i(c("CometHovercardGroupContext"));
        n = n.groupID;
        var o = i(c("CometHovercardSettingsContext"));
        o = o.hovercardInteractionPreference;
        l = l || o === 3;
        o = "WWW_COMET_HOVERCARD";
        a === "CIVIC_POST" && (o = "WWW_COMET_CIVIC_PROFILE_HOVERCARD");
        var p = j(null);
        return l ? h.jsx(c("CometEntryPointPopoverTrigger.react"), {
            align: d,
            entryPointParams: {
                actionBarRenderLocation: o,
                context: a,
                entityID: b,
                groupID: n
            },
            fallback: h.jsx(c("CometPopoverLoadingState.react"), {}),
            otherProps: {},
            popoverEntryPoint: c("CometHovercardQueryRenderer.entrypoint"),
            position: g,
            children: function(a, b, d, g, i, j, l, n) {
                return h.jsx(c("CometDangerouslySuppressInteractiveElementsContext").Provider, {
                    value: !1,
                    children: h.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, m, {
                        "aria-expanded": n ? n : void 0,
                        onPress: b,
                        ref: a,
                        role: "button",
                        xstyle: [k.fitContent, f === "inline" ? k.displayInline : f === "inline-block" ? k.displayInlineBlock : k.displayBlock],
                        children: h.jsx(c("CometDangerouslySuppressInteractiveElementsContext").Provider, {
                            value: !0,
                            children: e(p)
                        })
                    }))
                })
            }
        }) : h.jsx(c("CometHovercardTrigger.react"), {
            align: d,
            display: f,
            popoverEntryPoint: c("CometHovercardQueryRenderer.entrypoint"),
            popoverProps: {
                actionBarRenderLocation: o,
                context: a,
                entityID: b,
                groupID: n
            },
            position: g,
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("PagesCometLinkContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        shouldHostInWatch: !1
    });
    g["default"] = b
}), 98);
__d("ProfileCometContextualProfileGating", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a;
        return (a = c("gkx")("1183591")) != null ? a : !1
    }
    g.canViewCometContextualProfile = a
}), 98);
__d("ProfileCometLinkContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        groupID: null
    });
    g["default"] = b
}), 98);
__d("RecoverableViolation.react", ["react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function a(a) {
        var b = a.errorMessage,
            d = a.errorObject,
            e = a.projectName,
            f = i(!1);
        h(function() {
            f.current || (c("recoverableViolation")(b, e, d), f.current = !0)
        });
        return null
    }
    g["default"] = a
}), 98);
__d("XCometContextualProfileControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/groups/{group_idorvanity}/user/{member_id}/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XCometStoriesControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/stories/{?bucket_id}/{?card_id}/", Object.freeze({
        view_single: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XCometVideoHomePlaylistControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/watch/{?idorvanity}/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("useActorStoryStatus", ["CometRelay", "useActorStoryStatus_actor.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = {
        status: "none"
    };

    function a(a) {
        var c, e, f;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useActorStoryStatus_actor.graphql"), a);
        var g;
        switch (a.__typename) {
            case "Page":
                g = a.pages_story_bucket_v2;
                break;
            case "User":
                a = (a = a.story_bucket) == null ? void 0 : a.nodes;
                g = a ? a[0] : null;
                break;
            default:
                return i
        }
        if (g == null) return i;
        a = g.id;
        c = (c = g.first_story_to_show) == null ? void 0 : c.id;
        if (a == null || c == null) return i;
        e = (e = g.first_story_to_show) == null ? void 0 : (e = e.story_card_seen_state) == null ? void 0 : e.is_seen_by_viewer;
        f = (f = g.should_show_close_friend_badge) != null ? f : !1;
        if (e === !1) return {
            firstBucketId: a,
            firstCardId: c,
            shouldShowCloseFriendsBadge: f,
            status: "unseen"
        };
        else if (e === !0) return {
            firstBucketId: a,
            firstCardId: c,
            shouldShowCloseFriendsBadge: f,
            status: "seen"
        };
        else return i
    }
    g["default"] = a
}), 98);
__d("CometProfilePhotoForActor.react", ["ActorHovercard.react", "CometProfilePhoto.react", "CometProfilePhotoForActor_actor.graphql", "CometRelay", "PagesCometLinkContext", "ProfileCometContextualProfileGating", "ProfileCometLinkContext", "RecoverableViolation.react", "WebPixelRatio", "XCometContextualProfileControllerRouteBuilder", "XCometStoriesControllerRouteBuilder", "XCometVideoHomePlaylistControllerRouteBuilder", "react", "useActorStoryStatus"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");
    e = d("react");
    var j = e.useContext,
        k = e.useMemo;

    function a(a) {
        var e = a.actor,
            f = a.addOn,
            g = a.enableStoryStatus,
            l = g === void 0 ? !0 : g;
        a.entrypoint;
        var m = a.linkProps;
        g = a.noHovercard;
        g = g === void 0 ? !1 : g;
        var n = a.noLink,
            o = n === void 0 ? !1 : n,
            p = a.onPress;
        n = a.showHovercardOnClick;
        n = n === void 0 ? !1 : n;
        var q = a.size,
            r = babelHelpers.objectWithoutPropertiesLoose(a, ["actor", "addOn", "enableStoryStatus", "entrypoint", "linkProps", "noHovercard", "noLink", "onPress", "showHovercardOnClick", "size"]);
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("CometProfilePhotoForActor_actor.graphql"), e);
        e = (e = a.profile_picture) != null ? e : {};
        var s = a.profile_video != null ? a.profile_video : void 0,
            t = e.height,
            u = e.scale,
            v = e.uri,
            w = e.width,
            x = a.availability;
        e = a.id;
        var y = a.name,
            z = j(c("ProfileCometLinkContext"));
        z = z.groupID;
        var A = j(c("PagesCometLinkContext"));
        A = A.shouldHostInWatch;
        var B = a.url,
            C, D = c("useActorStoryStatus")(a),
            E = !1;
        l && D.status !== "none" ? (B = c("XCometStoriesControllerRouteBuilder").buildURL({
            bucket_id: D.firstBucketId,
            card_id: D.firstCardId,
            view_single: !0
        }), E = D.shouldShowCloseFriendsBadge, C = {
            target: m == null ? void 0 : m.target,
            url: B
        }) : z != null && d("ProfileCometContextualProfileGating").canViewCometContextualProfile() && e != null && a.__typename !== "Group" ? (B = c("XCometContextualProfileControllerRouteBuilder").buildURL({
            group_idorvanity: z,
            member_id: e
        }), C = {
            target: m == null ? void 0 : m.target,
            url: B
        }) : A === !0 && (B = c("XCometVideoHomePlaylistControllerRouteBuilder").buildURL({
            idorvanity: e,
            tab: "home"
        }), C = {
            target: m == null ? void 0 : m.target,
            url: B
        });
        var F = k(function() {
            var a;
            return {
                addOn: (a = f) != null ? a : x === "ACTIVE" ? {
                    type: "availabilityBadge"
                } : void 0,
                "aria-label": (a = y) != null ? a : "",
                linkProps: m != null && m.url != null ? m : o ? void 0 : (a = C) != null ? a : {
                    target: m == null ? void 0 : m.target,
                    url: B
                },
                onPress: p,
                profileVideo: s,
                shouldShowCloseFriendsBadge: E,
                size: q,
                source: {
                    height: (a = t) != null ? a : q,
                    scale: (a = u) != null ? a : d("WebPixelRatio").get(),
                    uri: (a = v) != null ? a : "",
                    width: (a = w) != null ? a : q
                },
                storyStatus: l ? D.status : "none"
            }
        }, [f, x, y, m, o, C, B, p, s, q, t, u, E, v, w, D.status, l]);
        if (v == null || e == null || y == null || F.source.uri === "") {
            return i.jsx(c("RecoverableViolation.react"), {
                errorMessage: "Missing fields for CometProfilePhotoForActor, id: " + ((a = e) != null ? a : "null"),
                projectName: "comet_ui"
            })
        }
        return g ? i.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, r, F)) : i.jsx(c("ActorHovercard.react"), {
            actorID: e,
            "aria-hidden": r["aria-hidden"],
            showHovercardOnClick: n,
            children: function(a) {
                return i.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({
                    ref: a
                }, r, F))
            }
        })
    }
    g["default"] = a
}), 98);
__d("CometProgressSkittleIndeterminate.react", ["CometProgressRingIndeterminate.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            36: {
                height: "xc9qbxq",
                width: "x14qfxbe"
            },
            48: {
                height: "xsdox4t",
                width: "x1useyqa"
            },
            circle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            gray: {
                backgroundColor: "x1qhmfi1"
            },
            skittle: {
                alignItems: "x6s0dn4",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                display: "x3nfvp2",
                justifyContent: "xl56j7k",
                position: "x1n2onr6"
            }
        };

    function a(a) {
        a = a.size;
        a = a === void 0 ? 36 : a;
        return h.jsx("div", {
            className: c("stylex")(i.circle, i.skittle, i.gray, i[a]),
            children: h.jsx(c("CometProgressRingIndeterminate.react"), {
                color: "disabled",
                size: a === 48 ? 32 : 20
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("EmojiImageURL", ["invariant", "EmojiConfig", "EmojiStaticConfig"], (function(a, b, c, d, e, f, g) {
    function h(b, c) {
        var d = a.unescape(encodeURIComponent(b));
        c = c;
        for (var e = 0; e < d.length; e++) c = (c << 5) - c + b.charCodeAt(e), c &= 4294967295;
        return (c & 255).toString(16)
    }

    function i(a, c, d) {
        c in b("EmojiStaticConfig").supportedSizes || g(0, 772, c);
        c = b("EmojiConfig").pixelRatio + "/" + c + "/" + a + b("EmojiStaticConfig").fileExt;
        a = h(c, b("EmojiStaticConfig").checksumBase);
        return b("EmojiConfig").schemaAuth + "/" + d + a + "/" + c
    }
    e.exports = {
        getMessengerURL: function(a, c) {
            return i(a, c, b("EmojiStaticConfig").types.MESSENGER)
        },
        getEmoji3URL: function(a, c) {
            c === void 0 && (c = 16);
            return i(a, c, b("EmojiStaticConfig").types.EMOJI_3)
        },
        getFBEmojiURL: function(a, c) {
            c === void 0 && (c = 16);
            return i(a, c, b("EmojiStaticConfig").types.FBEMOJI)
        },
        getFBEmojiExtendedURL: function(a, c) {
            c === void 0 && (c = 16);
            return i(a, c, b("EmojiStaticConfig").types.FB_EMOJI_EXTENDED)
        },
        getCompositeURL: function(a, c) {
            c === void 0 && (c = 16);
            return i(a, c, b("EmojiStaticConfig").types.COMPOSITE)
        }
    }
}), null);
__d("EmojiRendererData", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {}
        a.isEmoji = function(a) {
            return a > 983041 || a < 35 ? !1 : a === 35 || a === 42 || a >= 48 && a <= 57 || a === 169 || a === 174 || a === 8205 || a === 8252 || a === 8265 || a === 8419 || a === 8482 || a === 8505 || a >= 8596 && a <= 8601 || a >= 8617 && a <= 8618 || a >= 8986 && a <= 8987 || a === 9e3 || a === 9167 || a >= 9193 && a <= 9203 || a >= 9208 && a <= 9210 || a === 9410 || a >= 9642 && a <= 9643 || a === 9654 || a === 9664 || a >= 9723 && a <= 9726 || a >= 9728 && a <= 9732 || a === 9742 || a === 9745 || a >= 9748 && a <= 9749 || a === 9752 || a === 9760 || a >= 9762 && a <= 9763 || a === 9766 || a === 9770 || a >= 9774 && a <= 9775 || a >= 9784 && a <= 9786 || a === 9792 || a === 9794 || a >= 9800 && a <= 9811 || a >= 9823 && a <= 9824 || a === 9827 || a >= 9829 && a <= 9830 || a === 9832 || a === 9851 || a >= 9854 && a <= 9855 || a >= 9874 && a <= 9879 || a === 9881 || a >= 9883 && a <= 9884 || a >= 9888 && a <= 9889 || a === 9895 || a >= 9898 && a <= 9899 || a >= 9904 && a <= 9905 || a >= 9917 && a <= 9918 || a >= 9924 && a <= 9925 || a === 9928 || a >= 9934 && a <= 9935 || a === 9937 || a >= 9939 && a <= 9940 || a >= 9961 && a <= 9962 || a >= 9968 && a <= 9973 || a >= 9975 && a <= 9976 || a === 9978 || a === 9981 || a === 9986 || a === 9989 || a >= 9992 && a <= 9993 || a === 9999 || a === 10002 || a === 10004 || a === 10006 || a === 10013 || a === 10017 || a === 10024 || a >= 10035 && a <= 10036 || a === 10052 || a === 10055 || a === 10060 || a === 10062 || a >= 10067 && a <= 10069 || a === 10071 || a >= 10083 && a <= 10084 || a >= 10133 && a <= 10135 || a === 10145 || a === 10160 || a === 10175 || a >= 10548 && a <= 10549 || a >= 11013 && a <= 11015 || a >= 11035 && a <= 11036 || a === 11088 || a === 11093 || a === 12336 || a === 12349 || a === 12951 || a === 12953 || a === 126980 || a === 127183 || a >= 127344 && a <= 127345 || a >= 127358 && a <= 127359 || a === 127374 || a >= 127377 && a <= 127386 || a >= 127462 && a <= 127487 || a >= 127489 && a <= 127490 || a === 127514 || a === 127535 || a >= 127538 && a <= 127546 || a >= 127568 && a <= 127569 || a >= 127744 && a <= 127777 || a >= 127780 && a <= 127876 || a >= 127878 && a <= 127891 || a >= 127894 && a <= 127895 || a >= 127897 && a <= 127899 || a >= 127902 && a <= 127937 || a >= 127941 && a <= 127942 || a >= 127944 && a <= 127945 || a >= 127949 && a <= 127984 || a >= 127987 && a <= 127989 || a >= 127991 && a <= 127994 || a >= 128e3 && a <= 128065 || a >= 128068 && a <= 128069 || a >= 128081 && a <= 128101 || a >= 128121 && a <= 128123 || a >= 128125 && a <= 128128 || a === 128132 || a >= 128136 && a <= 128142 || a === 128144 || a >= 128146 && a <= 128169 || a >= 128171 && a <= 128253 || a >= 128255 && a <= 128317 || a >= 128329 && a <= 128334 || a >= 128336 && a <= 128359 || a >= 128367 && a <= 128368 || a === 128371 || a >= 128374 && a <= 128377 || a === 128391 || a >= 128394 && a <= 128397 || a >= 128420 && a <= 128421 || a === 128424 || a >= 128433 && a <= 128434 || a === 128444 || a >= 128450 && a <= 128452 || a >= 128465 && a <= 128467 || a >= 128476 && a <= 128478 || a === 128481 || a === 128483 || a === 128488 || a === 128495 || a === 128499 || a >= 128506 && a <= 128580 || a >= 128584 && a <= 128586 || a >= 128640 && a <= 128674 || a >= 128676 && a <= 128691 || a >= 128695 && a <= 128703 || a >= 128705 && a <= 128709 || a === 128715 || a >= 128717 && a <= 128722 || a >= 128725 && a <= 128727 || a >= 128733 && a <= 128741 || a === 128745 || a >= 128747 && a <= 128748 || a === 128752 || a >= 128755 && a <= 128764 || a >= 128992 && a <= 129003 || a === 129008 || a >= 129293 && a <= 129294 || a >= 129296 && a <= 129303 || a >= 129312 && a <= 129317 || a >= 129319 && a <= 129327 || a === 129338 || a >= 129343 && a <= 129349 || a >= 129351 && a <= 129398 || a >= 129400 && a <= 129460 || a === 129463 || a === 129466 || a >= 129468 && a <= 129484 || a === 129488 || a >= 129502 && a <= 129535 || a >= 129648 && a <= 129652 || a >= 129656 && a <= 129660 || a >= 129664 && a <= 129670 || a >= 129680 && a <= 129708 || a >= 129712 && a <= 129722 || a >= 129728 && a <= 129730 || a >= 129744 && a <= 129753 || a >= 129760 && a <= 129767 || a >= 917536 && a <= 917631 || a >= 983040 && a <= 983041
        };
        a.isEmojiModifier = function(a) {
            return a > 127999 || a < 127995 ? !1 : a >= 127995 && a <= 127999
        };
        a.isEmojiModifierBase = function(a) {
            return a > 129782 || a < 9757 ? !1 : a === 9757 || a === 9977 || a >= 9994 && a <= 9997 || a === 127877 || a >= 127938 && a <= 127940 || a === 127943 || a >= 127946 && a <= 127948 || a >= 128066 && a <= 128067 || a >= 128070 && a <= 128080 || a >= 128102 && a <= 128120 || a === 128124 || a >= 128129 && a <= 128131 || a >= 128133 && a <= 128135 || a === 128143 || a === 128145 || a === 128170 || a >= 128372 && a <= 128373 || a === 128378 || a === 128400 || a >= 128405 && a <= 128406 || a >= 128581 && a <= 128583 || a >= 128587 && a <= 128591 || a === 128675 || a >= 128692 && a <= 128694 || a === 128704 || a === 128716 || a === 129292 || a === 129295 || a >= 129304 && a <= 129311 || a === 129318 || a >= 129328 && a <= 129337 || a >= 129340 && a <= 129342 || a === 129399 || a >= 129461 && a <= 129462 || a >= 129464 && a <= 129465 || a === 129467 || a >= 129485 && a <= 129487 || a >= 129489 && a <= 129501 || a >= 129731 && a <= 129733 || a >= 129776 && a <= 129782
        };
        a.isEmojiVariationSelector = function(a) {
            return a === 65039
        };
        a.isNonSpacingCombiningMark = function(a) {
            return a > 8419 || a < 8416 ? !1 : a === 8416 || a === 8419
        };
        a.isRegionalIndicator = function(a) {
            return a > 127487 || a < 127462 ? !1 : a >= 127462 && a <= 127487
        };
        a.isTagSpec = function(a) {
            return a > 917630 || a < 917536 ? !1 : a >= 917536 && a <= 917568 || a >= 917595 && a <= 917630
        };
        a.isTagTerm = function(a) {
            return a === 917631
        };
        a.isText = function(a) {
            return a > 8419 || a < 35 ? !1 : a === 35 || a === 42 || a >= 48 && a <= 57 || a === 8419
        };
        a.isTextVariationSelector = function(a) {
            return a === 65038
        };
        a.isDefaultTextPresentation = function(a) {
            return a > 917631 || a < 35 ? !1 : a === 35 || a === 42 || a >= 48 && a <= 57 || a === 169 || a === 174 || a === 8205 || a === 8252 || a === 8265 || a === 8419 || a === 8482 || a === 8505 || a >= 8596 && a <= 8597 || a >= 8617 && a <= 8618 || a === 9e3 || a === 9167 || a >= 9197 && a <= 9199 || a >= 9201 && a <= 9202 || a >= 9208 && a <= 9210 || a === 9410 || a === 9654 || a === 9664 || a >= 9730 && a <= 9732 || a === 9745 || a === 9752 || a === 9760 || a >= 9762 && a <= 9763 || a === 9766 || a === 9770 || a >= 9774 && a <= 9775 || a >= 9784 && a <= 9785 || a === 9792 || a === 9794 || a === 9823 || a === 9851 || a === 9854 || a === 9874 || a >= 9876 && a <= 9879 || a === 9881 || a >= 9883 && a <= 9884 || a === 9895 || a >= 9904 && a <= 9905 || a === 9928 || a === 9935 || a === 9937 || a === 9939 || a === 9961 || a >= 9968 && a <= 9969 || a === 9972 || a >= 9975 && a <= 9977 || a === 9997 || a === 9999 || a === 10002 || a === 10004 || a === 10013 || a === 10017 || a === 10052 || a === 10055 || a === 10083 || a === 12336 || a >= 127344 && a <= 127345 || a >= 127358 && a <= 127359 || a === 127777 || a >= 127780 && a <= 127788 || a === 127798 || a === 127869 || a >= 127894 && a <= 127895 || a >= 127897 && a <= 127899 || a >= 127902 && a <= 127903 || a >= 127947 && a <= 127950 || a >= 127956 && a <= 127967 || a === 127987 || a === 127989 || a === 127991 || a === 128063 || a === 128065 || a === 128253 || a >= 128329 && a <= 128330 || a >= 128367 && a <= 128368 || a >= 128371 && a <= 128377 || a === 128391 || a >= 128394 && a <= 128397 || a === 128400 || a === 128421 || a === 128424 || a >= 128433 && a <= 128434 || a === 128444 || a >= 128450 && a <= 128452 || a >= 128465 && a <= 128467 || a >= 128476 && a <= 128478 || a === 128481 || a === 128483 || a === 128488 || a === 128495 || a === 128499 || a === 128506 || a === 128715 || a >= 128717 && a <= 128719 || a >= 128736 && a <= 128741 || a === 128745 || a === 128752 || a === 128755 || a >= 917536 && a <= 917631
        };
        a.isSymbol = function(a) {
            return a > 8482 || a < 169 ? !1 : a === 169 || a === 174 || a === 8482
        };
        a.isZWJ = function(a) {
            return a === 8205
        };
        return a
    }();
    e.exports = a
}), null);
__d("UnicodeUtils", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = 55296,
        j = 56319,
        k = 56320,
        l = 57343,
        m = /[\uD800-\uDFFF]/;

    function n(a) {
        return i <= a && a <= l
    }

    function a(a, b) {
        0 <= b && b < a.length || h(0, 1346, b, a.length);
        if (b + 1 === a.length) return !1;
        var c = a.charCodeAt(b);
        a = a.charCodeAt(b + 1);
        return i <= c && c <= j && k <= a && a <= l
    }

    function o(a) {
        return m.test(a)
    }

    function p(a, b) {
        return 1 + n(a.charCodeAt(b))
    }

    function b(a) {
        if (!o(a)) return a.length;
        var b = 0;
        for (var c = 0; c < a.length; c += p(a, c)) b++;
        return b
    }

    function c(a, b) {
        return r(a, b, b + 1)
    }

    function q(a, b, c) {
        var d = b || 0;
        c = c === void 0 ? Infinity : c || 0;
        if (!o(a)) return a.substr(d, c);
        var e = a.length;
        if (e <= 0 || d > e || c <= 0) return "";
        var f = 0;
        if (d > 0) {
            for (; d > 0 && f < e; d--) f += p(a, f);
            if (f >= e) return ""
        } else if (b < 0) {
            for (f = e; d < 0 && 0 < f; d++) f -= p(a, f - 1);
            f < 0 && (f = 0)
        }
        b = e;
        if (c < e)
            for (b = f; c > 0 && b < e; c--) b += p(a, b);
        return a.substring(f, b)
    }

    function r(a, b, c) {
        b = b || 0;
        c = c === void 0 ? Infinity : c || 0;
        b < 0 && (b = 0);
        c < 0 && (c = 0);
        var d = Math.abs(c - b);
        b = b < c ? b : c;
        return q(a, b, d)
    }

    function d(a) {
        var b = [];
        for (var c = 0; c < a.length; c += p(a, c)) b.push(a.codePointAt(c));
        return b
    }
    g.isCodeUnitInSurrogateRange = n;
    g.isSurrogatePair = a;
    g.hasSurrogateUnit = o;
    g.getUTF16Length = p;
    g.strlen = b;
    g.charAt = c;
    g.substr = q;
    g.substring = r;
    g.getCodePoints = d
}), 98);
__d("EmojiRenderer", ["EmojiRendererData", "UnicodeUtils"], (function(a, b, c, d, e, f, g) {
    var h = 0,
        i = 1,
        j = 2,
        k = 3,
        l = 4,
        m = 5,
        n = 6,
        o = 7,
        p = 8,
        q = 9,
        r = 10,
        s = 11;

    function t(a) {
        var b = a[0];
        if (b === void 0) return !1;
        var d = a.length,
            e = a[d - 1];
        if (e) {
            e = e.charCodeAt(0);
            if (c("EmojiRendererData").isTagSpec(e)) return !1
        }
        b = b.charCodeAt(0);
        if (c("EmojiRendererData").isSymbol(b) && d < 2) return !1;
        if (c("EmojiRendererData").isText(b))
            if (d === 1) return !1;
            else if (a.length == 2) return c("EmojiRendererData").isNonSpacingCombiningMark(a[1].charCodeAt(0));
        else {
            e = 1;
            c("EmojiRendererData").isEmojiVariationSelector(a[e].charCodeAt(0)) && e++;
            while (e < a.length) {
                if (!c("EmojiRendererData").isNonSpacingCombiningMark(a[e].charCodeAt(0))) return !1;
                e++
            }
            return !0
        }
        return !0
    }

    function u(a, b) {
        var e = null,
            f = [],
            g = p,
            u = 0,
            v = a.length;
        while (u < v) {
            var w = a.codePointAt(u),
                x = d("UnicodeUtils").getUTF16Length(a, u),
                y = a.substr(u, x);
            switch (g) {
                case q:
                    c("EmojiRendererData").isRegionalIndicator(w) ? g = k : g = p;
                    break;
                case l:
                    if (c("EmojiRendererData").isEmojiModifier(w)) {
                        g = m;
                        break
                    }
                case h:
                    c("EmojiRendererData").isZWJ(w) ? g = o : c("EmojiRendererData").isEmojiVariationSelector(w) ? g = j : c("EmojiRendererData").isTextVariationSelector(w) ? g = s : c("EmojiRendererData").isNonSpacingCombiningMark(w) ? g = i : c("EmojiRendererData").isTagSpec(w) ? g = n : g = p;
                    break;
                case i:
                case j:
                    if (c("EmojiRendererData").isNonSpacingCombiningMark(w)) break;
                case k:
                case m:
                    c("EmojiRendererData").isZWJ(w) ? g = o : c("EmojiRendererData").isTagSpec(w) ? g = n : g = p;
                    break;
                case n:
                    c("EmojiRendererData").isTagSpec(w) || c("EmojiRendererData").isTagTerm(w) ? g = n : g = p;
                    break;
                case o:
                    c("EmojiRendererData").isRegionalIndicator(w) ? g = q : c("EmojiRendererData").isEmojiModifierBase(w) ? g = l : c("EmojiRendererData").isEmoji(w) ? g = h : g = p;
                    break;
                case r:
                    c("EmojiRendererData").isNonSpacingCombiningMark(w) ? g = i : c("EmojiRendererData").isEmojiVariationSelector(w) ? g = j : g = p;
                    break;
                default:
                    g = p;
                    break
            }
            if (g === p) {
                c("EmojiRendererData").isRegionalIndicator(w) ? g = q : c("EmojiRendererData").isEmojiModifierBase(w) ? g = l : c("EmojiRendererData").isText(w) ? g = r : c("EmojiRendererData").isEmoji(w) && (g = h);
                if (g !== p) {
                    e !== null && t(e.emoji) && f.push(e);
                    if (b !== null && b === f.length) {
                        e = null;
                        break
                    }
                    e = {
                        emoji: [y],
                        length: x,
                        offset: u
                    }
                }
            } else e !== null && (e.emoji.push(y), e.length += x);
            u += x
        }
        e !== null && t(e.emoji) && f.push(e);
        return f
    }

    function a(a, b, c) {
        c = u(a);
        var d = [],
            e = 0;
        c.forEach(function(c) {
            var f = c.offset;
            f > e && d.push(a.substr(e, f - e));
            var g = b(c.emoji);
            g != null && d.push(g);
            e = f + c.length
        });
        d.push(a.substr(e, a.length - e));
        return d
    }

    function b(a) {
        return u(a, 1).length === 1
    }

    function e(a) {
        return u(a).length
    }
    g.parse = u;
    g.render = a;
    g.containsEmoji = b;
    g.countEmoji = e
}), 98);
__d("SupportedCommonEmoji", [], (function(a, b, c, d, e, f) {
    a = {
        "1f004": 1,
        "1f0cf": 1,
        "1f170": 1,
        "1f171": 1,
        "1f17e": 1,
        "1f17f": 1,
        "1f18e": 1,
        "1f191": 1,
        "1f192": 1,
        "1f193": 1,
        "1f194": 1,
        "1f195": 1,
        "1f196": 1,
        "1f197": 1,
        "1f198": 1,
        "1f199": 1,
        "1f19a": 1,
        "1f1e6": 1,
        "1f1e6_1f1e8": 1,
        "1f1e6_1f1e9": 1,
        "1f1e6_1f1ea": 1,
        "1f1e6_1f1eb": 1,
        "1f1e6_1f1ec": 1,
        "1f1e6_1f1ee": 1,
        "1f1e6_1f1f1": 1,
        "1f1e6_1f1f2": 1,
        "1f1e6_1f1f4": 1,
        "1f1e6_1f1f6": 1,
        "1f1e6_1f1f7": 1,
        "1f1e6_1f1f8": 1,
        "1f1e6_1f1f9": 1,
        "1f1e6_1f1fa": 1,
        "1f1e6_1f1fc": 1,
        "1f1e6_1f1fd": 1,
        "1f1e6_1f1ff": 1,
        "1f1e7": 1,
        "1f1e7_1f1e6": 1,
        "1f1e7_1f1e7": 1,
        "1f1e7_1f1e9": 1,
        "1f1e7_1f1ea": 1,
        "1f1e7_1f1eb": 1,
        "1f1e7_1f1ec": 1,
        "1f1e7_1f1ed": 1,
        "1f1e7_1f1ee": 1,
        "1f1e7_1f1ef": 1,
        "1f1e7_1f1f1": 1,
        "1f1e7_1f1f2": 1,
        "1f1e7_1f1f3": 1,
        "1f1e7_1f1f4": 1,
        "1f1e7_1f1f6": 1,
        "1f1e7_1f1f7": 1,
        "1f1e7_1f1f8": 1,
        "1f1e7_1f1f9": 1,
        "1f1e7_1f1fb": 1,
        "1f1e7_1f1fc": 1,
        "1f1e7_1f1fe": 1,
        "1f1e7_1f1ff": 1,
        "1f1e8": 1,
        "1f1e8_1f1e6": 1,
        "1f1e8_1f1e8": 1,
        "1f1e8_1f1e9": 1,
        "1f1e8_1f1eb": 1,
        "1f1e8_1f1ec": 1,
        "1f1e8_1f1ed": 1,
        "1f1e8_1f1ee": 1,
        "1f1e8_1f1f0": 1,
        "1f1e8_1f1f1": 1,
        "1f1e8_1f1f2": 1,
        "1f1e8_1f1f3": 1,
        "1f1e8_1f1f4": 1,
        "1f1e8_1f1f5": 1,
        "1f1e8_1f1f7": 1,
        "1f1e8_1f1fa": 1,
        "1f1e8_1f1fb": 1,
        "1f1e8_1f1fc": 1,
        "1f1e8_1f1fd": 1,
        "1f1e8_1f1fe": 1,
        "1f1e8_1f1ff": 1,
        "1f1e9": 1,
        "1f1e9_1f1ea": 1,
        "1f1e9_1f1ec": 1,
        "1f1e9_1f1ef": 1,
        "1f1e9_1f1f0": 1,
        "1f1e9_1f1f2": 1,
        "1f1e9_1f1f4": 1,
        "1f1e9_1f1ff": 1,
        "1f1ea": 1,
        "1f1ea_1f1e6": 1,
        "1f1ea_1f1e8": 1,
        "1f1ea_1f1ea": 1,
        "1f1ea_1f1ec": 1,
        "1f1ea_1f1ed": 1,
        "1f1ea_1f1f7": 1,
        "1f1ea_1f1f8": 1,
        "1f1ea_1f1f9": 1,
        "1f1ea_1f1fa": 1,
        "1f1eb": 1,
        "1f1eb_1f1ee": 1,
        "1f1eb_1f1ef": 1,
        "1f1eb_1f1f0": 1,
        "1f1eb_1f1f2": 1,
        "1f1eb_1f1f4": 1,
        "1f1eb_1f1f7": 1,
        "1f1ec": 1,
        "1f1ec_1f1e6": 1,
        "1f1ec_1f1e7": 1,
        "1f1ec_1f1e9": 1,
        "1f1ec_1f1ea": 1,
        "1f1ec_1f1eb": 1,
        "1f1ec_1f1ec": 1,
        "1f1ec_1f1ed": 1,
        "1f1ec_1f1ee": 1,
        "1f1ec_1f1f1": 1,
        "1f1ec_1f1f2": 1,
        "1f1ec_1f1f3": 1,
        "1f1ec_1f1f5": 1,
        "1f1ec_1f1f6": 1,
        "1f1ec_1f1f7": 1,
        "1f1ec_1f1f8": 1,
        "1f1ec_1f1f9": 1,
        "1f1ec_1f1fa": 1,
        "1f1ec_1f1fc": 1,
        "1f1ec_1f1fe": 1,
        "1f1ed": 1,
        "1f1ed_1f1f0": 1,
        "1f1ed_1f1f2": 1,
        "1f1ed_1f1f3": 1,
        "1f1ed_1f1f7": 1,
        "1f1ed_1f1f9": 1,
        "1f1ed_1f1fa": 1,
        "1f1ee": 1,
        "1f1ee_1f1e8": 1,
        "1f1ee_1f1e9": 1,
        "1f1ee_1f1ea": 1,
        "1f1ee_1f1f1": 1,
        "1f1ee_1f1f2": 1,
        "1f1ee_1f1f3": 1,
        "1f1ee_1f1f4": 1,
        "1f1ee_1f1f6": 1,
        "1f1ee_1f1f7": 1,
        "1f1ee_1f1f8": 1,
        "1f1ee_1f1f9": 1,
        "1f1ef": 1,
        "1f1ef_1f1ea": 1,
        "1f1ef_1f1f2": 1,
        "1f1ef_1f1f4": 1,
        "1f1ef_1f1f5": 1,
        "1f1f0": 1,
        "1f1f0_1f1ea": 1,
        "1f1f0_1f1ec": 1,
        "1f1f0_1f1ed": 1,
        "1f1f0_1f1ee": 1,
        "1f1f0_1f1f2": 1,
        "1f1f0_1f1f3": 1,
        "1f1f0_1f1f5": 1,
        "1f1f0_1f1f7": 1,
        "1f1f0_1f1fc": 1,
        "1f1f0_1f1fe": 1,
        "1f1f0_1f1ff": 1,
        "1f1f1": 1,
        "1f1f1_1f1e6": 1,
        "1f1f1_1f1e7": 1,
        "1f1f1_1f1e8": 1,
        "1f1f1_1f1ee": 1,
        "1f1f1_1f1f0": 1,
        "1f1f1_1f1f7": 1,
        "1f1f1_1f1f8": 1,
        "1f1f1_1f1f9": 1,
        "1f1f1_1f1fa": 1,
        "1f1f1_1f1fb": 1,
        "1f1f1_1f1fe": 1,
        "1f1f2": 1,
        "1f1f2_1f1e6": 1,
        "1f1f2_1f1e8": 1,
        "1f1f2_1f1e9": 1,
        "1f1f2_1f1ea": 1,
        "1f1f2_1f1eb": 1,
        "1f1f2_1f1ec": 1,
        "1f1f2_1f1ed": 1,
        "1f1f2_1f1f0": 1,
        "1f1f2_1f1f1": 1,
        "1f1f2_1f1f2": 1,
        "1f1f2_1f1f3": 1,
        "1f1f2_1f1f4": 1,
        "1f1f2_1f1f5": 1,
        "1f1f2_1f1f6": 1,
        "1f1f2_1f1f7": 1,
        "1f1f2_1f1f8": 1,
        "1f1f2_1f1f9": 1,
        "1f1f2_1f1fa": 1,
        "1f1f2_1f1fb": 1,
        "1f1f2_1f1fc": 1,
        "1f1f2_1f1fd": 1,
        "1f1f2_1f1fe": 1,
        "1f1f2_1f1ff": 1,
        "1f1f3": 1,
        "1f1f3_1f1e6": 1,
        "1f1f3_1f1e8": 1,
        "1f1f3_1f1ea": 1,
        "1f1f3_1f1eb": 1,
        "1f1f3_1f1ec": 1,
        "1f1f3_1f1ee": 1,
        "1f1f3_1f1f1": 1,
        "1f1f3_1f1f4": 1,
        "1f1f3_1f1f5": 1,
        "1f1f3_1f1f7": 1,
        "1f1f3_1f1fa": 1,
        "1f1f3_1f1ff": 1,
        "1f1f4": 1,
        "1f1f4_1f1f2": 1,
        "1f1f5": 1,
        "1f1f5_1f1e6": 1,
        "1f1f5_1f1ea": 1,
        "1f1f5_1f1eb": 1,
        "1f1f5_1f1ec": 1,
        "1f1f5_1f1ed": 1,
        "1f1f5_1f1f0": 1,
        "1f1f5_1f1f1": 1,
        "1f1f5_1f1f2": 1,
        "1f1f5_1f1f3": 1,
        "1f1f5_1f1f7": 1,
        "1f1f5_1f1f8": 1,
        "1f1f5_1f1f9": 1,
        "1f1f5_1f1fc": 1,
        "1f1f5_1f1fe": 1,
        "1f1f6": 1,
        "1f1f6_1f1e6": 1,
        "1f1f7": 1,
        "1f1f7_1f1ea": 1,
        "1f1f7_1f1f4": 1,
        "1f1f7_1f1f8": 1,
        "1f1f7_1f1fa": 1,
        "1f1f7_1f1fc": 1,
        "1f1f8": 1,
        "1f1f8_1f1e6": 1,
        "1f1f8_1f1e7": 1,
        "1f1f8_1f1e8": 1,
        "1f1f8_1f1e9": 1,
        "1f1f8_1f1ea": 1,
        "1f1f8_1f1ec": 1,
        "1f1f8_1f1ed": 1,
        "1f1f8_1f1ee": 1,
        "1f1f8_1f1ef": 1,
        "1f1f8_1f1f0": 1,
        "1f1f8_1f1f1": 1,
        "1f1f8_1f1f2": 1,
        "1f1f8_1f1f3": 1,
        "1f1f8_1f1f4": 1,
        "1f1f8_1f1f7": 1,
        "1f1f8_1f1f8": 1,
        "1f1f8_1f1f9": 1,
        "1f1f8_1f1fb": 1,
        "1f1f8_1f1fd": 1,
        "1f1f8_1f1fe": 1,
        "1f1f8_1f1ff": 1,
        "1f1f9": 1,
        "1f1f9_1f1e6": 1,
        "1f1f9_1f1e8": 1,
        "1f1f9_1f1e9": 1,
        "1f1f9_1f1eb": 1,
        "1f1f9_1f1ec": 1,
        "1f1f9_1f1ed": 1,
        "1f1f9_1f1ef": 1,
        "1f1f9_1f1f0": 1,
        "1f1f9_1f1f1": 1,
        "1f1f9_1f1f2": 1,
        "1f1f9_1f1f3": 1,
        "1f1f9_1f1f4": 1,
        "1f1f9_1f1f7": 1,
        "1f1f9_1f1f9": 1,
        "1f1f9_1f1fb": 1,
        "1f1f9_1f1fc": 1,
        "1f1f9_1f1ff": 1,
        "1f1fa": 1,
        "1f1fa_1f1e6": 1,
        "1f1fa_1f1ec": 1,
        "1f1fa_1f1f2": 1,
        "1f1fa_1f1f3": 1,
        "1f1fa_1f1f8": 1,
        "1f1fa_1f1fe": 1,
        "1f1fa_1f1ff": 1,
        "1f1fb": 1,
        "1f1fb_1f1e6": 1,
        "1f1fb_1f1e8": 1,
        "1f1fb_1f1ea": 1,
        "1f1fb_1f1ec": 1,
        "1f1fb_1f1ee": 1,
        "1f1fb_1f1f3": 1,
        "1f1fb_1f1fa": 1,
        "1f1fc": 1,
        "1f1fc_1f1eb": 1,
        "1f1fc_1f1f8": 1,
        "1f1fd": 1,
        "1f1fd_1f1f0": 1,
        "1f1fe": 1,
        "1f1fe_1f1ea": 1,
        "1f1fe_1f1f9": 1,
        "1f1ff": 1,
        "1f1ff_1f1e6": 1,
        "1f1ff_1f1f2": 1,
        "1f1ff_1f1fc": 1,
        "1f201": 1,
        "1f202": 1,
        "1f21a": 1,
        "1f22f": 1,
        "1f232": 1,
        "1f233": 1,
        "1f234": 1,
        "1f235": 1,
        "1f236": 1,
        "1f237": 1,
        "1f238": 1,
        "1f239": 1,
        "1f23a": 1,
        "1f250": 1,
        "1f251": 1,
        "1f300": 1,
        "1f301": 1,
        "1f302": 1,
        "1f303": 1,
        "1f304": 1,
        "1f305": 1,
        "1f306": 1,
        "1f307": 1,
        "1f308": 1,
        "1f309": 1,
        "1f30a": 1,
        "1f30b": 1,
        "1f30c": 1,
        "1f30d": 1,
        "1f30e": 1,
        "1f30f": 1,
        "1f310": 1,
        "1f311": 1,
        "1f312": 1,
        "1f313": 1,
        "1f314": 1,
        "1f315": 1,
        "1f316": 1,
        "1f317": 1,
        "1f318": 1,
        "1f319": 1,
        "1f31a": 1,
        "1f31b": 1,
        "1f31c": 1,
        "1f31d": 1,
        "1f31e": 1,
        "1f31f": 1,
        "1f320": 1,
        "1f321": 1,
        "1f324": 1,
        "1f325": 1,
        "1f326": 1,
        "1f327": 1,
        "1f328": 1,
        "1f329": 1,
        "1f32a": 1,
        "1f32b": 1,
        "1f32c": 1,
        "1f32d": 1,
        "1f32e": 1,
        "1f32f": 1,
        "1f330": 1,
        "1f331": 1,
        "1f332": 1,
        "1f333": 1,
        "1f334": 1,
        "1f335": 1,
        "1f336": 1,
        "1f337": 1,
        "1f338": 1,
        "1f339": 1,
        "1f33a": 1,
        "1f33b": 1,
        "1f33c": 1,
        "1f33d": 1,
        "1f33e": 1,
        "1f33f": 1,
        "1f340": 1,
        "1f341": 1,
        "1f342": 1,
        "1f343": 1,
        "1f344": 1,
        "1f345": 1,
        "1f346": 1,
        "1f347": 1,
        "1f348": 1,
        "1f349": 1,
        "1f34a": 1,
        "1f34b": 1,
        "1f34c": 1,
        "1f34d": 1,
        "1f34e": 1,
        "1f34f": 1,
        "1f350": 1,
        "1f351": 1,
        "1f352": 1,
        "1f353": 1,
        "1f354": 1,
        "1f355": 1,
        "1f356": 1,
        "1f357": 1,
        "1f358": 1,
        "1f359": 1,
        "1f35a": 1,
        "1f35b": 1,
        "1f35c": 1,
        "1f35d": 1,
        "1f35e": 1,
        "1f35f": 1,
        "1f360": 1,
        "1f361": 1,
        "1f362": 1,
        "1f363": 1,
        "1f364": 1,
        "1f365": 1,
        "1f366": 1,
        "1f367": 1,
        "1f368": 1,
        "1f369": 1,
        "1f36a": 1,
        "1f36b": 1,
        "1f36c": 1,
        "1f36d": 1,
        "1f36e": 1,
        "1f36f": 1,
        "1f370": 1,
        "1f371": 1,
        "1f372": 1,
        "1f373": 1,
        "1f374": 1,
        "1f375": 1,
        "1f376": 1,
        "1f377": 1,
        "1f378": 1,
        "1f379": 1,
        "1f37a": 1,
        "1f37b": 1,
        "1f37c": 1,
        "1f37d": 1,
        "1f37e": 1,
        "1f37f": 1,
        "1f380": 1,
        "1f381": 1,
        "1f382": 1,
        "1f383": 1,
        "1f384": 1,
        "1f385": 1,
        "1f385_1f3fb": 1,
        "1f385_1f3fc": 1,
        "1f385_1f3fd": 1,
        "1f385_1f3fe": 1,
        "1f385_1f3ff": 1,
        "1f386": 1,
        "1f387": 1,
        "1f388": 1,
        "1f389": 1,
        "1f38a": 1,
        "1f38b": 1,
        "1f38c": 1,
        "1f38d": 1,
        "1f38e": 1,
        "1f38f": 1,
        "1f390": 1,
        "1f391": 1,
        "1f392": 1,
        "1f393": 1,
        "1f396": 1,
        "1f397": 1,
        "1f399": 1,
        "1f39a": 1,
        "1f39b": 1,
        "1f39e": 1,
        "1f39f": 1,
        "1f3a0": 1,
        "1f3a1": 1,
        "1f3a2": 1,
        "1f3a3": 1,
        "1f3a4": 1,
        "1f3a5": 1,
        "1f3a6": 1,
        "1f3a7": 1,
        "1f3a8": 1,
        "1f3a9": 1,
        "1f3aa": 1,
        "1f3ab": 1,
        "1f3ac": 1,
        "1f3ad": 1,
        "1f3ae": 1,
        "1f3af": 1,
        "1f3b0": 1,
        "1f3b1": 1,
        "1f3b2": 1,
        "1f3b3": 1,
        "1f3b4": 1,
        "1f3b5": 1,
        "1f3b6": 1,
        "1f3b7": 1,
        "1f3b8": 1,
        "1f3b9": 1,
        "1f3ba": 1,
        "1f3bb": 1,
        "1f3bc": 1,
        "1f3bd": 1,
        "1f3be": 1,
        "1f3bf": 1,
        "1f3c0": 1,
        "1f3c1": 1,
        "1f3c2": 1,
        "1f3c2_1f3fb": 1,
        "1f3c2_1f3fc": 1,
        "1f3c2_1f3fd": 1,
        "1f3c2_1f3fe": 1,
        "1f3c2_1f3ff": 1,
        "1f3c3_1f3fb_200d_2640": 1,
        "1f3c3_1f3fb_200d_2642": 1,
        "1f3c3_1f3fc_200d_2640": 1,
        "1f3c3_1f3fc_200d_2642": 1,
        "1f3c3_1f3fd_200d_2640": 1,
        "1f3c3_1f3fd_200d_2642": 1,
        "1f3c3_1f3fe_200d_2640": 1,
        "1f3c3_1f3fe_200d_2642": 1,
        "1f3c3_1f3ff_200d_2640": 1,
        "1f3c3_1f3ff_200d_2642": 1,
        "1f3c3_200d_2640": 1,
        "1f3c3_200d_2642": 1,
        "1f3c4_1f3fb_200d_2640": 1,
        "1f3c4_1f3fb_200d_2642": 1,
        "1f3c4_1f3fc_200d_2640": 1,
        "1f3c4_1f3fc_200d_2642": 1,
        "1f3c4_1f3fd_200d_2640": 1,
        "1f3c4_1f3fd_200d_2642": 1,
        "1f3c4_1f3fe_200d_2640": 1,
        "1f3c4_1f3fe_200d_2642": 1,
        "1f3c4_1f3ff_200d_2640": 1,
        "1f3c4_1f3ff_200d_2642": 1,
        "1f3c4_200d_2640": 1,
        "1f3c4_200d_2642": 1,
        "1f3c5": 1,
        "1f3c6": 1,
        "1f3c7": 1,
        "1f3c7_1f3fb": 1,
        "1f3c7_1f3fc": 1,
        "1f3c7_1f3fd": 1,
        "1f3c7_1f3fe": 1,
        "1f3c7_1f3ff": 1,
        "1f3c8": 1,
        "1f3c9": 1,
        "1f3ca_1f3fb_200d_2640": 1,
        "1f3ca_1f3fb_200d_2642": 1,
        "1f3ca_1f3fc_200d_2640": 1,
        "1f3ca_1f3fc_200d_2642": 1,
        "1f3ca_1f3fd_200d_2640": 1,
        "1f3ca_1f3fd_200d_2642": 1,
        "1f3ca_1f3fe_200d_2640": 1,
        "1f3ca_1f3fe_200d_2642": 1,
        "1f3ca_1f3ff_200d_2640": 1,
        "1f3ca_1f3ff_200d_2642": 1,
        "1f3ca_200d_2640": 1,
        "1f3ca_200d_2642": 1,
        "1f3cb_1f3fb_200d_2640": 1,
        "1f3cb_1f3fb_200d_2642": 1,
        "1f3cb_1f3fc_200d_2640": 1,
        "1f3cb_1f3fc_200d_2642": 1,
        "1f3cb_1f3fd_200d_2640": 1,
        "1f3cb_1f3fd_200d_2642": 1,
        "1f3cb_1f3fe_200d_2640": 1,
        "1f3cb_1f3fe_200d_2642": 1,
        "1f3cb_1f3ff_200d_2640": 1,
        "1f3cb_1f3ff_200d_2642": 1,
        "1f3cb_200d_2640": 1,
        "1f3cb_200d_2642": 1,
        "1f3cc_1f3fb_200d_2640": 1,
        "1f3cc_1f3fb_200d_2642": 1,
        "1f3cc_1f3fc_200d_2640": 1,
        "1f3cc_1f3fc_200d_2642": 1,
        "1f3cc_1f3fd_200d_2640": 1,
        "1f3cc_1f3fd_200d_2642": 1,
        "1f3cc_1f3fe_200d_2640": 1,
        "1f3cc_1f3fe_200d_2642": 1,
        "1f3cc_1f3ff_200d_2640": 1,
        "1f3cc_1f3ff_200d_2642": 1,
        "1f3cc_200d_2640": 1,
        "1f3cc_200d_2642": 1,
        "1f3cd": 1,
        "1f3ce": 1,
        "1f3cf": 1,
        "1f3d0": 1,
        "1f3d1": 1,
        "1f3d2": 1,
        "1f3d3": 1,
        "1f3d4": 1,
        "1f3d5": 1,
        "1f3d6": 1,
        "1f3d7": 1,
        "1f3d8": 1,
        "1f3d9": 1,
        "1f3da": 1,
        "1f3db": 1,
        "1f3dc": 1,
        "1f3dd": 1,
        "1f3de": 1,
        "1f3df": 1,
        "1f3e0": 1,
        "1f3e1": 1,
        "1f3e2": 1,
        "1f3e3": 1,
        "1f3e4": 1,
        "1f3e5": 1,
        "1f3e6": 1,
        "1f3e7": 1,
        "1f3e8": 1,
        "1f3e9": 1,
        "1f3ea": 1,
        "1f3eb": 1,
        "1f3ec": 1,
        "1f3ed": 1,
        "1f3ee": 1,
        "1f3ef": 1,
        "1f3f0": 1,
        "1f3f3": 1,
        "1f3f3_200d_1f308": 1,
        "1f3f4": 1,
        "1f3f4_e0067_e0062_e0065_e006e_e0067_e007f": 1,
        "1f3f4_e0067_e0062_e0073_e0063_e0074_e007f": 1,
        "1f3f4_e0067_e0062_e0077_e006c_e0073_e007f": 1,
        "1f3f5": 1,
        "1f3f7": 1,
        "1f3f8": 1,
        "1f3f9": 1,
        "1f3fa": 1,
        "1f3fb": 1,
        "1f3fc": 1,
        "1f3fd": 1,
        "1f3fe": 1,
        "1f3ff": 1,
        "1f400": 1,
        "1f401": 1,
        "1f402": 1,
        "1f403": 1,
        "1f404": 1,
        "1f405": 1,
        "1f406": 1,
        "1f407": 1,
        "1f408": 1,
        "1f409": 1,
        "1f40a": 1,
        "1f40b": 1,
        "1f40c": 1,
        "1f40d": 1,
        "1f40e": 1,
        "1f40f": 1,
        "1f410": 1,
        "1f411": 1,
        "1f412": 1,
        "1f413": 1,
        "1f414": 1,
        "1f415": 1,
        "1f416": 1,
        "1f417": 1,
        "1f418": 1,
        "1f419": 1,
        "1f41a": 1,
        "1f41b": 1,
        "1f41c": 1,
        "1f41d": 1,
        "1f41e": 1,
        "1f41f": 1,
        "1f420": 1,
        "1f421": 1,
        "1f422": 1,
        "1f423": 1,
        "1f424": 1,
        "1f425": 1,
        "1f426": 1,
        "1f427": 1,
        "1f428": 1,
        "1f429": 1,
        "1f42a": 1,
        "1f42b": 1,
        "1f42c": 1,
        "1f42d": 1,
        "1f42e": 1,
        "1f42f": 1,
        "1f430": 1,
        "1f431": 1,
        "1f432": 1,
        "1f433": 1,
        "1f434": 1,
        "1f435": 1,
        "1f436": 1,
        "1f437": 1,
        "1f438": 1,
        "1f439": 1,
        "1f43a": 1,
        "1f43b": 1,
        "1f43c": 1,
        "1f43d": 1,
        "1f43e": 1,
        "1f43f": 1,
        "1f440": 1,
        "1f441": 1,
        "1f441_200d_1f5e8": 1,
        "1f442": 1,
        "1f442_1f3fb": 1,
        "1f442_1f3fc": 1,
        "1f442_1f3fd": 1,
        "1f442_1f3fe": 1,
        "1f442_1f3ff": 1,
        "1f443": 1,
        "1f443_1f3fb": 1,
        "1f443_1f3fc": 1,
        "1f443_1f3fd": 1,
        "1f443_1f3fe": 1,
        "1f443_1f3ff": 1,
        "1f444": 1,
        "1f445": 1,
        "1f446": 1,
        "1f446_1f3fb": 1,
        "1f446_1f3fc": 1,
        "1f446_1f3fd": 1,
        "1f446_1f3fe": 1,
        "1f446_1f3ff": 1,
        "1f447": 1,
        "1f447_1f3fb": 1,
        "1f447_1f3fc": 1,
        "1f447_1f3fd": 1,
        "1f447_1f3fe": 1,
        "1f447_1f3ff": 1,
        "1f448": 1,
        "1f448_1f3fb": 1,
        "1f448_1f3fc": 1,
        "1f448_1f3fd": 1,
        "1f448_1f3fe": 1,
        "1f448_1f3ff": 1,
        "1f449": 1,
        "1f449_1f3fb": 1,
        "1f449_1f3fc": 1,
        "1f449_1f3fd": 1,
        "1f449_1f3fe": 1,
        "1f449_1f3ff": 1,
        "1f44a": 1,
        "1f44a_1f3fb": 1,
        "1f44a_1f3fc": 1,
        "1f44a_1f3fd": 1,
        "1f44a_1f3fe": 1,
        "1f44a_1f3ff": 1,
        "1f44b": 1,
        "1f44b_1f3fb": 1,
        "1f44b_1f3fc": 1,
        "1f44b_1f3fd": 1,
        "1f44b_1f3fe": 1,
        "1f44b_1f3ff": 1,
        "1f44c": 1,
        "1f44c_1f3fb": 1,
        "1f44c_1f3fc": 1,
        "1f44c_1f3fd": 1,
        "1f44c_1f3fe": 1,
        "1f44c_1f3ff": 1,
        "1f44d": 1,
        "1f44d_1f3fb": 1,
        "1f44d_1f3fc": 1,
        "1f44d_1f3fd": 1,
        "1f44d_1f3fe": 1,
        "1f44d_1f3ff": 1,
        "1f44e": 1,
        "1f44e_1f3fb": 1,
        "1f44e_1f3fc": 1,
        "1f44e_1f3fd": 1,
        "1f44e_1f3fe": 1,
        "1f44e_1f3ff": 1,
        "1f44f": 1,
        "1f44f_1f3fb": 1,
        "1f44f_1f3fc": 1,
        "1f44f_1f3fd": 1,
        "1f44f_1f3fe": 1,
        "1f44f_1f3ff": 1,
        "1f450": 1,
        "1f450_1f3fb": 1,
        "1f450_1f3fc": 1,
        "1f450_1f3fd": 1,
        "1f450_1f3fe": 1,
        "1f450_1f3ff": 1,
        "1f451": 1,
        "1f452": 1,
        "1f453": 1,
        "1f454": 1,
        "1f455": 1,
        "1f456": 1,
        "1f457": 1,
        "1f458": 1,
        "1f459": 1,
        "1f45a": 1,
        "1f45b": 1,
        "1f45c": 1,
        "1f45d": 1,
        "1f45e": 1,
        "1f45f": 1,
        "1f460": 1,
        "1f461": 1,
        "1f462": 1,
        "1f463": 1,
        "1f464": 1,
        "1f465": 1,
        "1f466": 1,
        "1f466_1f3fb": 1,
        "1f466_1f3fc": 1,
        "1f466_1f3fd": 1,
        "1f466_1f3fe": 1,
        "1f466_1f3ff": 1,
        "1f467": 1,
        "1f467_1f3fb": 1,
        "1f467_1f3fc": 1,
        "1f467_1f3fd": 1,
        "1f467_1f3fe": 1,
        "1f467_1f3ff": 1,
        "1f468": 1,
        "1f468_1f3fb": 1,
        "1f468_1f3fb_200d_1f33e": 1,
        "1f468_1f3fb_200d_1f373": 1,
        "1f468_1f3fb_200d_1f393": 1,
        "1f468_1f3fb_200d_1f3a4": 1,
        "1f468_1f3fb_200d_1f3a8": 1,
        "1f468_1f3fb_200d_1f3eb": 1,
        "1f468_1f3fb_200d_1f3ed": 1,
        "1f468_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f466_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f467_1f3fb": 1,
        "1f468_1f3fb_200d_1f467_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f467_1f3fb_200d_1f467_1f3fb": 1,
        "1f468_1f3fb_200d_1f468_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f468_1f3fb_200d_1f466_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f468_1f3fb_200d_1f467_1f3fb": 1,
        "1f468_1f3fb_200d_1f468_1f3fb_200d_1f467_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f468_1f3fb_200d_1f467_1f3fb_200d_1f467_1f3fb": 1,
        "1f468_1f3fb_200d_1f469_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f469_1f3fb_200d_1f466_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f469_1f3fb_200d_1f467_1f3fb": 1,
        "1f468_1f3fb_200d_1f469_1f3fb_200d_1f467_1f3fb_200d_1f466_1f3fb": 1,
        "1f468_1f3fb_200d_1f469_1f3fb_200d_1f467_1f3fb_200d_1f467_1f3fb": 1,
        "1f468_1f3fb_200d_1f4bb": 1,
        "1f468_1f3fb_200d_1f4bc": 1,
        "1f468_1f3fb_200d_1f527": 1,
        "1f468_1f3fb_200d_1f52c": 1,
        "1f468_1f3fb_200d_1f680": 1,
        "1f468_1f3fb_200d_1f692": 1,
        "1f468_1f3fb_200d_2695": 1,
        "1f468_1f3fb_200d_2696": 1,
        "1f468_1f3fb_200d_2708": 1,
        "1f468_1f3fc": 1,
        "1f468_1f3fc_200d_1f33e": 1,
        "1f468_1f3fc_200d_1f373": 1,
        "1f468_1f3fc_200d_1f393": 1,
        "1f468_1f3fc_200d_1f3a4": 1,
        "1f468_1f3fc_200d_1f3a8": 1,
        "1f468_1f3fc_200d_1f3eb": 1,
        "1f468_1f3fc_200d_1f3ed": 1,
        "1f468_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f466_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f467_1f3fc": 1,
        "1f468_1f3fc_200d_1f467_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f467_1f3fc_200d_1f467_1f3fc": 1,
        "1f468_1f3fc_200d_1f468_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f468_1f3fc_200d_1f466_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f468_1f3fc_200d_1f467_1f3fc": 1,
        "1f468_1f3fc_200d_1f468_1f3fc_200d_1f467_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f468_1f3fc_200d_1f467_1f3fc_200d_1f467_1f3fc": 1,
        "1f468_1f3fc_200d_1f469_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f469_1f3fc_200d_1f466_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f469_1f3fc_200d_1f467_1f3fc": 1,
        "1f468_1f3fc_200d_1f469_1f3fc_200d_1f467_1f3fc_200d_1f466_1f3fc": 1,
        "1f468_1f3fc_200d_1f469_1f3fc_200d_1f467_1f3fc_200d_1f467_1f3fc": 1,
        "1f468_1f3fc_200d_1f4bb": 1,
        "1f468_1f3fc_200d_1f4bc": 1,
        "1f468_1f3fc_200d_1f527": 1,
        "1f468_1f3fc_200d_1f52c": 1,
        "1f468_1f3fc_200d_1f680": 1,
        "1f468_1f3fc_200d_1f692": 1,
        "1f468_1f3fc_200d_2695": 1,
        "1f468_1f3fc_200d_2696": 1,
        "1f468_1f3fc_200d_2708": 1,
        "1f468_1f3fd": 1,
        "1f468_1f3fd_200d_1f33e": 1,
        "1f468_1f3fd_200d_1f373": 1,
        "1f468_1f3fd_200d_1f393": 1,
        "1f468_1f3fd_200d_1f3a4": 1,
        "1f468_1f3fd_200d_1f3a8": 1,
        "1f468_1f3fd_200d_1f3eb": 1,
        "1f468_1f3fd_200d_1f3ed": 1,
        "1f468_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f466_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f467_1f3fd": 1,
        "1f468_1f3fd_200d_1f467_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f467_1f3fd_200d_1f467_1f3fd": 1,
        "1f468_1f3fd_200d_1f468_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f468_1f3fd_200d_1f466_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f468_1f3fd_200d_1f467_1f3fd": 1,
        "1f468_1f3fd_200d_1f468_1f3fd_200d_1f467_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f468_1f3fd_200d_1f467_1f3fd_200d_1f467_1f3fd": 1,
        "1f468_1f3fd_200d_1f469_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f469_1f3fd_200d_1f466_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f469_1f3fd_200d_1f467_1f3fd": 1,
        "1f468_1f3fd_200d_1f469_1f3fd_200d_1f467_1f3fd_200d_1f466_1f3fd": 1,
        "1f468_1f3fd_200d_1f469_1f3fd_200d_1f467_1f3fd_200d_1f467_1f3fd": 1,
        "1f468_1f3fd_200d_1f4bb": 1,
        "1f468_1f3fd_200d_1f4bc": 1,
        "1f468_1f3fd_200d_1f527": 1,
        "1f468_1f3fd_200d_1f52c": 1,
        "1f468_1f3fd_200d_1f680": 1,
        "1f468_1f3fd_200d_1f692": 1,
        "1f468_1f3fd_200d_2695": 1,
        "1f468_1f3fd_200d_2696": 1,
        "1f468_1f3fd_200d_2708": 1,
        "1f468_1f3fe": 1,
        "1f468_1f3fe_200d_1f33e": 1,
        "1f468_1f3fe_200d_1f373": 1,
        "1f468_1f3fe_200d_1f393": 1,
        "1f468_1f3fe_200d_1f3a4": 1,
        "1f468_1f3fe_200d_1f3a8": 1,
        "1f468_1f3fe_200d_1f3eb": 1,
        "1f468_1f3fe_200d_1f3ed": 1,
        "1f468_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f466_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f467_1f3fe": 1,
        "1f468_1f3fe_200d_1f467_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f467_1f3fe_200d_1f467_1f3fe": 1,
        "1f468_1f3fe_200d_1f468_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f468_1f3fe_200d_1f466_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f468_1f3fe_200d_1f467_1f3fe": 1,
        "1f468_1f3fe_200d_1f468_1f3fe_200d_1f467_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f468_1f3fe_200d_1f467_1f3fe_200d_1f467_1f3fe": 1,
        "1f468_1f3fe_200d_1f469_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f469_1f3fe_200d_1f466_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f469_1f3fe_200d_1f467_1f3fe": 1,
        "1f468_1f3fe_200d_1f469_1f3fe_200d_1f467_1f3fe_200d_1f466_1f3fe": 1,
        "1f468_1f3fe_200d_1f469_1f3fe_200d_1f467_1f3fe_200d_1f467_1f3fe": 1,
        "1f468_1f3fe_200d_1f4bb": 1,
        "1f468_1f3fe_200d_1f4bc": 1,
        "1f468_1f3fe_200d_1f527": 1,
        "1f468_1f3fe_200d_1f52c": 1,
        "1f468_1f3fe_200d_1f680": 1,
        "1f468_1f3fe_200d_1f692": 1,
        "1f468_1f3fe_200d_2695": 1,
        "1f468_1f3fe_200d_2696": 1,
        "1f468_1f3fe_200d_2708": 1,
        "1f468_1f3ff": 1,
        "1f468_1f3ff_200d_1f33e": 1,
        "1f468_1f3ff_200d_1f373": 1,
        "1f468_1f3ff_200d_1f393": 1,
        "1f468_1f3ff_200d_1f3a4": 1,
        "1f468_1f3ff_200d_1f3a8": 1,
        "1f468_1f3ff_200d_1f3eb": 1,
        "1f468_1f3ff_200d_1f3ed": 1,
        "1f468_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f466_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f467_1f3ff": 1,
        "1f468_1f3ff_200d_1f467_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f467_1f3ff_200d_1f467_1f3ff": 1,
        "1f468_1f3ff_200d_1f468_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f468_1f3ff_200d_1f466_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f468_1f3ff_200d_1f467_1f3ff": 1,
        "1f468_1f3ff_200d_1f468_1f3ff_200d_1f467_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f468_1f3ff_200d_1f467_1f3ff_200d_1f467_1f3ff": 1,
        "1f468_1f3ff_200d_1f469_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f469_1f3ff_200d_1f466_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f469_1f3ff_200d_1f467_1f3ff": 1,
        "1f468_1f3ff_200d_1f469_1f3ff_200d_1f467_1f3ff_200d_1f466_1f3ff": 1,
        "1f468_1f3ff_200d_1f469_1f3ff_200d_1f467_1f3ff_200d_1f467_1f3ff": 1,
        "1f468_1f3ff_200d_1f4bb": 1,
        "1f468_1f3ff_200d_1f4bc": 1,
        "1f468_1f3ff_200d_1f527": 1,
        "1f468_1f3ff_200d_1f52c": 1,
        "1f468_1f3ff_200d_1f680": 1,
        "1f468_1f3ff_200d_1f692": 1,
        "1f468_1f3ff_200d_2695": 1,
        "1f468_1f3ff_200d_2696": 1,
        "1f468_1f3ff_200d_2708": 1,
        "1f468_200d_1f33e": 1,
        "1f468_200d_1f373": 1,
        "1f468_200d_1f393": 1,
        "1f468_200d_1f3a4": 1,
        "1f468_200d_1f3a8": 1,
        "1f468_200d_1f3eb": 1,
        "1f468_200d_1f3ed": 1,
        "1f468_200d_1f466": 1,
        "1f468_200d_1f466_200d_1f466": 1,
        "1f468_200d_1f467": 1,
        "1f468_200d_1f467_200d_1f466": 1,
        "1f468_200d_1f467_200d_1f467": 1,
        "1f468_200d_1f468_200d_1f466": 1,
        "1f468_200d_1f468_200d_1f466_200d_1f466": 1,
        "1f468_200d_1f468_200d_1f467": 1,
        "1f468_200d_1f468_200d_1f467_200d_1f466": 1,
        "1f468_200d_1f468_200d_1f467_200d_1f467": 1,
        "1f468_200d_1f469_200d_1f466": 1,
        "1f468_200d_1f469_200d_1f466_200d_1f466": 1,
        "1f468_200d_1f469_200d_1f467": 1,
        "1f468_200d_1f469_200d_1f467_200d_1f466": 1,
        "1f468_200d_1f469_200d_1f467_200d_1f467": 1,
        "1f468_200d_1f4bb": 1,
        "1f468_200d_1f4bc": 1,
        "1f468_200d_1f527": 1,
        "1f468_200d_1f52c": 1,
        "1f468_200d_1f680": 1,
        "1f468_200d_1f692": 1,
        "1f468_200d_2695": 1,
        "1f468_200d_2696": 1,
        "1f468_200d_2708": 1,
        "1f468_200d_2764_200d_1f468": 1,
        "1f468_200d_2764_200d_1f48b_200d_1f468": 1,
        "1f469": 1,
        "1f469_1f3fb": 1,
        "1f469_1f3fb_200d_1f33e": 1,
        "1f469_1f3fb_200d_1f373": 1,
        "1f469_1f3fb_200d_1f393": 1,
        "1f469_1f3fb_200d_1f3a4": 1,
        "1f469_1f3fb_200d_1f3a8": 1,
        "1f469_1f3fb_200d_1f3eb": 1,
        "1f469_1f3fb_200d_1f3ed": 1,
        "1f469_1f3fb_200d_1f466_1f3fb": 1,
        "1f469_1f3fb_200d_1f466_1f3fb_200d_1f466_1f3fb": 1,
        "1f469_1f3fb_200d_1f467_1f3fb": 1,
        "1f469_1f3fb_200d_1f467_1f3fb_200d_1f466_1f3fb": 1,
        "1f469_1f3fb_200d_1f467_1f3fb_200d_1f467_1f3fb": 1,
        "1f469_1f3fb_200d_1f469_1f3fb_200d_1f466_1f3fb": 1,
        "1f469_1f3fb_200d_1f469_1f3fb_200d_1f466_1f3fb_200d_1f466_1f3fb": 1,
        "1f469_1f3fb_200d_1f469_1f3fb_200d_1f467_1f3fb": 1,
        "1f469_1f3fb_200d_1f469_1f3fb_200d_1f467_1f3fb_200d_1f466_1f3fb": 1,
        "1f469_1f3fb_200d_1f469_1f3fb_200d_1f467_1f3fb_200d_1f467_1f3fb": 1,
        "1f469_1f3fb_200d_1f4bb": 1,
        "1f469_1f3fb_200d_1f4bc": 1,
        "1f469_1f3fb_200d_1f527": 1,
        "1f469_1f3fb_200d_1f52c": 1,
        "1f469_1f3fb_200d_1f680": 1,
        "1f469_1f3fb_200d_1f692": 1,
        "1f469_1f3fb_200d_2695": 1,
        "1f469_1f3fb_200d_2696": 1,
        "1f469_1f3fb_200d_2708": 1,
        "1f469_1f3fc": 1,
        "1f469_1f3fc_200d_1f33e": 1,
        "1f469_1f3fc_200d_1f373": 1,
        "1f469_1f3fc_200d_1f393": 1,
        "1f469_1f3fc_200d_1f3a4": 1,
        "1f469_1f3fc_200d_1f3a8": 1,
        "1f469_1f3fc_200d_1f3eb": 1,
        "1f469_1f3fc_200d_1f3ed": 1,
        "1f469_1f3fc_200d_1f466_1f3fc": 1,
        "1f469_1f3fc_200d_1f466_1f3fc_200d_1f466_1f3fc": 1,
        "1f469_1f3fc_200d_1f467_1f3fc": 1,
        "1f469_1f3fc_200d_1f467_1f3fc_200d_1f466_1f3fc": 1,
        "1f469_1f3fc_200d_1f467_1f3fc_200d_1f467_1f3fc": 1,
        "1f469_1f3fc_200d_1f469_1f3fc_200d_1f466_1f3fc": 1,
        "1f469_1f3fc_200d_1f469_1f3fc_200d_1f466_1f3fc_200d_1f466_1f3fc": 1,
        "1f469_1f3fc_200d_1f469_1f3fc_200d_1f467_1f3fc": 1,
        "1f469_1f3fc_200d_1f469_1f3fc_200d_1f467_1f3fc_200d_1f466_1f3fc": 1,
        "1f469_1f3fc_200d_1f469_1f3fc_200d_1f467_1f3fc_200d_1f467_1f3fc": 1,
        "1f469_1f3fc_200d_1f4bb": 1,
        "1f469_1f3fc_200d_1f4bc": 1,
        "1f469_1f3fc_200d_1f527": 1,
        "1f469_1f3fc_200d_1f52c": 1,
        "1f469_1f3fc_200d_1f680": 1,
        "1f469_1f3fc_200d_1f692": 1,
        "1f469_1f3fc_200d_2695": 1,
        "1f469_1f3fc_200d_2696": 1,
        "1f469_1f3fc_200d_2708": 1,
        "1f469_1f3fd": 1,
        "1f469_1f3fd_200d_1f33e": 1,
        "1f469_1f3fd_200d_1f373": 1,
        "1f469_1f3fd_200d_1f393": 1,
        "1f469_1f3fd_200d_1f3a4": 1,
        "1f469_1f3fd_200d_1f3a8": 1,
        "1f469_1f3fd_200d_1f3eb": 1,
        "1f469_1f3fd_200d_1f3ed": 1,
        "1f469_1f3fd_200d_1f466_1f3fd": 1,
        "1f469_1f3fd_200d_1f466_1f3fd_200d_1f466_1f3fd": 1,
        "1f469_1f3fd_200d_1f467_1f3fd": 1,
        "1f469_1f3fd_200d_1f467_1f3fd_200d_1f466_1f3fd": 1,
        "1f469_1f3fd_200d_1f467_1f3fd_200d_1f467_1f3fd": 1,
        "1f469_1f3fd_200d_1f469_1f3fd_200d_1f466_1f3fd": 1,
        "1f469_1f3fd_200d_1f469_1f3fd_200d_1f466_1f3fd_200d_1f466_1f3fd": 1,
        "1f469_1f3fd_200d_1f469_1f3fd_200d_1f467_1f3fd": 1,
        "1f469_1f3fd_200d_1f469_1f3fd_200d_1f467_1f3fd_200d_1f466_1f3fd": 1,
        "1f469_1f3fd_200d_1f469_1f3fd_200d_1f467_1f3fd_200d_1f467_1f3fd": 1,
        "1f469_1f3fd_200d_1f4bb": 1,
        "1f469_1f3fd_200d_1f4bc": 1,
        "1f469_1f3fd_200d_1f527": 1,
        "1f469_1f3fd_200d_1f52c": 1,
        "1f469_1f3fd_200d_1f680": 1,
        "1f469_1f3fd_200d_1f692": 1,
        "1f469_1f3fd_200d_2695": 1,
        "1f469_1f3fd_200d_2696": 1,
        "1f469_1f3fd_200d_2708": 1,
        "1f469_1f3fe": 1,
        "1f469_1f3fe_200d_1f33e": 1,
        "1f469_1f3fe_200d_1f373": 1,
        "1f469_1f3fe_200d_1f393": 1,
        "1f469_1f3fe_200d_1f3a4": 1,
        "1f469_1f3fe_200d_1f3a8": 1,
        "1f469_1f3fe_200d_1f3eb": 1,
        "1f469_1f3fe_200d_1f3ed": 1,
        "1f469_1f3fe_200d_1f466_1f3fe": 1,
        "1f469_1f3fe_200d_1f466_1f3fe_200d_1f466_1f3fe": 1,
        "1f469_1f3fe_200d_1f467_1f3fe": 1,
        "1f469_1f3fe_200d_1f467_1f3fe_200d_1f466_1f3fe": 1,
        "1f469_1f3fe_200d_1f467_1f3fe_200d_1f467_1f3fe": 1,
        "1f469_1f3fe_200d_1f469_1f3fe_200d_1f466_1f3fe": 1,
        "1f469_1f3fe_200d_1f469_1f3fe_200d_1f466_1f3fe_200d_1f466_1f3fe": 1,
        "1f469_1f3fe_200d_1f469_1f3fe_200d_1f467_1f3fe": 1,
        "1f469_1f3fe_200d_1f469_1f3fe_200d_1f467_1f3fe_200d_1f466_1f3fe": 1,
        "1f469_1f3fe_200d_1f469_1f3fe_200d_1f467_1f3fe_200d_1f467_1f3fe": 1,
        "1f469_1f3fe_200d_1f4bb": 1,
        "1f469_1f3fe_200d_1f4bc": 1,
        "1f469_1f3fe_200d_1f527": 1,
        "1f469_1f3fe_200d_1f52c": 1,
        "1f469_1f3fe_200d_1f680": 1,
        "1f469_1f3fe_200d_1f692": 1,
        "1f469_1f3fe_200d_2695": 1,
        "1f469_1f3fe_200d_2696": 1,
        "1f469_1f3fe_200d_2708": 1,
        "1f469_1f3ff": 1,
        "1f469_1f3ff_200d_1f33e": 1,
        "1f469_1f3ff_200d_1f373": 1,
        "1f469_1f3ff_200d_1f393": 1,
        "1f469_1f3ff_200d_1f3a4": 1,
        "1f469_1f3ff_200d_1f3a8": 1,
        "1f469_1f3ff_200d_1f3eb": 1,
        "1f469_1f3ff_200d_1f3ed": 1,
        "1f469_1f3ff_200d_1f466_1f3ff": 1,
        "1f469_1f3ff_200d_1f466_1f3ff_200d_1f466_1f3ff": 1,
        "1f469_1f3ff_200d_1f467_1f3ff": 1,
        "1f469_1f3ff_200d_1f467_1f3ff_200d_1f466_1f3ff": 1,
        "1f469_1f3ff_200d_1f467_1f3ff_200d_1f467_1f3ff": 1,
        "1f469_1f3ff_200d_1f469_1f3ff_200d_1f466_1f3ff": 1,
        "1f469_1f3ff_200d_1f469_1f3ff_200d_1f466_1f3ff_200d_1f466_1f3ff": 1,
        "1f469_1f3ff_200d_1f469_1f3ff_200d_1f467_1f3ff": 1,
        "1f469_1f3ff_200d_1f469_1f3ff_200d_1f467_1f3ff_200d_1f466_1f3ff": 1,
        "1f469_1f3ff_200d_1f469_1f3ff_200d_1f467_1f3ff_200d_1f467_1f3ff": 1,
        "1f469_1f3ff_200d_1f4bb": 1,
        "1f469_1f3ff_200d_1f4bc": 1,
        "1f469_1f3ff_200d_1f527": 1,
        "1f469_1f3ff_200d_1f52c": 1,
        "1f469_1f3ff_200d_1f680": 1,
        "1f469_1f3ff_200d_1f692": 1,
        "1f469_1f3ff_200d_2695": 1,
        "1f469_1f3ff_200d_2696": 1,
        "1f469_1f3ff_200d_2708": 1,
        "1f469_200d_1f33e": 1,
        "1f469_200d_1f373": 1,
        "1f469_200d_1f393": 1,
        "1f469_200d_1f3a4": 1,
        "1f469_200d_1f3a8": 1,
        "1f469_200d_1f3eb": 1,
        "1f469_200d_1f3ed": 1,
        "1f469_200d_1f466": 1,
        "1f469_200d_1f466_200d_1f466": 1,
        "1f469_200d_1f467": 1,
        "1f469_200d_1f467_200d_1f466": 1,
        "1f469_200d_1f467_200d_1f467": 1,
        "1f469_200d_1f469_200d_1f466": 1,
        "1f469_200d_1f469_200d_1f466_200d_1f466": 1,
        "1f469_200d_1f469_200d_1f467": 1,
        "1f469_200d_1f469_200d_1f467_200d_1f466": 1,
        "1f469_200d_1f469_200d_1f467_200d_1f467": 1,
        "1f469_200d_1f4bb": 1,
        "1f469_200d_1f4bc": 1,
        "1f469_200d_1f527": 1,
        "1f469_200d_1f52c": 1,
        "1f469_200d_1f680": 1,
        "1f469_200d_1f692": 1,
        "1f469_200d_2695": 1,
        "1f469_200d_2696": 1,
        "1f469_200d_2708": 1,
        "1f469_200d_2764_200d_1f468": 1,
        "1f469_200d_2764_200d_1f469": 1,
        "1f469_200d_2764_200d_1f48b_200d_1f468": 1,
        "1f469_200d_2764_200d_1f48b_200d_1f469": 1,
        "1f46a_1f3fb": 1,
        "1f46a_1f3fc": 1,
        "1f46a_1f3fd": 1,
        "1f46a_1f3fe": 1,
        "1f46a_1f3ff": 1,
        "1f46b": 1,
        "1f46b_1f3fb": 1,
        "1f46b_1f3fc": 1,
        "1f46b_1f3fd": 1,
        "1f46b_1f3fe": 1,
        "1f46b_1f3ff": 1,
        "1f46c": 1,
        "1f46c_1f3fb": 1,
        "1f46c_1f3fc": 1,
        "1f46c_1f3fd": 1,
        "1f46c_1f3fe": 1,
        "1f46c_1f3ff": 1,
        "1f46d": 1,
        "1f46d_1f3fb": 1,
        "1f46d_1f3fc": 1,
        "1f46d_1f3fd": 1,
        "1f46d_1f3fe": 1,
        "1f46d_1f3ff": 1,
        "1f46e_1f3fb_200d_2640": 1,
        "1f46e_1f3fb_200d_2642": 1,
        "1f46e_1f3fc_200d_2640": 1,
        "1f46e_1f3fc_200d_2642": 1,
        "1f46e_1f3fd_200d_2640": 1,
        "1f46e_1f3fd_200d_2642": 1,
        "1f46e_1f3fe_200d_2640": 1,
        "1f46e_1f3fe_200d_2642": 1,
        "1f46e_1f3ff_200d_2640": 1,
        "1f46e_1f3ff_200d_2642": 1,
        "1f46e_200d_2640": 1,
        "1f46e_200d_2642": 1,
        "1f46f_1f3fb_200d_2640": 1,
        "1f46f_1f3fb_200d_2642": 1,
        "1f46f_1f3fc_200d_2640": 1,
        "1f46f_1f3fc_200d_2642": 1,
        "1f46f_1f3fd_200d_2640": 1,
        "1f46f_1f3fd_200d_2642": 1,
        "1f46f_1f3fe_200d_2640": 1,
        "1f46f_1f3fe_200d_2642": 1,
        "1f46f_1f3ff_200d_2640": 1,
        "1f46f_1f3ff_200d_2642": 1,
        "1f46f_200d_2640": 1,
        "1f46f_200d_2642": 1,
        "1f470": 1,
        "1f470_1f3fb": 1,
        "1f470_1f3fc": 1,
        "1f470_1f3fd": 1,
        "1f470_1f3fe": 1,
        "1f470_1f3ff": 1,
        "1f471_1f3fb_200d_2640": 1,
        "1f471_1f3fb_200d_2642": 1,
        "1f471_1f3fc_200d_2640": 1,
        "1f471_1f3fc_200d_2642": 1,
        "1f471_1f3fd_200d_2640": 1,
        "1f471_1f3fd_200d_2642": 1,
        "1f471_1f3fe_200d_2640": 1,
        "1f471_1f3fe_200d_2642": 1,
        "1f471_1f3ff_200d_2640": 1,
        "1f471_1f3ff_200d_2642": 1,
        "1f471_200d_2640": 1,
        "1f471_200d_2642": 1,
        "1f472": 1,
        "1f472_1f3fb": 1,
        "1f472_1f3fc": 1,
        "1f472_1f3fd": 1,
        "1f472_1f3fe": 1,
        "1f472_1f3ff": 1,
        "1f473_1f3fb_200d_2640": 1,
        "1f473_1f3fb_200d_2642": 1,
        "1f473_1f3fc_200d_2640": 1,
        "1f473_1f3fc_200d_2642": 1,
        "1f473_1f3fd_200d_2640": 1,
        "1f473_1f3fd_200d_2642": 1,
        "1f473_1f3fe_200d_2640": 1,
        "1f473_1f3fe_200d_2642": 1,
        "1f473_1f3ff_200d_2640": 1,
        "1f473_1f3ff_200d_2642": 1,
        "1f473_200d_2640": 1,
        "1f473_200d_2642": 1,
        "1f474": 1,
        "1f474_1f3fb": 1,
        "1f474_1f3fc": 1,
        "1f474_1f3fd": 1,
        "1f474_1f3fe": 1,
        "1f474_1f3ff": 1,
        "1f475": 1,
        "1f475_1f3fb": 1,
        "1f475_1f3fc": 1,
        "1f475_1f3fd": 1,
        "1f475_1f3fe": 1,
        "1f475_1f3ff": 1,
        "1f476": 1,
        "1f476_1f3fb": 1,
        "1f476_1f3fc": 1,
        "1f476_1f3fd": 1,
        "1f476_1f3fe": 1,
        "1f476_1f3ff": 1,
        "1f477_1f3fb_200d_2640": 1,
        "1f477_1f3fb_200d_2642": 1,
        "1f477_1f3fc_200d_2640": 1,
        "1f477_1f3fc_200d_2642": 1,
        "1f477_1f3fd_200d_2640": 1,
        "1f477_1f3fd_200d_2642": 1,
        "1f477_1f3fe_200d_2640": 1,
        "1f477_1f3fe_200d_2642": 1,
        "1f477_1f3ff_200d_2640": 1,
        "1f477_1f3ff_200d_2642": 1,
        "1f477_200d_2640": 1,
        "1f477_200d_2642": 1,
        "1f478": 1,
        "1f478_1f3fb": 1,
        "1f478_1f3fc": 1,
        "1f478_1f3fd": 1,
        "1f478_1f3fe": 1,
        "1f478_1f3ff": 1,
        "1f479": 1,
        "1f47a": 1,
        "1f47b": 1,
        "1f47c": 1,
        "1f47c_1f3fb": 1,
        "1f47c_1f3fc": 1,
        "1f47c_1f3fd": 1,
        "1f47c_1f3fe": 1,
        "1f47c_1f3ff": 1,
        "1f47d": 1,
        "1f47e": 1,
        "1f47f": 1,
        "1f480": 1,
        "1f481_1f3fb_200d_2640": 1,
        "1f481_1f3fb_200d_2642": 1,
        "1f481_1f3fc_200d_2640": 1,
        "1f481_1f3fc_200d_2642": 1,
        "1f481_1f3fd_200d_2640": 1,
        "1f481_1f3fd_200d_2642": 1,
        "1f481_1f3fe_200d_2640": 1,
        "1f481_1f3fe_200d_2642": 1,
        "1f481_1f3ff_200d_2640": 1,
        "1f481_1f3ff_200d_2642": 1,
        "1f481_200d_2640": 1,
        "1f481_200d_2642": 1,
        "1f482_1f3fb_200d_2640": 1,
        "1f482_1f3fb_200d_2642": 1,
        "1f482_1f3fc_200d_2640": 1,
        "1f482_1f3fc_200d_2642": 1,
        "1f482_1f3fd_200d_2640": 1,
        "1f482_1f3fd_200d_2642": 1,
        "1f482_1f3fe_200d_2640": 1,
        "1f482_1f3fe_200d_2642": 1,
        "1f482_1f3ff_200d_2640": 1,
        "1f482_1f3ff_200d_2642": 1,
        "1f482_200d_2640": 1,
        "1f482_200d_2642": 1,
        "1f483": 1,
        "1f483_1f3fb": 1,
        "1f483_1f3fc": 1,
        "1f483_1f3fd": 1,
        "1f483_1f3fe": 1,
        "1f483_1f3ff": 1,
        "1f484": 1,
        "1f485": 1,
        "1f485_1f3fb": 1,
        "1f485_1f3fc": 1,
        "1f485_1f3fd": 1,
        "1f485_1f3fe": 1,
        "1f485_1f3ff": 1,
        "1f486_1f3fb_200d_2640": 1,
        "1f486_1f3fb_200d_2642": 1,
        "1f486_1f3fc_200d_2640": 1,
        "1f486_1f3fc_200d_2642": 1,
        "1f486_1f3fd_200d_2640": 1,
        "1f486_1f3fd_200d_2642": 1,
        "1f486_1f3fe_200d_2640": 1,
        "1f486_1f3fe_200d_2642": 1,
        "1f486_1f3ff_200d_2640": 1,
        "1f486_1f3ff_200d_2642": 1,
        "1f486_200d_2640": 1,
        "1f486_200d_2642": 1,
        "1f487_1f3fb_200d_2640": 1,
        "1f487_1f3fb_200d_2642": 1,
        "1f487_1f3fc_200d_2640": 1,
        "1f487_1f3fc_200d_2642": 1,
        "1f487_1f3fd_200d_2640": 1,
        "1f487_1f3fd_200d_2642": 1,
        "1f487_1f3fe_200d_2640": 1,
        "1f487_1f3fe_200d_2642": 1,
        "1f487_1f3ff_200d_2640": 1,
        "1f487_1f3ff_200d_2642": 1,
        "1f487_200d_2640": 1,
        "1f487_200d_2642": 1,
        "1f488": 1,
        "1f489": 1,
        "1f48a": 1,
        "1f48b": 1,
        "1f48c": 1,
        "1f48d": 1,
        "1f48e": 1,
        "1f490": 1,
        "1f492": 1,
        "1f493": 1,
        "1f494": 1,
        "1f495": 1,
        "1f496": 1,
        "1f497": 1,
        "1f498": 1,
        "1f499": 1,
        "1f49a": 1,
        "1f49b": 1,
        "1f49c": 1,
        "1f49d": 1,
        "1f49e": 1,
        "1f49f": 1,
        "1f4a0": 1,
        "1f4a1": 1,
        "1f4a2": 1,
        "1f4a3": 1,
        "1f4a4": 1,
        "1f4a5": 1,
        "1f4a6": 1,
        "1f4a7": 1,
        "1f4a8": 1,
        "1f4a9": 1,
        "1f4aa": 1,
        "1f4aa_1f3fb": 1,
        "1f4aa_1f3fc": 1,
        "1f4aa_1f3fd": 1,
        "1f4aa_1f3fe": 1,
        "1f4aa_1f3ff": 1,
        "1f4ab": 1,
        "1f4ac": 1,
        "1f4ad": 1,
        "1f4ae": 1,
        "1f4af": 1,
        "1f4b0": 1,
        "1f4b1": 1,
        "1f4b2": 1,
        "1f4b3": 1,
        "1f4b4": 1,
        "1f4b5": 1,
        "1f4b6": 1,
        "1f4b7": 1,
        "1f4b8": 1,
        "1f4b9": 1,
        "1f4ba": 1,
        "1f4bb": 1,
        "1f4bc": 1,
        "1f4bd": 1,
        "1f4be": 1,
        "1f4bf": 1,
        "1f4c0": 1,
        "1f4c1": 1,
        "1f4c2": 1,
        "1f4c3": 1,
        "1f4c4": 1,
        "1f4c5": 1,
        "1f4c6": 1,
        "1f4c7": 1,
        "1f4c8": 1,
        "1f4c9": 1,
        "1f4ca": 1,
        "1f4cb": 1,
        "1f4cc": 1,
        "1f4cd": 1,
        "1f4ce": 1,
        "1f4cf": 1,
        "1f4d0": 1,
        "1f4d1": 1,
        "1f4d2": 1,
        "1f4d3": 1,
        "1f4d4": 1,
        "1f4d5": 1,
        "1f4d6": 1,
        "1f4d7": 1,
        "1f4d8": 1,
        "1f4d9": 1,
        "1f4da": 1,
        "1f4db": 1,
        "1f4dc": 1,
        "1f4dd": 1,
        "1f4de": 1,
        "1f4df": 1,
        "1f4e0": 1,
        "1f4e1": 1,
        "1f4e2": 1,
        "1f4e3": 1,
        "1f4e4": 1,
        "1f4e5": 1,
        "1f4e6": 1,
        "1f4e7": 1,
        "1f4e8": 1,
        "1f4e9": 1,
        "1f4ea": 1,
        "1f4eb": 1,
        "1f4ec": 1,
        "1f4ed": 1,
        "1f4ee": 1,
        "1f4ef": 1,
        "1f4f0": 1,
        "1f4f1": 1,
        "1f4f2": 1,
        "1f4f3": 1,
        "1f4f4": 1,
        "1f4f5": 1,
        "1f4f6": 1,
        "1f4f7": 1,
        "1f4f8": 1,
        "1f4f9": 1,
        "1f4fa": 1,
        "1f4fb": 1,
        "1f4fc": 1,
        "1f4fd": 1,
        "1f4ff": 1,
        "1f500": 1,
        "1f501": 1,
        "1f502": 1,
        "1f503": 1,
        "1f504": 1,
        "1f505": 1,
        "1f506": 1,
        "1f507": 1,
        "1f508": 1,
        "1f509": 1,
        "1f50a": 1,
        "1f50b": 1,
        "1f50c": 1,
        "1f50d": 1,
        "1f50e": 1,
        "1f50f": 1,
        "1f510": 1,
        "1f511": 1,
        "1f512": 1,
        "1f513": 1,
        "1f514": 1,
        "1f515": 1,
        "1f516": 1,
        "1f517": 1,
        "1f518": 1,
        "1f519": 1,
        "1f51a": 1,
        "1f51b": 1,
        "1f51c": 1,
        "1f51d": 1,
        "1f51e": 1,
        "1f51f": 1,
        "1f520": 1,
        "1f521": 1,
        "1f522": 1,
        "1f523": 1,
        "1f524": 1,
        "1f525": 1,
        "1f526": 1,
        "1f527": 1,
        "1f528": 1,
        "1f529": 1,
        "1f52a": 1,
        "1f52b": 1,
        "1f52c": 1,
        "1f52d": 1,
        "1f52e": 1,
        "1f52f": 1,
        "1f530": 1,
        "1f531": 1,
        "1f532": 1,
        "1f533": 1,
        "1f534": 1,
        "1f535": 1,
        "1f536": 1,
        "1f537": 1,
        "1f538": 1,
        "1f539": 1,
        "1f53a": 1,
        "1f53b": 1,
        "1f53c": 1,
        "1f53d": 1,
        "1f549": 1,
        "1f54a": 1,
        "1f54b": 1,
        "1f54c": 1,
        "1f54d": 1,
        "1f54e": 1,
        "1f550": 1,
        "1f551": 1,
        "1f552": 1,
        "1f553": 1,
        "1f554": 1,
        "1f555": 1,
        "1f556": 1,
        "1f557": 1,
        "1f558": 1,
        "1f559": 1,
        "1f55a": 1,
        "1f55b": 1,
        "1f55c": 1,
        "1f55d": 1,
        "1f55e": 1,
        "1f55f": 1,
        "1f560": 1,
        "1f561": 1,
        "1f562": 1,
        "1f563": 1,
        "1f564": 1,
        "1f565": 1,
        "1f566": 1,
        "1f567": 1,
        "1f56f": 1,
        "1f570": 1,
        "1f573": 1,
        "1f574": 1,
        "1f574_1f3fb": 1,
        "1f574_1f3fb_200d_2640": 1,
        "1f574_1f3fc": 1,
        "1f574_1f3fc_200d_2640": 1,
        "1f574_1f3fd": 1,
        "1f574_1f3fd_200d_2640": 1,
        "1f574_1f3fe": 1,
        "1f574_1f3fe_200d_2640": 1,
        "1f574_1f3ff": 1,
        "1f574_1f3ff_200d_2640": 1,
        "1f574_200d_2640": 1,
        "1f575_1f3fb_200d_2640": 1,
        "1f575_1f3fb_200d_2642": 1,
        "1f575_1f3fc_200d_2640": 1,
        "1f575_1f3fc_200d_2642": 1,
        "1f575_1f3fd_200d_2640": 1,
        "1f575_1f3fd_200d_2642": 1,
        "1f575_1f3fe_200d_2640": 1,
        "1f575_1f3fe_200d_2642": 1,
        "1f575_1f3ff_200d_2640": 1,
        "1f575_1f3ff_200d_2642": 1,
        "1f575_200d_2640": 1,
        "1f575_200d_2642": 1,
        "1f576": 1,
        "1f577": 1,
        "1f578": 1,
        "1f579": 1,
        "1f57a": 1,
        "1f57a_1f3fb": 1,
        "1f57a_1f3fc": 1,
        "1f57a_1f3fd": 1,
        "1f57a_1f3fe": 1,
        "1f57a_1f3ff": 1,
        "1f587": 1,
        "1f58a": 1,
        "1f58b": 1,
        "1f58c": 1,
        "1f58d": 1,
        "1f590": 1,
        "1f590_1f3fb": 1,
        "1f590_1f3fc": 1,
        "1f590_1f3fd": 1,
        "1f590_1f3fe": 1,
        "1f590_1f3ff": 1,
        "1f595": 1,
        "1f595_1f3fb": 1,
        "1f595_1f3fc": 1,
        "1f595_1f3fd": 1,
        "1f595_1f3fe": 1,
        "1f595_1f3ff": 1,
        "1f596": 1,
        "1f596_1f3fb": 1,
        "1f596_1f3fc": 1,
        "1f596_1f3fd": 1,
        "1f596_1f3fe": 1,
        "1f596_1f3ff": 1,
        "1f5a4": 1,
        "1f5a5": 1,
        "1f5a8": 1,
        "1f5b1": 1,
        "1f5b2": 1,
        "1f5bc": 1,
        "1f5c2": 1,
        "1f5c3": 1,
        "1f5c4": 1,
        "1f5d1": 1,
        "1f5d2": 1,
        "1f5d3": 1,
        "1f5dc": 1,
        "1f5dd": 1,
        "1f5de": 1,
        "1f5e1": 1,
        "1f5e3": 1,
        "1f5e8": 1,
        "1f5ef": 1,
        "1f5f3": 1,
        "1f5fa": 1,
        "1f5fb": 1,
        "1f5fc": 1,
        "1f5fd": 1,
        "1f5fe": 1,
        "1f5ff": 1,
        "1f600": 1,
        "1f601": 1,
        "1f602": 1,
        "1f603": 1,
        "1f604": 1,
        "1f605": 1,
        "1f606": 1,
        "1f607": 1,
        "1f608": 1,
        "1f609": 1,
        "1f60a": 1,
        "1f60b": 1,
        "1f60c": 1,
        "1f60d": 1,
        "1f60e": 1,
        "1f60f": 1,
        "1f610": 1,
        "1f611": 1,
        "1f612": 1,
        "1f613": 1,
        "1f614": 1,
        "1f615": 1,
        "1f616": 1,
        "1f617": 1,
        "1f618": 1,
        "1f619": 1,
        "1f61a": 1,
        "1f61b": 1,
        "1f61c": 1,
        "1f61d": 1,
        "1f61e": 1,
        "1f61f": 1,
        "1f620": 1,
        "1f621": 1,
        "1f622": 1,
        "1f623": 1,
        "1f624": 1,
        "1f625": 1,
        "1f626": 1,
        "1f627": 1,
        "1f628": 1,
        "1f629": 1,
        "1f62a": 1,
        "1f62b": 1,
        "1f62c": 1,
        "1f62d": 1,
        "1f62e": 1,
        "1f62f": 1,
        "1f630": 1,
        "1f631": 1,
        "1f632": 1,
        "1f633": 1,
        "1f634": 1,
        "1f635": 1,
        "1f636": 1,
        "1f637": 1,
        "1f638": 1,
        "1f639": 1,
        "1f63a": 1,
        "1f63b": 1,
        "1f63c": 1,
        "1f63d": 1,
        "1f63e": 1,
        "1f63f": 1,
        "1f640": 1,
        "1f641": 1,
        "1f642": 1,
        "1f643": 1,
        "1f644": 1,
        "1f645_1f3fb_200d_2640": 1,
        "1f645_1f3fb_200d_2642": 1,
        "1f645_1f3fc_200d_2640": 1,
        "1f645_1f3fc_200d_2642": 1,
        "1f645_1f3fd_200d_2640": 1,
        "1f645_1f3fd_200d_2642": 1,
        "1f645_1f3fe_200d_2640": 1,
        "1f645_1f3fe_200d_2642": 1,
        "1f645_1f3ff_200d_2640": 1,
        "1f645_1f3ff_200d_2642": 1,
        "1f645_200d_2640": 1,
        "1f645_200d_2642": 1,
        "1f646_1f3fb_200d_2640": 1,
        "1f646_1f3fb_200d_2642": 1,
        "1f646_1f3fc_200d_2640": 1,
        "1f646_1f3fc_200d_2642": 1,
        "1f646_1f3fd_200d_2640": 1,
        "1f646_1f3fd_200d_2642": 1,
        "1f646_1f3fe_200d_2640": 1,
        "1f646_1f3fe_200d_2642": 1,
        "1f646_1f3ff_200d_2640": 1,
        "1f646_1f3ff_200d_2642": 1,
        "1f646_200d_2640": 1,
        "1f646_200d_2642": 1,
        "1f647_1f3fb_200d_2640": 1,
        "1f647_1f3fb_200d_2642": 1,
        "1f647_1f3fc_200d_2640": 1,
        "1f647_1f3fc_200d_2642": 1,
        "1f647_1f3fd_200d_2640": 1,
        "1f647_1f3fd_200d_2642": 1,
        "1f647_1f3fe_200d_2640": 1,
        "1f647_1f3fe_200d_2642": 1,
        "1f647_1f3ff_200d_2640": 1,
        "1f647_1f3ff_200d_2642": 1,
        "1f647_200d_2640": 1,
        "1f647_200d_2642": 1,
        "1f648": 1,
        "1f649": 1,
        "1f64a": 1,
        "1f64b_1f3fb_200d_2640": 1,
        "1f64b_1f3fb_200d_2642": 1,
        "1f64b_1f3fc_200d_2640": 1,
        "1f64b_1f3fc_200d_2642": 1,
        "1f64b_1f3fd_200d_2640": 1,
        "1f64b_1f3fd_200d_2642": 1,
        "1f64b_1f3fe_200d_2640": 1,
        "1f64b_1f3fe_200d_2642": 1,
        "1f64b_1f3ff_200d_2640": 1,
        "1f64b_1f3ff_200d_2642": 1,
        "1f64b_200d_2640": 1,
        "1f64b_200d_2642": 1,
        "1f64c": 1,
        "1f64c_1f3fb": 1,
        "1f64c_1f3fc": 1,
        "1f64c_1f3fd": 1,
        "1f64c_1f3fe": 1,
        "1f64c_1f3ff": 1,
        "1f64d_1f3fb_200d_2640": 1,
        "1f64d_1f3fb_200d_2642": 1,
        "1f64d_1f3fc_200d_2640": 1,
        "1f64d_1f3fc_200d_2642": 1,
        "1f64d_1f3fd_200d_2640": 1,
        "1f64d_1f3fd_200d_2642": 1,
        "1f64d_1f3fe_200d_2640": 1,
        "1f64d_1f3fe_200d_2642": 1,
        "1f64d_1f3ff_200d_2640": 1,
        "1f64d_1f3ff_200d_2642": 1,
        "1f64d_200d_2640": 1,
        "1f64d_200d_2642": 1,
        "1f64e_1f3fb_200d_2640": 1,
        "1f64e_1f3fb_200d_2642": 1,
        "1f64e_1f3fc_200d_2640": 1,
        "1f64e_1f3fc_200d_2642": 1,
        "1f64e_1f3fd_200d_2640": 1,
        "1f64e_1f3fd_200d_2642": 1,
        "1f64e_1f3fe_200d_2640": 1,
        "1f64e_1f3fe_200d_2642": 1,
        "1f64e_1f3ff_200d_2640": 1,
        "1f64e_1f3ff_200d_2642": 1,
        "1f64e_200d_2640": 1,
        "1f64e_200d_2642": 1,
        "1f64f": 1,
        "1f64f_1f3fb": 1,
        "1f64f_1f3fc": 1,
        "1f64f_1f3fd": 1,
        "1f64f_1f3fe": 1,
        "1f64f_1f3ff": 1,
        "1f680": 1,
        "1f681": 1,
        "1f682": 1,
        "1f683": 1,
        "1f684": 1,
        "1f685": 1,
        "1f686": 1,
        "1f687": 1,
        "1f688": 1,
        "1f689": 1,
        "1f68a": 1,
        "1f68b": 1,
        "1f68c": 1,
        "1f68d": 1,
        "1f68e": 1,
        "1f68f": 1,
        "1f690": 1,
        "1f691": 1,
        "1f692": 1,
        "1f693": 1,
        "1f694": 1,
        "1f695": 1,
        "1f696": 1,
        "1f697": 1,
        "1f698": 1,
        "1f699": 1,
        "1f69a": 1,
        "1f69b": 1,
        "1f69c": 1,
        "1f69d": 1,
        "1f69e": 1,
        "1f69f": 1,
        "1f6a0": 1,
        "1f6a1": 1,
        "1f6a2": 1,
        "1f6a3_1f3fb_200d_2640": 1,
        "1f6a3_1f3fb_200d_2642": 1,
        "1f6a3_1f3fc_200d_2640": 1,
        "1f6a3_1f3fc_200d_2642": 1,
        "1f6a3_1f3fd_200d_2640": 1,
        "1f6a3_1f3fd_200d_2642": 1,
        "1f6a3_1f3fe_200d_2640": 1,
        "1f6a3_1f3fe_200d_2642": 1,
        "1f6a3_1f3ff_200d_2640": 1,
        "1f6a3_1f3ff_200d_2642": 1,
        "1f6a3_200d_2640": 1,
        "1f6a3_200d_2642": 1,
        "1f6a4": 1,
        "1f6a5": 1,
        "1f6a6": 1,
        "1f6a7": 1,
        "1f6a8": 1,
        "1f6a9": 1,
        "1f6aa": 1,
        "1f6ab": 1,
        "1f6ac": 1,
        "1f6ad": 1,
        "1f6ae": 1,
        "1f6af": 1,
        "1f6b0": 1,
        "1f6b1": 1,
        "1f6b2": 1,
        "1f6b3": 1,
        "1f6b4_1f3fb_200d_2640": 1,
        "1f6b4_1f3fb_200d_2642": 1,
        "1f6b4_1f3fc_200d_2640": 1,
        "1f6b4_1f3fc_200d_2642": 1,
        "1f6b4_1f3fd_200d_2640": 1,
        "1f6b4_1f3fd_200d_2642": 1,
        "1f6b4_1f3fe_200d_2640": 1,
        "1f6b4_1f3fe_200d_2642": 1,
        "1f6b4_1f3ff_200d_2640": 1,
        "1f6b4_1f3ff_200d_2642": 1,
        "1f6b4_200d_2640": 1,
        "1f6b4_200d_2642": 1,
        "1f6b5_1f3fb_200d_2640": 1,
        "1f6b5_1f3fb_200d_2642": 1,
        "1f6b5_1f3fc_200d_2640": 1,
        "1f6b5_1f3fc_200d_2642": 1,
        "1f6b5_1f3fd_200d_2640": 1,
        "1f6b5_1f3fd_200d_2642": 1,
        "1f6b5_1f3fe_200d_2640": 1,
        "1f6b5_1f3fe_200d_2642": 1,
        "1f6b5_1f3ff_200d_2640": 1,
        "1f6b5_1f3ff_200d_2642": 1,
        "1f6b5_200d_2640": 1,
        "1f6b5_200d_2642": 1,
        "1f6b6_1f3fb_200d_2640": 1,
        "1f6b6_1f3fb_200d_2642": 1,
        "1f6b6_1f3fc_200d_2640": 1,
        "1f6b6_1f3fc_200d_2642": 1,
        "1f6b6_1f3fd_200d_2640": 1,
        "1f6b6_1f3fd_200d_2642": 1,
        "1f6b6_1f3fe_200d_2640": 1,
        "1f6b6_1f3fe_200d_2642": 1,
        "1f6b6_1f3ff_200d_2640": 1,
        "1f6b6_1f3ff_200d_2642": 1,
        "1f6b6_200d_2640": 1,
        "1f6b6_200d_2642": 1,
        "1f6b7": 1,
        "1f6b8": 1,
        "1f6b9": 1,
        "1f6ba": 1,
        "1f6bb": 1,
        "1f6bc": 1,
        "1f6bd": 1,
        "1f6be": 1,
        "1f6bf": 1,
        "1f6c0": 1,
        "1f6c0_1f3fb": 1,
        "1f6c0_1f3fc": 1,
        "1f6c0_1f3fd": 1,
        "1f6c0_1f3fe": 1,
        "1f6c0_1f3ff": 1,
        "1f6c1": 1,
        "1f6c2": 1,
        "1f6c3": 1,
        "1f6c4": 1,
        "1f6c5": 1,
        "1f6cb": 1,
        "1f6cc": 1,
        "1f6cc_1f3fb": 1,
        "1f6cc_1f3fc": 1,
        "1f6cc_1f3fd": 1,
        "1f6cc_1f3fe": 1,
        "1f6cc_1f3ff": 1,
        "1f6cd": 1,
        "1f6ce": 1,
        "1f6cf": 1,
        "1f6d0": 1,
        "1f6d1": 1,
        "1f6d2": 1,
        "1f6e0": 1,
        "1f6e1": 1,
        "1f6e2": 1,
        "1f6e3": 1,
        "1f6e4": 1,
        "1f6e5": 1,
        "1f6e9": 1,
        "1f6eb": 1,
        "1f6ec": 1,
        "1f6f0": 1,
        "1f6f3": 1,
        "1f6f4": 1,
        "1f6f5": 1,
        "1f6f6": 1,
        "1f6f7": 1,
        "1f6f8": 1,
        "1f910": 1,
        "1f911": 1,
        "1f912": 1,
        "1f913": 1,
        "1f914": 1,
        "1f915": 1,
        "1f916": 1,
        "1f917": 1,
        "1f918": 1,
        "1f918_1f3fb": 1,
        "1f918_1f3fc": 1,
        "1f918_1f3fd": 1,
        "1f918_1f3fe": 1,
        "1f918_1f3ff": 1,
        "1f919": 1,
        "1f919_1f3fb": 1,
        "1f919_1f3fc": 1,
        "1f919_1f3fd": 1,
        "1f919_1f3fe": 1,
        "1f919_1f3ff": 1,
        "1f91a": 1,
        "1f91a_1f3fb": 1,
        "1f91a_1f3fc": 1,
        "1f91a_1f3fd": 1,
        "1f91a_1f3fe": 1,
        "1f91a_1f3ff": 1,
        "1f91b": 1,
        "1f91b_1f3fb": 1,
        "1f91b_1f3fc": 1,
        "1f91b_1f3fd": 1,
        "1f91b_1f3fe": 1,
        "1f91b_1f3ff": 1,
        "1f91c": 1,
        "1f91c_1f3fb": 1,
        "1f91c_1f3fc": 1,
        "1f91c_1f3fd": 1,
        "1f91c_1f3fe": 1,
        "1f91c_1f3ff": 1,
        "1f91d": 1,
        "1f91d_1f3fb": 1,
        "1f91d_1f3fc": 1,
        "1f91d_1f3fd": 1,
        "1f91d_1f3fe": 1,
        "1f91d_1f3ff": 1,
        "1f91e": 1,
        "1f91e_1f3fb": 1,
        "1f91e_1f3fc": 1,
        "1f91e_1f3fd": 1,
        "1f91e_1f3fe": 1,
        "1f91e_1f3ff": 1,
        "1f91f": 1,
        "1f91f_1f3fb": 1,
        "1f91f_1f3fc": 1,
        "1f91f_1f3fd": 1,
        "1f91f_1f3fe": 1,
        "1f91f_1f3ff": 1,
        "1f920": 1,
        "1f921": 1,
        "1f922": 1,
        "1f923": 1,
        "1f924": 1,
        "1f925": 1,
        "1f926_1f3fb_200d_2640": 1,
        "1f926_1f3fb_200d_2642": 1,
        "1f926_1f3fc_200d_2640": 1,
        "1f926_1f3fc_200d_2642": 1,
        "1f926_1f3fd_200d_2640": 1,
        "1f926_1f3fd_200d_2642": 1,
        "1f926_1f3fe_200d_2640": 1,
        "1f926_1f3fe_200d_2642": 1,
        "1f926_1f3ff_200d_2640": 1,
        "1f926_1f3ff_200d_2642": 1,
        "1f926_200d_2640": 1,
        "1f926_200d_2642": 1,
        "1f927": 1,
        "1f928": 1,
        "1f929": 1,
        "1f92a": 1,
        "1f92b": 1,
        "1f92c": 1,
        "1f92d": 1,
        "1f92e": 1,
        "1f92f": 1,
        "1f930": 1,
        "1f930_1f3fb": 1,
        "1f930_1f3fc": 1,
        "1f930_1f3fd": 1,
        "1f930_1f3fe": 1,
        "1f930_1f3ff": 1,
        "1f931": 1,
        "1f931_1f3fb": 1,
        "1f931_1f3fc": 1,
        "1f931_1f3fd": 1,
        "1f931_1f3fe": 1,
        "1f931_1f3ff": 1,
        "1f932": 1,
        "1f932_1f3fb": 1,
        "1f932_1f3fc": 1,
        "1f932_1f3fd": 1,
        "1f932_1f3fe": 1,
        "1f932_1f3ff": 1,
        "1f933": 1,
        "1f933_1f3fb": 1,
        "1f933_1f3fc": 1,
        "1f933_1f3fd": 1,
        "1f933_1f3fe": 1,
        "1f933_1f3ff": 1,
        "1f934": 1,
        "1f934_1f3fb": 1,
        "1f934_1f3fc": 1,
        "1f934_1f3fd": 1,
        "1f934_1f3fe": 1,
        "1f934_1f3ff": 1,
        "1f935": 1,
        "1f935_1f3fb": 1,
        "1f935_1f3fc": 1,
        "1f935_1f3fd": 1,
        "1f935_1f3fe": 1,
        "1f935_1f3ff": 1,
        "1f936": 1,
        "1f936_1f3fb": 1,
        "1f936_1f3fc": 1,
        "1f936_1f3fd": 1,
        "1f936_1f3fe": 1,
        "1f936_1f3ff": 1,
        "1f937_1f3fb_200d_2640": 1,
        "1f937_1f3fb_200d_2642": 1,
        "1f937_1f3fc_200d_2640": 1,
        "1f937_1f3fc_200d_2642": 1,
        "1f937_1f3fd_200d_2640": 1,
        "1f937_1f3fd_200d_2642": 1,
        "1f937_1f3fe_200d_2640": 1,
        "1f937_1f3fe_200d_2642": 1,
        "1f937_1f3ff_200d_2640": 1,
        "1f937_1f3ff_200d_2642": 1,
        "1f937_200d_2640": 1,
        "1f937_200d_2642": 1,
        "1f938_1f3fb_200d_2640": 1,
        "1f938_1f3fb_200d_2642": 1,
        "1f938_1f3fc_200d_2640": 1,
        "1f938_1f3fc_200d_2642": 1,
        "1f938_1f3fd_200d_2640": 1,
        "1f938_1f3fd_200d_2642": 1,
        "1f938_1f3fe_200d_2640": 1,
        "1f938_1f3fe_200d_2642": 1,
        "1f938_1f3ff_200d_2640": 1,
        "1f938_1f3ff_200d_2642": 1,
        "1f938_200d_2640": 1,
        "1f938_200d_2642": 1,
        "1f939": 1,
        "1f939_1f3fb": 1,
        "1f939_1f3fc": 1,
        "1f939_1f3fd": 1,
        "1f939_1f3fe": 1,
        "1f939_1f3ff": 1,
        "1f93a": 1,
        "1f93c_1f3fb_200d_2640": 1,
        "1f93c_1f3fb_200d_2642": 1,
        "1f93c_1f3fc_200d_2640": 1,
        "1f93c_1f3fc_200d_2642": 1,
        "1f93c_1f3fd_200d_2640": 1,
        "1f93c_1f3fd_200d_2642": 1,
        "1f93c_1f3fe_200d_2640": 1,
        "1f93c_1f3fe_200d_2642": 1,
        "1f93c_1f3ff_200d_2640": 1,
        "1f93c_1f3ff_200d_2642": 1,
        "1f93c_200d_2640": 1,
        "1f93c_200d_2642": 1,
        "1f93d_1f3fb_200d_2640": 1,
        "1f93d_1f3fb_200d_2642": 1,
        "1f93d_1f3fc_200d_2640": 1,
        "1f93d_1f3fc_200d_2642": 1,
        "1f93d_1f3fd_200d_2640": 1,
        "1f93d_1f3fd_200d_2642": 1,
        "1f93d_1f3fe_200d_2640": 1,
        "1f93d_1f3fe_200d_2642": 1,
        "1f93d_1f3ff_200d_2640": 1,
        "1f93d_1f3ff_200d_2642": 1,
        "1f93d_200d_2640": 1,
        "1f93d_200d_2642": 1,
        "1f93e_1f3fb_200d_2640": 1,
        "1f93e_1f3fb_200d_2642": 1,
        "1f93e_1f3fc_200d_2640": 1,
        "1f93e_1f3fc_200d_2642": 1,
        "1f93e_1f3fd_200d_2640": 1,
        "1f93e_1f3fd_200d_2642": 1,
        "1f93e_1f3fe_200d_2640": 1,
        "1f93e_1f3fe_200d_2642": 1,
        "1f93e_1f3ff_200d_2640": 1,
        "1f93e_1f3ff_200d_2642": 1,
        "1f93e_200d_2640": 1,
        "1f93e_200d_2642": 1,
        "1f940": 1,
        "1f941": 1,
        "1f942": 1,
        "1f943": 1,
        "1f944": 1,
        "1f945": 1,
        "1f947": 1,
        "1f948": 1,
        "1f949": 1,
        "1f94a": 1,
        "1f94b": 1,
        "1f94c": 1,
        "1f950": 1,
        "1f951": 1,
        "1f952": 1,
        "1f953": 1,
        "1f954": 1,
        "1f955": 1,
        "1f956": 1,
        "1f957": 1,
        "1f958": 1,
        "1f959": 1,
        "1f95a": 1,
        "1f95b": 1,
        "1f95c": 1,
        "1f95d": 1,
        "1f95e": 1,
        "1f95f": 1,
        "1f960": 1,
        "1f961": 1,
        "1f962": 1,
        "1f963": 1,
        "1f964": 1,
        "1f965": 1,
        "1f966": 1,
        "1f967": 1,
        "1f968": 1,
        "1f969": 1,
        "1f96a": 1,
        "1f96b": 1,
        "1f980": 1,
        "1f981": 1,
        "1f982": 1,
        "1f983": 1,
        "1f984": 1,
        "1f985": 1,
        "1f986": 1,
        "1f987": 1,
        "1f988": 1,
        "1f989": 1,
        "1f98a": 1,
        "1f98b": 1,
        "1f98c": 1,
        "1f98d": 1,
        "1f98e": 1,
        "1f98f": 1,
        "1f990": 1,
        "1f991": 1,
        "1f992": 1,
        "1f993": 1,
        "1f994": 1,
        "1f995": 1,
        "1f996": 1,
        "1f997": 1,
        "1f9c0": 1,
        "1f9d0": 1,
        "1f9d1": 1,
        "1f9d1_1f3fb": 1,
        "1f9d1_1f3fc": 1,
        "1f9d1_1f3fd": 1,
        "1f9d1_1f3fe": 1,
        "1f9d1_1f3ff": 1,
        "1f9d2": 1,
        "1f9d2_1f3fb": 1,
        "1f9d2_1f3fc": 1,
        "1f9d2_1f3fd": 1,
        "1f9d2_1f3fe": 1,
        "1f9d2_1f3ff": 1,
        "1f9d3": 1,
        "1f9d3_1f3fb": 1,
        "1f9d3_1f3fc": 1,
        "1f9d3_1f3fd": 1,
        "1f9d3_1f3fe": 1,
        "1f9d3_1f3ff": 1,
        "1f9d4": 1,
        "1f9d4_1f3fb": 1,
        "1f9d4_1f3fc": 1,
        "1f9d4_1f3fd": 1,
        "1f9d4_1f3fe": 1,
        "1f9d4_1f3ff": 1,
        "1f9d5": 1,
        "1f9d5_1f3fb": 1,
        "1f9d5_1f3fc": 1,
        "1f9d5_1f3fd": 1,
        "1f9d5_1f3fe": 1,
        "1f9d5_1f3ff": 1,
        "1f9d6": 1,
        "1f9d6_1f3fb": 1,
        "1f9d6_1f3fb_200d_2640": 1,
        "1f9d6_1f3fb_200d_2642": 1,
        "1f9d6_1f3fc": 1,
        "1f9d6_1f3fc_200d_2640": 1,
        "1f9d6_1f3fc_200d_2642": 1,
        "1f9d6_1f3fd": 1,
        "1f9d6_1f3fd_200d_2640": 1,
        "1f9d6_1f3fd_200d_2642": 1,
        "1f9d6_1f3fe": 1,
        "1f9d6_1f3fe_200d_2640": 1,
        "1f9d6_1f3fe_200d_2642": 1,
        "1f9d6_1f3ff": 1,
        "1f9d6_1f3ff_200d_2640": 1,
        "1f9d6_1f3ff_200d_2642": 1,
        "1f9d6_200d_2640": 1,
        "1f9d6_200d_2642": 1,
        "1f9d7": 1,
        "1f9d7_1f3fb": 1,
        "1f9d7_1f3fb_200d_2640": 1,
        "1f9d7_1f3fb_200d_2642": 1,
        "1f9d7_1f3fc": 1,
        "1f9d7_1f3fc_200d_2640": 1,
        "1f9d7_1f3fc_200d_2642": 1,
        "1f9d7_1f3fd": 1,
        "1f9d7_1f3fd_200d_2640": 1,
        "1f9d7_1f3fd_200d_2642": 1,
        "1f9d7_1f3fe": 1,
        "1f9d7_1f3fe_200d_2640": 1,
        "1f9d7_1f3fe_200d_2642": 1,
        "1f9d7_1f3ff": 1,
        "1f9d7_1f3ff_200d_2640": 1,
        "1f9d7_1f3ff_200d_2642": 1,
        "1f9d7_200d_2640": 1,
        "1f9d7_200d_2642": 1,
        "1f9d8": 1,
        "1f9d8_1f3fb": 1,
        "1f9d8_1f3fb_200d_2640": 1,
        "1f9d8_1f3fb_200d_2642": 1,
        "1f9d8_1f3fc": 1,
        "1f9d8_1f3fc_200d_2640": 1,
        "1f9d8_1f3fc_200d_2642": 1,
        "1f9d8_1f3fd": 1,
        "1f9d8_1f3fd_200d_2640": 1,
        "1f9d8_1f3fd_200d_2642": 1,
        "1f9d8_1f3fe": 1,
        "1f9d8_1f3fe_200d_2640": 1,
        "1f9d8_1f3fe_200d_2642": 1,
        "1f9d8_1f3ff": 1,
        "1f9d8_1f3ff_200d_2640": 1,
        "1f9d8_1f3ff_200d_2642": 1,
        "1f9d8_200d_2640": 1,
        "1f9d8_200d_2642": 1,
        "1f9d9": 1,
        "1f9d9_1f3fb": 1,
        "1f9d9_1f3fb_200d_2640": 1,
        "1f9d9_1f3fb_200d_2642": 1,
        "1f9d9_1f3fc": 1,
        "1f9d9_1f3fc_200d_2640": 1,
        "1f9d9_1f3fc_200d_2642": 1,
        "1f9d9_1f3fd": 1,
        "1f9d9_1f3fd_200d_2640": 1,
        "1f9d9_1f3fd_200d_2642": 1,
        "1f9d9_1f3fe": 1,
        "1f9d9_1f3fe_200d_2640": 1,
        "1f9d9_1f3fe_200d_2642": 1,
        "1f9d9_1f3ff": 1,
        "1f9d9_1f3ff_200d_2640": 1,
        "1f9d9_1f3ff_200d_2642": 1,
        "1f9d9_200d_2640": 1,
        "1f9d9_200d_2642": 1,
        "1f9da": 1,
        "1f9da_200d_2640": 1,
        "1f9da_200d_2642": 1,
        "1f9db": 1,
        "1f9db_200d_2640": 1,
        "1f9db_200d_2642": 1,
        "1f9dc": 1,
        "1f9dc_1f3fb": 1,
        "1f9dc_1f3fb_200d_2640": 1,
        "1f9dc_1f3fb_200d_2642": 1,
        "1f9dc_1f3fc": 1,
        "1f9dc_1f3fc_200d_2640": 1,
        "1f9dc_1f3fc_200d_2642": 1,
        "1f9dc_1f3fd": 1,
        "1f9dc_1f3fd_200d_2640": 1,
        "1f9dc_1f3fd_200d_2642": 1,
        "1f9dc_1f3fe": 1,
        "1f9dc_1f3fe_200d_2640": 1,
        "1f9dc_1f3fe_200d_2642": 1,
        "1f9dc_1f3ff": 1,
        "1f9dc_1f3ff_200d_2640": 1,
        "1f9dc_1f3ff_200d_2642": 1,
        "1f9dc_200d_2640": 1,
        "1f9dc_200d_2642": 1,
        "1f9dd": 1,
        "1f9dd_1f3fb": 1,
        "1f9dd_1f3fb_200d_2640": 1,
        "1f9dd_1f3fb_200d_2642": 1,
        "1f9dd_1f3fc": 1,
        "1f9dd_1f3fc_200d_2640": 1,
        "1f9dd_1f3fc_200d_2642": 1,
        "1f9dd_1f3fd": 1,
        "1f9dd_1f3fd_200d_2640": 1,
        "1f9dd_1f3fd_200d_2642": 1,
        "1f9dd_1f3fe": 1,
        "1f9dd_1f3fe_200d_2640": 1,
        "1f9dd_1f3fe_200d_2642": 1,
        "1f9dd_1f3ff": 1,
        "1f9dd_1f3ff_200d_2640": 1,
        "1f9dd_1f3ff_200d_2642": 1,
        "1f9dd_200d_2640": 1,
        "1f9dd_200d_2642": 1,
        "1f9de": 1,
        "1f9de_200d_2640": 1,
        "1f9de_200d_2642": 1,
        "1f9df": 1,
        "1f9df_200d_2640": 1,
        "1f9df_200d_2642": 1,
        "1f9e0": 1,
        "1f9e1": 1,
        "1f9e2": 1,
        "1f9e3": 1,
        "1f9e4": 1,
        "1f9e5": 1,
        "1f9e6": 1,
        "203c": 1,
        2049: 1,
        2122: 1,
        2139: 1,
        2194: 1,
        2195: 1,
        2196: 1,
        2197: 1,
        2198: 1,
        2199: 1,
        "21a9": 1,
        "21aa": 1,
        "231a": 1,
        "231b": 1,
        2328: 1,
        "23_20e3": 1,
        "23cf": 1,
        "23e9": 1,
        "23ea": 1,
        "23eb": 1,
        "23ec": 1,
        "23ed": 1,
        "23ee": 1,
        "23ef": 1,
        "23f0": 1,
        "23f1": 1,
        "23f2": 1,
        "23f3": 1,
        "23f8": 1,
        "23f9": 1,
        "23fa": 1,
        "24c2": 1,
        "25aa": 1,
        "25ab": 1,
        "25b6": 1,
        "25c0": 1,
        "25fb": 1,
        "25fc": 1,
        "25fd": 1,
        "25fe": 1,
        2600: 1,
        2601: 1,
        2602: 1,
        2603: 1,
        2604: 1,
        "260e": 1,
        2611: 1,
        2614: 1,
        2615: 1,
        2618: 1,
        "261d": 1,
        "261d_1f3fb": 1,
        "261d_1f3fc": 1,
        "261d_1f3fd": 1,
        "261d_1f3fe": 1,
        "261d_1f3ff": 1,
        2620: 1,
        2622: 1,
        2623: 1,
        2626: 1,
        "262a": 1,
        "262e": 1,
        "262f": 1,
        2638: 1,
        2639: 1,
        "263a": 1,
        2640: 1,
        2642: 1,
        2648: 1,
        2649: 1,
        "264a": 1,
        "264b": 1,
        "264c": 1,
        "264d": 1,
        "264e": 1,
        "264f": 1,
        2650: 1,
        2651: 1,
        2652: 1,
        2653: 1,
        2660: 1,
        2663: 1,
        2665: 1,
        2666: 1,
        2668: 1,
        "267b": 1,
        "267f": 1,
        2692: 1,
        2693: 1,
        2694: 1,
        2695: 1,
        2696: 1,
        2697: 1,
        2699: 1,
        "269b": 1,
        "269c": 1,
        "26a0": 1,
        "26a1": 1,
        "26aa": 1,
        "26ab": 1,
        "26b0": 1,
        "26b1": 1,
        "26bd": 1,
        "26be": 1,
        "26c4": 1,
        "26c5": 1,
        "26c8": 1,
        "26ce": 1,
        "26cf": 1,
        "26d1": 1,
        "26d3": 1,
        "26d4": 1,
        "26e9": 1,
        "26ea": 1,
        "26f0": 1,
        "26f1": 1,
        "26f2": 1,
        "26f3": 1,
        "26f4": 1,
        "26f5": 1,
        "26f7": 1,
        "26f8": 1,
        "26f9_1f3fb_200d_2640": 1,
        "26f9_1f3fb_200d_2642": 1,
        "26f9_1f3fc_200d_2640": 1,
        "26f9_1f3fc_200d_2642": 1,
        "26f9_1f3fd_200d_2640": 1,
        "26f9_1f3fd_200d_2642": 1,
        "26f9_1f3fe_200d_2640": 1,
        "26f9_1f3fe_200d_2642": 1,
        "26f9_1f3ff_200d_2640": 1,
        "26f9_1f3ff_200d_2642": 1,
        "26f9_200d_2640": 1,
        "26f9_200d_2642": 1,
        "26fa": 1,
        "26fd": 1,
        2702: 1,
        2705: 1,
        2708: 1,
        2709: 1,
        "270a": 1,
        "270a_1f3fb": 1,
        "270a_1f3fc": 1,
        "270a_1f3fd": 1,
        "270a_1f3fe": 1,
        "270a_1f3ff": 1,
        "270b": 1,
        "270b_1f3fb": 1,
        "270b_1f3fc": 1,
        "270b_1f3fd": 1,
        "270b_1f3fe": 1,
        "270b_1f3ff": 1,
        "270c": 1,
        "270c_1f3fb": 1,
        "270c_1f3fc": 1,
        "270c_1f3fd": 1,
        "270c_1f3fe": 1,
        "270c_1f3ff": 1,
        "270d": 1,
        "270d_1f3fb": 1,
        "270d_1f3fc": 1,
        "270d_1f3fd": 1,
        "270d_1f3fe": 1,
        "270d_1f3ff": 1,
        "270f": 1,
        2712: 1,
        2714: 1,
        2716: 1,
        "271d": 1,
        2721: 1,
        2728: 1,
        2733: 1,
        2734: 1,
        2744: 1,
        2747: 1,
        "274c": 1,
        "274e": 1,
        2753: 1,
        2754: 1,
        2755: 1,
        2757: 1,
        2763: 1,
        2764: 1,
        2795: 1,
        2796: 1,
        2797: 1,
        "27a1": 1,
        "27b0": 1,
        "27bf": 1,
        2934: 1,
        2935: 1,
        "2a_20e3": 1,
        "2b05": 1,
        "2b06": 1,
        "2b07": 1,
        "2b1b": 1,
        "2b1c": 1,
        "2b50": 1,
        "2b55": 1,
        3030: 1,
        "303d": 1,
        "30_20e3": 1,
        "31_20e3": 1,
        3297: 1,
        3299: 1,
        "32_20e3": 1,
        "33_20e3": 1,
        "34_20e3": 1,
        "35_20e3": 1,
        "36_20e3": 1,
        "37_20e3": 1,
        "38_20e3": 1,
        "39_20e3": 1,
        a9: 1,
        ae: 1
    };
    e.exports = a
}), null);
__d("SupportedEmoji3", ["SupportedCommonEmoji"], (function(a, b, c, d, e, f) {
    a = babelHelpers["extends"]({}, b("SupportedCommonEmoji"), {
        "1f3c3": 1,
        "1f3c3_1f3fb": 1,
        "1f3c3_1f3fc": 1,
        "1f3c3_1f3fd": 1,
        "1f3c3_1f3fe": 1,
        "1f3c3_1f3ff": 1,
        "1f3c4": 1,
        "1f3c4_1f3fb": 1,
        "1f3c4_1f3fc": 1,
        "1f3c4_1f3fd": 1,
        "1f3c4_1f3fe": 1,
        "1f3c4_1f3ff": 1,
        "1f3ca": 1,
        "1f3ca_1f3fb": 1,
        "1f3ca_1f3fc": 1,
        "1f3ca_1f3fd": 1,
        "1f3ca_1f3fe": 1,
        "1f3ca_1f3ff": 1,
        "1f3cb": 1,
        "1f3cb_1f3fb": 1,
        "1f3cb_1f3fc": 1,
        "1f3cb_1f3fd": 1,
        "1f3cb_1f3fe": 1,
        "1f3cb_1f3ff": 1,
        "1f3cc": 1,
        "1f3cc_1f3fb": 1,
        "1f3cc_1f3fc": 1,
        "1f3cc_1f3fd": 1,
        "1f3cc_1f3fe": 1,
        "1f3cc_1f3ff": 1,
        "1f3f3_200d_26a7": 1,
        "1f3f4_200d_2620": 1,
        "1f408_200d_2b1b": 1,
        "1f415_200d_1f9ba": 1,
        "1f43b_200d_2744": 1,
        "1f468_1f3fb_200d_1f37c": 1,
        "1f468_1f3fb_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f468_1f3fb_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f468_1f3fb_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f468_1f3fb_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f468_1f3fb_200d_1f9af": 1,
        "1f468_1f3fb_200d_1f9b0": 1,
        "1f468_1f3fb_200d_1f9b1": 1,
        "1f468_1f3fb_200d_1f9b2": 1,
        "1f468_1f3fb_200d_1f9b3": 1,
        "1f468_1f3fb_200d_1f9bc": 1,
        "1f468_1f3fb_200d_1f9bd": 1,
        "1f468_1f3fb_200d_2764_200d_1f3fb_1f468": 1,
        "1f468_1f3fb_200d_2764_200d_1f468_1f3fb": 1,
        "1f468_1f3fb_200d_2764_200d_1f468_1f3fc": 1,
        "1f468_1f3fb_200d_2764_200d_1f468_1f3fd": 1,
        "1f468_1f3fb_200d_2764_200d_1f468_1f3fe": 1,
        "1f468_1f3fb_200d_2764_200d_1f468_1f3ff": 1,
        "1f468_1f3fb_200d_2764_200d_1f48b_200d_1f3fb_1f468": 1,
        "1f468_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f468_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f468_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f468_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f468_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f468_1f3fc_200d_1f37c": 1,
        "1f468_1f3fc_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f468_1f3fc_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f468_1f3fc_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f468_1f3fc_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f468_1f3fc_200d_1f9af": 1,
        "1f468_1f3fc_200d_1f9b0": 1,
        "1f468_1f3fc_200d_1f9b1": 1,
        "1f468_1f3fc_200d_1f9b2": 1,
        "1f468_1f3fc_200d_1f9b3": 1,
        "1f468_1f3fc_200d_1f9bc": 1,
        "1f468_1f3fc_200d_1f9bd": 1,
        "1f468_1f3fc_200d_2764_200d_1f3fc_1f468": 1,
        "1f468_1f3fc_200d_2764_200d_1f468_1f3fb": 1,
        "1f468_1f3fc_200d_2764_200d_1f468_1f3fc": 1,
        "1f468_1f3fc_200d_2764_200d_1f468_1f3fd": 1,
        "1f468_1f3fc_200d_2764_200d_1f468_1f3fe": 1,
        "1f468_1f3fc_200d_2764_200d_1f468_1f3ff": 1,
        "1f468_1f3fc_200d_2764_200d_1f48b_200d_1f3fc_1f468": 1,
        "1f468_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f468_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f468_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f468_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f468_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f468_1f3fd_200d_1f37c": 1,
        "1f468_1f3fd_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f468_1f3fd_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f468_1f3fd_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f468_1f3fd_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f468_1f3fd_200d_1f9af": 1,
        "1f468_1f3fd_200d_1f9b0": 1,
        "1f468_1f3fd_200d_1f9b1": 1,
        "1f468_1f3fd_200d_1f9b2": 1,
        "1f468_1f3fd_200d_1f9b3": 1,
        "1f468_1f3fd_200d_1f9bc": 1,
        "1f468_1f3fd_200d_1f9bd": 1,
        "1f468_1f3fd_200d_2764_200d_1f3fd_1f468": 1,
        "1f468_1f3fd_200d_2764_200d_1f468_1f3fb": 1,
        "1f468_1f3fd_200d_2764_200d_1f468_1f3fc": 1,
        "1f468_1f3fd_200d_2764_200d_1f468_1f3fd": 1,
        "1f468_1f3fd_200d_2764_200d_1f468_1f3fe": 1,
        "1f468_1f3fd_200d_2764_200d_1f468_1f3ff": 1,
        "1f468_1f3fd_200d_2764_200d_1f48b_200d_1f3fd_1f468": 1,
        "1f468_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f468_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f468_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f468_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f468_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f468_1f3fe_200d_1f37c": 1,
        "1f468_1f3fe_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f468_1f3fe_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f468_1f3fe_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f468_1f3fe_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f468_1f3fe_200d_1f9af": 1,
        "1f468_1f3fe_200d_1f9b0": 1,
        "1f468_1f3fe_200d_1f9b1": 1,
        "1f468_1f3fe_200d_1f9b2": 1,
        "1f468_1f3fe_200d_1f9b3": 1,
        "1f468_1f3fe_200d_1f9bc": 1,
        "1f468_1f3fe_200d_1f9bd": 1,
        "1f468_1f3fe_200d_2764_200d_1f3fe_1f468": 1,
        "1f468_1f3fe_200d_2764_200d_1f468_1f3fb": 1,
        "1f468_1f3fe_200d_2764_200d_1f468_1f3fc": 1,
        "1f468_1f3fe_200d_2764_200d_1f468_1f3fd": 1,
        "1f468_1f3fe_200d_2764_200d_1f468_1f3fe": 1,
        "1f468_1f3fe_200d_2764_200d_1f468_1f3ff": 1,
        "1f468_1f3fe_200d_2764_200d_1f48b_200d_1f3fe_1f468": 1,
        "1f468_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f468_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f468_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f468_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f468_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f468_1f3ff_200d_1f37c": 1,
        "1f468_1f3ff_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f468_1f3ff_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f468_1f3ff_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f468_1f3ff_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f468_1f3ff_200d_1f9af": 1,
        "1f468_1f3ff_200d_1f9b0": 1,
        "1f468_1f3ff_200d_1f9b1": 1,
        "1f468_1f3ff_200d_1f9b2": 1,
        "1f468_1f3ff_200d_1f9b3": 1,
        "1f468_1f3ff_200d_1f9bc": 1,
        "1f468_1f3ff_200d_1f9bd": 1,
        "1f468_1f3ff_200d_2764_200d_1f3ff_1f468": 1,
        "1f468_1f3ff_200d_2764_200d_1f468_1f3fb": 1,
        "1f468_1f3ff_200d_2764_200d_1f468_1f3fc": 1,
        "1f468_1f3ff_200d_2764_200d_1f468_1f3fd": 1,
        "1f468_1f3ff_200d_2764_200d_1f468_1f3fe": 1,
        "1f468_1f3ff_200d_2764_200d_1f468_1f3ff": 1,
        "1f468_1f3ff_200d_2764_200d_1f48b_200d_1f3ff_1f468": 1,
        "1f468_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f468_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f468_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f468_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f468_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f468_200d_1f37c": 1,
        "1f468_200d_1f9af": 1,
        "1f468_200d_1f9b0": 1,
        "1f468_200d_1f9b1": 1,
        "1f468_200d_1f9b2": 1,
        "1f468_200d_1f9b3": 1,
        "1f468_200d_1f9bc": 1,
        "1f468_200d_1f9bd": 1,
        "1f469_1f3fb_200d_1f37c": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f469_1f3fc": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f469_1f3fd": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f469_1f3fe": 1,
        "1f469_1f3fb_200d_1f91d_200d_1f469_1f3ff": 1,
        "1f469_1f3fb_200d_1f9af": 1,
        "1f469_1f3fb_200d_1f9b0": 1,
        "1f469_1f3fb_200d_1f9b1": 1,
        "1f469_1f3fb_200d_1f9b2": 1,
        "1f469_1f3fb_200d_1f9b3": 1,
        "1f469_1f3fb_200d_1f9bc": 1,
        "1f469_1f3fb_200d_1f9bd": 1,
        "1f469_1f3fb_200d_2764_200d_1f3fb_1f468": 1,
        "1f469_1f3fb_200d_2764_200d_1f3fb_1f469": 1,
        "1f469_1f3fb_200d_2764_200d_1f468_1f3fb": 1,
        "1f469_1f3fb_200d_2764_200d_1f468_1f3fc": 1,
        "1f469_1f3fb_200d_2764_200d_1f468_1f3fd": 1,
        "1f469_1f3fb_200d_2764_200d_1f468_1f3fe": 1,
        "1f469_1f3fb_200d_2764_200d_1f468_1f3ff": 1,
        "1f469_1f3fb_200d_2764_200d_1f469_1f3fb": 1,
        "1f469_1f3fb_200d_2764_200d_1f469_1f3fc": 1,
        "1f469_1f3fb_200d_2764_200d_1f469_1f3fd": 1,
        "1f469_1f3fb_200d_2764_200d_1f469_1f3fe": 1,
        "1f469_1f3fb_200d_2764_200d_1f469_1f3ff": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f3fb_1f468": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f3fb_1f469": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f469_1f3fb": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f469_1f3fc": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f469_1f3fd": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f469_1f3fe": 1,
        "1f469_1f3fb_200d_2764_200d_1f48b_200d_1f469_1f3ff": 1,
        "1f469_1f3fc_200d_1f37c": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f469_1f3fb": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f469_1f3fd": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f469_1f3fe": 1,
        "1f469_1f3fc_200d_1f91d_200d_1f469_1f3ff": 1,
        "1f469_1f3fc_200d_1f9af": 1,
        "1f469_1f3fc_200d_1f9b0": 1,
        "1f469_1f3fc_200d_1f9b1": 1,
        "1f469_1f3fc_200d_1f9b2": 1,
        "1f469_1f3fc_200d_1f9b3": 1,
        "1f469_1f3fc_200d_1f9bc": 1,
        "1f469_1f3fc_200d_1f9bd": 1,
        "1f469_1f3fc_200d_2764_200d_1f3fc_1f468": 1,
        "1f469_1f3fc_200d_2764_200d_1f3fc_1f469": 1,
        "1f469_1f3fc_200d_2764_200d_1f468_1f3fb": 1,
        "1f469_1f3fc_200d_2764_200d_1f468_1f3fc": 1,
        "1f469_1f3fc_200d_2764_200d_1f468_1f3fd": 1,
        "1f469_1f3fc_200d_2764_200d_1f468_1f3fe": 1,
        "1f469_1f3fc_200d_2764_200d_1f468_1f3ff": 1,
        "1f469_1f3fc_200d_2764_200d_1f469_1f3fb": 1,
        "1f469_1f3fc_200d_2764_200d_1f469_1f3fc": 1,
        "1f469_1f3fc_200d_2764_200d_1f469_1f3fd": 1,
        "1f469_1f3fc_200d_2764_200d_1f469_1f3fe": 1,
        "1f469_1f3fc_200d_2764_200d_1f469_1f3ff": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f3fc_1f468": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f3fc_1f469": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f469_1f3fb": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f469_1f3fc": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f469_1f3fd": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f469_1f3fe": 1,
        "1f469_1f3fc_200d_2764_200d_1f48b_200d_1f469_1f3ff": 1,
        "1f469_1f3fd_200d_1f37c": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f469_1f3fb": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f469_1f3fc": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f469_1f3fe": 1,
        "1f469_1f3fd_200d_1f91d_200d_1f469_1f3ff": 1,
        "1f469_1f3fd_200d_1f9af": 1,
        "1f469_1f3fd_200d_1f9b0": 1,
        "1f469_1f3fd_200d_1f9b1": 1,
        "1f469_1f3fd_200d_1f9b2": 1,
        "1f469_1f3fd_200d_1f9b3": 1,
        "1f469_1f3fd_200d_1f9bc": 1,
        "1f469_1f3fd_200d_1f9bd": 1,
        "1f469_1f3fd_200d_2764_200d_1f3fd_1f468": 1,
        "1f469_1f3fd_200d_2764_200d_1f3fd_1f469": 1,
        "1f469_1f3fd_200d_2764_200d_1f468_1f3fb": 1,
        "1f469_1f3fd_200d_2764_200d_1f468_1f3fc": 1,
        "1f469_1f3fd_200d_2764_200d_1f468_1f3fd": 1,
        "1f469_1f3fd_200d_2764_200d_1f468_1f3fe": 1,
        "1f469_1f3fd_200d_2764_200d_1f468_1f3ff": 1,
        "1f469_1f3fd_200d_2764_200d_1f469_1f3fb": 1,
        "1f469_1f3fd_200d_2764_200d_1f469_1f3fc": 1,
        "1f469_1f3fd_200d_2764_200d_1f469_1f3fd": 1,
        "1f469_1f3fd_200d_2764_200d_1f469_1f3fe": 1,
        "1f469_1f3fd_200d_2764_200d_1f469_1f3ff": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f3fd_1f468": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f3fd_1f469": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f469_1f3fb": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f469_1f3fc": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f469_1f3fd": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f469_1f3fe": 1,
        "1f469_1f3fd_200d_2764_200d_1f48b_200d_1f469_1f3ff": 1,
        "1f469_1f3fe_200d_1f37c": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f468_1f3ff": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f469_1f3fb": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f469_1f3fc": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f469_1f3fd": 1,
        "1f469_1f3fe_200d_1f91d_200d_1f469_1f3ff": 1,
        "1f469_1f3fe_200d_1f9af": 1,
        "1f469_1f3fe_200d_1f9b0": 1,
        "1f469_1f3fe_200d_1f9b1": 1,
        "1f469_1f3fe_200d_1f9b2": 1,
        "1f469_1f3fe_200d_1f9b3": 1,
        "1f469_1f3fe_200d_1f9bc": 1,
        "1f469_1f3fe_200d_1f9bd": 1,
        "1f469_1f3fe_200d_2764_200d_1f3fe_1f468": 1,
        "1f469_1f3fe_200d_2764_200d_1f3fe_1f469": 1,
        "1f469_1f3fe_200d_2764_200d_1f468_1f3fb": 1,
        "1f469_1f3fe_200d_2764_200d_1f468_1f3fc": 1,
        "1f469_1f3fe_200d_2764_200d_1f468_1f3fd": 1,
        "1f469_1f3fe_200d_2764_200d_1f468_1f3fe": 1,
        "1f469_1f3fe_200d_2764_200d_1f468_1f3ff": 1,
        "1f469_1f3fe_200d_2764_200d_1f469_1f3fb": 1,
        "1f469_1f3fe_200d_2764_200d_1f469_1f3fc": 1,
        "1f469_1f3fe_200d_2764_200d_1f469_1f3fd": 1,
        "1f469_1f3fe_200d_2764_200d_1f469_1f3fe": 1,
        "1f469_1f3fe_200d_2764_200d_1f469_1f3ff": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f3fe_1f468": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f3fe_1f469": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f469_1f3fb": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f469_1f3fc": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f469_1f3fd": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f469_1f3fe": 1,
        "1f469_1f3fe_200d_2764_200d_1f48b_200d_1f469_1f3ff": 1,
        "1f469_1f3ff_200d_1f37c": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f468_1f3fb": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f468_1f3fc": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f468_1f3fd": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f468_1f3fe": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f469_1f3fb": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f469_1f3fc": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f469_1f3fd": 1,
        "1f469_1f3ff_200d_1f91d_200d_1f469_1f3fe": 1,
        "1f469_1f3ff_200d_1f9af": 1,
        "1f469_1f3ff_200d_1f9b0": 1,
        "1f469_1f3ff_200d_1f9b1": 1,
        "1f469_1f3ff_200d_1f9b2": 1,
        "1f469_1f3ff_200d_1f9b3": 1,
        "1f469_1f3ff_200d_1f9bc": 1,
        "1f469_1f3ff_200d_1f9bd": 1,
        "1f469_1f3ff_200d_2764_200d_1f3ff_1f468": 1,
        "1f469_1f3ff_200d_2764_200d_1f3ff_1f469": 1,
        "1f469_1f3ff_200d_2764_200d_1f468_1f3fb": 1,
        "1f469_1f3ff_200d_2764_200d_1f468_1f3fc": 1,
        "1f469_1f3ff_200d_2764_200d_1f468_1f3fd": 1,
        "1f469_1f3ff_200d_2764_200d_1f468_1f3fe": 1,
        "1f469_1f3ff_200d_2764_200d_1f468_1f3ff": 1,
        "1f469_1f3ff_200d_2764_200d_1f469_1f3fb": 1,
        "1f469_1f3ff_200d_2764_200d_1f469_1f3fc": 1,
        "1f469_1f3ff_200d_2764_200d_1f469_1f3fd": 1,
        "1f469_1f3ff_200d_2764_200d_1f469_1f3fe": 1,
        "1f469_1f3ff_200d_2764_200d_1f469_1f3ff": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f3ff_1f468": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f3ff_1f469": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fb": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fc": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fd": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3fe": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f468_1f3ff": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f469_1f3fb": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f469_1f3fc": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f469_1f3fd": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f469_1f3fe": 1,
        "1f469_1f3ff_200d_2764_200d_1f48b_200d_1f469_1f3ff": 1,
        "1f469_200d_1f37c": 1,
        "1f469_200d_1f9af": 1,
        "1f469_200d_1f9b0": 1,
        "1f469_200d_1f9b1": 1,
        "1f469_200d_1f9b2": 1,
        "1f469_200d_1f9b3": 1,
        "1f469_200d_1f9bc": 1,
        "1f469_200d_1f9bd": 1,
        "1f46a": 1,
        "1f46e": 1,
        "1f46e_1f3fb": 1,
        "1f46e_1f3fc": 1,
        "1f46e_1f3fd": 1,
        "1f46e_1f3fe": 1,
        "1f46e_1f3ff": 1,
        "1f46f": 1,
        "1f46f_1f3fb": 1,
        "1f46f_1f3fc": 1,
        "1f46f_1f3fd": 1,
        "1f46f_1f3fe": 1,
        "1f46f_1f3ff": 1,
        "1f470_1f3fb_200d_2640": 1,
        "1f470_1f3fb_200d_2642": 1,
        "1f470_1f3fc_200d_2640": 1,
        "1f470_1f3fc_200d_2642": 1,
        "1f470_1f3fd_200d_2640": 1,
        "1f470_1f3fd_200d_2642": 1,
        "1f470_1f3fe_200d_2640": 1,
        "1f470_1f3fe_200d_2642": 1,
        "1f470_1f3ff_200d_2640": 1,
        "1f470_1f3ff_200d_2642": 1,
        "1f470_200d_2640": 1,
        "1f470_200d_2642": 1,
        "1f471": 1,
        "1f471_1f3fb": 1,
        "1f471_1f3fc": 1,
        "1f471_1f3fd": 1,
        "1f471_1f3fe": 1,
        "1f471_1f3ff": 1,
        "1f473": 1,
        "1f473_1f3fb": 1,
        "1f473_1f3fc": 1,
        "1f473_1f3fd": 1,
        "1f473_1f3fe": 1,
        "1f473_1f3ff": 1,
        "1f477": 1,
        "1f477_1f3fb": 1,
        "1f477_1f3fc": 1,
        "1f477_1f3fd": 1,
        "1f477_1f3fe": 1,
        "1f477_1f3ff": 1,
        "1f481": 1,
        "1f481_1f3fb": 1,
        "1f481_1f3fc": 1,
        "1f481_1f3fd": 1,
        "1f481_1f3fe": 1,
        "1f481_1f3ff": 1,
        "1f482": 1,
        "1f482_1f3fb": 1,
        "1f482_1f3fc": 1,
        "1f482_1f3fd": 1,
        "1f482_1f3fe": 1,
        "1f482_1f3ff": 1,
        "1f486": 1,
        "1f486_1f3fb": 1,
        "1f486_1f3fc": 1,
        "1f486_1f3fd": 1,
        "1f486_1f3fe": 1,
        "1f486_1f3ff": 1,
        "1f487": 1,
        "1f487_1f3fb": 1,
        "1f487_1f3fc": 1,
        "1f487_1f3fd": 1,
        "1f487_1f3fe": 1,
        "1f487_1f3ff": 1,
        "1f48f": 1,
        "1f48f_1f3fb": 1,
        "1f48f_1f3fc": 1,
        "1f48f_1f3fd": 1,
        "1f48f_1f3fe": 1,
        "1f48f_1f3ff": 1,
        "1f491": 1,
        "1f491_1f3fb": 1,
        "1f491_1f3fc": 1,
        "1f491_1f3fd": 1,
        "1f491_1f3fe": 1,
        "1f491_1f3ff": 1,
        "1f574_1f3fb_200d_2642": 1,
        "1f574_1f3fc_200d_2642": 1,
        "1f574_1f3fd_200d_2642": 1,
        "1f574_1f3fe_200d_2642": 1,
        "1f574_1f3ff_200d_2642": 1,
        "1f574_200d_2642": 1,
        "1f575": 1,
        "1f575_1f3fb": 1,
        "1f575_1f3fc": 1,
        "1f575_1f3fd": 1,
        "1f575_1f3fe": 1,
        "1f575_1f3ff": 1,
        "1f62e_200d_1f4a8": 1,
        "1f635_200d_1f4ab": 1,
        "1f636_200d_1f32b": 1,
        "1f645": 1,
        "1f645_1f3fb": 1,
        "1f645_1f3fc": 1,
        "1f645_1f3fd": 1,
        "1f645_1f3fe": 1,
        "1f645_1f3ff": 1,
        "1f646": 1,
        "1f646_1f3fb": 1,
        "1f646_1f3fc": 1,
        "1f646_1f3fd": 1,
        "1f646_1f3fe": 1,
        "1f646_1f3ff": 1,
        "1f647": 1,
        "1f647_1f3fb": 1,
        "1f647_1f3fc": 1,
        "1f647_1f3fd": 1,
        "1f647_1f3fe": 1,
        "1f647_1f3ff": 1,
        "1f64b": 1,
        "1f64b_1f3fb": 1,
        "1f64b_1f3fc": 1,
        "1f64b_1f3fd": 1,
        "1f64b_1f3fe": 1,
        "1f64b_1f3ff": 1,
        "1f64d": 1,
        "1f64d_1f3fb": 1,
        "1f64d_1f3fc": 1,
        "1f64d_1f3fd": 1,
        "1f64d_1f3fe": 1,
        "1f64d_1f3ff": 1,
        "1f64e": 1,
        "1f64e_1f3fb": 1,
        "1f64e_1f3fc": 1,
        "1f64e_1f3fd": 1,
        "1f64e_1f3fe": 1,
        "1f64e_1f3ff": 1,
        "1f6a3": 1,
        "1f6a3_1f3fb": 1,
        "1f6a3_1f3fc": 1,
        "1f6a3_1f3fd": 1,
        "1f6a3_1f3fe": 1,
        "1f6a3_1f3ff": 1,
        "1f6b4": 1,
        "1f6b4_1f3fb": 1,
        "1f6b4_1f3fc": 1,
        "1f6b4_1f3fd": 1,
        "1f6b4_1f3fe": 1,
        "1f6b4_1f3ff": 1,
        "1f6b5": 1,
        "1f6b5_1f3fb": 1,
        "1f6b5_1f3fc": 1,
        "1f6b5_1f3fd": 1,
        "1f6b5_1f3fe": 1,
        "1f6b5_1f3ff": 1,
        "1f6b6": 1,
        "1f6b6_1f3fb": 1,
        "1f6b6_1f3fc": 1,
        "1f6b6_1f3fd": 1,
        "1f6b6_1f3fe": 1,
        "1f6b6_1f3ff": 1,
        "1f6d5": 1,
        "1f6d6": 1,
        "1f6d7": 1,
        "1f6dd": 1,
        "1f6de": 1,
        "1f6df": 1,
        "1f6f9": 1,
        "1f6fa": 1,
        "1f6fb": 1,
        "1f6fc": 1,
        "1f7e0": 1,
        "1f7e1": 1,
        "1f7e2": 1,
        "1f7e3": 1,
        "1f7e4": 1,
        "1f7e5": 1,
        "1f7e6": 1,
        "1f7e7": 1,
        "1f7e8": 1,
        "1f7e9": 1,
        "1f7ea": 1,
        "1f7eb": 1,
        "1f7f0": 1,
        "1f90c": 1,
        "1f90c_1f3fb": 1,
        "1f90c_1f3fc": 1,
        "1f90c_1f3fd": 1,
        "1f90c_1f3fe": 1,
        "1f90c_1f3ff": 1,
        "1f90d": 1,
        "1f90e": 1,
        "1f90f": 1,
        "1f90f_1f3fb": 1,
        "1f90f_1f3fc": 1,
        "1f90f_1f3fd": 1,
        "1f90f_1f3fe": 1,
        "1f90f_1f3ff": 1,
        "1f926": 1,
        "1f926_1f3fb": 1,
        "1f926_1f3fc": 1,
        "1f926_1f3fd": 1,
        "1f926_1f3fe": 1,
        "1f926_1f3ff": 1,
        "1f935_1f3fb_200d_2640": 1,
        "1f935_1f3fb_200d_2642": 1,
        "1f935_1f3fc_200d_2640": 1,
        "1f935_1f3fc_200d_2642": 1,
        "1f935_1f3fd_200d_2640": 1,
        "1f935_1f3fd_200d_2642": 1,
        "1f935_1f3fe_200d_2640": 1,
        "1f935_1f3fe_200d_2642": 1,
        "1f935_1f3ff_200d_2640": 1,
        "1f935_1f3ff_200d_2642": 1,
        "1f935_200d_2640": 1,
        "1f935_200d_2642": 1,
        "1f937": 1,
        "1f937_1f3fb": 1,
        "1f937_1f3fc": 1,
        "1f937_1f3fd": 1,
        "1f937_1f3fe": 1,
        "1f937_1f3ff": 1,
        "1f938": 1,
        "1f938_1f3fb": 1,
        "1f938_1f3fc": 1,
        "1f938_1f3fd": 1,
        "1f938_1f3fe": 1,
        "1f938_1f3ff": 1,
        "1f939_1f3fb_200d_2640": 1,
        "1f939_1f3fb_200d_2642": 1,
        "1f939_1f3fc_200d_2640": 1,
        "1f939_1f3fc_200d_2642": 1,
        "1f939_1f3fd_200d_2640": 1,
        "1f939_1f3fd_200d_2642": 1,
        "1f939_1f3fe_200d_2640": 1,
        "1f939_1f3fe_200d_2642": 1,
        "1f939_1f3ff_200d_2640": 1,
        "1f939_1f3ff_200d_2642": 1,
        "1f939_200d_2640": 1,
        "1f939_200d_2642": 1,
        "1f93c": 1,
        "1f93c_1f3fb": 1,
        "1f93c_1f3fc": 1,
        "1f93c_1f3fd": 1,
        "1f93c_1f3fe": 1,
        "1f93c_1f3ff": 1,
        "1f93d": 1,
        "1f93d_1f3fb": 1,
        "1f93d_1f3fc": 1,
        "1f93d_1f3fd": 1,
        "1f93d_1f3fe": 1,
        "1f93d_1f3ff": 1,
        "1f93e": 1,
        "1f93e_1f3fb": 1,
        "1f93e_1f3fc": 1,
        "1f93e_1f3fd": 1,
        "1f93e_1f3fe": 1,
        "1f93e_1f3ff": 1,
        "1f93f": 1,
        "1f94d": 1,
        "1f94e": 1,
        "1f94f": 1,
        "1f96c": 1,
        "1f96d": 1,
        "1f96e": 1,
        "1f96f": 1,
        "1f970": 1,
        "1f971": 1,
        "1f972": 1,
        "1f973": 1,
        "1f974": 1,
        "1f975": 1,
        "1f976": 1,
        "1f977": 1,
        "1f977_1f3fb": 1,
        "1f977_1f3fc": 1,
        "1f977_1f3fd": 1,
        "1f977_1f3fe": 1,
        "1f977_1f3ff": 1,
        "1f978": 1,
        "1f979": 1,
        "1f97a": 1,
        "1f97b": 1,
        "1f97c": 1,
        "1f97d": 1,
        "1f97e": 1,
        "1f97f": 1,
        "1f998": 1,
        "1f999": 1,
        "1f99a": 1,
        "1f99b": 1,
        "1f99c": 1,
        "1f99d": 1,
        "1f99e": 1,
        "1f99f": 1,
        "1f9a0": 1,
        "1f9a1": 1,
        "1f9a2": 1,
        "1f9a3": 1,
        "1f9a4": 1,
        "1f9a5": 1,
        "1f9a6": 1,
        "1f9a7": 1,
        "1f9a8": 1,
        "1f9a9": 1,
        "1f9aa": 1,
        "1f9ab": 1,
        "1f9ac": 1,
        "1f9ad": 1,
        "1f9ae": 1,
        "1f9af": 1,
        "1f9b0": 1,
        "1f9b1": 1,
        "1f9b2": 1,
        "1f9b3": 1,
        "1f9b4": 1,
        "1f9b5": 1,
        "1f9b5_1f3fb": 1,
        "1f9b5_1f3fc": 1,
        "1f9b5_1f3fd": 1,
        "1f9b5_1f3fe": 1,
        "1f9b5_1f3ff": 1,
        "1f9b6": 1,
        "1f9b6_1f3fb": 1,
        "1f9b6_1f3fc": 1,
        "1f9b6_1f3fd": 1,
        "1f9b6_1f3fe": 1,
        "1f9b6_1f3ff": 1,
        "1f9b7": 1,
        "1f9b8": 1,
        "1f9b8_1f3fb": 1,
        "1f9b8_1f3fb_200d_2640": 1,
        "1f9b8_1f3fb_200d_2642": 1,
        "1f9b8_1f3fc": 1,
        "1f9b8_1f3fc_200d_2640": 1,
        "1f9b8_1f3fc_200d_2642": 1,
        "1f9b8_1f3fd": 1,
        "1f9b8_1f3fd_200d_2640": 1,
        "1f9b8_1f3fd_200d_2642": 1,
        "1f9b8_1f3fe": 1,
        "1f9b8_1f3fe_200d_2640": 1,
        "1f9b8_1f3fe_200d_2642": 1,
        "1f9b8_1f3ff": 1,
        "1f9b8_1f3ff_200d_2640": 1,
        "1f9b8_1f3ff_200d_2642": 1,
        "1f9b8_200d_2640": 1,
        "1f9b8_200d_2642": 1,
        "1f9b9": 1,
        "1f9b9_1f3fb": 1,
        "1f9b9_1f3fb_200d_2640": 1,
        "1f9b9_1f3fb_200d_2642": 1,
        "1f9b9_1f3fc": 1,
        "1f9b9_1f3fc_200d_2640": 1,
        "1f9b9_1f3fc_200d_2642": 1,
        "1f9b9_1f3fd": 1,
        "1f9b9_1f3fd_200d_2640": 1,
        "1f9b9_1f3fd_200d_2642": 1,
        "1f9b9_1f3fe": 1,
        "1f9b9_1f3fe_200d_2640": 1,
        "1f9b9_1f3fe_200d_2642": 1,
        "1f9b9_1f3ff": 1,
        "1f9b9_1f3ff_200d_2640": 1,
        "1f9b9_1f3ff_200d_2642": 1,
        "1f9b9_200d_2640": 1,
        "1f9b9_200d_2642": 1,
        "1f9ba": 1,
        "1f9bb": 1,
        "1f9bb_1f3fb": 1,
        "1f9bb_1f3fc": 1,
        "1f9bb_1f3fd": 1,
        "1f9bb_1f3fe": 1,
        "1f9bb_1f3ff": 1,
        "1f9bc": 1,
        "1f9bd": 1,
        "1f9be": 1,
        "1f9bf": 1,
        "1f9c1": 1,
        "1f9c2": 1,
        "1f9c3": 1,
        "1f9c4": 1,
        "1f9c5": 1,
        "1f9c6": 1,
        "1f9c7": 1,
        "1f9c8": 1,
        "1f9c9": 1,
        "1f9ca": 1,
        "1f9cb": 1,
        "1f9cc": 1,
        "1f9cd": 1,
        "1f9cd_1f3fb": 1,
        "1f9cd_1f3fb_200d_2640": 1,
        "1f9cd_1f3fb_200d_2642": 1,
        "1f9cd_1f3fc": 1,
        "1f9cd_1f3fc_200d_2640": 1,
        "1f9cd_1f3fc_200d_2642": 1,
        "1f9cd_1f3fd": 1,
        "1f9cd_1f3fd_200d_2640": 1,
        "1f9cd_1f3fd_200d_2642": 1,
        "1f9cd_1f3fe": 1,
        "1f9cd_1f3fe_200d_2640": 1,
        "1f9cd_1f3fe_200d_2642": 1,
        "1f9cd_1f3ff": 1,
        "1f9cd_1f3ff_200d_2640": 1,
        "1f9cd_1f3ff_200d_2642": 1,
        "1f9cd_200d_2640": 1,
        "1f9cd_200d_2642": 1,
        "1f9ce": 1,
        "1f9ce_1f3fb": 1,
        "1f9ce_1f3fb_200d_2640": 1,
        "1f9ce_1f3fb_200d_2642": 1,
        "1f9ce_1f3fc": 1,
        "1f9ce_1f3fc_200d_2640": 1,
        "1f9ce_1f3fc_200d_2642": 1,
        "1f9ce_1f3fd": 1,
        "1f9ce_1f3fd_200d_2640": 1,
        "1f9ce_1f3fd_200d_2642": 1,
        "1f9ce_1f3fe": 1,
        "1f9ce_1f3fe_200d_2640": 1,
        "1f9ce_1f3fe_200d_2642": 1,
        "1f9ce_1f3ff": 1,
        "1f9ce_1f3ff_200d_2640": 1,
        "1f9ce_1f3ff_200d_2642": 1,
        "1f9ce_200d_2640": 1,
        "1f9ce_200d_2642": 1,
        "1f9cf": 1,
        "1f9cf_1f3fb": 1,
        "1f9cf_1f3fb_200d_2640": 1,
        "1f9cf_1f3fb_200d_2642": 1,
        "1f9cf_1f3fc": 1,
        "1f9cf_1f3fc_200d_2640": 1,
        "1f9cf_1f3fc_200d_2642": 1,
        "1f9cf_1f3fd": 1,
        "1f9cf_1f3fd_200d_2640": 1,
        "1f9cf_1f3fd_200d_2642": 1,
        "1f9cf_1f3fe": 1,
        "1f9cf_1f3fe_200d_2640": 1,
        "1f9cf_1f3fe_200d_2642": 1,
        "1f9cf_1f3ff": 1,
        "1f9cf_1f3ff_200d_2640": 1,
        "1f9cf_1f3ff_200d_2642": 1,
        "1f9cf_200d_2640": 1,
        "1f9cf_200d_2642": 1,
        "1f9d1_1f3fb_200d_1f33e": 1,
        "1f9d1_1f3fb_200d_1f373": 1,
        "1f9d1_1f3fb_200d_1f37c": 1,
        "1f9d1_1f3fb_200d_1f384": 1,
        "1f9d1_1f3fb_200d_1f393": 1,
        "1f9d1_1f3fb_200d_1f3a4": 1,
        "1f9d1_1f3fb_200d_1f3a8": 1,
        "1f9d1_1f3fb_200d_1f3eb": 1,
        "1f9d1_1f3fb_200d_1f3ed": 1,
        "1f9d1_1f3fb_200d_1f4bb": 1,
        "1f9d1_1f3fb_200d_1f4bc": 1,
        "1f9d1_1f3fb_200d_1f527": 1,
        "1f9d1_1f3fb_200d_1f52c": 1,
        "1f9d1_1f3fb_200d_1f680": 1,
        "1f9d1_1f3fb_200d_1f692": 1,
        "1f9d1_1f3fb_200d_1f91d_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fb_200d_1f91d_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fb_200d_1f91d_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fb_200d_1f91d_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fb_200d_1f91d_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fb_200d_1f9af": 1,
        "1f9d1_1f3fb_200d_1f9b0": 1,
        "1f9d1_1f3fb_200d_1f9b1": 1,
        "1f9d1_1f3fb_200d_1f9b2": 1,
        "1f9d1_1f3fb_200d_1f9b3": 1,
        "1f9d1_1f3fb_200d_1f9bc": 1,
        "1f9d1_1f3fb_200d_1f9bd": 1,
        "1f9d1_1f3fb_200d_2695": 1,
        "1f9d1_1f3fb_200d_2696": 1,
        "1f9d1_1f3fb_200d_2708": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f48b_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f48b_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f48b_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f48b_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fb_200d_2764_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fc_200d_1f33e": 1,
        "1f9d1_1f3fc_200d_1f373": 1,
        "1f9d1_1f3fc_200d_1f37c": 1,
        "1f9d1_1f3fc_200d_1f384": 1,
        "1f9d1_1f3fc_200d_1f393": 1,
        "1f9d1_1f3fc_200d_1f3a4": 1,
        "1f9d1_1f3fc_200d_1f3a8": 1,
        "1f9d1_1f3fc_200d_1f3eb": 1,
        "1f9d1_1f3fc_200d_1f3ed": 1,
        "1f9d1_1f3fc_200d_1f4bb": 1,
        "1f9d1_1f3fc_200d_1f4bc": 1,
        "1f9d1_1f3fc_200d_1f527": 1,
        "1f9d1_1f3fc_200d_1f52c": 1,
        "1f9d1_1f3fc_200d_1f680": 1,
        "1f9d1_1f3fc_200d_1f692": 1,
        "1f9d1_1f3fc_200d_1f91d_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fc_200d_1f91d_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fc_200d_1f91d_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fc_200d_1f91d_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fc_200d_1f91d_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fc_200d_1f9af": 1,
        "1f9d1_1f3fc_200d_1f9b0": 1,
        "1f9d1_1f3fc_200d_1f9b1": 1,
        "1f9d1_1f3fc_200d_1f9b2": 1,
        "1f9d1_1f3fc_200d_1f9b3": 1,
        "1f9d1_1f3fc_200d_1f9bc": 1,
        "1f9d1_1f3fc_200d_1f9bd": 1,
        "1f9d1_1f3fc_200d_2695": 1,
        "1f9d1_1f3fc_200d_2696": 1,
        "1f9d1_1f3fc_200d_2708": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f48b_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f48b_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f48b_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f48b_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fc_200d_2764_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fd_200d_1f33e": 1,
        "1f9d1_1f3fd_200d_1f373": 1,
        "1f9d1_1f3fd_200d_1f37c": 1,
        "1f9d1_1f3fd_200d_1f384": 1,
        "1f9d1_1f3fd_200d_1f393": 1,
        "1f9d1_1f3fd_200d_1f3a4": 1,
        "1f9d1_1f3fd_200d_1f3a8": 1,
        "1f9d1_1f3fd_200d_1f3eb": 1,
        "1f9d1_1f3fd_200d_1f3ed": 1,
        "1f9d1_1f3fd_200d_1f4bb": 1,
        "1f9d1_1f3fd_200d_1f4bc": 1,
        "1f9d1_1f3fd_200d_1f527": 1,
        "1f9d1_1f3fd_200d_1f52c": 1,
        "1f9d1_1f3fd_200d_1f680": 1,
        "1f9d1_1f3fd_200d_1f692": 1,
        "1f9d1_1f3fd_200d_1f91d_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fd_200d_1f91d_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fd_200d_1f91d_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fd_200d_1f91d_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fd_200d_1f91d_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fd_200d_1f9af": 1,
        "1f9d1_1f3fd_200d_1f9b0": 1,
        "1f9d1_1f3fd_200d_1f9b1": 1,
        "1f9d1_1f3fd_200d_1f9b2": 1,
        "1f9d1_1f3fd_200d_1f9b3": 1,
        "1f9d1_1f3fd_200d_1f9bc": 1,
        "1f9d1_1f3fd_200d_1f9bd": 1,
        "1f9d1_1f3fd_200d_2695": 1,
        "1f9d1_1f3fd_200d_2696": 1,
        "1f9d1_1f3fd_200d_2708": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f48b_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f48b_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f48b_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f48b_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fd_200d_2764_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fe_200d_1f33e": 1,
        "1f9d1_1f3fe_200d_1f373": 1,
        "1f9d1_1f3fe_200d_1f37c": 1,
        "1f9d1_1f3fe_200d_1f384": 1,
        "1f9d1_1f3fe_200d_1f393": 1,
        "1f9d1_1f3fe_200d_1f3a4": 1,
        "1f9d1_1f3fe_200d_1f3a8": 1,
        "1f9d1_1f3fe_200d_1f3eb": 1,
        "1f9d1_1f3fe_200d_1f3ed": 1,
        "1f9d1_1f3fe_200d_1f4bb": 1,
        "1f9d1_1f3fe_200d_1f4bc": 1,
        "1f9d1_1f3fe_200d_1f527": 1,
        "1f9d1_1f3fe_200d_1f52c": 1,
        "1f9d1_1f3fe_200d_1f680": 1,
        "1f9d1_1f3fe_200d_1f692": 1,
        "1f9d1_1f3fe_200d_1f91d_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fe_200d_1f91d_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fe_200d_1f91d_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fe_200d_1f91d_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3fe_200d_1f91d_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fe_200d_1f9af": 1,
        "1f9d1_1f3fe_200d_1f9b0": 1,
        "1f9d1_1f3fe_200d_1f9b1": 1,
        "1f9d1_1f3fe_200d_1f9b2": 1,
        "1f9d1_1f3fe_200d_1f9b3": 1,
        "1f9d1_1f3fe_200d_1f9bc": 1,
        "1f9d1_1f3fe_200d_1f9bd": 1,
        "1f9d1_1f3fe_200d_2695": 1,
        "1f9d1_1f3fe_200d_2696": 1,
        "1f9d1_1f3fe_200d_2708": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f48b_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f48b_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f48b_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f48b_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3fe_200d_2764_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3ff_200d_1f33e": 1,
        "1f9d1_1f3ff_200d_1f373": 1,
        "1f9d1_1f3ff_200d_1f37c": 1,
        "1f9d1_1f3ff_200d_1f384": 1,
        "1f9d1_1f3ff_200d_1f393": 1,
        "1f9d1_1f3ff_200d_1f3a4": 1,
        "1f9d1_1f3ff_200d_1f3a8": 1,
        "1f9d1_1f3ff_200d_1f3eb": 1,
        "1f9d1_1f3ff_200d_1f3ed": 1,
        "1f9d1_1f3ff_200d_1f4bb": 1,
        "1f9d1_1f3ff_200d_1f4bc": 1,
        "1f9d1_1f3ff_200d_1f527": 1,
        "1f9d1_1f3ff_200d_1f52c": 1,
        "1f9d1_1f3ff_200d_1f680": 1,
        "1f9d1_1f3ff_200d_1f692": 1,
        "1f9d1_1f3ff_200d_1f91d_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3ff_200d_1f91d_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3ff_200d_1f91d_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3ff_200d_1f91d_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3ff_200d_1f91d_200d_1f9d1_1f3ff": 1,
        "1f9d1_1f3ff_200d_1f9af": 1,
        "1f9d1_1f3ff_200d_1f9b0": 1,
        "1f9d1_1f3ff_200d_1f9b1": 1,
        "1f9d1_1f3ff_200d_1f9b2": 1,
        "1f9d1_1f3ff_200d_1f9b3": 1,
        "1f9d1_1f3ff_200d_1f9bc": 1,
        "1f9d1_1f3ff_200d_1f9bd": 1,
        "1f9d1_1f3ff_200d_2695": 1,
        "1f9d1_1f3ff_200d_2696": 1,
        "1f9d1_1f3ff_200d_2708": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f48b_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f48b_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f48b_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f48b_200d_1f9d1_1f3fe": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f9d1_1f3fb": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f9d1_1f3fc": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f9d1_1f3fd": 1,
        "1f9d1_1f3ff_200d_2764_200d_1f9d1_1f3fe": 1,
        "1f9d1_200d_1f33e": 1,
        "1f9d1_200d_1f373": 1,
        "1f9d1_200d_1f37c": 1,
        "1f9d1_200d_1f384": 1,
        "1f9d1_200d_1f393": 1,
        "1f9d1_200d_1f3a4": 1,
        "1f9d1_200d_1f3a8": 1,
        "1f9d1_200d_1f3eb": 1,
        "1f9d1_200d_1f3ed": 1,
        "1f9d1_200d_1f4bb": 1,
        "1f9d1_200d_1f4bc": 1,
        "1f9d1_200d_1f527": 1,
        "1f9d1_200d_1f52c": 1,
        "1f9d1_200d_1f680": 1,
        "1f9d1_200d_1f692": 1,
        "1f9d1_200d_1f91d_200d_1f9d1": 1,
        "1f9d1_200d_1f9af": 1,
        "1f9d1_200d_1f9b0": 1,
        "1f9d1_200d_1f9b1": 1,
        "1f9d1_200d_1f9b2": 1,
        "1f9d1_200d_1f9b3": 1,
        "1f9d1_200d_1f9bc": 1,
        "1f9d1_200d_1f9bd": 1,
        "1f9d1_200d_2695": 1,
        "1f9d1_200d_2696": 1,
        "1f9d1_200d_2708": 1,
        "1f9d4_1f3fb_200d_2640": 1,
        "1f9d4_1f3fb_200d_2642": 1,
        "1f9d4_1f3fc_200d_2640": 1,
        "1f9d4_1f3fc_200d_2642": 1,
        "1f9d4_1f3fd_200d_2640": 1,
        "1f9d4_1f3fd_200d_2642": 1,
        "1f9d4_1f3fe_200d_2640": 1,
        "1f9d4_1f3fe_200d_2642": 1,
        "1f9d4_1f3ff_200d_2640": 1,
        "1f9d4_1f3ff_200d_2642": 1,
        "1f9d4_200d_2640": 1,
        "1f9d4_200d_2642": 1,
        "1f9da_1f3fb": 1,
        "1f9da_1f3fb_200d_2640": 1,
        "1f9da_1f3fb_200d_2642": 1,
        "1f9da_1f3fc": 1,
        "1f9da_1f3fc_200d_2640": 1,
        "1f9da_1f3fc_200d_2642": 1,
        "1f9da_1f3fd": 1,
        "1f9da_1f3fd_200d_2640": 1,
        "1f9da_1f3fd_200d_2642": 1,
        "1f9da_1f3fe": 1,
        "1f9da_1f3fe_200d_2640": 1,
        "1f9da_1f3fe_200d_2642": 1,
        "1f9da_1f3ff": 1,
        "1f9da_1f3ff_200d_2640": 1,
        "1f9da_1f3ff_200d_2642": 1,
        "1f9db_1f3fb": 1,
        "1f9db_1f3fb_200d_2640": 1,
        "1f9db_1f3fb_200d_2642": 1,
        "1f9db_1f3fc": 1,
        "1f9db_1f3fc_200d_2640": 1,
        "1f9db_1f3fc_200d_2642": 1,
        "1f9db_1f3fd": 1,
        "1f9db_1f3fd_200d_2640": 1,
        "1f9db_1f3fd_200d_2642": 1,
        "1f9db_1f3fe": 1,
        "1f9db_1f3fe_200d_2640": 1,
        "1f9db_1f3fe_200d_2642": 1,
        "1f9db_1f3ff": 1,
        "1f9db_1f3ff_200d_2640": 1,
        "1f9db_1f3ff_200d_2642": 1,
        "1f9e7": 1,
        "1f9e8": 1,
        "1f9e9": 1,
        "1f9ea": 1,
        "1f9eb": 1,
        "1f9ec": 1,
        "1f9ed": 1,
        "1f9ee": 1,
        "1f9ef": 1,
        "1f9f0": 1,
        "1f9f1": 1,
        "1f9f2": 1,
        "1f9f3": 1,
        "1f9f4": 1,
        "1f9f5": 1,
        "1f9f6": 1,
        "1f9f7": 1,
        "1f9f8": 1,
        "1f9f9": 1,
        "1f9fa": 1,
        "1f9fb": 1,
        "1f9fc": 1,
        "1f9fd": 1,
        "1f9fe": 1,
        "1f9ff": 1,
        "1fa70": 1,
        "1fa71": 1,
        "1fa72": 1,
        "1fa73": 1,
        "1fa74": 1,
        "1fa78": 1,
        "1fa79": 1,
        "1fa7a": 1,
        "1fa7b": 1,
        "1fa7c": 1,
        "1fa80": 1,
        "1fa81": 1,
        "1fa82": 1,
        "1fa83": 1,
        "1fa84": 1,
        "1fa85": 1,
        "1fa86": 1,
        "1fa90": 1,
        "1fa91": 1,
        "1fa92": 1,
        "1fa93": 1,
        "1fa94": 1,
        "1fa95": 1,
        "1fa96": 1,
        "1fa97": 1,
        "1fa98": 1,
        "1fa99": 1,
        "1fa9a": 1,
        "1fa9b": 1,
        "1fa9c": 1,
        "1fa9d": 1,
        "1fa9e": 1,
        "1fa9f": 1,
        "1faa0": 1,
        "1faa1": 1,
        "1faa2": 1,
        "1faa3": 1,
        "1faa4": 1,
        "1faa5": 1,
        "1faa6": 1,
        "1faa7": 1,
        "1faa8": 1,
        "1faa9": 1,
        "1faaa": 1,
        "1faab": 1,
        "1faac": 1,
        "1fab0": 1,
        "1fab1": 1,
        "1fab2": 1,
        "1fab3": 1,
        "1fab4": 1,
        "1fab5": 1,
        "1fab6": 1,
        "1fab7": 1,
        "1fab8": 1,
        "1fab9": 1,
        "1faba": 1,
        "1fac0": 1,
        "1fac1": 1,
        "1fac2": 1,
        "1fac3": 1,
        "1fac3_1f3fb": 1,
        "1fac3_1f3fc": 1,
        "1fac3_1f3fd": 1,
        "1fac3_1f3fe": 1,
        "1fac3_1f3ff": 1,
        "1fac4": 1,
        "1fac4_1f3fb": 1,
        "1fac4_1f3fc": 1,
        "1fac4_1f3fd": 1,
        "1fac4_1f3fe": 1,
        "1fac4_1f3ff": 1,
        "1fac5": 1,
        "1fac5_1f3fb": 1,
        "1fac5_1f3fc": 1,
        "1fac5_1f3fd": 1,
        "1fac5_1f3fe": 1,
        "1fac5_1f3ff": 1,
        "1fad0": 1,
        "1fad1": 1,
        "1fad2": 1,
        "1fad3": 1,
        "1fad4": 1,
        "1fad5": 1,
        "1fad6": 1,
        "1fad7": 1,
        "1fad8": 1,
        "1fad9": 1,
        "1fae0": 1,
        "1fae1": 1,
        "1fae2": 1,
        "1fae3": 1,
        "1fae4": 1,
        "1fae5": 1,
        "1fae6": 1,
        "1fae7": 1,
        "1faf0": 1,
        "1faf0_1f3fb": 1,
        "1faf0_1f3fc": 1,
        "1faf0_1f3fd": 1,
        "1faf0_1f3fe": 1,
        "1faf0_1f3ff": 1,
        "1faf1": 1,
        "1faf1_1f3fb": 1,
        "1faf1_1f3fb_200d_1faf2_1f3fc": 1,
        "1faf1_1f3fb_200d_1faf2_1f3fd": 1,
        "1faf1_1f3fb_200d_1faf2_1f3fe": 1,
        "1faf1_1f3fb_200d_1faf2_1f3ff": 1,
        "1faf1_1f3fc": 1,
        "1faf1_1f3fc_200d_1faf2_1f3fb": 1,
        "1faf1_1f3fc_200d_1faf2_1f3fd": 1,
        "1faf1_1f3fc_200d_1faf2_1f3fe": 1,
        "1faf1_1f3fc_200d_1faf2_1f3ff": 1,
        "1faf1_1f3fd": 1,
        "1faf1_1f3fd_200d_1faf2_1f3fb": 1,
        "1faf1_1f3fd_200d_1faf2_1f3fc": 1,
        "1faf1_1f3fd_200d_1faf2_1f3fe": 1,
        "1faf1_1f3fd_200d_1faf2_1f3ff": 1,
        "1faf1_1f3fe": 1,
        "1faf1_1f3fe_200d_1faf2_1f3fb": 1,
        "1faf1_1f3fe_200d_1faf2_1f3fc": 1,
        "1faf1_1f3fe_200d_1faf2_1f3fd": 1,
        "1faf1_1f3fe_200d_1faf2_1f3ff": 1,
        "1faf1_1f3ff": 1,
        "1faf1_1f3ff_200d_1faf2_1f3fb": 1,
        "1faf1_1f3ff_200d_1faf2_1f3fc": 1,
        "1faf1_1f3ff_200d_1faf2_1f3fd": 1,
        "1faf1_1f3ff_200d_1faf2_1f3fe": 1,
        "1faf1_1f3ff_200d_1faf_1f3fd": 1,
        "1faf2": 1,
        "1faf2_1f3fb": 1,
        "1faf2_1f3fc": 1,
        "1faf2_1f3fd": 1,
        "1faf2_1f3fe": 1,
        "1faf2_1f3ff": 1,
        "1faf3": 1,
        "1faf3_1f3fb": 1,
        "1faf3_1f3fc": 1,
        "1faf3_1f3fd": 1,
        "1faf3_1f3fe": 1,
        "1faf3_1f3ff": 1,
        "1faf4": 1,
        "1faf4_1f3fb": 1,
        "1faf4_1f3fc": 1,
        "1faf4_1f3fd": 1,
        "1faf4_1f3fe": 1,
        "1faf4_1f3ff": 1,
        "1faf5": 1,
        "1faf5_1f3fb": 1,
        "1faf5_1f3fc": 1,
        "1faf5_1f3fd": 1,
        "1faf5_1f3fe": 1,
        "1faf5_1f3ff": 1,
        "1faf6": 1,
        "1faf6_1f3fb": 1,
        "1faf6_1f3fc": 1,
        "1faf6_1f3fd": 1,
        "1faf6_1f3fe": 1,
        "1faf6_1f3ff": 1,
        "265f": 1,
        "267e": 1,
        "26a7": 1,
        "26f9": 1,
        "26f9_1f3fb": 1,
        "26f9_1f3fc": 1,
        "26f9_1f3fd": 1,
        "26f9_1f3fe": 1,
        "26f9_1f3ff": 1,
        "2764_200d_1f525": 1,
        "2764_200d_1fa79": 1,
        "2764_fe0f_200d_1fa79": 1,
        f0000: 1
    });
    e.exports = a
}), null);
__d("FBEmojiUtils", ["EmojiRendererData", "SupportedEmoji3"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = /_fe0f/g,
        i = [127995, 127996, 127997, 127998, 127999];

    function a(a) {
        return a.map(function(a) {
            return String.fromCodePoint(a)
        }).join("")
    }
    var j = function(a) {
            return a.filter(function(a) {
                return a.length > 0
            }).map(function(a) {
                return a.codePointAt(0).toString(16)
            }).join("_").replace(h, "")
        },
        k = function(a) {
            a = j(a);
            if (a == null) return null;
            return c("SupportedEmoji3")[a] ? a : null
        };
    b = function(a) {
        return a.replace(h, "")
    };
    d = function(a) {
        var b = [];
        if (!c("EmojiRendererData").isEmojiModifierBase(a[0])) return b;
        i.forEach(function(d) {
            var e = a.reduce(function(a, b) {
                if (a.length && c("EmojiRendererData").isEmojiVariationSelector(b) && c("EmojiRendererData").isEmojiModifier(a[a.length - 1])) return a;
                a.push(b);
                c("EmojiRendererData").isEmojiModifierBase(b) && a.push(d);
                return a
            }, []);
            k(e.map(function(a) {
                return String.fromCodePoint(a)
            })) && b.push(e)
        });
        return b
    };
    g.codepointsToString = a;
    g.getKeyFromCodepoints = j;
    g.getSupportedKey = k;
    g.normalizeKey = b;
    g.getSupportedModifierSequences = d
}), 98);
__d("SupportedEmojiExtended", [], (function(a, b, c, d, e, f) {
    a = {
        FACE_WITH_COLON_THREE: 1,
        LIKE: 1,
        PACMAN: 1
    };
    e.exports = a
}), null);
__d("SupportedFacebookEmoji", ["SupportedCommonEmoji"], (function(a, b, c, d, e, f) {
    a = babelHelpers["extends"]({}, b("SupportedCommonEmoji"));
    e.exports = a
}), null);
__d("FBEmojiResource", ["EmojiImageURL", "EmojiRenderer", "FBEmojiUtils", "SupportedEmoji3", "SupportedEmojiExtended", "SupportedFacebookEmoji"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        a = d("FBEmojiUtils").normalizeKey(a);
        return c("SupportedFacebookEmoji")[a] || c("SupportedEmoji3")[a] ? a : null
    }

    function i(a) {
        if (c("SupportedEmoji3")[a]) return "EMOJI_3";
        else if (c("SupportedFacebookEmoji")[a]) return "FB_EMOJI";
        else return null
    }
    a = function() {
        function a(a) {
            this.$1 = a
        }
        var b = a.prototype;
        b.getImageURL = function(a) {
            var b = this.$1;
            if (c("SupportedEmojiExtended")[b]) return d("EmojiImageURL").getFBEmojiExtendedURL(b, a);
            var e = i(b);
            switch (e) {
                case "EMOJI_3":
                    return d("EmojiImageURL").getEmoji3URL(b, a);
                case "FB_EMOJI":
                    return d("EmojiImageURL").getFBEmojiURL(b, a)
            }
            return null
        };
        a.firstFromText = function(b) {
            b = d("EmojiRenderer").parse(b);
            return b.length === 0 ? null : a.fromCodepoints(b[0].emoji)
        };
        a.fromCodepoints = function(b) {
            b = h(d("FBEmojiUtils").getKeyFromCodepoints(b));
            return b == null ? null : new a(b)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("CometEmoji.react", ["CometImage.react", "FBEmojiResource", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.emoji,
            d = a.resource,
            e = a.size;
        e = e === void 0 ? 16 : e;
        a = a.testid;
        a = d || c("FBEmojiResource").fromCodepoints(b);
        d = a != null ? a.getImageURL(e) : null;
        a = b.join("");
        return d == null ? h.jsx("span", {
            className: "xxymvpz xgzva0m xat24cr xhhsvwb xdj266r x1fcty0u x1j61x8r x3nfvp2",
            children: a
        }) : h.jsx("span", {
            className: c("stylex")({
                "display-1": "x3nfvp2",
                "font-style-1": "x1j61x8r",
                "font-weight-1": "x1fcty0u",
                "margin-top-1": "xdj266r",
                "margin-end-1": "xhhsvwb",
                "margin-bottom-1": "xat24cr",
                "margin-start-1": "xgzva0m",
                "vertical-align-1": "xxymvpz"
            }, e === 16 ? {
                "height-1": "xlup9mm",
                "width-1": "x1kky2od"
            } : null, e === 18 ? {
                "height-1": "xmix8c7",
                "width-1": "x1xp8n7a"
            } : null, e === 20 ? {
                "height-1": "x1qx5ct2",
                "width-1": "xw4jnvo"
            } : null, e === 24 ? {
                "height-1": "xxk0z11",
                "width-1": "xvy4d1p"
            } : null, e === 28 ? {
                "height-1": "x1fgtraw",
                "width-1": "xgd8bvy"
            } : null, e === 30 ? {
                "height-1": "x1gnnpzl",
                "width-1": "x1849jeq"
            } : null, e === 32 ? {
                "height-1": "x10w6t97",
                "width-1": "x1td3qas"
            } : null, e === 56 ? {
                "height-1": "xnnlda6",
                "width-1": "x15yg21f"
            } : null, e === 128 ? {
                "height-1": "x1nbnut7",
                "width-1": "x2pejg6"
            } : null),
            "data-testid": void 0,
            children: h.jsx(c("CometImage.react"), {
                alt: a,
                height: e,
                src: d,
                width: e
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSkittleEmoji.react", ["CometEmoji.react", "EmojiRenderer", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            circle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            roundedRect: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c"
            },
            skittle: {
                alignItems: "x6s0dn4",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                display: "x3nfvp2",
                justifyContent: "xl56j7k",
                position: "x1n2onr6"
            }
        },
        j = {
            accent: {
                backgroundColor: "xwnonoy"
            },
            blue: {
                backgroundColor: "x11goek"
            },
            cherry: {
                backgroundColor: "x1tzrqqp"
            },
            grape: {
                backgroundColor: "x17f3y5z"
            },
            gray: {
                backgroundColor: "x1qhmfi1"
            },
            green: {
                backgroundColor: "xv9rvxn"
            },
            lemon: {
                backgroundColor: "xacajkf"
            },
            lightblue: {
                backgroundColor: "x1hr4nm9"
            },
            lime: {
                backgroundColor: "xbmc1ew"
            },
            pink: {
                backgroundColor: "x1qrsksh"
            },
            red: {
                backgroundColor: "x1ciooss"
            },
            seafoam: {
                backgroundColor: "x1tw9p8u"
            },
            teal: {
                backgroundColor: "x1emf0wh"
            },
            tomato: {
                backgroundColor: "xqjkjv5"
            },
            transparent: {
                backgroundColor: "xjbqb8w"
            },
            white: {
                backgroundColor: "x14hiurz"
            }
        },
        k = {
            24: {
                height: "xxk0z11",
                width: "xvy4d1p"
            },
            36: {
                height: "xc9qbxq",
                width: "x14qfxbe"
            },
            40: {
                height: "x1vqgdyp",
                width: "x100vrsf"
            },
            48: {
                height: "xsdox4t",
                width: "x1useyqa"
            },
            56: {
                height: "xnnlda6",
                width: "x15yg21f"
            },
            60: {
                height: "xng8ra",
                width: "x1247r65"
            }
        };

    function a(a) {
        var b = a.color,
            e = a.emoji,
            f = a.emojiSize,
            g = a.shape;
        g = g === void 0 ? "circle" : g;
        a = a.size;
        var l = d("EmojiRenderer").parse(e);
        return h.jsx("div", {
            className: c("stylex")(g === "circle" && i.circle, g === "roundedRect" && i.roundedRect, i.skittle, j[b], k[a]),
            children: h.jsx(c("CometEmoji.react"), {
                emoji: l[0] ? l[0].emoji : [e],
                size: f
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWJewelThreadFacepile.react", ["CometProfilePhotoAvailabilityBadge.react", "CometProfilePhotoLastActiveTimeBadge.react", "CometSSRReplaceContentOnHydrationAndBreakEventReplaying.react", "TetraProfilePhoto.react", "profilePhotoUtils", "react", "stylex", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            badge: {
                position: "x10l6tqk"
            },
            badgeWithLastActiveTime: {
                bottom: "x1ey2m1c",
                display: "x78zum5",
                end: "xds687c",
                justifyContent: "x13a6bvl",
                start: "x17qophe"
            },
            primaryPhoto: {
                bottom: "x1ey2m1c",
                position: "x10l6tqk",
                start: "x17qophe"
            },
            root: {
                position: "x1n2onr6"
            },
            secondaryPhoto: {
                end: "xds687c",
                position: "x10l6tqk",
                top: "x13vifvy"
            },
            withCircleBorder: {
                borderTop: "xu3qyrb",
                borderEnd: "x5azwcr",
                borderBottom: "xssttbw",
                borderStart: "xt910rc",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            }
        },
        j = {
            24: {
                height: "xxk0z11",
                width: "xvy4d1p"
            },
            36: {
                height: "xc9qbxq",
                width: "x14qfxbe"
            },
            40: {
                height: "x1vqgdyp",
                width: "x100vrsf"
            },
            48: {
                height: "xsdox4t",
                width: "x1useyqa"
            },
            56: {
                height: "xnnlda6",
                width: "x15yg21f"
            },
            60: {
                height: "xng8ra",
                width: "x1247r65"
            },
            80: {
                height: "xwzfr38",
                width: "x1dmp6jm"
            }
        };

    function k(a) {
        switch (a) {
            case 24:
                return 16;
            case 36:
                return 24;
            case 40:
                return 28;
            case 48:
                return 32;
            case 56:
                return 36;
            case 60:
                return 40;
            case 80:
                return 56;
            default:
                a
        }
        throw c("unrecoverableViolation")("Invalid size passed to MWJewelThreadfacepile", "comet_ui")
    }

    function a(a) {
        var b = a.addOn,
            e = a.primaryPhoto,
            f = a.secondaryPhoto;
        a = a.size;
        var g = k(a),
            l = d("profilePhotoUtils").getBadgeSizeAndStrokeWidth(a, "availabilityBadge");
        l = l[0];
        var m = d("profilePhotoUtils").getBadgePosition(a / 2),
            n = (b == null ? void 0 : b.type) === "lastActiveTimeBadge" && a > 28,
            o = e.withBorder;
        e = babelHelpers.objectWithoutPropertiesLoose(e, ["withBorder"]);
        l = (b == null ? void 0 : b.type) === "availabilityBadge" ? h.jsx("div", {
            className: c("stylex")(i.badge),
            style: m,
            children: h.jsx(c("CometProfilePhotoAvailabilityBadge.react"), {
                pressed: !1,
                size: l
            })
        }) : (b == null ? void 0 : b.type) === "lastActiveTimeBadge" ? h.jsx("div", {
            className: c("stylex")(i.badge, n && i.badgeWithLastActiveTime),
            style: n ? void 0 : m,
            children: h.jsx(c("CometProfilePhotoLastActiveTimeBadge.react"), {
                border: b.border,
                pressed: !1,
                time: b.time
            })
        }) : (b == null ? void 0 : b.type) === "trigger" ? h.jsx("div", {
            className: c("stylex")(i.badge, i.badgeWithLastActiveTime),
            children: b.icon
        }) : null;
        return h.jsxs("div", {
            className: c("stylex")(i.root, j[String(a)]),
            children: [h.jsx("div", {
                className: c("stylex")(i.secondaryPhoto),
                children: h.jsx(c("TetraProfilePhoto.react"), babelHelpers["extends"]({}, f, {
                    shape: "circle",
                    size: g
                }))
            }), h.jsx("div", {
                className: c("stylex")(i.primaryPhoto, o === !0 && i.withCircleBorder),
                children: h.jsx(c("TetraProfilePhoto.react"), babelHelpers["extends"]({}, e, {
                    shape: "circle",
                    size: g
                }))
            }), h.jsx(c("CometSSRReplaceContentOnHydrationAndBreakEventReplaying.react"), {
                children: l
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getListCellAddOn.react", ["fbt", "ix", "CometIcon.react", "CometSwitch.react", "Locale", "TetraButton.react", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("Locale").isRTL(),
        l = function(a, b) {
            var e = a.on,
                f = a.onPress,
                g = a.testOnly_pressed;
            a.type;
            var h = babelHelpers.objectWithoutPropertiesLoose(a, ["on", "onPress", "testOnly_pressed", "type"]);
            return j.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, h, {
                "aria-checked": f != null ? e : void 0,
                color: b ? "disabled" : e ? "highlight" : "secondary",
                disabled: b,
                hideHoverOverlay: !0,
                icon: a.on ? d("fbicon")._(i("484757"), 20) : d("fbicon")._(i("659288"), 20),
                onPress: f,
                role: f != null ? "checkbox" : void 0,
                testOnly_pressed: g
            }))
        },
        m = function(a, b) {
            var e = a.on,
                f = a.onPress,
                g = a.testOnly_pressed;
            a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["on", "onPress", "testOnly_pressed", "type"]);
            return j.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, a, {
                "aria-checked": f != null ? e : void 0,
                color: b ? "disabled" : e ? "highlight" : "secondary",
                disabled: b,
                hideHoverOverlay: !0,
                icon: e ? d("fbicon")._(i("621399"), 20) : d("fbicon")._(i("545517"), 20),
                onPress: f,
                role: f != null ? "radio" : void 0,
                testOnly_pressed: g
            }))
        },
        n = function(a, b, e) {
            a.text;
            a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["text", "type"]);
            e === 3 ? e = k ? d("fbicon")._(i("492521"), 24) : d("fbicon")._(i("492575"), 24) : e = k ? d("fbicon")._(i("492518"), 20) : d("fbicon")._(i("492572"), 20);
            return j.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, a, {
                color: b ? "disabled" : "secondary",
                disabled: b,
                icon: e
            }))
        },
        o = function(a, b, e) {
            a.children;
            e = a.onPress;
            var f = a.open;
            a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "onPress", "open", "type"]);
            return j.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, a, {
                color: b ? "disabled" : "secondary",
                disabled: b,
                icon: f ? d("fbicon")._(i("505565"), 20) : d("fbicon")._(i("492454"), 20),
                onPress: e
            }))
        },
        p = function(a, b) {
            var d = a.color,
                e = a.icon,
                f = a.onHoverIn,
                g = a.onHoverOut,
                h = a.onPress,
                i = a.onPressIn,
                k = a.testOnly_pressed;
            a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["color", "icon", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "testOnly_pressed", "type"]);
            d = (d = d) != null ? d : "primary";
            return j.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, a, {
                color: b ? "disabled" : d,
                disabled: b,
                hideHoverOverlay: !0,
                icon: e,
                onHoverIn: f,
                onHoverOut: g,
                onPress: h,
                onPressIn: i,
                testOnly_pressed: k
            }))
        },
        q = function(a, b) {
            var d = a.labelIsHidden;
            d = d === void 0 ? !1 : d;
            var e = a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["labelIsHidden", "type"]);
            e = e === "primary-button" ? "primary" : "secondary";
            return j.createElement(c("TetraButton.react"), d ? babelHelpers["extends"]({
                disabled: b,
                labelIsHidden: !0,
                type: e
            }, a) : babelHelpers["extends"]({
                disabled: b,
                type: e
            }, a))
        },
        r = function(a, b) {
            var d = a.onChange,
                e = a.size;
            a.type;
            var f = a.value;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["onChange", "size", "type", "value"]);
            return j.jsx(c("CometSwitch.react"), babelHelpers["extends"]({
                disabled: b,
                onClick: d != null ? d : function() {},
                size: e,
                tabIndex: -1,
                value: f
            }, a, {
                children: a.disabled === !0 ? h._("Disabled") : h._("Enabled")
            }))
        },
        s = function(a, b) {
            var e = a.onPress,
                f = a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["onPress", "type"]);
            return j.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, a, {
                color: b ? "disabled" : "secondary",
                disabled: b,
                icon: f === "more" ? d("fbicon")._(i("484391"), 24) : d("fbicon")._(i("478237"), 16),
                onPress: e
            }))
        };
    a = function(a, b, c) {
        switch (a.type) {
            case "checkbox":
                return l(a, b);
            case "radio":
                return m(a, b);
            case "disclosure":
                return n(a, b, c);
            case "expander":
                return o(a, b, c);
            case "icon":
                return p(a, b);
            case "primary-button":
                return q(a, b);
            case "secondary-button":
                return q(a, b);
            case "switch":
                return r(a, b);
            case "more":
                return s(a, b);
            case "close":
                return s(a, b);
            case "body":
                return a.addOn
        }
    };
    g.getEndAddOn = a
}), 98);
__d("CometListCellStrict.react", ["CometCompositeStructureContext", "CometDensityAwarenessContext", "CometDensityModeContext", "CometFocusGroupContext", "CometFocusTableContext", "CometIcon.react", "CometImageFromIXValueRelayWrapper.react", "CometPressable.react", "CometProfilePhoto.react", "CometProfilePhotoForActor.react", "CometProgressSkittleIndeterminate.react", "CometSkittleEmoji.react", "CometSkittleIcon.react", "CometVisualCompletionAttributes", "MWJewelThreadFacepile.react", "TetraText.react", "TetraTextPairing.react", "getItemRoleFromCompositeRole", "getListCellAddOn.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            addOn: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexDirection: "x1q0g3np"
            },
            addOnWithExpander: {
                marginEnd: "x1emribx"
            },
            addOnWithIcon: {
                display: "x78zum5"
            },
            addOnWithText: {
                marginStart: "xsgj6o6"
            },
            bottomAddOn: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                marginEnd: "x12rz0ws",
                marginStart: "x16hk5td"
            },
            bottomAddOnInner: {
                maxWidth: "x193iq5w"
            },
            bottomAddOnOverrideRow: {
                flexDirection: "x1q0g3np",
                marginEnd: "x11i5rnm",
                marginStart: "x1mh8g0r",
                paddingTop: "x1yrsyyn"
            },
            bottomAddOnWithFacepile: {
                marginStart: "x169t7cy"
            },
            bottomDivider: {
                backgroundColor: "x14nfmen",
                bottom: "x1ey2m1c",
                end: "xds687c",
                height: "xjm9jq1",
                position: "x10l6tqk",
                start: "x17qophe"
            },
            content: {
                alignItems: "x1qjc9v5",
                borderTopStyle: "x13fuv20",
                borderStartStyle: "x26u7qi",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderTopWidth: "x972fbf",
                borderStartWidth: "xm0m39n",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                justifyContent: "x1qughib",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                minHeight: "x2lwn1j",
                minWidth: "xeuugli",
                paddingEnd: "x4uap5",
                paddingStart: "xkhd6sd",
                position: "x1n2onr6",
                zIndex: "x1ja2u2z",
                flexBasis: "x1r8uery",
                paddingTop: "xz9dl7a",
                paddingBottom: "xsag5q8"
            },
            contentContainer: {
                borderTopStyle: "x13fuv20",
                borderStartStyle: "x26u7qi",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderTopWidth: "x972fbf",
                borderStartWidth: "xm0m39n",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                justifyContent: "x1qughib",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                minHeight: "x2lwn1j",
                minWidth: "xeuugli",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                zIndex: "x1ja2u2z",
                alignItems: "x6s0dn4",
                alignSelf: "xkh2ocl",
                flexDirection: "x1q0g3np",
                position: "x1n2onr6"
            },
            contentDense: {
                paddingTop: "x1y1aw1k",
                paddingBottom: "xwib8y2"
            },
            contentWithMoreSpacing: {
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v"
            },
            contentWithMoreSpacingDense: {
                paddingTop: "xz9dl7a",
                paddingBottom: "xsag5q8"
            },
            disabled: {
                cursor: "x1h6gzvc",
                pointerEvents: "x47corl"
            },
            endAddOn: {
                marginBottom: "xod5an3",
                marginStart: "x16n37ib",
                marginTop: "x14vqqas",
                position: "x1n2onr6"
            },
            endAddOnCenter: {
                marginBottom: "x1e56ztr",
                marginTop: "x1xmf6yo"
            },
            endAddOnSmall: {
                marginBottom: "x1e56ztr",
                marginStart: "x16n37ib",
                marginTop: "x1xmf6yo",
                position: "x1n2onr6"
            },
            listCellMinHeight: {
                minHeight: "x1gg8mnh"
            },
            pressable: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                display: "x1lliihq"
            },
            responsiveButtons: {
                flexGrow: "x1iyjqo2",
                paddingBottom: "x10b6aqq",
                paddingTop: "x1yrsyyn"
            },
            responsiveContent: {
                alignItems: "x6s0dn4",
                flexDirection: "x1q0g3np",
                flexWrap: "x1a02dak",
                marginBottom: "x4cne27",
                marginTop: "xifccgj"
            },
            responsiveText: {
                boxSizing: "x9f619",
                flexBasis: "x4pfjvb",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                maxWidth: "x193iq5w",
                minWidth: "x1mkiy5m",
                paddingBottom: "x10b6aqq",
                paddingEnd: "x1pi30zi",
                paddingTop: "x1yrsyyn"
            },
            root: {
                borderTopStyle: "x13fuv20",
                borderStartStyle: "x26u7qi",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderTopWidth: "x972fbf",
                borderStartWidth: "xm0m39n",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                justifyContent: "x1qughib",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                minHeight: "x2lwn1j",
                minWidth: "xeuugli",
                paddingTop: "xexx8yu",
                paddingBottom: "x18d9i69",
                position: "x1n2onr6",
                zIndex: "x1ja2u2z",
                alignItems: "x6s0dn4",
                flexDirection: "x1q0g3np",
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha"
            },
            rootWithIncreasedHeight: {
                minHeight: "x1wiwyrm"
            },
            selected: {
                backgroundColor: "x1av1boa"
            },
            selectedWashBackground: {
                backgroundColor: "xljulmy"
            },
            startAddOn: {
                alignSelf: "xqcrz7y",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                marginEnd: "xq8finb",
                marginTop: "x1xmf6yo",
                marginBottom: "x1e56ztr",
                position: "x1n2onr6"
            },
            startAddOnDense: {
                marginTop: "x1k70j0n",
                marginBottom: "xzueoph"
            },
            startAddOnDensityAware: {
                "@media (max-height: 700px)": {
                    marginEnd: "x1ywmky0",
                    marginStart: "xnd27nj",
                    marginTop: "xv2ei83",
                    marginBottom: "x1og3r51",
                    transform: "xv3fwf9"
                }
            },
            textRight: {
                flexShrink: "x2lah0s"
            },
            visualSwitch: {
                pointerEvents: "x47corl"
            }
        },
        k = {
            center: {
                alignSelf: "xamitd3"
            },
            top: {
                alignSelf: "xqcrz7y"
            }
        },
        l = {
            center: {
                alignSelf: "xamitd3"
            },
            top: {
                alignSelf: "xqcrz7y"
            }
        };

    function a(a, b) {
        var d = a.addOnBottom,
            e = a.addOnEnd,
            f = a.addOnEndDisabled,
            g = a.addOnEndRef,
            p = a.addOnEndTestId;
        p = a.addOnEndVerticalAlign;
        p = p === void 0 ? "top" : p;
        var q = a.addOnStart,
            r = a.addOnStartCssSelectionId,
            s = a.addOnStartDisabled,
            t = a.addOnStartOverrideVerticalStyle,
            u = a.addOnStartTestId;
        u = a.addOnStartVerticalAlign;
        u = u === void 0 ? "top" : u;
        var v = a["aria-label"],
            w = a["aria-pressed"],
            x = a.body,
            y = a.bodyColor;
        y = y === void 0 ? "secondary" : y;
        var z = a.bodyLineLimit,
            A = a.contentHorizontalPadding,
            B = a.dataAttributes,
            C = a.describedby,
            D = a.disabled;
        D = D === void 0 ? !1 : D;
        var E = a.emphasized;
        E = E === void 0 ? !1 : E;
        var aa = a.focusable,
            ba = a.hasBottomDivider,
            F = a.headline,
            G = a.headlineAddOn,
            H = a.headlineColor;
        H = H === void 0 ? "primary" : H;
        var I = a.headlineLineLimit,
            J = a.level;
        J = J === void 0 ? 3 : J;
        var K = a.linkProps,
            L = a.meta,
            M = a.metaColor;
        M = M === void 0 ? "tertiary" : M;
        var N = a.metaLineLimit,
            O = a.metaLocation,
            ca = a.onFocusChange,
            da = a.onHoverIn,
            ea = a.onHoverOut,
            P = a.onPress,
            fa = a.onPressIn,
            ga = a.onPressOut,
            Q = a.paddingHorizontal,
            ha = a.role,
            R = a.selected;
        R = R === void 0 ? !1 : R;
        var S = a.selectedBackground,
            T = a.size;
        T = T === void 0 ? "default" : T;
        var U = a.testid;
        U = a.testOnly_pressed;
        a = D;
        var V = P;
        if (P == null && (e == null ? void 0 : e.type) === "switch") {
            var W;
            V = (W = e == null ? void 0 : e.onChange) != null ? W : P;
            a = (W = e == null ? void 0 : e.disabled) != null ? W : D
        }
        P = i(c("CometDensityModeContext"));
        W = P[0];
        D = i(c("CometDensityAwarenessContext"));
        P = F != null && x == null && L == null;
        var X = F == null && x != null && L == null,
            Y = F == null && x == null && L != null,
            Z = P && I != null && I === 1 || X && z != null && z === 1 || Y && N != null && N === 1;
        P = P && I != null && I > 1 || X && z != null && z > 1 || Y && N != null && N > 1;
        X = e != null && (e.type === "primary-button" || e.type === "secondary-button" || e.type === "body");
        Y = e != null && e.type === "expander";
        p = X || Y ? "center" : p;
        u = Z ? "center" : u;
        var $ = d != null && d.type === "buttons";
        P = q == null && (P || Z && (X || Y));
        Z = B != null ? Object.keys(B).reduce(function(a, b) {
            a != null && b != null && (a["data-" + b] = B[b]);
            return a
        }, {}) : null;
        D = h.jsxs("div", {
            className: c("stylex")(j.root, Y && T !== "small" && j.rootWithIncreasedHeight, T !== "small" && j.listCellMinHeight),
            style: A == null ? void 0 : {
                paddingLeft: A,
                paddingRight: A
            },
            children: [q != null ? h.jsx("div", {
                className: c("stylex")(j.startAddOn, t, k[u], W && j.startAddOnDense, D === !0 && j.startAddOnDensityAware),
                "data-testid": void 0,
                id: r,
                children: h.jsx(m, {
                    addOnStart: q,
                    disabled: (A = s) != null ? A : a
                })
            }) : null, h.jsxs("div", {
                className: c("stylex")(j.contentContainer),
                children: [h.jsxs("div", {
                    className: c("stylex")(j.content, W && j.contentDense, P && j.contentWithMoreSpacing, P && W && j.contentWithMoreSpacingDense, $ && j.responsiveContent),
                    children: [h.jsx("div", {
                        className: c("stylex")($ && j.responsiveText),
                        children: h.jsx(c("TetraTextPairing.react"), {
                            body: x,
                            bodyColor: a ? "disabled" : y,
                            bodyLineLimit: z,
                            headline: F,
                            headlineAddOn: G,
                            headlineColor: a ? "disabled" : H,
                            headlineLineLimit: I,
                            level: J,
                            meta: L,
                            metaColor: a ? "disabled" : M,
                            metaLineLimit: N,
                            metaLocation: O,
                            reduceEmphasis: E === !1
                        })
                    }), d != null && h.jsx("div", {
                        className: c("stylex")(j.bottomAddOn, d.type === "facepile" && j.bottomAddOnWithFacepile, d.type === "override-row" && j.bottomAddOnOverrideRow, $ && j.responsiveButtons),
                        children: h.jsx("div", {
                            className: c("stylex")(j.bottomAddOnInner),
                            children: h.jsx(n, {
                                addOnBottom: d
                            })
                        })
                    })]
                }), e != null ? h.jsx("div", {
                    className: c("stylex")(T !== "small" && j.endAddOn, T === "small" && j.endAddOnSmall, (X || Y) && j.endAddOnCenter, l[p]),
                    "data-testid": void 0,
                    ref: g,
                    children: h.jsx(o, {
                        addOn: e,
                        disabled: (t = f) != null ? t : a,
                        level: J
                    })
                }) : null, ((u = ba) != null ? u : !1) ? h.jsx("div", {
                    className: c("stylex")(j.bottomDivider)
                }) : null]
            })]
        });
        r = e != null && e.type === "expander" && e.open === !0 && e.children != null ? e.children : null;
        q = void 0;
        s = void 0;
        if (e != null) switch (e.type) {
            case "checkbox":
                s = e.on;
                q = "checkbox";
                break;
            case "radio":
                s = e.on;
                q = "radio";
                break;
            case "switch":
                s = e.value;
                q = "switch";
                break
        }
        A = i(c("CometFocusGroupContext"));
        P = A.FocusItem;
        W = i(c("CometFocusTableContext"));
        x = W.FocusCell;
        y = W.FocusRow;
        z = i(c("CometCompositeStructureContext"));
        F = z.role;
        H = (G = ha) != null ? G : c("getItemRoleFromCompositeRole")(F);
        L = H === "row" && y ? y : (I = P) != null ? I : h.Fragment;
        N = (M = x) != null ? M : h.Fragment;
        return h.jsxs(L, {
            children: [h.jsx("div", babelHelpers["extends"]({}, c("CometVisualCompletionAttributes").IGNORE_DYNAMIC, {
                "aria-selected": H === "option" ? R : void 0,
                role: (O = H) != null ? O : void 0,
                style: {
                    paddingLeft: (E = Q) != null ? E : 8,
                    paddingRight: ($ = Q) != null ? $ : 8
                }
            }, Z, {
                children: h.jsx(N, {
                    children: V != null || K != null ? h.jsx(c("CometPressable.react"), {
                        "aria-checked": s,
                        "aria-current": R ? "page" : void 0,
                        "aria-describedby": C != null ? C : void 0,
                        "aria-label": v,
                        "aria-pressed": w,
                        disabled: a,
                        display: "block",
                        focusable: aa,
                        linkProps: K,
                        onFocusChange: ca,
                        onHoverIn: da,
                        onHoverOut: ea,
                        onPress: V,
                        onPressIn: fa,
                        onPressOut: ga,
                        overlayDisabled: R,
                        ref: b,
                        role: q,
                        testOnly_pressed: U,
                        testid: void 0,
                        xstyle: [j.pressable, R && S !== "none" && j.selected, R && S === "wash" && j.selectedWashBackground, a && j.disabled],
                        children: D
                    }) : h.jsx("div", {
                        className: c("stylex")(j.pressable, R && j.selected, R && S === "wash" && j.selectedWashBackground, a && j.disabled),
                        "data-testid": void 0,
                        ref: b,
                        children: D
                    })
                })
            })), r]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function m(a) {
        var b = a.addOnStart;
        a = a.disabled;
        switch (b.type) {
            case "icon":
                b.type;
                var d = babelHelpers.objectWithoutPropertiesLoose(b, ["type"]);
                return h.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, d, {
                    disabled: a
                }));
            case "profile-photo":
                b.type;
                d = babelHelpers.objectWithoutPropertiesLoose(b, ["type"]);
                return h.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, d));
            case "profile-photo-for-actor":
                b.type;
                d = babelHelpers.objectWithoutPropertiesLoose(b, ["type"]);
                return h.jsx(c("CometProfilePhotoForActor.react"), babelHelpers["extends"]({}, d));
            case "contained-icon":
                d = b.color;
                d = d === void 0 ? "gray" : d;
                b.type;
                var e = babelHelpers.objectWithoutPropertiesLoose(b, ["color", "type"]);
                return h.jsx(c("CometSkittleIcon.react"), babelHelpers["extends"]({
                    color: d
                }, e, {
                    disabled: a
                }));
            case "contained-progress-ring-indeterminate":
                return h.jsx(c("CometProgressSkittleIndeterminate.react"), {});
            case "messenger-facepile":
                b.type;
                d = babelHelpers.objectWithoutPropertiesLoose(b, ["type"]);
                return h.jsx(c("MWJewelThreadFacepile.react"), babelHelpers["extends"]({}, d));
            case "override":
                return b.component;
            case "emoji":
                e = b.color;
                a = e === void 0 ? "gray" : e;
                d = b.emoji;
                e = b.emojiSize;
                e = e === void 0 ? 20 : e;
                var f = b.size;
                f = f === void 0 ? 40 : f;
                return h.jsx(c("CometSkittleEmoji.react"), {
                    color: a,
                    emoji: d,
                    emojiSize: e,
                    size: f
                });
            case "sprite":
                a = b.sprite;
                return h.jsx(c("CometImageFromIXValueRelayWrapper.react"), {
                    sprite: a
                });
            default:
                b.type;
                return null
        }
    }
    m.displayName = m.name + " [from " + f.id + "]";
    var n = function(a) {
            a = a.addOnBottom;
            switch (a.type) {
                case "facepile":
                    return a.facepile;
                default:
                    return a.component
            }
        },
        o = function(a) {
            var b = a.addOn,
                e = a.disabled;
            a = a.level;
            var f = d("getListCellAddOn.react").getEndAddOn(b, e, a),
                g = b.type === "disclosure" && b.text != null ? b.text : null;
            return h.jsxs("div", {
                className: c("stylex")(j.addOn, b.type === "switch" && j.visualSwitch),
                children: [g != null && h.jsx("div", {
                    className: c("stylex")(j.textRight),
                    children: h.jsx(c("TetraText.react"), {
                        color: e ? "disabled" : "secondary",
                        numberOfLines: 1,
                        type: a === 3 ? "body2" : "body3",
                        children: g
                    })
                }), h.jsx("div", {
                    className: c("stylex")(b.type === "expander" && j.addOnWithExpander, g != null && j.addOnWithText, b.type === "icon" && j.addOnWithIcon),
                    children: f
                })]
            })
        };
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("TetraListCell.react", ["CometListCellStrict.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = a.addOnPrimary,
            e = a.addOnPrimaryCssSelectionId,
            f = a.addOnPrimaryDisabled,
            g = a.addOnPrimaryOverrideVerticalStyle,
            i = a.addOnPrimaryTestId,
            j = a.addOnPrimaryVerticalAlign,
            k = a.addOnSecondary,
            l = a.addOnSecondaryDisabled,
            m = a.addOnSecondaryRef,
            n = a.addOnSecondaryTestId,
            o = a.addOnSecondaryVerticalAlign;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnPrimary", "addOnPrimaryCssSelectionId", "addOnPrimaryDisabled", "addOnPrimaryOverrideVerticalStyle", "addOnPrimaryTestId", "addOnPrimaryVerticalAlign", "addOnSecondary", "addOnSecondaryDisabled", "addOnSecondaryRef", "addOnSecondaryTestId", "addOnSecondaryVerticalAlign"]);
        return h.jsx(c("CometListCellStrict.react"), babelHelpers["extends"]({
            addOnEnd: k,
            addOnEndDisabled: l,
            addOnEndRef: m,
            addOnEndTestId: n,
            addOnEndVerticalAlign: o,
            addOnStart: d,
            addOnStartCssSelectionId: e,
            addOnStartDisabled: f,
            addOnStartOverrideVerticalStyle: g,
            addOnStartTestId: i,
            addOnStartVerticalAlign: j
        }, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("focusKeyboardEventPropagation", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a._stopFocusKeyboardPropagation === !0
    }

    function b(a) {
        a._stopFocusKeyboardPropagation = !0
    }
    f.hasFocusKeyboardEventPropagationStopped = a;
    f.stopFocusKeyboardEventPropagation = b
}), 66);
__d("FocusGroup.react", ["FocusManager", "Locale", "ReactFocusEvent.react", "ReactKeyboardEvent.react", "focusKeyboardEventPropagation", "gkx", "react", "setElementCanTab"], (function(a, b, c, d, e, f, g) {
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = b.useRef,
        l = 5;

    function m(a) {
        return a.length === 1
    }

    function n(a, b, c, e) {
        d("focusKeyboardEventPropagation").stopFocusKeyboardEventPropagation(c);
        b = b.DO_NOT_USE_queryFirstNode(a);
        b !== null && (document.activeElement != null && d("setElementCanTab").setElementCanTab(document.activeElement, !1), d("setElementCanTab").setElementCanTab(b, !0), d("FocusManager").focusElement(b, {
            preventScroll: e
        }), c.preventDefault())
    }

    function o(a, b, c, d, e, f) {
        b = b.onNavigate;
        if (b && d) {
            var g = !1,
                h = p(d, e);
            e = {
                currentIndex: h,
                event: c,
                focusItem: function(a, b) {
                    a = a.scopeRef.current;
                    a && n(b || f, a, c)
                },
                getItem: function(a) {
                    return t(d, a)
                },
                getItemByTag: function(a) {
                    var b = d.length,
                        c = h + 1;
                    while (!0) {
                        if (c === h) return null;
                        if (c > b - 1) {
                            c = 0;
                            continue
                        }
                        var e = d[c];
                        if (e) {
                            var f = e.disabled,
                                g = e.scopeRef,
                                i = e.tag;
                            g = g.current;
                            if (g && f !== !0 && i === a) return e
                        }
                        c++
                    }
                    return null
                },
                preventDefault: function() {
                    g = !0
                },
                type: a
            };
            b(e);
            if (g) return !0
        }
        return !1
    }

    function p(a, b) {
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            if (d && d.scopeRef.current === b) return c
        }
        return -1
    }

    function q(a, b, c) {
        var d = a.scopeRef.current;
        if (d === null) return null;
        if (c !== null) {
            d = p(c, b);
            b = a.wrap;
            a = u(c, d - 1);
            return !a && b === !0 ? u(c, c.length - 1) : a
        }
        return null
    }

    function r(a, b, c) {
        var d = a.scopeRef.current;
        if (d === null) return null;
        if (c.length > 0) {
            d = p(c, b);
            b = a.wrap;
            a = s(c, d + 1);
            return !a && b === !0 ? s(c, 0) : a
        }
        return null
    }

    function s(a, b) {
        var d = a.length;
        if (b > d) return null;
        b = b;
        while (b < d) {
            var e = a[b];
            if (c("gkx")("5403")) {
                if (e !== null) return e.scopeRef.current
            } else if (e !== null && e.disabled !== !0) return e.scopeRef.current;
            b++
        }
        return null
    }

    function t(a, b) {
        b = b;
        while (b >= 0) {
            var d = a[b];
            if (c("gkx")("5403")) {
                if (d !== null) return d
            } else if (d !== null && d.disabled !== !0) return d;
            b--
        }
        return null
    }

    function u(a, b) {
        a = t(a, b);
        return a ? a.scopeRef.current : null
    }

    function v(a) {
        var b = a.altKey,
            c = a.ctrlKey,
            d = a.metaKey;
        a = a.shiftKey;
        return b === !0 || c === !0 || d === !0 || a === !0
    }

    function a(a) {
        var b = h.unstable_Scope,
            c = h.createContext(null),
            e = h.createContext(null);

        function g(e) {
            var f = e.children,
                g = e.orientation,
                i = e.wrap,
                m = e.tabScopeQuery,
                n = e.allowModifiers,
                o = e.preventScrollOnFocus,
                p = o === void 0 ? !1 : o;
            o = e.pageJumpSize;
            var q = o === void 0 ? l : o,
                r = e.onNavigate,
                s = k(null);
            o = j(function() {
                return {
                    scopeRef: s,
                    orientation: g,
                    wrap: i,
                    tabScopeQuery: m,
                    allowModifiers: n,
                    pageJumpSize: q,
                    preventScrollOnFocus: p,
                    onNavigate: r
                }
            }, [g, i, m, n, q, p, r]);
            var u = k(!1);
            e = d("ReactFocusEvent.react").useFocusWithin(s, j(function() {
                return {
                    onFocusWithin: function(b) {
                        u.current || (u.current = !0, s.current && a && (t(s.current, a), d("setElementCanTab").setElementCanTab(b.target, !0)))
                    }
                }
            }, [u]));
            return h.jsx(c.Provider, {
                value: o,
                children: h.jsx(b, {
                    ref: e,
                    children: f
                })
            })
        }
        g.displayName = g.name + " [from " + f.id + "]";

        function t(a, b) {
            var c = document.activeElement;
            a = a.DO_NOT_USE_queryAllNodes(b);
            if (a !== null)
                for (var b = 0; b < a.length; b++) {
                    var e = a[b];
                    e !== c ? d("setElementCanTab").setElementCanTab(e, !1) : d("setElementCanTab").setElementCanTab(e, !0)
                }
        }

        function w(f) {
            var g = f.children,
                l = f.disabled;
            f = f.tag;
            var w = k(null),
                x = i(c);
            d("ReactKeyboardEvent.react").useKeyboard(w, j(function() {
                return {
                    onKeyDown: function(b) {
                        if (d("focusKeyboardEventPropagation").hasFocusKeyboardEventPropagationStopped(b)) return;
                        var c = w.current;
                        if (c !== null && x !== null) {
                            var f = x.orientation === "vertical" || x.orientation === "both",
                                g = x.orientation === "horizontal" || x.orientation === "both",
                                h = x.scopeRef.current,
                                i = b.key,
                                j = x.preventScrollOnFocus;
                            if (i === "Tab" && h !== null) {
                                var k = x.tabScopeQuery;
                                if (k) {
                                    if (x.onNavigate) {
                                        var l = h.getChildContextValues(e);
                                        if (o("TAB", x, b, l, c, k)) return
                                    }
                                    t(h, k)
                                }
                                return
                            }
                            if (v(b)) {
                                l = x.allowModifiers;
                                if (l !== !0) return
                            }
                            if (h === null) return;
                            k = i;
                            d("Locale").isRTL() && (i === "ArrowRight" ? k = "ArrowLeft" : i === "ArrowLeft" && (k = "ArrowRight"));
                            switch (k) {
                                case "Home":
                                    l = h.getChildContextValues(e);
                                    if (o("HOME", x, b, l, c, a)) return;
                                    k = s(l, 0);
                                    if (k) {
                                        n(a, k, b, j);
                                        return
                                    }
                                    break;
                                case "End":
                                    l = h.getChildContextValues(e);
                                    if (o("END", x, b, l, c, a)) return;
                                    k = u(l, l.length - 1);
                                    if (k) {
                                        n(a, k, b, j);
                                        return
                                    }
                                    break;
                                case "PageUp":
                                    l = h.getChildContextValues(e);
                                    if (o("PAGE_UP", x, b, l, c, a)) return;
                                    k = x.pageJumpSize;
                                    var y = p(l, c);
                                    l = s(l, Math.max(0, y - k));
                                    if (l) {
                                        n(a, l, b, j);
                                        return
                                    }
                                    break;
                                case "PageDown":
                                    y = h.getChildContextValues(e);
                                    if (o("PAGE_DOWN", x, b, y, c, a)) return;
                                    k = x.pageJumpSize;
                                    l = p(y, c);
                                    y = u(y, Math.min(y.length - 1, l + k));
                                    if (y) {
                                        n(a, y, b, j);
                                        return
                                    }
                                    break;
                                case "ArrowUp":
                                    if (f) {
                                        l = h.getChildContextValues(e);
                                        if (o("PREV_ITEM", x, b, l, c, a)) return;
                                        k = b.metaKey || b.ctrlKey ? s(l, 0) : q(x, c, l);
                                        if (k) {
                                            n(a, k, b, j);
                                            return
                                        }
                                    }
                                    break;
                                case "ArrowDown":
                                    if (f) {
                                        y = h.getChildContextValues(e);
                                        if (o("NEXT_ITEM", x, b, y, c, a)) return;
                                        l = b.metaKey || b.ctrlKey ? u(y, y.length - 1) : r(x, c, y);
                                        if (l) {
                                            n(a, l, b, j);
                                            return
                                        }
                                    }
                                    break;
                                case "ArrowLeft":
                                    if (g) {
                                        k = h.getChildContextValues(e);
                                        if (o("PREV_ITEM", x, b, k, c, a)) return;
                                        f = b.metaKey || b.ctrlKey ? s(k, 0) : q(x, c, k);
                                        if (f) {
                                            n(a, f, b, j);
                                            return
                                        }
                                    }
                                    break;
                                case "ArrowRight":
                                    if (g) {
                                        y = h.getChildContextValues(e);
                                        if (o("NEXT_ITEM", x, b, y, c, a)) return;
                                        l = b.metaKey || b.ctrlKey ? u(y, y.length - 1) : r(x, c, y);
                                        l && n(a, l, b, j)
                                    }
                                    break;
                                default:
                                    if (m(i) && x.onNavigate) {
                                        k = h.getChildContextValues(e);
                                        o("PRINT_CHAR", x, b, k, c, a)
                                    }
                            }
                        }
                    }
                }
            }, [x]));
            var y = d("ReactFocusEvent.react").useFocusWithin(w, j(function() {
                return {
                    onFocusWithin: function(b) {
                        if (a != null) {
                            var c;
                            c = (c = w.current) == null ? void 0 : c.DO_NOT_USE_queryFirstNode(a);
                            b = b.target === c;
                            if (b && (c && !d("setElementCanTab").canElementTab(c))) {
                                b = x == null ? void 0 : x.scopeRef.current;
                                b && t(b, a)
                            }
                        }
                    }
                }
            }, [x == null ? void 0 : x.scopeRef]));
            l = {
                scopeRef: w,
                disabled: l,
                tag: f
            };
            return h.jsx(e.Provider, {
                value: l,
                children: h.jsx(b, {
                    ref: y,
                    children: g
                })
            })
        }
        w.displayName = w.name + " [from " + f.id + "]";
        return [g, w]
    }
    g.createFocusGroup = a
}), 98);
__d("CometMenuFocusGroup", ["fbt", "CometComponentWithKeyCommands.react", "CometKeys", "FocusGroup.react", "focusScopeQueries", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("FocusGroup.react").createFocusGroup(d("focusScopeQueries").tabbableScopeQuery);
    var j = b[0];
    e = b[1];

    function a(a) {
        var b = [{
            command: {
                key: c("CometKeys").UP
            },
            description: h._("Previous item"),
            handler: function() {}
        }, {
            command: {
                key: c("CometKeys").DOWN
            },
            description: h._("Next item"),
            handler: function() {}
        }];
        return i.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: b,
            children: i.jsx(j, babelHelpers["extends"]({}, a))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = {
        FocusGroup: a,
        FocusItem: e
    };
    g["default"] = d
}), 98);
__d("CometFocusGroupFirstLetterNavigation", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    var h = a.useEffect,
        i = a.useState,
        j = function(a) {
            return a.slice(0, 1).toLowerCase()
        };
    b = function(a) {
        var b = i(void 0),
            c = b[0],
            d = b[1];
        h(function() {
            var b;
            b = a == null ? void 0 : (b = a.current) == null ? void 0 : b.innerText;
            b != null && b !== "" && d(j(b))
        }, [a]);
        return c
    };
    c = function(a) {
        if (a.type === "PRINT_CHAR") {
            a.event.stopPropagation();
            var b = a.event.key.toLowerCase();
            b = a.getItemByTag(b);
            b != null && a.focusItem(b)
        }
    };
    g.getFirstLetterNavigationTag = j;
    g.useFirstLetterNavigationTag = b;
    g.handleFirstLetterNavigation = c
}), 98);
__d("CometMenuItemHighlightContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("CometTextWithIcon.react", ["BaseView.react", "CometNonBreakingSpace.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            icon: {
                alignItems: "x6s0dn4",
                display: "x3nfvp2",
                verticalAlign: "xxymvpz"
            },
            iconContainer: {
                display: "xt0psk2",
                whiteSpace: "xuxw1ft"
            }
        };

    function a(a) {
        var b = a.children,
            d = a.iconAfter,
            e = a.iconBefore,
            f = a.iconOverrideVerticalStyle,
            g = a.observeDirectionality;
        g = g === void 0 ? !1 : g;
        a = a.spacing;
        a = a === void 0 ? .5 : a;
        e = h.jsxs(h.Fragment, {
            children: [e != null && h.jsxs(c("BaseView.react"), {
                xstyle: i.iconContainer,
                children: [h.jsx(c("BaseView.react"), {
                    xstyle: babelHelpers["extends"]({}, i.icon, f),
                    children: e
                }), h.jsx(c("CometNonBreakingSpace.react"), {
                    size: a
                })]
            }), b, d != null && h.jsxs(c("BaseView.react"), {
                xstyle: i.iconContainer,
                children: [h.jsx(c("CometNonBreakingSpace.react"), {
                    size: a
                }), h.jsx(c("BaseView.react"), {
                    xstyle: babelHelpers["extends"]({}, i.icon, f),
                    children: d
                })]
            })]
        });
        return g ? h.jsx("span", {
            dir: "auto",
            children: e
        }) : e
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometMenuItemBase.react", ["BaseFocusRing.react", "CometFocusGroupFirstLetterNavigation", "CometMenuContext", "CometMenuFocusGroup", "CometMenuItemBaseRoleContext", "CometMenuItemHighlightContext", "CometNonBreakingSpace.react", "CometPressable.react", "CometPressableOverlay.react", "CometTextWithIcon.react", "TetraText.react", "TetraTextPairing.react", "gkx", "mergeRefs", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useEffect,
        l = b.useMemo,
        m = b.useRef,
        n = {
            aux: {
                marginStart: "x16n37ib"
            },
            content: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexGrow: "x1iyjqo2",
                justifyContent: "x1qughib",
                minWidth: "xeuugli"
            },
            disabled: {
                cursor: "x1h6gzvc"
            },
            extraHorizontalPadding: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha"
            },
            listItem: {
                alignItems: "x6s0dn4",
                appearance: "xjyslct",
                boxSizing: "x9f619",
                cursor: "x1ypdohk",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexShrink: "x2lah0s",
                marginEnd: "x1w4qvff",
                marginStart: "x13mpval",
                marginTop: "xdj266r",
                marginBottom: "xat24cr",
                paddingTop: "xz9dl7a",
                paddingEnd: "x1sxyh0",
                paddingBottom: "xsag5q8",
                paddingStart: "xurb0ha",
                position: "x1n2onr6",
                textAlign: "x16tdsg8",
                zIndex: "x1ja2u2z"
            },
            listItemAlignedCenter: {
                alignItems: "x6s0dn4"
            },
            listItemWithIcon: {
                paddingTop: "x1y1aw1k",
                paddingEnd: "x1sxyh0",
                paddingBottom: "xwib8y2",
                paddingStart: "xurb0ha"
            }
        },
        o = c("gkx")("1721477") || c("gkx")("1459");

    function a(a, b) {
        var e = a.alignCenter;
        e = e === void 0 ? !1 : e;
        var f = a.aux,
            g = a.badge,
            p = a.bodyColor,
            q = a.bodyText,
            r = a.disabled,
            s = r === void 0 ? !1 : r;
        r = a.download;
        var t = a.href,
            u = a.iconNode,
            v = a.id,
            w = a.isIconAnImage,
            x = a.onClick,
            y = a.onFocusIn,
            z = a.onFocusOut,
            A = a.onHoverIn,
            B = a.onHoverOut,
            C = a.onPressIn,
            D = a.overlayRadius,
            E = D === void 0 ? 4 : D;
        D = a.passthroughProps;
        var F = a.prefetchQueriesOnHover,
            G = a.preventClosingMenuOnSelect;
        G = G === void 0 ? !1 : G;
        var H = a.preventLocalNavigation,
            I = a.primaryColor,
            J = a.primaryText,
            K = a.role,
            L = a.routeTarget,
            M = a.secondaryColor,
            N = a.secondaryText,
            O = a.target,
            P = a.testid;
        P = a.traceParams;
        var Q = a.visuallyFocused,
            R = Q === void 0 ? !1 : Q;
        Q = babelHelpers.objectWithoutPropertiesLoose(a, ["alignCenter", "aux", "badge", "bodyColor", "bodyText", "disabled", "download", "href", "iconNode", "id", "isIconAnImage", "onClick", "onFocusIn", "onFocusOut", "onHoverIn", "onHoverOut", "onPressIn", "overlayRadius", "passthroughProps", "prefetchQueriesOnHover", "preventClosingMenuOnSelect", "preventLocalNavigation", "primaryColor", "primaryText", "role", "routeTarget", "secondaryColor", "secondaryText", "target", "testid", "traceParams", "visuallyFocused"]);
        var S = m(null);
        a = j(c("CometMenuContext"));
        var T = G !== !0 && a ? a.onClose : null;
        G = t != null || L != null || O != null ? {
            download: r,
            passthroughProps: D,
            prefetchQueriesOnHover: F,
            preventLocalNavigation: H,
            routeTarget: L,
            target: O,
            traceParams: P,
            url: t
        } : void 0;
        a = i(function(a) {
            T != null && T(), x && x(a)
        }, [x, T]);
        r = j(c("CometMenuItemBaseRoleContext"));
        H = (F = (D = K) != null ? D : r) != null ? F : void 0;
        var U = m(R);
        k(function() {
            var a = S.current;
            !U.current && R && a != null && a.scrollIntoView({
                block: "nearest"
            })
        }, [R]);
        var V = m(null);
        L = d("CometFocusGroupFirstLetterNavigation").useFirstLetterNavigationTag(V);
        O = l(function() {
            return c("mergeRefs")(b, S)
        }, [b]);
        var W = g != null ? typeof g === "number" ? h.jsxs(h.Fragment, {
            children: [J, h.jsx(c("CometNonBreakingSpace.react"), {
                size: .5
            }), h.jsx(c("TetraText.react"), {
                color: s ? "disabled" : I,
                type: "body4",
                children: g
            })]
        }) : h.jsx(c("CometTextWithIcon.react"), {
            iconAfter: g,
            children: J
        }) : J;
        return h.jsx(c("CometMenuFocusGroup").FocusItem, {
            disabled: s,
            tag: L,
            children: h.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, Q, {
                disabled: s,
                display: "inline",
                id: v,
                linkProps: G,
                onFocusIn: y,
                onFocusOut: z,
                onHoverIn: A,
                onHoverOut: B,
                onPress: a,
                onPressIn: C,
                overlayDisabled: !0,
                ref: O,
                role: H,
                suppressFocusRing: !0,
                testid: void 0,
                xstyle: [n.listItem, e && n.listItemAlignedCenter, u != null && n.listItemWithIcon, s && n.disabled, !o && R && c("BaseFocusRing.react").focusRingXStyle],
                children: function(a) {
                    var b = a.focused,
                        d = a.focusVisible,
                        e = a.hovered;
                    a = a.pressed;
                    return h.jsxs(c("CometMenuItemHighlightContext").Provider, {
                        value: b && d || e,
                        children: [u, h.jsxs("div", {
                            className: c("stylex")(n.content, ((b = w) != null ? b : !1) && n.extraHorizontalPadding),
                            children: [h.jsx(c("TetraTextPairing.react"), {
                                body: q,
                                bodyColor: s ? "disabled" : p,
                                headline: W,
                                headlineColor: s ? "disabled" : I,
                                headlineRef: V,
                                level: 4,
                                meta: N,
                                metaColor: s ? "disabled" : M,
                                reduceEmphasis: !0
                            }), f != null && h.jsx("div", {
                                className: c("stylex")(n.aux),
                                children: f
                            })]
                        }), h.jsx(c("CometPressableOverlay.react"), {
                            focusVisible: d || R,
                            hovered: e,
                            pressed: a,
                            radius: E,
                            showFocusRing: !0
                        })]
                    })
                }
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometMenuItemIcon.react", ["CometEmoji.react", "CometIcon.react", "CometImage.react", "IconSource", "ImageIconSource", "SVGIcon", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo,
        j = {
            circle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            contained: {
                backgroundColor: "x1qhmfi1",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                height: "xvnh2x",
                minWidth: "x1g0q3yh"
            },
            iconRelativeContainer: {
                position: "x1n2onr6"
            },
            inset: {
                boxShadow: "xlg9a9y",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy"
            },
            root: {
                alignItems: "x6s0dn4",
                alignSelf: "xoi2r2e",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginEnd: "xq8finb"
            },
            roundedRect: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c"
            }
        };

    function a(a) {
        var b = a.disabled,
            e = a.emojiSize,
            f = e === void 0 ? 20 : e,
            g = a.icon,
            k = a.iconColor;
        e = a.iconCssSelectorId;
        var l = a.iconSize,
            m = l === void 0 ? 20 : l;
        l = a.use;
        var n = l === void 0 ? "normal" : l;
        a = i(function() {
            if (g instanceof c("IconSource")) {
                var a;
                return h.jsx(c("CometIcon.react"), {
                    color: (a = k) != null ? a : "primary",
                    disabled: b,
                    icon: g
                })
            }
            if (g instanceof c("ImageIconSource")) return h.jsx(c("CometIcon.react"), {
                disabled: b,
                icon: g
            });
            if (g instanceof d("SVGIcon").SVGIcon) {
                return h.jsx(c("CometIcon.react"), {
                    color: (a = k) != null ? a : "primary",
                    disabled: b,
                    icon: g,
                    size: m
                })
            }
            if (g instanceof d("SVGIcon").LegacySVGIcon) {
                return h.jsx(c("CometIcon.react"), {
                    color: (a = k) != null ? a : "primary",
                    disabled: b,
                    icon: g,
                    size: m
                })
            }
            if (g instanceof d("SVGIcon").EmojiIcon) return h.jsx(c("CometEmoji.react"), {
                emoji: g.codepoints,
                size: f
            });
            if (typeof g === "object" && typeof g !== "function" && !g._isSVG && g.src !== null) {
                a = n === "contained" ? 36 : 20;
                return h.jsxs("div", {
                    className: c("stylex")(j.iconRelativeContainer),
                    children: [h.jsx(c("CometImage.react"), {
                        height: a,
                        src: g.src,
                        width: a,
                        xstyle: [g.style === "circle" && j.circle, g.style === "roundedRect" && j.circle]
                    }), g.style !== "square" ? h.jsx("div", {
                        className: c("stylex")(g.style === "circle" && j.circle, j.inset, g.style === "roundedRect" && j.roundedRect),
                        style: {
                            height: a,
                            width: a
                        }
                    }) : null]
                })
            }
            return h.jsx(c("CometIcon.react"), {
                color: (a = k) != null ? a : "secondary",
                disabled: b,
                icon: g
            })
        }, [b, f, g, k, m, n]);
        return h.jsx("div", {
            className: c("stylex")([j.root, (n === "contained" || n === "contained_small_icon") && j.contained]),
            id: e,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.memo(a);
    g["default"] = b
}), 98);
__d("CometMenuItem.react", ["CometBadge.react", "CometIcon.react", "CometMenuItemBase.react", "CometMenuItemIcon.react", "CometProfilePhoto.react", "TetraTextPairing.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = a.auxItem,
            e = a.emojiSize,
            f = a.icon,
            g = a.iconColor,
            i = a.iconCssSelectorId,
            j = a.iconSize,
            k = a.iconStyle;
        k = k === void 0 ? "normal" : k;
        var l = a.image,
            m = a.overlayRadius;
        m = m === void 0 ? 4 : m;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["auxItem", "emojiSize", "icon", "iconColor", "iconCssSelectorId", "iconSize", "iconStyle", "image", "overlayRadius"]);
        var n = null;
        if (d != null) switch (d.type) {
            case "text":
                n = h.jsx(c("TetraTextPairing.react"), {
                    level: 3,
                    meta: d.auxText
                });
                break;
            case "badge":
                n = h.jsx(c("CometBadge.react"), {
                    color: d.color
                });
                break;
            case "icon":
                n = h.jsx(c("CometIcon.react"), {
                    color: d.color,
                    icon: d.icon
                });
                break
        }
        return h.jsx(c("CometMenuItemBase.react"), babelHelpers["extends"]({}, a, {
            alignCenter: !0,
            aux: n,
            iconNode: f != null ? h.jsx(c("CometMenuItemIcon.react"), {
                disabled: a.disabled,
                emojiSize: e,
                icon: f,
                iconColor: g,
                iconCssSelectorId: i,
                iconSize: j,
                use: k
            }) : l != null ? h.jsx(c("CometProfilePhoto.react"), {
                addOn: l.addOn,
                size: l.size,
                source: l.source
            }) : null,
            isIconAnImage: f == null && l != null,
            overlayRadius: m,
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseTheme.react", ["BaseThemeProvider.react", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = a.config,
            e = a.displayMode,
            f = a.style,
            g = a.xstyle,
            i = babelHelpers.objectWithoutPropertiesLoose(a, ["config", "displayMode", "style", "xstyle"]);
        return h.jsx(c("BaseThemeProvider.react"), {
            config: d,
            displayMode: e,
            children: function(a, d) {
                return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, i, {
                    ref: b,
                    style: babelHelpers["extends"]({}, d, f),
                    xstyle: [a, g]
                }))
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometEntryPointDialogTrigger.react", ["react", "useCometEntryPointDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useCallback,
        i = b.useRef;

    function a(a) {
        var b = a.children,
            d = a.dialogEntryPoint,
            e = a.fallback,
            f = a.onHide,
            g = a.onShow,
            j = a.otherProps,
            k = a.preloadParams,
            l = a.preloadTrigger,
            m = a.tracePolicy;
        i(null);
        a = c("useCometEntryPointDialog")(d, k, l, e);
        var n = a[0];
        d = a[1];
        k = a[2];
        l = a[3];
        e = h(function() {
            n(j, f, m), g == null ? void 0 : g()
        }, [n, j, f, m, g]);
        return b(e, d, k, l)
    }
    g["default"] = a
}), 98);
__d("CometProgressIndicator.react", ["BaseLoadingStateElement.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            animateDot: {
                animationDuration: "x1c74tu6",
                animationIterationCount: "xa4qsjk",
                animationName: "xwp40e0",
                animationTimingFunction: "x147wac7",
                opacity: "xllgmg",
                transform: "x13kylt9"
            },
            animationDelay300: {
                animationDelay: "x1x1c4bx"
            },
            animationDelay600: {
                animationDelay: "x1nrwgbl"
            },
            root: {
                display: "x78zum5",
                flexDirection: "x1q0g3np"
            }
        },
        j = {
            "default": {
                borderTopStartRadius: "x1lcm9me",
                borderTopEndRadius: "x1yr5g0i",
                borderBottomEndRadius: "xrt01vj",
                borderBottomStartRadius: "x10y3i5r",
                height: "xdk7pt",
                marginEnd: "xfs2ol5",
                marginStart: "x12mruv9",
                width: "x1xc55vz"
            },
            small: {
                borderTopStartRadius: "xm3z3ea",
                borderTopEndRadius: "x1x8b98j",
                borderBottomEndRadius: "x131883w",
                borderBottomStartRadius: "x16mih1h",
                height: "xqu0tyb",
                marginEnd: "xhhsvwb",
                marginStart: "xgzva0m",
                width: "x51ohtg"
            }
        },
        k = {
            media: {
                backgroundColor: "x14hiurz"
            },
            primary: {
                backgroundColor: "xn25soc"
            }
        };

    function a(a) {
        var b = a.disableLoadingStateTracker,
            d = a.overrideBGColorContext;
        d = d === void 0 ? "primary" : d;
        a = a.size;
        a = a === void 0 ? "default" : a;
        a = [i.animateDot, j[a], k[d]];
        return h.jsxs(c("BaseLoadingStateElement.react"), {
            disableLoadingStateTracker: b,
            xstyle: i.root,
            children: [h.jsx("div", {
                className: c("stylex")(a)
            }), h.jsx("div", {
                className: c("stylex").apply(void 0, a.concat([i.animationDelay300]))
            }), h.jsx("div", {
                className: c("stylex").apply(void 0, a.concat([i.animationDelay600]))
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTheme.react", ["BaseTheme.react", "CometStyleXSheet", "react", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo,
        j = {
            root: {
                boxSizing: "x1afcbsf",
                position: "x1uhb9sk",
                zIndex: "x1swf91x"
            }
        },
        k = {
            dark: d("CometStyleXSheet").DARK_MODE_CLASS_NAME,
            light: d("CometStyleXSheet").LIGHT_MODE_CLASS_NAME,
            type: "CLASSNAMES"
        };

    function a(a) {
        var b = a.theme,
            d = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["theme", "xstyle"]);
        var e = c("useCurrentDisplayMode")(),
            f = i(function() {
                return b === "invert" ? e === "dark" ? "light" : "dark" : b
            }, [e, b]);
        return h.jsx(c("BaseTheme.react"), babelHelpers["extends"]({
            config: k,
            displayMode: f,
            xstyle: [j.root, d]
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometToast.react", ["fbt", "ix", "CometCircleButton.react", "CometPressable.react", "CometRow.react", "CometRowItem.react", "CometTheme.react", "TetraText.react", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useMemo,
        l = {
            icon: {
                minWidth: "xnei2rj"
            },
            pressable: {
                display: "x1lliihq"
            },
            root: {
                backgroundColor: "x1jx94hy",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                boxShadow: "xdy0x9s",
                maxWidth: "x193iq5w",
                minWidth: "xp33xtk"
            }
        };

    function a(a) {
        var b = a.action,
            e = a.href,
            f = a.icon,
            g = a.impressionLoggingRef,
            m = a.message,
            n = a.onDismiss,
            o = a.supressCloseButton;
        o = o === void 0 ? !1 : o;
        var p = a.target,
            q = a.testid;
        q = a.truncateText;
        q = q === void 0 ? !0 : q;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["action", "href", "icon", "impressionLoggingRef", "message", "onDismiss", "supressCloseButton", "target", "testid", "truncateText"]);
        var r = k(function() {
            return e != null ? {
                target: p,
                url: e
            } : void 0
        }, [e, p]);
        g = j.jsxs(c("CometRow.react"), {
            paddingHorizontal: 16,
            paddingVertical: 16,
            ref: g,
            spacing: 12,
            testid: void 0,
            verticalAlign: "center",
            children: [f != null ? j.jsx(c("CometRowItem.react"), {
                xstyle: l.icon,
                children: f
            }) : null, j.jsx(c("CometRowItem.react"), {
                "aria-atomic": !0,
                expanding: !0,
                role: "alert",
                children: j.jsx(c("TetraText.react"), {
                    color: "primary",
                    numberOfLines: q ? 4 : void 0,
                    type: "body3",
                    children: m
                })
            }), b != null ? j.jsx(c("CometRowItem.react"), {
                children: j.jsx(c("CometPressable.react"), {
                    onPress: function(a) {
                        n(), b.onPress(a)
                    },
                    testid: void 0,
                    children: j.jsx(c("TetraText.react"), {
                        color: "blueLink",
                        numberOfLines: 1,
                        type: "body3",
                        children: b.label
                    })
                })
            }) : null, o !== !0 && j.jsx(c("CometRowItem.react"), {
                children: j.jsx(c("CometCircleButton.react"), {
                    icon: d("fbicon")._(i("478231"), 12),
                    label: h._("Close"),
                    onPress: n,
                    size: 24
                })
            })]
        });
        (a.onPress != null || r != null) && (g = j.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, a, {
            expanding: !0,
            linkProps: r,
            xstyle: l.pressable,
            children: g
        })));
        return j.jsx(c("CometTheme.react"), {
            testid: void 0,
            theme: "invert",
            xstyle: l.root,
            children: g
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useStatesInMap", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = b.useState;

    function a(a, b) {
        var c = i(a),
            d = i({}),
            e = j(b),
            f = e[0],
            g = e[1];
        h(function() {
            if (c.current !== a) {
                var e;
                c.current = a;
                g((e = d.current[a]) != null ? e : b)
            }
        }, [d, g, c, a, b]);
        h(function() {
            d.current[a] = f
        }, [f, a]);
        return [f, g]
    }
    g["default"] = a
}), 98);
__d("CometWarningScreenContext", ["react", "useStatesInMap"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    d = d("react");
    var i = d.createContext,
        j = d.useCallback,
        k = d.useContext,
        l = d.useMemo,
        m = i({
            makeContentVisibleDespiteOverlay: function() {},
            overlaySettings: {
                additionalRequiredHeight: 0,
                isContentVisibleDespiteOverlay: null,
                overlayExists: !1,
                overlayShown: !1,
                parentRenderInstructions: "CLIP_TO_MEDIA",
                videoController: null
            },
            setAdditionalRequiredHeight: function() {},
            setOverlayExists: function() {},
            setParentRenderInstructions: function() {},
            showOverlay: function() {}
        });

    function a(a) {
        var b = a.children,
            d = a.identifier,
            e = a.overlayExists,
            f = a.overlayShownOverride;
        a = a.videoController;
        f = c("useStatesInMap")(d, {
            additionalRequiredHeight: 0,
            isContentVisibleDespiteOverlay: null,
            overlayExists: e,
            overlayShown: (d = f) != null ? d : e,
            parentRenderInstructions: "CLIP_TO_MEDIA",
            videoController: a
        });
        var g = f[0],
            i = f[1],
            k = j(function(a) {
                i(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        overlayShown: a
                    })
                })
            }, []),
            n = j(function(a) {
                i(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        isContentVisibleDespiteOverlay: a
                    })
                })
            }, []),
            o = j(function(a) {
                i(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        overlayExists: a
                    })
                })
            }, []),
            p = j(function(a) {
                i(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        additionalRequiredHeight: a
                    })
                })
            }, []),
            q = j(function(a) {
                i(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        parentRenderInstructions: a
                    })
                })
            }, []);
        d = l(function() {
            return {
                makeContentVisibleDespiteOverlay: n,
                overlaySettings: g,
                setAdditionalRequiredHeight: p,
                setOverlayExists: o,
                setParentRenderInstructions: q,
                showOverlay: k
            }
        }, [g, p, k, n, o, q]);
        return h.jsx(m.Provider, {
            value: d,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b() {
        var a = k(m);
        a = a.overlaySettings;
        return a.overlayExists
    }

    function e() {
        var a = k(m);
        a = a.overlaySettings;
        return a.videoController
    }

    function n() {
        var a = k(m);
        a = a.overlaySettings;
        return a.overlayShown
    }

    function o() {
        var a = k(m);
        a = a.overlaySettings;
        return a.isContentVisibleDespiteOverlay
    }

    function p() {
        var a = n(),
            b = o();
        return !a ? !0 : b
    }

    function q() {
        var a = k(m);
        a = a.overlaySettings;
        return a.additionalRequiredHeight
    }

    function r() {
        var a = k(m);
        a = a.overlaySettings;
        return a.parentRenderInstructions
    }

    function s() {
        var a = k(m);
        a = a.showOverlay;
        return a
    }

    function t() {
        var a = k(m);
        a = a.makeContentVisibleDespiteOverlay;
        return a
    }

    function u() {
        var a = k(m);
        a = a.setOverlayExists;
        return a
    }

    function v() {
        var a = k(m);
        a = a.setAdditionalRequiredHeight;
        return a
    }

    function w() {
        var a = k(m);
        a = a.setParentRenderInstructions;
        return a
    }
    g.CometWarningScreenContextProvider = a;
    g.useHasOverlay = b;
    g.useHasVideoController = e;
    g.useIsOverlayShown = n;
    g.useIsContentVisibleDespiteOverlay = o;
    g.useIsContentVisible = p;
    g.useAdditionalRequiredHeight = q;
    g.useParentRenderInstructions = r;
    g.useShowOverlay = s;
    g.useMakeContentVisibleDespiteOverlay = t;
    g.useSetOverlayExists = u;
    g.useSetAdditionalRequiredHeight = v;
    g.useSetParentRenderInstructions = w
}), 98);
__d("useImpressionMoatSivtLogger", ["BaseViewportMarginsContext", "getIntersectionMarginFromViewportMargin", "intersectionObserverEntryIsIntersecting", "react", "useIntersectionObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useCallback,
        i = b.useContext,
        j = b.useRef;

    function a(a, b) {
        var d = i(c("BaseViewportMarginsContext")),
            e = j(!1),
            f = h(function(d) {
                d = c("intersectionObserverEntryIsIntersecting")(d);
                if (e.current !== d) {
                    e.current = d;
                    if (e.current) {
                        var f = new Date();
                        e.current = !0;
                        a.onReady(function(a) {
                            b(a, f)
                        })
                    }
                }
            }, [b, a]);
        return c("useIntersectionObserver")(f, {
            root: null,
            rootMargin: c("getIntersectionMarginFromViewportMargin")(d),
            threshold: 0
        })
    }
    g["default"] = a
}), 98);
__d("useStoryMoatSivtLogger", ["react", "requireDeferred", "useImpressionMoatSivtLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useCallback,
        i = b.useRef,
        j = c("requireDeferred")("Banzai").__setRef("useStoryMoatSivtLogger"),
        k = c("requireDeferred")("MoatSIVTSignals").__setRef("useStoryMoatSivtLogger"),
        l = 60 * 1e3;

    function a(a) {
        var b = i(0),
            d = h(function(c, d) {
                d = d.getTime();
                d - b.current >= l && a != null && (b.current = d, k.onReady(function(b) {
                    b = b.getSignals();
                    b = {
                        moat_sivt_results: b,
                        xt: a
                    };
                    c.post("comet_metrics:moat_sivt", b)
                }))
            }, [a]);
        return c("useImpressionMoatSivtLogger")(j, d)
    }
    g["default"] = a
}), 98);
__d("useRelayClientStateWithLocalStorage", ["CometRelay", "FBLogger", "WebStorage", "react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = new Set();

    function a(a, b, e, f) {
        var g = j.has(b),
            k = d("CometRelay").useRelayEnvironment(),
            l = c("useStable")(c("WebStorage").getLocalStorage),
            m = c("useStable")(function() {
                if (g || l == null) return f;
                var a = l.getItem(b);
                try {
                    return a == null || a === "" ? f : JSON.parse(a)
                } catch (a) {
                    return f
                }
            }),
            n = h(function(c) {
                d("CometRelay").commitLocalUpdate(k, function(d) {
                    d = d.get(a);
                    if (d == null) return;
                    if (d.getValue(e) === c) return;
                    d.setValue(c, e);
                    j.add(b)
                })
            }, [k, e, a, b]);
        i(function() {
            if (l == null) return;
            if (!g) return;
            var a = JSON.stringify(f);
            if (a == null) return;
            try {
                l.setItem(b, a)
            } catch (b) {
                b != null && typeof b === "object" && b.code === 22 && l.clear();
                a = c("FBLogger")("use_local_storage");
                b instanceof Error && (a = a.catching(b));
                a.mustfix("Cannot save to local storage.")
            }
        }, [b, g, l, f]);
        return [g ? f : m, n]
    }
    g.useRelayClientStateWithLocalStorage = a
}), 98);
__d("useFeedClickEventHandler", ["react", "useStoryClickEventLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback;

    function a(a, b) {
        var d = c("useStoryClickEventLogger")();
        return h(function(c) {
            a && a(c);
            var e = c.type;
            if (e === "click" || e === "contextmenu" || e === "mousedown" && typeof c.button === "number" && (c.button === 1 || c.button === 2) || e === "keydown" && (c.key === "Enter" || c.key === " ")) {
                e = typeof c.button === "number" ? c.button : 0;
                d(c.timeStamp, e, b)
            }
        }, [a, d, b])
    }
    g["default"] = a
}), 98);
__d("CometIsInNotificationsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("getTextDirectionAttribute", ["cr:1080422"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var c = "auto";
        b("cr:1080422") != null && window != null && (c = b("cr:1080422").isDirectionRTL(a) ? "rtl" : "ltr");
        return c
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerControllerSubscription", ["VideoPlayerHooks", "react", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = b.useState;

    function a(a) {
        var b = d("VideoPlayerHooks").useController(),
            e = j(function() {
                return a(b, null)
            }),
            f = e[0],
            g = e[1],
            k = i(a);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            k.current = a
        }, [a]);
        h(function() {
            g(function(a) {
                return k.current(b, a)
            });
            var a = b.subscribe(function() {
                g(function(a) {
                    return k.current(b, a)
                })
            });
            return function() {
                a.remove()
            }
        }, [b]);
        return f
    }
    g["default"] = a
}), 98);
__d("useAudioAvailabilityAtPlayhead", ["VideoPlayerAudioAvailabilityInfo", "VideoPlayerHooks", "useVideoPlayerControllerSubscription"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = d("VideoPlayerHooks").useAudioAvailabilityInfo();

        function b(b, c) {
            b = b.getPlayheadPosition();
            b = d("VideoPlayerAudioAvailabilityInfo").makeVideoPlayerAudioAvailabilityAtPlayheadInfo(a, {
                playheadPosition: b
            });
            return c != null && c.isPlayheadWithinMutedSegment === b.isPlayheadWithinMutedSegment && c.isSilentAtPlayhead === b.isSilentAtPlayhead && c.volumeControlState === b.volumeControlState ? c : b
        }
        return c("useVideoPlayerControllerSubscription")(b)
    }
    g["default"] = a
}), 98);
__d("CastingStateHooks", ["CastingContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(d("CastingContext").CastingStateContext);
        return (a == null ? void 0 : a.receiverIsConnected) || !1
    }

    function i() {
        var a = s();
        return a == null ? null : a.currentVideoID
    }

    function b() {
        var a = i();
        return a != null
    }

    function c() {
        var a = s();
        return a == null ? 0 : a.currentPosition || 0
    }

    function e() {
        var a = s();
        return a == null ? 0 : a.currentDuration || 0
    }

    function f() {
        var a = s();
        if (a == null) return !1;
        a = a.currentPlaybackState;
        return a === "play" || a === "seeking"
    }

    function j() {
        var a = s();
        if (a == null) return !1;
        a = a.currentPlaybackState;
        return a === "paused"
    }

    function k() {
        var a = s();
        if (a == null) return !1;
        a = a.currentPlaybackState;
        return a === "ended"
    }

    function l() {
        var a = h(d("CastingContext").CastingStateContext);
        return a == null || !a.receiverIsConnected ? !1 : a.receiverIsMuted === !0
    }

    function m() {
        var a = h(d("CastingContext").CastingStateContext);
        return a == null || !a.receiverIsConnected ? 0 : a.receiverVolume || 0
    }

    function n() {
        var a = h(d("CastingContext").CastingStateContext);
        return a == null || !a.receiverIsConnected ? null : a.receiverFriendlyName
    }

    function o() {
        var a = t();
        return a == null ? !1 : !0
    }

    function p() {
        var a = u();
        return a == null ? !1 : a.currentPlaybackState === "paused"
    }

    function q() {
        var a = u();
        return a == null ? !1 : a.currentPlaybackState === "play"
    }

    function r() {
        var a = u();
        return a == null ? null : a.currentAssetID
    }

    function s() {
        var a = h(d("CastingContext").CastingStateContext),
            b = h(d("CastingContext").CastingExperienceStateContext);
        if (a == null || !a.receiverIsConnected) return null;
        return (b == null ? void 0 : b.type) !== "video_channel" ? null : b
    }

    function t() {
        var a = h(d("CastingContext").CastingStateContext),
            b = h(d("CastingContext").CastingExperienceStateContext);
        if (a == null || !a.receiverIsConnected) return null;
        return (b == null ? void 0 : b.type) !== "photo" ? null : b
    }

    function u() {
        var a = h(d("CastingContext").CastingStateContext),
            b = h(d("CastingContext").CastingExperienceStateContext);
        if (a == null || !a.receiverIsConnected) return null;
        return (b == null ? void 0 : b.type) !== "photo_album" ? null : b
    }
    g.useIsCastingConnected = a;
    g.useCastingVideoID = i;
    g.useIsCastingAnyVideo = b;
    g.useCastingCurrentTime = c;
    g.useCastingDuration = e;
    g.useCastingIsPlaying = f;
    g.useCastingIsPaused = j;
    g.useCastingIsEnded = k;
    g.useCastingIsMuted = l;
    g.useCastingVolume = m;
    g.useCastingReceiverFriendlyName = n;
    g.useIsCastingPhotoExperience = o;
    g.useCastingIsAlbumPaused = p;
    g.useCastingIsAlbumPlaying = q;
    g.useCastingAlbumAssetID = r
}), 98);
__d("VideoPlayerInteractionOverlay.react", ["VideoPlayerHooks", "createVideoStateHook", "performanceNow", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useCallback,
        j = {
            hiddenCursor: {
                cursor: "xjfk50j"
            },
            pointer: {
                cursor: "x1ypdohk"
            },
            root: {
                bottom: "x1ey2m1c",
                boxSizing: "x9f619",
                end: "xds687c",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy"
            }
        };
    b = d("createVideoStateHook").createVideoStateHook(null);
    var k = b.setterHook;
    e = b.valueHook;

    function a(a, b) {
        var e = a.children,
            f = a.pressInteraction,
            g = a.style;
        a = a.xstyle;
        var l = k(),
            m = i(function(a) {
                a.preventDefault(), l({
                    left: a.clientX,
                    time: c("performanceNow")(),
                    top: a.clientY
                })
            }, [l]),
            n = f == null ? void 0 : f.handler,
            o = f == null ? void 0 : f.onPressStart,
            p = f == null ? void 0 : f.onMouseEnter;
        f = f == null ? void 0 : f.onMouseLeave;
        var q = d("VideoPlayerHooks").useIsFullscreen(),
            r = d("VideoPlayerHooks").useIsMouseIdle();
        return h.jsx("div", {
            className: c("stylex")(j.root, !!n && j.pointer, q && r && j.hiddenCursor, a),
            onClick: n,
            onContextMenu: m,
            onMouseEnter: p,
            onMouseLeave: f,
            onPointerDown: o,
            ref: b,
            role: "presentation",
            style: g,
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    f = e;
    g.VideoPlayerInteractionOverlay = b;
    g.useLastRightClick = f
}), 98);
__d("VideoPlayerPlayButton.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.isVisible;
        a = a.onClick;
        var d = j.jsx(c("CometImage.react"), {
            src: i("352839")
        });
        a = a != null ? j.jsx(c("CometPressable.react"), {
            display: "inline",
            label: h._("Play video"),
            onPress: a,
            overlayDisabled: !0,
            children: d
        }) : d;
        return j.jsx("i", {
            className: c("stylex")({
                "border-top-start-radius-1": "x14yjl9h",
                "border-top-end-radius-1": "xudhj91",
                "border-bottom-end-radius-1": "x18nykt9",
                "border-bottom-start-radius-1": "xww2gxu",
                "cursor-1": "x1ypdohk",
                "height-1": "xy75621",
                "margin-top-1": "xafmxuu",
                "margin-end-1": "x11i5rnm",
                "margin-bottom-1": "xat24cr",
                "margin-start-1": "x4mskuk",
                "opacity-1": "x1hc1fzr",
                "position-1": "x10l6tqk",
                "start-1": "xtzzx4i",
                "top-1": "xwa60dl",
                "width-1": "xni59qk"
            }, b ? null : {
                "opacity-1": "xg01cxk",
                "visibility-1": "xlshs6z"
            }),
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSmallPlayButton.react", ["fbt", "CometImage.react", "CometPressable.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.isVisible;
        a = a.onClick;
        var d = i.jsx(c("CometImage.react"), {
            src: "/images/video/play_48dp.png"
        });
        a = a != null ? i.jsx(c("CometPressable.react"), {
            display: "inline",
            label: h._("Play video"),
            onPress: a,
            overlayDisabled: !0,
            children: d
        }) : d;
        return i.jsx("i", {
            className: c("stylex")({
                "border-top-start-radius-1": "x14yjl9h",
                "border-top-end-radius-1": "xudhj91",
                "border-bottom-end-radius-1": "x18nykt9",
                "border-bottom-start-radius-1": "xww2gxu",
                "cursor-1": "x1ypdohk",
                "height-1": "xsdox4t",
                "margin-top-1": "xs9mwh0",
                "margin-end-1": "x11i5rnm",
                "margin-bottom-1": "xat24cr",
                "margin-start-1": "x10ndw75",
                "opacity-1": "x1hc1fzr",
                "position-1": "x10l6tqk",
                "start-1": "xtzzx4i",
                "top-1": "xwa60dl",
                "width-1": "x1useyqa"
            }, b ? null : {
                "opacity-1": "xg01cxk",
                "visibility-1": "xlshs6z"
            }),
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerControlsHiddenContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("VideoPlayerControlIcon.react", ["BaseFocusRing.react", "BaseTooltip.react", "CometPressable.react", "CometTooltipImpl.react", "TetraIcon.react", "VideoPlayerControlsHiddenContext", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            "default": {
                backgroundColor: "xjbqb8w",
                borderTop: "x76ihet",
                borderEnd: "xwmqs3e",
                borderBottom: "x112ta8",
                borderStart: "xxxdfa6",
                cursor: "x1ypdohk",
                display: "x1rg5ohu",
                height: "x1qx5ct2",
                marginTop: "x1k70j0n",
                marginEnd: "x1w0mnb",
                marginBottom: "xzueoph",
                marginStart: "x1mnrxsn",
                opacity: "x1iy03kw",
                outline: "x1a2a7pz",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                ":hover": {
                    opacity: "x1o7uuvo"
                }
            },
            disabled: {
                cursor: "xt0e3qv",
                opacity: "xbyyjgo",
                ":hover": {
                    opacity: "xj34u2y"
                }
            },
            dropShadow: {
                filter: "x1qo4wvw"
            },
            tooltipWrapperInner: {
                alignItems: "xuk3077",
                display: "x78zum5",
                width: "x14atkfc"
            },
            tooltipWrapperOuter: {
                alignItems: "xuk3077",
                display: "x78zum5",
                width: "x14atkfc"
            }
        };

    function k(a) {
        var b = a.children,
            d = a.tooltipOffsetY;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "tooltipOffsetY"]);
        d = Math.min(0, (d = d) != null ? d : 0);
        return h.jsx("span", {
            className: c("stylex")(j.tooltipWrapperOuter),
            style: {
                marginTop: d
            },
            children: h.jsx(c("BaseTooltip.react"), babelHelpers["extends"]({}, a, {
                children: h.jsx("span", {
                    className: c("stylex")(j.tooltipWrapperInner),
                    style: {
                        paddingTop: -d
                    },
                    children: b
                })
            }))
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.color,
            d = b === void 0 ? "white" : b,
            e = a.disabled,
            f = a.icon,
            g = a.label;
        b = a.tooltip;
        b = b === void 0 ? null : b;
        var l = a.tooltipAlign;
        l = l === void 0 ? "start" : l;
        var m = a.tooltipImpl,
            n = a.tooltipOffsetY,
            o = babelHelpers.objectWithoutPropertiesLoose(a, ["color", "disabled", "icon", "label", "tooltip", "tooltipAlign", "tooltipImpl", "tooltipOffsetY"]),
            p = i(c("VideoPlayerControlsHiddenContext"));
        return h.jsx(k, {
            align: l,
            position: "above",
            tooltip: b,
            tooltipImpl: (a = m) != null ? a : c("CometTooltipImpl.react"),
            tooltipOffsetY: n,
            children: h.jsx(c("BaseFocusRing.react"), {
                children: function(a) {
                    return h.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, o, {
                        disabled: e,
                        display: "inline",
                        label: g,
                        overlayDisabled: !0,
                        testid: void 0,
                        xstyle: [j["default"], e === !0 && j.disabled, a, p === !0 && j.dropShadow],
                        children: h.jsx(c("TetraIcon.react"), {
                            color: d,
                            icon: f
                        })
                    }))
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerControlsBottomRowAddOnContext", ["react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    d = d("react");
    var i = d.useContext,
        j = d.useEffect,
        k = d.useState,
        l = h.createContext(null);

    function a(a) {
        a = a.children;
        var b = c("useStable")(function() {
            var a = null,
                b = null,
                c = null;
            return {
                getBottomRowAddOn: function() {
                    return b
                },
                initialize: function(d) {
                    c = function(a) {
                        b = a, d(a)
                    };
                    if (a == null) return;
                    c(a);
                    a = null
                },
                setBottomRowAddOn: function(b) {
                    if (c == null) {
                        a = b;
                        return
                    }
                    c(b)
                }
            }
        });
        return h.jsx(l.Provider, {
            value: b,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = i(l);
        a = k(a);
        var c = a[0],
            d = a[1];
        j(function() {
            if (b == null) return;
            b.initialize(d)
        }, [b]);
        return c
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function e(a) {
        var b = i(l);
        j(function() {
            if (b == null) return;
            b.setBottomRowAddOn(a)
        }, [a, b])
    }
    g.VideoPlayerControlsBottomRowAddOnContext = l;
    g.VideoPlayerControlsBottomRowAddOnContextProvider = a;
    g.useVideoPlayerControlsBottomRowAddOn = b;
    g.useSetVideoPlayerControlsBottomRowAddOn = e
}), 98);
__d("VideoPlayerDefaultControlsProperties", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["SAME_AS_OTHER_CONTROLS", "SEPARATE_FROM_OTHER_CONTROLS"]);
    c = b("$InternalEnum")({
        VIDEO_CAPTIONS_MENU: "video_captions_menu",
        VIDEO_SETTINGS_MENU: "video_settings_menu"
    });
    f.MutedButtonVisibility = a;
    f.VideoMenuType = c
}), 66);
__d("VideoPlayerUserInteractionCounter", ["react", "unrecoverableViolation", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useCallback,
        i = e.useEffect,
        j = e.useRef,
        k = e.useState;

    function a(a, b, d) {
        var e = j(a);
        i(function() {
            if (a !== e.current) throw c("unrecoverableViolation")("User interaction name should not change between renders ('" + e.current + "' -> '" + a + "').", "comet_video_player")
        }, [a]);
        var f = j(d);
        i(function() {
            f.current = d
        }, [d]);
        var g = c("usePrevious")(b),
            h = j(!1);
        i(function() {
            var a = e.current,
                c = f.current;
            c && ((g === null || b !== g) && (b ? (h.current = !0, c({
                name: a,
                type: "started"
            })) : g !== null && (h.current = !1, c({
                name: a,
                type: "ended"
            }))))
        }, [b, g]);
        i(function() {
            var a = e.current,
                b = f.current;
            return function() {
                b && h.current && b({
                    name: a,
                    type: "ended"
                })
            }
        }, [])
    }

    function b() {
        var a = j(new Set()),
            b = k(0),
            c = b[0],
            d = b[1];
        b = h(function(b) {
            var c = a.current;
            b.type === "started" || b.type === "happening" ? (c.add(b.name), d(c.size)) : b.type === "ended" && (c["delete"](b.name), d(c.size))
        }, []);
        return {
            ongoingInteractionsCount: c,
            onUserInteraction: b
        }
    }
    g.useVideoPlayerUserInteraction = a;
    g.useVideoPlayerUserInteractionCounter = b
}), 98);
__d("CometWatchAndScrollTriggerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = {
        isControlShown: !1,
        isTriggerDisabled: !1,
        setIsControlShown: null,
        setIsTriggerDisabled: null
    };
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("VideoPlayerWithWatchAndScrollTrigger.react", ["$InternalEnum", "CastingStateHooks", "CometWatchAndScrollTriggerContext", "CometWatchAndScrollVideoContext", "VideoPlayerHooks", "react", "requireDeferred", "useVisibilityObserver", "useWatchAndScrollTrigger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useContext,
        k = c("requireDeferred")("VideoHomeTypedLoggerLite").__setRef("VideoPlayerWithWatchAndScrollTrigger.react"),
        l = 5,
        m = 30,
        n = b("$InternalEnum")({
            BROADCAST: "broadcast",
            HERO: "hero",
            PAGE_SPOTLIGHT_CARD: "page_spotlight_card",
            TAHOE: "tahoe",
            VOD: "vod",
            WNS_CONTROL: "wns_control"
        });

    function a(a) {
        var b = a.subOrigin,
            e = a.triggerType;
        a = a.videoID;
        var f = j(c("CometWatchAndScrollTriggerContext")),
            g = f.isControlShown;
        f = f.isTriggerDisabled;
        var o = d("VideoPlayerHooks").useController(),
            p = d("useWatchAndScrollTrigger").useWatchAndScrollTrigger(b, e, a),
            q = j(c("CometWatchAndScrollVideoContext")),
            r = d("CastingStateHooks").useIsCastingAnyVideo();
        b = i(function(a) {
            if (a.hiddenReason !== "NOT_IN_VIEWPORT") return;
            a = o.getCurrentState();
            var b = a.paused,
                c = !a.muted,
                d = o.getPlayheadPosition();
            a = a.duration;
            var f = l;
            a >= 30 && (f = Math.max(l, Math.min(m, Math.ceil(a * 0 / 100))));
            if (!b && !r && q == null) switch (e) {
                case n.HERO:
                    p();
                    k.onReady(function(a) {
                        a.log({
                            event: "watch_and_scroll_trigger",
                            event_target: "hero"
                        })
                    });
                    break;
                case n.BROADCAST:
                    c && (p(), k.onReady(function(a) {
                        a.log({
                            event: "watch_and_scroll_trigger",
                            event_target: "newsfeed_live"
                        })
                    }));
                    break;
                case n.VOD:
                    c && d >= f && (p(), k.onReady(function(a) {
                        a.log({
                            event: "watch_and_scroll_trigger",
                            event_target: "newsfeed_vod"
                        })
                    }));
                    break;
                default:
                    break
            }
        }, [o, q, e, p, r]);
        a = c("useVisibilityObserver")({
            onHidden: b
        });
        if (!g || f) return null;
        switch (e) {
            case n.HERO:
            case n.BROADCAST:
                return h.jsx("div", {
                    className: "xh8yej3 xu1mrb",
                    ref: a
                });
            case n.VOD:
                return h.jsx("div", {
                    className: "xh8yej3 xu1mrb",
                    ref: a
                });
            default:
                return null
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.WatchAndScrollTriggerType = n;
    g.VideoPlayerWithWatchAndScrollTrigger = a
}), 98);
__d("CometRouteRenderType", ["CometRouterRenderTypeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(c("CometRouterRenderTypeContext"));
        return a === "pushView"
    }

    function b() {
        var a = h(c("CometRouterRenderTypeContext"));
        return a === "hosted"
    }

    function e() {
        var a = h(c("CometRouterRenderTypeContext"));
        return a === "main"
    }
    g.useIsPushView = a;
    g.useIsHosted = b;
    g.useIsMain = e
}), 98);
__d("usePlayerOriginRouteTracePolicy", ["CometIsInNotificationsContext", "CometRouteRenderType", "react", "useCometRouteTracePolicy", "useCometRouterState", "useParentRoute", "useRoutePassthroughProps"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(c("CometIsInNotificationsContext")),
            b = c("useCometRouteTracePolicy")(),
            e = d("CometRouteRenderType").useIsPushView(),
            f = c("useParentRoute")(),
            g = c("useCometRouterState")(),
            i = c("useRoutePassthroughProps")();
        if ((i == null ? void 0 : i.isARLTW) === !0) return "comet.watch.arltw";
        i = b === "comet.videos.tahoe";
        var j = b === "comet.stories.viewer",
            k = b === "comet.reels.home";
        if (e) {
            if (i) return "unknown";
            if (j) return b;
            if (k && (f == null ? void 0 : f.tracePolicy) == null && g != null) {
                e = g.main;
                j = g.pushViewStack;
                k = j && j.length > 1 ? j[j.length - 2] : e;
                g = k.route;
                return (j = g.tracePolicy) != null ? j : b
            }
        }
        return a && !i ? b : (e = f == null ? void 0 : f.tracePolicy) != null ? e : b
    }
    g["default"] = a
}), 98);
__d("VideoPlayerViewabilityHooks", ["VideoPlayerHooks"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.useVideoPlayerExtendedPassiveViewabilityInfo = d("VideoPlayerHooks").useVideoPlayerExtendedPassiveViewabilityInfo, g.useVideoPlayerPassiveViewabilityInfo = d("VideoPlayerHooks").useVideoPlayerPassiveViewabilityInfo, g.useVideoPlayerViewabilityInfo = d("VideoPlayerHooks").useVideoPlayerViewabilityInfo
}), 98);
__d("useVideoPlayerPortalingPassthroughProps", ["VideoPlayerPortalingPlaceInfoProvider.react", "VideoPlayerViewabilityHooks", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;

    function a() {
        var a = d("VideoPlayerPortalingPlaceInfoProvider.react").useVideoPlayerPortalingPlaceInfo(),
            b = a.currentVideoID,
            c = a.thisPlaceID;
        a = d("VideoPlayerViewabilityHooks").useVideoPlayerViewabilityInfo();
        var e = a ? a.positionToViewport : null;
        return h(function() {
            return {
                portableVideoID: b,
                portalingPlaceID: c,
                positionToViewport: e
            }
        }, [b, e])
    }
    g["default"] = a
}), 98);
__d("useWatchAndScrollTrigger", ["CometPictureInPictureExpContext", "CometSetWatchAndScrollVideoContext", "CometWatchAndScrollSoundContext", "VideoPlayerHooks", "VideoPlayerWithWatchAndScrollTrigger.react", "react", "recoverableViolation", "usePlayerOriginRouteTracePolicy", "useVideoPlayerPortalingPassthroughProps"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useContext;

    function a(a, b, e, f) {
        var g = c("useVideoPlayerPortalingPassthroughProps")(),
            j = c("usePlayerOriginRouteTracePolicy")(),
            k = d("VideoPlayerHooks").useController(),
            l = i(c("CometSetWatchAndScrollVideoContext")),
            m = i(c("CometWatchAndScrollSoundContext")),
            n = i(c("CometPictureInPictureExpContext"));
        return h(function() {
            var h = g.portableVideoID,
                i = g.portalingPlaceID;
            m != null && (m.setMuted(null), m.setVolume(null));
            if (h != null && i != null) {
                var o = n.pictureInPictureExpConfig.isInPictureInPictureExp,
                    p = n.pictureInPictureExpConfig.isInPictureInPictureExpControlGroup;
                if ((o || p) && b !== d("VideoPlayerWithWatchAndScrollTrigger.react").WatchAndScrollTriggerType.WNS_CONTROL) return;
                l({
                    controller: k,
                    portableVideoID: h,
                    portalingPlaceID: i,
                    routeTracePolicy: j,
                    sessionStartTime: new Date(),
                    sessionTrigger: b,
                    subOrigin: a,
                    videoID: e,
                    videoUrl: f
                })
            } else c("recoverableViolation")("Could not transition to Watch and Scroll player because portableVideoID was null", "comet_video_player")
        }, [g, l, k, j, m, a, b, e, f])
    }
    g.useWatchAndScrollTrigger = a
}), 98);
__d("useSelectedLatencySetting", ["useRelayClientStateWithLocalStorage"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "_video_LiveVideoLatencyMenuContextProvider_selected_latency_setting";

    function i(a) {
        if (a == null) return null;
        switch (a) {
            case "low":
            case "normal":
                return a;
            default:
                return null
        }
    }

    function a(a, b) {
        b = d("useRelayClientStateWithLocalStorage").useRelayClientStateWithLocalStorage(a, h, "selected_latency_setting", (a = i(b)) != null ? a : "normal");
        a = b[0];
        b = b[1];
        return [a, b]
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerHasStartedPlayingAtLeastOnce", ["VideoPlayerHooks", "createVideoStateHook", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect;
    b = d("createVideoStateHook").createVideoStateHook(null);
    var i = b.stateHook;

    function a() {
        var a = i(!1),
            b = a[0],
            c = a[1],
            e = d("VideoPlayerHooks").usePlaying();
        h(function() {
            e && c(!0)
        }, [e, c]);
        return b
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerBigPlayButtonOverlay", ["VideoPlayerHooks", "VideoPlayerPlayButton.react", "VideoPlayerSmallPlayButton.react", "react", "useVideoPlayerHasStartedPlayingAtLeastOnce"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useCallback;

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.buttonSize;
        b = b === void 0 ? "large" : b;
        var e = a.forceVisible,
            f = a.overrideInteraction,
            g = a.shouldUnmute;
        a = c("useVideoPlayerHasStartedPlayingAtLeastOnce")();
        var j = d("VideoPlayerHooks").usePaused(),
            k = d("VideoPlayerHooks").useLastMuteReason(),
            l = d("VideoPlayerHooks").useController(),
            m = i(function() {
                l.play("user_initiated"), g === !0 && k !== "user_initiated" && l.setMuted(!1, "product_initiated")
            }, [l, k, g]);
        f = f != null ? f.handler : m;
        m = e === !0 || e === !1 ? e : !a && j;
        e = b === "small" ? h.jsx(c("VideoPlayerSmallPlayButton.react"), {
            isVisible: m,
            onClick: f
        }) : h.jsx(c("VideoPlayerPlayButton.react"), {
            isVisible: m,
            onClick: f
        });
        return {
            bigPlayButtonElement: e,
            bigPlayButtonIsVisible: m
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerInstreamAdsStateHooks", ["createVideoStateHook"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("createVideoStateHook").createVideoStateHook(),
        i = h.stateHook,
        j = h.valueHook,
        k = [];

    function a() {
        return i(k)
    }

    function b() {
        return j(k)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var l = h.stateHook,
        m = h.valueHook,
        n = null;

    function c() {
        return l(n)
    }

    function e() {
        return m(n)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var o = h.setterHook,
        p = h.valueHook,
        q = !0;

    function f() {
        return o(q)
    }

    function r() {
        return p(q)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var s = h.stateHook,
        t = h.valueHook,
        u = "INIT";

    function v() {
        return s(u)
    }

    function w() {
        return t(u)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var x = h.stateHook,
        y = h.valueHook,
        z = !0;

    function A() {
        return x(z)
    }

    function B() {
        return y(z)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var C = h.stateHook,
        D = h.valueHook,
        E = null;

    function F() {
        return C(E)
    }

    function G() {
        return D(E)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var H = h.stateHook,
        I = h.valueHook,
        J = null;

    function K() {
        return H(J)
    }

    function L() {
        return I(J)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var M = h.stateHook,
        N = h.valueHook,
        O = null;

    function P() {
        return M(O)
    }

    function Q() {
        return N(O)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var R = h.stateHook,
        S = h.valueHook,
        T = null;

    function U() {
        return R(T)
    }

    function aa() {
        return S(T)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var ba = h.stateHook,
        ca = h.valueHook,
        V = null;

    function da() {
        return ba(V)
    }

    function ea() {
        return ca(V)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var fa = h.stateHook,
        ga = h.valueHook,
        W = 0;

    function ha() {
        return fa(W)
    }

    function ia() {
        return ga(W)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var ja = h.stateHook,
        ka = h.valueHook,
        X = !1;

    function la() {
        return ja(X)
    }

    function ma() {
        return ka(X)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var na = h.stateHook,
        oa = h.valueHook,
        Y = !1;

    function pa() {
        return na(Y)
    }

    function qa() {
        return oa(Y)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var ra = h.stateHook,
        sa = h.valueHook,
        Z = null;

    function ta() {
        return ra(Z)
    }

    function ua() {
        return sa(Z)
    }
    h = d("createVideoStateHook").createVideoStateHook();
    var va = h.stateHook,
        wa = h.valueHook,
        $ = null;

    function xa() {
        return va($)
    }

    function ya() {
        return wa($)
    }

    function za() {
        var a = w();
        return a === "STARTING_INDICATOR" || a === "START" || a === "START_AD" || a === "PLAY_NI_VIDEO"
    }
    g.useInstreamAdsMidRollsState = a;
    g.useInstreamAdsMidRollsValue = b;
    g.useInstreamAdsPostRollState = c;
    g.useInstreamAdsPostRollValue = e;
    g.useInstreamAdsPostRollEndedOrSkippedStateSetter = f;
    g.useInstreamAdsPostRollEndedOrSkippedStateValue = r;
    g.useInstreamAdsState = v;
    g.useInstreamAdsStateValue = w;
    g.useInstreamAdsIsEmptyState = A;
    g.useInstreamAdsIsEmptyStateValue = B;
    g.useInstreamAdsCurrentInsertionState = F;
    g.useInstreamAdsCurrentInsertionStateValue = G;
    g.useStartIndicatorBeginningTimeState = K;
    g.useStartIndicatorBeginningTimeStateValue = L;
    g.useAdBreaksTimeOffsetBeginningState = P;
    g.useAdBreaksTimeOffsetBeginningStateValue = Q;
    g.useInstreamAdsExtraFieldsState = U;
    g.useInstreamAdsExtraFieldsStateValue = aa;
    g.useInstreamAdsHideAdBehaviorState = da;
    g.useInstreamAdsHideAdBehaviorStateValue = ea;
    g.useUnifiedSchedulerLastFetchTimeState = ha;
    g.useUnifiedSchedulerLastFetchTimeStateValue = ia;
    g.useWaitingForAdFetchState = la;
    g.useWaitingForAdFetchStateValue = ma;
    g.useInstreamAdsHasCTAState = pa;
    g.useInstreamAdsHasCTAStateValue = qa;
    g.useInstreamAdsFeedContextCardState = ta;
    g.useInstreamAdsFeedContextCardStateValue = ua;
    g.useInstreamAdsFullScreenContextCardState = xa;
    g.useInstreamAdsFullScreenContextCardStateValue = ya;
    g.useInstreamAdsIsStart = za
}), 98);
__d("CometVideoPictureInPictureManagerContext", ["gkx", "qex", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f = d("react").createContext;
    d = f({
        openPipPlayer: function() {},
        setController: function() {},
        setPipPortableVideoID: function() {}
    });
    f = f({
        hasNextChainedVideo: !1,
        isPipEnabled: !1,
        setHasNextChainedVideo: function() {},
        setSkippedFromPipPlayer: function() {},
        skippedFromPipPlayer: !1
    });

    function a() {
        return c("gkx")("3610") || !!c("qex")._("595")
    }

    function b() {
        return !!c("qex")._("830")
    }

    function e() {
        return !!c("qex")._("586")
    }
    g.CometVideoPictureInPictureManagerAPIContext = d;
    g.CometVideoPictureInPictureManagerContext = f;
    g.isInPictureInPictureExp = a;
    g.isInPictureInPictureExpControlGroup = b;
    g.isSkipAndChainingDisabledInPictureInPicture = e
}), 98);
__d("useIsVideoHomePlayerOriginFromTracePolicy", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = ["comet.watch.catalog", "comet.watch.explore", "comet.watch.feed", "comet.watch.injection", "comet.watch.latest", "comet.watch.notifications", "comet.watch.playlist", "comet.watch.saved", "comet.watch.search", "comet.watch.sports", "comet.watch.live.injection", "comet.watch.live", "comet.watch.music", "comet.watch.lancelet"];
        return b.includes(a)
    }
    f["default"] = a
}), 66);
__d("CometWatchAndScrollControlNUXContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = {
        isVideoPlayerWatchAndScrollControlNUXVisible: !1,
        setIsVideoPlayerWatchAndScrollControlNUXVisible: null
    };
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("AsyncTypedRequest", ["AsyncRequest"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            b = a.call(this, b) || this;
            b.setReplaceTransportMarkers();
            return b
        }
        var c = b.prototype;
        c.promisePayload = function(b) {
            return a.prototype.promisePayload.call(this, b)
        };
        c.setPayloadHandler = function(b) {
            a.prototype.setPayloadHandler.call(this, b);
            return this
        };
        return b
    }(c("AsyncRequest"));
    g["default"] = a
}), 98);
__d("OzWidevineDrmProvider", ["ConstUriUtils", "FBLogger", "oz-player/drm/OzDrmUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b, e, f, g) {
            this.$2 = [];
            this.$4 = !0;
            this.$5 = !1;
            g != null && g !== "" && (this.$1 = d("oz-player/drm/OzDrmUtils").base64ToUint8Array(g));
            if (b != null && f != null) {
                b = (g = d("ConstUriUtils").getUri(b)) == null ? void 0 : g.addQueryParam("access_token", f);
                if (b == null) throw c("FBLogger")("comet_video_player").mustfixThrow("Invalid Graph API license uri for video: %s", a);
                this.$3 = b.toString();
                this.$5 = !0;
                this.$4 = !1
            } else {
                g = e["0"];
                if (g == null) {
                    g = "/video/drm/getlicense";
                    b = (f = d("ConstUriUtils").getUri(g)) == null ? void 0 : f.addQueryParam("video_id", a);
                    if (b == null) throw c("FBLogger")("comet_video_player").mustfixThrow("Invalid server license uri for video: %s", a);
                    this.$3 = b.toString()
                } else this.$3 = g
            }
        }
        var b = a.prototype;
        b.getKeySystem = function() {
            return "com.widevine.alpha"
        };
        b.getSchemeId = function() {
            return "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"
        };
        b.getInitDatas = function() {
            return this.$2
        };
        b.setInitDatas = function(a) {
            this.$2 = a
        };
        b.getRequireDistinctiveIdentifier = function() {
            return "optional"
        };
        b.getRequirePersistentState = function() {
            return "optional"
        };
        b.getInitDataTypes = function() {
            return
        };
        b.getDrmSessionTypes = function() {
            return ["temporary"]
        };
        b.getAudioRobustness = function() {
            return ""
        };
        b.getVideoRobustness = function() {
            return ""
        };
        b.getServerCertificate = function() {
            return this.$1
        };
        b.getLicenseRequestInfo = function(a) {
            var b = {
                url: this.$3,
                method: "POST",
                body: "",
                headers: {},
                credentials: void 0
            };
            this.$4 && (b.credentials = "include");
            a = d("oz-player/drm/OzDrmUtils").arrayBufferToBase64(a);
            if (this.$5) {
                var c = {
                    request: a
                };
                b.body = JSON.stringify(c);
                b.headers["Content-Type"] = "application/json"
            } else b.body = a, b.headers["Content-Type"] = "application/text";
            return b
        };
        b.parseLicenseResponse = function(a) {
            a = String.fromCharCode.apply(null, a);
            var b;
            try {
                b = JSON.parse(a)
            } catch (a) {
                b = void 0
            }
            var c;
            if (b !== void 0 && b.data !== void 0 && b.data.length === 1) {
                b = b.data[0];
                b.error != null || (c = b.license)
            } else c = a;
            if (c != null && c !== "") try {
                return d("oz-player/drm/OzDrmUtils").base64ToUint8Array(c)
            } catch (a) {
                if (a.name === "InvalidCharacterError") throw new Error("Endpoint returned error: " + c);
                else throw a
            }
            return null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("HTML5OzDrmHelper", ["OzWidevineDrmProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        OzWidevineDrmProviderModule: c("OzWidevineDrmProvider")
    };
    b = a;
    g["default"] = b
}), 98);
__d("WebPerfDeviceInfoLogFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1871697");
    c = b("FalcoLoggerInternal").create("web_perf_device_info_log", a);
    e.exports = c
}), null);
__d("XDeviceClassRealtimeController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/web_perf/get_perf_level/", {})
}), null);
__d("WebDevicePerfInfoLogging", ["AsyncTypedRequest", "JSScheduler", "Promise", "WebDevicePerfInfoData", "WebPerfDeviceInfoLogFalcoEvent", "XDeviceClassRealtimeController", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = document.createElement("canvas");
        b = b.getContext("webgl") || b.getContext("experimental-webgl");
        if (!b) return;
        var c = b.getExtension("WEBGL_debug_renderer_info");
        if (!c) return;
        var d = b.getParameter(c.UNMASKED_RENDERER_WEBGL);
        b = b.getParameter(c.UNMASKED_VENDOR_WEBGL);
        a.gpu_vendor = b;
        a.gpu_renderer = d
    }

    function i() {
        var a = window.navigator,
            b = {};
        a && a.hardwareConcurrency !== void 0 && (b.cpu_cores = a.hardwareConcurrency);
        a && a.deviceMemory !== void 0 && (b.ram = a.deviceMemory);
        c("WebDevicePerfInfoData").needsFullUpdate && h(b);
        return b
    }

    function j() {
        var a = i();
        c("WebPerfDeviceInfoLogFalcoEvent").log(function() {
            var b;
            return {
                cpu_cores: (b = a.cpu_cores) != null ? b : null,
                ram: (b = a.ram) != null ? b : null,
                gpu_renderer: (b = a.gpu_renderer) != null ? b : null,
                gpu_vendor: (b = a.gpu_vendor) != null ? b : null
            }
        })
    }

    function k() {
        var a, d;
        return b("regeneratorRuntime").async(function(e) {
            while (1) switch (e.prev = e.next) {
                case 0:
                    a = i();
                    e.next = 3;
                    return b("regeneratorRuntime").awrap(new(c("AsyncTypedRequest"))(c("XDeviceClassRealtimeController").getURIBuilder().getURI()).setData(a).promisePayload());
                case 3:
                    d = e.sent;
                    return e.abrupt("return", d.devicePerfClassLevel);
                case 5:
                case "end":
                    return e.stop()
            }
        }, null, this)
    }

    function a() {
        (c("WebDevicePerfInfoData").needsFullUpdate || c("WebDevicePerfInfoData").needsPartialUpdate) && d("JSScheduler").scheduleSpeculativeCallback(j)
    }

    function e() {
        return new(b("Promise"))(function(a, b) {
            c("WebDevicePerfInfoData").needsFullUpdate || c("WebDevicePerfInfoData").needsPartialUpdate ? d("JSScheduler").scheduleSpeculativeCallback(function() {
                k().then(a)["catch"](b)
            }) : a()
        })
    }
    g.doLog = a;
    g.doLogPromise = e
}), 98);
__d("isEmptyObject", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        for (var a in a) return !1;
        return !0
    }
    f["default"] = a
}), 66);
__d("EmoticonsList", [], (function(a, b, c, d, e, f) {
    e.exports = {
        emotes: {
            "O:)": "angel",
            "O:-)": "angel",
            "0:)": "angel",
            "0:-)": "angel",
            "'-_-": "coldsweat",
            ":3": "colonthree",
            "o.O": "confused",
            O_O: "confused",
            o_o: "confused",
            "0_0": "confused",
            "O.o": "confused_rev",
            ":'(": "cry",
            ":'-(": "cry",
            "3:)": "devil",
            "3:-)": "devil",
            ":dog:": "dog",
            "-3-": "flushkiss",
            ":(": "frown",
            ":-(": "frown",
            ":[": "frown",
            "=(": "frown",
            ")=": "frown",
            ":o": "gasp",
            ":-O": "gasp",
            ":O": "gasp",
            ":-o": "gasp",
            "8-)": "glasses",
            "B-)": "glasses",
            "=D": "grin",
            ":-D": "grin",
            ":D": "grin",
            ">:(": "grumpy",
            ">:-(": "grumpy",
            "<3": "heart",
            "&lt;3": "heart",
            "^_^": "kiki",
            "^~^": "kiki",
            ":*": "kiss",
            ":-*": "kiss",
            "(y)": "like",
            ":like:": "like",
            "(Y)": "like",
            T_T: "loudly_crying",
            "T-T": "loudly_crying",
            ToT: "loudly_crying",
            "T.T": "loudly_crying",
            ":-|": "neutral",
            ":|": "neutral",
            ":v": "pacman",
            ":V": "pacman",
            '<(")': "penguin",
            ">_<": "persevere",
            ">.<": "persevere",
            ":poop:": "poop",
            ":|]": "robot",
            "(^^^)": "shark",
            ":)": "smile",
            ":-)": "smile",
            ":]": "smile",
            "(:": "smile",
            "=)": "smilingface",
            "(=": "smilingface",
            "-_-": "squint",
            "B|": "sunglasses",
            "8-|": "sunglasses",
            "8|": "sunglasses",
            "B-|": "sunglasses",
            "8)": "sunglasses",
            "(n)": "thumbsdown",
            "(N)": "thumbsdown",
            ":+1:": "thumbsup",
            ":thumbsup:": "thumbsup",
            ":P": "tongue",
            ":-P": "tongue",
            ":-p": "tongue",
            ":p": "tongue",
            "=P": "tongue",
            ":trans:": "transflag",
            ":/": "unsure",
            ":-/": "unsure",
            ":\\": "unsure",
            ":-\\": "unsure",
            "=/": "unsure",
            "=\\": "unsure",
            ">:o": "upset",
            ">:O": "upset",
            ">:-O": "upset",
            ">:-o": "upset",
            ";)": "wink",
            ";-)": "wink",
            ";*": "winkkiss",
            ";-*": "winkkiss",
            ";-P": "winktongue",
            ";P": "winktongue",
            ";-p": "winktongue",
            ";p": "winktongue",
            ":cheese:": "cheesewedge",
            ":eyes:": "eyes",
            ":peek:": "eyes",
            ":clown:": "clown"
        },
        symbols: {
            angel: "O:)",
            coldsweat: "'-_-",
            colonthree: ":3",
            confused: "o.O",
            confused_rev: "O.o",
            cry: ":'(",
            devil: "3:)",
            dog: ":dog:",
            flushkiss: "-3-",
            frown: ":(",
            gasp: ":o",
            glasses: "8-)",
            grin: "=D",
            grumpy: ">:(",
            heart: "<3",
            kiki: "^_^",
            kiss: ":*",
            like: "(y)",
            loudly_crying: "T_T",
            neutral: ":-|",
            pacman: ":v",
            penguin: '<(")',
            persevere: ">_<",
            poop: ":poop:",
            robot: ":|]",
            shark: "(^^^)",
            smile: ":)",
            smilingface: "=)",
            squint: "-_-",
            sunglasses: "B|",
            thumbsdown: "(n)",
            thumbsup: ":+1:",
            tongue: ":P",
            transflag: ":trans:",
            unsure: ":/",
            upset: ">:o",
            wink: ";)",
            winkkiss: ";*",
            winktongue: ";-P",
            cheesewedge: ":cheese:",
            eyes: ":eyes:",
            clown: ":clown:"
        },
        emoji: {
            angel: "1f607",
            coldsweat: "1f613",
            colonthree: "FACE_WITH_COLON_THREE",
            confused: "1f633",
            confused_rev: "1f633",
            cry: "1f622",
            devil: "1f608",
            dog: "1f436",
            flushkiss: "1f61a",
            frown: "1f641",
            gasp: "1f62e",
            glasses: "1f913",
            grin: "1f603",
            grumpy: "1f620",
            heart: "2764",
            kiki: "1f60a",
            kiss: "1f618",
            like: "LIKE",
            loudly_crying: "1f62d",
            neutral: "1f610",
            pacman: "PACMAN",
            penguin: "1f427",
            persevere: "1f623",
            poop: "1f4a9",
            robot: "1f916",
            shark: "1f988",
            smile: "1f642",
            smilingface: "1f60a",
            squint: "1f611",
            sunglasses: "1f60e",
            thumbsdown: "1f44e",
            thumbsup: "1f44d",
            tongue: "1f61b",
            transflag: "1f3f3_fe0f_200d_26a7_fe0f",
            unsure: "1f615",
            upset: "1f620",
            wink: "1f609",
            winkkiss: "1f618",
            winktongue: "1f61c",
            cheesewedge: "1f9c0",
            eyes: "1f440",
            clown: "1f921"
        },
        regexp: /(^|[\s\'\".\(])(O:\)(?!\))|O:\-\)(?!\))|0:\)(?!\))|0:\-\)(?!\))|\'\-_\-|:3|o\.O|O_O|o_o|0_0|O\.o|:\'\(|:\'\-\(|3:\)(?!\))|3:\-\)(?!\))|:dog:|\-3\-|:\(|:\-\(|:\[|=\(|\)=|:o|:\-O|:O|:\-o|8\-\)(?!\))|B\-\)(?!\))|=D|:\-D|:D|>:\(|>:\-\(|<3|&lt;3|\^_\^|\^~\^|:\*|:\-\*|\(y\)(?!\))|:like:|\(Y\)(?!\))|T_T|T\-T|ToT|T\.T|:\-\||:\||:v|:V|<\(\"\)(?!\))|>_<|>\.<|:poop:|:\|\]|\(\^\^\^\)(?!\))|:\)(?!\))|:\-\)(?!\))|:\]|\(:|=\)(?!\))|\(=|\-_\-|B\||8\-\||8\||B\-\||8\)(?!\))|\(n\)(?!\))|\(N\)(?!\))|:\+1:|:thumbsup:|:P|:\-P|:\-p|:p|=P|:trans:|:\/|:\-\/|:\\|:\-\\|=\/|=\\|>:o|>:O|>:\-O|>:\-o|;\)(?!\))|;\-\)(?!\))|;\*|;\-\*|;\-P|;P|;\-p|;p|:cheese:|:eyes:|:peek:|:clown:)([\s\'\".,!?\)]|<br>|$)/,
        noncapturingRegexp: /(?:^|[\s\'\".\(])(O:\)(?!\))|O:\-\)(?!\))|0:\)(?!\))|0:\-\)(?!\))|\'\-_\-|:3|o\.O|O_O|o_o|0_0|O\.o|:\'\(|:\'\-\(|3:\)(?!\))|3:\-\)(?!\))|:dog:|\-3\-|:\(|:\-\(|:\[|=\(|\)=|:o|:\-O|:O|:\-o|8\-\)(?!\))|B\-\)(?!\))|=D|:\-D|:D|>:\(|>:\-\(|<3|&lt;3|\^_\^|\^~\^|:\*|:\-\*|\(y\)(?!\))|:like:|\(Y\)(?!\))|T_T|T\-T|ToT|T\.T|:\-\||:\||:v|:V|<\(\"\)(?!\))|>_<|>\.<|:poop:|:\|\]|\(\^\^\^\)(?!\))|:\)(?!\))|:\-\)(?!\))|:\]|\(:|=\)(?!\))|\(=|\-_\-|B\||8\-\||8\||B\-\||8\)(?!\))|\(n\)(?!\))|\(N\)(?!\))|:\+1:|:thumbsup:|:P|:\-P|:\-p|:p|=P|:trans:|:\/|:\-\/|:\\|:\-\\|=\/|=\\|>:o|>:O|>:\-O|>:\-o|;\)(?!\))|;\-\)(?!\))|;\*|;\-\*|;\-P|;P|;\-p|;p|:cheese:|:eyes:|:peek:|:clown:)(?:[\s\'\".,!?\)]|<br>|$)/
    }
}), null);
__d("CommerceTabFeedImpressionFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("2315");
    c = b("FalcoLoggerInternal").create("commerce_tab_feed_impression", a);
    e.exports = c
}), null);