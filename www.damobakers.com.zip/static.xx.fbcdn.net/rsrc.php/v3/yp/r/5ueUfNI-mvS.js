if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometImageFromIXValueRelayWrapper_sprite.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "CometImageFromIXValueRelayWrapper_sprite",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "sprited",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "sprite_map_css_class",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "sprite_css_class",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "preloading_spi",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "w",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "h",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "p",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "sz",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "spi",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "uri",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "width",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "height",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "logging_id",
            storageKey: null
        }],
        type: "XFBIXMapEntry",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("CometGlobalPanelEMCopresence.relayprovider", ["CometGlobalPanelGating.entrypointutils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        get: function() {
            return d("CometGlobalPanelGating.entrypointutils").isCommunityPanelEMCopresenceEnabled()
        }
    };
    g["default"] = a
}), 98);
__d("GlobalPanelEnabled.relayprovider", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        get: function() {
            return Boolean(c("qex")._("19"))
        }
    };
    g["default"] = a
}), 98);
__d("CometHovercardQueryRendererQuery$Parameters", ["CometGlobalPanelEMCopresence.relayprovider", "GlobalPanelEnabled.relayprovider"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: "6304732502874815",
            metadata: {},
            name: "CometHovercardQueryRendererQuery",
            operationKind: "query",
            text: null,
            providedVariables: {
                __relay_internal__pv__GlobalPanelEnabledrelayprovider: b("GlobalPanelEnabled.relayprovider"),
                __relay_internal__pv__CometGlobalPanelEMCopresencerelayprovider: b("CometGlobalPanelEMCopresence.relayprovider")
            }
        }
    };
    e.exports = a
}), null);
__d("CometAccessibilityAnnouncement.react", ["cr:1465733", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useRef;

    function a(a) {
        var c = a.assertive;
        c = c === void 0 ? !1 : c;
        var d = a.children;
        d = d === void 0 ? null : d;
        var e = a.isVisible;
        e = e === void 0 ? !1 : e;
        a = a.role;
        a = a === void 0 ? "alert" : a;
        var f = i(null);
        b("cr:1465733")({
            assertive: c,
            nodeRef: f
        });
        return h.jsx("div", {
            "aria-atomic": !0,
            "aria-live": c ? "assertive" : "polite",
            className: e === !1 ? "x1i1rx1s x10l6tqk x10wlt62 x6ikm8r xjm9jq1 x1hyvwdk xzpqnlu" : null,
            ref: f,
            role: a,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometGlobalPanelExpandedState", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["Collapsed", "Collapsing", "Expanded", "Expanding"]);
    f.ExpandedState = a
}), 66);
__d("CometGlobalPanelExpandedContext", ["CometGlobalPanelExpandedState", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(d("CometGlobalPanelExpandedState").ExpandedState.Collapsed);
    g["default"] = b
}), 98);
__d("HovercardInteractionPreference", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        DISABLED: 1,
        ENABLED_ON_HOVER: 2,
        ENABLED_ON_CLICK: 3
    });
    c = a;
    f["default"] = c
}), 66);
__d("CometHovercardSettingsContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        hovercardInteractionPreference: 2,
        setHovercardInteractionPreference: c("emptyFunction")
    });
    g["default"] = b
}), 98);
__d("CometAppNavigationConstants", ["Env", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = null;
    b = 56;
    d = 44;
    switch (!0) {
        case c("Env").isCometOnMobile:
            a = c("gkx")("976093") ? b : d;
            break;
        case c("Env").isMessengerDotComOnComet:
            a = 0;
            break;
        default:
            a = b
    }
    e = a;
    f = 60;
    d = 300;
    c = {
        bounciness: 1,
        speed: 20
    };
    b = 1099 + f;
    g.HEADER_HEIGHT = e;
    g.GLOBAL_PANEL_WIDTH = f;
    g.GLOBAL_PANEL_WIDTH_EXPANDED = d;
    g.GLOBAL_PANEL_EXPAND_SPRING_CONFIG = c;
    g.MAX_VIEWPORT_WIDTH_GLOBAL_PANEL_EXPANDED = b
}), 98);
__d("usePartialViewImpression", ["useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.onImpressionEnd;
        a = a.onImpressionStart;
        return c("useVisibilityObserver")({
            onHidden: b,
            onVisible: a,
            options: {
                hiddenWhenCSSStyleHidden: !0,
                hiddenWhenZeroArea: !0
            }
        })
    }
    g["default"] = a
}), 98);
__d("CometNUXTourConsumerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useCometVisualChangeTracker", ["cr:683059", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c = d("react");
    var h = c.useCallback,
        i = c.useEffect,
        j = c.useRef;

    function a() {
        var a = j(null),
            c = j(null);
        i(function() {
            return function() {
                c.current && c.current(), c.current = null, a.current = null
            }
        }, []);
        return h(function(d) {
            if (a.current !== d) {
                c.current && (c.current(), c.current = null);
                a.current = d;
                if (d && b("cr:683059")) {
                    var e = b("cr:683059").getCurrentNavigationTrace();
                    e && (c.current = e.addMutationRoot(d))
                }
            }
        }, [])
    }
    g["default"] = a
}), 98);
__d("CometEntryPointPopoverContainer.react", ["CometRelay", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useLayoutEffect,
        j = b.useMemo;

    function a(a) {
        a.entryPointParams;
        var b = a.entryPointReference,
            c = a.load,
            e = a.otherProps,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["entryPointParams", "entryPointReference", "load", "otherProps"]);
        a = j(function() {
            return babelHelpers["extends"]({}, e, f)
        }, [e, f]);
        i(function() {
            b == null && c()
        }, [b, c]);
        return b == null ? null : h.jsx(d("CometRelay").EntryPointContainer, {
            entryPointReference: b,
            props: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("isPrimitive", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (Object.prototype.toString.call(a)) {
            case "[object String]":
            case "[object Number]":
            case "[object Boolean]":
            case "[object Null]":
            case "[object Undefined]":
                return !0
        }
        return !1
    }
    f["default"] = a
}), 66);
__d("deepEquals", ["isPrimitive"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
            return function(b, c) {
                return l(b, a[c])
            }
        },
        i = function(a, b) {
            return function(c) {
                return c in a && c in b && l(a[c], b[c])
            }
        },
        j = function(a, b) {
            if (a.size !== b.size) return !1;
            b = new Set(b);
            for (var a = a.keys(), d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                if (b.has(f)) b["delete"](f);
                else if (c("isPrimitive")(f)) return !1;
                else {
                    f = k(b, f);
                    if (f != null) b["delete"](f);
                    else return !1
                }
            }
            return b.size === 0
        };

    function k(a, b) {
        for (var a = a, c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var e;
            if (c) {
                if (d >= a.length) break;
                e = a[d++]
            } else {
                d = a.next();
                if (d.done) break;
                e = d.value
            }
            e = e;
            if (l(e, b)) return e
        }
        return null
    }

    function l(a, b) {
        if (a === b) return !0;
        if (c("isPrimitive")(a)) return !1;
        if (Object.prototype.toString.call(a) !== Object.prototype.toString.call(b)) return !1;
        if (Array.isArray(a)) return a.length === b.length && a.every(h(b));
        if (a instanceof Set) return j(a, b);
        var d = Object.keys(a);
        return d.length !== Object.keys(b).length ? !1 : d.every(i(a, b))
    }
    g["default"] = l
}), 98);
__d("CometEntryPointPopoverTrigger.react", ["BasePopoverTrigger.react", "CometEntryPointPopoverContainer.react", "CometPopoverLoadingState.react", "CometRelay", "deepEquals", "react", "tracePolicyFromResource", "useCometPopoverInteractionTracing", "useCometRelayEntrypointContextualEnvironmentProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo,
        k = b.useRef;

    function a(a) {
        var b = a.doNotCloseOnOutsideClick,
            e = a.entryPointParams,
            f = a.fallback,
            g = a.onVisibilityChange,
            l = a.otherProps,
            m = a.popoverEntryPoint,
            n = a.preloadTrigger,
            o = a.tracePolicy;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["doNotCloseOnOutsideClick", "entryPointParams", "fallback", "onVisibilityChange", "otherProps", "popoverEntryPoint", "preloadTrigger", "tracePolicy"]);
        o = c("useCometPopoverInteractionTracing")((o = o) != null ? o : c("tracePolicyFromResource")("comet.popover", m.root), "entrypoint", n);
        var p = c("useCometRelayEntrypointContextualEnvironmentProvider")();
        p = d("CometRelay").useEntryPointLoader(p, m);
        var q = p[0],
            r = p[1];
        p = p[2];
        var s = k(null),
            t = i(function() {
                if (e == null) return;
                if (q !== null && c("deepEquals")(s.current, e)) return;
                s.current = e;
                r(e)
            }, [e, q, r]),
            u = j(function() {
                return {
                    entryPointParams: e,
                    entryPointReference: q,
                    load: t,
                    otherProps: l
                }
            }, [e, q, t, l]),
            v = i(function() {
                (arguments.length <= 0 ? void 0 : arguments[0]) && t(), g && g.apply(void 0, arguments)
            }, [t, g]);
        return h.jsx(c("BasePopoverTrigger.react"), babelHelpers["extends"]({
            doNotCloseOnOutsideClick: b,
            fallback: (b = f) != null ? b : h.jsx(c("CometPopoverLoadingState.react"), {
                withArrow: !0
            }),
            interactionTracker: o,
            onHighIntentPreload: t,
            onLayerDetached: p,
            onVisibilityChange: v,
            popover: c("CometEntryPointPopoverContainer.react"),
            popoverPreloadResource: m.root,
            popoverProps: u,
            preloadTrigger: n
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometImageFromIXValueRelayWrapper.react", ["CometImageFromIXValue.react", "CometImageFromIXValueRelayWrapper_sprite.graphql", "CometRelay", "RecoverableViolationWithComponentStack.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");

    function a(a, e) {
        a = a.sprite;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("CometImageFromIXValueRelayWrapper_sprite.graphql"), a);
        var f = a.h,
            g = a.height,
            j = a.logging_id,
            k = a.p,
            l = a.preloading_spi,
            m = a.spi,
            n = a.sprite_css_class,
            o = a.sprite_map_css_class,
            p = a.sprited,
            q = a.sz,
            r = a.uri,
            s = a.w;
        a = a.width;
        var t = null;
        if (p === 0) t = {
            height: g,
            loggingID: j,
            sprited: p,
            uri: r,
            width: a
        };
        else if (p === 1) t = {
            _spi: l,
            loggingID: j,
            spriteCssClass: n,
            sprited: p,
            spriteMapCssClass: o
        };
        else if (p === 2) t = {
            h: f,
            loggingID: j,
            p: k,
            spi: m,
            sprited: p,
            sz: q,
            w: s
        };
        else return i.jsx(c("RecoverableViolationWithComponentStack.react"), {
            errorMessage: "asset fetched from graphql via CometImageFromIXValueRelay that doesn't match expected any known sprited icons",
            projectName: "comet_ui"
        });
        return i.jsx(c("CometImageFromIXValue.react"), {
            ref: e,
            source: t
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = i.forwardRef(a);
    g["default"] = e
}), 98);
__d("TetraProfilePhoto.react", ["CometProfilePhoto.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        return h.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometFocusTableContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        FocusCell: null,
        FocusRow: null,
        FocusTable: null
    });
    g["default"] = b
}), 98);
__d("BaseSwitch.react", ["BaseFocusRing.react", "BaseInput.react", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            "switch": {
                cursor: "x1ypdohk",
                height: "x5yr21d",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r",
                opacity: "x1w3u9th",
                outline: "x1a2a7pz",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy",
                width: "xh8yej3"
            },
            wrapper: {
                position: "x1n2onr6"
            }
        };

    function a(a, b) {
        var d = a.children,
            e = a.suppressFocusRing,
            f = a.testid,
            g = a.xstyle,
            j = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "suppressFocusRing", "testid", "xstyle"]);
        return h.jsx(c("BaseFocusRing.react"), {
            suppressFocusRing: e,
            children: function(a) {
                return h.jsxs(c("BaseView.react"), {
                    testid: void 0,
                    xstyle: [i.wrapper, a, g],
                    children: [d, h.jsx(c("BaseInput.react"), babelHelpers["extends"]({}, j, {
                        "aria-checked": (a = j.checked) != null ? a : !1,
                        ref: b,
                        role: "switch",
                        type: "checkbox",
                        xstyle: i["switch"]
                    }))]
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.memo(h.forwardRef(a));
    g["default"] = b
}), 98);
__d("BaseStyledSwitch.react", ["BaseRow.react", "BaseRowItem.react", "BaseSwitch.react", "BaseView.react", "Locale", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("Locale").isRTL(),
        j = {
            alignIcon: {
                alignItems: "x6s0dn4"
            },
            background: {
                backgroundColor: "x1bc5xmc",
                bottom: "x1ey2m1c",
                boxSizing: "x9f619",
                end: "xds687c",
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy",
                transitionDuration: "x1eub6wo",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1d72o"
            },
            backgroundActive: {
                opacity: "x1hc1fzr",
                transitionDuration: "xii2z7h",
                transitionTimingFunction: "x1r7x56h"
            },
            disabled: {
                opacity: "xti2d7y",
                transitionDuration: "xii2z7h",
                transitionTimingFunction: "x1r7x56h"
            },
            innerShadow: {
                borderTopStartRadius: "xhw592a",
                borderTopEndRadius: "xwihvcr",
                borderBottomEndRadius: "x7wuybg",
                borderBottomStartRadius: "xb9tvrk",
                boxShadow: "xzdp66v",
                height: "x1fgtraw",
                width: "xvni27"
            },
            slider: {
                backgroundColor: "x14hiurz",
                borderTopStartRadius: "xyi19xy",
                borderTopEndRadius: "x1ccrb07",
                borderBottomEndRadius: "xtf3nb5",
                borderBottomStartRadius: "x1pc53ja",
                boxShadow: "x3bazc0",
                height: "xxk0z11",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                start: "xb1c2wi",
                top: "xs7f9wi",
                transitionDuration: "x1eub6wo",
                transitionProperty: "x11xpdln",
                transitionTimingFunction: "x1d72o",
                width: "xvy4d1p"
            },
            sliderActive: {
                transitionDuration: "xii2z7h",
                transitionTimingFunction: "x1r7x56h"
            },
            sliderActiveLeft: {
                transform: "x92xnlw"
            },
            sliderActiveLeftSmall: {
                transform: "x13gy369"
            },
            sliderActiveRight: {
                transform: "x13t98kf"
            },
            sliderActiveRightSmall: {
                transform: "x13n5tbt"
            },
            sliderIconContainer: {
                height: "x5yr21d",
                width: "xh8yej3"
            },
            sliderSmall: {
                height: "x1qx5ct2",
                width: "xw4jnvo"
            },
            "switch": {
                backgroundColor: "x14nfmen",
                borderTopStartRadius: "xhw592a",
                borderTopEndRadius: "xwihvcr",
                borderBottomEndRadius: "x7wuybg",
                borderBottomStartRadius: "xb9tvrk",
                boxSizing: "x9f619",
                display: "x1rg5ohu",
                height: "x1fgtraw",
                opacity: "x1hc1fzr",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                position: "x1n2onr6",
                transitionDuration: "x1eub6wo",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1d72o",
                width: "xvni27"
            },
            switchSmall: {
                borderTopStartRadius: "xyi19xy",
                borderTopEndRadius: "x1ccrb07",
                borderBottomEndRadius: "xtf3nb5",
                borderBottomStartRadius: "x1pc53ja",
                height: "xxk0z11",
                width: "x187nhsf"
            }
        };

    function a(a, b) {
        var d, e = a.disabled;
        e = e === void 0 ? !1 : e;
        var f = a.icon,
            g = a.onClick,
            k = a.onValueChange,
            l = a.size;
        l = l === void 0 ? "medium" : l;
        var m = a.suppressFocusRing,
            n = a.tabIndex,
            o = a.testid;
        o = a.value;
        var p = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["disabled", "icon", "onClick", "onValueChange", "size", "suppressFocusRing", "tabIndex", "testid", "value", "xstyle"]);
        l = l === "small";
        return h.jsx(c("BaseSwitch.react"), babelHelpers["extends"]({}, a, {
            checked: o,
            disabled: e,
            onClick: g,
            onValueChange: k,
            ref: b,
            suppressFocusRing: m,
            tabIndex: n,
            testid: void 0,
            xstyle: [j["switch"], l && j.switchSmall, e && j.disabled, p],
            children: h.jsxs(c("BaseView.react"), {
                xstyle: [j.innerShadow, l && j.switchSmall, p],
                children: [h.jsx(c("BaseView.react"), {
                    xstyle: [j.background, o && j.backgroundActive]
                }), h.jsx(c("BaseView.react"), {
                    xstyle: [j.slider, l && j.sliderSmall, o && j.sliderActive, o && (i ? [j.sliderActiveLeft, l && j.sliderActiveLeftSmall] : [j.sliderActiveRight, l && j.sliderActiveRightSmall])],
                    children: f == null ? null : h.jsx(c("BaseRow.react"), {
                        align: "center",
                        expanding: !0,
                        verticalAlign: "center",
                        xstyle: j.sliderIconContainer,
                        children: h.jsx(c("BaseRowItem.react"), {
                            expanding: !0,
                            verticalAlign: "center",
                            xstyle: j.alignIcon,
                            children: f
                        })
                    })
                })]
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("useCometLazyDialog", ["CometDialogContext", "CometDialogLoadingState.react", "CometSuspendedDialogImpl.react", "lazyLoadComponent", "react", "tracePolicyFromResource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = c("react"),
        i = b.useCallback,
        j = b.useContext,
        k = function(a) {
            return h.jsx(c("CometDialogLoadingState.react"), {
                onClose: a
            })
        };

    function a(a, b) {
        var d = j(c("CometDialogContext")),
            e = i(function(e, f) {
                var g = c("lazyLoadComponent")(a);
                d(c("CometSuspendedDialogImpl.react"), {
                    dialog: g,
                    dialogProps: e,
                    fallback: (g = b) != null ? g : k
                }, {
                    loadType: "lazy",
                    tracePolicy: c("tracePolicyFromResource")("comet.dialog", a)
                }, f)
            }, [d, a, b]),
            f = i(function() {
                a.preload()
            }, [a]);
        return [e, f]
    }
    g["default"] = a
}), 98);
__d("CometSwitch.react", ["BaseStyledSwitch.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            toggle: {
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "x4vbgl9",
                marginStart: "x1mh8g0r"
            }
        };

    function a(a, b) {
        var d, e = a.children,
            f = a.disabled;
        f = f === void 0 ? !1 : f;
        var g = a.size;
        g = g === void 0 ? "medium" : g;
        var j = a.testid;
        j = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "disabled", "size", "testid", "xstyle"]);
        return h.jsx(c("BaseStyledSwitch.react"), babelHelpers["extends"]({}, a, {
            "aria-label": e,
            disabled: f,
            ref: b,
            size: g,
            testid: void 0,
            xstyle: [i.toggle, j]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometHovercardQueryRenderer.entrypoint", ["CometHovercardQueryRendererQuery$Parameters", "JSResourceForInteraction", "WebPixelRatio", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            var e = a.actionBarRenderLocation,
                f = a.context,
                g = a.entityID;
            a = a.groupID;
            return {
                queries: {
                    hovercardQueryReference: {
                        parameters: b("CometHovercardQueryRendererQuery$Parameters"),
                        variables: {
                            actionBarRenderLocation: e,
                            context: f,
                            entityID: g,
                            groupID: a,
                            includeTdaInfo: c("gkx")("4427"),
                            scale: d("WebPixelRatio").get()
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("CometHovercardQueryRenderer.react").__setRef("CometHovercardQueryRenderer.entrypoint")
    };
    g["default"] = a
}), 98);
__d("CometBackgroundImage.react", ["CometImage.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            root: {
                height: "x5yr21d",
                objectFit: "xl1xv1r",
                width: "xh8yej3"
            }
        };

    function a(a) {
        return h.jsx(c("CometImage.react"), {
            alt: a.alt,
            draggable: a.draggable,
            loading: a.loading || void 0,
            objectFit: "cover",
            onError: a.onError,
            onLoad: a.onLoad,
            src: a.src,
            xstyle: i.root
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometCard.react", ["BaseView.react", "isBlueprintStylesEnabled", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            "base-wash": {
                backgroundColor: "x1vtvx1t"
            },
            "card-flat": {
                backgroundColor: "xlhe6ec"
            },
            "dark-wash": {
                backgroundColor: "xatbrnm"
            },
            error: {
                backgroundColor: "x1ciooss"
            },
            highlight: {
                backgroundColor: "xwnonoy"
            },
            "light-wash": {
                backgroundColor: "x443n21"
            },
            transparent: {
                backgroundColor: "xjbqb8w"
            },
            white: {
                backgroundColor: "x2bj2ny"
            }
        },
        j = {
            borderHighlightAnimation: {
                animationDuration: "x1q3qbx4",
                animationFillMode: "x1u6ievf",
                animationName: "x1raiwjw",
                animationTimingFunction: "x11wifem"
            },
            borderHighlightOverlay: {
                borderTop: "x1nqgybo",
                borderEnd: "x12eorn",
                borderBottom: "xsclsaf",
                borderStart: "x768y1r",
                borderTopStartRadius: "x1a2cdl4",
                borderTopEndRadius: "xnhgr82",
                borderBottomEndRadius: "x1qt0ttw",
                borderBottomStartRadius: "xgk8upj",
                bottom: "x1t1qrwb",
                end: "x15jmxi0",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                start: "x1uvgrom",
                top: "x1qiirwl",
                zIndex: "x1vjfegm"
            },
            borderInset: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                bottom: "x1ey2m1c",
                boxShadow: "xlg9a9y",
                boxSizing: "x9f619",
                end: "xds687c",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy"
            },
            borderOnWash: {
                borderTopColor: "x8cjs6t",
                borderEndColor: "x1ch86jh",
                borderBottomColor: "x80vd3b",
                borderStartColor: "xckqwgs"
            },
            borderOnWhite: {
                borderTopColor: "x8cjs6t",
                borderEndColor: "x1ch86jh",
                borderBottomColor: "x80vd3b",
                borderStartColor: "xckqwgs"
            },
            borderSolid: {
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "x178xt8z",
                borderEndWidth: "xm81vs4",
                borderBottomWidth: "xso031l",
                borderStartWidth: "xy80clv"
            },
            container: {
                display: "x78zum5",
                position: "x1n2onr6",
                width: "xh8yej3"
            },
            expanding: {
                flexGrow: "x1iyjqo2"
            },
            overflowHidden: {
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62"
            },
            root: {
                borderTopStartRadius: "x1qpq9i9",
                borderTopEndRadius: "xdney7k",
                borderBottomEndRadius: "xu5ydu1",
                borderBottomStartRadius: "xt3gfkd",
                width: "xh8yej3"
            }
        },
        k = (b = {}, b[1] = {
            boxShadow: "xquyuld"
        }, b[2] = {
            boxShadow: "x10h3on"
        }, b);

    function a(a, b) {
        var d = a.allowOverflow;
        d = d === void 0 ? !1 : d;
        var e = a.background;
        e = e === void 0 ? "transparent" : e;
        var f = a.border;
        f = f === void 0 ? "none" : f;
        var g = a.borderHighlight,
            l = a.children,
            m = a.dropShadow;
        m = m === void 0 ? 0 : m;
        var n = a.expanding;
        n = n === void 0 ? !1 : n;
        var o = a.testid;
        a = a.xstyle;
        m = k[m];
        return h.jsxs("div", babelHelpers["extends"]({
            className: c("stylex")(j.container, n && j.expanding)
        }, c("testID")(o), {
            children: [h.jsx(c("BaseView.react"), {
                ref: b,
                style: {
                    borderRadius: c("isBlueprintStylesEnabled")() ? "max(0px, min(12px, calc((100vw - 4px - 100%) * 9999))) / 12px" : "max(0px, min(8px, calc((100vw - 4px - 100%) * 9999))) / 8px"
                },
                xstyle: [i[e], f === "solid" && e !== "white" && j.borderOnWash, f === "solid" && e === "white" && j.borderOnWhite, f === "solid" && j.borderSolid, j.root, !d && j.overflowHidden, m, a],
                children: l
            }), f === "inset" ? h.jsx("div", {
                className: c("stylex")(j.borderInset)
            }) : null, g != null ? h.jsx("div", {
                className: c("stylex")(j.borderHighlightOverlay, g === "animated" && j.borderHighlightAnimation)
            }) : null]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("TetraButtonGroup.react", ["CometFocusTableContext", "CometRow.react", "CometRowItem.react", "TetraButton.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            hiddenButton: {
                height: "xqtp20y",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                visibility: "xlshs6z"
            },
            resetFlexBasis: {
                flexBasis: "xdl72j9"
            }
        };

    function k(a) {
        var b = i(c("CometFocusTableContext"));
        b = b.FocusCell;
        a = a.children;
        return b != null ? h.jsx(b, {
            children: a
        }) : a
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.align,
            d = b === void 0 ? "justify" : b;
        b = a.direction;
        b = b === void 0 ? "forward" : b;
        var e = a.expanding;
        e = e === void 0 ? !1 : e;
        var f = a.paddingHorizontal,
            g = a.paddingTop,
            i = a.paddingVertical,
            l = a.primary,
            m = a.secondary,
            n = a.size,
            o = a.verticalAlign,
            p = a.wrap;
        p = p === void 0 ? "none" : p;
        var q = [],
            r = [],
            s = null;
        if (l != null) {
            var t = l.ref,
                u = l.testid;
            u = babelHelpers.objectWithoutPropertiesLoose(l, ["ref", "testid"]);
            s = h.jsx(k, {
                children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, u, {
                    ref: t,
                    size: n,
                    testid: void 0
                }))
            });
            q.push({
                hidden: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, u, {
                    disabled: !0,
                    padding: "normal",
                    size: n
                })),
                visible: s
            })
        }
        if (m != null) {
            l = m.ref;
            t = m.testid;
            u = babelHelpers.objectWithoutPropertiesLoose(m, ["ref", "testid"]);
            q.push({
                hidden: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, u, {
                    disabled: !0,
                    padding: "normal",
                    size: n,
                    type: "secondary"
                })),
                visible: h.jsx(k, {
                    children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, u, {
                        ref: l,
                        size: n,
                        testid: void 0,
                        type: "secondary"
                    }))
                })
            })
        } else if (a.secondaryIcon != null) r.push(h.jsx(c("CometRowItem.react"), {
            children: h.jsx(k, {
                children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, a.secondaryIcon, {
                    labelIsHidden: !0,
                    size: n,
                    type: "secondary"
                }))
            })
        }, "secondary-icon"));
        else if (a.secondaryIconGroup != null) {
            t = a.secondaryIconGroup;
            m = t.primaryIcon;
            u = t.secondaryIcon;
            r.push(h.jsx(c("CometRowItem.react"), {
                children: h.jsx(k, {
                    children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, m, {
                        labelIsHidden: !0,
                        size: n,
                        type: "secondary"
                    }))
                })
            }, "secondary-icon-1"), h.jsx(c("CometRowItem.react"), {
                children: h.jsx(k, {
                    children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, u, {
                        labelIsHidden: !0,
                        size: n,
                        type: "secondary"
                    }))
                })
            }, "secondary-icon-2"))
        }
        l = q.map(function(a, b) {
            return h.jsx(c("CometRowItem.react"), {
                expanding: d === "justify",
                xstyle: j.resetFlexBasis,
                children: q.map(function(a, d) {
                    return h.jsx(h.Fragment, {
                        children: b !== d ? h.jsx("div", {
                            "aria-hidden": !0,
                            className: c("stylex")(j.hiddenButton),
                            children: a.hidden
                        }) : a.visible
                    }, d)
                })
            }, b)
        });
        a = s != null ? h.jsx(c("CometRowItem.react"), {
            expanding: d === "justify",
            xstyle: j.resetFlexBasis,
            children: s
        }, "primary") : null;
        t = [a].concat(r);
        m = q.length === 2;
        u = m || s == null ? l : t;
        n = b === "forward" ? u : u.reverse();
        return h.jsx(c("CometRow.react"), {
            align: d,
            expanding: e,
            paddingHorizontal: f,
            paddingTop: g,
            paddingVertical: i,
            spacing: 8,
            verticalAlign: o,
            wrap: p,
            children: n
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("TimeSpentArray", ["Banzai", "TimeSlice", "clearTimeout", "pageID", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    var h = 2,
        i = h * 32,
        j, k, l, m, n, o, p, q, r, s, t = {},
        u;

    function v() {
        return {
            timeoutDelayMap: t,
            nextDelay: u,
            timeoutInSeconds: m
        }
    }

    function w() {
        if (j) {
            var a = Date.now();
            a > o && (q = Math.min(i, Math.ceil(a / 1e3 - n)));
            a = B();
            a && j(a, u)
        }
        A()
    }

    function x() {
        y(), l = c("setTimeoutAcrossTransitions")(c("TimeSlice").guard(w, "TimeSpentArray Timeout", {
            propagationType: c("TimeSlice").PropagationType.ORPHAN
        }), m * 1e3)
    }

    function y() {
        l && (c("clearTimeout")(l), l = null)
    }

    function z(a) {
        n = a;
        o = n * 1e3;
        p = [1];
        for (var a = 1; a < h; a++) p.push(0);
        q = 1;
        r += 1;
        s += 1;
        a = s.toString() + "_delay";
        u = t[a];
        u === void 0 && (u = t.delay);
        a = s.toString() + "_timeout";
        a = t[a];
        a === void 0 && (a = t.timeout);
        a = Math.min(a, i);
        m = a || i;
        x()
    }

    function A() {
        y(), p = null
    }

    function B() {
        return !p ? null : {
            tos_id: c("pageID"),
            start_time: n,
            tos_array: p.slice(0),
            tos_len: q,
            tos_seq: s,
            tos_cum: r
        }
    }

    function C(a) {
        if (a >= o && a - o < 1e3) return;
        k && k(a);
        D(Math.floor(a / 1e3))
    }

    function D(a) {
        var b = a - n;
        (b < 0 || b >= i) && w();
        !p ? z(a) : (p[b >> 5] |= 1 << (b & 31), q = b + 1, r += 1, o = a * 1e3)
    }

    function a(a, b, d, e) {
        r = 0, s = -1, j = a, k = e, typeof b === "object" && b !== null ? t = b : t = {}, z(Math.floor((d === void 0 || d === null || d === 0 ? Date.now() : d) / 1e3)), c("Banzai").subscribe(c("Banzai").SHUTDOWN, w)
    }

    function b(a) {
        C(a)
    }

    function d() {
        return B()
    }

    function e() {
        w()
    }

    function f() {
        A()
    }

    function E() {
        return v()
    }
    g.init = a;
    g.update = b;
    g.get = d;
    g.ship = e;
    g.reset = f;
    g.testState = E
}), 98);
__d("TimeSpentImmediateActiveSecondsLogger", ["cr:844180"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:844180")
}), 98);
__d("WebTimeSpentBitArrayFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1829320");
    c = b("FalcoLoggerInternal").create("web_time_spent_bit_array", a);
    e.exports = c
}), null);
__d("CometTimeSpentBitArrayLogger", ["ODS", "Random", "TimeSpentArray", "TimeSpentImmediateActiveSecondsLogger", "TimeSpentWWWCometConfig", "WebSession", "WebTimeSpentBitArrayFalcoEvent", "cr:1999269", "isInIframe"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "";

    function i(a, b) {
        a.sid_raw = h, c("WebTimeSpentBitArrayFalcoEvent").logImmediately(function() {
            return {
                sid_raw: a.sid_raw,
                start_time: a.start_time,
                tos_array: a.tos_array,
                tos_cum: a.tos_cum,
                tos_id: a.tos_id,
                tos_len: a.tos_len,
                tos_seq: a.tos_seq
            }
        })
    }

    function j(a) {
        a = k();
        a !== h && (d("TimeSpentArray").ship(), h = a)
    }

    function k() {
        d("WebSession").extend();
        return d("WebSession").getId()
    }

    function l(a) {
        return a === "XWorkPostPluginCometController" || a === "XWorkGroupFeedPluginCometController" || a === "XWorkMSTeamsAppFeedCometController" ? !0 : !1
    }

    function a(a) {
        if (c("isInIframe")() && !l(a)) return;
        a = Date.now();
        d("TimeSpentArray").init(i, c("TimeSpentWWWCometConfig").CONFIG, a, j);
        h = k();
        c("TimeSpentImmediateActiveSecondsLogger").maybeReportActiveSecond(a);
        a = 772;
        d("Random").coinflip(a) && d("ODS").bumpEntityKey(2966, "ms.time_spent.qa.www", "time_spent.bits.js_initialized", a)
    }

    function e(a) {
        if (b("cr:1999269") != null) {
            b("cr:1999269").getBroker().sendMessage("update_time_spent_bit_array", {
                eventTimeInMs: a
            });
            return
        }
        d("TimeSpentArray").update(a);
        c("TimeSpentImmediateActiveSecondsLogger").maybeReportActiveSecond(a)
    }
    g.init = a;
    g.updateTimeSpentArray = e
}), 98);
__d("CometTimeSpentUtils", ["forEachObject"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a, b, d) {
        a = (a = a.timeSpentConfig) == null ? void 0 : a.session_ids;
        if (d == null || a == null) return b;
        c("forEachObject")(a, function(a, c) {
            a = a.extradata_key;
            if (a != null) {
                b[a] = (a = d[c]) != null ? a : void 0
            }
        });
        return b
    };
    a = function(a, b, c) {
        if (c == null) return b;
        c = c || Object.freeze({});
        var d = c.session_ids;
        c = babelHelpers.objectWithoutPropertiesLoose(c, ["session_ids"]);
        return h(a, babelHelpers["extends"]({}, b, c), d)
    };
    g.addSessionIDsInfo = h;
    g.addTimeSpentMetaData = a
}), 98);
__d("CometVisitationManager", ["FBLogger", "isSearchCometGlobalResultPageTracePolicy", "pageID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            "comet.marketplace.category": "comet.marketplace.home",
            "comet.marketplace.home.hoisted_pdp": "comet.marketplace.home"
        },
        i = {},
        j = null,
        k = null,
        l = !1;

    function m(a) {
        return a.tracePolicy + ":" + a.instanceId + ":" + a.subsessionCount + ":" + a.timeStampMs / 1e3
    }

    function n(a) {
        if (a == null) return;
        a = h[a] ? h[a] : a;
        if (j === a) return;
        var b = i[a];
        b ? (b.subsessionCount++, b.timeStampMs = Date.now()) : i[a] = {
            instanceId: c("pageID"),
            subsessionCount: 1,
            timeStampMs: Date.now(),
            tracePolicy: a
        };
        k = j;
        j = a
    }

    function a() {
        if (!l) {
            c("FBLogger")("CometVisitationManager").mustfix("Attempting to get the current visitation id without initialization.");
            return null
        }
        if (!l || j == null || !i[j]) return null;
        var a = m(i[j]);
        if (c("isSearchCometGlobalResultPageTracePolicy")(j) && k != null && i[k]) {
            var b = m(i[k]);
            return a + "|" + b
        }
        return a
    }

    function b(a) {
        if (l) return;
        n(a);
        l = !0
    }

    function o(a) {
        if (!l) {
            c("FBLogger")("CometVisitationManager").mustfix("Updating the visitation manager without initialization");
            return
        }
        n(a)
    }

    function d(a) {
        o(a.main.route.tracePolicy)
    }
    g.getCurrentVisitationId = a;
    g.init = b;
    g.update = o;
    g.updateFromRouterState = d
}), 98);
__d("ProfileCometSessionConfig", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = "ps";
    b = 3e4;
    f.PREFIX = a;
    f.TIMEOUT_MS = b
}), 66);
__d("ProfileCometRoutingUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a != null && a.startsWith("comet.profile.")
    }
    f.isProfilePolicy = a
}), 66);
__d("ProfileCometSessionUtil", ["ProfileCometRoutingUtils", "ProfileCometSessionConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = a.tracePolicy;
        if (d("ProfileCometRoutingUtils").isProfilePolicy(b)) {
            b = a.params;
            a = b.profile_idorvanity;
            b = b.vanity;
            if (typeof b === "string") return b;
            return typeof a === "string" ? a : null
        }
        return null
    }

    function i(a) {
        var b = a.tracePolicy;
        if (d("ProfileCometRoutingUtils").isProfilePolicy(b)) {
            b = a.params;
            a = b.id;
            b = b.profile_idorvanity;
            if (typeof a === "string") return a;
            if (typeof b === "string") return b
        }
        return null
    }

    function a(a, b) {
        if (b == null) return !1;
        var c = b.tracePolicy;
        if (!d("ProfileCometRoutingUtils").isProfilePolicy(c)) return !1;
        if (a == null) return !0;
        c = a.tracePolicy;
        if (!d("ProfileCometRoutingUtils").isProfilePolicy(c)) return !1;
        c = h(b);
        var e = h(a);
        b = i(b);
        a = i(a);
        return c != null && c === e || b != null && b === a
    }

    function b(a) {
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var e = a.key(c);
            e != null && e.startsWith(d("ProfileCometSessionConfig").PREFIX) && b.push(e)
        }
        return b
    }
    g.isSameProfileSession = a;
    g.getStorageKeys = b
}), 98);
__d("ProfileEngagementFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744234");
    c = b("FalcoLoggerInternal").create("profile_engagement", a);
    e.exports = c
}), null);
__d("ProfileCometSession", ["ProfileCometSessionConfig", "ProfileCometSessionUtil", "ProfileEngagementFalcoEvent", "WebStorage", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = i();
        return b === null ? null : d("ProfileCometSessionConfig").PREFIX + ":" + a + ":" + b
    }

    function i() {
        var a = c("WebStorage").getSessionStorageForRead();
        if (!a) return null;
        var b = d("ProfileCometSessionConfig").PREFIX + ":tabID";
        a = a.getItem(b);
        if (a == null) {
            a = c("uuid")();
            var e = c("WebStorage").getSessionStorage();
            if (!e) return null;
            e.setItem(b, a)
        }
        return a
    }

    function j(a) {
        if (a == null) return "timeline";
        if (a === "comet.profile.timeline.grid") return "timeline_overview";
        if (a.startsWith("comet.profile.collection.friend")) return "friends_page";
        return a.startsWith("comet.profile.collection") ? "about_page" : "timeline"
    }

    function k(a, b, d) {
        c("ProfileEngagementFalcoEvent").log(function() {
            return {
                content_id: null,
                profile_event_type: "profile_session_impression",
                profile_id: a,
                profile_product_bucket: "profile_core",
                profile_session_id: b,
                profile_surface: j(d)
            }
        })
    }

    function l(a, b) {
        var d = c("WebStorage").getLocalStorage();
        if (!d) return null;
        d = c("uuid")();
        p(a, d);
        k(a, d, b == null ? void 0 : b.tracePolicy);
        return d
    }

    function m(a, b) {
        var c = o(a);
        return c === null ? l(a, b) : c
    }

    function n(a) {
        a = h(a);
        var b = c("WebStorage").getLocalStorageForRead();
        if (a === null || !b) return null;
        b = b.getItem(a);
        if (b == null) return null;
        a = b.split(":");
        b = a[0];
        a = a[1];
        a = parseInt(a, 10);
        return [b, a]
    }

    function o(a) {
        a = n(a);
        if (a !== null) {
            var b = a[0];
            a = a[1];
            if (Date.now() - a < d("ProfileCometSessionConfig").TIMEOUT_MS) return b
        }
        return null
    }

    function p(a, b) {
        var d = Date.now();
        a = h(a);
        var e = c("WebStorage").getLocalStorage();
        if (e && a !== null) {
            c("WebStorage").setItemGuarded(e, a, b + ":" + d);
            return b
        }
        return null
    }

    function q(a, b) {
        b = m(a, b);
        if (b == null) return null;
        p(a, b);
        return b
    }

    function a(a, b) {
        return m(a, b)
    }

    function b(a, b, c) {
        if (b != null) {
            var d = o(a);
            if (d === null) {
                k(a, b, c);
                return p(a, b)
            }
        }
        return q(a)
    }

    function e(a, b, c, e) {
        return d("ProfileCometSessionUtil").isSameProfileSession(b, c) || e === "popstate" || e === "initial" ? q(a, c) : l(a, c)
    }
    g.extend = q;
    g.get = a;
    g.initOrExtend = b;
    g.navigate = e
}), 98);
__d("CometTimeSpentNavigation", ["CometProductAttribution", "CometTimeSpentUtils", "CometVisitationManager", "ProfileCometSession"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null,
        j = new Set();

    function k() {
        j.forEach(function(a) {
            return a({
                destPathInfo: i,
                sourcePathInfo: h
            })
        })
    }
    a = {
        changePath: function(a, b, c) {
            c === void 0 && (c = null);
            h = i;
            var e = a.entityID,
                f = a.parentContainerId,
                g = a.tracePolicy,
                j = a.url;
            if (c && c.profile_session_id != null && e != null) {
                var l;
                c.profile_session_id = (l = d("ProfileCometSession").initOrExtend(e, (l = c) == null ? void 0 : l.profile_session_id, g)) != null ? l : (l = c) == null ? void 0 : l.profile_session_id
            }
            l = babelHelpers["extends"]({}, b);
            delete l.v2;
            b = d("CometProductAttribution").minifyProductAttributionV2(b);
            l = {
                pa: JSON.stringify(l),
                pav2: b,
                uri: j
            };
            l = d("CometTimeSpentUtils").addTimeSpentMetaData(a, l, c);
            b = d("CometVisitationManager").getCurrentVisitationId();
            b != null && (l.visitation_id = b);
            l.container_id == null && (e != null && (l.container_id = e));
            l.parent_container_id == null && f != null && (l.parent_container_id = f);
            i = {
                extraData: l,
                name: g
            };
            k()
        },
        getPathInfo: function() {
            return i
        },
        getSourcePathInfo: function() {
            return h
        },
        listenToPathChange: function(a) {
            j.add(a);
            return {
                cancelListen: function() {
                    return j["delete"](a)
                }
            }
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("CometVCTracker", ["vc-tracker"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("vc-tracker")
}), 98);
__d("CometVisualCompletion", ["CometVCTracker", "JSScheduler", "QPLEvent", "gkx", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            defer_expensive_calculation: function(a) {
                d("JSScheduler").scheduleLoggingPriCallback(a)
            },
            observeTextMutation: !1,
            retain_element_reference: c("gkx")("950768") || c("gkx")("1293035") || c("gkx")("1537962"),
            use_image_download_tracker: c("gkx")("6017"),
            vc_deep_cleanup: c("gkx")("2654")
        },
        i = 0,
        j = null,
        k = new Map(),
        l = 4,
        m;
    a = {
        addAnnotation: function(a, b) {
            j != null && j.addAnnotation(a, b)
        },
        addAnnotationDouble: function(a, b) {
            j != null && j.addAnnotationDouble(a, b)
        },
        addAnnotationInt: function(a, b) {
            j != null && j.addAnnotationInt(a, b)
        },
        addFirstMarkerPoint: function(a, b, d) {
            b === void 0 && (b = c("performanceAbsoluteNow")()), d === void 0 && (d = {}), j != null && b != null && b > 0 && j.addFirstMarkerPoint(a, b, d)
        },
        addMarkerPoint: function(a, b, d) {
            b === void 0 && (b = c("performanceAbsoluteNow")()), d === void 0 && (d = {}), j != null && b != null && b > 0 && j.addMarkerPoint(a, b, d)
        },
        addTag: function(a, b) {
            j != null && j.addTag(a, b)
        },
        addTracedInteraction: function(a, b, e) {
            var f = 1,
                g = null;
            k.get(a) && (f = k.get(a) + 1);
            k.set(a, f);
            if (j != null) {
                if (f >= l) return function() {};
                g = j.traceID;
                j.addMarkerPoint(a + "_" + f + "_start", c("performanceAbsoluteNow")(), {
                    interactionId: b,
                    qplEvent: d("QPLEvent").getMarkerId(e)
                })
            }
            return function() {
                j != null && j.traceID === g && j.addMarkerPoint(a + "_" + f + "_end", c("performanceAbsoluteNow")())
            }
        },
        addVisualElement: function(a, b, d) {
            d === void 0 && (d = c("performanceAbsoluteNow")()), j != null && a != null && (j.mutationSeq++, j.addVisualElement(j.mutationSeq, a, b, d))
        },
        dumpLocks: function() {
            if (j != null) return j.dumpLocks()
        },
        excludeElement: function(a) {
            j != null && m == null && j.excludeElement(a)
        },
        getCurrentNavigationTrace: function() {
            return j
        },
        getReport: function() {
            return m
        },
        holdTrigger: function(a) {
            if (j != null) return j.lock(a);
            else return function() {}
        },
        resumeTrigger: function(a) {
            j != null && j.unlock(a)
        },
        setInitialScrollY: function(a) {
            j != null && j.setInitialScrollY(a)
        },
        setRoute: function(a) {
            j != null && a != null && j.setTracePolicy(a)
        },
        setupNavigationMutationRoot: function(a) {
            j != null && (j.observeMutation(a), j.registerNavigationMutationRoot(a))
        },
        traceNavigation: function(a, b, d) {
            j = new(c("CometVCTracker").VisualCompletionTraceForNavigation)(b, ++i, a, d, h);
            j.onComplete(function(a) {
                m = a
            });
            m = null;
            k.clear();
            return j
        },
        trackLoadingState: function(a) {
            if (j != null) return j.waitLoadingState(a);
            else return function() {}
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("setTimeoutCometSpeculative", ["JSScheduler", "setTimeoutCometInternals"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        for (var c = arguments.length, e = new Array(c > 2 ? c - 2 : 0), f = 2; f < c; f++) e[f - 2] = arguments[f];
        return d("setTimeoutCometInternals").setTimeoutAtPriority_DO_NOT_USE.apply(d("setTimeoutCometInternals"), [d("JSScheduler").priorities.unstable_Idle, a, b].concat(e))
    }
    g["default"] = a
}), 98);
__d("CometAudioManagerContexts", ["cometUniqueID", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react").createContext;

    function a() {
        return c("cometUniqueID")()
    }
    e = b({
        muted: !0,
        setMuted: function() {},
        setVolume: function() {},
        volume: 1
    });
    f = b(null);
    d = b(null);
    g.makeAudioGroupID = a;
    g.CometAudioLocalScopeContext = e;
    g.CometAudioGroupContext = f;
    g.AudioApiContext = d
}), 98);
__d("CoreVideoPlayerAutoplayClientUtils", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {}

    function b(a, b, c, d) {
        return a === "PAUSE" && b === "PAUSE" && !c && d
    }
    g.log = a;
    g.componentShouldPause = b
}), 98);
__d("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        function b(b) {
            var d;
            d = (d = c("qex")._("1647")) != null ? d : !1;
            return (!d || b.paused) && b.bandwidthEstimate < a ? "IGNORE" : "SKIP"
        }
        b.displayName = "evaluateVideoAutoplayIgnoreOnLowBandwidthRule";
        return b
    }
    g["default"] = a
}), 98);
__d("createEvaluateVideoAutoplayPauseOnInvisibleRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        function b(b) {
            b = b.videoPlayerPassiveViewabilityInfo;
            b = b && b.getCurrent();
            b = b ? b.visiblePercentage : null;
            b = b === null || b >= a;
            return b ? "SKIP" : "PAUSE"
        }
        b.displayName = "evaluateVideoAutoplayPauseOnInvisibleRule:" + a + "%";
        return b
    }
    f["default"] = a
}), 66);
__d("createEvaluateVideoAutoplayPauseOnInvisibleUsingExtraViewabilityRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        c === void 0 && (c = !0);

        function d(d) {
            var e = d.muted;
            d = d.videoPlayerExtendedPassiveViewabilityInfo;
            if (c && e) return "SKIP";
            e = d == null ? void 0 : d.getCurrent();
            d = e == null ? void 0 : e.visiblePercentage;
            var f = d == null || d >= a;
            if (f) return "SKIP";
            e = e == null ? void 0 : (f = e.positionToViewport) == null ? void 0 : f.height;
            return e != null && d != null && d * e >= window.innerHeight * b ? "SKIP" : "PAUSE"
        }
        d.displayName = "evaluateVideoAutoplayPauseOnInvisibleUsingExtendedViewabilityRule:" + a + ":" + b + "%";
        return d
    }
    f["default"] = a
}), 66);
__d("createEvaluateVideoAutoplayPauseOnMutedInvisibleRule", ["createEvaluateVideoAutoplayPauseOnInvisibleRule"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(a);

        function d(a) {
            return a.muted ? b(a) : "SKIP"
        }
        d.displayName = "evaluateVideoAutoplayPauseOnMutedInvisibleRule:" + a + "%";
        return d
    }
    g["default"] = a
}), 98);
__d("evaluateVideoAutoplayDefaultIgnoreRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return "IGNORE"
    }
    a.displayName = "evaluateVideoAutoplayDefaultIgnoreRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreExternalMediaRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.isExternalMedia ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreExternalMediaRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnBroadcastEndedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.ended;
        a = a.broadcastStatus != null;
        return a && b ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnBroadcastEndedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnEndedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.ended;
        return a ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnEndedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnFrozenRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.isFrozenPassive;
        a = a.getCurrentState();
        return a ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnFrozenRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnUnmuteRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.muted;
        a = a.paused;
        return !b && !a ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnUnmuteRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnUserPausedRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.paused;
        a = a.lastPauseReason;
        return b && (a === "user_initiated" || a === "other_user_initiated") ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnUserPausedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayIgnoreOnUserPlayRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.paused,
            c = a.muted;
        a = a.lastPlayReason;
        return !c && !b && (a === "user_initiated" || a === "other_user_initiated") ? "IGNORE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayIgnoreOnUserPlayRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnAdInvisibleRule", ["VideoPlayerViewabilityConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.adClientToken;
        a = a.videoPlayerPassiveViewabilityInfo;
        a = a && a.getCurrent();
        a = a ? a.visiblePercentage : null;
        a = a === null || a >= c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE;
        return b != null && !a ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnAdInvisibleRule";
    g["default"] = a
}), 98);
__d("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = !1;

    function a(a) {
        var b = a.adClientToken,
            c = a.hiddenSubtreePassive,
            d = a.muted;
        a = a.isBackgrounded || c.getCurrentState().backgrounded;
        c = b != null;
        return !a || !d ? "SKIP" : a && d && c ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.hiddenSubtreePassive;
        return a.getCurrentState().backgrounded ? "PAUSE" : "SKIP"
    }
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnHiddenSubtreeRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = a.hiddenSubtreePassive;
        return a.getCurrentState().hidden ? "PAUSE" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnHiddenSubtreeRule";
    f["default"] = a
}), 66);
__d("evaluateVideoAutoplayPauseOnMutedBackgroundedRule", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = !1;

    function a(a) {
        var b = a.hiddenSubtreePassive,
            c = a.muted;
        a = a.isBackgrounded || b.getCurrentState().backgrounded;
        return a ? a && c ? "PAUSE" : "SKIP" : "SKIP"
    }
    a.displayName = "evaluateVideoAutoplayPauseOnMutedBackgroundedRule";
    f["default"] = a
}), 66);
__d("VideoPlayerAutoplayRulesProvider", ["VideoPlayerViewabilityConstants", "createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule", "createEvaluateVideoAutoplayPauseOnInvisibleRule", "createEvaluateVideoAutoplayPauseOnInvisibleUsingExtraViewabilityRule", "createEvaluateVideoAutoplayPauseOnMutedInvisibleRule", "evaluateVideoAutoplayDefaultIgnoreRule", "evaluateVideoAutoplayIgnoreExternalMediaRule", "evaluateVideoAutoplayIgnoreOnBroadcastEndedRule", "evaluateVideoAutoplayIgnoreOnEndedRule", "evaluateVideoAutoplayIgnoreOnFrozenRule", "evaluateVideoAutoplayIgnoreOnUnmuteRule", "evaluateVideoAutoplayIgnoreOnUserPausedRule", "evaluateVideoAutoplayIgnoreOnUserPlayRule", "evaluateVideoAutoplayPauseOnAdInvisibleRule", "evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule", "evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule", "evaluateVideoAutoplayPauseOnHiddenSubtreeRule", "evaluateVideoAutoplayPauseOnMutedBackgroundedRule", "gkx", "qex", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    b = 25e4;
    d = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), c("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")];
    f = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), c("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule")((e = c("qex")._("1645")) != null ? e : b), c("evaluateVideoAutoplayPauseOnMutedBackgroundedRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")];
    e = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")];
    h = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule")((h = c("qex")._("1646")) != null ? h : b), c("evaluateVideoAutoplayIgnoreOnUserPausedRule")];
    !c("gkx")("2988") ? (h.push(c("createEvaluateVideoAutoplayPauseOnInvisibleUsingExtraViewabilityRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE, .75)), h.push(c("createEvaluateVideoAutoplayPauseOnMutedInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE))) : h.push(c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE));
    c("gkx")("1564135") ? h.push(c("evaluateVideoAutoplayIgnoreOnBroadcastEndedRule")) : h.push(c("evaluateVideoAutoplayIgnoreOnEndedRule"));
    h = h.slice();
    var i = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("createEvaluateVideoAutoplayPauseOnMutedInvisibleRule")(.01), c("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")].filter(Boolean),
        j = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        k = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        l = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        m = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        n = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        o = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("evaluateVideoAutoplayPauseOnAdInvisibleRule"), c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE), c("evaluateVideoAutoplayPauseOnAdMutedBackgroundedRule"), c("evaluateVideoAutoplayIgnoreOnUnmuteRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayIgnoreOnUserPlayRule"), c("evaluateVideoAutoplayIgnoreOnEndedRule")],
        p = [c("evaluateVideoAutoplayDefaultIgnoreRule")],
        q = [c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(0)],
        r = [c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(0)],
        s = [c("evaluateVideoAutoplayIgnoreOnFrozenRule"), c("createEvaluateVideoAutoplayPauseOnInvisibleRule")(.25), c("evaluateVideoAutoplayPauseOnMutedBackgroundedRule"), c("evaluateVideoAutoplayPauseOnHiddenSubtreeRule"), c("evaluateVideoAutoplayIgnoreOnUserPausedRule"), c("evaluateVideoAutoplayPauseOnBackgroundedSubtreeRule")];
    c("qex")._("181") === !0 && s.push(c("createEvaluateVideoAutoplayIgnoreOnLowBandwidthRule")(b));
    var t = {
        always_disable: p,
        basic: d,
        bulletin: q,
        creator_studio: o,
        creator_studio_sliding_tray_rules: r,
        default_feed: f,
        gif: e,
        live_producer: j,
        polaris_feed: s,
        stages: n,
        tournament_hero: k,
        watch_feed: h,
        watch_live_tab: i,
        wns: l,
        work_knowledge: m
    };
    for (var b in t) t[b].push(c("evaluateVideoAutoplayIgnoreExternalMediaRule"));
    p = function(a) {
        a = t[a];
        if (!a) throw c("unrecoverableViolation")("Unknown VideoPlayerAutoplayRulesType passed to VideoPlayerAutoplayRulesProvider", "comet_video_player");
        return a
    };

    function a(a) {
        return a
    }
    g.provideAutoplayRules = p;
    g.makeVideoPlayerAutoplayRules = a
}), 98);
__d("VideoPlayerAutoplayContexts", ["VideoPlayerAutoplayRulesProvider", "cometUniqueID", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react").createContext;
    e = b({
        autoplayLocalRules: d("VideoPlayerAutoplayRulesProvider").provideAutoplayRules("basic"),
        autoplayScopeID: "null"
    });
    f = b(null);

    function a() {
        return "id-vpas-" + c("cometUniqueID")()
    }
    g.VideoAutoplayLocalScopeContext = e;
    g.AutoplayApiContext = f;
    g.makeAutoplayScopeID = a
}), 98);
__d("VideoAutoplayLocalScopeProvider.react", ["VideoPlayerAutoplayContexts", "react", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = a.autoplayLocalRules,
            e = a.customAutoplaySelectionFunc,
            f = a.disableScrollBeforePlayWhenOffscreen,
            g = a.noPauseOnBlurOrFocus,
            j = d("VideoPlayerAutoplayContexts").makeAutoplayScopeID(),
            k = c("useUnsafeRef_DEPRECATED")(j);
        j = i(function() {
            return {
                autoplayLocalRules: b,
                autoplayScopeID: k.current,
                customAutoplaySelectionFunc: e,
                disableScrollBeforePlayWhenOffscreen: f,
                noPauseOnBlurOrFocus: g
            }
        }, [k, e, b, f, g]);
        return h.jsx(d("VideoPlayerAutoplayContexts").VideoAutoplayLocalScopeContext.Provider, {
            value: j,
            children: a.children
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("scrollTo", ["debounce", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b, d = a.onScrollComplete,
            e = a.onScrollStart,
            f = babelHelpers.objectWithoutPropertiesLoose(a, ["onScrollComplete", "onScrollStart"]);
        b = (b = a.top) != null ? b : window.pageYOffset;
        a = (a = a.left) != null ? a : window.pageXOffset;
        e && e();
        if (window.pageYOffset === b && window.pageXOffset === a) {
            d && d();
            return {
                dispose: c("emptyFunction")
            }
        }
        e = !1;
        try {
            var g = document.documentElement;
            if (g == null) {
                d && d();
                return {
                    dispose: c("emptyFunction")
                }
            }
            g = "scrollBehavior" in g.style;
            g ? window.scrollTo(f) : e = !0
        } catch (a) {
            e = !0
        }
        if (e) {
            window.scrollTo(a, b);
            d && d();
            return {
                dispose: c("emptyFunction")
            }
        }
        var h, i = !1;
        d != null && (h = c("debounce")(function() {
            i = !0, window.removeEventListener("scroll", h), d && d()
        }, 200), window.addEventListener("scroll", h, {
            passive: !0
        }), window.dispatchEvent(new Event("scroll")));
        return {
            dispose: function() {
                if (i) return;
                h && h.reset();
                window.removeEventListener("scroll", h);
                window.scrollTo(window.pageYOffset, window.pageXOffset)
            }
        }
    }
    g["default"] = a
}), 98);
__d("scrollIntoView", ["debounce", "emptyFunction", "recoverableViolation", "scrollTo"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        center: "center",
        top: "start",
        bottom: "end",
        closest: "nearest"
    };

    function a(a, b) {
        b === void 0 && (b = Object.freeze({}));
        var d = b,
            e = d.behavior;
        e = e === void 0 ? "auto" : e;
        var f = d.onScrollComplete,
            g = f === void 0 ? c("emptyFunction") : f;
        f = d.onScrollStart;
        f = f === void 0 ? c("emptyFunction") : f;
        d = d.force;
        d = d === void 0 ? !1 : d;
        var i = a.getBoundingClientRect(),
            j = document.documentElement;
        if (j == null) {
            c("recoverableViolation")("There is no documentElement accessible on document, something is seriously wrong and I couldn't imagine the situation you have found yourself in", "comet_ui");
            return {
                dispose: c("emptyFunction")
            }
        }
        var k = j.clientHeight,
            l = i.top <= k && i.bottom >= 0;
        f();
        if (!d && l) {
            g != null && g();
            return {
                dispose: c("emptyFunction")
            }
        }
        d = (f = b.verticalAlign) != null ? f : "closest";
        try {
            l = "scrollBehavior" in j.style;
            if (l) {
                a.scrollIntoView({
                    behavior: e,
                    block: d != null ? h[d] : void 0
                });
                var m, n = !1;
                g != null && (m = c("debounce")(function() {
                    n = !0, window.removeEventListener("scroll", m, {
                        capture: !0
                    }), g()
                }, 200), window.addEventListener("scroll", m, {
                    passive: !0,
                    capture: !0
                }), window.dispatchEvent(new Event("scroll")));
                return {
                    dispose: function() {
                        if (n) return;
                        m && m.reset();
                        window.removeEventListener("scroll", m, {
                            capture: !0
                        });
                        window.scrollTo(window.pageYOffset, window.pageXOffset)
                    }
                }
            }
        } catch (a) {}
        d === "closest" && (i.top >= k ? d = "bottom" : d = "top");
        var o;
        switch (d) {
            case "top":
                o = window.pageYOffset + i.top;
                break;
            case "bottom":
                o = window.pageYOffset + i.bottom - k;
                break;
            case "center":
                o = window.pageYOffset + i.bottom - k + (k - i.height) / 2;
                break
        }
        return c("scrollTo")({
            behavior: e,
            top: o,
            onScrollComplete: g
        })
    }
    g["default"] = a
}), 98);
__d("WebPerformanceDeviceInfo", ["Promise", "WebDevicePerfClassData", "regeneratorRuntime", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("WebDevicePerfInfoLogging").__setRef("WebPerformanceDeviceInfo"),
        i = c("WebDevicePerfClassData").deviceLevel,
        j = null;

    function k() {
        var a, c;
        return b("regeneratorRuntime").async(function(d) {
            while (1) switch (d.prev = d.next) {
                case 0:
                    d.next = 2;
                    return b("regeneratorRuntime").awrap(new(b("Promise"))(function(a, b) {
                        h.onReady(function(b) {
                            a(b)
                        })
                    }));
                case 2:
                    a = d.sent;
                    d.next = 5;
                    return b("regeneratorRuntime").awrap(a.doLogPromise());
                case 5:
                    c = d.sent, c && (i = c);
                case 7:
                case "end":
                    return d.stop()
            }
        }, null, this)
    }

    function a() {
        return i
    }

    function d() {
        return c("WebDevicePerfClassData").yearClass
    }

    function e() {
        h.onReady(function(a) {
            a.doLog()
        })
    }

    function f() {
        j == null && (j = k());
        return j
    }
    g.getDeviceLevel = a;
    g.getMobileYearClass = d;
    g.initWebDevicePerfLoggingPassive = e;
    g.initWebDevicePerfLoggingAndUpdateValue = f
}), 98);
__d("useInterval", ["clearInterval", "react", "setIntervalAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function a(a, b, d) {
        d === void 0 && (d = []);
        var e = i(a);
        h(function() {
            e.current = a
        }, [a]);
        var f = a != null;
        h(function() {
            if (!f || b <= 0) return;
            var a = c("setIntervalAcrossTransitions")(function() {
                var a = e.current;
                if (a == null) return;
                a()
            }, b);
            return function() {
                return c("clearInterval")(a)
            }
        }, [f, b].concat(d))
    }
    g["default"] = a
}), 98);
__d("WwwCometVideoAutoplayFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744552");
    c = b("FalcoLoggerInternal").create("www_comet_video_autoplay", a);
    e.exports = c
}), null);