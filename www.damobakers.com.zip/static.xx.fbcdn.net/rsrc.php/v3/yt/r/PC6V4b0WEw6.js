if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("getFullScreenElement", [], (function(a, b, c, d, e, f) {
    function a() {
        return document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement
    }
    e.exports = a
}), null);
__d("VideoPermalinkURI", [], (function(a, b, c, d, e, f) {
    function a(a) {
        return g(a) !== null
    }

    function g(a) {
        if (i(a)) {
            var b = a.getQueryData();
            return b.v != null ? {
                video_id: String(b.v),
                set_token: b.set != null ? String(b.set) : b.set
            } : null
        }
        b = a.getPath();
        b[b.length - 1] === "/" && (b = b.substring(0, b.length - 1));
        a = b.split("/");
        if (a.length >= 3 && a[2] === "videos")
            if (a.length === 4 && h(a[3])) return {
                video_id: a[3],
                set_token: null
            };
            else if (a.length === 5) {
            if (h(a[4])) return {
                video_id: a[4],
                set_token: a[3]
            };
            else if (h(a[3])) return {
                video_id: a[3],
                story_id: a[4]
            }
        } else if (a.length === 6 && h(a[4])) return {
            video_id: a[4],
            set_token: a[3],
            story_id: a[5]
        };
        return null
    }

    function h(a) {
        return /^\d+$/.exec(a) !== null
    }

    function i(a) {
        a = a.getPath();
        a[a.length - 1] === "/" && (a = a.substring(0, a.length - 1));
        return a === "/photo.php" || a === "/force_photo/photo.php" || a === "/photo" || a === "/force_photo/photo/index.php" || a === "/photo/index.php" || a === "/force_photo/photo" || a === "/video.php" || a === "/video/video.php" ? !0 : !1
    }

    function b(a) {
        a = a.getDomain();
        return a === "fb.watch" || a === "fbwat.ch"
    }

    function c(a, b) {
        return a + b + "/"
    }
    f.isValid = a;
    f.parse = g;
    f.isNumeric = h;
    f.isValidLegacy = i;
    f.isValidFBWatchDomain = b;
    f.getCustomStoryURI = c
}), 66);
__d("cxMargin", ["cx"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        throw new Error("cxMargin: Unexpected margin transformation.")
    }
    g["default"] = a
}), 98);
__d("ShakaConstants", [], (function(a, b, c, d, e, f) {
    a = {
        abort_loading_delay: 2e4,
        abr_abort_on_zero_stream_progress_below_threshold: -1,
        abr_abort_when_fetch_estimate_exceeds_buffer_factor: 0,
        abr_abort_when_fetch_estimate_exceeds_time: 0,
        append_window_end_fudge_factor: 0,
        audio_request_pipeline_max_concurrent_requests: 1,
        audio_request_pipeline_soothing_factor: 1,
        audio_video_buffer_diff_threshold: 14400,
        autoplay_start_video_interval: 200,
        back_off_buffering_overflow_max: 5,
        back_off_buffering_overflow_time_factor: 2,
        back_off_buffering_overflow_time_window: 2e3,
        bandwidth_downgrade_target: .9,
        bandwidth_penalty_decay_per_video: 1,
        bandwidth_standard_deviation_penalty_factor: .1,
        buffer_downgrade_threshold: 10,
        buffer_replacement_ahead_threshold: 15,
        buffer_replacement_behind_threshold: 5,
        buffer_target: -1,
        buffer_target_overflow_upgrade_aggressiveness: 1,
        buffer_target_underflow_upgrade_aggressiveness: 1,
        buffer_velocity_time_in_past_to_consider: 0,
        buffering_count_threshold: 5,
        buffering_spinner_delay_ms: 0,
        buffering_underflow_threshold: .05,
        clear_buffer_on_constraint_change_offset: 5,
        clear_buffer_on_constraint_change_paused_offset: 5,
        clear_buffer_on_seek_back_delta: 0,
        decouple_stream_on_update_loop_from_request_loop_int: 0,
        fast_moving_average_half_life: 3,
        frame_drop_penalty_factor: 0,
        frame_drop_penalty_minimum_frame_count: 0,
        global_scheduler_priority_downgrade_bufferahead_threshold: 0,
        global_scheduler_priority_threshold: 6,
        hvq_inline_upgrade_aggressiveness: 1,
        hvq_upgrade_aggressiveness: 1,
        initial_stream_buffer_size_for_blocked_autoplay: 5.9335983320607,
        initial_stream_buffer_size_for_video_stream: 0,
        jump_to_live_threshold: .5,
        live_bandwidth_downgrade_target: 1,
        live_bitrate_estimates_half_life: 1,
        live_bitrate_estimates_large_sample_weight_factor: 10,
        live_bitrate_estimates_minimum_sample_count: 1,
        live_buffering_underflow_threshold: .5,
        live_data_fetch_max_retries: 0,
        live_dynamic_stream_buffer_size: 12,
        live_hvq_inline_upgrade_aggressiveness: 1,
        live_hvq_upgrade_aggressiveness: 1,
        live_interruption_consecutive_updates_with_change: 3,
        live_interruption_consecutive_updates_without_change: 5,
        live_max_manifest_fetches_with_push: 1,
        live_max_segments_to_push: 1,
        live_playhead_idle_all_stream_threshold: 4,
        live_playhead_idle_single_stream_threshold: 5,
        live_pre_hvq_inline_upgrade_aggressiveness: 1,
        live_pre_hvq_upgrade_aggressiveness: 1,
        live_predictive_abr_down_buffer: 5e3,
        live_predictive_abr_floor_swich_lanes: -2,
        live_predictive_abr_floor_ttfb_ratio: 5,
        live_predictive_abr_ttfb_ratio: 1.8,
        live_predictive_abr_up_buffer: 9e3,
        live_predictive_abr_up_retry_interval: 3e4,
        live_rewind_templated_last_x_segments_only: 0,
        live_source_buffer_clear_max_retries: 0,
        live_stream_end_slack: .5,
        live_stream_end_timeout: 6e4,
        living_room_play_x_milliseconds_before_seek: 0,
        living_room_playhead_catchup_interval: 0,
        local_bitrate_segments_ahead: 10,
        logging_log_event_limit: 1e3,
        low_buffer_velocity_abr_interval: 500,
        low_buffer_velocity_abr_interval_buffer_threshold: 10,
        low_buffer_velocity_threshold: 0,
        low_pri_task_min_bytes_to_yield: 0,
        low_pri_task_yield_check_interval: 0,
        low_pri_task_yields_per_task: 0,
        max_bandwidth_update_interval: 0,
        max_network_interrupted_time_before_seek: 1e4,
        max_prefetch_request_num: 0,
        max_prefetch_videos_num: 2,
        max_recent_bandwidth_samples: 25,
        maximum_bandwidth_bitrate_ratio: 1.5,
        maximum_mos_to_decrease: 3,
        min_mpd_refresh_interval: 1e3,
        min_sample_count: 1e4,
        minimum_sample_count_to_use_deviation_penalty: 2,
        minimum_sample_count_to_use_new_estimator: 0,
        minimum_samples_to_use_neural_estimate: 1,
        minimum_weight_to_trust_local_bandwidth_estimate: .5,
        multiple_videos_queue_penalty_start_count: 2,
        neural_estimate_weight: 0,
        new_estimator_half_life: 5,
        new_estimator_standard_deviation_exclusion_factor: 2,
        pending_seek_while_playing_delay: 2e3,
        pending_seek_while_playing_offset_from_livehead: 4e3,
        playhead_fragmented_gap_diff_allowance: .1,
        pre_hvq_inline_upgrade_aggressiveness: 1,
        pre_hvq_upgrade_aggressiveness: 1,
        priority_precision: 1,
        recursive_native_settimeout_delay: -1,
        recursive_ric_timeout: 17,
        request_bounded_animation_frame_bound: 50,
        request_pipeline_max_concurrent_requests: 2,
        request_pipeline_soothing_factor: 2,
        request_pipeline_timeout_ms: 0,
        resolution_constraint_max_height: 0,
        resolution_constraint_max_width: 0,
        ric_autoplay_bound: 50,
        rl_bandwidth_scale: 1e6,
        rl_bitrate_reward: 1,
        rl_buffer_scale: 10,
        rl_max_number_of_bitrates: 10,
        rl_model_id: 0,
        rl_playback_scale: 2e5,
        rl_request_timeout: 1e3,
        rl_stall_count_penalty: 30,
        rl_stall_time_penalty: 0,
        rl_watch_time_reward: 0,
        scheduled_videos_start_stream_buffer_size_threshold: 0,
        scheduler_priority_update_interval: 1e3,
        settimeout_polling_delay: 17,
        shaka_default_ajax_request_timeout_ms: 0,
        shaka_default_request_timeout_timescale: 1e3,
        skip_manifest_gap_boundary_precision_ms: 1e3,
        slow_moving_average_half_life: 10,
        stream_maximum_onpause_buffer_size_multiplier: 0,
        stream_onupdate_sampling: 0,
        streaming_append_per_segment: 3,
        templated_adjust_stream_limits_start_offset: 0,
        templated_adjust_stream_limits_start_offset_int: 10,
        templated_chunked_segment_update_limit_int: 10,
        templated_ingest_throttle: 0,
        templated_jump_to_live_sidx_end_offset: 0,
        templated_quarantine_idle_references_threshold: 0,
        templated_use_perf_test_segment_index_base_int: 0,
        video_dash_prefetch_cache_retention_duration_ms: 5e3
    };
    b = {
        block_play_request_http_status_list: "410",
        defer_which_video_to_abort_loading_decisioning_logic: "live",
        feature_param: "",
        live_abr_audio_push_representation: "live-md-a",
        live_abr_initial_push_representation: "live-md-v",
        rl_smc_tier: "repomen_1",
        segment_update_helper_splice_path_entity_key: "",
        templated_perf_test_methods_under_test_csv_string: "all"
    };
    c = {
        numbers: a,
        strings: b
    };
    f["default"] = c
}), 66);
__d("VideoFeedFastPreloadController", ["DOMQuery", "Run"], (function(a, b, c, d, e, f, g) {
    var h = 0;

    function b(b) {
        h < 2 && (b = d("DOMQuery").scry(b, "video")[0], b instanceof a.HTMLVideoElement && (h || d("Run").onBeforeUnload(function() {
            return i()
        }), b.preload = "auto", h += 1))
    }

    function i() {
        h = 0
    }
    i();
    g.preload = b;
    g.reset = i
}), 98);
__d("logVideosClickTracking", ["clickRefAction"], (function(a, b, c, d, e, f) {
    function a(a) {
        b("clickRefAction")("click", a, null, "FORCE")
    }
    e.exports = a
}), null);
__d("VideoWithClickPlayPause", ["logVideosClickTracking"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a(a) {
            this.$1 = a, this.$2 = this.$1.getVideoNode(), this.$1.addListener("clickVideo", this.$3.bind(this)), this.$1.hasSeenClick() && this.$3()
        }
        var c = a.prototype;
        c.$3 = function() {
            var a = this.$1.getOption("CommercialBreakVideoAdOverlay", "videoController");
            if (this.$1.isState("playing")) {
                if (this.$1.getOption("VideoWithLiveBroadcast", "isLive") || a && a.getOption("VideoWithLiveBroadcast", "isLive") || this.$4() || this.$5()) return;
                this.$1.pause("user_initiated")
            } else b("logVideosClickTracking")(this.$2), this.$1.play("user_initiated")
        };
        c.$4 = function() {
            var a = this.$1.getOption("CommercialBreakVideoAdOverlay", "videoController");
            a = a && a.getOption("VideoWithInstreamVideo", "controller");
            return a && !a.getConfig().canPauseAdBreak
        };
        c.$5 = function() {
            return this.$1.getOption("VideoWithInstreamVideo", "disableClickToPause")
        };
        return a
    }();
    e.exports = a
}), null);
__d("VideoAkamaiRequestHelper", ["URI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a.toLowerCase().indexOf("akamai") !== -1
    }

    function h(a) {
        var b = a.startByte;
        a = a.endByte;
        if (b != void 0 && !(b === 0 && a == void 0)) {
            b = "bytes=" + b + "-" + (a == void 0 ? "" : a);
            return {
                Range: b
            }
        }
        return null
    }

    function b(a) {
        var b = new(c("URI"))(a);
        b = b.getQueryData();
        var d = b.startByte;
        b = b.endByte;
        return h({
            baseUrl: a,
            startByte: d,
            endByte: b
        })
    }
    g.isAkamai = a;
    g.getRequestHeaders = h;
    g.getRequestHeadersFromUrl = b
}), 98);
__d("VideoDashPrefetchCacheUtils", ["ConstUriUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = d("ConstUriUtils").getUri(a);
        a = a == null ? void 0 : a.getDomain();
        return a != null && a.endsWith("fbcdn.net") && !a.startsWith("interncache") && !a.endsWith("ak.fbcdn.net")
    }

    function b(a) {
        var b = d("ConstUriUtils").getUri(a);
        if (b == null ? void 0 : b.getDomain()) {
            var c = ["oh", "__gda__"],
                e = b == null ? void 0 : b.getQueryParams().keys();
            if (e != null)
                for (var e = e, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var h;
                    if (f) {
                        if (g >= e.length) break;
                        h = e[g++]
                    } else {
                        g = e.next();
                        if (g.done) break;
                        h = g.value
                    }
                    h = h;
                    h.startsWith("_nc") && c.push(h)
                }
            return (g = b == null ? void 0 : (h = b.removeQueryParams(c)) == null ? void 0 : h.toString()) != null ? g : a
        }
        return a
    }
    g.isFBCDN = a;
    g.stripNonCachingParams = b
}), 98);
__d("parseHeaders", [], (function(a, b, c, d, e, f) {
    var g = /\r?\n[\t]+/g,
        h = /\r?\n/;

    function a(a) {
        a = a.replace(g, " ");
        var b = {};
        a.split(h).forEach(function(a) {
            a = a.split(":");
            var c = a.shift().trim();
            if (c) {
                a = a.join(":").trim();
                b[c.toLowerCase()] = a
            }
        });
        return b
    }
    f["default"] = a
}), 66);
__d("VideoPlayerShakaError", ["parseHeaders"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        var e = a.errorRawTransportStatus,
            f = null;
        a.errorRawResponseHeaders != null && (f = c("parseHeaders")(a.errorRawResponseHeaders));
        return {
            name: a.errorType,
            message: a.errorMsg,
            type: d,
            url: b,
            status: e,
            responseHeaders: f
        }
    }

    function b(a) {
        return {
            name: "timeout",
            message: "timeout",
            type: "net",
            url: a,
            status: 0,
            responseHeaders: null
        }
    }
    g.translateError = a;
    g.createTimeoutError = b
}), 98);
__d("VideoDashPrefetchCache", ["ConstUriUtils", "Deferred", "MaybeNativePromise", "ODS", "Promise", "VideoAkamaiRequestHelper", "VideoDashPrefetchCacheUtils", "VideoPlayerPrefetchExperiments", "VideoPlayerShakaError", "XHRRequest", "clearTimeout", "cr:1209197", "cr:1209198", "getCrossOriginTransport", "recoverableViolation", "regeneratorRuntime", "requireWeak", "setTimeout"], (function(a, b, c, d, e, f, g) {
    var h = 5e3,
        i = function(a) {
            b("cr:1209197") != null ? b("cr:1209197").onLeave(a) : b("cr:1209198") != null ? b("cr:1209198").onUnload(a) : c("recoverableViolation")("Dash prefetch cache onNavigatingAway handler was not properly set", "video")
        },
        j = null;
    c("requireWeak")("VideoPlayerShakaBandwidthEstimator", function(a) {
        return j = a
    });
    var k = null;
    c("requireWeak")("VideoStreamingTaskQueueProvider", function(a) {
        return k = a
    });

    function l(a) {
        return a.audio.length + a.video.length + a.manifest.length
    }

    function m(a, b) {
        d("ODS").bumpEntityKey(2966, "www_video_playback", "prefetch." + a, b)
    }

    function n(a) {
        var b = "aborted",
            c = {
                status: 0
            },
            d = new Error("Prefetch request aborted.");
        return Object.assign(d, {
            type: b,
            url: a,
            xhr: c
        })
    }

    function o(a) {
        var b = a.getURI(),
            c = b.toString();
        if (d("VideoAkamaiRequestHelper").isAkamai(c)) {
            var e = d("VideoAkamaiRequestHelper").getRequestHeadersFromUrl(c);
            c = b.removeQueryData(["bytestart", "byteend"]);
            a.setURI(c);
            e && Object.keys(e).forEach(function(b) {
                a.setRequestHeader(b, e[b])
            })
        }
        return a
    }
    var p = null,
        q = new Map();

    function r(a, b) {
        b === void 0 && (b = !1);
        return b && d("VideoDashPrefetchCacheUtils").isFBCDN(a) ? c("getCrossOriginTransport").withCredentials : c("getCrossOriginTransport")
    }

    function s(a) {
        return d("VideoDashPrefetchCacheUtils").isFBCDN(a.url)
    }

    function t(a, b, c) {
        return {
            response: a.slice(b.start + 0, b.end + 1),
            responseTime: c,
            initiator: "XHR_REQUEST"
        }
    }
    a = function() {
        function a() {
            this.$2 = new Map(), this.$9 = new Map(), this.$10 = new Map(), this.$1 = new Map(), this.$3 = [], this.$4 = [], this.$5 = 0, this.$6 = c("VideoPlayerPrefetchExperiments").maxPrefetchVideosNum, this.$7 = c("VideoPlayerPrefetchExperiments").consolidateFragmentedPrefetchRequest
        }
        var e = a.prototype;
        e.$11 = function(a, b) {
            var e = this;
            b === void 0 && (b = !1);
            var f = a,
                g = window.fetch,
                h = c("VideoPlayerPrefetchExperiments").useFetch;
            if (h && g && "AbortController" in window) {
                var i = new AbortController();
                h = i.signal;
                var j = g(f, {
                    signal: h,
                    credentials: b ? "include" : "same-origin"
                }).then(function(a) {
                    e.$12(j);
                    return {
                        initiator: "FETCH",
                        response: a
                    }
                });
                this.$13(a, j);
                this.$3.push(babelHelpers["extends"]({}, j, {
                    abort: function() {
                        i.abort()
                    }
                }));
                return j
            }
            var k = new(c("XHRRequest"))(f).setMethod("GET").setResponseType("arraybuffer").setTransportBuilder(r(f, b));
            o(k);
            g = new(c("MaybeNativePromise"))(function(b, c) {
                k.setErrorHandler(function(a) {
                    e.$12(k), c(d("VideoPlayerShakaError").translateError(a, f, "preload"))
                }), k.setResponseHandler(function(a) {
                    a = a;
                    var c = k;
                    e.$12(k);
                    b(babelHelpers["extends"]({}, c, {
                        response: a,
                        initiator: "XHR_REQUEST"
                    }))
                }), k.setAbortHandler(function() {
                    e.$12(k);
                    var b = n(a);
                    c(b)
                })
            });
            this.$13(a, g);
            this.$3.push(k);
            this.$8 ? this.$8.push(k) : k.send();
            return g
        };
        e.genPrefetchMpdNow = function(a) {
            return b("regeneratorRuntime").async(function(b) {
                while (1) switch (b.prev = b.next) {
                    case 0:
                        if (!this.has(a)) {
                            b.next = 2;
                            break
                        }
                        return b.abrupt("return", null);
                    case 2:
                        return b.abrupt("return", this.$11(a));
                    case 3:
                    case "end":
                        return b.stop()
                }
            }, null, this)
        };
        e.$14 = function(b, c, d) {
            c === void 0 && (c = !1);
            d === void 0 && (d = null);
            var e = [];
            for (var f = 0; f < b.length; f++) {
                var g = a.createQueryStringURL(b[f]);
                this.has(g) || (e.push(this.$11(g, c).then(function(a) {
                    m("received", 1);
                    return a
                })), d != null && this.$2.set(g, d))
            }
            m("sent", e.length);
            return e
        };
        e.$15 = function(e) {
            var f = this,
                g = a.getConsolidatedURL(e);
            if (g == null) return this.$14(e);
            var h = new(c("XHRRequest"))(g).setMethod("GET").setResponseType("arraybuffer").setTransportBuilder(r(g));
            o(h);
            var i = Date.now(),
                j = [];
            for (var k = 0; k < e.length; k++) {
                var l = a.createQueryStringURL(e[k]),
                    n = new(c("Deferred"))();
                this.has(l) || this.$13(l, n.getPromise());
                j.push(n)
            }
            h.setErrorHandler(function(a) {
                f.$12(h);
                for (var b = 0; b < j.length; b++) j[b].reject(d("VideoPlayerShakaError").translateError(a, g, "preload"))
            });
            h.setResponseHandler(function(a) {
                a = a;
                var b = Date.now() - i;
                for (var c = 0; c < e.length; c++) {
                    var d = j[c],
                        g = e[c];
                    d.resolve(t(a, g, b))
                }
                f.$12(h)
            });
            h.setAbortHandler(function() {
                for (var a = 0; a < e.length; a++) {
                    var b = j[a];
                    b.reject(new Error("Request aborted."))
                }
            });
            this.$3.push(h);
            h.send();
            m("consolidated.sent", 1);
            m("sent", j.length);
            l = j.map(function(a) {
                return a.getPromise().then(function(a) {
                    m("received", 1);
                    return a
                })
            });
            b("Promise").all(l).then(function() {
                return m("consolidated.received", 1)
            })["catch"](function() {});
            return l
        };
        e.$16 = function(a) {
            var b = this,
                d = a.useCredentials,
                e = a.connectionQualityLevel;
            this.$5++;
            var f = this.$7 && !d;
            c("VideoPlayerPrefetchExperiments").enableGlobalSchedulerForPrefetch && (this.$8 = []);
            var g = f ? this.$15(a.video) : this.$14(a.video, d, e);
            f = f ? this.$15(a.audio) : this.$14(a.audio, d, e);
            e = this.$14(a.manifest, d);
            d = g.concat(f, e);
            if (this.$8) {
                var h = this.$8 || [];
                this.$8 = null;
                var i = "" + a.videoID,
                    j = c("MaybeNativePromise").all(d).then(function() {
                        return void 0
                    }, function() {
                        return void 0
                    });
                g = {
                    cancel: function() {},
                    getPromise: function() {
                        return j
                    },
                    name: "prefetch task, " + i,
                    run: function() {
                        i && q["delete"](i);
                        h.forEach(function(a) {
                            return a.send()
                        });
                        return j
                    }
                };
                k ? (c("VideoPlayerPrefetchExperiments").switchPrefetchTaskToHighPriWhenPlayed && i && q.set(i, g), k.getQueue("video").enqueue(g, c("VideoPlayerPrefetchExperiments").prefetchPriority), this.$17()) : (g.run(), c("MaybeNativePromise").all(d).then(function() {
                    return b.$17()
                })["catch"](function() {
                    return b.$17()
                }))
            } else c("MaybeNativePromise").all(d).then(function() {
                return b.$17()
            })["catch"](function() {
                return b.$17()
            })
        };
        e.$13 = function(a, b) {
            var e = this;
            a = d("VideoDashPrefetchCacheUtils").stripNonCachingParams(a);
            this.$1.values().next().done && i(function() {
                for (var a = 0; a < e.$3.length; a++) e.$3[a].abort();
                e.$3 = [];
                e.$4 = [];
                e.$5 = 0;
                e.$1.clear();
                e.$10.forEach(function(a) {
                    c("clearTimeout")(a)
                });
                e.$10.clear()
            });
            this.$1.set(a, b);
            b = c("setTimeout")(function() {
                e.$1.has(a) && e.$1["delete"](a), e.$10["delete"](a)
            }, h);
            this.$10.set(a, b)
        };
        e.$12 = function(a) {
            a = this.$3.indexOf(a);
            a > -1 && this.$3.splice(a, 1)
        };
        e.$17 = function() {
            this.$5--;
            var a = this.$4.shift();
            a && this.$16(a)
        };
        e.has = function(a) {
            a = d("VideoDashPrefetchCacheUtils").stripNonCachingParams(a);
            return this.$1.has(a)
        };
        e.getConnectionQualityLevel = function(a) {
            return this.$2.get(a)
        };
        e.getAndDelete = function(a) {
            a = d("VideoDashPrefetchCacheUtils").stripNonCachingParams(a);
            var b = this.$1.get(a);
            if (b) {
                m("cache.hit", 1);
                var e = this.$10.get(a);
                e != null && (c("clearTimeout")(e), this.$10["delete"](a))
            } else m("cache.miss", 1);
            this.$1["delete"](a);
            m("retrieve", 1);
            return b
        };
        e.queueRequestBatch = function(a) {
            this.$6 === 0 || this.$5 < this.$6 ? this.$16(a) : (m("queued", l(a)), this.$4.push(a))
        };
        e.setCachedRepresentations = function(a, b) {
            this.$9.set(a, b)
        };
        e.getCachedRepresentations = function(a) {
            return this.$9.get(a)
        };
        a.getCachedRepresentations = function(b) {
            return a.getInstance().getCachedRepresentations(b)
        };
        a.getInstance = function() {
            p === null && (p = new a());
            return p
        };
        a.createQueryStringURL = function(a) {
            var b = a.start,
                c = a.end,
                e;
            if (b != null && c !== null && c !== void 0) {
                var f;
                e = (f = d("ConstUriUtils").getUri(a.url)) == null ? void 0 : (f = f.addQueryParam("bytestart", b)) == null ? void 0 : (b = f.addQueryParam("byteend", c)) == null ? void 0 : b.toString()
            }
            return (f = e) != null ? f : a.url
        };
        a.getConsolidatedURL = function(b) {
            var c = "",
                d = Infinity,
                e = 0;
            for (var f = 0; f < b.length; f++) {
                var g = b[f],
                    h = g.url,
                    i = g.start;
                g = g.end;
                if (h == null || i == null || g == null) return null;
                if (c === "") c = h;
                else if (c !== h) return null;
                d = Math.min(d, i);
                e = Math.max(e, g)
            }
            return a.createQueryStringURL({
                url: c,
                start: d,
                end: e
            })
        };
        a.getPrefetchInfoFromRepresentation = function(a) {
            return a.segments.map(function(b) {
                return {
                    url: a.url,
                    start: b.start,
                    end: b.end
                }
            })
        };
        a.getVideoRepresentationFromRepresentations = function(a, b) {
            var c = a.find(function(a) {
                return a.representation_id.endsWith("d")
            });
            !b && j && (b = j.getBandwidth());
            if (!b) return c;
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = c && c.bandwidth || 0;
                if (f > e.bandwidth) continue;
                else b > e.bandwidth && (c = e)
            }
            return c
        };
        a.loadVideoGivenAllRepresentations = function(b, c, d) {
            if (a.isAutoplayBandwidthRestrained()) return;
            var e = [],
                f = [];
            c.audio.length > 0 && (e = a.getPrefetchInfoFromRepresentation(c.audio[0]), e.length > 0 && f.push(c.audio[0].representation_id));
            var g = [];
            c = a.getVideoRepresentationFromRepresentations(c.video, d);
            c && (g = a.getPrefetchInfoFromRepresentation(c), g.length > 0 && f.push(c.representation_id));
            d = a.getInstance();
            d.queueRequestBatch({
                audio: e,
                video: g,
                manifest: [],
                videoID: b,
                useCredentials: !1
            });
            d.setCachedRepresentations(b, f)
        };
        a.isAutoplayBandwidthRestrained = function() {
            return !!j && j.isAutoplayBandwidthRestrained()
        };
        a.loadVideo = function(b, d, e) {
            d = !!d;
            if (!c("VideoPlayerPrefetchExperiments").disableShakaBandwidthEstimator && j && j.isAutoplayBandwidthRestrained()) return;
            if (c("VideoPlayerPrefetchExperiments").disablePrefetchCache) return;
            var f = a.getInstance();
            Array.isArray(b.manifest) || (b.manifest = []);
            b.video || (b.video = []);
            b.audio || (b.audio = []);
            f.queueRequestBatch({
                manifest: b.manifest.filter(s),
                video: b.video.filter(s),
                audio: b.audio.filter(s),
                videoID: b.videoID,
                useCredentials: d,
                connectionQualityLevel: e
            })
        };
        a.getCacheValue = function(b) {
            return a.getInstance().getAndDelete(b)
        };
        a.getConnectionQualityLevel = function(b) {
            return a.getInstance().getConnectionQualityLevel(b)
        };
        a.hasCacheValue = function(b) {
            return a.getInstance().has(b)
        };
        a.getPrefetchTaskByID = function(a) {
            return q.get(a) || null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoDisplayTimePlayButton", ["CSS", "DataStore", "Event"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {},
        i = "_spinner";

    function a(a) {
        return d("DataStore").get(a, "clicked", !1)
    }

    function b(a, b) {
        var e = a.id;
        h[e] = c("Event").listen(a, "click", function() {
            b && (d("CSS").hide(a), d("CSS").show(b)), d("DataStore").set(a, "clicked", !0)
        });
        b && (h[e + i] = c("Event").listen(b, "click", function() {
            b && d("CSS").hide(b), d("CSS").show(a), d("DataStore").set(a, "clicked", !1)
        }))
    }

    function e(a) {
        a = a.id;
        Object.prototype.hasOwnProperty.call(h, a) && h[a].remove();
        a = a + i;
        Object.prototype.hasOwnProperty.call(h, a) && h[a].remove()
    }
    g.getClicked = a;
    g.register = b;
    g.unregister = e
}), 98);
__d("VideoPlayerUIComponentDrawer", ["EventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            var d;
            d = a.call(this) || this;
            d.$VideoPlayerUIComponentDrawer1 = b;
            d.$VideoPlayerUIComponentDrawer2 = c;
            d.$VideoPlayerUIComponentDrawer4 = !1;
            return d
        }
        var c = b.prototype;
        c.reserve = function() {
            if (this.$VideoPlayerUIComponentDrawer4) return;
            this.$VideoPlayerUIComponentDrawer4 = !0;
            this.emit("reserve")
        };
        c.release = function() {
            if (!this.$VideoPlayerUIComponentDrawer4) return;
            this.$VideoPlayerUIComponentDrawer4 = !1;
            this.emit("release")
        };
        c.getPriority = function() {
            return this.$VideoPlayerUIComponentDrawer1
        };
        c.getHeight = function() {
            return this.$VideoPlayerUIComponentDrawer2
        };
        c.setHeight = function(a) {
            this.$VideoPlayerUIComponentDrawer2 = a, this.emit("heightChange")
        };
        c.emit = function(b) {
            var c;
            for (var d = arguments.length, e = new Array(d > 1 ? d - 1 : 0), f = 1; f < d; f++) e[f - 1] = arguments[f];
            b === "reposition" && (this.$VideoPlayerUIComponentDrawer3 = e[0]);
            (c = a.prototype.emit).call.apply(c, [this, b].concat(e))
        };
        c.reposition = function() {
            this.emit("reposition", this.$VideoPlayerUIComponentDrawer3)
        };
        c.isReserved = function() {
            return this.$VideoPlayerUIComponentDrawer4
        };
        return b
    }(c("EventEmitter"));
    a.priorities = {
        EmbeddedControls: 0,
        AdBreakStartingIndicator: 1,
        ClickForMore: 2,
        PollCard: 5,
        GameshowCard: 6,
        Subtitles: 3,
        SphericalMouseAnimation: 4
    };
    g["default"] = a
}), 98);
__d("VideoPlayerVolumeSettings", ["FBLogger", "WebStorage"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a() {
            this.$1 = 1, this.$2 = 1
        }
        var b = a.prototype;
        b.getVolume = function() {
            var a = c("WebStorage").getLocalStorage();
            if (a) {
                a = a.getItem("videoPlayerControllerVolume");
                return a === null || isNaN(+a) ? 1 : +a
            }
            return this.$1
        };
        b.getSessionVolume = function() {
            return this.$1
        };
        b.setSessionVolume = function(a) {
            this.$1 = a
        };
        b.saveVolume = function(a) {
            var b = c("WebStorage").getLocalStorage();
            if (b) {
                b = c("WebStorage").setItemGuarded(b, "videoPlayerControllerVolume", a.toString());
                b != null && c("FBLogger")("video").catching(b).warn("Attempt to set the video volume failed.")
            }
            this.$1 = a
        };
        b.getLastVolumeBeforeMute = function() {
            var a = c("WebStorage").getLocalStorage();
            if (a) {
                a = a.getItem("videoPlayerControllerLastVolumeBeforeMute");
                return a === null || isNaN(+a) ? 1 : +a
            }
            return this.$2
        };
        b.saveLastVolumeBeforeMute = function(a) {
            var b = c("WebStorage").getLocalStorage();
            if (b) {
                b = c("WebStorage").setItemGuarded(b, "videoPlayerControllerLastVolumeBeforeMute", a.toString());
                b != null && c("FBLogger")("video").catching(b).warn("Attempt to set the video volume failed.")
            }
            this.$2 = a
        };
        return a
    }();
    b = new a();
    d = b;
    g["default"] = d
}), 98);
__d("VideosRenderingInstrumentation", ["DataStore", "VideoPlayerHTML5Experiments", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        var b = c("VideoPlayerHTML5Experiments").useMonotonicallyIncreasingTimers ? c("performanceAbsoluteNow")() : Date.now();
        d("DataStore").set(a, "videos_rendering_instrumentation", b);
        return b
    }

    function a(a) {
        var b = d("DataStore").get(a, "videos_rendering_instrumentation", NaN);
        Number.isNaN(b) && (b = h(a));
        return b
    }
    g.storeRenderTime = h;
    g.retrieveRenderTime = a
}), 98);
__d("HTMLMediaElementReadyStates", [], (function(a, b, c, d, e, f) {
    a = {
        HAVE_NOTHING: 0,
        HAVE_METADATA: 1,
        HAVE_CURRENT_DATA: 2,
        HAVE_FUTURE_DATA: 3,
        HAVE_ENOUGH_DATA: 4
    };
    b = a;
    f["default"] = b
}), 66);
__d("VideoFrameBuffer", ["HTMLMediaElementReadyStates"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b, c, d, e, f, g) {
            d === void 0 && (d = null), e === void 0 && (e = null), f === void 0 && (f = null), g === void 0 && (g = null), this.$2 = b, this.$1 = a, this.$3 = c || "contain", this.$6 = d, this.$7 = e, this.$8 = f, this.$9 = g
        }
        var b = a.prototype;
        b.updateFrameBuffer = function() {
            this.$4 && (this.$1.width = this.$4, this.$4 = null);
            this.$5 && (this.$1.height = this.$5, this.$5 = null);
            if (this.$2.readyState < c("HTMLMediaElementReadyStates").HAVE_CURRENT_DATA) return;
            var a = this.$1.clientWidth || this.$1.width,
                b = this.$1.clientHeight || this.$1.height,
                d = a,
                e = b,
                f = this.$2.videoWidth / this.$2.videoHeight,
                g = d / e;
            this.$3 === "cover" && (g *= -1, f *= -1);
            g > f ? d = e * f : g < f && (e = d / f);
            g = this.$1.getContext("2d");
            if (!(g instanceof window.CanvasRenderingContext2D)) return;
            try {
                if (this.$6 || this.$7) {
                    g.drawImage(this.$2, (f = this.$8) != null ? f : 0, (f = this.$9) != null ? f : 0, (f = this.$6) != null ? f : a, (f = this.$7) != null ? f : b, 0, 0, a, b)
                } else g.drawImage(this.$2, (a - d) / 2, (b - e) / 2, d, e)
            } catch (a) {
                if (a.name !== "NS_ERROR_NOT_AVAILABLE") throw a
            }
        };
        b.getDOMNode = function() {
            return this.$1
        };
        b.updateDimensions = function(a, b) {
            this.$4 = a, this.$5 = b
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("Clipboard", ["Promise", "UserAgent"], (function(a, b, c, d, e, f, g) {
    function a() {
        return window.document && window.document.queryCommandSupported instanceof Function && window.document.queryCommandSupported("copy") && !(c("UserAgent").isBrowser("Firefox < 41") || c("UserAgent").isPlatform("iOS < 10.3")) || c("UserAgent").isBrowser("Chrome >= 43")
    }

    function h(a, b) {
        b = b || document.body;
        if (!b) return !1;
        var d = document.activeElement,
            e = !0,
            f = document.createElement("textarea");
        b.appendChild(f);
        f.value = a;
        if (c("UserAgent").isPlatform("iOS >= 10.3")) {
            a = document.createRange();
            a.selectNodeContents(f);
            var g = window.getSelection();
            g.removeAllRanges();
            g.addRange(a);
            f.setSelectionRange(0, 999999)
        } else f.select();
        try {
            e = document.execCommand("copy")
        } catch (a) {
            e = !1
        }
        b.removeChild(f);
        d != null && d.focus();
        return e
    }

    function d(a) {
        var c = window.navigator;
        if (c && c.clipboard && typeof c.clipboard.writeText === "function") return c.clipboard.writeText(a);
        return h(a) ? b("Promise").resolve() : b("Promise").reject()
    }
    g.isSupported = a;
    g.copy = h;
    g.copyAsync = d
}), 98);
__d("getVendorPrefixedEventName", ["fbjs/lib/ExecutionEnvironment"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        var c = {};
        c[a.toLowerCase()] = b.toLowerCase();
        c["Webkit" + a] = "webkit" + b;
        c["Moz" + a] = "moz" + b;
        c["ms" + a] = "MS" + b;
        c["O" + a] = "o" + b.toLowerCase();
        return c
    }
    var g = {
            animationend: a("Animation", "AnimationEnd"),
            animationiteration: a("Animation", "AnimationIteration"),
            animationstart: a("Animation", "AnimationStart"),
            transitionend: a("Transition", "TransitionEnd")
        },
        h = {},
        i = {};
    b("fbjs/lib/ExecutionEnvironment").canUseDOM && (i = document.createElement("div").style, "AnimationEvent" in window || (delete g.animationend.animation, delete g.animationiteration.animation, delete g.animationstart.animation), "TransitionEvent" in window || delete g.transitionend.transition);

    function c(a) {
        if (h[a]) return h[a];
        else if (!g[a]) return a;
        var b = g[a];
        for (var c in b)
            if (Object.prototype.hasOwnProperty.call(b, c) && c in i) return h[a] = b[c];
        return ""
    }
    e.exports = c
}), null);
__d("ReactTransitionEvents", ["fbjs/lib/ExecutionEnvironment", "getVendorPrefixedEventName"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = [];

    function a() {
        var a = b("getVendorPrefixedEventName")("animationend"),
            c = b("getVendorPrefixedEventName")("transitionend");
        a && g.push(a);
        c && g.push(c)
    }
    b("fbjs/lib/ExecutionEnvironment").canUseDOM && a();

    function h(a, b, c) {
        a.addEventListener(b, c, !1)
    }

    function i(a, b, c) {
        a.removeEventListener(b, c, !1)
    }
    c = {
        addEndEventListener: function(a, b) {
            if (g.length === 0) {
                window.setTimeout(b, 0);
                return
            }
            g.forEach(function(c) {
                h(a, c, b)
            })
        },
        removeEndEventListener: function(a, b) {
            if (g.length === 0) return;
            g.forEach(function(c) {
                i(a, c, b)
            })
        }
    };
    e.exports = c
}), null);