if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometSetDarkModeSettingMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7080935065311534"
}), null);
__d("CometSetDarkModeSettingMutation.graphql", ["CometSetDarkModeSettingMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            },
            c = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "setting"
            },
            d = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "input",
                    variableName: "input"
                }, {
                    kind: "Variable",
                    name: "setting",
                    variableName: "setting"
                }],
                concreteType: "SetDarkModeSettingResponsePayload",
                kind: "LinkedField",
                name: "set_dark_mode_setting",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "Viewer",
                    kind: "LinkedField",
                    name: "viewer",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: [{
                            kind: "Literal",
                            name: "product",
                            value: "COMET"
                        }],
                        kind: "ScalarField",
                        name: "dark_mode_setting",
                        storageKey: 'dark_mode_setting(product:"COMET")'
                    }],
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: [a, c],
                kind: "Fragment",
                metadata: null,
                name: "CometSetDarkModeSettingMutation",
                selections: d,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [c, a],
                kind: "Operation",
                name: "CometSetDarkModeSettingMutation",
                selections: d
            },
            params: {
                id: b("CometSetDarkModeSettingMutation_facebookRelayOperation"),
                metadata: {},
                name: "CometSetDarkModeSettingMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("CometTriggerAccessibilityAlertContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(function() {
        return function() {}
    });
    g["default"] = b
}), 98);
__d("CometDarkMode", ["CometDarkModeSetting", "CometRelay", "CometRelayEnvironment", "CometSetDarkModeSettingMutation.graphql", "CometStyleXSheet", "Env", "ExecutionEnvironment", "ODS", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("919810") && c("Env").isCometOnMobile !== !0,
        i = "(prefers-color-scheme: dark)",
        j = {
            product: "COMET"
        },
        k = d("CometDarkModeSetting").initialSetting,
        l = new Set();

    function a(a) {
        l.add(a);
        return function() {
            l["delete"](a)
        }
    }

    function m(a) {
        k = a;
        var b = n();
        l.forEach(function(a) {
            return a(b)
        });
        h && p(b)
    }

    function n() {
        return !h ? "DISABLED" : k
    }

    function b() {
        return n() === "ENABLED"
    }

    function e(a, b) {
        var e = b.onRevert;
        if (!c("ExecutionEnvironment").canUseDOM) return;
        var f = k;
        if (f === a) return;
        m(a);

        function g(b) {
            b = b.getRoot().getLinkedRecord("viewer");
            if (b == null) return;
            var c = b.getValue("dark_mode_setting", j);
            if (c === a) return;
            b.setValue("dark_mode_setting", a, j)
        }
        d("CometRelay").commitMutation(c("CometRelayEnvironment"), {
            mutation: c("CometSetDarkModeSettingMutation.graphql"),
            onError: function() {
                m(f), e(f)
            },
            optimisticUpdater: g,
            variables: {
                input: j,
                setting: a
            }
        })
    }

    function o(a, b, c) {
        c ? a.classList.add(b) : a.classList.remove(b)
    }

    function f(a) {
        p(a ? "ENABLED" : "DISABLED")
    }

    function p(a) {
        if (!c("ExecutionEnvironment").canUseDOM) return;
        var b = window.document.documentElement;
        o(b, d("CometStyleXSheet").DARK_MODE_CLASS_NAME, a === "ENABLED");
        o(b, d("CometStyleXSheet").LIGHT_MODE_CLASS_NAME, a === "DISABLED" || a === "UNDECLARED")
    }

    function q() {
        p(n());
        if (window.matchMedia != null) {
            var a = "comet.dark_mode_audit",
                b = window.matchMedia(i).matches;
            d("ODS").bumpFraction(4929, a, "system_setting_is_dark_mode", b ? 1 : 0, 1);
            d("ODS").bumpFraction(4929, a, "initial_setting_is_use_system", d("CometDarkModeSetting").initialSetting === "USE_SYSTEM" ? 1 : 0, 1);
            b = b !== d("CometDarkModeSetting").initialGuessForDarkModeOnClient;
            d("ODS").bumpFraction(4929, a, "server_guess_is_incorrect", b ? 1 : 0, 1);
            window.__invalidateSSR != null && d("CometDarkModeSetting").initialSetting === "USE_SYSTEM" && b && window.__invalidateSSR("Incorrect guess for client dark mode state")
        }
    }
    g.onDarkModeChange = a;
    g.getDarkModeSetting = n;
    g.getDarkModePreference = b;
    g.saveDarkModeSetting = e;
    g.toggleDarkModeRootClass = f;
    g.updateDarkModeRootClass = p;
    g.initDarkMode = q
}), 98);
__d("CometNUXManagerContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    var h = new Set(),
        i = new Map();
    b = a.createContext({
        registerNUX: function(a, b, d) {
            d === void 0 && (d = !1);
            if (h.has(a) || !d && i.has(a)) return c("emptyFunction");
            i.has(a) || i.set(a, []);
            (d = i.get(a)) == null ? void 0 : d.push(b);
            b(!0);
            return function() {
                var c;
                i.set(a, (c = (c = i.get(a)) == null ? void 0 : c.filter(function(a) {
                    return a !== b
                })) != null ? c : []);
                ((c = i.get(a)) == null ? void 0 : c.length) === 0 && i["delete"](a)
            }
        },
        removeNUX: function(a) {
            h.add(a);
            a = i.get(a);
            a != null && a.forEach(function(a) {
                return a(!1)
            })
        }
    });
    g["default"] = b
}), 98);
__d("BasePopoverArrowContainer.react", ["BaseContextualLayerContextSizeContext", "BaseContextualLayerLayerAdjustmentContext", "BaseContextualLayerOrientationContext", "Locale", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = 6,
        l = 16,
        m = {
            arrow: {
                borderBottomColor: "x16stqrj",
                borderEndColor: "xogb00i",
                borderStartColor: "x1ftr3km",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopColor: "x1v8p93f",
                borderTopWidth: "x1kr8tdy",
                borderEndWidth: "x1e7kja",
                borderBottomWidth: "xqm4iv",
                borderStartWidth: "x19d7kov",
                pointerEvents: "x47corl",
                position: "x10l6tqk"
            },
            arrowAlignBottom: {
                bottom: "x1ey2m1c"
            },
            arrowAlignEnd: {
                end: "xds687c"
            },
            arrowAlignHorizontalCenter: {
                start: "x79fbxx"
            },
            arrowAlignStart: {
                start: "x17qophe"
            },
            arrowAlignTop: {
                top: "x13vifvy"
            },
            arrowAlignVerticalCenter: {
                top: "x6ewuzp"
            }
        },
        n = {
            above: {
                marginBottom: "x1fqp7bg"
            },
            below: {
                marginTop: "xcxhlts"
            },
            end: {
                marginStart: "x13ibhcj"
            },
            start: {
                marginEnd: "x1jqylkn"
            }
        },
        o = {
            above: {
                borderBottomColor: "xpn8fn3",
                borderStartColor: "xtct9fg",
                boxShadow: "x1ew2t21",
                top: "xdsb8wn"
            },
            below: {
                borderEndColor: "x1xm1mqw",
                borderTopColor: "x6zyg47",
                bottom: "x10w3d4m",
                boxShadow: "x1mnrasx"
            },
            end: {
                borderBottomColor: "xpn8fn3",
                borderStartColor: "xtct9fg",
                boxShadow: "x1ew2t21",
                end: "x1hlliyw"
            },
            start: {
                borderBottomColor: "xpn8fn3",
                borderEndColor: "x1xm1mqw",
                boxShadow: "x1g0b5sy",
                start: "xulwito"
            }
        },
        p = d("Locale").isRTL(),
        q = p ? "start" : "end",
        r = p ? "end" : "start";

    function a(a, b) {
        var d = a.arrowAlignment,
            e = a.children,
            f = a.testid,
            g = a.withArrow,
            s = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["arrowAlignment", "children", "testid", "withArrow", "xstyle"]);
        var t = i(c("BaseContextualLayerOrientationContext")),
            u = t.align,
            v = t.position,
            w = i(c("BaseContextualLayerContextSizeContext")),
            x = (t = i(c("BaseContextualLayerLayerAdjustmentContext"))) != null ? t : 0;
        t = n[v];
        var y = j(function() {
                var a = 0,
                    b = 0,
                    c = 0,
                    e = 0,
                    f = 0;
                switch (v) {
                    case "above":
                        c += -x;
                        e += -7;
                        f = 45 * (p ? 1 : -1);
                        break;
                    case "below":
                        c += -x;
                        e += 7;
                        f = 45 * (p ? 1 : -1);
                        break;
                    case r:
                        c += -6;
                        e += -x;
                        f = -45;
                        break;
                    case q:
                        c += 6;
                        e += -x;
                        f = 45;
                        break
                }
                var g = l;
                if (v === "start" || v === "end") {
                    d === "center" && (g = w ? w.height / 2 : 0);
                    var h = Math.max(g, l),
                        i = h - g;
                    u === "start" ? (e += h - k, b -= i) : u === "end" && (e -= h - k, b += i)
                } else if (v === "above" || v === "below") {
                    d === "center" && (g = w ? w.width / 2 : 0);
                    h = Math.max(g, l);
                    i = h - g;
                    u === r ? (c += h - k, a -= i) : u === q && (c -= h - k, a += i)
                }
                return {
                    arrowTransform: "translate(" + c + "px, " + e + "px) rotate(" + f + "deg)",
                    popoverTransform: "translate(" + a + "px, " + b + "px)"
                }
            }, [u, d, w, x, v]),
            z = y.arrowTransform;
        y = y.popoverTransform;
        return h.jsxs("div", babelHelpers["extends"]({}, a, {
            className: c("stylex")(s, g && t),
            ref: b,
            style: g ? {
                transform: y
            } : void 0
        }, c("testID")(f), {
            children: [e, g ? h.jsx("div", {
                className: c("stylex")(m.arrow, o[v], (v === "above" || v === "below") && [u === "middle" && m.arrowAlignHorizontalCenter, u === "start" && m.arrowAlignStart, u === "end" && m.arrowAlignEnd], (v === "start" || v === "end") && [u === "middle" && m.arrowAlignVerticalCenter, u === "start" && m.arrowAlignTop, u === "end" && m.arrowAlignBottom]),
                style: {
                    transform: z
                }
            }) : null]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("BasePopoverDownEdgeArrow.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            height: 12,
            viewBox: "0 0 21 12",
            width: 21
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M20.685.12c-2.229.424-4.278 1.914-6.181 3.403L5.4 10.94c-2.026 2.291-5.434.62-5.4-2.648V.12h20.684z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    g["default"] = a
}), 98);
__d("BasePopoverDownInsetArrow.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            height: 12,
            viewBox: "0 0 25 12",
            width: 25
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M24.553.103c-2.791.32-5.922 1.53-7.78 3.455l-9.62 7.023c-2.45 2.54-5.78 1.645-5.78-2.487V2.085C1.373 1.191.846.422.1.102h24.453z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    g["default"] = a
}), 98);
__d("BasePopoverRightEdgeArrow.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            height: 21,
            viewBox: "0 0 12 21",
            width: 12
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M20.685.12c-2.229.424-4.278 1.914-6.181 3.403L5.4 10.94c-2.026 2.291-5.434.62-5.4-2.648V.12Z",
                transform: "rotate(-90 10.498 10.488)"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    g["default"] = a
}), 98);
__d("BasePopoverRightInsetArrow.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            height: 25,
            viewBox: "0 0 12 25",
            width: 12
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M24.553.103c-2.791.32-5.922 1.53-7.78 3.455l-9.62 7.023c-2.45 2.54-5.78 1.645-5.78-2.487V2.085C1.373 1.19.846.422.1.102z",
                transform: "rotate(-90 12.5 12.48)"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    g["default"] = a
}), 98);
__d("BasePopoverSVGArrowContainer.react", ["BaseContextualLayerContextSizeContext", "BaseContextualLayerLayerAdjustmentContext", "BaseContextualLayerOrientationContext", "BasePopoverDownEdgeArrow.svg.react", "BasePopoverDownInsetArrow.svg.react", "BasePopoverRightEdgeArrow.svg.react", "BasePopoverRightInsetArrow.svg.react", "Locale", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = 3,
        l = c("Locale").isRTL(),
        m = 25,
        n = {
            arrow: {
                position: "x10l6tqk"
            },
            container: {
                position: "x1n2onr6"
            }
        },
        o = {
            above: {
                filter: "x1fayt1i",
                marginBottom: "x1fqp7bg"
            },
            below: {
                filter: "x1fayt1i",
                marginTop: "xcxhlts"
            },
            end: {
                filter: "x1fayt1i",
                marginStart: "x13ibhcj"
            },
            start: {
                filter: "x1fayt1i",
                marginEnd: "x1jqylkn"
            }
        },
        p = {
            above: {
                top: "x11k2h6o"
            },
            below: {
                bottom: "xng853d"
            },
            end: {
                end: "x1gozi89"
            },
            start: {
                start: "x1ke83zm"
            }
        },
        q = {
            end: {
                end: "xds687c"
            },
            middle: {
                start: "xu8u0ou"
            },
            start: {
                start: "x17qophe"
            },
            stretch: {}
        },
        r = {
            end: {
                bottom: "x1ey2m1c"
            },
            middle: {
                top: "x18g6o9x"
            },
            start: {
                top: "x13vifvy"
            },
            stretch: {}
        };

    function s(a, b, c) {
        c = c - k;
        if (!a) return b === "end" || b === "middle" ? c * -1 : c;
        return l && b === "start" || !l && b === "end" ? c * -1 : c
    }

    function t(a, b, c, d) {
        if (c === "edge" || d == null) return {};
        c = a === "below" || a === "above";
        a = c ? d.width : d.height;
        d = a > 0 ? a / 2 : 0;
        if (d === 0) return {};
        a = s(c, b, b === "middle" ? m / 2 : d);
        return {
            transform: c ? "translateX(" + a + "px)" : "translateY(" + a + "px)"
        }
    }

    function u(a, b) {
        return a === "above" || a === "below" ? b === "middle" ? c("BasePopoverDownInsetArrow.svg.react") : c("BasePopoverDownEdgeArrow.svg.react") : b === "middle" ? c("BasePopoverRightInsetArrow.svg.react") : c("BasePopoverRightEdgeArrow.svg.react")
    }

    function a(a, b) {
        var d, e = a.arrowAlignment,
            f = a.children,
            g = a.testid,
            k = a.withArrow,
            m = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["arrowAlignment", "children", "testid", "withArrow", "xstyle"]);
        var s = i(c("BaseContextualLayerOrientationContext")),
            v = s.align,
            w = s.position,
            x = i(c("BaseContextualLayerContextSizeContext"));
        s = u(w, v);
        var y = (d = i(c("BaseContextualLayerLayerAdjustmentContext"))) != null ? d : 0;
        d = j(function() {
            var a = l ? "start" : "end",
                b = l ? "end" : "start",
                c = v === "end" && !l || v === "start" && l,
                d = 1,
                f = 1,
                g = 0,
                h = 0;
            switch (w) {
                case "above":
                    g += -y;
                    c && (d = -1);
                    break;
                case "below":
                    g += -y;
                    f = -1;
                    c && (d = -1);
                    break;
                case b:
                    h += -y;
                    v === "start" && (f = -1);
                    break;
                case a:
                    h += -y;
                    d = -1;
                    v === "start" && (f = -1);
                    break
            }
            return {
                arrowStyle: {
                    transform: "scale(" + d + ", " + f + ") translate(" + g + "px, " + h + "px)"
                },
                containerStyle: t(w, v, e, x)
            }
        }, [v, e, x, y, w]);
        var z = d.arrowStyle;
        d = d.containerStyle;
        return h.jsxs("div", babelHelpers["extends"]({}, a, {
            className: c("stylex")(n.container, m, k && o[w]),
            ref: b,
            style: k ? d : void 0
        }, c("testID")(g), {
            children: [f, k ? h.jsx(s, {
                className: c("stylex")(n.arrow, p[w], (w === "start" || w === "end") && r[v], (w === "above" || w === "below") && q[v]),
                fill: "var(--card-background)",
                style: z
            }) : null]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("HeroBootloadPerfStore", ["BootloaderEvents", "InteractionTracingMetrics", "ResourceTimingStore", "gkx", "performanceNavigationStart"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = ["encodedBodySize", "transferSize", "totalCount", "cacheCount"],
        i = ["t1", "t2", "t3"],
        j = ["untiered"],
        k = ["js", "css"],
        l = new Map();
    d("BootloaderEvents").onBootload(function(a) {
        a.components.forEach(function(b) {
            l.set(b, a)
        })
    });

    function m(a) {
        try {
            return new URL(a).pathname
        } catch (a) {
            return "[invalid url]"
        }
    }

    function n(a, b) {
        if (b == null) {
            a.missingData++;
            return
        }
        a.urls && a.urls.add(b.name);
        a.encodedBodySize += b.encodedBodySize;
        a.decodedBodySize += b.decodedBodySize;
        a.transferSize += b.transferSize;
        a.totalCount += 1;
        b.transferSize === 0 && (a.cacheCount += 1)
    }

    function o(a) {
        return a.src.indexOf("data") === 0
    }

    function p(a, b, e) {
        var f = new Map();

        function g(a) {
            var b;
            b = (b = f.get(a)) != null ? b : {
                cacheCount: 0,
                decodedBodySize: 0,
                encodedBodySize: 0,
                missingData: 0,
                totalCount: 0,
                transferSize: 0,
                urls: c("gkx")("1924645") ? new Set() : null
            };
            f.set(a, b);
            return b
        }

        function h(a, c) {
            var f = d("ResourceTimingStore").getEntryForURL(c.src);
            n(g("used_" + c.type), f);
            n(g("used_" + a), f);
            n(g("used_" + a + "_" + c.type), f);
            f != null && f.responseEnd >= b && f.responseEnd <= e && (n(g("downloaded_" + a), f), n(g("downloaded_" + c.type), f), n(g("downloaded_" + a + "_" + c.type), f))
        }

        function i(a, b) {
            a.decodedBodySize += b.length, a.totalCount += 1
        }

        function j(a, b) {
            i(g("inline_" + a), b.src), i(g("inline_" + b.type), b.src), i(g("inline_" + a + "_" + b.type), b.src)
        }
        var k = function() {
            if (m) {
                if (p >= l.length) return "break";
                q = l[p++]
            } else {
                p = l.next();
                if (p.done) return "break";
                q = p.value
            }
            var a = q,
                b = a[0];
            a = a[1];
            a.forEach(function(a, c) {
                if (!(a.type === "css" || a.type === "js")) return;
                o(a) ? j(b, a) : h(b, a)
            })
        };
        for (var l = a, m = Array.isArray(l), p = 0, l = m ? l : l[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var q;
            a = k();
            if (a === "break") break
        }
        return f
    }

    function q(a, b, c) {
        var d;
        d = (d = a.get(b)) != null ? d : new Map();
        a.set(b, d);
        for (var a = c, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var e;
            if (b) {
                if (c >= a.length) break;
                e = a[c++]
            } else {
                c = a.next();
                if (c.done) break;
                e = c.value
            }
            e = e;
            (e.type === "css" || e.type === "js") && d.set(e.src, e)
        }
    }

    function r(a, b, d, e) {
        d = p(d, a, b);
        a = {};
        for (var b = e, e = Array.isArray(b), f = 0, b = e ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= b.length) break;
                g = b[f++]
            } else {
                f = b.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            for (var i = k, j = Array.isArray(i), l = 0, i = j ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var n;
                if (j) {
                    if (l >= i.length) break;
                    n = i[l++]
                } else {
                    l = i.next();
                    if (l.done) break;
                    n = l.value
                }
                n = n;
                var o = "downloaded_" + g + "_" + n;
                for (var q = 0; q < h.length; q++) {
                    var r, s = h[q];
                    a[o + "_" + s] = (r = (r = d.get(o)) == null ? void 0 : r[s]) != null ? r : 0
                }
                if (c("gkx")("1924645")) {
                    a[o + "_urls"] = Array.from((r = (s = d.get(o)) == null ? void 0 : s.urls) != null ? r : []).map(m)
                }
                q = "inline_" + g + "_" + n;
                a[q + "_decodedBodySize"] = (s = (o = d.get(q)) == null ? void 0 : o.decodedBodySize) != null ? s : 0
            }
        }
        return a
    }

    function s(a, b, d, e) {
        var f = p(b, a.start, (b = a.completed) != null ? b : a.start);
        [].concat(k, e).forEach(function(b) {
            var e = f.get("downloaded_" + b);
            for (var g = 0; g < h.length; g++) {
                var i = h[g];
                c("InteractionTracingMetrics").addMetadata(a.traceId, d + "_downloaded_" + b + "_" + i, (i = e == null ? void 0 : e[i]) != null ? i : 0)
            }
            i = f.get("inline_" + b);
            c("InteractionTracingMetrics").addMetadata(a.traceId, d + "_inline_" + b + "_decodedBodySize", (g = i == null ? void 0 : i.decodedBodySize) != null ? g : 0)
        })
    }

    function t(a) {
        var b = new Map();
        a.heroRelay.forEach(function(e) {
            var f = e.pageletStack;
            e = e.queries;
            for (var e = e, g = Array.isArray(e), h = 0, e = g ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var i;
                if (g) {
                    if (h >= e.length) break;
                    i = e[h++]
                } else {
                    h = e.next();
                    if (h.done) break;
                    i = h.value
                }
                i = i;
                var k = i.hasteResponseLogEvents;
                for (var k = k, l = Array.isArray(k), m = 0, k = l ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var n, o;
                    if (l) {
                        if (m >= k.length) break;
                        o = k[m++]
                    } else {
                        m = k.next();
                        if (m.done) break;
                        o = m.value
                    }
                    o = o;
                    var p = o.startTime - c("performanceNavigationStart")(),
                        s = o.logTime - c("performanceNavigationStart")();
                    if (s < a.start || p > ((n = a.completed) != null ? n : Infinity)) return;
                    n = d("BootloaderEvents").flattenResourceMapSet(o.rsrcs);
                    o = new Map();
                    q(b, "untiered", n.values());
                    q(o, "untiered", n.values());
                    n = r(p, s, o, j);
                    c("InteractionTracingMetrics").addSubspan(a.traceId, "Relay3D: " + i.name, "HeroTracing", Math.max(a.start, p), Math.min((o = a.completed) != null ? o : Infinity, s), babelHelpers["extends"]({}, {
                        pagelet: f[f.length - 1],
                        pageletStack: f,
                        spanType: "Relay3D"
                    }, n))
                }
            }
        });
        s(a, b, "relay3d", j)
    }

    function u(a) {
        var b;
        b = Array.from(new Set((b = []).concat.apply(b, a.heroBootloads.map(function(a) {
            return a.moduleIDs
        }))));
        var e = new Map(),
            f = new Map();
        b.forEach(function(a) {
            var b = l.get(a);
            b && f.set(a, b)
        });
        for (var b = f.values(), g = Array.isArray(b), h = 0, b = g ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var j;
            if (g) {
                if (h >= b.length) break;
                j = b[h++]
            } else {
                h = b.next();
                if (h.done) break;
                j = h.value
            }
            j = j;
            q(e, "t1", d("BootloaderEvents").flattenResourceMapSet(j.tierOne).values());
            q(e, "t2", d("BootloaderEvents").flattenResourceMapSet(j.tierTwo).values());
            q(e, "t3", d("BootloaderEvents").flattenResourceMapSet(j.tierThree).values())
        }
        s(a, e, "bootload", i);
        a.heroBootloads.forEach(function(b) {
            var e = b.moduleIDs,
                f = b.pageletStack;
            b = new Set(e.map(function(a) {
                return l.get(a)
            }).filter(Boolean));
            b.forEach(function(b) {
                var e;
                if (b.callbackEnd - c("performanceNavigationStart")() < a.start) return;
                var g = new Map();
                q(g, "t1", d("BootloaderEvents").flattenResourceMapSet(b.tierOne).values());
                q(g, "t2", d("BootloaderEvents").flattenResourceMapSet(b.tierTwo).values());
                q(g, "t3", d("BootloaderEvents").flattenResourceMapSet(b.tierThree).values());
                g = r(b.startTime - c("performanceNavigationStart")(), b.callbackEnd - c("performanceNavigationStart")(), g, i);
                c("InteractionTracingMetrics").addSubspan(a.traceId, "Bootload: " + b.components.join(), "HeroTracing", Math.max(a.start, b.startTime - c("performanceNavigationStart")()), Math.min((e = a.completed) != null ? e : Infinity, b.callbackStart - c("performanceNavigationStart")()), babelHelpers["extends"]({}, {
                    bootloadComponents: b.components,
                    bootloadRef: b.ref,
                    pagelet: f[f.length - 1],
                    pageletStack: f,
                    spanType: "Bootload"
                }, g))
            })
        })
    }

    function a(a) {
        d("ResourceTimingStore").init(), u(a), t(a)
    }
    g.addStaticResourcesStats = a
}), 98);
__d("setTimeoutComet", ["JSScheduler", "setTimeoutCometInternals"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = d("JSScheduler").getCurrentPriorityLevel() === d("JSScheduler").priorities.unstable_Idle ? d("JSScheduler").priorities.unstable_Idle : d("JSScheduler").priorities.unstable_Low;
        for (var e = arguments.length, f = new Array(e > 2 ? e - 2 : 0), g = 2; g < e; g++) f[g - 2] = arguments[g];
        return d("setTimeoutCometInternals").setTimeoutAtPriority_DO_NOT_USE.apply(d("setTimeoutCometInternals"), [c, a, b].concat(f))
    }
    g["default"] = a
}), 98);
__d("GeminiPluginErrorRoot.entrypoint", ["JSResourceForInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            return {}
        },
        root: c("JSResourceForInteraction")("GeminiPluginErrorRoot.react").__setRef("GeminiPluginErrorRoot.entrypoint")
    };
    b = a;
    g["default"] = b
}), 98);
__d("warningComet", ["SiteData", "cr:1072546", "cr:1072547", "cr:1072549", "cr:983844", "err", "fb-error"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {}
    b = a;
    c = b;
    g["default"] = c
}), 98);
__d("JSSPStatsTypedLogger", ["Banzai", "GeneratedLoggerUtils"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {}
        }
        var c = a.prototype;
        c.log = function() {
            b("GeneratedLoggerUtils").log("logger:JSSPStatsLoggerConfig", this.$1, b("Banzai").BASIC)
        };
        c.logVital = function() {
            b("GeneratedLoggerUtils").log("logger:JSSPStatsLoggerConfig", this.$1, b("Banzai").VITAL)
        };
        c.logImmediately = function() {
            b("GeneratedLoggerUtils").log("logger:JSSPStatsLoggerConfig", this.$1, {
                signal: !0
            })
        };
        c.clear = function() {
            this.$1 = {};
            return this
        };
        c.getData = function() {
            return babelHelpers["extends"]({}, this.$1)
        };
        c.updateData = function(a) {
            this.$1 = babelHelpers["extends"]({}, this.$1, a);
            return this
        };
        c.setBootUpTime = function(a) {
            this.$1.boot_up_time = a;
            return this
        };
        c.setShutDownTime = function(a) {
            this.$1.shut_down_time = a;
            return this
        };
        c.setTime = function(a) {
            this.$1.time = a;
            return this
        };
        c.setTraceSize = function(a) {
            this.$1.trace_size = a;
            return this
        };
        c.setWeight = function(a) {
            this.$1.weight = a;
            return this
        };
        return a
    }();
    c = {
        boot_up_time: !0,
        shut_down_time: !0,
        time: !0,
        trace_size: !0,
        weight: !0
    };
    e.exports = a
}), null);
__d("JSSelfProfiler", ["FBLogger", "JSSPStatsTypedLogger", "SiteData", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b) {
            this.$1 = a, this.$5 = b, this.$4 = !1
        }
        a.startRecording = function(b, d) {
            if (!a.isSupported()) {
                var e = new Error("JS Self Profiling is not supported");
                e.stack;
                throw e
            }
            e = performance.now();
            try {
                d = new Profiler({
                    sampleInterval: b,
                    maxBufferSize: d
                });
                e = performance.now() - e;
                d = new a(d, b);
                d.setStartUpTime(e);
                return d
            } catch (a) {
                c("FBLogger")("JSSelfProfiler").catching(a).warn("Could not initialize profiler")
            }
            return null
        };
        var d = a.prototype;
        d.stopRecording = function() {
            var a, d, e, f;
            return b("regeneratorRuntime").async(function(g) {
                while (1) switch (g.prev = g.next) {
                    case 0:
                        if (!this.$4) {
                            g.next = 4;
                            break
                        }
                        a = new Error("The profiling has stopped before stopRecording() is called");
                        a.stack;
                        throw a;
                    case 4:
                        d = performance.now();
                        g.next = 7;
                        return b("regeneratorRuntime").awrap(this.$1.stop());
                    case 7:
                        e = g.sent;
                        this.$3 = performance.now() - d;
                        e.resources = e.resources.map(function(a) {
                            return a.startsWith("data:") ? "inline JavaScript" : a
                        });
                        e.frames.forEach(function(a) {
                            a.resourceId != null && c("SiteData").push_phase === "dev" && (a.name = "")
                        });
                        f = {
                            trace: e,
                            stats: {
                                timeOrigin: performance.timeOrigin,
                                requestedSampleInterval: this.$5,
                                actualSampleInterval: this.$1.sampleInterval
                            }
                        };
                        this.$6 = JSON.stringify(e).length;
                        this.$4 = !0;
                        return g.abrupt("return", f);
                    case 15:
                    case "end":
                        return g.stop()
                }
            }, null, this)
        };
        d.setStartUpTime = function(a) {
            this.$2 = a
        };
        d.logStats = function() {
            if (this.$2 == null) {
                c("FBLogger")("JSSelfProfiler").warn("JSSP start up time is null/undefined");
                return
            }
            if (this.$3 == null) {
                c("FBLogger")("JSSelfProfiler").warn("JSSP shut down time is null/undefined");
                return
            }
            new(c("JSSPStatsTypedLogger"))().setBootUpTime(this.$2).setShutDownTime(this.$3).setTraceSize(this.$6).log()
        };
        a.isSupported = function() {
            return window.performance != null && typeof window.Profiler === "function" && performance.timeOrigin != null
        };
        a.setIsHeaderSent = function() {
            a.isHeaderSent = !0
        };
        return a
    }();
    a.isHeaderSent = !1;
    g["default"] = a
}), 98);
__d("WebLoomBanzaiTransport", ["Banzai"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        post: function(a, b) {
            c("Banzai").post("loom_trace", a, {
                callback: b.onComplete,
                delay: b.isHighPri ? c("Banzai").VITAL_WAIT : c("Banzai").BASIC_WAIT
            })
        },
        flush: function(a, b) {
            c("Banzai").flush(a, b)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("web-loom", ["Promise", "QPLEvent", "clamp", "interaction-tracing-metrics", "mapObject", "one-trace", "performanceAbsoluteNow", "performanceNavigationStart", "performanceNow", "recoverableViolation", "regeneratorRuntime", "uuid", "vc-tracker"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h, i, j = {
        js: "js",
        css: "css",
        wasm: "wasm",
        woff: "woff",
        woff2: "woff2",
        otf: "otf",
        eot: "eot",
        ttf: "ttf"
    };

    function k(a) {
        return Object.prototype.hasOwnProperty.call(j, a)
    }
    var l = new Map(),
        m = 0,
        n = /(\d{4,})/gm,
        o = /([a-f0-9]{8,})/gm;

    function p(a) {
        a = a.replace(n, "{N}");
        return a.replace(o, "{N}")
    }

    function q(a) {
        a = a.getPath();
        var b = a.lastIndexOf(".");
        return b === -1 ? "" : a.substring(b + 1)
    }

    function r() {
        return m++
    }

    function s(a) {
        if (a.getProtocol() !== "http" && a.getProtocol() !== "https") return !1;
        var b = Number(a.getPort());
        if (!!b && b !== 80 && b !== 443) return !1;
        return a.isSubdomainOfDomain("fbcdn.net") ? !0 : !1
    }

    function t(a, b) {
        b = new b.URI(a);
        a = q(b);
        b.setQueryString("");
        b.setFragment("");
        if (a === "" || a === "php" || a === "ico") {
            var c = p(b.getPath());
            c !== b.getPath() && b.setPath(c + "/sanitized-" + r())
        } else k(a) || b.setPath("/sanitized" + (s(b) ? "-cdn" : "") + "-" + r() + "." + a);
        return b.toString()
    }

    function u(a, b) {
        if (b.isBrowser("IE")) return "";
        l.has(a) || l.set(a, t(a, b));
        return l.get(a) || ""
    }
    var v = b("performanceNavigationStart")();

    function w(a) {
        return a.substr(0, 7) === "http://" || a.substr(0, 8) === "https://" ? !0 : !1
    }
    var x = new Set(["AppTiming", "CometHeroTiming", "RelayQuery", "HeroTracing", "GraphAPI", "FluxAction", "Debug", "DOMEventTiming", "AdsPreloader", "ServerTimings", "AdsPreloaderEvent", "LONGTASK", "INPUT_DELAY", "XController", "AdsEntryPoints", "LatePlaceholder", "HeroDebug"]),
        y = function() {
            var c = a.prototype;
            c.$1 = function(a) {
                return this.$2.sanitizeURIs && w(a) ? u(a, this.$3) : a
            };
            c.$4 = function(a, b) {
                var c = this.$5;
                if (!c) return;
                c.buffer.addEvent(a, v + b)
            };
            c.$6 = function(a, b, c) {
                var d = this,
                    e = a.subSpans,
                    f = function(f) {
                        e[f].forEach(function(e, g) {
                            if (x.has(e.type)) {
                                var h = e.data;
                                if (e.type === "CometHeroTiming" && (h == null || h.tracePolicy !== a.annotations.string.tracePolicy || c == null || h.event == null || !Array.isArray(h.event) || h.event.indexOf(c) === -1)) return;
                                h = {
                                    blockName: f + "_" + g,
                                    blockType: e.type,
                                    execUnitName: f,
                                    traceId: b,
                                    traceType: a.type
                                };
                                d.$4(babelHelpers["extends"]({
                                    type: "INTERACTION_TRACE_START"
                                }, h), e.start);
                                d.$4(babelHelpers["extends"]({
                                    blockAnnotations: e.data,
                                    type: "INTERACTION_TRACE_END"
                                }, h), e.end)
                            }
                        })
                    };
                for (var g in e) f(g)
            };
            c.$7 = function(a, b) {
                var c = a.payloadResources;
                for (var d in c) {
                    var e = c[d],
                        f = this.$1(d),
                        g = {
                            blockName: f,
                            blockType: "PayloadResources",
                            execUnitName: e.initiator,
                            traceId: b,
                            traceType: a.type
                        };
                    this.$4(babelHelpers["extends"]({
                        type: "INTERACTION_TRACE_START"
                    }, g), e.start);
                    this.$4({
                        blockName: f,
                        execUnitName: e.initiator,
                        pointAnnotations: {},
                        pointName: "requestStart",
                        traceId: b,
                        type: "INTERACTION_TRACE_POINT"
                    }, e.requestStart);
                    this.$4(babelHelpers["extends"]({
                        blockAnnotations: {
                            refs: e.refs.join(","),
                            transferSize: e.transferSize,
                            url: this.$1(e.url)
                        },
                        type: "INTERACTION_TRACE_END"
                    }, g), e.end)
                }
            };
            c.$8 = function(a, b) {
                var c = a.imagePreloaderTimings;
                for (var d in c) {
                    var e = c[d],
                        f = this.$1(d),
                        g = {
                            blockName: f,
                            blockType: "ImagePreloaders",
                            execUnitName: e.playloadName,
                            traceId: b,
                            traceType: a.type
                        };
                    this.$4(babelHelpers["extends"]({
                        type: "INTERACTION_TRACE_START"
                    }, g), e.start);
                    this.$4({
                        blockName: f,
                        execUnitName: e.playloadName,
                        pointAnnotations: {},
                        pointName: "requestStart",
                        traceId: b,
                        type: "INTERACTION_TRACE_POINT"
                    }, e.requestStart);
                    this.$4(babelHelpers["extends"]({
                        blockAnnotations: {
                            url: f
                        },
                        type: "INTERACTION_TRACE_END"
                    }, g), e.end)
                }
            };
            c.$9 = function(a, b) {
                var c = this,
                    d = a.payloadTimings,
                    e = function(e) {
                        var f = d[e];
                        if (f.start == null || f.end == null) return {
                            v: void 0
                        };
                        var g = {
                            blockName: e,
                            blockType: f.payloadType,
                            execUnitName: e,
                            traceId: b,
                            traceType: a.type
                        };
                        c.$4(babelHelpers["extends"]({
                            type: "INTERACTION_TRACE_START"
                        }, g), f.start);
                        Object.keys(f.points).forEach(function(a) {
                            c.$4({
                                blockName: e,
                                execUnitName: e,
                                pointAnnotations: {},
                                pointName: a,
                                traceId: b,
                                type: "INTERACTION_TRACE_POINT"
                            }, f.points[a])
                        });
                        var h = babelHelpers["extends"]({}, f.data);
                        for (var i in f.pkgStat) {
                            var j = f.pkgStat[i];
                            for (var k in j) h[i + "_" + k] = j[k]
                        }
                        c.$4(babelHelpers["extends"]({
                            blockAnnotations: h,
                            type: "INTERACTION_TRACE_END"
                        }, g), f.end)
                    };
                for (var f in d) {
                    var g = e(f);
                    if (typeof g === "object") return g.v
                }
            };
            c.$10 = function(a, b, c) {
                var d = a.markerPoints;
                for (var e in d) {
                    var f = d[e];
                    if (f.type === "AppTiming" || f.type === "CometHeroTiming" || f.type === "RelayQuery" || f.type === "VisualCompletion" || f.type === "ServerTimings" || f.type === "NavigationTiming") {
                        var g = f.timestamp,
                            h = f.type,
                            i = f.data;
                        if (f.type === "CometHeroTiming" && (i == null || i.tracePolicy !== a.annotations.string.tracePolicy || c == null || i.event == null || !Array.isArray(i.event) || i.event.indexOf(c) === -1)) continue;
                        i = {
                            blockName: e,
                            blockType: h,
                            execUnitName: e,
                            traceId: b,
                            traceType: a.type
                        };
                        this.$4(babelHelpers["extends"]({
                            type: "INTERACTION_TRACE_START"
                        }, i), g);
                        this.$4(babelHelpers["extends"]({
                            blockAnnotations: f.data || {},
                            type: "INTERACTION_TRACE_END"
                        }, i), g)
                    }
                }
            };
            c.$11 = function(a, b) {
                var c = a.requireDeferreds;
                for (var d in c) {
                    var e = c[d],
                        f = {
                            blockName: d,
                            blockType: "RequireDeferreds",
                            execUnitName: d,
                            traceId: b,
                            traceType: a.type
                        },
                        g = e.end;
                    if (g == null) continue;
                    this.$4(babelHelpers["extends"]({
                        type: "INTERACTION_TRACE_START"
                    }, f), e.start);
                    this.$4(babelHelpers["extends"]({
                        blockAnnotations: {
                            alreadyRequired: Boolean(e.alreadyRequired)
                        },
                        type: "INTERACTION_TRACE_END"
                    }, f), g)
                }
            };
            c.$12 = function(a, b, c, d) {
                for (var e = 0; e < d.length; e++) {
                    var f = {
                        blockName: a + "_" + e,
                        blockType: a,
                        execUnitName: a + "_" + e,
                        traceId: c,
                        traceType: b.type
                    };
                    this.$4(babelHelpers["extends"]({
                        type: "INTERACTION_TRACE_START"
                    }, f), d[e].start);
                    this.$4(babelHelpers["extends"]({
                        blockAnnotations: {},
                        type: "INTERACTION_TRACE_END"
                    }, f), d[e].end)
                }
            };
            c.$13 = function(a) {
                var b = this;
                a.vcStateLog != null && a.vcStateLog.forEach(function(c, d) {
                    var e = c[0];
                    c = c[1];
                    d = {
                        blockName: d,
                        blockType: "VCState",
                        execUnitName: "VCState",
                        traceId: a.traceId,
                        traceType: a.type
                    };
                    b.$4(babelHelpers["extends"]({
                        type: "INTERACTION_TRACE_START"
                    }, d), e);
                    b.$4(babelHelpers["extends"]({
                        blockAnnotations: {},
                        type: "INTERACTION_TRACE_END"
                    }, d), c)
                })
            };
            c.$14 = function(a) {
                var b = this;
                a.factoryTimings.forEach(function(c) {
                    var d = {
                        blockName: c.name,
                        blockType: "Factories",
                        execUnitName: "Factories",
                        traceId: a.traceId,
                        traceType: a.type
                    };
                    b.$4(babelHelpers["extends"]({
                        type: "INTERACTION_TRACE_START"
                    }, d), c.start);
                    b.$4(babelHelpers["extends"]({
                        blockAnnotations: {},
                        type: "INTERACTION_TRACE_END"
                    }, d), c.end)
                })
            };

            function a(a, b, c) {
                this.$5 = a, this.$3 = b, this.$2 = c
            }
            c.loomTraceWillEnd = function() {
                var a = this,
                    c = this.$5;
                if (!c) return;
                var d = b("interaction-tracing-metrics").InteractionTracingMetricsCore.dump(),
                    e = [];
                if (c.triggerInfo.type === "INTERACTION" && c.triggerInfo.interaction_id != null) e.push(c.triggerInfo.interaction_id);
                else
                    for (var f in d) {
                        var g = d[f];
                        g = g.completed != null ? v + g.completed : null;
                        (g == null || g > c.startTime) && e.push(f)
                    }
                e.forEach(function(b) {
                    var c = d[b];
                    a.$6(c, b, c.qplEvent);
                    a.$10(c, b, c.qplEvent);
                    a.$11(c, b);
                    a.$7(c, b);
                    a.$8(c, b);
                    a.$9(c, b);
                    a.$12("hidden", c, b, c.hiddenTimings);
                    a.$12("offline", c, b, c.offlineTimings);
                    a.$14(c);
                    a.$13(c)
                })
            };
            return a
        }(),
        z = {
            getInstance: function(a, b, c) {
                return new y(a, b, c)
            },
            isSupported: function() {
                return !0
            },
            loomProviderId: "InteractionTracing"
        },
        A = function() {
            function a(a, c) {
                var d = this;
                this.$1 = {};
                this.$2 = c.QuickPerformanceLogger.addListener({
                    onMarkerStart: function(c, e, f) {
                        c = b("QPLEvent").getMarkerId(c);
                        f >= a.startTime && a.buffer.addEvent({
                            type: "QPL_START",
                            markerId: c,
                            instanceKey: e
                        }, f);
                        d.$1[c] || (d.$1[c] = {});
                        d.$1[c][e] = f
                    },
                    onMarkerEnd: function(c, d, e, f) {
                        d = b("QPLEvent").getMarkerId(d);
                        f >= a.startTime && a.buffer.addEvent({
                            type: "QPL_END",
                            action: c,
                            markerId: d,
                            instanceKey: e
                        }, f)
                    },
                    onMarkerPoint: function(c, d, e, f, g) {
                        c = b("QPLEvent").getMarkerId(c);
                        if (g >= a.startTime) {
                            a.buffer.addEvent({
                                type: "QPL_POINT",
                                markerId: c,
                                instanceKey: d,
                                name: e,
                                data: f === null || f === void 0 ? void 0 : (c = f.string) === null || c === void 0 ? void 0 : c.__key
                            }, g)
                        }
                    },
                    onAnnotation: function(c, e, f, g) {
                        c = b("QPLEvent").getMarkerId(c);
                        var h = d.$1[c];
                        h = h === null || h === void 0 ? void 0 : h[e];
                        h != null && h >= a.startTime && a.buffer.addEvent({
                            type: "QPL_ANNOTATION",
                            markerId: c,
                            instanceKey: e,
                            annotationKey: f,
                            annotationValue: g
                        }, h)
                    }
                })
            }
            var c = a.prototype;
            c.loomTraceWillEnd = function() {
                this.$2.dispose()
            };
            return a
        }(),
        B = {
            loomProviderId: "QPL",
            isSupported: function() {
                return !0
            },
            getInstance: function(a, b) {
                return new A(a, b)
            }
        };

    function C(a, b) {
        b = b.substring(b.lastIndexOf(".") + 1);
        if (b == "js" || b == "css") return b;
        else if (a == "img" || b == "png" || b == "jpg" || b == "ico") return "img";
        else return a
    }
    var D = function() {
            a.isSupported = function() {
                return window.performance && window.performance.getEntriesByType && window.performance.timing && window.performance.timing.navigationStart
            };

            function a(a, b, c) {
                this.$1 = a, this.$2 = b, this.$3 = c
            }
            var c = a.prototype;
            c.$4 = function(a) {
                var c = a.entry,
                    d = a.resourceName,
                    e = a.resourceId,
                    f = a.resourceType,
                    g = a.startTime,
                    h = a.endTime,
                    i = this.$1;
                if (i != null) {
                    var j = window.performance.timing.navigationStart;
                    a = c;
                    i.buffer.addEvent({
                        type: "RESOURCE_TIMING_START",
                        resourceType: f,
                        resourceId: e,
                        resourceName: d,
                        encodedSize: a != null && typeof a.encodedBodySize === "number" ? a.encodedBodySize : 0,
                        decodedSize: a != null && typeof a.decodedBodySize === "number" ? a.decodedBodySize : 0,
                        transferSize: a != null && typeof a.transferSize === "number" ? a.transferSize : 0
                    }, g);
                    d = function(a, c) {
                        c = c + j;
                        i.buffer.addEvent({
                            type: "RESOURCE_TIMING_POINT",
                            resourceType: f,
                            resourceId: e,
                            pointName: a
                        }, b("clamp")(c, g, h))
                    };
                    d("requestStart", c.requestStart);
                    d("responseStart", c.responseStart);
                    i.buffer.addEvent({
                        type: "RESOURCE_TIMING_END",
                        resourceType: f,
                        resourceId: e
                    }, h)
                }
            };
            c.$5 = function(a) {
                if (this.$3.sanitizeURIs) return u(a, this.$2);
                var b = a.indexOf("?");
                return b == -1 ? a : a.substring(0, b)
            };
            c.loomTraceWillEnd = function() {
                var a = this,
                    c = this.$1;
                if (c != null) {
                    var d = c.startTime,
                        e = (g || (g = b("performanceAbsoluteNow")))(),
                        f = window.performance.timing.navigationStart;
                    window.performance.getEntriesByType("resource").filter(function(a) {
                        return a.startTime < a.responseEnd && a.startTime + f >= d && a.responseEnd + f <= e
                    }).forEach(function(g, c) {
                        var d = g.startTime + f,
                            e = g.responseEnd + f,
                            h = a.$5(g.name),
                            b = C(g.initiatorType, h);
                        a.$4({
                            entry: g,
                            resourceName: h,
                            resourceId: c,
                            resourceType: b,
                            startTime: d,
                            endTime: e
                        })
                    });
                    c = window.performance.getEntriesByType("navigation")[0];
                    c = typeof PerformanceNavigationTiming !== "undefined" && c instanceof PerformanceNavigationTiming ? c : null;
                    if (c != null && (c.responseEnd === 0 || c.responseEnd + f >= d)) {
                        var h = "document",
                            i = -1,
                            j = d > f ? d : f,
                            k = c.responseEnd === 0 ? e : c.responseEnd + f;
                        this.$4({
                            entry: c,
                            resourceName: this.$5(location.href),
                            resourceId: i,
                            resourceType: h,
                            startTime: j,
                            endTime: k
                        })
                    }
                }
                this.$1 = null
            };
            return a
        }(),
        E = {
            loomProviderId: "ResourceTiming",
            isSupported: function() {
                return D.isSupported()
            },
            getInstance: function(a, b, c) {
                return new D(a, b, c)
            }
        },
        F = b("vc-tracker").VisualCompletionTraceObserver,
        G = function() {
            a.isSupported = function() {
                return !0
            };

            function a(a) {
                var b = this;
                this.$2 = function(a) {
                    var c = b.$1;
                    if (c != null && a != null && a.startTime >= c.startTime) {
                        var d = new Map();
                        a.elements.forEach(function(a) {
                            var b;
                            d.set(a.timestamp, ((b = d.get(a.timestamp)) !== null && b !== void 0 ? b : 0) + a.pixels)
                        });
                        Array.from(d.entries()).sort(function(a, b) {
                            return a[0] - b[0]
                        }).reduce(function(b, d) {
                            var e = d[0];
                            d = d[1];
                            b = b + d;
                            c.buffer.addEvent({
                                progress: b / a.paintedPixels,
                                type: "VISUAL_COMPLETION_PROGRESS"
                            }, e);
                            return b
                        }, 0);
                        b.$3(c, a, a.elements.filter(function(a) {
                            return a.parent == null
                        }), 0)
                    }
                };
                this.$1 = a;
                F.subscribe(this.$2)
            }
            var b = a.prototype;
            b.$3 = function(a, b, c, d, e) {
                var f = this;
                e === void 0 && (e = null);
                c.slice().sort(function(a, b) {
                    return a.timestamp - b.timestamp
                }).forEach(function(c) {
                    var g = c.rectangle,
                        h = c.type === "component" || e == null ? c.timestamp : Math.max(c.timestamp, e.timestamp);
                    a.buffer.addEvent({
                        depth: d,
                        elementType: c.type,
                        height: Math.floor(g.bottom - g.top),
                        mutationType: c.mutationType,
                        lateMutationType: c.hadLateMutationUnexpected ? "unexpected" : c.hadLateMutationExpected ? "expected" : void 0,
                        type: "VISUAL_COMPLETION_RECT",
                        width: Math.floor(g.right - g.left),
                        x: Math.floor(g.left),
                        y: Math.floor(g.top)
                    }, h);
                    c.children.length && f.$3(a, b, c.children, d + 1, c)
                })
            };
            b.loomTraceWillEnd = function() {
                F.unsubscribe(this.$2), this.$1 = null
            };
            return a
        }(),
        H = {
            getInstance: function(a) {
                return new G(a)
            },
            isSupported: function() {
                return G.isSupported()
            },
            loomProviderId: "VisualCompletion"
        },
        I = function() {
            function a() {
                this.$1 = []
            }
            var c = a.prototype;
            c.addEvent = function(a, c) {
                this.$1.push({
                    event: a,
                    timestamp: c !== null && c !== void 0 ? c : (g || (g = b("performanceAbsoluteNow")))()
                })
            };
            c.flushEvents = function() {
                return this.$1
            };
            return a
        }();

    function J(a, b, c, d) {
        b = b === "QPL" ? a.samplingConfig.adaptive_config.qpl : a.samplingConfig.adaptive_config.interactions;
        a = d != null ? c + "." + d : "" + c;
        d = b.events[a];
        if (d != null) return d;
        d = (a = b.modules[c >> 16 & 65535]) !== null && a !== void 0 ? a : 0;
        return d
    }

    function K() {
        return !window.Uint8Array || !window.btoa ? !1 : !0
    }

    function L(a, b, c, d) {
        c = c.flushEvents();
        if (!K()) return null;
        var e = b.start_time_us,
            f = b.end_time_us,
            g = e / 1e3,
            h = f / 1e3;
        if (d != null) {
            var i = g - d.stats.timeOrigin,
                j = h - d.stats.timeOrigin;
            d.trace.samples = d.trace.samples.filter(function(a) {
                return a.timestamp >= i && a.timestamp <= j
            })
        }
        var k = JSON.stringify(b) + "\n{}\n" + JSON.stringify(d || null) + "\n",
            l = 0;
        c.forEach(function(a) {
            var b = Math.round(a.timestamp * 1e3);
            if (b < e || b > f) return;
            var c = b - l;
            l = b;
            b = a.event;
            a = [c, b.type];
            switch (b.type) {
                case "QPL_ANNOTATION":
                    a.push(b.markerId);
                    a.push(b.instanceKey);
                    a.push(b.annotationKey);
                    a.push(b.annotationValue);
                    break;
                case "QPL_START":
                    a.push(b.markerId);
                    a.push(b.instanceKey);
                    break;
                case "QPL_END":
                    a.push(b.markerId);
                    a.push(b.instanceKey);
                    a.push(b.action);
                    break;
                case "QPL_POINT":
                    a.push(b.markerId);
                    a.push(b.instanceKey);
                    a.push(b.name);
                    b.data != null && a.push(b.data);
                    break;
                case "RESOURCE_TIMING_START":
                    a.push(b.resourceType);
                    a.push(b.resourceId);
                    a.push(b.resourceName);
                    a.push(b.encodedSize);
                    a.push(b.decodedSize);
                    a.push(b.transferSize);
                    break;
                case "RESOURCE_TIMING_END":
                    a.push(b.resourceType);
                    a.push(b.resourceId);
                    break;
                case "RESOURCE_TIMING_POINT":
                    a.push(b.resourceType);
                    a.push(b.resourceId);
                    a.push(b.pointName);
                    break;
                case "INTERACTION_TRACE_START":
                    a.push(b.traceId);
                    a.push(b.execUnitName);
                    a.push(b.blockName);
                    a.push(b.blockType);
                    a.push(b.traceType);
                    break;
                case "INTERACTION_TRACE_END":
                    a.push(b.traceId);
                    a.push(b.execUnitName);
                    a.push(b.blockName);
                    a.push(b.blockType);
                    a.push(b.traceType);
                    a.push(b.blockAnnotations);
                    break;
                case "INTERACTION_TRACE_POINT":
                    a.push(b.traceId);
                    a.push(b.execUnitName);
                    a.push(b.blockName);
                    a.push(b.pointName);
                    a.push(b.pointAnnotations);
                    break;
                case "VISUAL_COMPLETION_RECT":
                    a.push(b.elementType);
                    a.push(b.depth);
                    a.push(b.x);
                    a.push(b.y);
                    a.push(b.width);
                    a.push(b.height);
                    a.push(b.mutationType);
                    a.push(b.lateMutationType);
                    break;
                case "VISUAL_COMPLETION_PROGRESS":
                    a.push(b.progress);
                    break;
                case "JS_SCHEDULER_QUEUE":
                    a.push(b.priority);
                    a.push(b.queueSize);
                    break
            }
            k += JSON.stringify(a) + "\n"
        });
        return a.compressStringToSnappy(k)
    }
    var M = b("performanceNavigationStart")(),
        N = new Set(["InteractionTracing"]);
    a = function() {
        function a(a, c) {
            this.$1 = a, this.$2 = c, this.$3 = [z, H, E, B], this.$4 = new Set(this.$3.map(function(a) {
                return a.loomProviderId
            })), this.$5 = new Set(this.$3.map(function(a) {
                return a.loomProviderId
            })), this.$6 = new Map(), this.$7 = new Map(), this.$8 = K(), this.$9 = !1, this.$10 = 1, this.$11 = new Map(), this.$12 = b("uuid")(), this.$13 = 1
        }
        var c = a.prototype;
        c.getNextSequenceNumber = function() {
            var a = this.$13;
            this.$13++;
            return a
        };
        c.getSessionId = function() {
            return this.$12
        };
        c.getActiveTraces = function() {
            return this.$6
        };
        c.addProvider = function(a, b) {
            b === void 0 && (b = !0), this.$5.has(a.loomProviderId) || (this.$3.push(a), this.$5.add(a.loomProviderId)), b && !this.$4.has(a.loomProviderId) && this.$4.add(a.loomProviderId)
        };
        c.addStatusListener = function(a) {
            var b = this,
                c = this.$10++;
            this.$11.set(c, a);
            return {
                dispose: function() {
                    b.$11["delete"](c)
                }
            }
        };
        c.maybeStartTraceForInteraction = function(a, c, d, e, f) {
            d = b("QPLEvent").getMarkerId(d);
            var g = J(this.$1, "INTERACTION", d, e);
            if (!this.$2.Random.coinflip(g)) return null;
            f = f + M;
            c = {
                interaction_class: c,
                interaction_id: a,
                qpl_marker_id: "" + d,
                sample_rate: g,
                trace_policy: e,
                type: "INTERACTION"
            };
            return this.startTrace(a, c, f, this.$1.useLiteTracing ? N : void 0)
        };
        c.endTraceForInteraction = function(a, c, d) {
            var e = a.traceId,
                f = babelHelpers["extends"]({}, null);
            for (var g in a.annotations)
                for (var j in a.annotations[g]) f[j] = a.annotations[g][j];
            f.qpl_action = c;
            j = (h || (h = b("mapObject")))(a.tagSet, function(a) {
                return Array.from(a)
            });
            g = a.completed;
            c = (c = a.markerPoints.visuallyComplete) === null || c === void 0 ? void 0 : c.timestamp;
            a = (a = a.markerPoints.logVC) === null || a === void 0 ? void 0 : a.timestamp;
            g = Math.max(g !== null && g !== void 0 ? g : 0, c !== null && c !== void 0 ? c : 0, a !== null && a !== void 0 ? a : 0, d !== null && d !== void 0 ? d : 0);
            c = g > 0 ? g : (i || (i = b("performanceNow")))();
            a = M + c;
            return this.endTrace(e, a, f, j)
        };
        c.startTrace = function(a, c, d, e) {
            var f = this;
            e === void 0 && (e = this.$4);
            if (!this.$8) return null;
            if (this.$6.has(a)) {
                b("recoverableViolation")("Already running trace for triggerId: " + a, "web_loom");
                return null
            }
            var g = this.$13++,
                h = {
                    buffer: new I(),
                    triggerId: a,
                    triggerInfo: c,
                    startTime: d,
                    sequenceNumber: g
                },
                i = new Set(),
                j = [];
            this.$3.forEach(function(a) {
                e.has(a.loomProviderId) && a.isSupported() && (j.push(a.getInstance(h, f.$2, f.$1)), i.add(a.loomProviderId))
            });
            var k = "STARTED";
            this.$6.set(a, {
                traceContext: h,
                providerInstances: j,
                status: k,
                startURI: window.location.href
            });
            this.$11.forEach(function(a) {
                return a(h, k)
            });
            var l = this.$12 + "_" + g;
            b("one-trace") && (this.$14 = b("one-trace").subscribe("trace-start", function(a) {
                (a.traceType === "LONGTASK" || a.traceType === "INPUT_DELAY") && (a.annotations.string.loomRefId = l, a.annotations.string_array.loomProviders = Array.from(i))
            }));
            return {
                traceReferenceId: l,
                loomProviders: i
            }
        };
        c.endTrace = function(a, c, d, e) {
            var f = this,
                g, h, i, j, k, l, m, n, o;
            return b("regeneratorRuntime").async(function(p) {
                while (1) switch (p.prev = p.next) {
                    case 0:
                        g = this.$6.get(a);
                        if (g) {
                            p.next = 4;
                            break
                        }
                        b("recoverableViolation")("No trace running for triggerId: " + a, "web_loom");
                        return p.abrupt("return", !1);
                    case 4:
                        h = g.traceContext.sequenceNumber;
                        this.$6["delete"](a);
                        this.$7.set(h, g);
                        this.$15(g, "END_PENDING");
                        i = [];
                        g.providerInstances.forEach(function(a) {
                            a = a.loomTraceWillEnd();
                            a && i.push(a)
                        });
                        this.$14 && this.$14();
                        j = window.location.href;
                        p.prev = 12;
                        p.next = 15;
                        return b("regeneratorRuntime").awrap(b("Promise").all(i));
                    case 15:
                        k = this.$1.perfXData;
                        l = g.traceContext.triggerInfo;
                        m = {
                            app_id: this.$1.appId,
                            start_time_us: Math.round(g.traceContext.startTime * 1e3),
                            end_time_us: Math.round(c * 1e3),
                            trigger_id: g.traceContext.triggerId,
                            trigger_info: l,
                            trigger_metadata: d,
                            trigger_metadata_sets: e,
                            client_push_phase: k.client_push_phase,
                            device_num_cores: k.num_cores,
                            device_ram_bytes: k.ram_gb != null ? k.ram_gb * 1073741824 : null,
                            is_rtl: k.isRTL,
                            locale: k.locale,
                            network_effective_connection_type: k.effective_connection_type,
                            network_downlink_bps: k.downlink_megabits != null && k.downlink_megabits * 1e6 < 1e20 ? k.downlink_megabits * 1e6 : null,
                            network_rtt_ms: k.rtt_ms,
                            client_rev: this.$1.clientRev,
                            server_rev: this.$1.serverRev,
                            spin_mode: this.$1.spinMode,
                            start_uri: g.startURI,
                            end_uri: j
                        };
                        n = L(this.$2, m, g.traceContext.buffer, g.traceContext.jsSelfProfilerData);
                        n != null ? (o = {
                            trace: n,
                            session_id: this.$12,
                            sequence_number: g.traceContext.sequenceNumber,
                            qpl_marker_id: l.qpl_marker_id,
                            trace_policy: l.trace_policy,
                            sample_rate: l.sample_rate
                        }, this.$2.Transport.post(o, {
                            onComplete: function() {
                                f.$15(g, "COMPLETE"), f.$7["delete"](h)
                            },
                            isHighPri: this.$9
                        }), this.$15(g, "UPLOAD_PENDING")) : (this.$15(g, "COMPLETE"), this.$7["delete"](h));
                        p.next = 26;
                        break;
                    case 22:
                        p.prev = 22, p.t0 = p["catch"](12), this.$15(g, "ERROR"), this.$7["delete"](h);
                    case 26:
                        return p.abrupt("return", !0);
                    case 27:
                    case "end":
                        return p.stop()
                }
            }, null, this, [
                [12, 22]
            ])
        };
        c.flush = function(a) {
            var b = this,
                c = new Set(),
                d = new Set();
            this.$7.forEach(function(a) {
                a.status === "END_PENDING" ? c.add(a.traceContext.sequenceNumber) : a.status === "UPLOAD_PENDING" && d.add(a.traceContext.sequenceNumber)
            });
            if (c.size > 0) var e = this.addStatusListener(function(d) {
                c["delete"](d.sequenceNumber), c.size === 0 && (b.$2.Transport.flush(a, a), e.dispose())
            });
            else d.size > 0 ? this.$2.Transport.flush(a, a) : a && a()
        };
        c.setIsDevToolsConnected = function(a) {
            this.$9 = a
        };
        c.$15 = function(a, b) {
            a.status = b, this.$11.forEach(function(b) {
                return b(a.traceContext, a.status)
            })
        };
        return a
    }();
    f.WebLoomCore = a
}), null);
__d("WebLoom", ["CurrentUser", "JSSelfProfiler", "PerfXSharedFields", "QuickPerformanceLogger", "Random", "SiteData", "SnappyCompressUtil", "URI", "UserAgent", "WebLoomBanzaiTransport", "WebLoomConfig", "cr:1094133", "cr:955714", "gkx", "web-loom"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        QuickPerformanceLogger: c("QuickPerformanceLogger"),
        Random: c("Random"),
        Transport: c("WebLoomBanzaiTransport"),
        URI: c("URI"),
        isBrowser: c("UserAgent").isBrowser,
        compressStringToSnappy: c("SnappyCompressUtil").compressStringToSnappy
    };
    e = {
        appId: c("CurrentUser").getAppID(),
        sanitizeURIs: c("gkx")("1787898"),
        samplingConfig: c("WebLoomConfig"),
        clientRev: c("SiteData").client_revision,
        serverRev: c("SiteData").server_revision,
        spinMode: c("SiteData").spin,
        useLiteTracing: c("gkx")("4240"),
        perfXData: d("PerfXSharedFields").getCommonData()
    };
    f = new(d("web-loom").WebLoomCore)(e, a);
    b("cr:1094133") && f.addProvider(b("cr:1094133"));
    c("JSSelfProfiler").isHeaderSent && b("cr:955714") && f.addProvider(b("cr:955714"));
    d = f;
    g["default"] = d
}), 98);
__d("getReactComponentStackFromDOMElement_THIS_CAN_BREAK", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        var b = Object.keys(a).find(function(a) {
            return a.startsWith("__reactFiber$")
        });
        return b == null ? null : a[b]
    }

    function h(a) {
        var b;
        b = (b = a.displayName) != null ? b : a.name;
        if (b == null) return null;
        a = b.match(/.*\[from (.*)\.react\]/);
        return a && a[1] || b
    }

    function a(a) {
        try {
            var b = [];
            a = g(a);
            while (a) {
                var c = a.type;
                if (c == null || typeof c === "string") {
                    a = a["return"];
                    continue
                }
                var d = h(c);
                d == null && c.render != null && (d = h(c.render));
                d != null && d !== "" && b.push(d);
                a = a["return"]
            }
            return b
        } catch (a) {
            return null
        }
    }
    f["default"] = a
}), 66);
__d("FBInteractionTracingDependencies", ["HeroBootloadPerfStore", "QuickPerformanceLogger", "WebLoom", "cr:1791018", "cr:1791501", "cr:1808490", "cr:683059", "getReactComponentStackFromDOMElement_THIS_CAN_BREAK"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getReactComponentStackFromDOMElement: c("getReactComponentStackFromDOMElement_THIS_CAN_BREAK"),
        HeroBootloadPerfStore: {
            addStaticResourcesStats: d("HeroBootloadPerfStore").addStaticResourcesStats
        },
        InteractionVC: b("cr:1791018"),
        QuickPerformanceLogger: c("QuickPerformanceLogger"),
        UserTimingUtils: b("cr:1808490"),
        VCTracker: b("cr:1791501"),
        VisualCompletion: b("cr:683059"),
        WebLoom: c("WebLoom")
    };
    g["default"] = a
}), 98);
__d("CometSSRViewportHints", [], (function(a, b, c, d, e, f) {
    "use strict";
    e = {
        max: function(a, b) {
            return a <= b
        },
        min: function(a, b) {
            return a >= b
        }
    };
    var g = null,
        h = null,
        i = [];

    function a(a) {
        return a === "width" ? g : h
    }

    function b(a) {
        g = a.width_px, h = a.height_px
    }

    function c(a, b, c, d) {
        var e = i.findIndex(function(b) {
            return b.dimension === a && b.operation === c && b.result === d
        });
        if (e === -1) i.push({
            dimension: a,
            numPixels: b,
            operation: c,
            result: d
        });
        else {
            var f = c === "min" && d === !0 || c === "max" && d === !1,
                g = i[e].numPixels;
            i[e].numPixels = f ? Math.max(g, b) : Math.min(g, b)
        }
    }

    function d() {
        i.length = 0
    }
    f.check = e;
    f.useMatchViewportResults = i;
    f.getDimension = a;
    f.setDimensions = b;
    f.addUseMatchViewportResult = c;
    f.clearUseMatchViewportResults = d
}), 66);
__d("TimeSliceSham", ["Env", "ErrorGuard", "IntervalTrackingBoundedBuffer"], (function(a, b, c, d, e, f) {
    var g, h;
    c = (g || (g = b("Env"))).timesliceBufferSize;
    c == null && (c = 5e3);
    var i = new(b("IntervalTrackingBoundedBuffer"))(c),
        j = {
            PropagationType: {
                CONTINUATION: 0,
                EXECUTION: 1,
                ORPHAN: 2
            },
            guard: function(a, c, d) {
                var e, f;
                e = (e = (g || (g = b("Env"))).deferred_stack_trace_rate) != null ? e : 0;
                (d == null ? void 0 : d.registerCallStack) && e > 0 && Math.random() < 1 / e && (f = new Error("deferred execution source"));
                return (h || (h = b("ErrorGuard"))).guard(a, {
                    deferredSource: f,
                    name: "TimeSlice" + (c ? ": " + c : "")
                })
            },
            copyGuardForWrapper: function(a, b) {
                return a
            },
            checkCoverage: function() {},
            setLogging: function(a, b) {},
            getContext: function() {
                return null
            },
            getGuardedContinuation: function(a) {
                function a(a) {
                    for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
                    return a.apply(this, c)
                }
                return a
            },
            getReusableContinuation: function(a) {
                return j.getPlaceholderReusableContinuation()
            },
            getPlaceholderReusableContinuation: function() {
                var a = function(a) {
                    return a()
                };
                a.last = a;
                return a
            },
            getGuardNameStack: function() {
                return []
            },
            registerExecutionContextObserver: function(a) {},
            catchUpOnDemandExecutionContextObservers: function(a) {},
            getBuffer: function() {
                return i
            }
        };
    a.TimeSlice = j;
    e.exports = j
}), 6);
__d("ReactFlightDOMRelayClientIntegration", ["RelayFBModuleLoader"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return d("RelayFBModuleLoader").getModuleReference(a)
    }

    function b(a) {
        a.preload()
    }

    function c(a) {
        return d("RelayFBModuleLoader").read(a)
    }
    g.resolveModuleReference = a;
    g.preloadModule = b;
    g.requireModule = c
}), 98);
__d("ReactFlightDOMRelayClient-prod.modern", ["ReactFlightDOMRelayClientIntegration"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
        return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }
    var h = Array.isArray;

    function i(a, b, c, d) {
        if ("string" === typeof d) return B(a, b, c, d);
        if ("object" === typeof d && null !== d) {
            if (h(d)) {
                c = [];
                for (b = 0; b < d.length; b++) c[b] = i(a, d, "" + b, d[b]);
                a = c[0] === k ? {
                    $$typeof: k,
                    type: c[1],
                    key: c[2],
                    ref: null,
                    props: c[3],
                    _owner: null
                } : c;
                return a
            }
            b = {};
            for (c in d) b[c] = i(a, d, c, d[c]);
            return b
        }
        return d
    }
    var j = {},
        k = Symbol["for"]("react.element"),
        l = Symbol["for"]("react.lazy");

    function m(a, b, c, d) {
        this.status = a, this.value = b, this.reason = c, this._response = d
    }
    m.prototype = Object.create(Promise.prototype);
    m.prototype.then = function(a, b) {
        switch (this.status) {
            case "resolved_model":
                v(this);
                break;
            case "resolved_module":
                w(this)
        }
        switch (this.status) {
            case "fulfilled":
                a(this.value);
                break;
            case "pending":
            case "blocked":
                a && (null === this.value && (this.value = []), this.value.push(a));
                b && (null === this.reason && (this.reason = []), this.reason.push(b));
                break;
            default:
                b(this.reason)
        }
    };

    function n(a) {
        switch (a.status) {
            case "resolved_model":
                v(a);
                break;
            case "resolved_module":
                w(a)
        }
        switch (a.status) {
            case "fulfilled":
                return a.value;
            case "pending":
            case "blocked":
                throw a;
            default:
                throw a.reason
        }
    }

    function o(a, b) {
        return new m("fulfilled", b, null, a)
    }

    function p(a, b) {
        for (var c = 0; c < a.length; c++) a[c](b)
    }

    function q(a, b, c) {
        switch (a.status) {
            case "fulfilled":
                p(b, a.value);
                break;
            case "pending":
            case "blocked":
                a.value = b;
                a.reason = c;
                break;
            case "rejected":
                c && p(c, a.reason)
        }
    }

    function r(a, b) {
        if ("pending" === a.status || "blocked" === a.status) {
            var c = a.reason;
            a.status = "rejected";
            a.reason = b;
            null !== c && p(c, b)
        }
    }

    function s(a, b) {
        if ("pending" === a.status || "blocked" === a.status) {
            var c = a.value,
                d = a.reason;
            a.status = "resolved_module";
            a.value = b;
            null !== c && (w(a), q(a, c, d))
        }
    }
    var t = null,
        u = null;

    function v(a) {
        var b = t,
            c = u;
        t = a;
        u = null;
        try {
            var d = i(a._response, j, "", a.value);
            null !== u && 0 < u.deps ? (u.value = d, a.status = "blocked", a.value = null, a.reason = null) : (a.status = "fulfilled", a.value = d)
        } catch (b) {
            a.status = "rejected", a.reason = b
        } finally {
            t = b, u = c
        }
    }

    function w(a) {
        try {
            var c = b("ReactFlightDOMRelayClientIntegration").requireModule(a.value);
            a.status = "fulfilled";
            a.value = c
        } catch (b) {
            a.status = "rejected", a.reason = b
        }
    }

    function x(a, b) {
        a._chunks.forEach(function(a) {
            "pending" === a.status && r(a, b)
        })
    }

    function y(a, b) {
        var c = a._chunks,
            d = c.get(b);
        d || (d = new m("pending", null, null, a), c.set(b, d));
        return d
    }

    function z(a, b, c) {
        if (u) {
            var d = u;
            d.deps++
        } else d = u = {
            deps: 1,
            value: null
        };
        return function(e) {
            b[c] = e, d.deps--, 0 === d.deps && "blocked" === a.status && (e = a.value, a.status = "fulfilled", a.value = d.value, null !== e && p(e, d.value))
        }
    }

    function A(a) {
        return function(b) {
            return r(a, b)
        }
    }

    function B(a, b, c, d) {
        switch (d[0]) {
            case "$":
                if ("$" === d) return k;
                if ("$" === d[1] || "@" === d[1]) return d.substring(1);
                d = parseInt(d.substring(1), 16);
                a = y(a, d);
                switch (a.status) {
                    case "resolved_model":
                        v(a);
                        break;
                    case "resolved_module":
                        w(a)
                }
                switch (a.status) {
                    case "fulfilled":
                        return a.value;
                    case "pending":
                    case "blocked":
                        return d = t, a.then(z(d, b, c), A(d)), null;
                    default:
                        throw a.reason
                }
            case "@":
                return b = parseInt(d.substring(1), 16), b = y(a, b), {
                    $$typeof: l,
                    _payload: b,
                    _init: n
                }
        }
        return d
    }

    function C(a, c, d) {
        var e = a._chunks,
            f = e.get(c);
        d = i(a, j, "", d);
        var g = b("ReactFlightDOMRelayClientIntegration").resolveModuleReference(d);
        if (d = b("ReactFlightDOMRelayClientIntegration").preloadModule(g)) {
            if (f) {
                var h = f;
                h.status = "blocked"
            } else h = new m("blocked", null, null, a), e.set(c, h);
            d.then(function() {
                return s(h, g)
            }, function(a) {
                return r(h, a)
            })
        } else f ? s(f, g) : e.set(c, new m("resolved_module", g, null, a))
    }
    f.close = function(a) {
        x(a, Error(g(412)))
    };
    f.createResponse = function(a) {
        var b = new Map();
        return {
            _bundlerConfig: a,
            _chunks: b
        }
    };
    f.getRoot = function(a) {
        return y(a, 0)
    };
    f.resolveRow = function(a, b) {
        if ("J" === b[0]) {
            var c = b[1],
                d = b[2],
                e = a._chunks;
            (b = e.get(c)) ? "pending" === b.status && (a = b.value, c = b.reason, b.status = "resolved_model", b.value = d, null !== a && (v(b), q(b, a, c))): e.set(c, new m("resolved_model", d, null, a))
        } else "M" === b[0] ? C(a, b[1], b[2]) : "S" === b[0] ? a._chunks.set(b[1], o(a, Symbol["for"](b[2]))) : (d = b[1], c = b[2].digest, b = Error(g(441)), b.stack = "", b.digest = c, c = a._chunks, (e = c.get(d)) ? r(e, b) : c.set(d, new m("rejected", null, b, a)))
    }
}), null);
__d("CometRouterRouteMutableStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);