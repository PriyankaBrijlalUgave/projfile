if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("VideoPlayerFormatsMap", [], (function(a, b, c, d, e, f) {
    e.exports = {
        biz_mentions_and_tags: "inline",
        biz_stories_composer: "inline",
        topic_live: "inline",
        live_map: "inline",
        live_map_sidebar: "inline",
        live_map_listview: "inline",
        live_map_tooltip: "inline",
        live_map_tooltip_from_listview: "inline",
        live_map_tooltip_from_map: "inline",
        video_home_inline: "inline",
        inline: "inline",
        chained: "inline",
        page_live_video_module: "inline",
        chained_suggestion: "inline",
        embedded_video: "inline",
        embedded_video_preview: "inline",
        embedded_video_from_ufi: "inline",
        ufi_comment_attachment: "inline",
        media_collage: "inline",
        media_viewer: "inline",
        channel: "channel",
        watch: "watch",
        paid_content_package_permalink_cover: "permalink",
        permalink: "permalink",
        snowlift: "snowlift",
        tv: "tv",
        watch_scroll: "watch_scroll",
        continue_watching_recommendation: "inline",
        tahoe: "tahoe",
        tahoe_costreaming_thumbnail: "tahoe_costreaming_thumbnail",
        search_live_video_module: "inline",
        videohub_live: "inline",
        camera_post: "fb_stories",
        story_viewer_live_sticker: "fb_stories",
        story_tray_live_dropdown: "fb_stories",
        story_viewer_live_cta: "fb_stories",
        story_viewer_live_dropdown: "fb_stories",
        pages_cover: "inline",
        video_page_spotlight_unit: "inline",
        pages_cover_hover: "inline",
        pages_messaging_video: "inline",
        profile_overview: "inline",
        profile_cover: "inline",
        memory_leak_test: "inline",
        games_video_home_streamer_hub: "inline",
        games_video_live_recommendation: "inline",
        games_video_search_unit: "inline",
        games_video_streamer_unit: "inline",
        games_video_highlight_video_transition: "inline",
        trivia_game_admin_dashboard: "misc",
        games_streamer_dashboard: "inline",
        games_video_clips_home: "inline",
        games_video_clips_home_immersive_player: "inline",
        ads_preview: "inline",
        discover: "inline",
        business_feed: "inline",
        sotto_consideration_page: "inline",
        series_card: "inline",
        video_list: "inline",
        video_home_thumbnail_preview: "inline",
        work_captions_review: "inline",
        live_pyml: "inline",
        serp_thumbnail_preview: "inline",
        linear_channel: "inline",
        events_cover: "inline",
        fundraiser_cover: "inline",
        video_wall: "inline",
        live_clips_creator: "inline",
        live_evergreen_qp: "inline",
        messenger_cowatch: "inline",
        facebook_design: "inline",
        games_video_home_hero: "inline",
        games_feed: "inline",
        games_profile: "inline",
        messenger_kids_dot_com: "inline",
        live_qp: "inline",
        poe_qp: "inline",
        woodhenge_comet_signup: "inline",
        audio_home: "audio_home",
        inline_pause_screen: "inline",
        unified_editor: "inline",
        group_highlight_live_affiliate_player: "inline",
        candidate_portal: "inline",
        remote_learning_instructor_home: "inline",
        ad_library: "inline",
        bulletin_audio_player: "inline",
        instant_games: "instant_game_player",
        horizon_web_learn_more: "inline",
        creator_studio_inspiration_hub: "inline",
        subs_share_promotional_video_preview: "inline",
        ads: null,
        animated_image_share: null,
        asset: null,
        asset_manager: null,
        audio_home_orion_cta: null,
        aymt: null,
        ballot: null,
        billing_hub: null,
        biz_art: null,
        bloks_emulator: null,
        broadcast_request_attachment: null,
        candidate_videos: null,
        catalog_manager: null,
        channel_tab: null,
        channel_tab_live_card: null,
        channel_tab_videos_card: null,
        cms: null,
        commerce_manager: null,
        compass_curation: null,
        corporate_card_application: null,
        cowatch: null,
        creator_studio_mix_insights_trends: null,
        creator_studio_stars_cue_insertion_preview: null,
        cricket_matches_aggregation: null,
        crowdsourcing_video_preview: null,
        cs_video_composer_crossposting_review: null,
        curation: null,
        curation_qp: null,
        dim_sum: null,
        discovery_hubs_header: null,
        dolly_discovery_page: null,
        embedded: null,
        embedded_page_plugin: null,
        entry_point: null,
        entry_point_notifications: null,
        ep_takedown_request_manager: null,
        events_live_cta: null,
        events_live_video_section: null,
        external_deeplink: null,
        fb_reels_video_preview: null,
        fb_shorts_creation_feed_unit: null,
        fb_shorts_native_in_feed_unit: null,
        fb_shorts_profile_viewer: null,
        fb_shorts_reshare_feed_unit: null,
        fb_shorts_unified_tofu: null,
        fb_shorts_viewer: null,
        feed: null,
        feed_story: null,
        gameroom_live_video_hero_banner: null,
        gameroom_live_video_tab: null,
        gameroom_live_video_thumbnail: null,
        games_arena_hero: null,
        games_arena_videos_tab: null,
        games_audience_network_ads: null,
        games_featured_hero_banner: null,
        games_feed_story_header: null,
        games_feed_vod_unit: null,
        games_game_details: null,
        games_instant_game_quick_promotion: null,
        games_verse_destination: null,
        games_video_clips_home_my_clips: null,
        games_video_clips_home_top_clips: null,
        games_video_clips_library_preview_modal: null,
        games_video_community_feed: null,
        games_video_costreamers_list: null,
        games_video_explore_home: null,
        games_video_highlight_video_preview: null,
        games_video_highlighted_clips_streamer_page: null,
        games_video_home: null,
        games_video_home_left_rail: null,
        games_video_home_see_all: null,
        games_video_home_streamer_hub_hero: null,
        games_video_home_streamer_hub_schedule: null,
        games_video_hub: null,
        games_video_hub_redirect_notification: null,
        games_video_hub_redirect_unknown: null,
        games_video_mixer_us_qp_recommended_live: null,
        games_video_play_with_streamers_live: null,
        games_video_qp_recommended_live: null,
        games_video_qp_us_recommended_live: null,
        games_video_single_game: null,
        games_video_social_plugin: null,
        games_video_streamer_hub: null,
        games_video_thumbnail_preview: null,
        games_video_top_weekly_clips_streamer_page: null,
        games_video_view_highlights_cue: null,
        gaming_followed_game_aggregation: null,
        gaming_top_videos_aggregation: null,
        get_caught_up_qp: null,
        goodwill_product_system: null,
        group_live_video_module: null,
        group_videos_aggregation: null,
        groups_cover: null,
        groups_featured: null,
        groups_latest_videos: null,
        groups_watch_all: null,
        groups_watch_popular: null,
        guidance_hub: null,
        hashtag_destination: null,
        html5: null,
        igd_thread: null,
        inline_end_screen: null,
        inline_qp: null,
        insights: null,
        interests_bling_string: null,
        interests_cue_listpack: null,
        interests_fixed_entrypoint: null,
        interests_fixed_listpack: null,
        interests_follow_cue: null,
        interests_follow_edge_header: null,
        interests_manager: null,
        interests_multiple_subtopic_cue: null,
        interests_spring_board: null,
        interests_subtopic_aggregation: null,
        interests_suggested_follow: null,
        interests_warion_belt: null,
        intern_api_unlabelled_datasets: null,
        intern_crm_call_recording: null,
        intern_curation: null,
        intern_example: null,
        intern_new_hire_orientation: null,
        issues_module: null,
        jobs_visual_intro: null,
        lancelet: null,
        lightweight_status: null,
        lightweight_status_consumption: null,
        lightweight_status_self_view: null,
        live_autoplay_watch_and_scroll: null,
        live_beeper: null,
        live_control_panel: null,
        live_destination_scheduled_lives_qp: null,
        live_destination_thematic_upsell_qp: null,
        live_destination_upsell_qp: null,
        live_gaming_rhc: null,
        live_hero: null,
        live_linear: null,
        live_map_tooltip_from_webgl: null,
        live_msite: null,
        live_music_destination: null,
        live_page_upcoming_next_unit: null,
        live_producer: null,
        live_rhc: null,
        live_shopping: null,
        live_shopping_buyer_qp: null,
        live_video_broadcast: null,
        live_video_preview: null,
        living_room: null,
        living_room_commentating: null,
        living_room_recap_fullscreen: null,
        living_room_recap_inline: null,
        lookback: null,
        marketplace_promotional_video: null,
        media_match_service: null,
        media_sync: null,
        messaging: null,
        messenger_kids_challenges_internal_tool: null,
        messenger_thread: null,
        meta_family_center: null,
        misc: null,
        mobile: null,
        morc_console: null,
        movies_recommended_movies_qp: null,
        music_home: null,
        music_home_deeplink: null,
        music_home_entry_aggregation: null,
        music_home_internal_bookmark: null,
        music_home_newsfeed_attachment: null,
        music_home_newsfeed_attachment_trending: null,
        music_home_notification: null,
        music_home_qp: null,
        music_home_qp_overlay_header: null,
        music_home_rich_tile: null,
        music_home_search_shortcut: null,
        music_home_serp: null,
        music_home_springboard_unit: null,
        music_home_stations_qp: null,
        music_home_tappable_edge_header: null,
        music_home_third_party_pivot: null,
        music_home_ugc_cta: null,
        music_home_unknown: null,
        music_home_watch_cue: null,
        music_home_watch_cue_artist: null,
        music_home_watch_cue_trending: null,
        music_home_watch_pill: null,
        music_home_watch_pill_fix: null,
        music_home_watch_search: null,
        music_home_watch_spotlight_unit: null,
        music_home_watch_stations_unit: null,
        music_home_watch_surface_promotion_pill: null,
        music_videos_featuring_artist_card: null,
        music_videos_playlists_card: null,
        music_weekly_chart: null,
        newsfeed_qp: null,
        not_specified_please_fix: null,
        notifications: null,
        npr_qp: null,
        oculus: null,
        oculus_games: null,
        oculus_hub: null,
        oculus_recommended_video_unit: null,
        offers_detail: null,
        page_admin_things_you_should_do_tip: null,
        page_autoload_watch_and_scroll: null,
        page_live_tab: null,
        page_roles: null,
        page_timeline_live_card: null,
        page_timeline_live_now_dialog: null,
        pages_finch_main_video: null,
        pages_finch_thumbnail_video: null,
        pages_finch_trailer: null,
        pages_home_hero: null,
        pages_home_pmv_unit: null,
        pages_timeline_inline: null,
        pages_timeline_pages_cover: null,
        pages_video_set: null,
        people_portal: null,
        playlist_page: null,
        playlists_card: null,
        playlists_tab: null,
        pmv_back_catalog_qp: null,
        pmv_new_release_digest: null,
        pmv_new_release_digest_channel_view: null,
        pmv_new_release_qp: null,
        pmv_third_party_triggered_cta: null,
        pmv_top_chart_cta: null,
        pmv_ugc_cta: null,
        pmv_youtube_story_level_cta: null,
        profile_featured_section: null,
        profile_plus_live_card: null,
        profile_plus_live_videos_tab: null,
        profile_plus_pinned_popular_video_card: null,
        profile_plus_popular_video_card: null,
        profile_plus_product_tour: null,
        profile_plus_video_tab: null,
        profile_plus_videos_card: null,
        profile_switcher_illustration: null,
        profile_video: null,
        profile_video_hovercard: null,
        profile_video_thumb: null,
        proton: null,
        push: null,
        quick_promotion: null,
        redirected_watch_serp: null,
        report_flow: null,
        results: null,
        review: null,
        rl_hub: null,
        robotics_rtc_page: null,
        robotics_tour_guide_page: null,
        rooms_tray: null,
        saved_videos_qp: null,
        serp_inline_player: null,
        serp_videos_tab: null,
        short_videos_spotlight: null,
        shows_catalog: null,
        single_page_channel: null,
        slideshow: null,
        sotto_catalog: null,
        spotlight_featured: null,
        spotlight_live: null,
        spotlight_popular: null,
        spotlight_unknown: null,
        srt_review: null,
        stages_waiting_room_ondemand: null,
        stars_eligible_creator_onboarding_upsell_video: null,
        stars_ineligible_creator_onboarding_upsell_video: null,
        stories_video_preview: null,
        story_viewer_live_video_view: null,
        suggested_pages_to_follow_agg: null,
        text_based_video_editor_on_comet: null,
        timepass: null,
        topic_animals: null,
        topic_beauty: null,
        topic_channel_living_room: null,
        topic_cricket: null,
        topic_feed: null,
        topic_following: null,
        topic_following_continue_watching: null,
        topic_following_latest: null,
        topic_following_not_watched: null,
        topic_food: null,
        topic_gaming: null,
        topic_interest: null,
        topic_music: null,
        topic_news: null,
        topic_saved_videos: null,
        topic_shows: null,
        topic_sports: null,
        topics: null,
        tpfc: null,
        trailer_og_attachment: null,
        trailer_timeline_collections: null,
        trailer_timeline_unit: null,
        transparency_content_library: null,
        unified_tofu: null,
        user_video_tab: null,
        vep_session: null,
        vep_waiting_room: null,
        video_composer_crossposting_review: null,
        video_copyright_preview: null,
        video_copyright_segment_preview: null,
        video_home_catalog: null,
        video_home_channel: null,
        video_home_cricket: null,
        explore: null,
        notif_hub: null,
        video_home_pineapple_home: null,
        video_home_rainbow_qp: null,
        video_home_top_searched_tv_movies_keywords: null,
        video_home_tv_movies: null,
        video_home_video_not_found: null,
        watchlist: null,
        video_inline_chaining: null,
        video_insights_metadata_summary: null,
        video_insights_multiviewer: null,
        video_insights_opsview: null,
        video_list_aggregation: null,
        video_page_unspecified: null,
        video_page_video_list: null,
        videohub_featured: null,
        videohub_playlist: null,
        videos_card: null,
        videos_tab: null,
        voices_podcast: null,
        watch_casting_qp: null,
        watch_continue_watching: null,
        watch_continue_watching_qp: null,
        watch_creator_qp: null,
        watch_explore_surface_gcu: null,
        watch_explore_surface_interest: null,
        watch_explore_surface_new_releases_pmv: null,
        watch_explore_surface_pages: null,
        watch_explore_surface_popular_pmv: null,
        watch_explore_surface_pyml: null,
        watch_explore_surface_trending: null,
        watch_explore_surface_tv_movie: null,
        watch_explore_trending_reels_creators: null,
        watch_explore_trending_unit: null,
        watch_history: null,
        watch_liked_videos: null,
        watch_nullstate_discovery_gcu: null,
        watch_nullstate_discovery_interest: null,
        watch_nullstate_discovery_pyml: null,
        watch_originals_qp: null,
        watch_premium_content_qp: null,
        watch_racial_injustice_qp: null,
        watch_rainbow_qp: null,
        watch_search_discover: null,
        watch_subtopic_channel: null,
        watch_topic_pills_to_channel: null,
        watch_video_highlights_qp: null,
        watchlist_aggregation: null,
        work_chapters_editor: null,
        work_top_of_feed_unit: null,
        work_video_qp: null,
        work_watch_collections: null,
        work_watch_collections_official: null,
        work_watch_groups: null,
        work_watch_groups_all: null,
        work_watch_groups_outer: null,
        work_watch_groups_popular: null,
        work_watch_home: null,
        work_watch_home_carousel: null,
        work_watch_home_continue_watching: null,
        work_watch_home_explore_other_groups: null,
        work_watch_home_hear_about_leaders: null,
        work_watch_home_popular: null,
        work_watch_home_recent_from_groups: null,
        work_watch_home_recent_other_groups: null,
        work_watch_home_recently_live: null,
        work_watch_home_recently_watched: null,
        work_watch_home_saved_videos: null,
        work_watch_live: null,
        work_watch_live_all: null,
        work_watch_live_popular: null,
        workplace_insights: null
    }
}), null);
__d("ViewportTrackingHelper", ["DOMDimensions", "ge", "getElementPosition", "getElementRect", "getViewportDimensions"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        if (a === b) return !0;
        while (a && a.parentElement) {
            if (a.parentElement === b) return !0;
            a = a.parentElement
        }
        return !1
    }

    function h(a, b) {
        return j(c("getViewportDimensions")(), a, b)
    }

    function b(a, b) {
        var d = c("ge")("pagelet_bluebar");
        return d == null ? h(a, b) : j(c("getViewportDimensions")(), a, b, d.clientHeight)
    }
    var i = function(a, b) {
        a = c("getElementRect")(a);
        b = c("getElementRect")(b);
        return b.top >= a.top && b.bottom <= a.bottom && b.left >= a.left && b.right <= a.right
    };

    function j(a, b, e, f) {
        f === void 0 && (f = 0);
        var g = c("getElementPosition")(b);
        b = d("DOMDimensions").getElementDimensions(b);
        if (!g.x && !g.y && !b.height && !b.width) return !1;
        f = Math.max(g.y, f);
        g = Math.min(g.y + b.height, a.height);
        a = Math.min(b.height, e);
        return g - f >= a
    }

    function e(a, b) {
        var c = k(a);
        a = d("DOMDimensions").getElementDimensions(a);
        a = Math.min(a.height, b);
        return c >= a ? c : 0
    }

    function k(a) {
        var b = c("getElementPosition")(a);
        a = d("DOMDimensions").getElementDimensions(a);
        if (!b.x && !b.y && !a.x && !a.y) return 0;
        var e = c("getViewportDimensions")().height,
            f = Math.max(b.y, 0);
        b = Math.min(b.y + a.height, e);
        return b - f
    }

    function f(a) {
        var b = !1,
            c = [];
        for (var d = 0; d < a.length; d++) {
            var e = a[d];
            if (h(e, 0, null)) c.push(e), b = !0;
            else if (b) break
        }
        return c
    }
    g.isDescendantOf = a;
    g.isVisible = h;
    g.isVisibleUnderBluebar = b;
    g.isFullyVisibleInContainer = i;
    g.isVisibleInDimension = j;
    g.getHeightIfVisible = e;
    g.getHeightInViewport = k;
    g.getElementsInViewIgnoreHeight = f
}), 98);
__d("oz-player/loggings/OzPerfLoggerProviderBase", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {}
        var b = a.prototype;
        b.cloneContext = function() {
            var a = this.createLoggerProvider();
            this.$11(a);
            return a
        };
        b.setType = function(a) {
            this.$1 = a;
            return this
        };
        b.setInitiator = function(a) {
            this.$2 = a;
            return this
        };
        b.setResource = function(a) {
            this.$4 = a;
            return this
        };
        b.setRepresentationID = function(a) {
            this.$3 = a;
            return this
        };
        b.setSegmentStartTime = function(a) {
            this.$5 = a;
            return this
        };
        b.setSegmentEndTime = function(a) {
            this.$6 = a;
            return this
        };
        b.setStreamSwitchReason = function(a) {
            this.$7 = a;
            return this
        };
        b.setIsP2pPlayback = function(a) {
            this.$8 = a;
            return this
        };
        b.setIsRingBufferSample = function(a) {
            this.$9 = a;
            return this
        };
        b.setPerSessionSampleRate = function(a) {
            this.$10 = a;
            return this
        };
        b.getType = function() {
            return this.$1
        };
        b.getInitiator = function() {
            return this.$2
        };
        b.getRepresentationID = function() {
            return this.$3
        };
        b.getStreamSwitchReason = function() {
            return this.$7
        };
        b.getResource = function() {
            return this.$4
        };
        b.getSegmentStartTime = function() {
            return this.$5
        };
        b.getSegmentEndTime = function() {
            return this.$6
        };
        b.getIsP2pPlayback = function() {
            return this.$8
        };
        b.getIsRingBufferSample = function() {
            return this.$9
        };
        b.getOperationLogger = function(a) {
            a = this.createOperationLogger(a);
            return this.setOperationContext(a)
        };
        b.setOperationContext = function(a) {
            this.$11(a);
            return a
        };
        b.createOperationLogger = function(a) {
            throw new Error("Not implemented: createOperationLogger")
        };
        b.createLoggerProvider = function() {
            throw new Error("Not implemented: createLoggerProvider")
        };
        b.$11 = function(a) {
            this.getType() && a.setType(this.getType()), this.getInitiator() && a.setInitiator(this.getInitiator()), this.getResource() && a.setResource(this.getResource()), this.getRepresentationID() && a.setRepresentationID(this.getRepresentationID()), this.getStreamSwitchReason() && a.setStreamSwitchReason(this.getStreamSwitchReason()), typeof this.getSegmentStartTime() === "number" && a.setSegmentStartTime(this.getSegmentStartTime()), typeof this.getSegmentEndTime() === "number" && a.setSegmentEndTime(this.getSegmentEndTime()), typeof this.getIsP2pPlayback() === "boolean" && a.setIsP2pPlayback(this.getIsP2pPlayback()), typeof this.getIsRingBufferSample() === "boolean" && a.setIsRingBufferSample(this.getIsRingBufferSample())
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("oz-player/manifests/OzByteRange", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a.startByte === b.startByte
    }

    function b(a, b) {
        return b.endByte === null ? !1 : a.startByte === b.endByte + 1
    }

    function c(a, b) {
        return a.startByte < b.startByte ? !1 : b.endByte == null || b.endByte >= a.startByte
    }

    function d(a, b) {
        a = a;
        b = b;
        if (b.startByte < a.startByte) {
            var c = a;
            a = b;
            b = c
        }
        if (a.endByte == null) return {
            startByte: a.startByte,
            endByte: null
        };
        if (b.startByte > a.endByte + 1) return null;
        c = b.endByte == null || b.endByte > a.endByte ? b.endByte : a.endByte;
        return {
            startByte: a.startByte,
            endByte: c
        }
    }

    function e(a, b) {
        if (b.endByte == null) return null;
        if (a.startByte > b.endByte) return {
            startByte: a.startByte,
            endByte: a.endByte
        };
        return a.endByte != null && a.endByte <= b.endByte ? null : {
            startByte: b.endByte + 1,
            endByte: a.endByte
        }
    }

    function g(a) {
        return a.endByte == null ? null : a.endByte - a.startByte + 1
    }
    f.startsAtSame = a;
    f.startsImmediateAfter = b;
    f.startsDuring = c;
    f.union = d;
    f.disjoinAfter = e;
    f.getLength = g
}), 66);
__d("oz-player/shims/www/OzStreamsWWW", ["cr:927622", "cr:927623"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c = Boolean(b("cr:927622"));
    d = Boolean(b("cr:927623"));
    e = b("cr:927622") ? b("cr:927622").ReadableStream : a.ReadableStream;
    f = b("cr:927623") ? b("cr:927623").WritableStream : a.WritableStream;
    g.OzReadableStream = e;
    g.OzReadableStreamIsPolyfilled = c;
    g.OzWritableStream = f;
    g.OzWritableStreamIsPolyfilled = d
}), 98);
__d("oz-player/shims/OzStreams", ["oz-player/shims/www/OzStreamsWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.OzReadableStream = d("oz-player/shims/www/OzStreamsWWW").OzReadableStream, g.OzReadableStreamIsPolyfilled = d("oz-player/shims/www/OzStreamsWWW").OzReadableStreamIsPolyfilled, g.OzWritableStream = d("oz-player/shims/www/OzStreamsWWW").OzWritableStream, g.OzWritableStreamIsPolyfilled = d("oz-player/shims/www/OzStreamsWWW").OzWritableStreamIsPolyfilled
}), 98);
__d("oz-player/networks/OzCreateErrorStream", ["oz-player/shims/OzStreams"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return new(d("oz-player/shims/OzStreams").OzReadableStream)({
            pull: function(b) {
                b.error(a)
            }
        })
    }
    g["default"] = a
}), 98);
__d("oz-player/networks/OzProducerInterruptedError", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f["default"] = a
}), 66);
__d("oz-player/shims/www/OzDeferredWWW", ["Deferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("Deferred")
}), 98);
__d("oz-player/shims/OzDeferred", ["oz-player/shims/www/OzDeferredWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/OzDeferredWWW")
}), 98);
__d("oz-player/shims/www/OzMaybeNativePromiseWWW", ["cr:3014"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:3014")
}), 98);
__d("oz-player/shims/OzMaybeNativePromise", ["oz-player/shims/www/OzMaybeNativePromiseWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/OzMaybeNativePromiseWWW")
}), 98);
__d("oz-player/networks/OzDeferredBuffer", ["oz-player/networks/OzProducerInterruptedError", "oz-player/shims/OzDeferred", "oz-player/shims/OzMaybeNativePromise"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            a === void 0 && (a = {});
            this.$2 = [];
            this.$3 = !1;
            this.$5 = 0;
            a = a;
            a = a.disableArrayShift;
            this.$1 = !!a
        }
        var b = a.prototype;
        b.produce = function(a) {
            this.$6(a)
        };
        b.signalProducerInterruption = function() {
            this.$6(new(c("oz-player/networks/OzProducerInterruptedError"))("producer interrupted"))
        };
        b.consume = function(a) {
            var b = this;
            if (this.$3) throw new Error("A buffer can only be consumed by one client at a time");
            this.$3 = !0;
            var d = c("oz-player/shims/OzMaybeNativePromise").resolve();
            this.isEmpty() && (this.$4 = new(c("oz-player/shims/OzDeferred"))(c("oz-player/shims/OzMaybeNativePromise")), d = this.$4.getPromise());
            return d.then(function() {
                if (b.$1) {
                    if (b.$2[b.$5] === void 0) throw new Error("buffer has no value at position " + b.$5)
                } else if (b.$2.length === 0) throw new Error("buffer length must not be 0");
                b.$4 = null;
                b.$3 = !1;
                var c = b.$1 ? b.$7(a) : b.$8(a);
                if (c instanceof Uint8Array) return c;
                throw c
            })
        };
        b.$6 = function(a) {
            this.$2.push(a), this.$4 && this.$4.resolve()
        };
        b.$7 = function(a) {
            var b = this.$2[this.$5];
            if (b === void 0) return new Uint8Array([]);
            b = b;
            if (!(b instanceof Uint8Array)) {
                this.$2[this.$5] = void 0;
                this.$5++;
                return b
            }
            if (a !== void 0 && b.length > a) {
                var c = b.slice(a);
                b = b.slice(0, a);
                this.$2[this.$5] = c
            } else this.$2[this.$5] = void 0, this.$5++;
            return b
        };
        b.$8 = function(a) {
            if (this.$2.length === 0) return new Uint8Array([]);
            var b = this.$2[0];
            if (!(b instanceof Uint8Array)) {
                this.$2.shift();
                return b
            }
            if (a !== void 0 && b.length > a) {
                var c = b.slice(a);
                b = b.slice(0, a);
                this.$2[0] = c
            } else this.$2.shift();
            return b
        };
        b.isEmpty = function() {
            return this.$1 ? this.$2[this.$5] === void 0 : this.$2.length === 0
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("oz-player/utils/ozPipeErrorTo", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        try {
            a == null ? void 0 : a.error(b)
        } catch (a) {}
    }
    f["default"] = a
}), 66);
__d("oz-player/networks/OzPausableRangeStream", ["oz-player/manifests/OzByteRange", "oz-player/networks/OzDeferredBuffer", "oz-player/shims/OzDeferred", "oz-player/shims/OzMaybeNativePromise", "oz-player/utils/ozPipeErrorTo"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        return new Error("Upstream has an inconsistent range")
    }
    var i = function() {
        function a() {
            this.$1 = 0
        }
        var b = a.prototype;
        b.setBytesToSkip = function(a) {
            this.$1 = a
        };
        b.setBytesSkipped = function(a) {
            this.$1 -= a
        };
        b.getBytesToSkip = function() {
            return this.$1
        };
        b.hasMoreBytesToSkip = function() {
            return this.$1 > 0
        };
        return a
    }();
    a = function() {
        function a(b, d, e, f, g) {
            var j = this;
            this.$5 = !1;
            this.$7 = 0;
            this.$8 = 0;
            this.$13 = !1;
            this.$14 = new i();
            this.$15 = !1;
            this.$16 = !1;
            this.$17 = !1;
            this.startStream = function() {
                j.$13 = !0;
                var b = {
                    startByte: j.$1.startByte,
                    endByte: j.$1.endByte
                };
                !j.$15 ? b.startByte += j.$8 : j.$8 && (j.$3.produce("skip_buffered_bytes"), j.$8 = 0);
                var d = j.$4;
                return j.$2.startStream(b).then(function(b) {
                    b.pipeTo(j.$16 ? d : j.$4).then(function() {
                        j.$12 && j.$12.resolve("stream_done")
                    })["catch"](function(b) {
                        j.$12 && !j.$12.isSettled() && (j.$16 && b === a.STREAM_PAUSED ? j.$12.resolve("stream_paused") : j.$12.reject(b))
                    });
                    j.$12 = new(c("oz-player/shims/OzDeferred"))(c("oz-player/shims/OzMaybeNativePromise"));
                    return {
                        statusPromise: j.$12.getPromise()
                    }
                })
            };
            this.$18 = b;
            this.$19 = d;
            this.$1 = e;
            this.$2 = f;
            b = g || {};
            d = b.fixStreamingUndefinedEndByte;
            e = b.disableDeferredBufferArrayShift;
            f = b.enablePausableStreamResumeFromStartDangerously;
            g = b.fixPausePreReadableStream;
            b = b.throwErrorWhenAborted;
            this.$11 = !!d;
            this.$15 = !!f;
            this.$16 = !!g;
            this.$17 = !!b;
            this.$3 = new(c("oz-player/networks/OzDeferredBuffer"))({
                disableArrayShift: !!e
            });
            this.$6 = new this.$18({
                start: function(a) {
                    j.$10 = a
                },
                pull: function(a) {
                    if ((j.$11 && j.$1.endByte === null && j.$5 || j.$7 === j.$20()) && j.$3.isEmpty()) {
                        a.close();
                        return c("oz-player/shims/OzMaybeNativePromise").resolve()
                    }
                    var b = function b() {
                        var d = j.$14.hasMoreBytesToSkip() ? j.$14.getBytesToSkip() : void 0;
                        return j.$3.consume(d).then(function(d) {
                            if (j.$14.hasMoreBytesToSkip()) {
                                j.$14.setBytesSkipped(d.length);
                                return b()
                            }
                            j.$7 += d.length;
                            var e = j.$20();
                            e !== null && j.$7 > (e || 0) && c("oz-player/utils/ozPipeErrorTo")(j.$10, h());
                            a.enqueue(d)
                        })["catch"](function(a) {
                            if (a === "skip_buffered_bytes") {
                                j.$14.setBytesToSkip(j.$7);
                                return b()
                            }
                            throw a
                        })
                    };
                    return b()
                },
                cancel: function(a) {
                    j.$12 && j.$12.resolve("stream_cancelled"), c("oz-player/utils/ozPipeErrorTo")(j.$9, a)
                }
            });
            this.$4 = this.$21()
        }
        var b = a.prototype;
        b.$20 = function() {
            var a = this.$1,
                b = a.startByte;
            a = a.endByte;
            return a != null ? a - b + 1 : null
        };
        b.$21 = function() {
            var a = this;
            return new this.$19({
                start: function(b) {
                    a.$9 = b
                },
                write: function(b) {
                    a.$3.produce(b), a.$8 += b.length
                },
                close: function() {
                    a.$5 = !0;
                    var b = a.$1,
                        d = b.endByte;
                    b = b.startByte;
                    a.$11 && d === null && a.$3.produce(new Uint8Array([]));
                    d !== null && a.$8 !== (d || 0) - b + 1 && c("oz-player/utils/ozPipeErrorTo")(a.$10, h())
                },
                abort: function(b) {
                    a.$12 && (a.$17 ? a.$12.reject(b) : a.$12.resolve("stream_aborted")), c("oz-player/utils/ozPipeErrorTo")(a.$10, b)
                }
            })
        };
        b.getStream = function() {
            return this.$6
        };
        b.pauseStream = function() {
            c("oz-player/utils/ozPipeErrorTo")(this.$9, a.STREAM_PAUSED), this.$12 && this.$12.resolve("stream_paused"), this.$4 = this.$21()
        };
        b.getByteRange = function() {
            return this.$1
        };
        b.getBytesStreamed = function() {
            return this.$7
        };
        b.tryConcatByteRange = function(a) {
            if (this.$13 || !d("oz-player/manifests/OzByteRange").startsImmediateAfter(a, this.$1)) return !1;
            this.$1 = {
                startByte: this.$1.startByte,
                endByte: a.endByte
            };
            return !0
        };
        return a
    }();
    a.STREAM_PAUSED = "streamPaused";
    g["default"] = a
}), 98);
__d("oz-player/shims/www/ozReportUnexpectedErrorWWW", ["FBLogger", "getErrorSafe"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        d === void 0 && (d = "mustfix");
        a = c("getErrorSafe")(a);
        a = c("FBLogger")("oz_player").catching(a);
        b = "Unexpected error in " + b;
        switch (d) {
            case "fatal":
                a.fatal(b);
                break;
            case "mustfix":
                a.mustfix(b);
                break;
            case "warn":
                a.warn(b);
                break;
            case "info":
                a.info(b);
                break;
            case "debug":
                a.debug(b);
                break
        }
    }
    g["default"] = a
}), 98);
__d("oz-player/shims/ozReportUnexpectedError", ["oz-player/shims/www/ozReportUnexpectedErrorWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/ozReportUnexpectedErrorWWW")
}), 98);
__d("oz-player/scheduling/OzRoundRobinPriorityTaskQueue", ["oz-player/shims/ozReportUnexpectedError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b) {
            b === void 0 && (b = -1), this.$3 = function() {}, this.$4 = [], this.$5 = new Map(), this.$1 = a, this.$2 = b
        }
        var b = a.prototype;
        b.getHighestPriority = function() {
            return Math.max.apply(Math, this.$4.map(function(a) {
                return a.queue.length ? a.priority : -Infinity
            }))
        };
        b.enqueue = function(a, b) {
            var d = this;
            b = b;
            b = this.$6(b);
            var e = this.$5.get(a);
            if (e === b) return;
            this.$5.has(a) && this.remove(a);
            e = this.$7(b);
            var f = this.$4[e];
            f && f.priority === b || (f = {
                priority: b,
                queue: []
            }, this.$4.splice(e, 0, f));
            this.$5.set(a, b);
            f.queue.push(a);
            a.getPromise().then(function() {
                d.remove(a)
            }, function() {
                d.remove(a)
            })["catch"](function(a) {
                c("oz-player/shims/ozReportUnexpectedError")(a, "OzRoundRobinPriorityTaskQueue remove after task run")
            });
            this.$3(a, b >= this.$1 ? "immediate" : "normal")
        };
        b.updatePriority = function(a, b) {
            if (!this.$5.has(a)) return;
            this.enqueue(a, b)
        };
        b.dequeue = function() {
            for (var a = 0; a < this.$4.length; a++) {
                var b = this.$4[a];
                if (b.queue.length) {
                    b = b.queue.shift();
                    this.$5["delete"](b);
                    return b
                }
            }
            return null
        };
        b.remove = function(a) {
            var b = this.$5.get(a);
            if (b !== void 0) {
                b = this.$7(b);
                b = this.$4[b];
                if (b && b.queue) {
                    var c = b.queue.findIndex(function(b) {
                        return b === a
                    });
                    c > -1 && b.queue.splice(c, 1)
                }
                this.$5["delete"](a)
            }
        };
        b.setOnTaskUpdated = function(a) {
            this.$3 = a
        };
        b.clearOnTaskUpdated = function() {
            this.setOnTaskUpdated(function() {})
        };
        b.getLength = function() {
            return this.$5.size
        };
        b.test_isEmpty = function() {
            return this.$5.size === 0 && this.$4.every(function(a) {
                return a.queue.length === 0
            })
        };
        b.$7 = function(a) {
            a = a;
            a = this.$6(a);
            var b;
            for (b = 0; b < this.$4.length; b++)
                if (a >= this.$4[b].priority) return b;
            return b
        };
        b.$6 = function(a) {
            a = a;
            this.$2 >= 0 && (a = Number.parseFloat(a.toFixed(this.$2)));
            return a
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("oz-player/shims/www/ozSetTimeoutAcrossTransitionsWWW", ["setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("setTimeoutAcrossTransitions")
}), 98);
__d("oz-player/shims/ozSetTimeoutAcrossTransitions", ["oz-player/shims/www/ozSetTimeoutAcrossTransitionsWWW"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("oz-player/shims/www/ozSetTimeoutAcrossTransitionsWWW")
}), 98);
__d("oz-player/scheduling/OzSequentialTaskScheduler", ["oz-player/shims/OzMaybeNativePromise", "oz-player/shims/ozReportUnexpectedError", "oz-player/shims/ozSetTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b) {
            this.$3 = 0;
            this.$1 = a;
            a = b || {};
            b = a.taskTimeout;
            this.$4 = b || 0
        }
        var b = a.prototype;
        b.start = function() {
            this.$1.setOnTaskUpdated(this.$5.bind(this));
            var a = this.$1.dequeue();
            a && this.$6(a, "immediate")
        };
        b.destroy = function() {
            this.$2 && this.$2.cancel(), this.$1.clearOnTaskUpdated()
        };
        b.$5 = function(a, b) {
            b = this.$6(a, b);
            b && this.$1.remove(a)
        };
        b.$6 = function(a, b) {
            var d = this;
            if (this.$2 && b !== "immediate") return !1;
            this.$2 && this.$2.cancel();
            b = a.run()["catch"](function(a) {});
            this.$4 > 0 && (b = c("oz-player/shims/OzMaybeNativePromise").race([b, new(c("oz-player/shims/OzMaybeNativePromise"))(function(a, b) {
                c("oz-player/shims/ozSetTimeoutAcrossTransitions")(a, d.$4)
            })]));
            this.$3++;
            this.$2 = a;
            b = b.then(function() {
                d.$3--;
                d.$2 === a && (d.$2 = null);
                if (d.$3 === 0) {
                    var b = d.$1.dequeue();
                    b && d.$6(b, "immediate")
                }
            });
            b["catch"](function(a) {
                c("oz-player/shims/ozReportUnexpectedError")(a, "OzSequentialTaskScheduler task complete")
            });
            return !0
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("oz-player/utils/OzError", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            var c;
            c = a.call(this, b.description) || this;
            c.$OzError1 = b;
            c.name = b.type;
            c.message = b.description;
            b = c.stack;
            if (!(typeof b === "string" && b !== "")) {
                if (Error.captureStackTrace) {
                    var d = {};
                    Error.captureStackTrace(d, c.constructor);
                    b = d.stack
                } else {
                    d = new Error().stack.split("\n");
                    d.splice(/^Error/.test(d[0]) ? 1 : 0, 1);
                    b = d.join("\n")
                }
                typeof b === "string" && b !== "" ? c.stack = b.replace(/^Error/, c.name) : c.stack = ""
            }
            return c
        }
        var c = b.prototype;
        c.getExtra = function() {
            return this.$OzError1.extra || {}
        };
        c.getType = function() {
            return this.$OzError1.type
        };
        c.getDescription = function() {
            return this.$OzError1.description
        };
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f["default"] = a
}), 66);
__d("oz-player/utils/OzTaggedTimeRanges", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a) {
            this.$1 = [], this.$2 = 0, this.$3 = 0, this.$4 = a ? a : function(a, b) {
                return a === b
            }
        }
        var b = a.prototype;
        b.add = function(a, b, c) {
            if (b < a) return;
            if (b === a) return;
            if (this.$1.length === 0) {
                this.$1.push({
                    startTime: a,
                    endTime: b,
                    tag: c
                });
                return
            }
            var d = 0,
                e = 0;
            for (var f = 0; f < this.$1.length; f++) {
                if (a === this.$1[f].startTime && b === this.$1[f].endTime) {
                    d = f;
                    e = f + 1;
                    break
                }
                a >= this.$1[f].startTime && (d = f + 1);
                b <= this.$1[f].endTime && (e = f);
                if (b < this.$1[f].startTime) break
            }
            this.$1.splice(d, e - d, {
                startTime: a,
                endTime: b,
                tag: c
            });
            this.$5(d)
        };
        b.$5 = function(a) {
            a = a;
            var b = this.$1[a],
                c = null;
            a !== 0 && (c = this.$1[a - 1]);
            c !== null && (this.$4(c.tag, b.tag) ? c.endTime >= b.startTime && (this.$1.splice(a - 1, 2, {
                startTime: c.startTime,
                endTime: Math.max(b.endTime, c.endTime),
                tag: b.tag
            }), a--) : (c.endTime > b.startTime && c.startTime === b.startTime ? (this.$1.splice(a - 1, 1), a--) : c.endTime > b.startTime && this.$1.splice(a - 1, 1, {
                startTime: c.startTime,
                endTime: b.startTime,
                tag: c.tag
            }), c.endTime > b.endTime && this.$1.splice(a + 1, 0, {
                startTime: b.endTime,
                endTime: c.endTime,
                tag: c.tag
            })));
            c = null;
            a !== this.$1.length - 1 && (c = this.$1[a + 1]);
            c && (this.$4(c.tag, b.tag) ? c.startTime <= b.endTime && this.$1.splice(a, 2, {
                startTime: b.startTime,
                endTime: Math.max(c.endTime, b.endTime),
                tag: b.tag
            }) : c.startTime <= b.endTime && (c.endTime < b.endTime ? (this.$1.splice(a, 1, {
                startTime: b.startTime,
                endTime: c.startTime,
                tag: b.tag
            }), this.$1.push({
                startTime: c.endTime,
                endTime: b.endTime,
                tag: b.tag
            })) : this.$1.splice(a + 1, 1, {
                startTime: b.endTime,
                endTime: c.endTime,
                tag: c.tag
            })))
        };
        b.get = function(a) {
            var b = a >= this.$3 ? this.$2 : 0,
                c = null;
            for (var b = b; b < this.$1.length; b++)
                if (this.$1[b].startTime <= a && a < this.$1[b].endTime) {
                    c = b;
                    break
                }
            this.$2 = c === null ? 0 : c;
            this.$3 = a;
            return c === null ? null : this.$1[c].tag
        };
        b.getLength = function() {
            return this.$1.length
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("TimeRanges", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    a = function() {
        function a(a) {
            this.$1 = [], this.$1 = a
        }
        var b = a.prototype;
        b.start = function(a) {
            this.$1[a] || h(0, 2205);
            return this.$1[a].startTime
        };
        b.end = function(a) {
            this.$1[a] || h(0, 2205);
            return this.$1[a].endTime
        };
        b.length = function() {
            return this.$1.length
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoWithFallbackMode", ["Event", "SubscriptionsHandler", "TimeSlice", "VideoPlayerExperiments", "VideoPlayerLoggerFallbackReasons", "Visibility"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a(a, c) {
            var d = this;
            this.$1 = !1;
            this.$2 = !1;
            this.$5 = function() {
                d.$1 = !0, b("VideoPlayerExperiments").disableFallbackModeForInactiveTab && d.$2 && (d.$6.play("fallback_mode"), d.$2 = !1)
            };
            this.$8 = function() {
                d.$1 = !1
            };
            this.$3 = new(b("SubscriptionsHandler"))();
            c || (c = a, a = null);
            this.$4 = c;
            a && this.enable(a)
        }
        var c = a.prototype;
        c.enable = function(a) {
            var c = this;
            this.$3.engage();
            this.$6 = a;
            if (this.$6.isImplementationUnavailable() || this.$6.getOption("SphericalVideoPlayer", "isUnavailable")) {
                this.$7(b("VideoPlayerLoggerFallbackReasons").FLASH_UNAVAILABLE);
                return
            }
            this.$3.addSubscriptions(b("Event").listen(window, "blur", this.$8), b("Event").listen(window, "focus", this.$5), b("Visibility").addListener(b("Visibility").HIDDEN, this.$8), b("Visibility").addListener(b("Visibility").VISIBLE, this.$5), a.addListener("error", this.$9.bind(this)));
            if (this.$4.fallbackTimeoutMs) {
                a = this.$4.fallbackTimeoutMs;
                this.$10 = setTimeout(b("TimeSlice").guard(function() {
                    c.$6.isState("loading") && (c.$6.pause("fallback_mode"), c.$7(b("VideoPlayerLoggerFallbackReasons").TIMEOUT), c.$2 = !0)
                }, "VideoWithFallbackMode fallbackTimeout", {
                    propagationType: b("TimeSlice").PropagationType.EXECUTION
                }), a)
            }
        };
        c.disable = function() {
            this.$3.release(), clearTimeout(this.$10), this.$10 = null, this.$6 = null
        };
        c.$9 = function(a) {
            if (this.$6.isState("fallback")) return;
            this.$6.isState("playing") && this.$6.pause("fallback_mode");
            this.$6.abortLoading();
            a ? this.$7(a) : (this.$7(b("VideoPlayerLoggerFallbackReasons").FLASH_ERROR), this.$2 = !0)
        };
        c.$7 = function(a) {
            if (b("VideoPlayerExperiments").disableFallbackModeForInactiveTab && !this.$1) return;
            this.$6.setState("fallback");
            a === b("VideoPlayerLoggerFallbackReasons").TIMEOUT && this.$6.emit("VideoWithStallRecoveryOverlay/timeout");
            this.$6.logEvent("entered_fallback", {
                debug_reason: a
            })
        };
        return a
    }();
    e.exports = a
}), null);
__d("VideoPlayerApiEvents", [], (function(a, b, c, d, e, f) {
    a = ["buffered", "buffering", "bufferingProgress", "beginPlayback", "updateStatus", "logEvent", "pausePlayback", "playbackNotAllowed", "clickVideo", "clickForTracking", "finishPlayback", "unmuteVideo", "muteVideo", "changeVolume", "turnOffAutoplay", "updateBuffer", "updateMetadata", "qualityChange", "updateViewportBegin", "updateViewportMove", "updateViewportEnd", "dimensionsChange", "viewportChange", "wheelScroll", "error", "loadedSubtitles", "toggleSubtitles", "captionsAvailabilityChanged", "toggleFullscreen", "seekEnd", "seekRangeChanged", "streamInterrupted", "streamResumed", "networkInterrupted", "networkResumed", "debug/dashPlayerEvent", "abortedLoading", "restoringAfterAbort", "restoredAfterAbort", "sphericalOrientationChange", "videoNodeStaled", "replicaSwitch", "initialLiveManifestRequestFailure"];
    f["default"] = a
}), 66);
__d("getErrorMessageFromMediaErrorCode", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case 1:
                return "The fetching process for the media resource was aborted by the user agent at the users request.";
            case 2:
                return "A network error of some description caused the user agent to stop fetching the media resource, after the resource was established to be usable.";
            case 3:
                return "An error of some description occurred while decoding the media resource, after the resource was established to be usable.";
            case 4:
                return "The media resource indicated by the src attribute was not suitable."
        }
        return null
    }
    f["default"] = a
}), 66);
__d("getErrorNameFromMediaErrorCode", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case 1:
                return "MEDIA_ERR_ABORTED";
            case 2:
                return "MEDIA_ERR_NETWORK";
            case 3:
                return "MEDIA_ERR_DECODE";
            case 4:
                return "MEDIA_ERR_SRC_NOT_SUPPORTED";
            default:
                return "MEDIA_ERR_UNKNOWN_" + ((a = a) != null ? a : "UNDEFINED")
        }
    }
    f["default"] = a
}), 66);
__d("VideoPlaybackQuality", [], (function(a, b, c, d, e, f) {
    function a(a) {
        if (typeof a.getVideoPlaybackQuality === "function") return a.getVideoPlaybackQuality().droppedVideoFrames;
        a = a.webkitDroppedFrameCount;
        return typeof a === "number" ? a : 0
    }

    function b(a) {
        if (typeof a.getVideoPlaybackQuality === "function") return a.getVideoPlaybackQuality().totalVideoFrames;
        a = a.webkitDecodedFrameCount;
        return typeof a === "number" ? a : 0
    }
    f.getDroppedFrames = a;
    f.getTotalFrames = b
}), 66);
__d("VideoPlayerConnectionQuality", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {
            POOR: "POOR",
            MODERATE: "MODERATE",
            GOOD: "GOOD",
            EXCELLENT: "EXCELLENT"
        },
        h = [{
            bandwidth: 5e5,
            connectionQuality: g.POOR
        }, {
            bandwidth: 2e6,
            connectionQuality: g.MODERATE
        }, {
            bandwidth: 1e7,
            connectionQuality: g.GOOD
        }],
        i = 100,
        j = null,
        k = null;
    a = function(a) {
        if (j !== null && k !== null && j >= Date.now() - i) return k;
        a = a();
        var b = null;
        if (a != null)
            for (var c = 0; c < h.length; c++)
                if (a < h[c].bandwidth) {
                    b = h[c].connectionQuality;
                    break
                }
        b === null && (b = g.EXCELLENT);
        j = Date.now();
        k = b;
        return b
    };
    f.evaluate = a
}), 66);
__d("VideoCover", ["invariant", "Animation", "Bootloader", "CSS", "EventListener", "Promise", "SubscriptionsHandler", "promiseDone", "setTimeout"], (function(a, b, c, d, e, f, g, h) {
    a = function() {
        function a(a, e, f, g, i, j) {
            var k = this;
            g === void 0 && (g = null);
            i === void 0 && (i = !1);
            j === void 0 && (j = 0);
            this.$7 = new(c("SubscriptionsHandler"))();
            this.$15 = function() {
                k.$5 && d("CSS").show(k.$1)
            };
            this.$16 = function() {
                k.$5 && d("CSS").hide(k.$1)
            };
            this.$11 = function() {
                k.$3 != null && k.$3.length > 0 ? c("Bootloader").loadModules(["PhotoSnowlift"], function(a) {
                    return a.bootstrap(k.$3)
                }, "VideoCover") : k.$8 && k.$8.clickVideo()
            };
            this.$12 = function() {
                k.$9 && k.$8 && !k.$8.hasSeenClick() ? c("promiseDone")(new(b("Promise"))(function(a) {
                    return c("setTimeout")(a, k.$10)
                }), function(a) {
                    return k.$17()
                }, function(a) {
                    return k.$17()
                }) : d("CSS").hide(k.$1)
            };
            this.$14 = function() {
                if (k.$8) {
                    var a = k.$8.getOption("Looping", "isLooping");
                    if (k.$4 || a) return;
                    d("CSS").show(k.$1)
                }
            };
            this.$13 = function() {
                k.$8 && k.$8.isState("fallback") && k.$6 && d("CSS").show(k.$1)
            };
            a instanceof Element || h(0, 4829);
            this.$1 = a;
            e[0] instanceof Element || h(0, 4830);
            this.$2 = e[0];
            this.$3 = f;
            this.$9 = i;
            this.$10 = j;
            g && (this.$4 = g.hiddenAfterFinish, this.$5 = g.showWhileBuffering, this.$6 = g.showAfterFallback);
            c("EventListener").listen(this.$1, "click", this.$11)
        }
        var e = a.prototype;
        e.disable = function() {
            this.$7.release(), this.$8 && this.$8.unregisterOption("VideoCover", "coverElement"), this.$8 = null
        };
        e.enable = function(a) {
            var b = this;
            this.$8 = a;
            a.getState() === "playing" && this.$12();
            this.$7.addSubscriptions(a.addListener("stateChange", this.$13), a.addListener("beginPlayback", this.$12), a.addListener("finishPlayback", this.$14), a.addListener("buffering", this.$15), a.addListener("buffered", this.$16));
            a.registerOption("VideoCover", "coverElement", function() {
                return b.$1
            })
        };
        e.getCurrentCover = function() {
            return this.$2
        };
        e.setSnowLiftURI = function(a) {
            this.$3 = a
        };
        e.$17 = function() {
            new(c("Animation"))(this.$1).from("opacity", 1).to("opacity", 0).duration(1e3).hide().go()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoNodeStaledScreen", ["CSS", "EventListener", "SubscriptionsHandler"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            var b = this;
            this.$3 = new(c("SubscriptionsHandler"))();
            this.$5 = function() {
                d("CSS").show(b.$1)
            };
            this.$4 = function() {
                d("CSS").hide(b.$1)
            };
            this.$1 = a;
            this.$2 = null;
            c("EventListener").listen(this.$1, "click", this.$4)
        }
        var b = a.prototype;
        b.enable = function(a) {
            this.$2 = a, this.$3.addSubscriptions(this.$2.addListener("videoNodeStaled", this.$5))
        };
        b.disable = function() {
            this.$3.release(), this.$2 = null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoMimeTypes", [], (function(a, b, c, d, e, f) {
    function a(a, b, c) {
        return a + '; codecs="' + b + ", " + c + '"'
    }
    e = "mp4a.40.2";

    function b(a) {
        return "avc1.42E0" + a.toString(16).toUpperCase()
    }

    function c(a) {
        return "avc1.4D40" + a.toString(16).toUpperCase()
    }

    function d(a) {
        return "avc1.6400" + a.toString(16).toUpperCase()
    }
    var g = "video/mp4";
    b = a(g, b(30), e);
    var h = a(g, c(30), e);
    c = a(g, c(31), e);
    var i = a(g, d(50), e);
    a = a(g, d(51), e);
    g = {
        h264baseline: b,
        h264main30avc: h,
        h264main31avc: c,
        h264high50avc: i,
        h264high51avc: a
    };
    f["default"] = g
}), 66);
__d("DataViewReader", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            this.$1 = 0, this.$2 = a
        }
        var b = a.prototype;
        b.seek = function(a) {
            this.$1 = a
        };
        b.skip = function(a) {
            var b = this.$1;
            this.$1 += a;
            return b
        };
        b.readUint8 = function() {
            return this.$2.getUint8(this.skip(8 / 8))
        };
        b.readUint16 = function(a) {
            a === void 0 && (a = !1);
            return this.$2.getUint16(this.skip(16 / 8), a)
        };
        b.readUint32 = function(a) {
            a === void 0 && (a = !1);
            return this.$2.getUint32(this.skip(32 / 8), a)
        };
        b.readUint64 = function(a) {
            a === void 0 && (a = !1);
            var b;
            a ? (a = this.$2.getUint32(this.skip(32 / 8), !0), b = this.$2.getUint32(this.skip(32 / 8), !0)) : (b = this.$2.getUint32(this.skip(32 / 8)), a = this.$2.getUint32(this.skip(32 / 8)));
            if (b > 2097151) throw new RangeError("Overflow reading 64-bit value.");
            return Math.pow(2, 32) * b + a
        };
        b.readInt64 = function(a) {
            a === void 0 && (a = !1);
            var b;
            a ? (a = this.$2.getInt32(this.skip(32 / 8), !0), b = this.$2.getInt32(this.skip(32 / 8), !0)) : (b = this.$2.getInt32(this.skip(32 / 8)), a = this.$2.getInt32(this.skip(32 / 8)));
            if (b > 2097151) throw new RangeError("Overflow reading 64-bit value.");
            return Math.pow(2, 32) * (b | 0) + a
        };
        b.readInt16 = function(a) {
            a === void 0 && (a = !1);
            return this.$2.getInt16(this.skip(16 / 8), a)
        };
        b.readInt32 = function(a) {
            a === void 0 && (a = !1);
            return this.$2.getInt32(this.skip(32 / 8), a)
        };
        b.readZeroTerminatedString = function(a) {
            var b = "",
                c = 0,
                d;
            while (c++ < a && (d = this.readUint8())) b += String.fromCharCode(d);
            return b
        };
        b.readChars = function(a) {
            var b = "";
            while (a-- > 0) b += String.fromCharCode(this.$2.getUint8(this.skip(8 / 8)));
            return b
        };
        b.readBytes = function(a) {
            var b = [];
            while (a-- > 0) b.push(this.$2.getUint8(this.skip(8 / 8)));
            return b
        };
        b.getDataView = function() {
            return this.$2
        };
        b.getCursor = function() {
            return this.$1
        };
        b.hasMoreData = function() {
            return this.$2.byteLength - this.getCursor() > 0
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("Mp4Box", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            this.$4 = a.getCursor(), this.$1 = a.readUint32(), this.$2 = a.readChars(4), this.$1 === 1 ? this.$1 = a.readUint64() : this.$1 === 0 && (this.$1 = a.getDataView().byteLength - this.$4), this.$2 === "uuid" && (this.$3 = a.readChars(16)), this.$5 = a.getCursor()
        }
        var b = a.prototype;
        b.getBodyStart = function() {
            return this.$5
        };
        b.getBodySize = function() {
            var a = this.$5 - this.$4;
            return this.getSize() - a
        };
        b.getSize = function() {
            return this.$1
        };
        b.getType = function() {
            return this.$2
        };
        b.getUuid = function() {
            return this.$3
        };
        b.getStart = function() {
            return this.$4
        };
        b.inspect = function() {
            return "{ size: " + this.$1 + ", type: " + this.$2 + " }"
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("Mp4FullBox", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a, b) {
            this.$2 = a.readUint8(), this.$1 = a.readUint8(), this.$1 = a.readUint8() + (this.$1 << 8), this.$1 = a.readUint8() + (this.$1 << 8), this.$3 = b
        }
        var b = a.prototype;
        b.getVersion = function() {
            return this.$2
        };
        b.getFlags = function() {
            return this.$1
        };
        b.getBox = function() {
            return this.$3
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("Mp4Demuxer", ["DataViewReader", "Mp4Box", "Mp4FullBox"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            this.$1 = new(c("DataViewReader"))(a)
        }
        var b = a.prototype;
        b.parseBox = function() {
            return new(c("Mp4Box"))(this.$1)
        };
        b.parseFullBox = function(a) {
            return new(c("Mp4FullBox"))(this.$1, a)
        };
        b.parseCanonicalBox = function(a, b) {
            return new a(this.$1, b)
        };
        b.skipBox = function(a) {
            this.$1.seek(a.getStart() + a.getSize())
        };
        b.withinBox = function(a) {
            var b = this.$1.getCursor();
            return b >= a.getStart() && b < a.getStart() + a.getSize()
        };
        b.atEnd = function() {
            return this.$1.getCursor() >= this.$1.getDataView().byteLength
        };
        b.reset = function() {
            this.$1.seek(0)
        };
        b.readBoxBodyText = function(a) {
            this.$1.seek(a.getBodyStart());
            var b = new TextDecoder();
            a = new Uint8Array(this.$1.readBytes(a.getBodySize()));
            return b.decode(a)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("Mp4DASHEventMessageBox", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a, b) {
            this.$1 = b, this.$2 = null, b.getVersion() == 0 ? this.$2 = {
                version: 0,
                schemeIdUri: a.readZeroTerminatedString(this.$4(a, b)),
                value: a.readZeroTerminatedString(this.$4(a, b)),
                timescale: a.readUint32(),
                presentationTimeDelta: a.readUint32(),
                eventDuration: a.readUint32(),
                id: a.readUint32()
            } : b.getVersion() == 1 && (this.$2 = {
                version: 1,
                timescale: a.readUint32(),
                presentationTime: a.readUint64(),
                eventDuration: a.readUint32(),
                id: a.readUint32(),
                schemeIdUri: a.readZeroTerminatedString(this.$4(a, b)),
                value: a.readZeroTerminatedString(this.$4(a, b))
            }), this.$3 = new DataView(a.getDataView().buffer, a.getCursor())
        }
        var b = a.prototype;
        b.getFullBox = function() {
            return this.$1
        };
        b.getEmsgFields = function() {
            return this.$2
        };
        b.getMessageData = function() {
            return this.$3
        };
        b.getStartTime = function() {
            var a = this.$2;
            if (a == null) return null;
            switch (a.version) {
                case 0:
                    return null;
                case 1:
                    return this.$5(a)
            }
        };
        b.getDuration = function() {
            var a = this.$2;
            if (a == null) return null;
            var b = a.eventDuration;
            a = a.timescale;
            return a !== 0 ? b / a : b
        };
        b.$5 = function(a) {
            var b = a.timescale;
            a = a.presentationTime;
            return b !== 0 ? a / b : a
        };
        b.$4 = function(a, b) {
            return b.getBox().getSize() - (a.getCursor() - b.getBox().getStart())
        };
        return a
    }();
    a.canonicalType = "emsg";
    f["default"] = a
}), 66);
__d("LiveTraceWwwVideoPlayerFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743810");
    c = b("FalcoLoggerInternal").create("live_trace_www_video_player", a);
    e.exports = c
}), null);
__d("VideoLiveTrace", ["DataViewReader", "LiveTraceWwwVideoPlayerFalcoEvent", "Mp4DASHEventMessageBox", "Mp4Demuxer", "throttle"], (function(a, b, c, d, e, f, g) {
    var h = "x-fb-video-livetrace-ids",
        i = "x-fb-video-livetrace-parentsource",
        j = "x-fb-video-livetrace-streamtype",
        k = "x-fb-origin-hit",
        l = "x-fb-edge-hit",
        m = "PLY:WWW:",
        n = m + "DL:",
        o = m + "DIS:",
        p = 1e3,
        q = /[\r\n]+/;
    a = function() {
        function a(a, b, d) {
            var e = this;
            this.$6 = [];
            this.$1 = a;
            this.$2 = null;
            a = d + ":" + b.substring(0, 5);
            this.$3 = m + a;
            this.$4 = n + a;
            this.$5 = o + a;
            this.$7 = c("throttle")(function(a) {
                return e.$8(a)
            }, p)
        }
        var b = a.prototype;
        b.setStreamType = function(a) {
            this.$2 = a
        };
        b.$9 = function(a, b, d, e, f, g) {
            var h, i = this,
                j = Date.now(),
                k = (h = this.$2) != null ? h : 0;
            c("LiveTraceWwwVideoPlayerFalcoEvent").log(function() {
                return {
                    stream_id: i.$1,
                    stream_type: k,
                    event_name: b,
                    event_severity: f,
                    event_creation_time: j,
                    source: a,
                    trace_id: d,
                    parent_source: e,
                    metadata: g
                }
            })
        };
        b.onUpdateStatus = function(a) {
            this.$7(a)
        };
        b.$8 = function(a) {
            a = a.position * 1e3;
            for (var b = this.$6.length - 1; b >= 0; b--) {
                var c = this.$6[b];
                if (c.presentationTimestamp > a) continue;
                if (c.displayTimestamp == null) c.displayTimestamp = Date.now();
                else continue;
                this.$9(this.$5, "FRAME", c.traceId, this.$4, "SUCCESS", null)
            }
        };
        b.getAndFlushTracedFrames = function() {
            var a, b = {
                    currentTimeMs: Date.now(),
                    streamId: this.$1
                },
                c = {
                    dl: [],
                    dis: []
                },
                d = [];
            this.$6.forEach(function(a) {
                a.hasBeenFlushedAsDownloaded || (c.dl.push({
                    id: a.traceId,
                    timeMs: a.downloadTimestamp
                }), a.hasBeenFlushedAsDownloaded = !0), a.displayTimestamp != null ? c.dis.push({
                    id: a.traceId,
                    timeMs: a.displayTimestamp
                }) : d.push(a)
            });
            this.$6 = d;
            b[(a = this.$2) != null ? a : 0] = c;
            return c.dl.length > 0 || c.dis.length > 0 ? b : null
        };
        b.handleHeadersString = function(a, b) {
            a = a.trim().split(q);
            this.$10(a.map(function(a) {
                a = a.split(": ");
                return [a.shift().toLowerCase(), a.shift()]
            }), b)
        };
        b.handleHeaders = function(a, b) {
            this.$10(this.$11(a), b)
        };
        b.handleHeadersAndBody = function(a, b, c) {
            this.$12(this.$11(a), b, c)
        };
        b.$11 = function(a) {
            var b = [];
            for (var a = a.entries(), c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= a.length) break;
                    e = a[d++]
                } else {
                    d = a.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                b.push(e)
            }
            return b
        };
        b.$13 = function(a) {
            var b = Date.now(),
                d = new Map(),
                e = a.reduce(function(a, b) {
                    return a + b.byteLength
                }, 0),
                f = new Uint8Array(e),
                g = 0;
            a.forEach(function(a) {
                f.set(a, g), g += a.byteLength
            });
            e = new(c("Mp4Demuxer"))(new DataView(f.buffer, f.byteOffset, f.byteLength));
            while (!e.atEnd()) {
                a = e.parseBox();
                if (a.getType() === c("Mp4DASHEventMessageBox").canonicalType) {
                    var h = e.parseCanonicalBox(c("Mp4DASHEventMessageBox"), e.parseFullBox(a));
                    if (h instanceof c("Mp4DASHEventMessageBox")) {
                        var i;
                        i = (i = h.getEmsgFields()) == null ? void 0 : i.schemeIdUri;
                        if (i == null ? void 0 : i.startsWith("livedash:trace:")) {
                            i = h.getMessageData();
                            h = new(c("DataViewReader"))(i).readZeroTerminatedString(i.byteLength);
                            try {
                                i = JSON.parse(h);
                                Array.isArray(i) && i.filter(function(a) {
                                    return Array.isArray(a) && a.length === 2
                                }).forEach(function(a) {
                                    var c = a[0];
                                    a = a[1];
                                    d.set(c, {
                                        displayTimestamp: null,
                                        downloadTimestamp: b,
                                        hasBeenFlushedAsDownloaded: !1,
                                        presentationTimestamp: a,
                                        traceId: c
                                    })
                                })
                            } catch (a) {}
                        }
                    }
                }
                e.skipBox(a)
            }
            return d
        };
        b.$14 = function(a, b) {
            var c = this,
                d = "null",
                e = Date.now(),
                f = new Map(),
                g = "";
            a.forEach(function(a) {
                var b = a[0].toLowerCase();
                a = a[1];
                if (b === h && a) {
                    var m = a.split(",");
                    m.forEach(function(a) {
                        a = a.split(":");
                        var b = +a[0];
                        a = +a[1];
                        f.set(b, {
                            displayTimestamp: null,
                            downloadTimestamp: e,
                            hasBeenFlushedAsDownloaded: !1,
                            presentationTimestamp: a,
                            traceId: b
                        })
                    })
                }
                b === i && (g = a);
                c.$2 === null && b === j && (c.$2 = parseInt(a, 10));
                (b === k || b === l) && parseInt(a, 10) && (d = b === k ? "origin" : "edge")
            });
            a = b || {};
            a.hit = d;
            return g !== "" ? {
                tracedFrames: f,
                eventMetaData: a,
                parentSource: g,
                streamType: this.$2
            } : null
        };
        b.$12 = function(a, b, c) {
            var d = this.$14(a, c);
            if (d == null || d.parentSource === "") return;
            if (b == null ? void 0 : b.length) {
                a = this.$13(b);
                a.forEach(function(a, b) {
                    d.tracedFrames.set(b, a)
                })
            }
            this.$6 = this.$6.concat(Array.from(d.tracedFrames.values()));
            c = d.tracedFrames.keys();
            for (var b = c, a = Array.isArray(b), c = 0, b = a ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (a) {
                    if (c >= b.length) break;
                    e = b[c++]
                } else {
                    c = b.next();
                    if (c.done) break;
                    e = c.value
                }
                e = e;
                this.$9(this.$4, "SEGMENT", e, d.parentSource, "SUCCESS", d.eventMetaData)
            }
        };
        b.$10 = function(a, b) {
            this.$12(a, null, b)
        };
        b.handleXHR = function(a, b) {
            this.handleHeadersString(a.getAllResponseHeaders(), b)
        };
        b.getLiveTraceContext = function() {
            return this.$2 != null ? {
                streamId: this.$1,
                streamType: this.$2,
                sourceId: this.$3
            } : null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoPlayerShakaConfigContextProvider", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {}
        }
        var b = a.prototype;
        b.setContext = function(a, b) {
            if (this.$1[a] !== b) {
                var c;
                this.$1 = babelHelpers["extends"]({}, this.$1, (c = {}, c[a] = b, c))
            }
        };
        b.setAllContexts = function(a) {
            this.$1 = a
        };
        b.getAllContexts = function() {
            return this.$1
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("VideoPlayerShakaConfig", ["VideoPlayerContextSensitiveConfigResolver", "VideoPlayerShakaConfigContextProvider"], (function(a, b, c, d, e, f, g) {
    var h = {};
    a = function() {
        function a(a, b, d) {
            this.$1 = new(c("VideoPlayerShakaConfigContextProvider"))(), this.$2 = b || null, this.$3 = new(c("VideoPlayerContextSensitiveConfigResolver"))(d), this.$3.setContexts(a || {}), a && this.$1.setAllContexts(a)
        }
        a.setGlobalOverrideConfig = function(a) {
            h = a
        };
        var b = a.prototype;
        b.setContext = function(a, b) {
            var c = this.$1.getAllContexts();
            this.$1.setContext(a, b);
            a = this.$1.getAllContexts();
            c !== a && this.$3.setContexts(a)
        };
        b.setOverrideConfig = function(a) {
            this.$2 = a
        };
        b.getBool = function(a, b) {
            a = this.$4(a, b);
            return typeof a === "boolean" ? a : b
        };
        b.getNumber = function(a, b) {
            a = this.$4(a, b);
            return typeof a === "number" ? a : b
        };
        b.getString = function(a, b) {
            a = this.$4(a, b);
            return typeof a === "string" ? a : b
        };
        b.getAllContexts = function() {
            return this.$1.getAllContexts()
        };
        b.$4 = function(a, b) {
            if (!!h && typeof h[a] === typeof b) return h[a];
            if (typeof this.$3.getValue(a) === typeof b) return this.$3.getValue(a);
            return !!this.$2 && typeof this.$2[a] === typeof b ? this.$2[a] : null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("BlobFactory", ["emptyFunction"], (function(a, b, c, d, e, f) {
    var g;

    function h() {
        try {
            new a.Blob(), g = !0
        } catch (a) {
            g = !1
        }
    }
    var i = a.BlobBuilder || a.WebKitBlobBuilder || a.MozBlobBuilder || a.MSBlobBuilder;
    a.Blob ? c = {
        getBlob: function(b, c) {
            b = b || [];
            c = c || {};
            g === void 0 && h();
            if (g) return new a.Blob(b, c);
            else {
                var d = new i();
                for (var e = 0; e < b.length; e++) d.append(b[e]);
                return d.getBlob(c.type)
            }
        },
        isSupported: b("emptyFunction").thatReturnsTrue
    } : c = {
        getBlob: function() {},
        isSupported: b("emptyFunction").thatReturnsFalse
    };
    e.exports = c
}), null);
__d("classWithMixins", [], (function(a, b, c, d, e, f) {
    function a(a, b) {
        var c = function() {
            a.apply(this, arguments)
        };
        c.prototype = Object.assign(Object.create(a.prototype), b.prototype);
        return c
    }
    f["default"] = a
}), 66);
__d("BaseGraphQLSubscription", ["ODS", "Random", "RelayRTIGraphQLSubscriber", "RelayRTIUtils", "gkx", "nullthrows", "relay-runtime", "uuid"], (function(a, b, c, d, e, f, g) {
    var h = 100,
        i = 1e3,
        j = 100,
        k = "gqls_default_logging_base",
        l = "gqls_workplace_logging_base",
        m = 110,
        n = {
            bumpTotalSubscribeCounter: function(a) {
                d("ODS").bumpEntityKey(m, "basegraphqlsubscription_migration", a + ".subscribe.total")
            },
            bumpSsttSubscribeCounter: function(a) {
                d("ODS").bumpEntityKey(m, "basegraphqlsubscription_migration", a + ".subscribe.sstt"), n.bumpTotalSubscribeCounter(a)
            },
            bumpTotalReceiveCounter: function(a) {
                d("ODS").bumpEntityKey(m, "basegraphqlsubscription_migration", a + ".receive.total")
            },
            bumpSsttReceiveCounter: function(a) {
                d("ODS").bumpEntityKey(m, "basegraphqlsubscription_migration", a + ".receive.sstt"), n.bumpTotalReceiveCounter(a)
            }
        };

    function o() {
        if (c("gkx")("676906") && c("Random").coinflip(h)) return k;
        if (c("gkx")("1383502") && c("Random").coinflip(j)) return l;
        if (c("gkx")("1388683") || c("gkx")("1382775") && c("Random").coinflip(i)) return k
    }
    a = function() {
        function a() {}
        var b = a.prototype;
        b.getQuery = function() {
            throw new Error("getQuery() or getQueryID() unimplemented by subclass of BaseGraphQLSubscription")
        };
        b.getQueryParameters = function(a) {
            throw new Error("getQueryParameters() unimplemented by subclass of BaseGraphQLSubscription")
        };
        b.getSubscriptionName = function() {
            var a = d("relay-runtime").getRequest(this.getQuery());
            return String(c("nullthrows")(a.params.metadata.subscriptionName))
        };
        a.subscribe = function(a, b, c, d) {
            return new this().subscribe(a, b, c, d)
        };
        b.subscribe = function(a, b, e, f) {
            var g = this.getQueryParameters(a),
                h = d("relay-runtime").getRequest(this.getQuery()).params,
                i = String(c("nullthrows")((a = h.metadata) == null ? void 0 : a.subscriptionName)),
                j = (a = e == null ? void 0 : e.forceLogContext) != null ? a : o();
            n.bumpSsttSubscribeCounter(i);
            g = babelHelpers["extends"]({}, g, {
                input: babelHelpers["extends"]({}, g.input, {
                    client_subscription_id: c("uuid")()
                })
            });
            a = d("RelayRTIGraphQLSubscriber").subscribeWithMobileStyleTopicTransform(h, g, j, e == null ? void 0 : e.viewerID, f)["do"]({
                start: function() {
                    d("RelayRTIUtils").logSubscriptionEvent("client_subscribe", i, g, j, h.id)
                },
                next: function() {
                    d("RelayRTIUtils").logSubscriptionEvent("receivepayload", i, g, j, h.id)
                },
                unsubscribe: function() {
                    d("RelayRTIUtils").logSubscriptionEvent("client_unsubscribe", i, g, j, h.id)
                }
            });
            return a.subscribe({
                next: function(a) {
                    n.bumpSsttReceiveCounter(i), typeof a == "object" && a.data && b(a.data)
                }
            })
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("CvcV3HttpEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1856513");
    c = b("FalcoLoggerInternal").create("cvc_v3_http_event", a);
    e.exports = c
}), null);
__d("VideoPlayerWwwFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1914651");
    c = b("FalcoLoggerInternal").create("video_player_www", a);
    e.exports = c
}), null);
__d("CVCv3DisabledPlayerOrigins", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        BEEPER: "beeper",
        FB_STORIES: "fb_stories"
    });
    f["default"] = a
}), 66);
__d("CVCv3DisabledPlayerSubOrigins", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        LIVE_BEEPER: "live_beeper"
    });
    f["default"] = a
}), 66);
__d("CVCv3SubscriptionHelper", ["CvcV3HttpEventFalcoEvent", "DateConsts", "guid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b, d) {
            this.$1 = a;
            this.$2 = c("guid")();
            this.$3 = ((a = b) != null ? a : "null") + "::" + ((b = d) != null ? b : "null");
            this.$4 = null;
            this.$5 = null
        }
        var b = a.prototype;
        b.isValidSubscription = function() {
            return !!this.$1
        };
        b.makeCVCv3StateUpdate = function(a, b, c, e) {
            var f = null;
            a != null && !Number.isNaN(a) && b != null && !Number.isNaN(b) && (f = {
                m: e,
                pf: Math.floor((b - a) * d("DateConsts").MS_PER_SEC),
                s: c,
                sa: Math.floor(a * d("DateConsts").MS_PER_SEC)
            });
            e = {
                pps: this.$4,
                ps: f,
                si: this.$2,
                so: this.$3,
                vi: this.$1
            };
            this.$4 = f;
            return e
        };
        b.makeUnifiedVideoCVCUpdate = function(a, b, c, d, e) {
            a = this.makeCVCv3StateUpdate(a, b, c, d);
            this.$5 != null && (a.tk = this.$5);
            return babelHelpers["extends"]({}, a, e)
        };
        b.processUnifiedResponse = function(a) {
            a = a;
            this.$5 = a.tk;
            return a
        };
        b.clearAnyPreviousContext = function() {
            this.$4 = null
        };
        b.logHttpRequestSuccess = function(a) {
            var b = this;
            c("CvcV3HttpEventFalcoEvent").log(function() {
                return {
                    name: "http_request_success",
                    duration_ms: a != null ? a.toString() : null,
                    countable_id: b.$1
                }
            })
        };
        b.logHttpRequestFailure = function(a, b) {
            var d = this;
            c("CvcV3HttpEventFalcoEvent").log(function() {
                return {
                    name: "http_request_failed",
                    error_msg: a,
                    duration_ms: b != null ? b.toString() : null,
                    countable_id: d.$1
                }
            })
        };
        b.logHttpRequestTimeout = function(a) {
            var b = this;
            c("CvcV3HttpEventFalcoEvent").log(function() {
                return {
                    name: "http_request_timeout",
                    duration_ms: a != null ? a.toString() : null,
                    countable_id: b.$1
                }
            })
        };
        b.logHttpResponseBad = function(a, b) {
            var d = this;
            c("CvcV3HttpEventFalcoEvent").log(function() {
                return {
                    name: "http_response_bad",
                    error_msg: a,
                    duration_ms: b != null ? b.toString() : null,
                    countable_id: d.$1
                }
            })
        };
        b.logDebugInfo = function(a) {
            var b = this;
            c("CvcV3HttpEventFalcoEvent").log(function() {
                return {
                    name: a,
                    countable_id: b.$1
                }
            })
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("WebSessionExtender", ["WebSession", "clearInterval", "cr:913", "setInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 2e4,
        i = new Set(),
        j = null;

    function a(a, e) {
        e === void 0 && (e = "extender"), i.add(a), j == null && (d("WebSession").extend(Date.now() + h + 2e3), j = c("setInterval")(function() {
            d("WebSession").extend(Date.now() + h + 2e3), b("cr:913") && new(b("cr:913"))().setClientTime(Date.now()).setWebsessionID(d("WebSession").getId()).setReason(e).log()
        }, h))
    }

    function e(a) {
        i["delete"](a);
        a = i.size;
        a === 0 && j != null && (c("clearInterval")(j), j = null)
    }
    g.subscribe = a;
    g.unsubscribe = e
}), 98);
__d("VideoPlayerLoggerErrorStates", [], (function(a, b, c, d, e, f) {
    a = "playback_failure";
    b = "player_failure";
    f.PLAYBACK_FAILURE = a;
    f.PLAYER_FAILURE = b
}), 66);
__d("VideoPlayerLoggerErrors", [], (function(a, b, c, d, e, f) {
    a = "entered_fallback";
    b = "error_calling_flash";
    f.ENTERED_FALLBACK = a;
    f.ERROR_CALLING_FLASH = b
}), 66);
__d("VideoPlayerLoggerPlayerStates", [], (function(a, b, c, d, e, f) {
    a = "started";
    b = "unpaused";
    c = {
        STARTED: a,
        UNPAUSED: b
    };
    f["default"] = c
}), 66);
__d("getVideoBrowserTabId", ["guid"], (function(a, b, c, d, e, f, g) {
    var h = c("guid")().slice(-8);

    function a() {
        return h
    }
    g["default"] = a
}), 98);