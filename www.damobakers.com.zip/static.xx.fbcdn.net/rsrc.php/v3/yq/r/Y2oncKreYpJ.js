if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometLazyPopoverTrigger.react", ["BasePopoverTrigger.react", "CometPopoverLoadingState.react", "lazyLoadComponent", "react", "tracePolicyFromResource", "useCometPopoverInteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = a.fallback,
            d = a.popoverResource,
            e = a.preloadTrigger,
            f = a.tracePolicy;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback", "popoverResource", "preloadTrigger", "tracePolicy"]);
        var g = i(function() {
            return c("lazyLoadComponent")(d)
        }, [d]);
        f = c("useCometPopoverInteractionTracing")((f = f) != null ? f : c("tracePolicyFromResource")("comet.popover", d), "lazy", e);
        return h.jsx(c("BasePopoverTrigger.react"), babelHelpers["extends"]({
            fallback: (b = b) != null ? b : h.jsx(c("CometPopoverLoadingState.react"), {
                withArrow: !0
            }),
            interactionTracker: f,
            popover: g,
            popoverPreloadResource: d,
            preloadTrigger: e
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometConfirmationDialog", ["CometDialogLoadingState.react", "react", "requireDeferred", "useCometDeferredDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useCallback,
        j = c("requireDeferred")("CometConfirmationDialogImpl.react").__setRef("useCometConfirmationDialog");

    function k() {
        return h.jsx(c("CometDialogLoadingState.react"), {})
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a() {
        var a = c("useCometDeferredDialog")(j, k);
        return i(function(b, c, d) {
            d === void 0 && (d = function() {}), a(b, function(a) {
                a ? c() : d()
            })
        }, [a])
    }
    g["default"] = a
}), 98);
__d("CometObjectFitContainer.react", ["cr:964538", "react", "stylex", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            inner: {
                height: "x5yr21d",
                position: "x1n2onr6",
                width: "xh8yej3"
            },
            innerWithAspectRatio: {
                bottom: "x1ey2m1c",
                boxSizing: "x9f619",
                end: "xds687c",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy"
            },
            outer: {
                height: "x5yr21d",
                position: "x1n2onr6",
                width: "xh8yej3"
            },
            outerWithAspectRatio: {
                height: "xt7dq6l"
            }
        };

    function j(a) {
        var b = a.children,
            d = a.debugRole;
        d = a.innerInlineStyle;
        var e = a.innerXStyle,
            f = a.outerInlineStyle,
            g = a.outerRef,
            j = a.outerXStyle;
        a = a.testid;
        var k = a != null && a !== "" ? a + "-outer" : void 0;
        k = a != null && a !== "" ? a + "-inner" : void 0;
        return h.jsx("div", babelHelpers["extends"]({}, {}, {
            className: c("stylex")(i.outer, j),
            "data-testid": void 0,
            ref: g,
            style: f,
            children: h.jsx("div", babelHelpers["extends"]({}, {}, {
                className: c("stylex")(i.inner, e),
                "data-testid": void 0,
                style: d,
                children: b
            }))
        }))
    }
    j.displayName = j.name + " [from " + f.id + "]";

    function a(a, b) {
        var d = a.children,
            e = a.contentAspectRatio,
            f = a.debugRole,
            g = a.objectFitMode;
        g = g === void 0 ? "CONTAINER_SIZE" : g;
        a = a.testid;
        a = 16 / 9;
        e = e != null && isFinite(e) && e > 0 ? e : a;
        if (g === "CONTAINER_WIDTH_BASED_ASPECT_RATIO") {
            a = isFinite(e) && e > 0 ? 100 / e : 100;
            e = {
                paddingBottom: a.toFixed(5) + "%"
            };
            return h.jsx(j, {
                children: d,
                debugRole: f,
                innerXStyle: i.innerWithAspectRatio,
                outerInlineStyle: e,
                outerRef: b,
                outerXStyle: i.outerWithAspectRatio,
                testid: void 0
            })
        } else if (g === "CONTAINER_SIZE") return h.jsx(j, {
            children: d,
            debugRole: f,
            outerRef: b,
            testid: void 0
        });
        else throw c("unrecoverableViolation")("Unsupported objectFitMode " + g, "comet_ui")
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("useCometSize_DO_NOT_USE", ["CometThrottle", "ExecutionEnvironment", "HiddenSubtreePassiveContext", "react", "unrecoverableViolation", "useLayoutEffect_SAFE_FOR_SSR", "useResizeObserver", "useStable", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useEffect,
        j = b.useRef,
        k = b.useState;

    function l(a) {
        var b = a.setBoxStateStable,
            d = null,
            e = function(a) {
                var c;
                if (((c = d) == null ? void 0 : c.height) === a.height && ((c = d) == null ? void 0 : c.width) === a.width) return;
                d = a;
                b(a)
            };
        a = function(a) {
            a = a.getBoundingClientRect();
            var b = a.height;
            a = a.width;
            e({
                height: b,
                width: a
            })
        };
        var f = c("CometThrottle")(function(a) {
            var b = a.height;
            a = a.width;
            if (b === 0 && a === 0) return;
            e({
                height: b,
                width: a
            })
        }, 200, {
            leading: !0,
            trailing: !0
        });
        return {
            measure: a,
            onResizeThrottled: f
        }
    }

    function a() {
        if (!c("ExecutionEnvironment").canUseDOM) throw c("unrecoverableViolation")("useCometSize is not compatible with Server Rendering. This will break SSR! See https://fburl.com/wiki/xrzohrqb", "comet_ssr", {}, {
            blameToPreviousFrame: 1
        });
        var a = j(null),
            b = k(null),
            d = b[0],
            e = b[1],
            f = h(c("HiddenSubtreePassiveContext")),
            g = c("useStable")(function() {
                return l({
                    setBoxStateStable: e
                })
            }),
            m = c("useResizeObserver")(g.onResizeThrottled),
            n = j(m);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            n.current = m
        }, [m]);
        b = c("useUnsafeRef_DEPRECATED")(function(b) {
            b !== a.current && (a.current = b, b != null && g.measure(b)), n.current(a.current)
        });
        i(function() {
            if (!f.getCurrentState().hidden) return;
            var b = f.subscribeToChanges(function(c) {
                !c.hidden && a.current != null && (g.measure(a.current), b.remove())
            });
            return function() {
                return b.remove()
            }
        }, [f, g]);
        i(function() {
            return function() {
                g.onResizeThrottled.cancel()
            }
        }, [g]);
        return [b.current, d]
    }
    g["default"] = a
}), 98);
__d("VideoPlayerAudioAvailabilityInfo", ["recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.audioAvailability;
        a = a.mutedSegmentsUnsanitized;
        a = a.map(function(a) {
            return a.muteStartTimeInSec != null && a.muteEndTimeInSec != null && a.muteEndTimeInSec > a.muteStartTimeInSec ? {
                muteEndTimeInSec: a.muteEndTimeInSec,
                muteStartTimeInSec: a.muteStartTimeInSec
            } : null
        }).filter(Boolean);
        return {
            audioAvailability: b,
            mutedSegments: a
        }
    }

    function b(a, b) {
        var d = a.audioAvailability;
        a = a.mutedSegments;
        var e = b.playheadPosition,
            f;
        b = !1;
        var g = !1;
        switch (d) {
            case "AVAILABLE_BUT_MUTED":
                a.length > 0 ? (b = e != null && a.some(function(a) {
                    return a.muteStartTimeInSec <= e && e <= a.muteEndTimeInSec
                }), b ? (f = "VOLUME_COPYRIGHT_PARTIAL_SILENCED", g = !0) : f = "VOLUME_COPYRIGHT_PARTIAL_NOT_SILENCED") : (f = "VOLUME_COPYRIGHT_FULL", g = !0);
                break;
            case "AVAILABLE_BUT_SILENT":
            case "UNAVAILABLE":
                f = "VOLUME_SILENT";
                g = !0;
                break;
            case "AVAILABLE":
            case "UNKNOWN":
            case null:
            case void 0:
                f = "VOLUME_DEFAULT";
                break;
            default:
                c("recoverableViolation")("Unhandled audio availability: " + d, "comet_video_player");
                f = "VOLUME_DEFAULT";
                break
        }
        return {
            isPlayheadWithinMutedSegment: b,
            isSilentAtPlayhead: g,
            volumeControlState: f
        }
    }
    d = a({
        audioAvailability: null,
        mutedSegmentsUnsanitized: []
    });
    g.makeVideoPlayerAudioAvailabilityInfo = a;
    g.makeVideoPlayerAudioAvailabilityAtPlayheadInfo = b;
    g.VideoPlayerAudioAvailabilityInfoDefault = d
}), 98);
__d("VideoPlayerOnViewability.react", ["DOMRectIsEqual", "DOMRectReadOnly", "VideoPlayerViewabilityConstants", "emptyFunction", "react", "useIntersectionObserver", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo,
        k = b.useRef,
        l = 10,
        m = [.25, .75, .99, 1].concat(new Array(10).fill().map(function(a, b) {
            return b / 10
        }));

    function a(a) {
        var b = a.viewportMargins,
            d = k(-1),
            e = k(-1),
            f = k(c("DOMRectReadOnly").fromRect({
                height: 0,
                width: 0,
                x: 0,
                y: 0
            })),
            g = k(null),
            n = k(null);
        b = -b.top + "px " + -b.right + "px " + -b.bottom + "px " + -b.left + "px";
        var o = a.onVideoPlayerViewabilityInfoChange || c("emptyFunction"),
            p = l,
            q = i(function(a) {
                if (a.time > e.current && !c("DOMRectIsEqual")(a.boundingClientRect, f.current)) {
                    var b = a.boundingClientRect,
                        d = b.height,
                        h = b.width,
                        i = b.x;
                    b = b.y;
                    var j = g.current;
                    d = c("DOMRectReadOnly").fromRect({
                        height: d,
                        width: h,
                        x: i,
                        y: b
                    });
                    f.current = d;
                    e.current = a.time;
                    if (j === null || j <= 0) return;
                    if (j <= c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE) return;
                    o({
                        positionToViewport: d,
                        visiblePercentage: j
                    })
                }
            }, [f, g, o]),
            r = i(function(a) {
                if (a.time > d.current && (a.intersectionRatio !== g.current || !c("DOMRectIsEqual")(a.boundingClientRect, f.current))) {
                    var b = a.boundingClientRect,
                        h = b.height,
                        i = b.width,
                        j = b.x;
                    b = b.y;
                    var k = a.intersectionRatio;
                    h = c("DOMRectReadOnly").fromRect({
                        height: h,
                        width: i,
                        x: j,
                        y: b
                    });
                    i = n.current;
                    j = i;
                    b = !1;
                    var l = Math.abs((i || 0) * 100 - (k || 0) * 100);
                    (k !== null && l >= 1 || l > 0 && k < (i || 0)) && (j = k, n.current = k, b = !0);
                    g.current = k;
                    d.current = a.time;
                    l = f.current;
                    f.current = h;
                    e.current = a.time;
                    if (!b && c("DOMRectIsEqual")(l, h)) return;
                    j !== null && o({
                        positionToViewport: h,
                        visiblePercentage: j
                    })
                }
            }, [e, f, g, o, d]),
            s = j(function() {
                var b = [];
                for (var a = 1; a <= p; a++) b.push("-" + (100 - a / p * 100) + "% 0% 0% 0%");
                return b
            }, [p]),
            t = c("useUnsafeRef_DEPRECATED")([]);
        t.current = [];
        for (var u = 0; u < s.length; u++) t.current.push(i(c("useIntersectionObserver")(q, {
            root: null,
            rootMargin: s[u],
            threshold: m
        }), [s[u], m, c("useIntersectionObserver")]));
        var v = t.current.length,
            w = i(function(a) {
                for (var b = 0; b < v; b++) t.current[b](a)
            }, [v, t]),
            x = i(c("useIntersectionObserver")(r, {
                root: null,
                rootMargin: b,
                threshold: m
            }), [r, b, m, c("useIntersectionObserver")]);
        u = i(function(a) {
            x(a), w(a)
        }, [x, w]);
        return h.jsx("div", {
            className: "xh8yej3 x1uhb9sk x5yr21d",
            ref: u,
            children: h.Children.only(a.children)
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerViewabilityContexts", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react").createContext;
    b = a(null);
    c = a(!1);
    e = a(!1);
    f = a(null);
    g.VideoPlayerPassiveViewabilityInfoContext = b;
    g.VideoPlayerDesktopPictureInPictureContext = c;
    g.VideoPlayerFullscreenContext = e;
    g.VideoPlayerExtendedPassiveViewabilityInfoContext = f
}), 98);
__d("computeAspectRatio", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a != null && b != null && a !== 0 && b !== 0 ? a / b : null
    }
    f["default"] = a
}), 66);
__d("VideoPlayerContexts", ["VideoPlayerAudioAvailabilityInfo", "computeAspectRatio", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    e = b.createContext;
    var i = b.useMemo;
    b = e(null);
    var j = e(!1),
        k = e(""),
        l = e(""),
        m = e(null),
        n = e(0),
        o = e(0),
        p = e(!1),
        q = e(!1),
        r = e(!0),
        s = e(!1),
        t = e(!1),
        u = e(null),
        v = e(!1),
        w = e(!1),
        x = e(null),
        y = e(null),
        z = e(null),
        A = e(null),
        B = e([]),
        C = e("notselected"),
        D = e(""),
        E = e(null),
        F = e(!1),
        G = e(!1),
        H = e(null),
        I = e({
            setVolume: function(a) {},
            volume: 1
        }),
        J = e(!1),
        K = e(0),
        L = e(0),
        M = e(null),
        N = e({
            originalAspectRatio: null,
            originalHeight: null,
            originalWidth: null
        });

    function a(a) {
        var b = a.children,
            d = a.originalHeight,
            e = a.originalWidth;
        a = i(function() {
            var a;
            return {
                originalAspectRatio: c("computeAspectRatio")(e, d),
                originalHeight: (a = d) != null ? a : null,
                originalWidth: (a = e) != null ? a : null
            }
        }, [d, e]);
        return h.jsx(N.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    f = e(null);
    var O = e(null),
        P = e(!1),
        Q = e(!1),
        R = e(null),
        S = e("deny"),
        T = e(null),
        U = e("unknown"),
        V = e(!1),
        W = e(!1),
        X = e({
            release: function(a) {},
            reserve: function(a) {
                return a
            }
        }),
        Y = e([]),
        Z = e(!1),
        $ = e(0),
        aa = e(0),
        ba = e(null),
        ca = e(!1);
    d = e(d("VideoPlayerAudioAvailabilityInfo").VideoPlayerAudioAvailabilityInfoDefault);
    var da = e(1),
        ea = e(!1),
        fa = e(!1),
        ga = e(null),
        ha = e("normal");
    e = e([]);
    g.VideoFBIDContext = b;
    g.IsAbrEnabledContext = j;
    g.TargetAudioQualityContext = k;
    g.TargetVideoQualityContext = l;
    g.AdClientTokenContext = m;
    g.LoopCountContext = n;
    g.LoopCurrentContext = o;
    g.PlayingContext = p;
    g.StallingContext = q;
    g.PausedContext = r;
    g.EndedContext = s;
    g.InPlayStallingContext = t;
    g.ErrorContext = u;
    g.IsLiveContext = v;
    g.SeekingContext = w;
    g.ControllerContext = x;
    g.LastMuteReasonContext = y;
    g.LastPlayReasonContext = z;
    g.LastPauseReasonContext = A;
    g.AvailableVideoQualitiesContext = B;
    g.SelectedVideoQualityContext = C;
    g.CurrentVideoQualityContext = D;
    g.ActiveCaptionsContext = E;
    g.CaptionsVisibleContext = F;
    g.CaptionsLoadedContext = G;
    g.CaptionDisplayStyleContext = H;
    g.VolumeContext = I;
    g.MutedContext = J;
    g.DurationContext = K;
    g.BufferEndContext = L;
    g.InstanceKeyContext = M;
    g.VideoOriginalDimensionsContext = N;
    g.VideoOriginalDimensionsContextMemoProvider = a;
    g.DimensionsContext = f;
    g.PlayerImplementationNameContext = O;
    g.VideoPlayerMouseHoverContext = P;
    g.VideoPlayerMouseIdleContext = Q;
    g.BroadcastStatusContext = R;
    g.CanAutoplayContext = S;
    g.VolumeSettingContext = T;
    g.AutoplayGatingResultContext = U;
    g.InbandCaptionsAutogeneratedContext = V;
    g.IsExternalMediaContext = W;
    g.VideoPlayerCaptionsReservationActionsContext = X;
    g.VideoPlayerCaptionsReservationsContext = Y;
    g.StreamInterruptedContext = Z;
    g.WatchTimeContext = $;
    g.LastPlayedTimeContext = aa;
    g.SeekableRangesContext = ba;
    g.IsLiveRewindActiveContext = ca;
    g.AudioAvailabilityInfoContext = d;
    g.PlaybackRateContext = da;
    g.IsNCSRContext = ea;
    g.IsPremiumMusicVideoContext = fa;
    g.InitialTracePolicyContext = ga;
    g.LatencyLevelContext = ha;
    g.ActiveEmsgBoxesContext = e
}), 98);
__d("VideoPlayerHooks", ["DOMRectIsEqual", "VideoPlayerContexts", "VideoPlayerViewabilityContexts", "clearTimeout", "qex", "react", "removeFromArray", "setTimeout", "unrecoverableViolation", "useLayoutEffect_SAFE_FOR_SSR", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = h.useContext,
        j = h.useEffect,
        k = h.useRef,
        l = h.useState,
        m = c("qex")._("109") ? j : c("useLayoutEffect_SAFE_FOR_SSR");

    function a(a) {
        var b = k(a);
        m(function() {
            b.current = a
        }, [a]);
        return b
    }

    function n() {
        var a = i(d("VideoPlayerContexts").ControllerContext);
        if (a == null) throw c("unrecoverableViolation")("Empty ControllerContext. Are you rendering useController outside of VideoPlayerRelay/VideoPlayerX?", "comet_video_player");
        return a
    }

    function b() {
        var a = i(d("VideoPlayerContexts").InstanceKeyContext);
        if (a == null) throw c("unrecoverableViolation")("Empty InstanceKeyContext. Are you rendering useInstanceKey outside of VideoPlayerRelay/VideoPlayerX?", "comet_video_player");
        return a
    }

    function o() {
        var a = T();
        return a === "LIVE"
    }

    function e() {
        var a = T();
        return a === "LIVE" || a === "VOD_READY"
    }

    function f() {
        return i(d("VideoPlayerContexts").BufferEndContext)
    }

    function p() {
        return i(d("VideoPlayerContexts").DurationContext)
    }

    function q() {
        return i(d("VideoPlayerContexts").SeekingContext)
    }

    function r() {
        return i(d("VideoPlayerContexts").EndedContext)
    }

    function s() {
        return i(d("VideoPlayerContexts").ErrorContext)
    }

    function t() {
        return i(d("VideoPlayerContexts").PlayingContext)
    }

    function u() {
        var a = l(0),
            b = a[0],
            c = a[1],
            d = n();
        j(function() {
            var a = d.subscribe(function() {
                c(d.getPlayheadPosition())
            });
            c(d.getPlayheadPosition());
            return function() {
                return a.remove()
            }
        }, [d]);
        return b
    }

    function v(a, b) {
        var d = l(0),
            e = d[0],
            f = d[1],
            g = n(),
            h = k(null),
            i = k(e);
        j(function() {
            var d = g.subscribe(function() {
                i.current = b ? b(g) : g.getPlayheadPosition();
                if (h.current != null) return;
                h.current = c("setTimeout")(function() {
                    f(i.current), h.current = null
                }, a)
            });
            f(g.getPlayheadPosition());
            return d.remove
        }, [g, a]);
        j(function() {
            return function() {
                h.current !== null && (c("clearTimeout")(h.current), h.current = null)
            }
        }, []);
        return e
    }

    function w(a) {
        a === void 0 && (a = 200);
        var b = l(0),
            d = b[0],
            e = b[1],
            f = n(),
            g = o(),
            h = k(null),
            i = k(d);
        j(function() {
            if (!g) return;
            var b = f.subscribe(function() {
                if (h.current != null) return;
                h.current = c("setTimeout")(function() {
                    f.getCurrentState().paused || (i.current += a / 1e3, e(i.current)), h.current = null
                }, a)
            });
            e(0);
            return function() {
                return b.remove()
            }
        }, [f, a, g]);
        j(function() {
            return function() {
                h.current !== null && (c("clearTimeout")(h.current), h.current = null)
            }
        }, []);
        return !g ? null : d
    }

    function x() {
        var a = n(),
            b = k([]),
            d = k(a.isFrozen()),
            e = c("useStable")(function() {
                return {
                    getCurrentState: function() {
                        return a.isFrozen()
                    },
                    subscribeToChanges: function(a) {
                        var d = b.current;
                        d.push(a);
                        return {
                            remove: function() {
                                return c("removeFromArray")(d, a)
                            }
                        }
                    }
                }
            });
        j(function() {
            var c = a.subscribe(function() {
                var c = d.current,
                    e = a.isFrozen();
                d.current = e;
                if (e !== c) {
                    c = b.current;
                    c.forEach(function(a) {
                        return a(e)
                    })
                }
            });
            return function() {
                c.remove()
            }
        }, [a]);
        return e
    }

    function y() {
        return i(d("VideoPlayerContexts").WatchTimeContext)
    }

    function z() {
        return i(d("VideoPlayerContexts").LastPlayedTimeContext)
    }

    function A() {
        return i(d("VideoPlayerContexts").PausedContext)
    }

    function B() {
        return i(d("VideoPlayerContexts").StallingContext)
    }

    function C() {
        return i(d("VideoPlayerContexts").InPlayStallingContext)
    }

    function D() {
        return i(d("VideoPlayerContexts").LastMuteReasonContext)
    }

    function E() {
        return i(d("VideoPlayerContexts").LastPauseReasonContext)
    }

    function F() {
        return i(d("VideoPlayerContexts").LastPlayReasonContext)
    }

    function G() {
        return i(d("VideoPlayerContexts").AvailableVideoQualitiesContext)
    }

    function H() {
        return i(d("VideoPlayerContexts").CaptionsVisibleContext)
    }

    function I() {
        return i(d("VideoPlayerContexts").CaptionDisplayStyleContext)
    }

    function J() {
        return i(d("VideoPlayerContexts").ActiveCaptionsContext)
    }

    function K() {
        return i(d("VideoPlayerContexts").CurrentVideoQualityContext)
    }

    function L() {
        return i(d("VideoPlayerContexts").SelectedVideoQualityContext)
    }

    function M() {
        return i(d("VideoPlayerContexts").MutedContext)
    }

    function N() {
        return i(d("VideoPlayerContexts").VolumeContext).volume
    }

    function O() {
        return i(d("VideoPlayerContexts").VolumeContext).setVolume
    }

    function P() {
        return i(d("VideoPlayerViewabilityContexts").VideoPlayerDesktopPictureInPictureContext)
    }

    function Q() {
        return i(d("VideoPlayerViewabilityContexts").VideoPlayerFullscreenContext)
    }

    function R() {
        return i(d("VideoPlayerContexts").DimensionsContext)
    }

    function aa() {
        return i(d("VideoPlayerContexts").VideoOriginalDimensionsContext)
    }

    function ba() {
        return i(d("VideoPlayerContexts").PlayerImplementationNameContext)
    }

    function ca() {
        return i(d("VideoPlayerContexts").CaptionsLoadedContext)
    }

    function da() {
        return i(d("VideoPlayerContexts").IsAbrEnabledContext)
    }

    function ea() {
        return i(d("VideoPlayerContexts").TargetVideoQualityContext)
    }

    function fa() {
        return i(d("VideoPlayerContexts").TargetAudioQualityContext)
    }

    function ga() {
        return i(d("VideoPlayerContexts").VideoPlayerMouseHoverContext)
    }

    function ha() {
        return i(d("VideoPlayerContexts").VideoPlayerMouseIdleContext)
    }

    function S() {
        return i(d("VideoPlayerViewabilityContexts").VideoPlayerPassiveViewabilityInfoContext)
    }

    function ia() {
        return i(d("VideoPlayerViewabilityContexts").VideoPlayerExtendedPassiveViewabilityInfoContext)
    }

    function ja() {
        var a = S(),
            b = l(null),
            d = b[0],
            e = b[1],
            f = k(d);
        j(function() {
            f.current = d
        }, [d]);
        m(function() {
            if (a) {
                var b = function() {
                        var b = a.getCurrent();
                        if (b) {
                            var d = b.positionToViewport;
                            b = b.visiblePercentage;
                            var g = f.current;
                            (g == null || b !== g.visiblePercentage || !c("DOMRectIsEqual")(d, g.positionToViewport)) && e({
                                positionToViewport: d,
                                visiblePercentage: b
                            })
                        }
                    },
                    d = a.subscribe(function() {
                        b()
                    });
                return function() {
                    return d.remove()
                }
            }
        }, [e, a]);
        return d
    }

    function T() {
        return i(d("VideoPlayerContexts").BroadcastStatusContext)
    }

    function ka() {
        return i(d("VideoPlayerContexts").CanAutoplayContext)
    }

    function la() {
        return i(d("VideoPlayerContexts").VolumeSettingContext)
    }

    function ma() {
        return i(d("VideoPlayerContexts").AutoplayGatingResultContext)
    }

    function na() {
        return i(d("VideoPlayerContexts").VideoFBIDContext)
    }

    function U() {
        return i(d("VideoPlayerContexts").AdClientTokenContext)
    }

    function V() {
        return i(d("VideoPlayerContexts").LoopCurrentContext)
    }

    function W() {
        return i(d("VideoPlayerContexts").LoopCountContext)
    }

    function oa() {
        return i(d("VideoPlayerContexts").InbandCaptionsAutogeneratedContext)
    }

    function pa() {
        return i(d("VideoPlayerContexts").IsExternalMediaContext)
    }

    function qa() {
        return i(d("VideoPlayerContexts").VideoPlayerCaptionsReservationsContext)
    }

    function ra() {
        return i(d("VideoPlayerContexts").VideoPlayerCaptionsReservationActionsContext)
    }

    function sa() {
        return i(d("VideoPlayerContexts").StreamInterruptedContext)
    }

    function ta() {
        return i(d("VideoPlayerContexts").SeekableRangesContext)
    }

    function X() {
        return i(d("VideoPlayerContexts").IsLiveRewindActiveContext)
    }

    function Y() {
        var a = r(),
            b = V(),
            c = W();
        a = a && (c === -1 || c > 0 && b < c);
        return a
    }

    function ua() {
        var a = r(),
            b = Y();
        return a && !b
    }

    function va() {
        return i(d("VideoPlayerContexts").PlaybackRateContext)
    }

    function wa() {
        return i(d("VideoPlayerContexts").IsNCSRContext)
    }

    function Z() {
        return i(d("VideoPlayerContexts").IsPremiumMusicVideoContext)
    }

    function xa() {
        var a = U() != null,
            b = o(),
            c = Z(),
            d = X();
        if (a || c) return !1;
        if (b) return d;
        else return !0
    }

    function ya() {
        return i(d("VideoPlayerContexts").InitialTracePolicyContext)
    }

    function za() {
        return i(d("VideoPlayerContexts").LatencyLevelContext)
    }

    function Aa() {
        return i(d("VideoPlayerContexts").AudioAvailabilityInfoContext)
    }

    function Ba() {
        var a = U() != null,
            b = o(),
            c = Z();
        return a || c || b ? !1 : !0
    }

    function $(a) {
        a === void 0 && (a = !0);
        var b = n();
        j(function() {
            if (a) {
                var c = b.registerEmsgObserver();
                return function() {
                    b.unregisterEmsgObserver(c)
                }
            }
        }, [b, a])
    }

    function Ca() {
        $();
        return i(d("VideoPlayerContexts").ActiveEmsgBoxesContext)
    }
    g.useLatestValueRef = a;
    g.useController = n;
    g.useInstanceKey = b;
    g.useIsLive = o;
    g.useIsVideoBroadcast = e;
    g.useBufferEnd = f;
    g.useDuration = p;
    g.useSeeking = q;
    g.useEnded = r;
    g.useError = s;
    g.usePlaying = t;
    g.useCurrentTime_DO_NOT_USE = u;
    g.useCurrentTimeThrottled = v;
    g.useLiveTimeElapsedThrottled = w;
    g.useIsFrozenPassive = x;
    g.useWatchTime = y;
    g.useLastPlayedTime = z;
    g.usePaused = A;
    g.useStalling = B;
    g.useInPlayStalling = C;
    g.useLastMuteReason = D;
    g.useLastPauseReason = E;
    g.useLastPlayReason = F;
    g.useAvailableVideoQualities = G;
    g.useCaptionsVisible = H;
    g.useCaptionDisplayStyle = I;
    g.useActiveCaptions = J;
    g.useCurrentVideoQuality = K;
    g.useSelectedVideoQuality = L;
    g.useMuted = M;
    g.useVolume = N;
    g.useSetVolume = O;
    g.useIsDesktopPictureInPicture = P;
    g.useIsFullscreen = Q;
    g.useDimensions = R;
    g.useVideoOriginalDimensions = aa;
    g.usePlayerImplementationName = ba;
    g.useCaptionsLoaded = ca;
    g.useIsAbrEnabled = da;
    g.useTargetVideoQuality = ea;
    g.useTargetAudioQuality = fa;
    g.useIsHovering = ga;
    g.useIsMouseIdle = ha;
    g.useVideoPlayerPassiveViewabilityInfo = S;
    g.useVideoPlayerExtendedPassiveViewabilityInfo = ia;
    g.useVideoPlayerViewabilityInfo = ja;
    g.useBroadcastStatus = T;
    g.useCanAutoplay = ka;
    g.useVolumeSetting = la;
    g.useAutoplayGatingResult = ma;
    g.useVideoFbid = na;
    g.useAdClientToken = U;
    g.useVideoPlayerCurrentLoop = V;
    g.useVideoPlayerTotalLoops = W;
    g.useInbandCaptionsAutogenerated = oa;
    g.useIsExternalMedia = pa;
    g.useVideoPlayerCaptionsReservations = qa;
    g.useVideoPlayerCaptionsReservationActions = ra;
    g.useStreamInterrupted = sa;
    g.useSeekableRanges_DO_NOT_USE = ta;
    g.useIsLiveRewindActive = X;
    g.useIsTransitioningToNextLoop = Y;
    g.useVideoPlaybackEnded = ua;
    g.usePlaybackRate = va;
    g.useIsNCSR = wa;
    g.useIsPremiumMusicVideo = Z;
    g.useShouldShowPlaybackRateControl = xa;
    g.useVideoPlayerInitialTracePolicy = ya;
    g.useLatencyLevel = za;
    g.useAudioAvailabilityInfo = Aa;
    g.useShouldPersistPlaybackRate = Ba;
    g.useEmsgObserver = $;
    g.useActiveEmsgBoxes = Ca
}), 98);
__d("createVideoStateHook", ["VideoPlayerHooks", "gkx", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useEffect,
        i = e.useRef,
        j = e.useState,
        k = new Set();

    function a(a) {
        var b = new Map();
        k.add(b);

        function e() {
            var a = d("VideoPlayerHooks").useInstanceKey();
            b.has(a) || b.set(a, {
                consumers: new Set(),
                key: a,
                lastValue: void 0
            });
            var e = b.get(a);
            if (e == null) throw c("unrecoverableViolation")('createVideoStateHook useInstance missing instance by key "' + a + '"', "comet_video_player");
            return e
        }

        function f(a, b) {
            a.consumers.add(b)
        }

        function g(a, b) {
            a.consumers["delete"](b)
        }

        function l(a, b, c) {
            a.lastValue = b, a.consumers.forEach(function(a) {
                c !== a && a(b)
            })
        }

        function m(a) {
            var b = e(),
                c = i(b);
            c.current = b;
            a = b.lastValue != null ? b.lastValue : a;
            var d = i(a);
            d.current = a;
            a = j(a);
            var k = a[0],
                m = a[1];
            h(function() {
                m(d.current);
                f(b, m);
                return function() {
                    g(b, m)
                }
            }, [b]);
            h(function() {
                l(c.current, k, m)
            }, [k]);
            return [k, m]
        }

        function a(a) {
            a = m(a);
            a[0];
            a = a[1];
            return a
        }

        function n(a) {
            a = m(a);
            var b = a[0];
            a[1];
            return b
        }
        return {
            setterHook: a,
            stateHook: m,
            valueHook: n
        }
    }

    function b(a) {
        h(function() {
            return function() {
                k.forEach(function(b) {
                    b["delete"](a)
                })
            }
        }, [a])
    }
    f = b;
    g.createVideoStateHook = a;
    g.useCleanupVideoStateHooks_INTERNAL = f
}), 98);
__d("renderVideoPlayerImplementation", ["react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        if (a.typename === "VideoPlayerMockImplementation") return h.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else if (a.typename === "VideoPlayerOzImplementation") return h.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else if (a.typename === "VideoPlayerProgressiveImplementation") return h.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else if (a.typename === "VideoPlayerShakaImplementation") return h.jsx(a.Component, babelHelpers["extends"]({}, b, a.data));
        else throw c("unrecoverableViolation")('CoreVideoPlayer: Unrecognized implementation typename "' + a.typename + '".', "comet_video_player")
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCreateVideoPlayerPassiveViewabilityInfo", ["DOMRectReadOnly", "react", "removeFromArray"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useState;

    function a() {
        var a = h(function() {
            var a = [],
                b = {
                    positionToViewport: c("DOMRectReadOnly").fromRect({
                        height: 0,
                        width: 0,
                        x: 0,
                        y: 0
                    }),
                    visiblePercentage: 0
                };
            b = null;
            return {
                setVideoPlayerPassiveViewabilityInfo: function(c) {
                    b = c, a.forEach(function(a) {
                        return a()
                    })
                },
                videoPlayerPassiveViewabilityInfo: {
                    getCurrent: function() {
                        return b
                    },
                    subscribe: function(b) {
                        a.push(b);
                        return {
                            remove: function() {
                                c("removeFromArray")(a, b)
                            }
                        }
                    }
                }
            }
        });
        a = a[0];
        var b = a.setVideoPlayerPassiveViewabilityInfo;
        a = a.videoPlayerPassiveViewabilityInfo;
        return {
            setVideoPlayerPassiveViewabilityInfo: b,
            videoPlayerPassiveViewabilityInfo: a
        }
    }
    g["default"] = a
}), 98);
__d("videoPlayerUniqueID", ["guid"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return "id-vpuid-" + c("guid")()
    }
    g["default"] = a
}), 98);
__d("CoreVideoPlayer.react", ["CometObjectFitContainer.react", "ErrorMetadata", "VideoPlayerAudioAvailabilityInfo", "VideoPlayerOnViewability.react", "VideoPlayerViewabilityContexts", "createVideoStateHook", "err", "gkx", "react", "renderVideoPlayerImplementation", "unrecoverableViolation", "useCometSize_DO_NOT_USE", "useCreateVideoPlayerPassiveViewabilityInfo", "videoPlayerUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useRef,
        k = b.useState,
        l = 584;

    function m(a) {
        return a != null && isFinite(a) && a > 0 ? a : 0
    }

    function n(a) {
        if (a === "video_home_inline" || a === "inline") return {
            height: l,
            width: l
        };
        else return {
            height: 1080,
            width: 1920
        }
    }
    var o = function(a) {
        var b = c("useCometSize_DO_NOT_USE")(),
            d = b[0];
        b = b[1];
        b = (b = b) != null ? b : n(a);
        return [b, function(a) {
            return h.jsx(c("CometObjectFitContainer.react"), {
                debugRole: null,
                objectFitMode: "CONTAINER_SIZE",
                ref: d,
                children: a
            })
        }]
    };

    function a(a) {
        var b = a.accessToken,
            e = a.expiredVideoUrlRefreshHandler,
            f = a.fullscreenController,
            g = a.implementations,
            l = a.isFullscreen,
            n = a.onCoreVideoStatesChanged,
            p = a.productAttribution,
            q = a.renderWithCoreVideoStates,
            r = a.trackingDataEncrypted,
            s = a.trackingNodes,
            t = a.viewportMarginsForViewability,
            u = babelHelpers.objectWithoutPropertiesLoose(a, ["accessToken", "expiredVideoUrlRefreshHandler", "fullscreenController", "implementations", "isFullscreen", "onCoreVideoStatesChanged", "productAttribution", "renderWithCoreVideoStates", "trackingDataEncrypted", "trackingNodes", "viewportMarginsForViewability"]);
        a = k(function() {
            return c("videoPlayerUniqueID")()
        });
        var v = a[0];
        d("createVideoStateHook").useCleanupVideoStateHooks_INTERNAL(v);
        a = j(0);
        var w = c("useCreateVideoPlayerPassiveViewabilityInfo")(),
            x = w.setVideoPlayerPassiveViewabilityInfo,
            y = w.videoPlayerPassiveViewabilityInfo;
        w = o(u.subOrigin);
        var z = w[0];
        w = w[1];
        var A = i(function(a) {
                x(a)
            }, [x]),
            B = i(function(a) {
                var b, c = a.implementationController;
                a = a.implementationExposedState;
                b = {
                    adClientToken: u.adClientToken,
                    audioAvailabilityInfo: (b = u.audioAvailabilityInfo) != null ? b : d("VideoPlayerAudioAvailabilityInfo").VideoPlayerAudioAvailabilityInfoDefault,
                    autoplayGatingResult: u.autoplayGatingResult != null ? u.autoplayGatingResult : "unknown",
                    autoplaySetting: u.autoplaySetting,
                    broadcastStatus: u.broadcastStatus,
                    canAutoplay: u.canAutoplay != null ? u.canAutoplay : "allow",
                    controller: c,
                    dimensions: z,
                    duration: a.duration,
                    initialTracePolicy: u.initialTracePolicy,
                    instanceKey: v,
                    isDesktopPictureInPicture: a.isDesktopPictureInPicture,
                    isFullscreen: l,
                    isNCSR: Boolean(u.isNCSR),
                    isPremiumMusicVideo: Boolean(u.isPremiumMusicVideo),
                    lastMuteReason: a.lastMuteReason,
                    lastPauseReason: a.lastPauseReason,
                    lastPlayReason: a.lastPlayReason,
                    loopCount: a.loopCount,
                    loopCurrent: a.loopCurrent,
                    originalHeight: u.originalHeight,
                    originalWidth: u.originalWidth,
                    videoFBID: u.videoFBID,
                    videoPlayerPassiveViewabilityInfo: y,
                    videoState: a,
                    volumeSetting: u.volumeSetting
                };
                n && n(b);
                return q(b)
            }, [u.adClientToken, u.audioAvailabilityInfo, u.autoplayGatingResult, u.autoplaySetting, u.broadcastStatus, u.canAutoplay, u.initialTracePolicy, u.isNCSR, u.isPremiumMusicVideo, u.originalHeight, u.originalWidth, u.videoFBID, u.volumeSetting, z, v, l, y, n, q]);
        b = {
            accessToken: b,
            coreVideoPlayerMetaData: u,
            dimensions: z,
            instanceKey: v,
            playerImplementationInstanceCountRef: a,
            productAttribution: p,
            trackingDataEncrypted: r,
            trackingNodes: s
        };
        if (g.length === 0) {
            if (!c("gkx")("1611172")) return null;
            a = c("err")("No implementations given to CoreVideoPlayer");
            a.metadata = new(c("ErrorMetadata"))();
            a.metadata.addEntry("COMET_VIDEO", "VIDEO_ID", String(u.videoFBID));
            throw c("unrecoverableViolation")("No implementations given to CoreVideoPlayer", "comet_video_player", {
                error: a
            })
        }
        p = Boolean(u.captionsUrl);
        r = Boolean(u.isLiveStreaming);
        e = {
            VideoPlayerShakaPerformanceLoggerClass: u.VideoPlayerShakaPerformanceLoggerClass,
            alt: u.alt,
            alwaysShowCaptions: u.alwaysShowCaptions,
            areCaptionsAutogenerated: u.areCaptionsAutogenerated,
            audioOnly: u.audioOnly,
            broadcastLatencySensitivity: u.broadcastLatencySensitivity,
            bufferEndLimit: u.bufferEndLimit,
            captionDisplayStyle: u.captionDisplayStyle,
            captionsUrl: u.captionsUrl,
            dimensions: z,
            disableLogging: u.disableLogging === !0,
            expiredVideoUrlRefreshHandler: e,
            fullscreenController: f,
            graphQLVideoDRMInfo: (s = u.graphQLVideoDRMInfo) != null ? s : null,
            graphQLVideoP2PSettings: (a = u.graphQLVideoP2PSettings) != null ? a : null,
            inbandCaptionsExpected: r,
            initialDesiredLatencyMs: u.desiredLatencyMs,
            initialLatencyToleranceMs: u.latencyToleranceMs,
            initialRepresentationIds: u.initialRepresentationIds,
            isClientTriggeredTraceEnabled: u.isClientTriggeredTraceEnabled,
            loadSequence: u.loadSequence,
            loggingMetaData: b,
            loopCount: u.loopCount,
            preloadForProgressiveDisabled: u.preloadForProgressiveDisabled,
            renderWithExposedState: B,
            seoWebCrawlerVideoTracks: u.seoWebCrawlerVideoTracks,
            sideLoadCaptionsExpected: p,
            startTimestamp: m(u.startTimestamp),
            videoFBID: u.videoFBID,
            videoPlayerPassiveViewabilityInfo: y,
            videoPlayerShakaPerformanceLoggerBuilder: u.videoPlayerShakaPerformanceLoggerBuilder,
            wrapVideoPixels_EXPERIMENTAL: u.wrapVideoPixels_EXPERIMENTAL
        };
        f = g[0];
        s = c("renderVideoPlayerImplementation")(f, e);
        s != null && (s = h.jsx(d("VideoPlayerViewabilityContexts").VideoPlayerFullscreenContext.Provider, {
            value: l,
            children: h.jsx(c("VideoPlayerOnViewability.react"), {
                onVideoPlayerViewabilityInfoChange: A,
                viewportMargins: t,
                children: s
            })
        }));
        return w(s)
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CoreVideoPlayerFitParentContainer.react", ["DOMContainer.react", "cr:964538", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = h.forwardRef(function(a, b) {
        var c = a.children;
        a = a.debugRole;
        return h.jsx("div", babelHelpers["extends"]({}, null, {
            className: "xh8yej3 x1n2onr6 x5yr21d x1lliihq x1ja2u2z",
            ref: b,
            children: c
        }))
    });
    e = h.forwardRef(function(a, b) {
        var d = a.debugRole;
        d = a.domElement;
        return h.jsx(c("DOMContainer.react"), babelHelpers["extends"]({}, null, {
            className: "xh8yej3 x1n2onr6 x5yr21d x1lliihq x1ja2u2z",
            display: "block",
            ref: b,
            children: d
        }))
    });

    function a(a) {
        a = a.debugRole;
        a = document.createElement("div");
        a.className = "xh8yej3 x1n2onr6 x5yr21d x1lliihq x1ja2u2z";
        return a
    }
    g.CoreVideoPlayerFitParentContainer = b;
    g.CoreVideoPlayerFitParentDOMContainer = e;
    g.createFitParentContainerDiv = a
}), 98);
__d("VideoPlayerPortalingPlaceInfoProvider.react", ["emptyFunction", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    d = e.createContext;
    var i = e.useContext,
        j = e.useEffect,
        k = e.useMemo,
        l = d(null);

    function a(a) {
        var b = a.children,
            c = a.currentPlaceID,
            d = a.currentVideoID,
            e = a.portalingEnabled,
            f = a.previousPlaceMetaData,
            g = a.thisPlaceID;
        a = k(function() {
            return {
                currentPlaceID: c,
                currentVideoID: d,
                portalingEnabled: e,
                previousPlaceMetaData: f,
                thisPlaceID: g
            }
        }, [c, d, e, f, g]);
        return h.jsx(l.Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var m = c("emptyFunction");

    function b() {
        var a = i(l);
        m(a);
        return a == null ? {
            currentPlaceID: null,
            currentVideoID: null,
            portalingEnabled: !1,
            previousPlaceMetaData: null,
            thisPlaceID: null
        } : a
    }
    g.VideoPlayerPortalingPlaceInfoProvider = a;
    g.useVideoPlayerPortalingPlaceInfo = b
}), 98);
__d("GlobalVideoPortsRenderers.react", ["CoreVideoPlayer.react", "VideoPlayerContexts", "VideoPlayerPortalingPlaceInfoProvider.react", "emptyFunction", "qex", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react"),
        j = i.useEffect,
        k = i.useLayoutEffect,
        l = i.useState,
        m = c("qex")._("109") ? j : k,
        n = c("emptyFunction").thatReturns(null);

    function a(a) {
        var b = a.coreVideoPlayerMetaData,
            e = a.currentPlaceID,
            f = a.currentVideoID,
            g = a.fullscreenController,
            i = a.implementations,
            j = a.isFullscreen,
            k = a.onCoreVideoStatesChanged,
            l = a.previousPlaceMetaData,
            m = a.trackingDataEncrypted,
            o = a.trackingNodes;
        a = a.viewportMarginsForViewability;
        var p = n;
        return h.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
            currentPlaceID: e,
            currentVideoID: f,
            portalingEnabled: !0,
            previousPlaceMetaData: l,
            thisPlaceID: e,
            children: h.jsx(c("CoreVideoPlayer.react"), babelHelpers["extends"]({}, b, {
                fullscreenController: g,
                implementations: i,
                isFullscreen: j,
                onCoreVideoStatesChanged: k,
                renderWithCoreVideoStates: p,
                trackingDataEncrypted: m,
                trackingNodes: o,
                viewportMarginsForViewability: a
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = a.currentPlaceID,
            c = a.currentVideoID,
            e = a.originalHeight,
            f = a.originalWidth,
            g = a.previousPlaceMetaData,
            i = a.renderPlaceholder;
        a = a.thisPlaceID;
        return h.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
            currentPlaceID: b,
            currentVideoID: c,
            portalingEnabled: !0,
            previousPlaceMetaData: g,
            thisPlaceID: a,
            children: h.jsx(d("VideoPlayerContexts").VideoOriginalDimensionsContextMemoProvider, {
                originalHeight: e,
                originalWidth: f,
                children: i != null ? i() : null
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function e(a) {
        var b = a.currentPlaceID,
            c = a.currentVideoID,
            e = a.injectCoreVideoStatesRef,
            f = a.previousPlaceMetaData,
            g = a.renderComponents;
        a = a.thisPlaceID;
        var i = l(null),
            j = i[0],
            k = i[1];
        i = l(null);
        var n = i[0],
            o = i[1];
        m(function() {
            e.current = function(a, b) {
                a != null && o(function() {
                    return a
                }), k(b)
            };
            return function() {
                e.current = null
            }
        }, [e]);
        if (a === b && j != null) {
            if (n != null) throw n;
            return h.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
                currentPlaceID: b,
                currentVideoID: c,
                portalingEnabled: !0,
                previousPlaceMetaData: f,
                thisPlaceID: a,
                children: g(j)
            })
        } else return null
    }
    e.displayName = e.name + " [from " + f.id + "]";
    g.GlobalVideoPortsPlayerRenderer = a;
    g.GlobalVideoPortsPlaceholderRenderer = b;
    g.GlobalVideoPortsVideoComponentsRenderer = e
}), 98);
__d("useSubscriptionValue", ["React"], (function(a, b, c, d, e, f, g) {
    b = d("React");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useState;

    function a(a) {
        var b = a.getCurrentValue,
            c = a.subscribe;
        a = j(function() {
            return b()
        });
        var d = a[0],
            e = a[1],
            f = h(function() {
                e(b)
            }, [b]);
        a = j(function() {
            return b
        });
        var g = a[0];
        a = a[1];
        g !== b && (a(function() {
            return b
        }), f());
        i(function() {
            var a = !1,
                b = function() {
                    a || f()
                },
                d = c(b);
            f();
            return function() {
                a = !0, d()
            }
        }, [f, c]);
        return d
    }
    g["default"] = a
}), 98);
__d("UnicodeBidiDirection", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = "NEUTRAL";
    var h = "LTR",
        i = "RTL";

    function j(a) {
        return a === h || a === i
    }

    function k(a) {
        if (!j(a)) throw c("unrecoverableViolation")("`dir` must be a strong direction to be converted to HTML Direction", "internationalization");
        return a === h ? "ltr" : "rtl"
    }

    function a(a, b) {
        if (!j(a)) throw c("unrecoverableViolation")("`dir` must be a strong direction to be converted to HTML Direction", "internationalization");
        if (!j(b)) throw c("unrecoverableViolation")("`otherDir` must be a strong direction to be converted to HTML Direction", "internationalization");
        return a === b ? null : k(a)
    }
    g.NEUTRAL = b;
    g.LTR = h;
    g.RTL = i;
    g.isStrong = j;
    g.getHTMLDir = k;
    g.getHTMLDirIfDifferent = a
}), 98);
__d("UnicodeBidiGlobalDirectionCore", ["UnicodeBidiDirection", "unrecoverableViolation"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function h(a) {
        g = a
    }

    function a() {
        h(b("UnicodeBidiDirection").LTR)
    }

    function c() {
        g || this.initDir();
        if (!g) throw b("unrecoverableViolation")("Global direction not set.", "internationalization");
        return g
    }
    d = {
        setDir: h,
        initDir: a,
        getDir: c
    };
    e.exports = d
}), null);
__d("UnicodeBidiGlobalDirection", ["Locale", "UnicodeBidiDirection", "UnicodeBidiGlobalDirectionCore"], (function(a, b, c, d, e, f) {
    "use strict";
    b("UnicodeBidiGlobalDirectionCore").initDir = function() {
        b("UnicodeBidiGlobalDirectionCore").setDir(b("Locale").isRTL() ? b("UnicodeBidiDirection").RTL : b("UnicodeBidiDirection").LTR)
    }, e.exports = b("UnicodeBidiGlobalDirectionCore")
}), null);
__d("UnicodeBidi", ["UnicodeBidiDirection", "UnicodeBidiGlobalDirection", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = {
        L: "A-Za-z\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02b8\u02bb-\u02c1\u02d0\u02d1\u02e0-\u02e4\u02ee\u0370-\u0373\u0376\u0377\u037a-\u037d\u037f\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0482\u048a-\u052f\u0531-\u0556\u0559-\u055f\u0561-\u0587\u0589\u0903-\u0939\u093b\u093d-\u0940\u0949-\u094c\u094e-\u0950\u0958-\u0961\u0964-\u0980\u0982\u0983\u0985-\u098c\u098f\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd-\u09c0\u09c7\u09c8\u09cb\u09cc\u09ce\u09d7\u09dc\u09dd\u09df-\u09e1\u09e6-\u09f1\u09f4-\u09fa\u0a03\u0a05-\u0a0a\u0a0f\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32\u0a33\u0a35\u0a36\u0a38\u0a39\u0a3e-\u0a40\u0a59-\u0a5c\u0a5e\u0a66-\u0a6f\u0a72-\u0a74\u0a83\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2\u0ab3\u0ab5-\u0ab9\u0abd-\u0ac0\u0ac9\u0acb\u0acc\u0ad0\u0ae0\u0ae1\u0ae6-\u0af0\u0b02\u0b03\u0b05-\u0b0c\u0b0f\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32\u0b33\u0b35-\u0b39\u0b3d\u0b3e\u0b40\u0b47\u0b48\u0b4b\u0b4c\u0b57\u0b5c\u0b5d\u0b5f-\u0b61\u0b66-\u0b77\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99\u0b9a\u0b9c\u0b9e\u0b9f\u0ba3\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bbe\u0bbf\u0bc1\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcc\u0bd0\u0bd7\u0be6-\u0bf2\u0c01-\u0c03\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d\u0c41-\u0c44\u0c58\u0c59\u0c60\u0c61\u0c66-\u0c6f\u0c7f\u0c82\u0c83\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd-\u0cc4\u0cc6-\u0cc8\u0cca\u0ccb\u0cd5\u0cd6\u0cde\u0ce0\u0ce1\u0ce6-\u0cef\u0cf1\u0cf2\u0d02\u0d03\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d-\u0d40\u0d46-\u0d48\u0d4a-\u0d4c\u0d4e\u0d57\u0d60\u0d61\u0d66-\u0d75\u0d79-\u0d7f\u0d82\u0d83\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0dcf-\u0dd1\u0dd8-\u0ddf\u0de6-\u0def\u0df2-\u0df4\u0e01-\u0e30\u0e32\u0e33\u0e40-\u0e46\u0e4f-\u0e5b\u0e81\u0e82\u0e84\u0e87\u0e88\u0e8a\u0e8d\u0e94-\u0e97\u0e99-\u0e9f\u0ea1-\u0ea3\u0ea5\u0ea7\u0eaa\u0eab\u0ead-\u0eb0\u0eb2\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0ed0-\u0ed9\u0edc-\u0edf\u0f00-\u0f17\u0f1a-\u0f34\u0f36\u0f38\u0f3e-\u0f47\u0f49-\u0f6c\u0f7f\u0f85\u0f88-\u0f8c\u0fbe-\u0fc5\u0fc7-\u0fcc\u0fce-\u0fda\u1000-\u102c\u1031\u1038\u103b\u103c\u103f-\u1057\u105a-\u105d\u1061-\u1070\u1075-\u1081\u1083\u1084\u1087-\u108c\u108e-\u109c\u109e-\u10c5\u10c7\u10cd\u10d0-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1360-\u137c\u1380-\u138f\u13a0-\u13f4\u1401-\u167f\u1681-\u169a\u16a0-\u16f8\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1735\u1736\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17b6\u17be-\u17c5\u17c7\u17c8\u17d4-\u17da\u17dc\u17e0-\u17e9\u1810-\u1819\u1820-\u1877\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191e\u1923-\u1926\u1929-\u192b\u1930\u1931\u1933-\u1938\u1946-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u19d0-\u19da\u1a00-\u1a16\u1a19\u1a1a\u1a1e-\u1a55\u1a57\u1a61\u1a63\u1a64\u1a6d-\u1a72\u1a80-\u1a89\u1a90-\u1a99\u1aa0-\u1aad\u1b04-\u1b33\u1b35\u1b3b\u1b3d-\u1b41\u1b43-\u1b4b\u1b50-\u1b6a\u1b74-\u1b7c\u1b82-\u1ba1\u1ba6\u1ba7\u1baa\u1bae-\u1be5\u1be7\u1bea-\u1bec\u1bee\u1bf2\u1bf3\u1bfc-\u1c2b\u1c34\u1c35\u1c3b-\u1c49\u1c4d-\u1c7f\u1cc0-\u1cc7\u1cd3\u1ce1\u1ce9-\u1cec\u1cee-\u1cf3\u1cf5\u1cf6\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u200e\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2119-\u211d\u2124\u2126\u2128\u212a-\u212d\u212f-\u2139\u213c-\u213f\u2145-\u2149\u214e\u214f\u2160-\u2188\u2336-\u237a\u2395\u249c-\u24e9\u26ac\u2800-\u28ff\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d70\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u3005-\u3007\u3021-\u3029\u302e\u302f\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309d-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312d\u3131-\u318e\u3190-\u31ba\u31f0-\u321c\u3220-\u324f\u3260-\u327b\u327f-\u32b0\u32c0-\u32cb\u32d0-\u32fe\u3300-\u3376\u337b-\u33dd\u33e0-\u33fe\u3400-\u4db5\u4e00-\u9fcc\ua000-\ua48c\ua4d0-\ua60c\ua610-\ua62b\ua640-\ua66e\ua680-\ua69d\ua6a0-\ua6ef\ua6f2-\ua6f7\ua722-\ua787\ua789-\ua78e\ua790-\ua7ad\ua7b0\ua7b1\ua7f7-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua824\ua827\ua830-\ua837\ua840-\ua873\ua880-\ua8c3\ua8ce-\ua8d9\ua8f2-\ua8fb\ua900-\ua925\ua92e-\ua946\ua952\ua953\ua95f-\ua97c\ua983-\ua9b2\ua9b4\ua9b5\ua9ba\ua9bb\ua9bd-\ua9cd\ua9cf-\ua9d9\ua9de-\ua9e4\ua9e6-\ua9fe\uaa00-\uaa28\uaa2f\uaa30\uaa33\uaa34\uaa40-\uaa42\uaa44-\uaa4b\uaa4d\uaa50-\uaa59\uaa5c-\uaa7b\uaa7d-\uaaaf\uaab1\uaab5\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaaeb\uaaee-\uaaf5\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5f\uab64\uab65\uabc0-\uabe4\uabe6\uabe7\uabe9-\uabec\uabf0-\uabf9\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\ue000-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc",
        R: "\u0590\u05be\u05c0\u05c3\u05c6\u05c8-\u05ff\u07c0-\u07ea\u07f4\u07f5\u07fa-\u0815\u081a\u0824\u0828\u082e-\u0858\u085c-\u089f\u200f\ufb1d\ufb1f-\ufb28\ufb2a-\ufb4f",
        AL: "\u0608\u060b\u060d\u061b-\u064a\u066d-\u066f\u0671-\u06d5\u06e5\u06e6\u06ee\u06ef\u06fa-\u0710\u0712-\u072f\u074b-\u07a5\u07b1-\u07bf\u08a0-\u08e3\ufb50-\ufd3d\ufd40-\ufdcf\ufdf0-\ufdfc\ufdfe\ufdff\ufe70-\ufefe"
    };
    var h = new RegExp("[" + e.L + e.R + e.AL + "]"),
        i = new RegExp("[" + e.R + e.AL + "]");

    function j(a) {
        a = h.exec(a);
        return a == null ? null : a[0]
    }

    function k(a) {
        a = j(a);
        return a == null ? d("UnicodeBidiDirection").NEUTRAL : i.exec(a) ? d("UnicodeBidiDirection").RTL : d("UnicodeBidiDirection").LTR
    }

    function l(a, b) {
        b = b || d("UnicodeBidiDirection").NEUTRAL;
        if (!a.length) return b;
        a = k(a);
        return a === d("UnicodeBidiDirection").NEUTRAL ? b : a
    }

    function m(a, b) {
        b = b || c("UnicodeBidiGlobalDirection").getDir();
        if (!d("UnicodeBidiDirection").isStrong(b)) throw c("unrecoverableViolation")("Fallback direction must be a strong direction", "internationalization");
        return l(a, b)
    }

    function a(a, b) {
        return m(a, b) === d("UnicodeBidiDirection").LTR
    }

    function b(a, b) {
        return m(a, b) === d("UnicodeBidiDirection").RTL
    }
    g.firstStrongChar = j;
    g.firstStrongCharDir = k;
    g.resolveBlockDir = l;
    g.getDirection = m;
    g.isDirectionLTR = a;
    g.isDirectionRTL = b
}), 98);