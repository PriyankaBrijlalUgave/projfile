if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("randomShuffleSeeded", ["Alea"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        for (var b = arguments.length, d = new Array(b > 1 ? b - 1 : 0), e = 1; e < b; e++) d[e - 1] = arguments[e];
        var f = c("Alea").apply(void 0, d);

        function g(a) {
            return Math.floor(f() * a)
        }
        for (var h = a.length - 1; h > 0; h--) {
            var i = g(h + 1);
            if (i != h) {
                var j = a[i];
                a[i] = a[h];
                a[h] = j
            }
        }
        return a
    }
    g["default"] = a
}), 98);
__d("useSortCometPollOptions", ["$InternalEnum", "guid", "randomShuffleSeeded", "react", "sortBy"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useCallback,
        i = e.useRef,
        j = c("guid")(),
        k = b("$InternalEnum").Mirrored(["Random", "None"]);

    function a() {
        var a = i([]);
        return h(function(b, d, e) {
            var f = b;
            if (e === k.Random) {
                var g = new Map();
                b.forEach(function(a) {
                    g.set(d(a), a)
                });
                var h = [];
                a.current.forEach(function(a) {
                    var b = g.get(a);
                    b != null && (h.push(b), g["delete"](a))
                });
                e = Array.from(g.values());
                f = [].concat(h, c("randomShuffleSeeded")(c("sortBy")(e, function(a) {
                    return d(a)
                }), j));
                a.current = f.map(function(a) {
                    return d(a)
                })
            }
            return f
        }, [])
    }
    g.SortType = k;
    g.useSortCometPollOptions = a
}), 98);
__d("PhotosUploadID", [], (function(a, b, c, d, e, f) {
    var g = 1024;

    function a() {
        return (g++).toString()
    }
    f.getNewID = a
}), 66);
__d("URLScraper", ["ArbiterMixin", "DataStore", "Event", "URLMatcher", "mixin"], (function(a, b, c, d, e, f, g) {
    var h = "scraperLastPermissiveMatch";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            var d;
            d = a.call(this) || this;
            d.input = b;
            d.enable();
            d.getValueFn = c;
            return d
        }
        var e = b.prototype;
        e.reset = function() {
            d("DataStore").set(this.input, h, null)
        };
        e.enable = function() {
            if (this.events) return;
            var a = function(a) {
                window.setTimeout(this.check.bind(this, a), 30)
            };
            this.events = c("Event").listen(this.input, {
                paste: a.bind(this, !1),
                keydown: a.bind(this, !0)
            })
        };
        e.disable = function() {
            if (!this.events) return;
            for (var a in this.events) this.events[a].remove();
            this.events = null
        };
        e.check = function(a) {
            var c = this.getValueFn ? this.getValueFn() : this.input.value;
            if (a && b.trigger(c)) return;
            a = b.match(c);
            c = d("URLMatcher").permissiveMatch(c);
            c && c != d("DataStore").get(this.input, h) && (d("DataStore").set(this.input, h, c), this.inform("match", {
                url: a || c,
                alt_url: c
            }))
        };
        return b
    }(c("mixin")(c("ArbiterMixin")));
    Object.assign(a, d("URLMatcher"));
    g["default"] = a
}), 98);
__d("getURLRanges", ["URI", "URLScraper", "UnicodeUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = [],
            e = 0;
        while (!0) {
            var f = d("UnicodeUtils").substr(a, e),
                g = c("URLScraper").match(f);
            if (!g) break;
            if (!c("URI").isValidURI(g)) break;
            var h = g;
            /^[a-z][a-z0-9\-+.]+:\/\//i.test(g) || (h = "http://" + g);
            var i = f.indexOf(g);
            f = d("UnicodeUtils").strlen(f.substr(0, i));
            e += f;
            i = g.length;
            b.push({
                offset: e,
                length: g.length,
                entity: {
                    url: h
                }
            });
            e += i
        }
        return b
    }
    g["default"] = a
}), 98);
__d("isNumberLike", [], (function(a, b, c, d, e, f) {
    function a(a) {
        return !isNaN(parseFloat(a)) && isFinite(a)
    }
    f["default"] = a
}), 66);
__d("XSlideshowShakrOAuthController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/slideshow/shakr/", {})
}), null);
__d("XSlideshowStorylineMoodAsyncController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/slideshow/storyline_mood/", {
        target_id: {
            type: "FBID"
        }
    })
}), null);
__d("XSlideshowStorylineMoodDeleteController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/slideshow/storyline_mood/delete/", {})
}), null);
__d("XSlideshowStorylineMoodUploadController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/slideshow/storyline_mood/upload/", {})
}), null);
__d("XSlideshowVideoFrameImagesAsyncController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/slideshow/frame_images/", {
        request_type: {
            type: "Enum",
            enumType: 0
        },
        video_id: {
            type: "FBID"
        }
    })
}), null);
__d("SlideshowDataManager", ["AsyncRequest", "ThisControllerNoLongerExists", "XSlideshowShakrOAuthController", "XSlideshowStorylineMoodAsyncController", "XSlideshowStorylineMoodDeleteController", "XSlideshowStorylineMoodUploadController", "XSlideshowVideoFrameImagesAsyncController", "immutable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {}
        var b = a.prototype;
        b.fetchStorylineMoodSource = function(a, b, d) {
            var e = c("XSlideshowStorylineMoodAsyncController").getURIBuilder().getURI();
            new(c("AsyncRequest"))().setURI(e).setData({
                storyline_mood_id: a,
                total_length: b
            }).setMethod("POST").setHandler(function(a) {
                return d(a.payload)
            }).send()
        };
        b.fetchStorylineMoodFiles = function(a, b) {
            var d = this,
                e = c("XSlideshowStorylineMoodAsyncController").getURIBuilder().getURI();
            new(c("AsyncRequest"))().setURI(e).setMethod("GET").setData({
                target_id: b
            }).setReadOnly(!0).setHandler(function(b) {
                return a(d.getStorylineMoodFiles(b.payload))
            }).send()
        };
        b.getStorylineMoodFiles = function(a) {
            var b = [];
            Object.keys(a).forEach(function(c) {
                b.push({
                    moodID: c,
                    fileName: a[c].fileName,
                    categories: a[c].categories,
                    source: null
                })
            });
            return c("immutable").List(b)
        };
        b.scheduleFrameImagesAsyncJob = function(a) {
            var b = c("XSlideshowVideoFrameImagesAsyncController").getURIBuilder().getURI();
            new(c("AsyncRequest"))().setURI(b).setData({
                request_type: 0,
                video_id: a
            }).setMethod("POST").send()
        };
        b.fetchVideoFrameImages = function(a, b) {
            var d = c("XSlideshowVideoFrameImagesAsyncController").getURIBuilder().getURI();
            new(c("AsyncRequest"))().setURI(d).setData({
                request_type: 1,
                video_id: b
            }).setMethod("POST").setHandler(function(b) {
                return a(b.payload)
            }).send()
        };
        b.uploadAudioFile = function(a, b, d, e) {
            var f = this;
            if (!a || !a.input || !a.input.files.length) return;
            var g = c("XSlideshowStorylineMoodUploadController").getURIBuilder().getURI(),
                h = new FormData();
            h.append("audio_file", a.input.files[0]);
            h.append("target_id", b);
            new(c("AsyncRequest"))().setURI(g).setRawData(h).setMethod("POST").setErrorHandler(function(a) {
                return e()
            }).setHandler(function(a) {
                return f.$1(a.payload, d, e)
            }).send();
            a.clear()
        };
        b.$1 = function(a, b, c) {
            a.success ? b({
                moodID: a.moodID,
                fileName: a.fileName,
                categories: a.categories,
                source: null
            }) : c()
        };
        b.deleteAudioFile = function(a) {
            var b = c("XSlideshowStorylineMoodDeleteController").getURIBuilder().getURI();
            new(c("AsyncRequest"))().setURI(b).setData({
                mood_id: a
            }).setMethod("POST").send()
        };
        b.getShakrScopeToken = function(a) {
            var b = c("XSlideshowShakrOAuthController").getURIBuilder();
            new(c("AsyncRequest"))().setURI(b.getURI()).setHandler(function(b) {
                return a(b.payload)
            }).send()
        };
        b.pollShakrForVideoURL = function(a, b) {
            var e = d("ThisControllerNoLongerExists").__DEADBUILDER__("o279ohaf");
            new(c("AsyncRequest"))().setURI(e.getURI()).setData({
                show_id: a
            }).setHandler(function(a) {
                return b(a.payload)
            }).send()
        };
        return a
    }();
    b = new a();
    g["default"] = b
}), 98);
__d("dotAccess", [], (function(a, b, c, d, e, f) {
    function a(a, b, c) {
        b = b.split(".");
        do {
            var d = b.shift();
            a = a[d] || c && (a[d] = {})
        } while (b.length && a);
        return a
    }
    f["default"] = a
}), 66);
__d("EmoticonSpan.react", ["cx", "EmoticonsList", "FBEmojiResource", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = 16;

    function a(a) {
        var b = a.children,
            e = a.contentState,
            f = a.entityKey;
        a = (a = a.size) != null ? a : j;
        if (f == null) return null;
        e = e.getEntity(f).getData();
        f = d("EmoticonsList").emoji[e.type];
        e = new(c("FBEmojiResource"))(f);
        f = e.getImageURL(a);
        return f == null ? null : i.jsx("span", {
            className: "_3gl1 _5zz4",
            "data-testid": void 0,
            style: {
                backgroundImage: "url(" + f + ")",
                backgroundSize: a + "px " + a + "px",
                height: a + "px",
                width: a + "px"
            },
            children: i.jsx("span", {
                className: "_ncl",
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("HashtagSpan.react", ["cx", "react"], (function(a, b, c, d, e, f, g, h) {
    var i = d("react");

    function a(a) {
        return i.jsx("span", {
            "data-offset-key": a.offsetKey,
            dir: a.dir,
            className: "_5zk7",
            spellCheck: !1,
            children: a.children
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MentionSpan.react", ["cx", "react"], (function(a, b, c, d, e, f, g, h) {
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.render = function() {
            var a = this.props,
                b = a.children,
                c = a.offsetKey;
            a.blockKey;
            a.contentState;
            a.decoratedText;
            a.end;
            a.entityKey;
            a.start;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "offsetKey", "blockKey", "contentState", "decoratedText", "end", "entityKey", "start"]);
            return i.jsx("span", babelHelpers["extends"]({}, a, {
                "data-offset-key": c,
                className: "_247o",
                spellCheck: !1,
                children: b
            }))
        };
        return b
    }(i.Component);
    g["default"] = a
}), 98);
__d("WeakMentionSpan.react", ["cx", "react"], (function(a, b, c, d, e, f, g, h) {
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.render = function() {
            return i.jsx("span", {
                "data-offset-key": this.props.offsetKey,
                className: "_whq",
                spellCheck: !1,
                children: this.props.children
            })
        };
        return b
    }(i.Component);
    g["default"] = a
}), 98);
__d("QuestionPollTypeJSEnum", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        NON_POLL: 0,
        CHOOSE_ONE: 1,
        CHOOSE_MULTIPLE: 2,
        RANKED: 3,
        GIF_CHOOSE_ONE: 4,
        IMAGE_CHOOSE_ONE: 5,
        VISUAL_TEXT_CHOOSE_ONE: 6,
        IMAGE_CHOOSE_MULTIPLE: 7,
        PAGE_CHOOSE_MULTIPLE: 8,
        MOST_LIKELY_TO: 9,
        MEDIA_CHOOSE_ONE: 10
    });
    f["default"] = a
}), 66);
__d("PhotosUploadWaterfallXMixin", ["invariant", "AsyncSignal", "Banzai", "PhotosUploadWaterfallXConfig", "randomInt"], (function(a, b, c, d, e, f, g) {
    var h = new Map();

    function i(a, c) {
        var d = {};
        a.client_time = Math.round(Date.now() / 1e3);
        b("PhotosUploadWaterfallXConfig").retryBanzai && (d.retry = !0, a.nonce = b("randomInt")(4294967296));
        b("Banzai").post(b("PhotosUploadWaterfallXConfig").banzaiRoute, a, d);
        c && setTimeout(c, 0)
    }

    function j(a, c) {
        if (b("PhotosUploadWaterfallXConfig").useBanzai) i(a, c);
        else {
            a = new(b("AsyncSignal"))(b("PhotosUploadWaterfallXConfig").loggingEndpoint, {
                data: JSON.stringify(a)
            }).setHandler(c);
            b("PhotosUploadWaterfallXConfig").timeout && a.setTimeout(10 * 1e3);
            a.send()
        }
    }
    e.exports = {
        logStep: function(a, b, c) {
            var d = this.getWaterfallID && this.getWaterfallID(),
                e = this.getWaterfallAppName && this.getWaterfallAppName();
            if (!d || !e) return;
            j(babelHelpers["extends"]({
                step: a,
                qn: d,
                uploader: e,
                ref: this.getWaterfallSource && this.getWaterfallSource()
            }, b), c)
        },
        logPUWStep: function(a, b, c, d, e, f, g) {
            if (f && f.logOncePerSession) {
                h.has(b) || h.set(b, new Set());
                if (h.get(b).has(a)) return;
                h.get(b).add(a)
            }
            j(babelHelpers["extends"]({
                step: a,
                qn: b,
                uploader: c,
                ref: d
            }, e), g)
        }
    }
}), null);
__d("ReactComponentWithPureRenderMixin", ["shallowCompare"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        shouldComponentUpdate: function(a, c) {
            return b("shallowCompare")(this, a, c)
        }
    };
    c = a;
    f["default"] = c
}), 66);
__d("SlideshowFlowTypes", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        SETTINGS_TAB: "SETTINGS_TAB",
        MUSIC_TAB: "MUSIC_TAB",
        FRAMES_TAB: "FRAMES_TAB"
    };
    f.SlideshowTabKey = a
}), 66);