if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ChatPluginThreadLoadQplLogger", ["QuickPerformanceLogger", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        c("QuickPerformanceLogger").markerStart(c("qpl")._(968822565, "3437"))
    }

    function b() {
        c("QuickPerformanceLogger").markerEnd(c("qpl")._(968822565, "3437"), 2)
    }

    function d() {
        c("QuickPerformanceLogger").markerEnd(c("qpl")._(968822565, "3437"), 3)
    }
    g.logChatPluginThreadLoadModuleStart = a;
    g.logChatPluginThreadLoadModuleEndSuccess = b;
    g.logChatPluginThreadLoadModuleEndFail = d
}), 98);