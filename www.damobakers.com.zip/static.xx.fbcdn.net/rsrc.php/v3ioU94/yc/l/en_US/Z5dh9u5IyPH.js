if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("compareDOMOrder", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1
    }
    f["default"] = a
}), 66);
__d("createLayoutContext", ["compareDOMOrder", "emptyFunction", "react", "useRefEffect", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useImperativeHandle,
        k = b.useMemo,
        l = b.useReducer;
    b.useRef;

    function a(a) {
        var b = {
                getLayout: function() {
                    return a
                },
                dispatch: c("emptyFunction"),
                nodes: new Map(),
                values: []
            },
            d = h.createContext(b);

        function e(a) {
            var b = a.children,
                c = a.imperativeRef,
                e = a.value;
            a = o();
            var f = a[0],
                g = a[1],
                i = a[2];
            j(c, function() {
                return {
                    forceUpdate: function() {
                        return i()
                    }
                }
            }, [i]);
            a = k(function() {
                return {
                    getLayout: e,
                    dispatch: i,
                    nodes: f,
                    values: g
                }
            }, [i, f, e, g]);
            return h.jsx(d.Provider, {
                value: a,
                children: b
            })
        }
        e.displayName = e.name + " [from " + f.id + "]";

        function g(a) {
            return h.jsx(d.Provider, babelHelpers["extends"]({
                value: b
            }, a))
        }
        g.displayName = g.name + " [from " + f.id + "]";

        function l(b) {
            var e = c("useUnsafeRef_DEPRECATED")(null),
                f = i(d),
                g = f.getLayout,
                h = f.dispatch,
                j = f.nodes,
                l = f.values;
            f = k(function() {
                var b = e.current && j.get(e.current),
                    c = j.size;
                return b != null ? g({
                    isFirst: b === 0,
                    isLast: b >= 0 && b === c - 1,
                    index: b,
                    total: c,
                    values: l,
                    nodes: j
                }) : a
            }, [g, j, l]);
            var m = c("useRefEffect")(function(a) {
                e.current = a;
                h({
                    add: a,
                    value: b
                });
                return function() {
                    e.current = null, h({
                        remove: a
                    })
                }
            }, [h, b]);
            return [f, m]
        }

        function m(a) {
            var b = l(a.value),
                c = b[0];
            b = b[1];
            return a.children(c, b)
        }
        m.displayName = m.name + " [from " + f.id + "]";
        return {
            Provider: e,
            Consumer: m,
            Resetter: g,
            useLayoutContext: l,
            _context: d
        }
    }

    function m(a, b) {
        a = a.node;
        b = b.node;
        return c("compareDOMOrder")(a, b)
    }

    function n(a, b) {
        var c = Array.from(a);
        b != null && (b.remove && (c = a.filter(function(a) {
            a = a.node;
            return a !== b.remove
        })), b.add && (c = c.filter(function(a) {
            a = a.node;
            return a !== b.add
        }).concat({
            node: b.add,
            value: b.value
        })));
        return c.sort(m)
    }

    function o() {
        var a = l(n, []),
            b = a[0];
        a = a[1];
        var c = k(function() {
                var a = new Map(),
                    c = [];
                b.forEach(function(b, d) {
                    var e = b.node;
                    b = b.value;
                    a.set(e, d);
                    c.push(b)
                });
                return {
                    nodes: a,
                    values: c
                }
            }, [b]),
            d = c.nodes;
        c = c.values;
        return [d, c, a]
    }
    g["default"] = a
}), 98);
__d("NotificationBeeperConst", ["keyMirror"], (function(a, b, c, d, e, f, g) {
    a = 1e4;
    b = 4e3;
    d = 1500;
    e = c("keyMirror")({
        PENDING: !0,
        RENDERED: !0,
        READY_TO_HIDE: !0,
        FADING_OUT: !0
    });
    g.IDLE_DELAY = a;
    g.ACTIVE_DELAY_LONG = b;
    g.FADE_OUT_LENGTH = d;
    g.BeepStates = e
}), 98);
__d("FDSPrivateButtonLayoutContext", ["createLayoutContext"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("createLayoutContext")({});
    b = a;
    g["default"] = b
}), 98);
__d("XUIDialogOkayButton.react", ["cx", "fbt", "XUIDialogButton.react", "joinClasses", "prop-types", "react"], (function(a, b, c, d, e, f, g, h, i) {
    var j = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            return j.jsx(c("XUIDialogButton.react"), babelHelpers["extends"]({}, this.props, {
                className: c("joinClasses")(this.props.className, "_2z1w"),
                action: this.props.action,
                label: i._("OK")
            }))
        };
        return b
    }(j.Component);
    a.propTypes = {
        action: c("prop-types").oneOf(["confirm", "cancel", "button"]).isRequired
    };
    g["default"] = a
}), 98);
__d("AlignmentEnum", ["keyMirror", "objectValues", "prop-types"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        left: null,
        center: null,
        right: null
    });
    b = c("objectValues")(a);
    d = c("prop-types").oneOf(b);
    e = babelHelpers["extends"]({}, a, {
        values: b,
        propType: d
    });
    g["default"] = e
}), 98);
__d("CornerEnum", ["keyMirror", "objectValues"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        topLeft: null,
        topRight: null,
        bottomRight: null,
        bottomLeft: null
    });
    b = c("objectValues")(a);
    d = babelHelpers["extends"]({}, a, {
        values: b
    });
    g["default"] = d
}), 98);
__d("SideEnum", ["keyMirror", "objectValues", "prop-types"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        top: null,
        right: null,
        bottom: null,
        left: null
    });
    b = c("objectValues")(a);
    d = c("prop-types").oneOf(b);
    e = babelHelpers["extends"]({}, a, {
        values: b,
        propType: d
    });
    g["default"] = e
}), 98);
__d("DialogHideOnSuccess", ["csx", "CSS"], (function(a, b, c, d, e, f, g) {
    a = function() {
        "use strict";

        function a(a) {
            this._layer = a
        }
        var c = a.prototype;
        c.enable = function() {
            this._subscription = this._layer.subscribe("success", this._handle.bind(this))
        };
        c.disable = function() {
            this._subscription.unsubscribe(), this._subscription = null
        };
        c._handle = function(a, c) {
            b("CSS").matchesSelector(c.getTarget(), "._s") && this._layer.hide()
        };
        return a
    }();
    Object.assign(a.prototype, {
        _subscription: null
    });
    e.exports = a
}), null);
__d("PopoverAsyncMenu", ["Bootloader", "Event", "KeyStatus", "PopoverMenu", "VirtualCursorStatus", "setImmediate"], (function(a, b, c, d, e, f) {
    var g = {},
        h = 0;
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(c, d, e, f, i, j) {
            c = a.call(this, c, d, null, i) || this;
            c._endpoint = f;
            c._endpointData = j || {};
            c._loadingMenu = e;
            c._instanceId = h++;
            g[c._instanceId] = babelHelpers.assertThisInitialized(c);
            c._mouseoverListener = b("Event").listen(d, "mouseover", c.fetchMenu.bind(babelHelpers.assertThisInitialized(c)));
            return c
        }
        var d = c.prototype;
        d._onLayerInit = function() {
            var a = this;
            !this._menu && this._loadingMenu && this.setMenu(this._loadingMenu);
            this._popover.getLayer().subscribe("key", this._handleKeyEvent.bind(this));
            this._triggerInfo = {
                isKeyDown: b("KeyStatus").isKeyDown(),
                isVirtualCursorTriggered: b("VirtualCursorStatus").isVirtualCursorTriggered()
            };
            b("setImmediate")(function() {
                return a.fetchMenu()
            })
        };
        d._onPopoverHide = function() {
            a.prototype._onPopoverHide.call(this), this._triggerInfo = null
        };
        d._refetchMenu = function() {
            this._menu && (this._menu.destroy(), this._fetched = !1, this._mouseoverListener = b("Event").listen(this.getTriggerElem(), "mouseover", this.fetchMenu.bind(this)))
        };
        d.fetchMenu = function() {
            var a = this;
            if (this._fetched) return;
            b("Bootloader").loadModules(["AsyncRequest"], function(b) {
                new b().setURI(a._endpoint).setData(babelHelpers["extends"]({
                    pmid: a._instanceId
                }, a._endpointData)).send()
            }, "PopoverAsyncMenu");
            this._fetched = !0;
            this._mouseoverListener && (this._mouseoverListener.remove(), this._mouseoverListener = null)
        };
        d._setFocus = function(a) {
            var b = this._triggerInfo || {},
                c = b.isKeyDown;
            b = b.isVirtualCursorTriggered;
            this.setInitialFocus(a, c || b);
            this._triggerInfo = null
        };
        c.setMenu = function(a, b) {
            a = g[a];
            a.setMenu(b);
            a._setFocus(b)
        };
        c.disableTypeaheadActivationForInstance = function(a) {
            a = g[a];
            a._isTypeaheadActivationDisabled = !0
        };
        c.getInstance = function(a) {
            return g[a]
        };
        c.getInstanceByTriggerElem = function(a) {
            var b = null;
            Object.keys(g).forEach(function(c) {
                g[c]._triggerElem == a && (b = g[c])
            });
            return b
        };
        return c
    }(b("PopoverMenu"));
    e.exports = a
}), null);
__d("NotificationSound", ["Sound"], (function(a, b, c, d, e, f, g) {
    var h = 5e3;
    d("Sound").init(["audio/mpeg"]);
    a = function() {
        function a(a) {
            this.$1 = a, this.$2 = 0
        }
        var b = a.prototype;
        b.play = function(a) {
            if (!this.$1) return !1;
            var b = Date.now();
            if (b - this.$2 < h) return !1;
            this.$2 = b;
            d("Sound").playOnlyIfImmediate(this.$1, a, !1);
            return !0
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("SUIBorderUtils", ["CornerEnum", "Locale", "SideEnum", "prop-types"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = c("prop-types").arrayOf(c("prop-types").oneOf(c("SideEnum").values));
    f = c("prop-types").arrayOf(c("prop-types").oneOf(c("CornerEnum").values));

    function a(a, b) {
        b = b;
        if (a === c("CornerEnum").values) return b != null ? {
            borderRadius: b
        } : null;
        a = new Set(a);
        if (a.size === c("CornerEnum").values.length) return b != null ? {
            borderRadius: b
        } : null;
        b == null && (b = "2px");
        a = {
            borderTopLeftRadius: a.has("topLeft") ? b : "0",
            borderTopRightRadius: a.has("topRight") ? b : "0",
            borderBottomRightRadius: a.has("bottomRight") ? b : "0",
            borderBottomLeftRadius: a.has("bottomLeft") ? b : "0"
        };
        return d("Locale").isRTL() ? {
            borderTopLeftRadius: a.borderTopRightRadius,
            borderTopRightRadius: a.borderTopLeftRadius,
            borderBottomRightRadius: a.borderBottomLeftRadius,
            borderBottomLeftRadius: a.borderBottomRightRadius
        } : a
    }

    function b(a) {
        if (a === c("SideEnum").values) return null;
        a = new Set(a);
        if (a.size === c("SideEnum").values.length) return null;
        a = {
            borderTopWidth: a.has("top") ? "1px" : "0",
            borderRightWidth: a.has("right") ? "1px" : "0",
            borderBottomWidth: a.has("bottom") ? "1px" : "0",
            borderLeftWidth: a.has("left") ? "1px" : "0"
        };
        return d("Locale").isRTL() ? babelHelpers["extends"]({}, a, {
            borderRightWidth: a.borderLeftWidth,
            borderLeftWidth: a.borderRightWidth
        }) : a
    }
    g.ALL_CORNERS = c("CornerEnum").values;
    g.ALL_SIDES = c("SideEnum").values;
    g.BorderedSidesPropType = e;
    g.RoundedCornersPropType = f;
    g.getBorderRadiusStyles = a;
    g.getBorderWidthStyles = b
}), 98);
__d("SUIInternalMouseUpListener", ["DOMEventListener"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null;

    function a(a) {
        i || (i = d("DOMEventListener").add(window, "mouseup", j)), h = a
    }

    function b(a) {
        h === a && (h = null)
    }

    function j(a) {
        h && (h(a), h = null)
    }
    g.set = a;
    g.unset = b
}), 98);
__d("SUITypeStyle", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d = c("UserAgent").isPlatform("Windows") ? "" : "0.01em";
    var h = {
            letterSpacing: d
        },
        i = {
            "40px": "50px",
            "32px": "40px",
            "24px": "30px",
            "16px": "20px",
            "14px": "18px",
            "13px": "16px",
            "12px": "16px",
            "11px": "14px"
        };

    function a(a) {
        return a + "px"
    }

    function b(a) {
        return babelHelpers["extends"]({}, h, a, {
            lineHeight: i[a.fontSize]
        })
    }
    b.createSUIFontSize = a;
    g["default"] = b
}), 98);
__d("RTLKeys", ["Keys", "Locale"], (function(a, b, c, d, e, f, g) {
    var h = null;

    function i() {
        h === null && (h = d("Locale").isRTL());
        return h
    }
    a = babelHelpers.objectWithoutPropertiesLoose(c("Keys"), ["RIGHT", "LEFT"]);
    var j = babelHelpers["extends"]({}, a, {
        REAL_RIGHT: c("Keys").RIGHT,
        REAL_LEFT: c("Keys").LEFT,
        getLeft: function() {
            return i() ? j.REAL_RIGHT : j.REAL_LEFT
        },
        getRight: function() {
            return i() ? j.REAL_LEFT : j.REAL_RIGHT
        }
    });
    b = j;
    g["default"] = b
}), 98);
__d("SUIButtonContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        isFixedWidthPadded: void 0
    });
    c = b;
    g["default"] = c
}), 98);
__d("SUIGlyphIcon.react", ["Image.react", "prop-types", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.active,
            d = a.disabled,
            e = a.focused,
            f = a.hover,
            g = a.srcActive,
            i = a.srcDefault,
            j = a.srcDisabled,
            k = a.srcFocused,
            l = a.srcHover;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["active", "disabled", "focused", "hover", "srcActive", "srcDefault", "srcDisabled", "srcFocused", "srcHover"]);
        i = i;
        d === !0 && j != null && j !== "" ? i = j : b === !0 && g != null && g !== "" ? i = g : e === !0 && k != null && k !== "" ? i = k : f === !0 && l != null && l !== "" && (i = l);
        return h.jsx(c("Image.react"), babelHelpers["extends"]({}, a, {
            src: i
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = c("prop-types").oneOfType([c("prop-types").object, c("prop-types").string]);
    a.propTypes = {
        active: c("prop-types").bool,
        disabled: c("prop-types").bool,
        hover: c("prop-types").bool,
        srcActive: b,
        srcDefault: b.isRequired,
        srcDisabled: b,
        srcHover: b
    };
    g["default"] = a
}), 98);
__d("mergeDeepInto", ["invariant", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = (c = b("mergeHelpers")).ArrayStrategies,
        i = c.checkArrayStrategy,
        j = c.checkMergeArrayArgs,
        k = c.checkMergeLevel,
        l = c.checkMergeObjectArgs,
        m = c.isTerminal,
        n = c.normalizeMergeArg,
        o = function(a, b, c, d) {
            l(a, b);
            k(d);
            var e = b ? Object.keys(b) : [];
            for (var f = 0; f < e.length; f++) {
                var g = e[f];
                q(a, b, g, c, d)
            }
        },
        p = function(a, b, c, d) {
            j(a, b);
            k(d);
            if (c === h.Concat) a.push.apply(a, b);
            else {
                var e = Math.max(a.length, b.length);
                for (var f = 0; f < e; f++) q(a, b, f, c, d)
            }
        },
        q = function(a, b, c, d, e) {
            var f = b[c];
            b = Object.prototype.hasOwnProperty.call(b, c);
            var i = b && m(f),
                j = b && Array.isArray(f),
                k = b && !j && !j,
                l = a[c],
                n = Object.prototype.hasOwnProperty.call(a, c),
                q = n && m(l),
                r = n && Array.isArray(l),
                s = n && !r && !r;
            q ? i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k ? (a[c] = {}, o(a[c], f, d, e + 1)) : b || (a[c] = l) : r ? i ? a[c] = f : j ? (d && h[d] || g(0, 5117), d === h.Clobber && (l.length = 0), p(l, f, d, e + 1)) : k && (a[c] = {}, o(a[c], f, d, e + 1)) : s ? i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k && o(l, f, d, e + 1) : n || (i ? a[c] = f : j ? (a[c] = [], p(a[c], f, d, e + 1)) : k && (a[c] = {}, o(a[c], f, d, e + 1)))
        };

    function a(a, b, c) {
        b = n(b);
        i(c);
        o(a, b, c, 0)
    }
    f["default"] = a
}), 66);
__d("mergeDeep", ["mergeDeepInto", "mergeHelpers"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        a = c("mergeHelpers").normalizeMergeArg(a);
        b = c("mergeHelpers").normalizeMergeArg(b);
        c("mergeHelpers").checkMergeObjectArgs(a, b);
        c("mergeHelpers").checkArrayStrategy(d);
        var e = {};
        c("mergeDeepInto")(e, a, d);
        c("mergeDeepInto")(e, b, d);
        return e
    }
    g["default"] = a
}), 98);
__d("SUIButton_DEPRECATED.react", ["cx", "AlignmentEnum", "KeyStatus", "Link.react", "RTLKeys", "SUIBorderUtils", "SUIButtonContext", "SUIErrorBoundary.react", "SUIGlyphIcon.react", "SUIInternalMouseUpListener", "SUITheme", "TooltipData", "VirtualCursorStatus", "autoFlipStyleProps", "joinClasses", "mergeDeep", "prop-types", "react", "shallowEqual", "withSUITheme"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = !1;
    b = "normal";
    e = "center";
    f = "button";
    var j = "default";
    h = {
        borderedSides: d("SUIBorderUtils").ALL_SIDES,
        disabled: a,
        hasHoverState: !0,
        height: b,
        labelIsHidden: !1,
        roundedCorners: d("SUIBorderUtils").ALL_CORNERS,
        suppressLabelOverflowTooltip: !1,
        suppressed: !1,
        textAlign: e,
        tooltipDelay: 0,
        type: f,
        use: j
    };
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            b = a.call(this) || this;
            b.$1 = null;
            b.$4 = function(a) {
                b.setState({
                    isActive: !1,
                    showFocusRing: !1
                }), b.props.onBlur && b.props.onBlur(a)
            };
            b.$5 = function(a) {
                if (b.props.disabled) {
                    a.preventDefault();
                    return
                }
                b.props.onClick && (b.props.onClick(a), b.props.href || a.preventDefault())
            };
            b.$6 = function(a) {
                (d("KeyStatus").isKeyDown() || d("VirtualCursorStatus").isVirtualCursorTriggered()) && b.setState({
                    showFocusRing: !0
                }), b.props.onFocus && b.props.onFocus(a)
            };
            b.$7 = function(a) {
                if (b.props.disabled) return;
                switch (a.keyCode) {
                    case c("RTLKeys").RETURN:
                    case c("RTLKeys").SPACE:
                        b.setState({
                            isActive: !0,
                            showFocusRing: !0
                        });
                        break
                }
                b.props.onKeyDown && b.props.onKeyDown(a)
            };
            b.$8 = function(a) {
                switch (a.keyCode) {
                    case c("RTLKeys").RETURN:
                    case c("RTLKeys").SPACE:
                        b.setState({
                            isActive: !1
                        });
                        break
                }
                b.props.onKeyUp && b.props.onKeyUp(a)
            };
            b.$9 = function(a) {
                b.setState({
                    isHovering: !0
                }), b.props.onMouseEnter && (b.props.onMouseEnter(a), a.preventDefault())
            };
            b.$10 = function(a) {
                b.setState({
                    isHovering: !1
                }), b.props.onMouseLeave && (b.props.onMouseLeave(a), a.preventDefault())
            };
            b.$11 = function(a) {
                if (b.props.disabled) return;
                d("SUIInternalMouseUpListener").set(b.$2);
                b.setState({
                    isActive: !0,
                    showFocusRing: !1
                });
                b.props.onMouseDown && (b.props.onMouseDown(a), a.preventDefault())
            };
            b.$2 = function(a) {
                if (!b.state.isActive) return;
                b.setState({
                    isActive: !1
                });
                b.props.onMouseUp && (b.props.onMouseUp(a), a.preventDefault())
            };
            b.$21 = function(a) {
                b.$1 = a;
                b.props.buttonRef == null ? void 0 : b.props.buttonRef((a = a) != null ? a : null)
            };
            b.state = {
                isActive: !1,
                isHovering: !1,
                showFocusRing: !1
            };
            return b
        }
        var e = b.prototype;
        e.componentWillUnmount = function() {
            d("SUIInternalMouseUpListener").unset(this.$2)
        };
        e.componentDidUpdate = function(a) {
            if (this.$1) {
                a = this.$3(a);
                var b = this.$3(this.props);
                c("shallowEqual")(a, b) || d("TooltipData").refreshIfActive(this.$1)
            }
        };
        e.$3 = function(a) {
            a = a === void 0 ? this.props : a;
            var b = a.tooltip;
            a = a.tooltipDelay;
            var c;
            b && (c = d("TooltipData").propsFor(b), a && (c["data-tooltip-delay"] = a));
            return c
        };
        e.$12 = function() {
            return {
                textAlign: this.props.textAlign
            }
        };
        e.$13 = function(a) {
            var b = this.props.use || j,
                c;
            this.props.disabled ? c = "disabled" : this.props.isDepressed || this.state.isActive ? c = "active" : this.state.isHovering || this.state.showFocusRing ? c = "hover" : c = "normal";
            a = a.use[b];
            b = a[c];
            c = {
                backgroundColor: b.background,
                borderColor: b.borderColor,
                color: b.color
            };
            a.fontWeight != null && (c.fontWeight = a.fontWeight);
            return b.backgroundImage ? babelHelpers["extends"]({}, c, {
                backgroundImage: b.backgroundImage
            }) : c
        };
        e.$14 = function(a) {
            a = a.height[this.props.height];
            return {
                height: a + "px"
            }
        };
        e.$15 = function() {
            var a = this.props,
                b = a.width,
                c = a.maxWidth;
            a = a.minWidth;
            var d = {};
            b && (d.width = b);
            c && (d.maxWidth = c);
            a != null && (d.minWidth = a);
            return d
        };
        e.$16 = function(a) {
            var b = new Set(this.props.borderedSides);
            a = a.height[this.props.height];
            b.has("bottom") && (a -= 1);
            b.has("top") && (a -= 1);
            return {
                lineHeight: a + "px"
            }
        };
        e.$17 = function(a, b, d, e) {
            if (b || d && e) return {};
            b = e ? "marginLeft" : "marginRight";
            d = a.padding[this.props.height].icon;
            return c("autoFlipStyleProps")((e = {}, e[b] = d, e)) || {}
        };
        e.$18 = function(a, b, c) {
            if (typeof this.props.width === "number" && c !== !0) return {};
            c = a.padding[this.props.height];
            a = c[b ? "onlyIcon" : "button"];
            return {
                paddingLeft: a,
                paddingRight: a
            }
        };
        e.$19 = function() {
            return this.props.uniformOverride ? c("mergeDeep")(c("SUITheme").get(this).SUIButton, this.props.uniformOverride) : c("SUITheme").get(this).SUIButton
        };
        e.$20 = function(a, b, d, e, f, g) {
            return i.cloneElement(e, babelHelpers["extends"]({
                "aria-hidden": !0,
                className: "_271o",
                disabled: a,
                style: babelHelpers["extends"]({}, this.$17(g, b, d, f), e.props.style)
            }, e.type === c("SUIGlyphIcon.react") ? {
                active: this.state.isActive || this.props.isDepressed,
                focused: this.state.showFocusRing,
                hover: this.state.isHovering
            } : {}))
        };
        e.render = function() {
            var a = this;
            return i.jsx(c("SUIButtonContext").Consumer, {
                children: function(b) {
                    b = b.isFixedWidthPadded;
                    var e = a.$19(),
                        f = a.props,
                        g = f.borderedSides;
                    f.buttonRef;
                    var h = f.className_DEPRECATED,
                        j = f.disabled,
                        k = f.hasHoverState;
                    f.height;
                    var l = f.icon,
                        m = f.iconAfter,
                        n = f.isDepressed,
                        o = f.isLabelFullWidth,
                        p = f.label,
                        q = f.labelIsHidden,
                        r = f.layerAction;
                    f.maxWidth;
                    f.minWidth;
                    var s = f.margin,
                        t = f.rightContent,
                        u = f.roundedCorners,
                        v = f.suppressLabelOverflowTooltip,
                        w = f.suppressed;
                    f.textAlign;
                    f.theme;
                    var x = f.tooltip;
                    f.tooltipDelay;
                    f.use;
                    f.uniformOverride;
                    var y = f.width;
                    f = babelHelpers.objectWithoutPropertiesLoose(f, ["borderedSides", "buttonRef", "className_DEPRECATED", "disabled", "hasHoverState", "height", "icon", "iconAfter", "isDepressed", "isLabelFullWidth", "label", "labelIsHidden", "layerAction", "maxWidth", "minWidth", "margin", "rightContent", "roundedCorners", "suppressLabelOverflowTooltip", "suppressed", "textAlign", "theme", "tooltip", "tooltipDelay", "use", "uniformOverride", "width"]);
                    var z = l != null,
                        A = m != null,
                        B = Boolean(p) && !q,
                        C = z && A && !B;
                    z = (z || A) && !C && !B;
                    A = c("autoFlipStyleProps")(babelHelpers["extends"]({}, a.$15(), e.typeStyle, a.$12(), a.$13(e), a.$14(e), a.$16(e), a.$18(e, z, b), d("SUIBorderUtils").getBorderRadiusStyles(u, e.borderRadius), d("SUIBorderUtils").getBorderWidthStyles(g), {
                        backgroundClip: "padding-box"
                    }, a.props.style || {}));
                    w && (A = babelHelpers["extends"]({}, A, {
                        backgroundColor: "transparent",
                        borderColor: "transparent"
                    }));
                    B = c("joinClasses")("_271k" + (a.props.density === "flex" ? " _6uvr" : "") + (l ? " _271l" : "") + (z ? " _1o4e" : "") + (y === void 0 || y === "auto" ? " _271m" : "") + (j ? " _271n" : "") + (a.state.showFocusRing ? "" : " _1qjd") + (a.props.href ? " _1gwm" : "") + (f.autoFocus ? " autofocus" : "") + (r === "confirm" ? " layerConfirm" : "") + (r === "cancel" ? " layerCancel" : "") + (r === "button" ? " layerButton" : ""), s, h);
                    var D;
                    !x && !f["data-tooltip-content"] && !v && (D = {
                        "data-hover": "tooltip",
                        "data-tooltip-display": "overflow"
                    }, f["data-tooltip-position"] && (D = babelHelpers["extends"]({}, D, {
                        "data-tooltip-position": f["data-tooltip-position"]
                    })));
                    u = babelHelpers["extends"]({
                        "aria-pressed": (b = a.props["aria-pressed"]) != null ? b : void 0
                    }, f);
                    n != null && a.props["aria-pressed"] === void 0 && (u["aria-pressed"] = n);
                    var E, F;
                    l && (E = a.$20(j, z, C, l, !1, e));
                    m && (F = a.$20(j, z, C, m, !0, e));
                    var G;
                    p && (G = q ? i.jsx("span", {
                        className: "accessible_elem",
                        children: p
                    }) : i.jsx("div", babelHelpers["extends"]({}, D, {
                        className: "_43rm" + (o ? " _46ce" : ""),
                        children: p
                    })));
                    g = babelHelpers["extends"]({}, a.$3(), u, {
                        "aria-disabled": a.props.disabled,
                        className: B,
                        onBlur: a.$4,
                        onClick: a.$5,
                        onFocus: a.$6,
                        onKeyDown: a.$7,
                        onKeyUp: a.$8,
                        onMouseDown: a.$11,
                        onMouseEnter: k ? a.$9 : null,
                        onMouseLeave: k ? a.$10 : null,
                        style: A,
                        type: a.props.type
                    });
                    w = i.jsx("div", {
                        className: "_43rl",
                        children: i.jsxs(c("SUIErrorBoundary.react"), {
                            children: [E, G, F, t]
                        })
                    });
                    return a.props.href ? i.jsx(c("Link.react"), babelHelpers["extends"]({}, g, {
                        linkRef: a.$21,
                        children: w
                    })) : i.jsx("button", babelHelpers["extends"]({}, g, {
                        ref: a.$21,
                        children: w
                    }))
                }
            })
        };
        return b
    }(i.PureComponent);
    a.propTypes = {
        borderedSides: d("SUIBorderUtils").BorderedSidesPropType.isRequired,
        buttonRef: c("prop-types").func,
        disabled: c("prop-types").bool.isRequired,
        hasHoverState: c("prop-types").bool.isRequired,
        height: c("prop-types").oneOf(["normal", "tall", "short"]).isRequired,
        icon: c("prop-types").element,
        iconAfter: c("prop-types").element,
        isDepressed: c("prop-types").bool,
        label: c("prop-types").node,
        labelIsHidden: c("prop-types").bool,
        layerAction: c("prop-types").oneOf(["cancel", "confirm", "button"]),
        margin: c("prop-types").string,
        maxWidth: c("prop-types").oneOfType([c("prop-types").string, c("prop-types").number]),
        minWidth: c("prop-types").oneOfType([c("prop-types").string, c("prop-types").number]),
        onBlur: c("prop-types").func,
        onClick: c("prop-types").func,
        onFocus: c("prop-types").func,
        onKeyDown: c("prop-types").func,
        onKeyUp: c("prop-types").func,
        onMouseDown: c("prop-types").func,
        onMouseEnter: c("prop-types").func,
        onMouseLeave: c("prop-types").func,
        onMouseUp: c("prop-types").func,
        rightContent: c("prop-types").node,
        roundedCorners: d("SUIBorderUtils").RoundedCornersPropType.isRequired,
        style: c("prop-types").object,
        suppressLabelOverflowTooltip: c("prop-types").bool.isRequired,
        suppressed: c("prop-types").bool.isRequired,
        textAlign: c("AlignmentEnum").propType.isRequired,
        theme: c("prop-types").instanceOf(c("SUITheme")),
        title: c("prop-types").string,
        tooltip: c("prop-types").node,
        tooltipDelay: c("prop-types").number,
        uniformOverride: c("prop-types").object,
        use: c("prop-types").oneOf(["default", "special", "confirm", "flat", "flatWhite"]).isRequired,
        width: c("prop-types").oneOfType([c("prop-types").string, c("prop-types").number])
    };
    a.defaultProps = h;
    b = c("withSUITheme")(a);
    g["default"] = b
}), 98);
__d("SUIButton.react", ["SUIButton_DEPRECATED.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("SUIButton_DEPRECATED.react")
}), 98);
__d("PopoverLoadingMenu", ["cx", "BehaviorsMixin", "DOM", "PopoverMenuInterface", "joinClasses"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(b) {
            var c;
            c = a.call(this) || this;
            c._config = b || {};
            c._theme = b.theme || {};
            return c
        }
        var d = c.prototype;
        d.getRoot = function() {
            if (!this._root) {
                var a;
                this._root = (a = b("DOM")).create("div", {
                    className: b("joinClasses")("_54nq", this._config.className, this._theme.className)
                }, a.create("div", {
                    className: "_54ng"
                }, a.create("div", {
                    className: "_54nf _54af"
                }, a.create("span", {
                    className: "_54ag"
                }))));
                this._config.behaviors && this.enableBehaviors(this._config.behaviors)
            }
            return this._root
        };
        return c
    }(b("PopoverMenuInterface"));
    Object.assign(a.prototype, b("BehaviorsMixin"), {
        _root: null
    });
    e.exports = a
}), null);
__d("LayerAutoFocusReact", ["focusWithinLayer"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            this._layer = a, this._subscription = null
        }
        var b = a.prototype;
        b.enable = function() {
            this._layer.containsReactComponent && (this._subscription = this._layer.subscribe("reactshow", this._focus.bind(this)))
        };
        b.disable = function() {
            this._subscription && (this._subscription.unsubscribe(), this._subscription = null)
        };
        b._focus = function() {
            var a = this._layer.getRoot();
            a && c("focusWithinLayer")(a)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LayerDestroyOnHide", ["setTimeout"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            this._layer = a
        }
        var b = a.prototype;
        b.enable = function() {
            var a = this._layer.destroy.bind(this._layer);
            this._subscription = this._layer.subscribe("hide", function() {
                c("setTimeout")(a, 0)
            })
        };
        b.disable = function() {
            this._subscription && (this._subscription.unsubscribe(), this._subscription = null)
        };
        return a
    }();
    Object.assign(a.prototype, {
        _subscription: null
    });
    g["default"] = a
}), 98);
__d("LayerFadeOnHide", ["invariant", "CSSFade", "Layer", "SubscriptionsHandler", "UserAgent_DEPRECATED", "clearTimeout", "emptyFunction", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g, h) {
    a = function() {
        function a(a) {
            this._layer = a, this._subscriptionsHandler = new(c("SubscriptionsHandler"))()
        }
        var b = a.prototype;
        b.enable = function() {
            if (d("UserAgent_DEPRECATED").ie() < 9) return;
            this._subscription = this._layer.subscribe("starthide", this._handleStartHide.bind(this))
        };
        b.disable = function() {
            this._subscription && (this._subscription.unsubscribe(), this._subscription = null), this._subscriptionsHandler.release()
        };
        b._getDuration = function() {
            return 150
        };
        b._handleStartHide = function() {
            var a = this,
                b = !0,
                d = c("Layer").subscribe("show", function() {
                    d.unsubscribe(), b = !1
                }),
                e = c("setTimeoutAcrossTransitions")(function() {
                    d.unsubscribe();
                    d = null;
                    var c = function() {
                        a._layer.finishHide()
                    };
                    b ? a._animate(c) : c()
                }, 0);
            this._subscriptionsHandler.addSubscriptions({
                remove: function() {
                    c("clearTimeout")(e)
                }
            });
            return !1
        };
        b._animate = function(a) {
            var b = this._layer.getRoot();
            b != null || h(0, 70);
            c("CSSFade").hide(b, {
                callback: function() {
                    a()
                },
                duration: this._getDuration()
            })
        };
        a.forDuration = function(b) {
            var d = function(b) {
                babelHelpers.inheritsLoose(a, b);

                function a() {
                    return b.apply(this, arguments) || this
                }
                return a
            }(a);
            d.prototype._getDuration = c("emptyFunction").thatReturns(b);
            return d
        };
        return a
    }();
    Object.assign(a.prototype, {
        _subscription: null
    });
    g["default"] = a
}), 98);
__d("LayerRemoveOnHide", ["DOM"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            this._layer = a
        }
        var b = a.prototype;
        b.enable = function() {
            this._subscription = this._layer.subscribe("hide", c("DOM").remove.bind(null, this._layer.getRoot()))
        };
        b.disable = function() {
            this._subscription && (this._subscription.unsubscribe(), this._subscription = null)
        };
        return a
    }();
    Object.assign(a.prototype, {
        _subscription: null
    });
    g["default"] = a
}), 98);
__d("BaseTextWithDecoration.react", ["ReactFragment", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function i(a, b, c, d) {
        var e = a[b];
        if (!e) {
            d.push(c);
            return
        }
        e(c, function(a) {
            d.push(a)
        }, function(c) {
            i(a, b + 1, c, d)
        })
    }
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.render = function() {
            var a = this.props,
                b = a.decorators;
            a = a.text;
            var c = [],
                e = {};
            i(b, 0, a, c);
            c.forEach(function(a, b) {
                e["i" + b] = a
            });
            return h.jsx("span", {
                children: d("ReactFragment").create(e)
            })
        };
        return b
    }(h.Component);
    g["default"] = a
}), 98);
__d("AbstractFBEmoji.react", ["cx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.children,
            c = a.size,
            d = a.src;
        a = a.title;
        c = {
            height: c,
            width: c,
            fontSize: c,
            backgroundImage: "url('" + d + "')"
        };
        return i.jsx("span", {
            className: "_5mfr",
            title: a,
            children: i.jsx("span", {
                style: c,
                className: "_6qdm",
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("FBEmoji.react", ["cx", "AbstractFBEmoji.react", "FBEmojiResource", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.codepoints;
        a = a.size;
        var d = b.join("");
        b = c("FBEmojiResource").fromCodepoints(b);
        b = b != null ? b.getImageURL(a) : null;
        return b == null ? i.jsx("span", {
            className: "_4ay8" + (a === 16 ? " _3kkw" : "") + (a === 18 ? " _366d" : "") + (a === 20 ? " _366e" : "") + (a === 24 ? " _48cb" : "") + (a === 28 ? " _5-0n" : "") + (a === 30 ? " _5-0o" : "") + (a === 32 ? " _5-0p" : "") + (a === 36 ? " _2oah" : "") + (a === 56 ? " _4352" : "") + (a === 112 ? " _435o" : ""),
            children: d
        }) : i.jsx(c("AbstractFBEmoji.react"), {
            size: a,
            src: b,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("FBEmoticon.react", ["fbt", "AbstractFBEmoji.react", "EmoticonsList", "FBEmojiResource", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.emoticon,
            e = a.name;
        a = a.size;
        var f = d("EmoticonsList").emoji[e];
        if (!f) return i.jsx("span", {
            children: b
        });
        f = new(c("FBEmojiResource"))(f);
        f = f.getImageURL(a);
        if (f == null) return i.jsx("span", {
            children: b
        });
        e = h._("{emoticonName} emoticon", [h._param("emoticonName", e)]);
        return i.jsx(c("AbstractFBEmoji.react"), {
            size: a,
            src: f,
            title: e,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("iterateEmoji", ["EmojiRenderer"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        var e = 0,
            f = d("EmojiRenderer").parse(a);
        f.forEach(function(d) {
            var f = d.offset;
            f > e && c(a.substr(e, f - e));
            b(d.emoji);
            e = f + d.length
        });
        c(a.substr(e, a.length - e))
    }
    g["default"] = a
}), 98);
__d("iterateEmoticons", ["EmoticonsList"], (function(a, b, c, d, e, f, g) {
    function a(a, b, c) {
        var e, f, g;
        a = a;
        while (a) {
            f = d("EmoticonsList").regexp.exec(a);
            if (f) e = f.index + f[1].length, g = a.substr(0, e), f = f[2], e = a.substr(e + f.length), c(g), b(f, d("EmoticonsList").emotes[f]), a = e;
            else break
        }
        c(a)
    }
    g["default"] = a
}), 98);
__d("TextWithEmoticons.react", ["BaseTextWithDecoration.react", "FBEmoji.react", "FBEmoticon.react", "iterateEmoji", "iterateEmoticons", "memoizeWithArgs", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function i(a, b) {
        return h.jsx(c("FBEmoji.react"), {
            codepoints: a,
            size: b
        })
    }
    i.displayName = i.name + " [from " + f.id + "]";

    function j(a, b, d) {
        return h.jsx(c("FBEmoticon.react"), {
            emoticon: a,
            name: b,
            size: d
        })
    }
    j.displayName = j.name + " [from " + f.id + "]";

    function k(a) {
        return function(b, d, e) {
            c("iterateEmoji")(b, function(b) {
                return d(i(b, a))
            }, e)
        }
    }

    function l(a) {
        return function(b, d, e) {
            c("iterateEmoticons")(b, function(b, c) {
                return d(j(b, c, a))
            }, e)
        }
    }
    var m = c("memoizeWithArgs")(function(a, b, c) {
        if (a && b) return [k(c), l(c)];
        else if (b) return [l(c)];
        else return [k(c)]
    }, function(a, b, c) {
        return a.toString() + "_" + b.toString() + "_" + c
    });
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.shouldComponentUpdate = function(a) {
            return a.text !== this.props.text || a.size !== this.props.size
        };
        d.render = function() {
            var a = this.props,
                b = a.text;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["text"]);
            if (typeof b === "string") return this.props.isWhitespace ? h.jsx("span", {
                className: "whitespace",
                children: b
            }) : h.jsx(c("BaseTextWithDecoration.react"), babelHelpers["extends"]({}, a, {
                text: b,
                decorators: [].concat(m(this.props.renderEmoji, this.props.renderEmoticons, this.props.size), this.props.decorators)
            }));
            else return h.jsx("span", {
                children: b
            })
        };
        return b
    }(h.Component);
    a.defaultProps = {
        renderEmoji: !0,
        renderEmoticons: !0,
        size: 16,
        decorators: []
    };
    g["default"] = a
}), 98);
__d("LoadObjectOperation", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["CREATING", "DELETING", "LOADING", "UPDATING"]);
    c = a;
    f["default"] = c
}), 66);
__d("LoadObject", ["invariant", "LoadObjectOperation", "immutable", "nullthrows", "shallowEqual"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = [void 0, null, !1, !0, 0, ""];
    var i = function(a, b) {
            return Object.is(a, b) || c("immutable").is(a, b)
        },
        j = "SECRET_" + Math.random(),
        k = new Map(new Map(a.map(function(a) {
            return [a, new Map([
                [!0, new Map()],
                [!1, new Map()]
            ])]
        })));
    b = c("immutable").Record({
        operation: void 0,
        value: void 0,
        error: void 0,
        internalHasValue: !1
    });
    d = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d, e, f) {
            b === j || h(0, 2084);
            return a.call(this, {
                operation: c,
                value: d,
                error: e,
                internalHasValue: f
            }) || this
        }
        b.$LoadObject1 = function(a, c, d, e) {
            var f = b.$LoadObject2(a, c, d, e);
            return f || new b(j, a, c, d, e)
        };
        b.$LoadObject2 = function(a, d, e, f) {
            if (e !== void 0 || !k.has(d)) return null;
            var g = c("nullthrows")(k.get(d));
            g = c("nullthrows")(g.get(f));
            if (!g.has(a)) {
                d = new b(j, a, d, e, f);
                g.set(a, d)
            }
            return c("nullthrows")(g.get(a))
        };
        var d = b.prototype;
        d.getOperation = function() {
            return this.get("operation")
        };
        d.getValue = function() {
            return this.get("value")
        };
        d.getValueEnforcing = function() {
            this.hasValue() || h(0, 2085);
            var a = this.getValue();
            return a
        };
        d.getError = function() {
            return this.get("error")
        };
        d.getErrorEnforcing = function() {
            this.hasError() || h(0, 2086);
            return this.get("error")
        };
        d.hasValue = function() {
            return !!this.get("internalHasValue")
        };
        d.hasOperation = function() {
            return this.getOperation() !== void 0
        };
        d.hasError = function() {
            return this.getError() !== void 0
        };
        d.isEmpty = function() {
            return !this.hasValue() && !this.hasOperation() && !this.hasError()
        };
        d.setOperation = function(a) {
            var c = b.$LoadObject2(a, this.getValue(), this.getError(), this.hasValue());
            return c || this.set("operation", a)
        };
        d.setValue = function(a) {
            var c = b.$LoadObject2(this.getOperation(), a, this.getError(), !0);
            return c || this.set("value", a).set("internalHasValue", !0)
        };
        d.setError = function(a) {
            var c = b.$LoadObject2(this.getOperation(), this.getValue(), a, this.hasValue());
            return c || this.set("error", a)
        };
        d.removeOperation = function() {
            var a = this.remove("operation"),
                c = b.$LoadObject2(a.getOperation(), a.getValue(), a.getError(), a.hasValue());
            return c || a
        };
        d.removeValue = function() {
            var a = this.remove("value").remove("internalHasValue"),
                c = b.$LoadObject2(a.getOperation(), a.getValue(), a.getError(), a.hasValue());
            return c || a
        };
        d.removeError = function() {
            var a = this.remove("error"),
                c = b.$LoadObject2(a.getOperation(), a.getValue(), a.getError(), a.hasValue());
            return c || a
        };
        d.isCreating = function() {
            return this.getOperation() === c("LoadObjectOperation").CREATING
        };
        d.isDeleting = function() {
            return this.getOperation() === c("LoadObjectOperation").DELETING
        };
        d.isDone = function() {
            return !this.hasOperation()
        };
        d.hasValueWithoutError = function() {
            return this.isDone() && this.hasValue() && !this.hasError()
        };
        d.isLoading = function() {
            return this.getOperation() === c("LoadObjectOperation").LOADING
        };
        d.isLoadingOrEmpty = function() {
            return this.isLoading() || this.isEmpty()
        };
        d.isUpdating = function() {
            return this.getOperation() === c("LoadObjectOperation").UPDATING
        };
        d.creating = function() {
            return this.setOperation(c("LoadObjectOperation").CREATING)
        };
        d.deleting = function() {
            return this.setOperation(c("LoadObjectOperation").DELETING)
        };
        d.done = function() {
            return this.removeOperation()
        };
        d.loading = function() {
            return this.setOperation(c("LoadObjectOperation").LOADING)
        };
        d.updating = function() {
            return this.setOperation(c("LoadObjectOperation").UPDATING)
        };
        d.map = function(a) {
            if (!this.hasValue()) return this;
            var c = this.getValueEnforcing();
            a = a(c);
            return a instanceof b ? a : this.setValue(a)
        };
        d.mapValue = function(a) {
            if (!this.hasValue()) return this;
            var c = this.getValueEnforcing();
            a = a(c);
            if (a instanceof b) {
                !a.hasError() && this.hasError() && (a = a.setError(this.getErrorEnforcing()));
                !a.hasOperation() && this.hasOperation() && (a = a.setOperation(this.getOperation()));
                return a
            } else return this.setValue(a)
        };
        d.mapError = function(a) {
            if (!this.hasError()) return this;
            var c = this.getErrorEnforcing();
            a = a(c);
            return a instanceof b ? a : this.setError(a)
        };
        d.match = function(a, b) {
            if (this.hasOperation()) {
                var d = a.loading;
                this.isCreating() && a.creating ? d = a.creating : this.isUpdating() && a.updating ? d = a.updating : this.isDeleting() && a.deleting && (d = a.deleting);
                return d(this.value, this.error, b)
            }
            if (this.hasError()) return this.hasValue() && a.loadedWithError ? c("nullthrows")(a.loadedWithError)(this.getValueEnforcing(), this.getErrorEnforcing(), b) : a.error(this.getErrorEnforcing(), b);
            return this.hasValue() ? a.loaded(this.getValueEnforcing(), b) : a.empty ? a.empty(b) : a.error(new Error("No value"), b)
        };
        d.equals = function(a, c) {
            return b.equals(this, a, c)
        };
        d.shallowEquals = function(a) {
            return b.equals(this, a, c("shallowEqual"))
        };
        b.equals = function(a, b, c) {
            var d = a === b;
            if (!a || !b || d) return d;
            if (a.getOperation() !== b.getOperation() || a.hasError() !== b.hasError() || a.hasValue() !== b.hasValue()) return !1;
            if (a.hasError() && b.hasError() && a.getError() === b.getError()) return !0;
            d = a.getValue();
            a = b.getValue();
            if (!d || !a) return d === a;
            c = (b = c) != null ? b : i;
            return c(d, a)
        };
        b.shallowEquals = function(a, d) {
            return b.equals(a, d, c("shallowEqual"))
        };
        b.creating = function() {
            return b.$LoadObject1(c("LoadObjectOperation").CREATING, void 0, void 0, !1)
        };
        b.deleting = function() {
            return b.$LoadObject1(c("LoadObjectOperation").DELETING, void 0, void 0, !1)
        };
        b.empty = function() {
            return b.$LoadObject1(void 0, void 0, void 0, !1)
        };
        b.loading = function() {
            return b.$LoadObject1(c("LoadObjectOperation").LOADING, void 0, void 0, !1)
        };
        b.updating = function() {
            return b.$LoadObject1(c("LoadObjectOperation").UPDATING, void 0, void 0, !1)
        };
        b.withError = function(a) {
            return b.$LoadObject1(void 0, void 0, a, !1)
        };
        b.withValue = function(a) {
            return b.$LoadObject1(void 0, a, void 0, !0)
        };
        return b
    }(b);
    g["default"] = d
}), 98);