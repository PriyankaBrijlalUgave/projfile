if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometImageIcon_DEPRECATED.react", ["BaseImage_DEPRECATED.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.auxiliary,
            d = a.size;
        d = d === void 0 ? 24 : d;
        var e = a.src,
            f = a.style;
        f = f === void 0 ? "circle" : f;
        a = a.testid;
        return h.jsxs("div", {
            className: "x1n2onr6",
            children: [h.jsx(c("BaseImage_DEPRECATED.react"), {
                className: c("stylex")(f === "circle" ? {
                    "border-top-start-radius-1": "x14yjl9h",
                    "border-top-end-radius-1": "xudhj91",
                    "border-bottom-end-radius-1": "x18nykt9",
                    "border-bottom-start-radius-1": "xww2gxu"
                } : {}, {
                    "display-1": "x1lliihq"
                }, f === "roundedRect" ? {
                    "border-top-start-radius-1": "x1lq5wgf",
                    "border-top-end-radius-1": "xgqcy7u",
                    "border-bottom-end-radius-1": "x30kzoy",
                    "border-bottom-start-radius-1": "x9jhf4c"
                } : null),
                height: d,
                src: e,
                testid: void 0,
                width: d
            }), f !== "square" ? h.jsx("div", {
                className: c("stylex")(f === "circle" ? {
                    "border-top-start-radius-1": "x14yjl9h",
                    "border-top-end-radius-1": "xudhj91",
                    "border-bottom-end-radius-1": "x18nykt9",
                    "border-bottom-start-radius-1": "xww2gxu"
                } : {}, {
                    "box-shadow-1": "xlg9a9y",
                    "position-1": "x10l6tqk",
                    "start-1": "x17qophe",
                    "top-1": "x13vifvy"
                }, f === "roundedRect" ? {
                    "border-top-start-radius-1": "x1lq5wgf",
                    "border-top-end-radius-1": "xgqcy7u",
                    "border-bottom-end-radius-1": "x30kzoy",
                    "border-bottom-start-radius-1": "x9jhf4c"
                } : null),
                style: {
                    height: d,
                    width: d
                }
            }) : null, b != null ? h.jsx("div", {
                className: "x10l6tqk xds687c x1ey2m1c",
                children: b
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("cometTypeaheadODSLogFetchNetworkEvent", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("ODS").__setRef("cometTypeaheadODSLogFetchNetworkEvent");

    function a(a, b, c) {
        b === void 0 && (b = !0);
        c === void 0 && (c = 1);
        if (!b) return;
        h.onReady(function(b) {
            b.bumpEntityKey(354, a, "fetched-network", c)
        })
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadSubscriptionDataSourceFetchResolverNetwork", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useRef,
        k = b.useState;

    function a(a) {
        var b = a.dataSource;
        a = k(!1);
        var c = a[0],
            d = a[1],
            e = j(null);
        a = h(function(a) {
            var c, f = a.onResolvePayload;
            a = a.requestParams;
            (c = e.current) == null ? void 0 : c.unsubscribe();
            e.current = b.fetchNetwork(a).subscribe({
                complete: function() {
                    d(!1)
                },
                error: function(a) {
                    d(!1)
                },
                next: function(a) {
                    return f(a)
                },
                start: function(a) {
                    d(!0)
                },
                unsubscribe: function() {
                    d(!1)
                }
            })
        }, [b]);
        i(function() {
            return function() {
                var a;
                (a = e.current) == null ? void 0 : a.unsubscribe()
            }
        }, []);
        return [{
            isLoading: c
        }, a]
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadSubscriptionDataSourceFetchResolver", ["cometTypeaheadODSLogFetchNetworkEvent", "cr:2557", "react", "recoverableViolation", "useBaseTypeaheadSubscriptionDataSourceFetchResolverNetwork", "useDebouncedComet"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useCallback,
        i = e.useEffect,
        j = e.useRef;

    function a(a, d) {
        var e = a.dataSource,
            f = a.dataSourceFetchConfigParams;
        f = f === void 0 ? {} : f;
        var g = f.requestFlow;
        f = f.shouldDebounceNetwork;
        var k = f === void 0 ? !0 : f,
            l = a.onResolvePayload;
        f = c("useBaseTypeaheadSubscriptionDataSourceFetchResolverNetwork")({
            dataSource: e
        });
        a = f[0].isLoading;
        var m = f[1],
            n = c("useDebouncedComet")(m),
            o = h(function(a, b) {
                var d = b.isTraceComplete;
                b = b.source;
                try {
                    l(a, {
                        isTraceComplete: d,
                        source: b
                    })
                } catch (a) {
                    c("recoverableViolation")("Failed to resolve fetched payload", "search")
                }
                return b
            }, [l]),
            p = j(g),
            q = h(function(a) {
                o(a, {
                    isTraceComplete: !0,
                    source: a.entries.length > 0 ? "network" : "network-no-results"
                }), c("cometTypeaheadODSLogFetchNetworkEvent") && c("cometTypeaheadODSLogFetchNetworkEvent")("comet.ta.fetch", !0, 1), b("cr:2557") && b("cr:2557")(["all"], a)
            }, [o]);
        i(function() {
            function a(a) {
                a = a.requestParams;
                var b = a.requestFlow;
                b != null && (p.current = b);
                b = {
                    onResolvePayload: q,
                    requestParams: babelHelpers["extends"]({}, a, {
                        requestFlow: p.current
                    })
                };
                Boolean(k) ? n(b) : m(b)
            }
            d != null && a(d)
        }, [m, n, d, q, k]);
        return [{
            isLoading: a
        }]
    }
    g["default"] = a
}), 98);
__d("useBaseTypeaheadSubscriptionDataSourceFetch", ["react", "recoverableViolation", "useBaseTypeaheadSubscriptionDataSourceFetchResolver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useState;

    function a(a) {
        var b = i(null),
            d = b[0],
            e = b[1];
        b = c("useBaseTypeaheadSubscriptionDataSourceFetchResolver")(a, d);
        a = b[0].isLoading;
        var f = h(function(a, b) {
            b === void 0 && (b = "all"), e({
                requestParams: a,
                source: b
            })
        }, []);
        b = h(function(a) {
            a = a || {};
            var b = a.requestFlow;
            a = a.source;
            if (d == null) {
                c("recoverableViolation")("Refetch cannot be called with undefined `fetchParams`", "search");
                return
            }
            var e = d.requestParams,
                g = e.loggingEventTrace;
            e = babelHelpers.objectWithoutPropertiesLoose(e, ["loggingEventTrace"]);
            g = babelHelpers["extends"]({
                loggingEventTrace: babelHelpers["extends"]({}, g, {
                    sequenceID: String(Date.now())
                }),
                requestFlow: b
            }, e);
            f(g, a)
        }, [f, d]);
        return [{
            isLoading: a,
            source: (a = d == null ? void 0 : d.source) != null ? a : "all"
        }, f, b]
    }
    g["default"] = a
}), 98);
__d("TypeaheadLoggingFetchRequestFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1880031");
    c = b("FalcoLoggerInternal").create("typeahead_logging_fetch_request", a);
    e.exports = c
}), null);
__d("CometTypeaheadVolumeLoggingProvider", ["TypeaheadLoggingFetchRequestFalcoEvent", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function() {
        return Math.random().toString()
    };
    a = function() {
        function a(a) {
            this.$2 = null, this.$1 = a, this.$2 = h()
        }
        var b = a.prototype;
        b.getContext = function() {
            return this.$1
        };
        b.getSessionID = function() {
            this.$2 == null && c("recoverableViolation")("Logging sessionID requested from " + this.getContext() + " surface does not exist.", "search");
            return this.$2
        };
        b.logRequest = function(a) {
            var b = {
                context: this.getContext(),
                requestType: a,
                sessionID: this.getSessionID()
            };
            c("TypeaheadLoggingFetchRequestFalcoEvent").log(function() {
                return {
                    fetchRequest: b
                }
            })
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("useCometTypeaheadVolumeLoggingProvider", ["CometTypeaheadVolumeLoggingProvider", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;

    function a(a) {
        a === void 0 && (a = "UNKNOWN");
        return h(function() {
            return new(c("CometTypeaheadVolumeLoggingProvider"))(a)
        }, [a])
    }
    g["default"] = a
}), 98);
__d("CometInternalTypeaheadSubscriptionProvider", ["CometInternalTypeaheadEmptyFetchProvider", "CometInternalTypeaheadFetchContext", "react", "useBaseTypeaheadSubscriptionDataSourceFetch", "useCometInternalTypeaheadStateDispatcher", "useCometTypeaheadVolumeLoggingProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo;

    function a(a) {
        var b = a.children,
            d = a.dataSource,
            e = a.dataSourceFetchConfigParams,
            f = a.loggingContext,
            g = a.onFetchEntries_DO_NOT_USE,
            k = a.traceProvider;
        a = c("useCometInternalTypeaheadStateDispatcher")();
        var l = a.dispatchActiveEntries,
            m = c("useCometTypeaheadVolumeLoggingProvider")(f);
        a = c("useBaseTypeaheadSubscriptionDataSourceFetch")({
            dataSource: d,
            dataSourceFetchConfigParams: e,
            onResolvePayload: i(function(a, b) {
                var c;
                a = a.entries;
                var d = b.isTraceComplete;
                b = b.source;
                l((c = a) != null ? c : []);
                m.logRequest(o);
                g && g(a);
                k && !k.isResolved() && (d && (b === "cache" && a.length >= k.getEntriesCountForVisualComplete() ? k.setEndReason("max_suggestions_reached") : b === "network" ? k.setEndReason("all_queries_completed") : b === "network-no-results" && k.setEndReason("all_queries_completed_no_network_results"), k.resolve()))
            }, [l, g, k])
        });
        f = a[0];
        var n = f.isLoading,
            o = f.source,
            p = a[1],
            q = a[2];
        d = j(function() {
            return {
                fetch: p,
                isLoading: n,
                refetch: q,
                source: o
            }
        }, [p, n, q, o]);
        return h.jsx(c("CometInternalTypeaheadFetchContext").Provider, {
            value: d,
            children: h.jsx(c("CometInternalTypeaheadEmptyFetchProvider"), {
                isLoading: n,
                source: o,
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseSubscriptionTypeahead.react", ["CometHeroInteractionContextPassthrough.react", "CometInternalTypeahead.react", "CometInternalTypeaheadStateProvider", "CometInternalTypeaheadSubscriptionProvider", "emptyFunction", "react", "useCometUniqueID", "withCometTypeaheadInputStrategyShouldQueryStringFollowHighlightedEntry"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo;

    function a(a) {
        var b = a.autoOpen;
        b = b === void 0 ? !1 : b;
        var d = a.autoFocus;
        d = d === void 0 ? !1 : d;
        var e = a.isDisabled;
        e = e === void 0 ? !1 : e;
        var f = a.errorMessage;
        f = f === void 0 ? null : f;
        var g = a.inputStrategyRenderer,
            k = a.dataSource,
            l = a.dataSourceFetchConfigParams,
            m = a.decorators,
            n = m === void 0 ? [] : m;
        m = a.emptyEntries_DO_NOT_USE;
        var o = a.id,
            p = a.label;
        p = p === void 0 ? "" : p;
        var q = a.loggingContext,
            r = a.onBackspace;
        r = r === void 0 ? c("emptyFunction") : r;
        var s = a.onBlur;
        s = s === void 0 ? c("emptyFunction") : s;
        var t = a.onChange,
            u = a.onClose;
        u = u === void 0 ? c("emptyFunction") : u;
        var v = a.onEnter;
        v = v === void 0 ? c("emptyFunction") : v;
        var w = a.onEscape;
        w = w === void 0 ? c("emptyFunction") : w;
        var x = a.onFetchEntries_DO_NOT_USE,
            y = a.onFocus;
        y = y === void 0 ? c("emptyFunction") : y;
        var z = a.onOpen;
        z = z === void 0 ? c("emptyFunction") : z;
        var A = a.onPressEntry,
            B = a.placeholder;
        B = B === void 0 ? "" : B;
        var C = a.shouldQueryStringFollowHighlightedEntry,
            D = C === void 0 ? !0 : C;
        C = a.shouldQueryStringUpdateFromSelectedEntryOnClick;
        var E = C === void 0 ? !0 : C;
        C = a.testid;
        C = C === void 0 ? "" : C;
        C = a.traceProvider;
        var F = a.inputRef,
            G = a.viewRole;
        G = G === void 0 ? "listbox" : G;
        var H = a.viewStrategyRenderer;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["autoOpen", "autoFocus", "isDisabled", "errorMessage", "inputStrategyRenderer", "dataSource", "dataSourceFetchConfigParams", "decorators", "emptyEntries_DO_NOT_USE", "id", "label", "loggingContext", "onBackspace", "onBlur", "onChange", "onClose", "onEnter", "onEscape", "onFetchEntries_DO_NOT_USE", "onFocus", "onOpen", "onPressEntry", "placeholder", "shouldQueryStringFollowHighlightedEntry", "shouldQueryStringUpdateFromSelectedEntryOnClick", "testid", "traceProvider", "inputRef", "viewRole", "viewStrategyRenderer"]);
        var I = c("useCometUniqueID")(),
            J = j(function() {
                var a = c("CometInternalTypeahead.react");
                n.forEach(function(b) {
                    var c = b.decorate;
                    b = b.params;
                    a = c(a, b)
                });
                return a
            }, [n]),
            K = i(function(a) {
                E && t(a.label), A && A(a)
            }, [t, A, E]),
            L = j(function() {
                return c("withCometTypeaheadInputStrategyShouldQueryStringFollowHighlightedEntry")(g, {
                    shouldQueryStringFollowHighlightedEntry: D
                })
            }, [g, D]);
        p = p || B;
        return h.jsx(c("CometHeroInteractionContextPassthrough.react"), {
            clear: !0,
            children: h.jsx(c("CometInternalTypeaheadStateProvider"), {
                autoOpen: b,
                emptyEntries_DO_NOT_USE: m,
                onClose: u,
                onOpen: z,
                children: h.jsx(c("CometInternalTypeaheadSubscriptionProvider"), {
                    dataSource: k,
                    dataSourceFetchConfigParams: l,
                    loggingContext: q,
                    onFetchEntries_DO_NOT_USE: x,
                    traceProvider: C,
                    children: h.jsx(J, babelHelpers["extends"]({}, a, {
                        autoFocus: d,
                        errorMessage: f,
                        id: (b = o) != null ? b : I,
                        inputRef: F,
                        inputStrategyRenderer: L,
                        isDisabled: e,
                        label: p,
                        onBackspace: r,
                        onBlur: s,
                        onChange: t,
                        onDownArrow: c("emptyFunction"),
                        onEnter: v,
                        onEscape: w,
                        onFocus: y,
                        onHighlightEntry: c("emptyFunction"),
                        onPressEntry: K,
                        onShiftTab: c("emptyFunction"),
                        onTab: c("emptyFunction"),
                        onUpArrow: c("emptyFunction"),
                        placeholder: B,
                        testid: void 0,
                        viewRole: G,
                        viewStrategyRenderer: H
                    }))
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("mwStaticSearchEntries", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        var b = h._("Search messages for \"{query_value}\"", [h._param("query_value", a)]);
        return {
            key: a,
            label: b,
            rawData: {
                displayName: b,
                id: a,
                imageUrl: "",
                isContact: !1,
                isE2e: !1,
                isEPD: !1,
                resultType: "messages",
                secondaryImageUrl: "",
                subtext: ""
            },
            type: "entry"
        }
    }
    g.createMessageSearchEntry = a
}), 98);
__d("sortMWChatSearchLocalEntries", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = {
        group: 1,
        message: 2,
        messages: 3,
        page: 4,
        user: 0
    };

    function a(a) {
        var b = {};
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            b[d.id] = (d = d.rankingScore) == null ? void 0 : d.score
        }
        return a.sort(function(a, c) {
            var d = g[a.resultType],
                e = g[c.resultType];
            if (d !== e) return d - e;
            e = (d = b[a.id]) != null ? d : 0;
            d = (a = b[c.id]) != null ? a : 0;
            return d - e
        })
    }
    f["default"] = a
}), 66);
__d("MWChatSearchTypeaheadLightspeedSubscriptionDataSource", ["FBLogger", "MAWGating.re", "MWChatSearchIssueLightspeedQuery.re", "MWChatSearchResultType", "MWChatSearchThreadCutover", "MWLSSearchIssueSearchQuerySupportedTypes.re", "MWPSearchSystem.re", "Promise", "cr:10864", "cr:3071", "createMWChatSearchTypeaheadDataEntry", "gkx", "justknobx", "mwChatSearchPayloadDecoratorRemoveExcluded", "mwChatSearchPayloadEnumerate", "mwStaticSearchEntries", "promiseDone", "qex", "relay-runtime/network/RelayObservable", "setTimeout", "sortMWChatSearchLocalEntries"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("6438");
    a = c("gkx")("4164");
    var i = a && ((e = c("qex")._("73")) != null ? e : !1),
        j = (f = c("qex")._("962")) != null ? f : a ? 10 : 0,
        k = (e = c("qex")._("963")) != null ? e : a ? 10 : 0,
        l = d("MAWGating.re").isArmadillo() && d("MAWGating.re").isTlcSearchEnabled();
    f = function() {
        function a(a) {
            var b = a.database,
                d = a.excludedIDs;
            d = d === void 0 ? [] : d;
            var e = a.lightspeedSupportedTypes;
            e = e === void 0 ? c("MWLSSearchIssueSearchQuerySupportedTypes.re").allSupportedTypes : e;
            var f = a.source;
            f = f === void 0 ? c("MWChatSearchIssueLightspeedQuery.re").Surfaces.universal : f;
            var g = a.includeRecommendations;
            g = g === void 0 ? !0 : g;
            a = a.includeGroupSearch;
            a = a === void 0 ? !1 : a;
            this.$1 = [];
            this.$5 = function() {};
            this.$1 = d;
            this.$2 = f === c("MWChatSearchIssueLightspeedQuery.re").Surfaces.omnipickerArmadillo ? c("MWLSSearchIssueSearchQuerySupportedTypes.re").armadilloSupportedTypes : e;
            this.$3 = f;
            this.$4 = b;
            this.$6 = g;
            this.$7 = a
        }
        var e = a.prototype;
        e.resolveData = function(a, b) {
            var e = this;
            b = b.map(c("createMWChatSearchTypeaheadDataEntry"));
            b = [].concat(this.$7 && a.query.length ? [d("mwStaticSearchEntries").createMessageSearchEntry(a.query)] : [], b);
            var f = [],
                g = new Set();
            for (var b = b, h = Array.isArray(b), i = 0, b = h ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var j;
                if (h) {
                    if (i >= b.length) break;
                    j = b[i++]
                } else {
                    i = b.next();
                    if (i.done) break;
                    j = i.value
                }
                j = j;
                g.has(j.key) || (f.push(j), g.add(j.key))
            }
            j = l ? f.filter(function(a) {
                var b = a.key;
                a = a.rawData;
                return a.resultType !== c("MWChatSearchResultType").USER || a.searchSource === "offline_nullstate" ? !0 : !d("MWChatSearchThreadCutover").isCutoverOpenThread(e.$4, b)
            }) : f;
            i = {
                entries: j,
                params: a
            };
            h = c("mwChatSearchPayloadDecoratorRemoveExcluded")(this.$1);
            return c("mwChatSearchPayloadEnumerate")(h(i))
        };
        e.fetchNetwork = function(a) {
            var d = this;
            this.$5();
            return c("relay-runtime/network/RelayObservable").create(function(e) {
                if (a.query.length === 0 && !d.$6) {
                    e.next({
                        entries: [],
                        params: a
                    });
                    e.complete();
                    return
                }
                if (a.query.length === 0) {
                    d.$5 = c("MWChatSearchIssueLightspeedQuery.re").requestRecommendations(d.$4, d.$2, d.$7, d.$3, a, function(b) {
                        if (c("justknobx")._("449") && b.length === 0) {
                            c("setTimeout")(function() {
                                e.next(d.resolveData(a, [])), e.complete()
                            }, 1500);
                            return
                        }
                        e.next(d.resolveData(a, b));
                        e.complete()
                    });
                    return
                }
                var f = [],
                    g = [],
                    l = !1,
                    m = !1;
                c("promiseDone")(b("Promise").allSettled([b("cr:10864") != null ? b("cr:10864").fetchResults(d.$2, d.$3, d.$7, a) : b("Promise").resolve([]), b("cr:3071") != null && (d.$3 !== c("MWChatSearchIssueLightspeedQuery.re").Surfaces.broadcast || i) ? b("cr:3071").search(a.query, d.$7) : b("Promise").resolve([])]).then(function(b) {
                    var h = b[0];
                    b = b[1];
                    h = h.status === "fulfilled" ? h.value : [];
                    b = b.status === "fulfilled" ? b.value : [];
                    b = j <= 0 ? b : b.slice(0, j);
                    h = k <= 0 ? h : h.slice(0, k);
                    f = b.concat(h);
                    f = c("sortMWChatSearchLocalEntries")(f);
                    l || e.next(d.resolveData(a, f.concat(g)))
                })["catch"](function(a) {
                    c("FBLogger")("messenger_search").catching(a).mustfix("Error performing MWChatSearchIssueMAWFTSQuery.fetchResults")
                })["finally"](function(a) {
                    m = !0
                }));
                var n = function b() {
                        if (a.query.length > 0 && c("MWPSearchSystem.re").isDone() && h && m !== !0) {
                            c("setTimeout")(b, 100);
                            return
                        }
                        e.next(d.resolveData(a, f.concat(g)));
                        e.complete()
                    },
                    o = c("MWChatSearchIssueLightspeedQuery.re").requestResults(d.$4, d.$2, d.$3, d.$7, a, function(a) {
                        g = a, n()
                    });
                d.$5 = function() {
                    o(), l = !0
                }
            })
        };
        e.setExcludedIds = function(a) {
            this.$1 = a
        };
        return a
    }();
    g["default"] = f
}), 98);
__d("MWJewelSearchSubscriptionTypeahead.react", ["fbt", "BaseSubscriptionTypeahead.react", "CometTypeaheadBackButton.react", "CometTypeaheadInputRoundedStrategy.react", "CometTypeaheadLayoutContextualStrategy.react", "LsUniversalSearchEndFalcoEvent", "LsUniversalSearchQueryChangedFalcoEvent", "LsUniversalSearchStartFalcoEvent", "MAWGating.re", "MWChatSearchIssueLightspeedQuery.re", "MWChatSearchTypeaheadLightspeedSubscriptionDataSource", "MWLSSearchIssueSearchQuerySupportedTypes.re", "MWLSThreadDisplayContext.re", "MWPSearchSystem.re", "MWSearchLogging", "UniversalSearchEndFalcoEvent", "UniversalSearchQueryChangedFalcoEvent", "UniversalSearchStartFalcoEvent", "clearTimeout", "createMWJewelSearchTypeaheadViewStrategy.react", "gkx", "react", "setTimeout", "useReStore", "uuid"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useCallback,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState,
        n = {
            searchInput: {
                marginTop: "x1xmf6yo",
                marginEnd: "x11i5rnm",
                marginBottom: "x1e56ztr",
                marginStart: "x1mh8g0r",
                paddingTop: "xexx8yu",
                paddingEnd: "x1pi30zi",
                paddingBottom: "x18d9i69",
                paddingStart: "x1swvt13"
            },
            searchView: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                boxShadow: "x1gnnqk1",
                display: "x78zum5",
                minHeight: "x1vvvjs8"
            }
        },
        o = c("createMWJewelSearchTypeaheadViewStrategy.react")(),
        p = ["1001"],
        q = c("gkx")("6395"),
        r = c("gkx")("4438"),
        s = c("gkx")("4370");

    function a(a) {
        var b = a.onBlur,
            e = a.onChange,
            f = a.onFocus,
            g = a.onPressEntry,
            t = a.onSelectFreeformQuery,
            u = babelHelpers.objectWithoutPropertiesLoose(a, ["onBlur", "onChange", "onFocus", "onPressEntry", "onSelectFreeformQuery"]);
        a = m(null);
        var v = a[0],
            w = a[1],
            x = l(null),
            y = c("useReStore")(),
            z = l(!1),
            A = c("MWLSThreadDisplayContext.re").useHook();
        a = k(function() {
            return new(c("MWChatSearchTypeaheadLightspeedSubscriptionDataSource"))({
                database: y,
                excludedIDs: [],
                includeGroupSearch: A !== "ChatTab" && c("gkx")("1902857"),
                includeRecommendations: !0,
                lightspeedSupportedTypes: c("MWLSSearchIssueSearchQuerySupportedTypes.re").allSupportedTypes,
                source: c("MWChatSearchIssueLightspeedQuery.re").Surfaces.universal
            })
        }, [y, A]);
        var B = j(function() {
                w(null), v != null && (c("LsUniversalSearchEndFalcoEvent").log(function() {
                    return {
                        end_action: 0,
                        instance_id: v,
                        recipient_ids: p
                    }
                }), s && (z.current || (x.current != null && (c("clearTimeout")(x.current), x.current = null), c("UniversalSearchEndFalcoEvent").log(function() {
                    return {
                        end_action: 8,
                        is_epd: r,
                        session_id: v,
                        transport_type: null
                    }
                }), z.current = !0))), e("")
            }, [e, v]),
            C = j(function(a) {
                var b = function() {
                    x.current != null && (c("clearTimeout")(x.current), x.current = null), g != null && g(a)
                };
                if (v == null) {
                    b();
                    return
                }
                d("MWSearchLogging").logResultSelected(v, u.queryString, a, p, z);
                b()
            }, [g, v, u.queryString]),
            D = j(function() {
                q && c("MWPSearchSystem.re").clearAll(y);
                var a = c("uuid")();
                w(a);
                z.current = !1;
                c("LsUniversalSearchStartFalcoEvent").log(function() {
                    return {
                        instance_id: a
                    }
                });
                s && (c("UniversalSearchStartFalcoEvent").log(function() {
                    return {
                        is_epd: r,
                        session_id: a
                    }
                }), c("UniversalSearchQueryChangedFalcoEvent").log(function() {
                    return {
                        query_length: "0",
                        query_string: null,
                        session_id: a
                    }
                }));
                x.current = c("setTimeout")(function() {
                    w(null), c("LsUniversalSearchEndFalcoEvent").log(function() {
                        return {
                            end_action: 3,
                            instance_id: a,
                            recipient_ids: p
                        }
                    }), s && (z.current || (c("UniversalSearchEndFalcoEvent").log(function() {
                        return {
                            end_action: 8,
                            is_epd: r,
                            session_id: a,
                            transport_type: null
                        }
                    }), z.current = !0))
                }, 3e4)
            }, [y]),
            E = j(function(a) {
                v != null && (c("LsUniversalSearchQueryChangedFalcoEvent").log(function() {
                    return {
                        instance_id: v,
                        query_string: a
                    }
                }), s && c("UniversalSearchQueryChangedFalcoEvent").log(function() {
                    return {
                        query_length: a.length.toString(),
                        query_string: a,
                        session_id: v
                    }
                })), e(a)
            }, [e, v]);
        return i.jsx(c("BaseSubscriptionTypeahead.react"), {
            dataSource: a,
            dataSourceFetchConfigParams: d("MAWGating.re").isArmadillo() ? {
                requestFlow: "network-upon-approve"
            } : void 0,
            inputExtraProps: {
                hideIconAnimation: !0,
                hideIconOnFocus: !0
            },
            inputStartContent: v ? i.jsx(c("CometTypeaheadBackButton.react"), {
                testid: void 0
            }) : null,
            inputStrategyRenderer: c("CometTypeaheadInputRoundedStrategy.react"),
            layoutStrategyRenderer: c("CometTypeaheadLayoutContextualStrategy.react"),
            loggingContext: "messenger_jewel",
            onBlur: b,
            onChange: E,
            onClose: B,
            onFocus: f,
            onOpen: D,
            onPressEntry: C,
            onSelectFreeformQuery: t,
            placeholder: h._("Search Messenger"),
            queryString: u.queryString,
            shouldHandleCloseAfterHandlePressEntry: !0,
            shouldQueryStringUpdateFromSelectedEntryOnClick: !1,
            viewStrategyRenderer: o,
            xstyles: {
                inputXStyle: n.searchInput,
                viewXStyle_DO_NOT_USE: n.searchView
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MWPSearchOfflineOpenConversations.re", ["MWPSearchOfflineOpenConversations.bs"], (function(a, b, c, d, e, f) {
    a = b("MWPSearchOfflineOpenConversations.bs").getGroupParticipantKey;
    f.getGroupParticipantKey = a;
    c = b("MWPSearchOfflineOpenConversations.bs").search;
    f.search = c;
    d = b("MWPSearchOfflineOpenConversations.bs").fetchRankingScoresKP;
    f.fetchRankingScoresKP = d
}), null);
__d("VideoPlayerIMFStateContext", ["react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = d("react").useContext,
        i = {
            stickers: []
        },
        j = b.createContext(i);
    j.displayName = "VideoPlayerIMFStateContext";
    e = j.Provider;

    function a() {
        var a = h(j);
        if (a === i) throw c("unrecoverableViolation")("useVideoPlayerIMFState is not called from a component nested under VideoPlayerRelay/VideoPlayerX.", "comet_video_player");
        return a
    }
    g.VideoPlayerIMFStateContextProvider = e;
    g.useVideoPlayerIMFState = a
}), 98);
__d("VideoPlayerSphericalMediaGyroOverlay.react", ["fbt", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        a = a.isActive;
        return i.jsx("div", {
            className: c("stylex")({
                "background-color-1": "xal61yo",
                "height-1": "x5yr21d",
                "opacity-1": "xg01cxk",
                "position-1": "x10l6tqk",
                "start-1": "xtzzx4i",
                "top-1": "xwa60dl",
                "transform-0.1": "x11lhmoz",
                "transform-style-1": "x1oyok0e",
                "transition-duration-1": "xippbsu",
                "transition-property-1": "x19991ni",
                "transition-timing-function-1": "xl405pv",
                "width-1": "xh8yej3",
                "z-index-1": "x1vjfegm"
            }, a ? {
                "opacity-1": "x1hc1fzr"
            } : null),
            children: i.jsxs("div", {
                className: "xni59qk xnrv1ok xwa60dl xtzzx4i x10l6tqk x1hc1fzr xy75621 xm0m39n x1qhh985 xcfux6l x972fbf xww2gxu x18nykt9 xudhj91 x14yjl9h xatbrnm",
                children: [i.jsxs("div", {
                    className: "xa4qsjk x1c74tu6 x1x1c4bx x1247r65 x1oyok0e x7p49u4 xndqk7f xit27t2 x10l6tqk xng8ra xww2gxu x18nykt9 xudhj91 x14yjl9h x8nt7p6 xmk2xwg xo26eqo xb2d7b1 x1xwhoib",
                    children: [i.jsx("div", {
                        className: "xa4qsjk x1c74tu6 x1x1c4bx x13w7htt xnhpnai xuuh30 xtzzx4i x10l6tqk xwa7hi xww2gxu x18nykt9 xudhj91 x14yjl9h x1q9b8am x146gacn x104e7ho xdo4eo8 x1esw782 x3zwtg"
                    }), i.jsx("div", {
                        className: "xa4qsjk x1c74tu6 x1x1c4bx x5uqrmk x1u78mur x1cb1t30 xwa60dl x10l6tqk x10c73hc xww2gxu x18nykt9 xudhj91 x14yjl9h x1q9b8am x146gacn x104e7ho xdo4eo8 x1ahlmzr xxoll9x"
                    })]
                }), i.jsx("div", {
                    className: "xa4qsjk x1c74tu6 x1x1c4bx x5uqrmk xnhpnai xuxw1ft xuuh30 x1atx4j1 xtzzx4i x10l6tqk x10wlt62 x6ikm8r xng8ra xm0m39n x1qhh985 xcfux6l x972fbf xww2gxu x18nykt9 xudhj91 x14yjl9h xi294cv",
                    children: h._("{=m0}", [h._implicitParam("=m0", i.jsx("span", {
                        className: "xnhpnai xuuh30 x2b8uid xtzzx4i x10l6tqk x1wus3qs xng8ra x1f6kntn xjb2p0i x14ctfv xm0m39n x1qhh985 xcfux6l x972fbf",
                        children: h._("360")
                    }))])
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("ZenonSDESKeyDetector", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /inline:\s*[0-9a-zA-z+/]{40}(\b|\s|$)/;

    function a(a) {
        return g.test(JSON.stringify(a))
    }
    f["default"] = a
}), 66);
__d("RtcWebUserActionsDebugFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744337");
    c = b("FalcoLoggerInternal").create("rtc_web_user_actions_debug", a);
    e.exports = c
}), null);
__d("RtcWebUserActionsFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744338");
    c = b("FalcoLoggerInternal").create("rtc_web_user_actions", a);
    e.exports = c
}), null);
__d("ZenonIceStatsParser", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = [];
        a = a.split("\r\n");
        a.forEach(function(a) {
            g(a) && b.push({
                gen: h(a),
                type: i(a)
            })
        });
        return b
    }

    function g(a) {
        return a.indexOf("candidate:") > -1
    }

    function h(a) {
        var b = 0;
        a = a.match(/generation (\d+)/);
        a && (b = parseInt(a[1], 10));
        return b
    }

    function i(a) {
        a = a.match(/typ (host|relay|srflx|prflx)/);
        if (a) return a[1];
        else return "unknown"
    }
    f.extractIceInfo = a
}), 66);
__d("RpWebInfraActionsLoggerEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744334");
    c = b("FalcoLoggerInternal").create("rp_web_infra_actions_logger_event", a);
    e.exports = c
}), null);
__d("ZenonAuditedCheckpointLogId", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["RP_ROOMS_INFRA_WWW__E2EE", "RP_ROOMS_INFRA_WWW__WASM", "RP_ROOMS_INFRA_WWW__LOGGER_INFRA"]);
    c = a;
    f["default"] = c
}), 66);
__d("ZenonInfraActionsLogger", ["Log", "ODS", "RpWebInfraActionsLoggerEventFalcoEvent", "ZenonAuditedCheckpointLogId", "formatDate", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {
                callID: void 0,
                callTrigger: void 0,
                conferenceName: void 0,
                deviceID: void 0,
                mediaPath: "sfu",
                peerID: void 0,
                serverInfoData: void 0,
                signalingID: void 0
            }, this.$2 = new Set(), this.$3 = !1, this.$4 = new Map()
        }
        var b = a.prototype;
        b.updateCachedValues = function(a) {
            Object.assign(this.$1, a)
        };
        b.setE2eeMandated = function() {
            this.$3 = !0
        };
        b.logCheckpointEmployeesTestUsersOnly = function(a) {
            if (!c("gkx")("2890") && !c("gkx")("6954")) return;
            this.logCheckpoint(a)
        };
        b.logCheckpoint = function(a) {
            this.logEvent(babelHelpers["extends"]({}, a))
        };
        b.logCheckpointOnceForDomain = function(a) {
            var b = a.checkpoint;
            this.$2.has(b) || (this.$2.add(b), this.logCheckpoint(a))
        };
        b.logError = function(a) {
            this.logEvent(babelHelpers["extends"]({}, a))
        };
        b.startTimer = function(a) {
            var b = Date.now();
            this.$4.set(a, b);
            this.logEvent({
                checkpoint: a + "_timerStart"
            })
        };
        b.stopTimer = function(a) {
            var b = this.$4.get(a);
            this.$4["delete"](a);
            b = b != null ? Date.now() - b : null;
            this.logEvent({
                checkpoint: a + "_timerEnd",
                eventTimeElapsed: b
            });
            return parseInt(b, 10)
        };
        b.logEvent = function(a) {
            if (c("gkx")("2716")) return;
            if (this.$3 && a.auditId == null) {
                var b = "Encountered an unaudited log line, dropping it.";
                a.error != null ? this.logEvent({
                    auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__LOGGER_INFRA,
                    error: b
                }) : this.logEvent({
                    auditId: c("ZenonAuditedCheckpointLogId").RP_ROOMS_INFRA_WWW__LOGGER_INFRA,
                    checkpoint: b
                });
                return
            }
            if (((b = a.checkpoint) == null ? void 0 : b.length) != null && a.checkpoint.length > 3e5) return;
            var d = {
                call_id: (b = a.callID) != null ? b : this.$1.callID == null ? void 0 : String(this.$1.callID),
                call_trigger: this.$1.callTrigger,
                call_type: (b = a.callType) != null ? b : null,
                checkpoint: a.checkpoint,
                client_session_id: this.$1.signalingID,
                client_time: Date.now().toString(),
                conference_name: (b = a.conferenceName) != null ? b : this.$1.conferenceName,
                connection: (b = a.connectionState) != null ? b : this.$1.connectionState,
                device_id: this.$1.deviceID,
                error: a.error,
                error_domain: a.errorDomain,
                event_time_elapsed: (b = a.eventTimeElapsed) == null ? void 0 : b.toString(),
                is_caller: (b = a.isCaller) != null ? b : null,
                media_path: (b = a.mediaPath) != null ? b : this.$1.mediaPath,
                message_id: a.messageID,
                peer_connection: (b = a.peerConnectionState) != null ? b : this.$1.peerConnectionState,
                peer_id: this.$1.peerID,
                sdp_format: (b = a.sdpFormat) != null ? b : null,
                server_info_data: (b = a.serverInfoData) != null ? b : this.$1.serverInfoData,
                signaling: (b = a.signalingState) != null ? b : this.$1.signalingState,
                state_machine_id: a.stateMachineID
            };
            c("RpWebInfraActionsLoggerEventFalcoEvent").log(function() {
                return d
            })
        };
        b.logCounter = function(a) {
            d("ODS").bumpEntityKey(4083, "zenon_multiway", a), d("ODS").flush()
        };
        return a
    }();
    b = new a();
    g["default"] = b
}), 98);
__d("fbwebrtc_ClientStack", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        OLD_CLIENT_PLATFORM_STACK: 0,
        RSYS_X: 1,
        IG_OLD_STACK: 2,
        MLITE_OLD_STACK: 3,
        SCOTCH: 4,
        ZENON: 5
    });
    f["default"] = a
}), 66);
__d("multiway_ApprovalStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        DENIED: 0,
        APPROVED: 1
    });
    f["default"] = a
}), 66);
__d("multiway_Capability", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        SUPPORT_AUDIO_DEPRECATED: 0,
        SUPPORT_VIDEO_DEPRECATED: 1,
        SUPPORT_EXPERIMENTS_IN_JOIN_RESPONSE: 2,
        SUPPORT_NEW_PARTICIPANT_STATES: 3,
        SUPPORT_SDP_RENEGOTIATION: 4,
        SUPPORT_MWPP: 5,
        REQUIRE_FULL_SDP_IN_SMU: 6,
        SUPPORT_PRECONNECT: 7,
        SUPPORT_MWPP_DEESCALATION: 8,
        SUPPORT_PARTICIPANT_STATE_UNCALLABLE: 9,
        SUPPORT_MULTIPLE_VIDEO_STREAMS: 10,
        REQUIRE_FULL_SDP_IN_SMU_OPTIMIZED: 11,
        SUPPORT_MULTISTREAM_FEC: 12,
        SUPPORT_DELTA_SMU: 13,
        REQUIRE_DEFAULT_CHANNEL_SCREENSHARE: 14,
        SUPPORT_SCREENSHARE_FLAG_IN_JOIN_RESPONSE_AND_SMU: 15,
        SUPPORT_TEMPORAL_LAYER_JBE: 16
    });
    f["default"] = a
}), 66);
__d("multiway_ClientEventType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        UNKNOWN: 0,
        MEDIA_CONNECTED: 1
    });
    f["default"] = a
}), 66);
__d("multiway_ConferenceType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        UNKNOWN: 0,
        GROUP: 1,
        LIVE: 3,
        MESSENGER: 5,
        ALOHA: 6,
        IGLIVE: 8,
        IGVIDEOCALL: 9,
        OCULUS: 10,
        WATCH: 13,
        GUEST: 14,
        ROOM: 15,
        DEBUGTOOL: 16,
        ROBOCALL: 17,
        DARWIN: 19,
        CRUCIBLE: 20
    });
    f["default"] = a
}), 66);
__d("multiway_DeviceStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        OK: 0,
        NOT_SUPPORTED: 1,
        IN_ANOTHER_CALL: 10
    });
    f["default"] = a
}), 66);
__d("multiway_DismissReason", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        CALL_ENDED: 0,
        ANSWERED_ON_ANOTHER_DEVICE: 1,
        IN_ANOTHER_CALL: 2,
        CONNECTION_DROPPED: 3,
        REJECTED_ON_ANOTHER_DEVICE: 4,
        REMOVED_BY_PARTICIPANT: 5,
        REJECTED_BY_CALLEE: 6,
        INTERNAL_ERROR: 7,
        CALL_ENDED_BY_PRODUCT: 9,
        JOIN_APPROVAL_DENIED: 10,
        JOIN_APPROVAL_TIMEDOUT: 11,
        UNSUPPORTED_VERSION: 12,
        LIVE_NOT_ACKED: 13,
        TX_ACK_TIMEDOUT: 14,
        ANSWERED_BY_OTHER_USER: 15,
        PARTICIPANT_SELF_TERMINATION: 16,
        PARTICIPANT_REJOIN: 17,
        LONG_LASTING_AUDIO_ISSUE: 18,
        PRIMARY_ENDPOINT_HANGUP: 19
    });
    f["default"] = a
}), 66);
__d("multiway_E2eeMode", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        E2EE_NOT_MANDATED: 0,
        DEPRECATED_NO_REQUIREMENT: 1,
        E2EE_MANDATED: 2
    });
    f["default"] = a
}), 66);
__d("multiway_EndpointServiceType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        UNKNOWN: 0,
        COMPOSITING_SERVICE: 1
    });
    f["default"] = a
}), 66);
__d("multiway_HangupReason", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        IGNORE_CALL: 0,
        HANGUP_CALL: 1,
        NO_ANSWER_TIMEOUT: 2,
        CLIENT_ERROR: 3,
        IN_ANOTHER_CALL: 4,
        CLIENT_INTERRUPTED: 5,
        SESSION_MIGRATED: 6,
        E2EE_MANDATED_BUT_OFFER_DID_NOT_CONTAIN_E2EE: 7,
        E2EE_MANDATED_BUT_ANSWER_DID_NOT_NEGOTIATE_E2EE: 8,
        WEBRTC_ERROR: 9,
        CONNECTION_DROPPED: 10
    });
    f["default"] = a
}), 66);
__d("multiway_JoinMode", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        PRIMARY: 0,
        SECONDARY: 1
    });
    f["default"] = a
}), 66);
__d("multiway_MediaPath", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        UNKNOWN: 0,
        SFU: 1,
        P2P: 2
    });
    f["default"] = a
}), 66);
__d("multiway_MediaPauseStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        NotPaused: 0,
        Paused: 1
    });
    f["default"] = a
}), 66);
__d("multiway_MessageTag", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        PRANSWER: 1001,
        INITIAL_ANSWER_TO_P2P_CALLER: 1002,
        DEESCALATE_OFFER_TO_P2P_CALLEE: 1003,
        DEESCALATE_ANSWER_TO_P2P_CALLER: 1004,
        REQUEST_DEESCALATE_TO_P2P_CALLER: 1005,
        REQUEST_ESCALATE: 1006,
        REQUEST_CLIENT_FULL_RENEGOTIATION_TO_ADMIT_FROM_WAITINGROOM: 1007,
        REQUEST_CLIENT_FULL_RENEGOTIATION_AGAINST_MWS: 1008,
        PARTICIPANT_ADDED: 1009,
        PARTICIPANT_REMOVED: 1010,
        FIRST_REMOTE_ALERTED_FOR_INITIATOR: 2001,
        FIRST_REMOTE_ANSWERED_FOR_INITIATOR: 2002,
        CONTAIN_PENDING_APPROVAL_PARTICIPANTS: 2003
    });
    f["default"] = a
}), 66);
__d("multiway_MessageType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        JOIN: 0,
        SERVER_MEDIA_UPDATE: 1,
        HANGUP: 2,
        ICE_CANDIDATE: 3,
        RING: 4,
        DISMISS: 5,
        CONFERENCE_STATE: 6,
        ADD_PARTICIPANTS: 7,
        SUBSCRIPTION: 8,
        CLIENT_MEDIA_UPDATE: 9,
        DATA_MESSAGE: 10,
        REMOVE_PARTICIPANTS: 11,
        PING: 18,
        P2P_PROTOCOL: 19,
        UPDATE: 20,
        NOTIFY: 21,
        CONNECT: 22,
        CLIENT_EVENT: 23,
        UNSUBSCRIBE: 25,
        APPROVAL: 26,
        TRANSFER: 27,
        WAKEUP: 28
    });
    f["default"] = a
}), 66);
__d("multiway_ParticipantCallState", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        UNKNOWN: 0,
        DISCONNECTED: 1,
        NO_ANSWER: 2,
        REJECTED: 3,
        UNREACHABLE: 4,
        CONNECTION_DROPPED: 5,
        CONTACTING: 6,
        RINGING: 7,
        CONNECTING: 8,
        CONNECTED: 9,
        PARTICIPANT_LIMIT_REACHED: 10,
        IN_ANOTHER_CALL: 11,
        RING_TYPE_UNSUPPORTED: 12,
        PENDING_APPROVAL: 13,
        APPROVED: 14,
        FAILED_APPROVAL: 15,
        HANGUP_IN_WAITING_ROOM: 16,
        UNCALLABLE: 17
    });
    f["default"] = a
}), 66);
__d("multiway_RingType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        GROUP_AUDIO_CALL: 0,
        PEER_VIDEO_CALL: 1,
        PEER_AUDIO_CALL: 2,
        GROUP_VIDEO_CALL: 3,
        LIVE_STREAM: 4,
        PEER_ESCALATED_VIDEO_CALL: 5,
        PEER_ESCALATED_AUDIO_CALL: 6,
        LIVE_AUDIO_ROOM: 7,
        LIVE_WITH_ROOM: 8
    });
    f["default"] = a
}), 66);
__d("multiway_RtcResponseStatusCode", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        OK: 200,
        BAD_REQUEST: 400,
        UNAUTHORIZED: 401,
        NOT_FOUND: 404,
        METHOD_NOT_ALLOWED: 406,
        CONFLICT: 409,
        CONDITIONAL_REQUEST_FAILED: 412,
        SERVER_INTERNAL_ERROR: 500,
        SERVICE_UNAVAILABLE: 503
    });
    f["default"] = a
}), 66);
__d("multiway_RtcResponseSubCode", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        UNKNOWN: 1e3,
        EXCEEDED_MAX_ALLOWED_PARTICIPANTS: 1001,
        MEMBERSHIP_CHECK_FAIL: 1002,
        CONFERENCE_THROTTLED: 1003,
        ENDPOINT_THROTTLED: 1004,
        MWS_MESSAGE_SENT_TO_INCORRECT_REGION: 1005,
        UNSUPPORTED_REQUEST_TYPE: 2e3,
        CLIENT_REQUEST_UNACCEPTABLE: 2001,
        CLIENT_RESPONSE_UNACCEPTABLE: 2002,
        RING_RESPONSE_BODY_NOT_SET: 2004,
        SERVER_MEDIA_UPDATE_RESPONSE_BODY_NOT_SET: 2005,
        INVALID_SDP: 2006,
        INVALID_CONFERENCE_NAME: 2007,
        SERVER_INFO_CONFERENCE_NAME_MISMATCH: 2008,
        INVALID_USER_ID: 2009,
        INCORRECT_VERSION_RANGE: 2010,
        SENDER_ID_MISMATCH: 2011,
        RECIPIENT_NOT_SPECIFIED: 2012,
        FIELD_NOT_ALLOWED: 2013,
        USERS_NOT_SPECIFIED: 2015,
        REQUEST_UNACCEPTABLE_FOR_ENDPOINT_STATE: 2016,
        INVALID_CALL_ID: 2017,
        SESSION_DESCRIPTION_ID_MISMATCH: 2018,
        EMPTY_CLIENT_MEDIA_UPDATES: 2019,
        INVALID_SERVER_INFO_DATA: 2020,
        INCORRECT_STATE_VERSION: 2021,
        MISMATCHED_STATE_FOR_VERSION: 2022,
        INVALID_STATE_VERSION: 2023,
        NO_RESOLVER_FOUND: 2024,
        MISSING_APPROVERLIST: 2025,
        FULL_SDP_REQUIRED_IN_APPROVED_STATE: 2026,
        INVALID_BROADCAST_ID: 2027,
        INVALID_ENDPOINT_CONFIG: 2028,
        INVALID_E2EE_STATE: 2029,
        SFU_MODE_PREVENTED: 2030,
        INVALID_CONFERENCE_STATE: 2031,
        JOIN_REQUEST_DENIED: 2032,
        MISSING_BODY_ENDPOINT: 2101,
        MISSING_BODY_HEADER: 2102,
        MISSING_BODY_BODY: 2103,
        MISSING_BODY_PARAMS: 2104,
        MISSING_BODY_REMOVE_PARTICIPANTS_REQUEST: 2105,
        MISSING_BODY_DATA_MESSAGE_REQUEST: 2106,
        MISSING_BODY_CLIENT_MEDIA_UPDATE_REQUEST: 2107,
        MISSING_BODY_ADD_PARTICIPANTS_REQUEST: 2108,
        MISSING_BODY_SUBSCRIPTION_REQUEST: 2110,
        MISSING_BODY_JOIN_REQUEST: 2111,
        MISSING_BODY_HANGUP_REQUEST: 2112,
        MISSING_BODY_ICE_CANDIDATE_REQUEST: 2113,
        MISSING_BODY_P2P_MESSAGE_REQUEST: 2114,
        MISSING_BODY_UPDATE_REQUEST: 2115,
        MISSING_BODY_CLIENT_EVENT_REQUEST: 2116,
        MISSING_BODY_CONNECT_REQUEST: 2117,
        MISSING_BODY_UNSUBSCRIBE_REQUEST: 2118,
        MISSING_BODY_APPROVAL_REQUEST: 2119,
        MISSING_ENDPOINT_USER_ID: 2120,
        EMPTY_ENDPOINT_USER_ID: 2121,
        MISSING_BODY_TRANSFER_REQUEST: 2122,
        MISSING_BODY_GENERIC: 2199,
        REQUESTOR_NOT_MEMBER_CONFERENCE: 3002,
        NOT_BROADCAST_OWNER: 3003,
        GUEST_NOT_INVITED: 3004,
        GUEST_DISCONNECTED: 3005,
        GUEST_INVITATION_EXPIRED: 3006,
        SHOULD_USE_NEW_SIGNALING_PATH: 3007,
        PARTICIPANT_IN_PENDING_APPROVAL_STATE: 3008,
        BROADCAST_ALREADY_STOPPED: 4002,
        FAILED_TO_GENERATE_SDP_ANSWER: 4003,
        FAILED_GENERATE_SESSION_DESCRIPTION: 4004,
        SDP_SESSION_ID_MISMATCH: 4005,
        MEDIA_ENDPOINT_GONE: 4007,
        MEDIA_ENDPOINT_ALREADY_EXISTS: 4008,
        MEDIA_ENDPOINT_EXISTS_DIFFERENT_SESSION_ID: 4009,
        LEGACY_MESSENGER_SENDER_UNSET: 4010,
        FAILED_TO_SET_TRANSPORT_INFO: 4011,
        NON_PRIMARY_MULTIWAY_SERVER: 4012,
        FAILED_TO_GET_REMOTE_DESCRIPTION: 4013,
        LOCAL_DESCRIPTION_NOT_SET: 4014,
        INVALID_SDP_TYPE: 4015,
        CLIENT_MEDIA_UPDATE_WITHOUT_REMOTE_SDP_INFO: 4016,
        SDP_UNSET_ON_P2P_ANSWER: 4017,
        MISSING_ICE_CANDIDATE_PAYLOAD: 4018,
        P2P_PROTOCOL_UNSET: 4019,
        CREATE_ACK_FOR_INVALID_MESSAGE_TYPE: 4020,
        LEGACY_CLIENT_CANNOT_JOIN_SFU_MODE: 4021,
        CONNECT_UNSUPPORTED_IN_SFU_MODE: 4022,
        CONNECT_UNSUPPORTED_FOR_JOINED_ENDPOINTS: 4023,
        RESOLVE_STATE_API_ERROR: 4024,
        EXTERNAL_RESOLUTION_ERROR: 4025,
        INTERNAL_RESOLUTION_ERROR: 4026,
        RESOLUTION_DISABLED: 4027,
        BROADCAST_ID_MISSING: 4028,
        SDP_UNSET_ON_P2P_OFFER: 4029,
        LIVESTREAM_INPUT_DESERIALIZATION_FAILED: 4030,
        LEGACY_OFFER_MISSING_REQUIRED_VALUE: 4031,
        MEDIA_SERVER_STATE_SYNC_DESERIALIZATION_ERROR: 4032,
        CONNECT_UNSUPPORTED_FOR_PRECONNECTED_USERS: 4033,
        OTHER_USER_ANSWERED_THE_CALL: 4034,
        MEDIA_SERVER_DESERIALIZATION_ERROR: 4035,
        REMOTE_SDP_TRACKID_MISMATCH: 4036,
        SIGNALING_MESSAGE_TO_CLIENT_DROPPED: 4037,
        DATA_CHANNEL_ENDPOINT_GONE: 4038,
        DATA_CHANNEL_ENDPOINT_ALREADY_EXISTS: 4039,
        CONFERENCE_NOT_FOUND: 5001,
        CONFERENCE_IS_TERMINATING: 5002,
        CONFERENCE_IS_TERMINATED: 5003,
        CONFERENCE_NAME_EMPTY: 5004,
        NONCE_EMPTY: 5005,
        NONCE_MISMATCH: 5006,
        CONFERENCE_HAS_GONE: 5007,
        PARTICIPANT_HAS_GONE: 5008,
        MEDIA_SERVER_NOT_FOUND: 5009,
        CLIENT_TERMINATED: 5010,
        PRECONNECT_FROM_OLDSTACK_TO_UNIFIED_NOT_SUPPORTED: 5011,
        MEDIA_CODECS_UNSUPPORTED_BY_CONFERENCE: 6001,
        CONFERENCE_INCAPABLE_RENEGOTIATION: 6002,
        REJECTING_CMU_WHEN_SMU_PENDING: 6003,
        PARTICIPANT_NOT_SUBSCRIBED_TO_TOPIC: 6004,
        PARTICIPANT_ALREADY_IN_WAITING_ROOM: 6005,
        PARTICIPANT_NOT_IN_PENDING_APPROVAL: 6006,
        USER_NOT_APPROVER_FOR_TARGET_USER: 6007,
        UNSUPPORTED_CAPABILITIES: 6008,
        PRODUCT_SERVER_DEFINED_END_REASON: 6009,
        OK: 9e3
    });
    f["default"] = a
}), 66);
__d("multiway_SubscriptionType", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        CNAME: 0,
        TRACK: 1,
        DOMINANT_SPEAKER: 2
    });
    f["default"] = a
}), 66);
__d("multiway_VideoQuality", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        LOW: 0,
        MEDIUM: 1,
        HIGH: 2,
        HD: 3,
        NUM_QUALITIES: 4
    });
    f["default"] = a
}), 66);
__d("ZenonMWMessageTypes", ["$InternalEnum", "fbwebrtc_ClientStack", "multiway_ApprovalStatus", "multiway_Capability", "multiway_ClientEventType", "multiway_ConferenceType", "multiway_DeviceStatus", "multiway_DismissReason", "multiway_E2eeMode", "multiway_EndpointServiceType", "multiway_HangupReason", "multiway_JoinMode", "multiway_MediaPath", "multiway_MediaPauseStatus", "multiway_MessageTag", "multiway_MessageType", "multiway_ParticipantCallState", "multiway_RingType", "multiway_RtcResponseStatusCode", "multiway_RtcResponseSubCode", "multiway_SubscriptionType", "multiway_VideoQuality"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = b("$InternalEnum")({
        DEFAULT_AUDIO: 0,
        DEFAULT_VIDEO: 1,
        SCREEN_AUDIO: 2,
        SCREEN_VIDEO: 3
    });
    g.ZenonMWClientStack = c("fbwebrtc_ClientStack");
    g.ZenonMWApprovalStatus = c("multiway_ApprovalStatus");
    g.ZenonMWCapability = c("multiway_Capability");
    g.ZenonMWClientEventType = c("multiway_ClientEventType");
    g.ZenonMWConferenceType = c("multiway_ConferenceType");
    g.ZenonMWDeviceStatus = c("multiway_DeviceStatus");
    g.ZenonMWDismissReason = c("multiway_DismissReason");
    g.ZenonMWE2eeMode = c("multiway_E2eeMode");
    g.ZenonMWEndpointServiceType = c("multiway_EndpointServiceType");
    g.ZenonMWHangupReason = c("multiway_HangupReason");
    g.ZenonMWMediaPath = c("multiway_MediaPath");
    g.ZenonMWJoinMode = c("multiway_JoinMode");
    g.ZenonMWMediaPauseStatus = c("multiway_MediaPauseStatus");
    g.ZenonMWMessageTag = c("multiway_MessageTag");
    g.ZenonMWSignalingPayloadType = c("multiway_MessageType");
    g.ZenonMWParticipantCallState = c("multiway_ParticipantCallState");
    g.ZenonMWRingType = c("multiway_RingType");
    g.ZenonMWResponseStatusCode = c("multiway_RtcResponseStatusCode");
    g.ZenonMWResponseSubCode = c("multiway_RtcResponseSubCode");
    g.ZenonMWSubscriptionType = c("multiway_SubscriptionType");
    g.ZenonMWVideoQuality = c("multiway_VideoQuality");
    g.ZenonMWTrackLabel = a
}), 98);
__d("ZenonMWMessageMap", ["ZenonMWMessageTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = Object.freeze((a = {}, a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.JOIN] = "JOIN", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SERVER_MEDIA_UPDATE] = "SERVER_MEDIA_UPDATE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ICE_CANDIDATE] = "ICE_CANDIDATE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.HANGUP] = "HANGUP", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.RING] = "RING", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DISMISS] = "DISMISS", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CONFERENCE_STATE] = "CONFERENCE_STATE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ADD_PARTICIPANTS] = "ADD_PARTICIPANTS", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SUBSCRIPTION] = "SUBSCRIPTION", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_MEDIA_UPDATE] = "CLIENT_MEDIA_UPDATE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DATA_MESSAGE] = "DATA_MESSAGE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.REMOVE_PARTICIPANTS] = "REMOVE_PARTICIPANTS", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.PING] = "PING", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.P2P_PROTOCOL] = "P2P_PROTOCOL", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.NOTIFY] = "NOTIFY", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CONNECT] = "CONNECT", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_EVENT] = "CLIENT_EVENT", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.UNSUBSCRIBE] = "UNSUBSCRIBE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.UPDATE] = "UPDATE", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.APPROVAL] = "APPROVAL", a[d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.WAKEUP] = "WAKEUP", a));
    c = b;
    g["default"] = c
}), 98);
__d("OverlayConfigConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        OverlayConfigNumParameters: 2522,
        OverlayConfigNotPresentFlagValue: -1
    };
    e.exports = a
}), null);
__d("OverlayConfigLayerSource", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = Object.freeze({
        UNKNOWN: 0,
        DEFAULT: 1,
        MOBILECONFIG: 2,
        APP_CRUCIBLE: 3,
        APP_JNI: 4,
        UNITTEST_CONFIG: 5,
        SERVER: 6,
        PLACEHOLDER: 7,
        LS_MOBILECONFIG: 8,
        APP_LS: 9,
        APP_JS: 10,
        BROWSER: 11,
        APP_OVRRTC: 12,
        APP_IG: 13,
        MLITE4A_LEGACY_QE: 14,
        APP_MLITE4A: 15,
        APP_PORTAL: 16,
        IG_LAUNCHER: 17,
        APP_ARCHON: 18,
        APP_WS: 19,
        APP_NOX: 20,
        APP_WEARABLE_MSNGR: 21,
        APP_WEARABLE_IG: 22,
        APP_ORCA_RSYS: 23,
        APP_WILDE: 24,
        APP_MKIOS: 25,
        APP_MK4A: 26,
        DYNAMIC: 27,
        SDK_DEFAULT: 28,
        APP_FB4A: 29,
        APP_RSYS_SDK_SAMPLE: 30,
        APP_BIZAPP: 31,
        APP_WORKCHAT: 32,
        APP_ARCHON_LOCAL_OVERRIDES: 33,
        APP_CATHODE: 34
    });
    e.exports = a
}), null);
__d("OverlayConfigServerLayer", ["OverlayConfigConstants", "OverlayConfigLayerSource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        a.createFromHeader = function(b) {
            try {
                b = b == null ? void 0 : (b = b.extensions) == null ? void 0 : b.oc1_json;
                if (b == null) return null;
                b = JSON.parse(b);
                b = b == null ? void 0 : b.values;
                return b == null ? null : new a(b)
            } catch (a) {
                return null
            }
        };

        function a(a) {
            this.$1 = a
        }
        var b = a.prototype;
        b.getLayerSource = function() {
            return c("OverlayConfigLayerSource").SERVER
        };
        b.getValue = function(a) {
            a = this.$1[String(a)];
            return a != null ? a : d("OverlayConfigConstants").OverlayConfigNotPresentFlagValue
        };
        b.logExposure = function(a) {};
        return a
    }();
    g["default"] = a
}), 98);
__d("ZenonEndCallReason", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        BREAKOUT_SESSION_SWITCH_ROOM: "BreakoutSessionSwitchRoom",
        CALL_END_ACCEPT_AFTER_HANG_UP: "CallEndAcceptAfterHangUp",
        CALLER_NOT_VISIBLE: "CallerNotVisible",
        CAMERA_PERMISSION_DENIED: "CameraPermissionDenied",
        CARRIER_BLOCKED: "CarrierBlocked",
        CLIENT_ENCRYPTION_ERROR: "ClientEncryptionError",
        CLIENT_ERROR: "ClientError",
        CLIENT_INTERRUPTED: "ClientInterrupted",
        CONNECTION_DROPPED: "ConnectionDropped",
        END_TO_END_ENCRYPTION_INVARIANT_VIOLATED: "EndToEndEncryptionInvariantViolated",
        HANGUP_CALL: "HangupCall",
        IGNORE_CALL: "IgnoreCall",
        IN_ANOTHER_CALL: "InAnotherCall",
        INACTIVE_TIMEOUT: "InactiveTimeout",
        INCOMING_TIMEOUT: "IncomingTimeout",
        MAX_ALLOWED_PARTICIPANTS_REACHED: "MaxAllowedParticipantsReached",
        MICROPHONE_PERMISSION_DENIED: "MicrophonePermissionDenied",
        NO_ANSWER_TIMEOUT: "NoAnswerTimeout",
        NO_PERMISSION: "NoPermission",
        NO_UI_SHOWN: "NoUIShown",
        OTHER_CARRIER_BLOCKED: "OtherCarrierBlocked",
        OTHER_INSTANCE_HANDLED: "OtherInstanceHandled",
        OTHER_NOT_CAPABLE: "OtherNotCapable",
        PRODUCT_SERVER_DEFINED_END_REASON: "ProductServerDefinedEndReason",
        RING_MUTED: "RingMuted",
        SESSION_MIGRATED: "SessionMigrated",
        SIGNALING_MESSAGE_FAILED: "SignalingMessageFailed",
        TX_ACK_TIMEOUT: "TxAckTimeout",
        UNEXPECTED_END_OF_CALL: "UnexpectedEndOfCall",
        UNKNOWN: "Unknown",
        VERSION_UNSUPPORTED: "VersionUnsupported",
        WEBRTC_ERROR: "WebRTCError"
    });
    c = a;
    f["default"] = c
}), 66);
__d("ZenonIncomingRingSDKTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["Hangup", "OtherDismiss"]);
    f.ZenonCancelReason = a
}), 66);
__d("ZenonMediaError", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["ConnectionClosed", "IceDisconnected", "IceFailure", "SetLocalSdpFailed", "SetRemoteSdpFailed", "RollbackSdpFailed", "UnknownError"]);
    f.ZenonMediaError = a
}), 66);
__d("ZenonDismissReason", ["$InternalEnum", "FBLogger", "ZenonIncomingRingSDKTypes", "ZenonMWMessageTypes", "ZenonMediaError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("$InternalEnum")({
        IgnoreCall: 0,
        HangupCall: 1,
        InAnotherCall: 2,
        AcceptAfterHangUp: 3,
        NoAnswerTimeout: 4,
        IncomingTimeout: 5,
        OtherInstanceHandled: 6,
        SignalingMessageFailed: 7,
        ConnectionDropped: 8,
        ClientInterrupted: 9,
        WebRTCError: 10,
        ClientError: 11,
        NoPermission: 12,
        OtherNotCapable: 13,
        NoUIShown: 14,
        VersionUnsupported: 15,
        CallerNotVisible: 16,
        CarrierBlocked: 17,
        OtherCarrierBlocked: 18,
        ClientEncryptionError: 19,
        MicrophonePermissionDenied: 20,
        CameraPermissionDenied: 21,
        SessionMigrated: 22,
        RingMuted: 23,
        JoinApprovalDenied: 24,
        RejectedByCallee: 25,
        CallEndedByProduct: 26,
        CallEnded: 27,
        AnsweredOnAnotherDevice: 28,
        RejectedOnAnotherDevice: 29,
        CallCollision: 30,
        MaxAllowedParticipantsReached: 31,
        UnexpectedEndOfCall: 32,
        TxAckTimeout: 33,
        EndToEndEncryptionInvariantViolated: 34,
        ProductServerDefinedEndReason: 35
    });

    function a(a) {
        switch (a) {
            case "BreakoutSessionSwitchRoom":
                return h.HangupCall;
            case "CallEndAcceptAfterHangUp":
                return h.AcceptAfterHangUp;
            case "CallerNotVisible":
                return h.CallerNotVisible;
            case "CarrierBlocked":
                return h.CarrierBlocked;
            case "ClientEncryptionError":
                return h.ClientEncryptionError;
            case "ClientError":
                return h.ClientError;
            case "ClientInterrupted":
                return h.ClientInterrupted;
            case "ConnectionDropped":
                return h.ConnectionDropped;
            case "HangupCall":
                return h.HangupCall;
            case "IgnoreCall":
                return h.IgnoreCall;
            case "InAnotherCall":
                return h.InAnotherCall;
            case "EndToEndEncryptionInvariantViolated":
                return h.EndToEndEncryptionInvariantViolated;
            case "InactiveTimeout":
                return h.CallEnded;
            case "IncomingTimeout":
                return h.IncomingTimeout;
            case "MaxAllowedParticipantsReached":
                return h.MaxAllowedParticipantsReached;
            case "NoAnswerTimeout":
                return h.NoAnswerTimeout;
            case "NoPermission":
                return h.NoPermission;
            case "NoUIShown":
                return h.NoUIShown;
            case "OtherCarrierBlocked":
                return h.OtherCarrierBlocked;
            case "OtherInstanceHandled":
                return h.OtherInstanceHandled;
            case "OtherNotCapable":
                return h.OtherNotCapable;
            case "SignalingMessageFailed":
                return h.SignalingMessageFailed;
            case "UnexpectedEndOfCall":
                return h.UnexpectedEndOfCall;
            case "Unknown":
                return h.CallEnded;
            case "VersionUnsupported":
                return h.VersionUnsupported;
            case "WebRTCError":
                return h.WebRTCError;
            case "MicrophonePermissionDenied":
                return h.MicrophonePermissionDenied;
            case "CameraPermissionDenied":
                return h.CameraPermissionDenied;
            case "SessionMigrated":
                return h.SessionMigrated;
            case "RingMuted":
                return h.RingMuted;
            case "TxAckTimeout":
                return h.TxAckTimeout;
            case "ProductServerDefinedEndReason":
                return h.ProductServerDefinedEndReason
        }
    }

    function e(a) {
        switch (a) {
            case h.CallEnded:
            case h.CallEndedByProduct:
            case h.HangupCall:
                return "HangupCall";
            case h.IgnoreCall:
            case h.JoinApprovalDenied:
            case h.RejectedByCallee:
                return "IgnoreCall";
            case h.InAnotherCall:
                return "InAnotherCall";
            case h.AcceptAfterHangUp:
                return "CallEndAcceptAfterHangUp";
            case h.NoAnswerTimeout:
                return "NoAnswerTimeout";
            case h.IncomingTimeout:
                return "IncomingTimeout";
            case h.AnsweredOnAnotherDevice:
            case h.CallCollision:
            case h.RejectedOnAnotherDevice:
            case h.OtherInstanceHandled:
                return "OtherInstanceHandled";
            case h.SignalingMessageFailed:
                return "SignalingMessageFailed";
            case h.ConnectionDropped:
                return "ConnectionDropped";
            case h.ClientInterrupted:
                return "ClientInterrupted";
            case h.WebRTCError:
                return "WebRTCError";
            case h.ClientError:
                return "ClientError";
            case h.NoPermission:
                return "NoPermission";
            case h.OtherNotCapable:
                return "OtherNotCapable";
            case h.NoUIShown:
                return "NoUIShown";
            case h.VersionUnsupported:
                return "VersionUnsupported";
            case h.CallerNotVisible:
                return "CallerNotVisible";
            case h.CarrierBlocked:
                return "CarrierBlocked";
            case h.OtherCarrierBlocked:
                return "OtherCarrierBlocked";
            case h.ClientEncryptionError:
                return "ClientEncryptionError";
            case h.UnexpectedEndOfCall:
                return "UnexpectedEndOfCall";
            case h.MaxAllowedParticipantsReached:
                return "MaxAllowedParticipantsReached";
            case h.MicrophonePermissionDenied:
                return "MicrophonePermissionDenied";
            case h.CameraPermissionDenied:
                return "CameraPermissionDenied";
            case h.SessionMigrated:
                return "SessionMigrated";
            case h.RingMuted:
                return "RingMuted";
            case h.TxAckTimeout:
                return "TxAckTimeout";
            case h.EndToEndEncryptionInvariantViolated:
                return "EndToEndEncryptionInvariantViolated";
            case h.ProductServerDefinedEndReason:
                return "ProductServerDefinedEndReason"
        }
        c("FBLogger")("rtc_www").mustfix("Unknown dismiss reason: %s", a);
        return "Unknown"
    }

    function f(a) {
        switch (a) {
            case h.OtherInstanceHandled:
            case h.AnsweredOnAnotherDevice:
            case h.RejectedOnAnotherDevice:
                return d("ZenonIncomingRingSDKTypes").ZenonCancelReason.OtherDismiss;
            default:
                return d("ZenonIncomingRingSDKTypes").ZenonCancelReason.Hangup
        }
    }

    function i(a) {
        switch (a) {
            case d("ZenonMediaError").ZenonMediaError.IceDisconnected:
                return h.ConnectionDropped;
            case d("ZenonMediaError").ZenonMediaError.ConnectionClosed:
                return h.HangupCall;
            case d("ZenonMediaError").ZenonMediaError.IceFailure:
            case d("ZenonMediaError").ZenonMediaError.SetLocalSdpFailed:
            case d("ZenonMediaError").ZenonMediaError.SetRemoteSdpFailed:
            case d("ZenonMediaError").ZenonMediaError.RollbackSdpFailed:
                return h.WebRTCError;
            case d("ZenonMediaError").ZenonMediaError.UnknownError:
                return h.UnexpectedEndOfCall
        }
    }

    function j(a) {
        return k[a]
    }
    var k = Object.freeze((b = {}, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.CALL_ENDED] = h.CallEnded, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.ANSWERED_ON_ANOTHER_DEVICE] = h.AnsweredOnAnotherDevice, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.IN_ANOTHER_CALL] = h.InAnotherCall, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.CONNECTION_DROPPED] = h.ConnectionDropped, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.REJECTED_ON_ANOTHER_DEVICE] = h.RejectedOnAnotherDevice, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.REJECTED_BY_CALLEE] = h.RejectedByCallee, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.CALL_ENDED_BY_PRODUCT] = h.CallEndedByProduct, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.INTERNAL_ERROR] = h.SignalingMessageFailed, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.REMOVED_BY_PARTICIPANT] = h.HangupCall, b[d("ZenonMWMessageTypes").ZenonMWDismissReason.TX_ACK_TIMEDOUT] = h.TxAckTimeout, b));
    g.ZenonDismissReason = h;
    g.endCallToDismissReason = a;
    g.dismissToEndCallReason = e;
    g.dismissReasonToCancelReason = f;
    g.mediaErrorToDismissReason = i;
    g.mwDismissToDmissReason = j
}), 98);
__d("ZenonCallsModelTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("$InternalEnum")).Mirrored(["Disconnected", "Precontacting", "Contacting", "Ringing", "PendingApproval", "Approved", "FailedApproval", "Connecting", "Connected", "Reconnecting", "ProvisionalRinging"]);
    d = a.Mirrored(["Facebook", "Instagram", "Messenger", "Guest", "WhatsApp", "Workplace"]);
    e = a.Mirrored(["New", "Connecting", "PendingApproval", "Connected", "Terminating", "Terminated"]);
    b = a.Mirrored(["Unknown", "CallsBlocked"]);
    a = a.Mirrored(["None", "PendingPeerFeedback", "Declined", "RemoteDeclined", "LocalDeclined", "Cancelled", "TimedOut", "Accepted", "InitiatedFromPeer"]);
    f.ZenonCallParticipantState = c;
    f.ZenonCallParticipantType = d;
    f.ZenonCallState = e;
    f.ZenonEndCallSubreason = b;
    f.ZenonVideoEscalationStatus = a
}), 66);
__d("ZenonParticipantState", ["$InternalEnum", "ZenonCallsModelTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("$InternalEnum")({
        UNKNOWN: 0,
        ADDING: 1,
        CONTACTING: 2,
        RINGING: 3,
        ACCEPTING: 4,
        PRECONNECTING: 5,
        CONNECTING: 6,
        CONNECTED: 7,
        REMOVING: 8,
        DISCONNECTED: 9,
        NO_ANSWER: 10,
        REJECTED: 11,
        UNREACHABLE: 12,
        CONNECTION_DROPPED: 13,
        PARTICIPANT_LIMIT_REACHED: 14,
        IN_ANOTHER_CALL: 15,
        RING_TYPE_UNSUPPORTED: 16,
        PENDING_APPROVAL: 17,
        APPROVING: 18,
        DENYING: 19,
        APPROVED: 20,
        FAILED_APPROVAL: 21,
        HANGUP_IN_WAITING_ROOM: 22,
        RECONNECTING: 23
    });

    function a(a) {
        if (a == null) return d("ZenonCallsModelTypes").ZenonCallParticipantState.Disconnected;
        switch (a) {
            case h.CONTACTING:
            case h.PRECONNECTING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Contacting;
            case h.RINGING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Ringing;
            case h.CONNECTING:
            case h.RECONNECTING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Connecting;
            case h.CONNECTED:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Connected;
            case h.PENDING_APPROVAL:
            case h.APPROVING:
            case h.DENYING:
            case h.ACCEPTING:
            case h.ADDING:
            case h.REMOVING:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.PendingApproval;
            case h.APPROVED:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Approved;
            case h.FAILED_APPROVAL:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.FailedApproval;
            case h.HANGUP_IN_WAITING_ROOM:
            case h.UNKNOWN:
            case h.DISCONNECTED:
            case h.NO_ANSWER:
            case h.REJECTED:
            case h.UNREACHABLE:
            case h.CONNECTION_DROPPED:
            case h.PARTICIPANT_LIMIT_REACHED:
            case h.IN_ANOTHER_CALL:
            case h.RING_TYPE_UNSUPPORTED:
                return d("ZenonCallsModelTypes").ZenonCallParticipantState.Disconnected
        }
        return d("ZenonCallsModelTypes").ZenonCallParticipantState.Disconnected
    }
    g.ZenonParticipantState = h;
    g.toCallParticipantState = a
}), 98);
__d("ZenonScreenShare", ["UserAgent", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a.length === 1 && ((a = a[0]) == null ? void 0 : a.contentType) === "screen"
    }

    function h() {
        return !c("UserAgent").isBrowser("Safari")
    }

    function i() {
        return !h() ? !0 : !c("gkx")("1667037")
    }

    function b(a) {
        return c("gkx")("4883") && h() ? !0 : !i() && (a == null ? void 0 : a.find(function(a) {
            return a.type === "video"
        })) != null
    }
    g.isScreenSharingTrack = a;
    g.screenShareWithReplaceTrack = i;
    g.isDualStreamScreenSharingEnabled = b
}), 98);
__d("ZenonSignalingTypes", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        OK: 0,
        REJECTED_FROM_VERSION_DOES_NOT_MATCH: 1,
        METHOD_NOT_ALLOWED: 2
    };
    b = {
        CLIENT_TERMINATED: 0
    };
    f.ZenonSignalingStatusCode = a;
    f.ZenonSignalingStatusSubCode = b
}), 66);
__d("ZenonMWTranslatorUtils", ["ChannelClientID", "CurrentUser", "OverlayConfigServerLayer", "RpWebMqttEnabledAppIds", "ZenonDismissReason", "ZenonInfraActionsLogger", "ZenonMWMessageTypes", "ZenonParticipantState", "ZenonScreenShare", "ZenonSignalingProtocol", "ZenonSignalingTypes", "err", "gkx", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = "signalingDominantSpeakerUpdate",
        j = "signalingVideoUploadUpdate",
        k = new Set(c("RpWebMqttEnabledAppIds").APP_IDS);

    function l(a) {
        var b = {
            multiwayCoreTier: "",
            multiwayWwwTier: ""
        };
        if (!c("gkx")("678350")) return b;
        b.multiwayWwwTier = t(a, "multiway_www_tier");
        b.multiwayCoreTier = t(a, "multiway_core_tier");
        return b
    }

    function a(a, b, c) {
        c === void 0 && (c = !1), a && Object.keys(a).forEach(function(d) {
            var e = a[d],
                f = e.data;
            e = e.version;
            if (f != null) {
                f = {
                    data: f,
                    eventName: "stateSyncNotifyRequest",
                    responseRequired: c,
                    topic: d,
                    version: e
                };
                b.push(f)
            }
        })
    }

    function b(a, b, d) {
        var e = {
            appId: r(),
            deviceId: c("ChannelClientID").getID(),
            userId: b.userInfo.userID
        };
        b = A(b, a);
        return {
            endpoint: e,
            jsonPayload: {
                body: d,
                header: b
            }
        }
    }

    function e(a, b, d, e, f) {
        var g = {
            appId: r(),
            deviceId: c("ChannelClientID").getID(),
            userId: b.userInfo.userID
        };
        b = B(b, a, e, f);
        return {
            endpoint: g,
            jsonPayload: {
                body: d,
                header: b
            }
        }
    }

    function f(a) {
        a = d("ZenonDismissReason").mwDismissToDmissReason(a);
        return (a = a) != null ? a : d("ZenonDismissReason").ZenonDismissReason.CallEnded
    }

    function m(a, b) {
        if (b === d("ZenonMWMessageTypes").ZenonMWResponseSubCode.EXCEEDED_MAX_ALLOWED_PARTICIPANTS) return d("ZenonDismissReason").ZenonDismissReason.MaxAllowedParticipantsReached;
        if (b === d("ZenonMWMessageTypes").ZenonMWResponseSubCode.PRODUCT_SERVER_DEFINED_END_REASON) return d("ZenonDismissReason").ZenonDismissReason.ProductServerDefinedEndReason;
        switch (a) {
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.METHOD_NOT_ALLOWED:
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.UNAUTHORIZED:
                return d("ZenonDismissReason").ZenonDismissReason.NoPermission;
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.SERVICE_UNAVAILABLE:
                return d("ZenonDismissReason").ZenonDismissReason.SignalingMessageFailed;
            case d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.OK:
                throw c("unrecoverableViolation")("Response status code is OK; should not return a dismiss reason", "rtc_www");
            default:
                c("ZenonInfraActionsLogger").logError({
                    callType: "mw",
                    error: "[ZP] Got unexpected JOIN response status: " + a + " subcode " + ((a = b) != null ? a : "[undefined]"),
                    errorDomain: "fromMWJoinResponseStatusToDismissReason"
                });
                return d("ZenonDismissReason").ZenonDismissReason.UnexpectedEndOfCall
        }
    }

    function n(a) {
        a = O[a];
        return (a = a) != null ? a : d("ZenonMWMessageTypes").ZenonMWParticipantCallState.UNKNOWN
    }

    function o(a) {
        var b = null;
        a != null && a.forEach(function(a) {
            a = (a = a.body) == null ? void 0 : a.genericMessage;
            if (a != null && a.topic === "collision_context_payload") {
                a = a.data;
                if (a != null) {
                    var c;
                    a = JSON.parse(a);
                    b = {
                        groupThreadID: (c = a.group_thread_id) != null ? c : null,
                        peerID: (c = a.peer_id) != null ? c : null,
                        serverInfoData: (c = a.server_info_data) != null ? c : null
                    }
                }
            }
        });
        return b
    }

    function p(a) {
        a = (a = a.message.body) != null ? a : {};
        var b = a.dominantSpeakerSignalingInfo,
            c = a.genericMessage;
        a = a.videoUploadSignalingInfo;
        if (c) try {
                return atob(c.data)
            } catch (a) {
                return c.data
            } else if (b) return JSON.stringify(b);
            else if (a) return JSON.stringify(a);
        return null
    }

    function q(a) {
        a = (a = a.message.body) != null ? a : {};
        var b = a.dominantSpeakerSignalingInfo,
            c = a.genericMessage;
        a = a.videoUploadSignalingInfo;
        if (c) return c.topic;
        else if (b) return i;
        else if (a) return j;
        return null
    }

    function r() {
        var a = c("CurrentUser").getAppID();
        if (a != null && (a === 936619743392459..toString() || a === 1217981644879628..toString())) return a;
        a = (a = a) != null ? a : 219994525426954..toString();
        return k.has(Number(a)) ? a : 219994525426954..toString()
    }

    function s(a) {
        a = a && a.length > 0 ? a.find(function(a) {
            return ((a = a.body) == null ? void 0 : (a = a.genericMessage) == null ? void 0 : a.topic) === "room_metadata"
        }) : null;
        if (a) {
            var b;
            b = (b = a.body) == null ? void 0 : (b = b.genericMessage) == null ? void 0 : b.data;
            if (b != null) {
                b = JSON.parse(b);
                a = (a = a.header) == null ? void 0 : a.sender;
                if (b.link_hash != null && b.room_name != null && a != null) return {
                    linkHash: b.link_hash,
                    profileURL: b.profile_url,
                    ringSubtitle: b.ring_subtitle,
                    roomName: b.room_name,
                    sender: a
                }
            }
        }
        return {}
    }

    function t(a, b) {
        b = b + "=";
        a = a.split(b);
        return a[1] ? a.pop().split("&").shift() : ""
    }

    function u(a) {
        a = a.split("\n");
        if (a.length < 2) throw c("unrecoverableViolation")("Expected SDP string with two or more lines, but got " + a.length, "rtc_www");
        a = a[1].trim();
        a = a.split(" ");
        if (a.length < 3) throw c("unrecoverableViolation")("Session line should have at least 3 tokens, but got " + a.length, "rtc_www");
        a = parseInt(a[2], 10);
        if (isNaN(a)) throw c("unrecoverableViolation")("SDP version could not be parsed as number.", "rtc_www");
        return a
    }

    function v(a) {
        return a.includes("BUNDLE 0")
    }

    function w(a, b) {
        b = c("OverlayConfigServerLayer").createFromHeader(b);
        if (b) {
            b = {
                eventName: "overlayConfigServerUpdateRequest",
                serverLayer: b
            };
            a.push(b)
        }
    }

    function x(a) {
        return a.reduce(function(a, b) {
            var c;
            c = (c = b.body) == null ? void 0 : (c = c.genericMessage) == null ? void 0 : c.topic;
            b = (b = b.body) == null ? void 0 : (b = b.genericMessage) == null ? void 0 : b.data;
            c != null && b != null && (a[c] = b);
            return a
        }, {})
    }

    function y(a) {
        var b = a.clientSessionId,
            d = a.conferenceName,
            e = a.receiver,
            f = a.receiverUserId,
            g = a.sequenceNumber,
            h = a.serverInfoData,
            i = a.transactionId;
        if (c("gkx")("1877") && f == null) throw c("err")("Incoming MW messages should have receiverUserId populated.");
        b = b;
        var j = {
            userID: "2"
        };
        e = {
            actorID: (e = e == null ? void 0 : e.actorId) != null ? e : null,
            messageID: i,
            messageTags: (e = a.messageTags) != null ? e : [],
            protocol: c("ZenonSignalingProtocol").MW,
            remoteInfo: j,
            retryCount: a.retryCount,
            roomInfo: {
                name: d
            },
            sequenceNumber: g,
            signalingID: b,
            userInfo: {
                userID: (i = f) != null ? i : "1"
            }
        };
        h != null && (e.remoteSignalingID = h);
        return e
    }

    function z(a, b) {
        return Object.keys(a).map(function(c) {
            var d = a[c];
            return {
                body: {
                    genericMessage: {
                        data: d,
                        topic: c
                    }
                },
                header: {
                    recipients: b,
                    topic_DEPRECATED: c
                }
            }
        })
    }

    function A(a, b) {
        var c = a.messageID,
            e = a.messageTags,
            f = a.remoteSignalingID,
            g = a.roomInfo,
            h = a.signalingID,
            i = l(window.location.href);
        g = {
            clientStack: d("ZenonMWMessageTypes").ZenonMWClientStack.ZENON,
            conferenceName: g.name,
            messageTags: e,
            retryCount: a.retryCount,
            sequenceNumber: a.sequenceNumber,
            transactionId: c,
            type: b
        };
        (i.multiwayCoreTier !== "" || i.multiwayWwwTier !== "") && (g.extensions = i);
        h != null && (g.clientSessionId = h);
        f != null && (g.serverInfoData = f);
        a.actorID != null && (g.sender = {
            id: a.actorID
        });
        return g
    }

    function B(a, b, c, e) {
        a = A(a, b);
        a.responseStatusCode = (b = c) != null ? b : d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.OK;
        e != null && (a.responseSubCode = e);
        return a
    }

    function C(a) {
        var b = {
                tracks: {}
            },
            c = d("ZenonScreenShare").isDualStreamScreenSharingEnabled(a.tracks);
        a.tracks.forEach(function(a) {
            var d = {
                    enabled: a.enabled,
                    name: a.name,
                    owner: a.participantID
                },
                e = c ? L(a.type) : null;
            e != null && (d.label = e);
            b.tracks[a.trackID] = d
        });
        return b
    }

    function D(a) {
        if (a == null) return null;
        switch (a) {
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_AUDIO:
                return "audio";
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_VIDEO:
                return "video";
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_AUDIO:
                return "screen_audio";
            case d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_VIDEO:
                return "screen"
        }
    }

    function E(a) {
        a = N[a];
        return (a = a) != null ? a : d("ZenonMWMessageTypes").ZenonMWDeviceStatus.OK
    }

    function F(a) {
        switch (a) {
            case d("ZenonDismissReason").ZenonDismissReason.IgnoreCall:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.IGNORE_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.HangupCall:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.HANGUP_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.NoAnswerTimeout:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.NO_ANSWER_TIMEOUT;
            case d("ZenonDismissReason").ZenonDismissReason.ClientError:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.CLIENT_ERROR;
            case d("ZenonDismissReason").ZenonDismissReason.InAnotherCall:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.IN_ANOTHER_CALL;
            case d("ZenonDismissReason").ZenonDismissReason.ClientInterrupted:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.CLIENT_INTERRUPTED;
            case d("ZenonDismissReason").ZenonDismissReason.SessionMigrated:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.SESSION_MIGRATED;
            default:
                return d("ZenonMWMessageTypes").ZenonMWHangupReason.HANGUP_CALL
        }
    }

    function G(a) {
        var b = {};
        a.tracks.forEach(function(a) {
            b[a.trackID] = a.enabled
        });
        return b
    }

    function H(a) {
        var b = {},
            c = d("ZenonScreenShare").isDualStreamScreenSharingEnabled(a.tracks);
        a.tracks.forEach(function(a) {
            var d = {
                    enabled: a.enabled
                },
                e = c ? L(a.type) : null;
            e != null && (d.label = e);
            b[a.trackID] = d
        });
        return {
            tracks: b
        }
    }

    function I(a) {
        return P[a]
    }

    function J(a) {
        return a == null ? null : Q[a]
    }

    function K(a) {
        var b = {};
        a.forEach(function(a, c) {
            b[c] = a
        });
        return b
    }

    function L(a) {
        switch (a) {
            case "audio":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_AUDIO;
            case "video":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.DEFAULT_VIDEO;
            case "screen":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_VIDEO;
            case "screen_audio":
                return d("ZenonMWMessageTypes").ZenonMWTrackLabel.SCREEN_AUDIO;
            default:
                return null
        }
    }

    function M(a, b, c) {
        c === void 0 && (c = 0);
        var d = {
            fromVersion: b,
            tracks: [],
            version: c
        };
        a != null && Object.keys(a.tracks).forEach(function(b) {
            var c = a.tracks[b];
            b = {
                enabled: c.enabled,
                name: c.name,
                participantID: c.owner,
                trackID: b,
                type: D(c.label)
            };
            d.tracks.push(b)
        });
        return d
    }
    var N = {
            IN_ANOTHER_CALL: d("ZenonMWMessageTypes").ZenonMWDeviceStatus.IN_ANOTHER_CALL,
            NOT_SUPPORTED: d("ZenonMWMessageTypes").ZenonMWDeviceStatus.NOT_SUPPORTED,
            OK: d("ZenonMWMessageTypes").ZenonMWDeviceStatus.OK
        },
        O = Object.freeze((h = {}, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.UNKNOWN] = d("ZenonParticipantState").ZenonParticipantState.UNKNOWN, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.DISCONNECTED] = d("ZenonParticipantState").ZenonParticipantState.DISCONNECTED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.NO_ANSWER] = d("ZenonParticipantState").ZenonParticipantState.NO_ANSWER, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.REJECTED] = d("ZenonParticipantState").ZenonParticipantState.REJECTED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.UNREACHABLE] = d("ZenonParticipantState").ZenonParticipantState.UNREACHABLE, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.CONNECTION_DROPPED] = d("ZenonParticipantState").ZenonParticipantState.CONNECTION_DROPPED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.CONTACTING] = d("ZenonParticipantState").ZenonParticipantState.CONTACTING, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.RINGING] = d("ZenonParticipantState").ZenonParticipantState.RINGING, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.CONNECTING] = d("ZenonParticipantState").ZenonParticipantState.CONNECTING, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.CONNECTED] = d("ZenonParticipantState").ZenonParticipantState.CONNECTED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.PARTICIPANT_LIMIT_REACHED] = d("ZenonParticipantState").ZenonParticipantState.PARTICIPANT_LIMIT_REACHED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.IN_ANOTHER_CALL] = d("ZenonParticipantState").ZenonParticipantState.IN_ANOTHER_CALL, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.RING_TYPE_UNSUPPORTED] = d("ZenonParticipantState").ZenonParticipantState.RING_TYPE_UNSUPPORTED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.PENDING_APPROVAL] = d("ZenonParticipantState").ZenonParticipantState.PENDING_APPROVAL, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.APPROVED] = d("ZenonParticipantState").ZenonParticipantState.APPROVED, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.FAILED_APPROVAL] = d("ZenonParticipantState").ZenonParticipantState.FAILED_APPROVAL, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.UNCALLABLE] = d("ZenonParticipantState").ZenonParticipantState.UNREACHABLE, h[d("ZenonMWMessageTypes").ZenonMWParticipantCallState.HANGUP_IN_WAITING_ROOM] = d("ZenonParticipantState").ZenonParticipantState.HANGUP_IN_WAITING_ROOM, h)),
        P = Object.freeze((h = {}, h[d("ZenonSignalingTypes").ZenonSignalingStatusCode.OK] = d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.OK, h[d("ZenonSignalingTypes").ZenonSignalingStatusCode.REJECTED_FROM_VERSION_DOES_NOT_MATCH] = d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.CONDITIONAL_REQUEST_FAILED, h[d("ZenonSignalingTypes").ZenonSignalingStatusCode.METHOD_NOT_ALLOWED] = d("ZenonMWMessageTypes").ZenonMWResponseStatusCode.METHOD_NOT_ALLOWED, h)),
        Q = Object.freeze((h = {}, h[d("ZenonSignalingTypes").ZenonSignalingStatusSubCode.CLIENT_TERMINATED] = d("ZenonMWMessageTypes").ZenonMWResponseSubCode.CLIENT_TERMINATED, h));
    g.addDevTierOverridesToHeaderExtensions = l;
    g.addStateStoreSignalingEvents = a;
    g.createMWRequest = b;
    g.createMWResponse = e;
    g.fromMWDismissReason = f;
    g.fromMWJoinResponseStatusToDismissReason = m;
    g.fromMWParticipantState = n;
    g.getCollisionContextFromAppMessages = o;
    g.getGenericDataMessageData = p;
    g.getGenericDataMessageTopic = q;
    g.getMWAppID = r;
    g.getRoomMetadataFromAppMessages = s;
    g.getSandboxingTierFromURIOrEmpty = t;
    g.getSdpVersion = u;
    g.isUnifiedPlan = v;
    g.maybeAddOverlayConfigServerUpdateRequest = w;
    g.mwAppMessagesToSignalingAppMessages = x;
    g.mwMessageHeaderToSignalingMessageHeader = y;
    g.signalingMessageAppMessagesToMWAppMessages = z;
    g.toMWClientMediaStatus = C;
    g.toMWClientTrackContentType = D;
    g.toMWDeviceStatus = E;
    g.toMWHangupReason = F;
    g.toMWMediaStatus = G;
    g.toMWMediaStatusEx = H;
    g.toMWResponseStatusCode = I;
    g.toMWResponseStatusSubCode = J;
    g.toMWSyncStateStore = K;
    g.toMWTrackLabel = L;
    g.toZenonMediaStates = M
}), 98);
__d("ZenonMachineToQPLEvent", ["qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        ConnectionStateMachine: c("qpl")._(64243854, "2452"),
        ParentSignalingClient: c("qpl")._(64234815, "1094"),
        PeerConnectionStateMachine: c("qpl")._(64239068, "6172"),
        SignalingStateMachine: c("qpl")._(64245348, "8823")
    };
    g["default"] = a
}), 98);
__d("ZenonDebugLogger", ["ChannelClientID", "CurrentUser", "FBLogger", "Log", "LogHistory", "ODS", "QuickLogActionType", "QuickPerformanceLogger", "RpWebStateMachineLoggingBlocklist", "UserAgentData", "ZenonIceStatsParser", "ZenonInfraActionsLogger", "ZenonMWMessageMap", "ZenonMWMessageTypes", "ZenonMWTranslatorUtils", "ZenonMachineToQPLEvent", "formatDate", "gkx", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;
    a = function() {
        a.getInstance = function() {
            h || (h = new a());
            return h
        };
        a.getFBLogger = function(a) {
            var b;
            a === void 0 && (a = {});
            return c("FBLogger")("rpweb").addMetadata("RT_WEB", "CALL_ID", "" + ((b = a.callID) != null ? b : "null")).addMetadata("RT_WEB", "PEER_ID", "" + ((b = a.peerID) != null ? b : "null"))
        };

        function a() {
            this.$1 = d("LogHistory").getInstance("webrtc");
            this.$2 = d("ChannelClientID").getID();
            this.$3 = JSON.stringify({
                browser: c("UserAgentData").browserName,
                browser_version: c("UserAgentData").browserFullVersion,
                device: c("UserAgentData").deviceName,
                msg_source: "web",
                os: c("UserAgentData").platformName,
                os_version: c("UserAgentData").platformFullVersion,
                version: 2
            });
            var a = c("CurrentUser").getAppID();
            a != null && (a === 936619743392459..toString() || a === 1217981644879628..toString()) ? this.$4 = parseInt(a) : this.$4 = 219994525426954;
            this.$5 = new Set(c("RpWebStateMachineLoggingBlocklist").EVENT_TYPES);
            this.$6 = new Set(c("RpWebStateMachineLoggingBlocklist").STATES);
            this.$7 = new Set(c("RpWebStateMachineLoggingBlocklist").MESSAGE_TYPES)
        }
        var b = a.prototype;
        b.$8 = function(a, b, d) {
            b === void 0 && (b = !0);
            var e = c("formatDate")(new Date(), "[H:i:s:X]", {
                skipPatternLocalization: !0
            });
            this.$1.log("Console", e + " " + a);
            b && c("ZenonInfraActionsLogger").logCheckpoint({
                checkpoint: "[ZP] " + a,
                messageID: d
            })
        };
        b.$9 = function(a, b, d) {
            var e = c("formatDate")(new Date(), "[H:i:s:X]", {
                skipPatternLocalization: !0
            });
            this.$1.log("Console", e + " " + a + ". StateMachineID:  " + ((e = b) != null ? e : ""));
            e = {
                checkpoint: "[ZP] " + a + ".",
                stateMachineID: b
            };
            d != null && (e.messageID = d);
            c("ZenonInfraActionsLogger").logCheckpoint(e)
        };
        b.$10 = function(a, b, d, e) {
            e === void 0 && (e = 0);
            a = c("ZenonMachineToQPLEvent") == null ? void 0 : c("ZenonMachineToQPLEvent")[a];
            if (!a || !c("QuickPerformanceLogger") || !c("QuickLogActionType")) return;
            d === "terminated" ? c("QuickPerformanceLogger").markerEnd(a, 2, e) : c("QuickPerformanceLogger").markerPoint(a, b, {
                data: {
                    string: {
                        data: d
                    }
                },
                instanceKey: e
            })
        };
        b.$11 = function(a) {
            return isNaN(+a) ? 0 : +a
        };
        b.$12 = function(a) {
            a = a.jsonPayload.header;
            return a.responseStatusCode != null
        };
        b.getLogHistory = function() {
            return this.$1
        };
        b.logStateMachine = function(a, b, d, e, f) {
            if (!c("gkx")("2890")) return;
            if (this.$5.has(d)) return;
            var g = "[" + a + "] [Current State: " + b + "] Processing event: " + d;
            g = {
                checkpoint: "" + g,
                stateMachineID: e
            };
            f != null && (g.messageID = f);
            c("ZenonInfraActionsLogger").logCheckpoint(g);
            this.$10(a, d, b, this.$11(e))
        };
        b.logStateMachineTransition = function(a, b, d, e, f, g, h, i) {
            if (this.$6.has(d) || this.$5.has(f)) return;
            if (!c("gkx")("2890")) return;
            g != null && g.length === 1 && g[0].type === "defer" ? g = "[" + a + "] [[DEFERRED] " + f + " did not trigger transition. Current state remains " + d : d !== e ? g = "[" + a + "] [[PROCESSED] " + f + " caused transition from " + (e || "") + " to " + d + "." : b ? g = "[" + a + "] [[PROCESSED] " + f + " did not trigger transition. Current state remains " + d : g = "[" + a + "] [[DROPPED] " + f + " did not trigger transition. Current state remains " + d;
            this.$9(g, h, i)
        };
        b.logMWMessage = function(a, b, e) {
            this.$13(a, b, e);
            var f = e.jsonPayload.header;
            if (f.type === d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.JOIN) {
                if (!c("QuickPerformanceLogger") || !c("QuickLogActionType")) return;
                this.$12(e) ? (c("QuickPerformanceLogger").markerPoint(c("qpl")._(41156609, "943"), "signaling_mw_join_response_recv", {
                    instanceKey: this.$11(f.clientSessionId)
                }), c("QuickPerformanceLogger").markerEnd(c("qpl")._(41156609, "943"), 2, this.$11(f.clientSessionId))) : (c("QuickPerformanceLogger").markerStart(c("qpl")._(41156609, "943"), this.$11(f.clientSessionId)), c("QuickPerformanceLogger").markerPoint(c("qpl")._(41156609, "943"), "signaling_mw_join_req_sent", {
                    instanceKey: this.$11(f.clientSessionId)
                }))
            }
            if (e.jsonPayload == null || !c("gkx")("2890")) return;
            var g = c("ZenonMWMessageMap")[f.type],
                h = this.$12(e) ? "RESPONSE" : "REQUEST";
            e = this.$14(e);
            a = "[ms] " + a + " [" + b + "] " + g + " " + h + " [retryCount: " + f.retryCount + (e != null ? " details: " + e : "") + "]";
            this.$7.has(g) || this.$8(a, !0, f.transactionId)
        };
        b.startQPL = function(a, b) {
            b === void 0 && (b = 0), c("QuickPerformanceLogger") && c("QuickPerformanceLogger").markerStart(a, this.$11(b))
        };
        b.endQPL = function(a, b) {
            b === void 0 && (b = 0), c("QuickPerformanceLogger") && c("QuickLogActionType") && c("QuickPerformanceLogger").markerEnd(a, 2, this.$11(b))
        };
        b.$13 = function(a, b, c) {
            a = this.$15(a, b, c);
            a !== null && d("ODS").bumpEntityKey(4083, "zenon_signaling", a)
        };
        b.$15 = function(a, b, e) {
            if (e.jsonPayload == null) return null;
            var f = e.jsonPayload,
                g = f.body;
            f = f.header;
            var h = "";
            switch (f.type) {
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.DATA_MESSAGE:
                    if (g.dataMessageRequest) {
                        h = (g = d("ZenonMWTranslatorUtils").getGenericDataMessageTopic(g.dataMessageRequest)) != null ? g : "undefined"
                    }
                    break
            }
            g = this.$12(e) ? "response" : "request";
            e = c("ZenonMWMessageMap")[f.type];
            if (h === "") return a + "-" + b + "-" + e + "-" + g;
            else return a + "-" + b + "-" + e + "-" + g + "-" + h
        };
        b.$14 = function(a) {
            if (a.jsonPayload == null) return null;
            var b = a.jsonPayload,
                c = b.body;
            b = b.header;
            switch (b.type) {
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.JOIN:
                    if (this.$12(a)) {
                        var e;
                        return JSON.stringify({
                            hasAnswer: ((e = c.joinResponse) == null ? void 0 : e.answer) != null,
                            hasRenegotiationOffer: ((e = c.joinResponse) == null ? void 0 : e.renegotiationOffer) != null,
                            isPendingApproval: (e = c.joinResponse) == null ? void 0 : e.isPendingApproval,
                            multipleVideoStreamsAllowed: (e = c.joinResponse) == null ? void 0 : e.multipleVideoStreamsAllowed,
                            statusCode: b.responseStatusCode,
                            subCode: b.responseSubCode
                        })
                    }
                    return JSON.stringify({
                        deviceCapabilities: (e = c.joinRequest) == null ? void 0 : e.deviceCapabilities,
                        sdpType: ((e = c.joinRequest) == null ? void 0 : e.offer) != null ? "offer" : ((e = c.joinRequest) == null ? void 0 : e.answer) != null ? "answer" : "null",
                        userCapabilities: (e = c.joinRequest) == null ? void 0 : e.userCapabilities
                    });
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SERVER_MEDIA_UPDATE:
                    if (this.$12(a)) {
                        return JSON.stringify({
                            currentVersion: (e = c.serverMediaUpdateResponse) == null ? void 0 : e.currentVersion,
                            hasAnswer: ((e = c.serverMediaUpdateResponse) == null ? void 0 : e.answer) != null,
                            statusCode: b.responseStatusCode
                        })
                    }
                    return JSON.stringify({
                        fromVersion: (e = c.serverMediaUpdateRequest) == null ? void 0 : e.fromVersion,
                        messageTags: b.messageTags,
                        renegotiationRequested: (e = (e = c.serverMediaUpdateRequest) == null ? void 0 : e.renegotiationRequested) != null ? e : !1,
                        sdpType: ((e = c.serverMediaUpdateRequest) == null ? void 0 : e.offer) ? "offer" : ((e = c.serverMediaUpdateRequest) == null ? void 0 : e.answer) ? "answer" : ((e = c.serverMediaUpdateRequest) == null ? void 0 : e.update) ? "delta" : "empty",
                        toVersion: (e = (e = c.serverMediaUpdateRequest) == null ? void 0 : e.toVersion) != null ? e : ""
                    });
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.CLIENT_MEDIA_UPDATE:
                    if (this.$12(a)) {
                        return JSON.stringify({
                            currentVersion: (e = (e = c.clientMediaUpdateResponse) == null ? void 0 : e.currentVersion) != null ? e : "",
                            statusCode: b.responseStatusCode
                        })
                    }
                    return JSON.stringify({
                        fromVersion: (b = (e = c.clientMediaUpdateRequest) == null ? void 0 : e.fromVersion) != null ? b : "",
                        toVersion: (b = (e = c.clientMediaUpdateRequest) == null ? void 0 : e.toVersion) != null ? b : ""
                    });
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.SUBSCRIPTION:
                    return this.$12(a) ? null : JSON.stringify({
                        subscriptions: (b = (e = c.subscriptionRequest) == null ? void 0 : e.subscriptions) != null ? b : ""
                    });
                case d("ZenonMWMessageTypes").ZenonMWSignalingPayloadType.ICE_CANDIDATE:
                    if (this.$12(a)) return null;
                    b = (e = c.iceCandidateRequest) == null ? void 0 : e.iceCandidateSdps.map(function(a) {
                        a = a.candidateSdpString;
                        if (a != null) return d("ZenonIceStatsParser").extractIceInfo(a)
                    });
                    return JSON.stringify({
                        iceCandidates: b
                    });
                default:
                    return null
            }
        };
        b.logConsole = function(a) {
            this.$8(a, !1)
        };
        b.logMQTTStateChange = function(a) {
            var b = "mqtt_client_state_" + a;
            c("ZenonInfraActionsLogger").logCounter(b);
            c("gkx")("2890") && c("ZenonInfraActionsLogger").logCheckpoint({
                checkpoint: "[ZP] onMQTTStateChanged: " + a + ", document.visibility: " + document.visibilityState + ", document.hasFocus: " + String(document.hasFocus()) + ", navigator.onLine: " + String(navigator.onLine)
            })
        };
        b.logMQTTConnectStats = function(a, b) {
            c("ZenonInfraActionsLogger").logCheckpoint({
                checkpoint: "[ZP] MQTT Connection time: " + String(a) + "ms, Retry Count: " + String(b)
            })
        };
        b.logSendMultiwayMessageFailure = function(a, b) {
            d("ODS").bumpEntityKey(4083, "zenon_multiway", "send_message_failure"), d("ODS").flush(), c("ZenonInfraActionsLogger").logCheckpoint({
                checkpoint: "Failed to send MW message of type " + b + ". Error msg: " + a + ":"
            })
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("ZenonUserActionLogger", ["RtcWebUserActionsDebugFalcoEvent", "RtcWebUserActionsFalcoEvent", "ZenonDebugLogger", "ZenonSDESKeyDetector", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map(),
        i = window.location.hostname.search("facebook") !== -1 ? "facebook" : window.location.hostname.search("messenger") !== -1 ? "messenger_dot_com" : null,
        j = {
            logCheckpoint: function(a) {
                j.logEvent(babelHelpers["extends"]({}, a, {
                    event: "checkpoint"
                }))
            },
            logClick: function(a) {
                j.logEvent(babelHelpers["extends"]({}, a, {
                    event: "tap"
                }))
            },
            logError: function(a) {
                j.logEvent(babelHelpers["extends"]({}, a, {
                    event: "error"
                }))
            },
            logEvent: function(a) {
                var b;
                if (c("ZenonSDESKeyDetector")(a)) throw c("unrecoverableViolation")("ZenonUserActionLogger event contains SDES crypto key! This log entry must be removed!", "rtc_www");
                b = babelHelpers["extends"]({}, a, {
                    page: (b = a.page) != null ? b : i
                });
                var d = babelHelpers["extends"]({}, b, {
                    client_time: Date.now().toString()
                });
                c("RtcWebUserActionsDebugFalcoEvent").log(function() {
                    return d
                });
                c("RtcWebUserActionsFalcoEvent").log(function() {
                    return d
                });
                c("ZenonDebugLogger").getInstance().getLogHistory().log((a = a.event) != null ? a : "null", JSON.stringify(b))
            },
            logImpression: function(a) {
                j.logEvent(babelHelpers["extends"]({}, a, {
                    event: "impression"
                }))
            },
            logPreCallClick: function(a) {
                j.logEvent(babelHelpers["extends"]({}, a, {
                    event: "tap"
                }))
            },
            logPreCallImpression: function(a) {
                j.logEvent(babelHelpers["extends"]({}, a, {
                    event: "impression"
                }))
            },
            startTimer: function(a) {
                var b = Date.now();
                h = h.set(a, b);
                j.logCheckpoint({
                    checkpoint: a + "_timerStart"
                })
            },
            stopTimer: function(a) {
                var b = a.checkpointName === void 0 ? a.timerName : a.checkpointName,
                    c = a.event || {},
                    d = function(a) {
                        var b = h.get(a);
                        if (b != null) {
                            h["delete"](a);
                            return parseInt(Date.now() - b, 10)
                        }
                        return null
                    };
                d = d(a.timerName);
                j.logCheckpoint(babelHelpers["extends"]({}, c, {
                    checkpoint: b + "_timerEnd",
                    event_time_elapsed: d == null ? void 0 : d.toString()
                }));
                return parseInt(d, 10)
            }
        };
    f.exports = j
}), 34);
__d("ZenonCallFalcoEventUtils", ["performanceNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
        return String(Math.trunc(a))
    };
    a = function() {
        return h(c("performanceNow")())
    };
    b = function(a) {
        return h((a = a) != null ? a : 0)
    };
    d = function(a) {
        return a == null ? null : h((a = a) != null ? a : 0)
    };
    e = function(a) {
        return (a = a) != null ? a : ""
    };
    g.truncateNumber = h;
    g.performanceNowParsed = a;
    g.nonNullIntNumber = b;
    g.intNumberOrNull = d;
    g.nonNullString = e
}), 98);
__d("ZenonPeerID", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "MW_PEER_ID";

    function a(a) {
        a.length > 0 || h(0, 33504);
        if (a === "MW_PEER_ID") return i;
        isNaN(a) === !1 || h(0, 33551, a);
        return a
    }

    function b(a) {
        return isNaN(a) || a === i ? null : a
    }
    g.ZenonMWPeerID = i;
    g.convertStringToPeerID = a;
    g.convertPeerIDForLogging = b
}), 98);
__d("ZenonSignalingProtocolUtils", ["ZenonSignalingProtocol"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Set([c("ZenonSignalingProtocol").MW, c("ZenonSignalingProtocol").MWPP]);
    a = {
        isMwSupportedProtocol: function(a) {
            return h.has(a)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("ZenonCallInfoManager", ["ChannelClientID", "ZenonPeerID", "ZenonSignalingProtocolUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            var b = a.callID,
                e = a.callTrigger,
                f = a.conferenceName,
                g = a.isCaller,
                h = a.isVideo,
                i = a.localCallID,
                j = a.peerID,
                k = a.protocol,
                l = a.serverInfoData;
            a = a.signalingID;
            a = a === void 0 ? "" : a;
            var m = d("ChannelClientID").getID();
            f = {
                callID: b,
                callTrigger: (e = e) != null ? e : "",
                conferenceName: (e = f) != null ? e : "",
                deviceID: m,
                isCaller: g,
                isVideo: h,
                localCallID: i,
                peerID: j,
                protocol: k,
                signalingID: a
            };
            this.$1 = babelHelpers["extends"]({}, f, {
                serverInfoData: l
            });
            e = c("ZenonSignalingProtocolUtils").isMwSupportedProtocol(k) && l != null ? l : b;
            this.$2 = babelHelpers["extends"]({}, f, {
                peerID: d("ZenonPeerID").convertPeerIDForLogging(j),
                sharedCallId: e
            })
        }
        var b = a.prototype;
        b.setDeviceID = function(a) {
            this.$1.deviceID = a, this.$2.deviceID = a
        };
        b.getParsedCallInfo = function() {
            return this.$2
        };
        b.getCallInfo = function() {
            return this.$1
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("E2eeMetricsSerializers", ["ThriftTypes"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function() {
            return {}
        },
        h = function() {
            return {}
        };
    a = function() {
        return {
            p2p_e2ee: g(),
            group_e2ee: h()
        }
    };
    var i = function(a, c) {
            c.writeStructBegin("P2pE2eeMetrics");
            a.engine_type != null && (c.writeFieldBegin({
                fname: "engine_type",
                ftype: b("ThriftTypes").I32,
                fid: 1
            }), c.writeI32(a.engine_type), c.writeFieldEnd());
            a.status != null && (c.writeFieldBegin({
                fname: "status",
                ftype: b("ThriftTypes").I32,
                fid: 2
            }), c.writeI32(a.status), c.writeFieldEnd());
            a.version != null && (c.writeFieldBegin({
                fname: "version",
                ftype: b("ThriftTypes").I32,
                fid: 3
            }), c.writeI32(a.version), c.writeFieldEnd());
            a.gen_prekey_bundle_time_ms != null && (c.writeFieldBegin({
                fname: "gen_prekey_bundle_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 4
            }), c.writeI32(a.gen_prekey_bundle_time_ms), c.writeFieldEnd());
            a.encrypted_msg_time_ms != null && (c.writeFieldBegin({
                fname: "encrypted_msg_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 5
            }), c.writeI32(a.encrypted_msg_time_ms), c.writeFieldEnd());
            a.decrypted_msg_time_ms != null && (c.writeFieldBegin({
                fname: "decrypted_msg_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 6
            }), c.writeI32(a.decrypted_msg_time_ms), c.writeFieldEnd());
            a.process_sdp_crypto_time_ms != null && (c.writeFieldBegin({
                fname: "process_sdp_crypto_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 7
            }), c.writeI32(a.process_sdp_crypto_time_ms), c.writeFieldEnd());
            a.create_crypto_offer_time_ms != null && (c.writeFieldBegin({
                fname: "create_crypto_offer_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 8
            }), c.writeI32(a.create_crypto_offer_time_ms), c.writeFieldEnd());
            a.create_crypto_answer_time_ms != null && (c.writeFieldBegin({
                fname: "create_crypto_answer_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 9
            }), c.writeI32(a.create_crypto_answer_time_ms), c.writeFieldEnd());
            a.get_ik_time_ms != null && (c.writeFieldBegin({
                fname: "get_ik_time_ms",
                ftype: b("ThriftTypes").I32,
                fid: 10
            }), c.writeI32(a.get_ik_time_ms), c.writeFieldEnd());
            a.peer_id != null && (c.writeFieldBegin({
                fname: "peer_id",
                ftype: b("ThriftTypes").I32,
                fid: 11
            }), c.writeI32(a.peer_id), c.writeFieldEnd());
            a.peer_connection_index != null && (c.writeFieldBegin({
                fname: "peer_connection_index",
                ftype: b("ThriftTypes").I32,
                fid: 12
            }), c.writeI32(a.peer_connection_index), c.writeFieldEnd());
            a.srtp_crypto_suite != null && (c.writeFieldBegin({
                fname: "srtp_crypto_suite",
                ftype: b("ThriftTypes").I32,
                fid: 13
            }), c.writeI32(a.srtp_crypto_suite), c.writeFieldEnd());
            a.engine_error != null && (c.writeFieldBegin({
                fname: "engine_error",
                ftype: b("ThriftTypes").I32,
                fid: 14
            }), c.writeI32(a.engine_error), c.writeFieldEnd());
            a.libsignal_error != null && (c.writeFieldBegin({
                fname: "libsignal_error",
                ftype: b("ThriftTypes").I32,
                fid: 15
            }), c.writeI32(a.libsignal_error), c.writeFieldEnd());
            a.identity_key_mode != null && (c.writeFieldBegin({
                fname: "identity_key_mode",
                ftype: b("ThriftTypes").I32,
                fid: 16
            }), c.writeI32(a.identity_key_mode), c.writeFieldEnd());
            a.identity_key_num_persistent != null && (c.writeFieldBegin({
                fname: "identity_key_num_persistent",
                ftype: b("ThriftTypes").I32,
                fid: 17
            }), c.writeI32(a.identity_key_num_persistent), c.writeFieldEnd());
            a.identity_key_num_validated != null && (c.writeFieldBegin({
                fname: "identity_key_num_validated",
                ftype: b("ThriftTypes").I32,
                fid: 18
            }), c.writeI32(a.identity_key_num_validated), c.writeFieldEnd());
            a.identity_key_num_saved != null && (c.writeFieldBegin({
                fname: "identity_key_num_saved",
                ftype: b("ThriftTypes").I32,
                fid: 19
            }), c.writeI32(a.identity_key_num_saved), c.writeFieldEnd());
            a.identity_key_num_existing != null && (c.writeFieldBegin({
                fname: "identity_key_num_existing",
                ftype: b("ThriftTypes").I32,
                fid: 20
            }), c.writeI32(a.identity_key_num_existing), c.writeFieldEnd());
            a.is_e2ee_mandated != null && (c.writeFieldBegin({
                fname: "is_e2ee_mandated",
                ftype: b("ThriftTypes").I32,
                fid: 21
            }), c.writeI32(a.is_e2ee_mandated), c.writeFieldEnd());
            a.local_trace_id != null && (c.writeFieldBegin({
                fname: "local_trace_id",
                ftype: b("ThriftTypes").I32,
                fid: 22
            }), c.writeI32(a.local_trace_id), c.writeFieldEnd());
            a.remote_trace_id != null && (c.writeFieldBegin({
                fname: "remote_trace_id",
                ftype: b("ThriftTypes").I32,
                fid: 23
            }), c.writeI32(a.remote_trace_id), c.writeFieldEnd());
            a.local_device_id != null && (c.writeFieldBegin({
                fname: "local_device_id",
                ftype: b("ThriftTypes").I32,
                fid: 24
            }), c.writeI32(a.local_device_id), c.writeFieldEnd());
            a.remote_device_id != null && (c.writeFieldBegin({
                fname: "remote_device_id",
                ftype: b("ThriftTypes").I32,
                fid: 25
            }), c.writeI32(a.remote_device_id), c.writeFieldEnd());
            if (a.events != null) {
                c.writeFieldBegin({
                    fname: "events",
                    ftype: b("ThriftTypes").LIST,
                    fid: 26
                });
                c.writeListBegin({
                    etype: b("ThriftTypes").I32,
                    size: a.events.length
                });
                for (var a = a.events, d = Array.isArray(a), e = 0, a = d ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= a.length) break;
                        f = a[e++]
                    } else {
                        e = a.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    c.writeI32(f)
                }
                c.writeListEnd();
                c.writeFieldEnd()
            }
            c.writeFieldStop();
            c.writeStructEnd()
        },
        j = function(a, c) {
            c.writeStructBegin("GroupE2eeMetrics");
            a.received_key_message_counter != null && (c.writeFieldBegin({
                fname: "received_key_message_counter",
                ftype: b("ThriftTypes").I64,
                fid: 1
            }), c.writeI64(BigInt(a.received_key_message_counter)), c.writeFieldEnd());
            a.sent_key_message_counter != null && (c.writeFieldBegin({
                fname: "sent_key_message_counter",
                ftype: b("ThriftTypes").I64,
                fid: 2
            }), c.writeI64(BigInt(a.sent_key_message_counter)), c.writeFieldEnd());
            a.cached_key_message_counter != null && (c.writeFieldBegin({
                fname: "cached_key_message_counter",
                ftype: b("ThriftTypes").I64,
                fid: 3
            }), c.writeI64(BigInt(a.cached_key_message_counter)), c.writeFieldEnd());
            a.used_cached_key_counter != null && (c.writeFieldBegin({
                fname: "used_cached_key_counter",
                ftype: b("ThriftTypes").I64,
                fid: 4
            }), c.writeI64(BigInt(a.used_cached_key_counter)), c.writeFieldEnd());
            a.unused_smu_counter != null && (c.writeFieldBegin({
                fname: "unused_smu_counter",
                ftype: b("ThriftTypes").I64,
                fid: 5
            }), c.writeI64(BigInt(a.unused_smu_counter)), c.writeFieldEnd());
            a.missing_key_message_counter != null && (c.writeFieldBegin({
                fname: "missing_key_message_counter",
                ftype: b("ThriftTypes").I64,
                fid: 6
            }), c.writeI64(BigInt(a.missing_key_message_counter)), c.writeFieldEnd());
            a.negotiate_off_status != null && (c.writeFieldBegin({
                fname: "negotiate_off_status",
                ftype: b("ThriftTypes").I64,
                fid: 7
            }), c.writeI64(BigInt(a.negotiate_off_status)), c.writeFieldEnd());
            a.cipher_suite_status != null && (c.writeFieldBegin({
                fname: "cipher_suite_status",
                ftype: b("ThriftTypes").I64,
                fid: 8
            }), c.writeI64(BigInt(a.cipher_suite_status)), c.writeFieldEnd());
            a.decrypt_used_cached_session_counter != null && (c.writeFieldBegin({
                fname: "decrypt_used_cached_session_counter",
                ftype: b("ThriftTypes").I64,
                fid: 9
            }), c.writeI64(BigInt(a.decrypt_used_cached_session_counter)), c.writeFieldEnd());
            a.encrypt_used_cached_session_counter != null && (c.writeFieldBegin({
                fname: "encrypt_used_cached_session_counter",
                ftype: b("ThriftTypes").I64,
                fid: 10
            }), c.writeI64(BigInt(a.encrypt_used_cached_session_counter)), c.writeFieldEnd());
            a.sent_ack_message_counter != null && (c.writeFieldBegin({
                fname: "sent_ack_message_counter",
                ftype: b("ThriftTypes").I64,
                fid: 11
            }), c.writeI64(BigInt(a.sent_ack_message_counter)), c.writeFieldEnd());
            a.reuse_ackd_uid_counter != null && (c.writeFieldBegin({
                fname: "reuse_ackd_uid_counter",
                ftype: b("ThriftTypes").I64,
                fid: 12
            }), c.writeI64(BigInt(a.reuse_ackd_uid_counter)), c.writeFieldEnd());
            a.total_uids_created_counter != null && (c.writeFieldBegin({
                fname: "total_uids_created_counter",
                ftype: b("ThriftTypes").I64,
                fid: 13
            }), c.writeI64(BigInt(a.total_uids_created_counter)), c.writeFieldEnd());
            a.generate_chain_key_failed_error != null && (c.writeFieldBegin({
                fname: "generate_chain_key_failed_error",
                ftype: b("ThriftTypes").I64,
                fid: 14
            }), c.writeI64(BigInt(a.generate_chain_key_failed_error)), c.writeFieldEnd());
            a.set_chain_key_failed_error != null && (c.writeFieldBegin({
                fname: "set_chain_key_failed_error",
                ftype: b("ThriftTypes").I64,
                fid: 15
            }), c.writeI64(BigInt(a.set_chain_key_failed_error)), c.writeFieldEnd());
            a.key_provider_not_found_error != null && (c.writeFieldBegin({
                fname: "key_provider_not_found_error",
                ftype: b("ThriftTypes").I64,
                fid: 16
            }), c.writeI64(BigInt(a.key_provider_not_found_error)), c.writeFieldEnd());
            a.key_message_parse_failed_error != null && (c.writeFieldBegin({
                fname: "key_message_parse_failed_error",
                ftype: b("ThriftTypes").I64,
                fid: 17
            }), c.writeI64(BigInt(a.key_message_parse_failed_error)), c.writeFieldEnd());
            a.empty_pkb_result_error != null && (c.writeFieldBegin({
                fname: "empty_pkb_result_error",
                ftype: b("ThriftTypes").I64,
                fid: 18
            }), c.writeI64(BigInt(a.empty_pkb_result_error)), c.writeFieldEnd());
            a.empty_encrypt_result_error != null && (c.writeFieldBegin({
                fname: "empty_encrypt_result_error",
                ftype: b("ThriftTypes").I64,
                fid: 19
            }), c.writeI64(BigInt(a.empty_encrypt_result_error)), c.writeFieldEnd());
            a.empty_decrypt_result_error != null && (c.writeFieldBegin({
                fname: "empty_decrypt_result_error",
                ftype: b("ThriftTypes").I64,
                fid: 20
            }), c.writeI64(BigInt(a.empty_decrypt_result_error)), c.writeFieldEnd());
            a.empty_version_error != null && (c.writeFieldBegin({
                fname: "empty_version_error",
                ftype: b("ThriftTypes").I64,
                fid: 21
            }), c.writeI64(BigInt(a.empty_version_error)), c.writeFieldEnd());
            a.unsupported_version_error != null && (c.writeFieldBegin({
                fname: "unsupported_version_error",
                ftype: b("ThriftTypes").I64,
                fid: 22
            }), c.writeI64(BigInt(a.unsupported_version_error)), c.writeFieldEnd());
            a.midcall_version_change_error != null && (c.writeFieldBegin({
                fname: "midcall_version_change_error",
                ftype: b("ThriftTypes").I64,
                fid: 23
            }), c.writeI64(BigInt(a.midcall_version_change_error)), c.writeFieldEnd());
            a.inconsistent_remote_maps_error != null && (c.writeFieldBegin({
                fname: "inconsistent_remote_maps_error",
                ftype: b("ThriftTypes").I64,
                fid: 24
            }), c.writeI64(BigInt(a.inconsistent_remote_maps_error)), c.writeFieldEnd());
            a.key_message_pkb_mismatch_error != null && (c.writeFieldBegin({
                fname: "key_message_pkb_mismatch_error",
                ftype: b("ThriftTypes").I64,
                fid: 25
            }), c.writeI64(BigInt(a.key_message_pkb_mismatch_error)), c.writeFieldEnd());
            a.no_key_or_ack_in_e2ee_message_error != null && (c.writeFieldBegin({
                fname: "no_key_or_ack_in_e2ee_message_error",
                ftype: b("ThriftTypes").I64,
                fid: 26
            }), c.writeI64(BigInt(a.no_key_or_ack_in_e2ee_message_error)), c.writeFieldEnd());
            a.receiver_key_provider_not_found_error != null && (c.writeFieldBegin({
                fname: "receiver_key_provider_not_found_error",
                ftype: b("ThriftTypes").I64,
                fid: 27
            }), c.writeI64(BigInt(a.receiver_key_provider_not_found_error)), c.writeFieldEnd());
            a.pkb_parse_failed_error != null && (c.writeFieldBegin({
                fname: "pkb_parse_failed_error",
                ftype: b("ThriftTypes").I64,
                fid: 28
            }), c.writeI64(BigInt(a.pkb_parse_failed_error)), c.writeFieldEnd());
            a.message_deserialized_failed_error != null && (c.writeFieldBegin({
                fname: "message_deserialized_failed_error",
                ftype: b("ThriftTypes").I64,
                fid: 29
            }), c.writeI64(BigInt(a.message_deserialized_failed_error)), c.writeFieldEnd());
            a.decrypt_no_identity_key_and_cached_session_not_used_error != null && (c.writeFieldBegin({
                fname: "decrypt_no_identity_key_and_cached_session_not_used_error",
                ftype: b("ThriftTypes").I64,
                fid: 30
            }), c.writeI64(BigInt(a.decrypt_no_identity_key_and_cached_session_not_used_error)), c.writeFieldEnd());
            a.encrypt_no_identity_key_and_cached_session_not_used_error != null && (c.writeFieldBegin({
                fname: "encrypt_no_identity_key_and_cached_session_not_used_error",
                ftype: b("ThriftTypes").I64,
                fid: 31
            }), c.writeI64(BigInt(a.encrypt_no_identity_key_and_cached_session_not_used_error)), c.writeFieldEnd());
            a.decrypt_ack_wrong_message_error != null && (c.writeFieldBegin({
                fname: "decrypt_ack_wrong_message_error",
                ftype: b("ThriftTypes").I64,
                fid: 32
            }), c.writeI64(BigInt(a.decrypt_ack_wrong_message_error)), c.writeFieldEnd());
            a.invalid_uid_received_error != null && (c.writeFieldBegin({
                fname: "invalid_uid_received_error",
                ftype: b("ThriftTypes").I64,
                fid: 33
            }), c.writeI64(BigInt(a.invalid_uid_received_error)), c.writeFieldEnd());
            a.ack_for_absent_user != null && (c.writeFieldBegin({
                fname: "ack_for_absent_user",
                ftype: b("ThriftTypes").I64,
                fid: 34
            }), c.writeI64(BigInt(a.ack_for_absent_user)), c.writeFieldEnd());
            a.uid_not_awaiting_ack_error != null && (c.writeFieldBegin({
                fname: "uid_not_awaiting_ack_error",
                ftype: b("ThriftTypes").I64,
                fid: 35
            }), c.writeI64(BigInt(a.uid_not_awaiting_ack_error)), c.writeFieldEnd());
            a.decrypt_ack_error != null && (c.writeFieldBegin({
                fname: "decrypt_ack_error",
                ftype: b("ThriftTypes").I64,
                fid: 36
            }), c.writeI64(BigInt(a.decrypt_ack_error)), c.writeFieldEnd());
            a.empty_decrypt_result_ack_error != null && (c.writeFieldBegin({
                fname: "empty_decrypt_result_ack_error",
                ftype: b("ThriftTypes").I64,
                fid: 37
            }), c.writeI64(BigInt(a.empty_decrypt_result_ack_error)), c.writeFieldEnd());
            a.decrypt_ack_cached_session_not_used_error != null && (c.writeFieldBegin({
                fname: "decrypt_ack_cached_session_not_used_error",
                ftype: b("ThriftTypes").I64,
                fid: 38
            }), c.writeI64(BigInt(a.decrypt_ack_cached_session_not_used_error)), c.writeFieldEnd());
            a.encrypt_ack_error != null && (c.writeFieldBegin({
                fname: "encrypt_ack_error",
                ftype: b("ThriftTypes").I64,
                fid: 39
            }), c.writeI64(BigInt(a.encrypt_ack_error)), c.writeFieldEnd());
            a.empty_encrypt_result_ack_error != null && (c.writeFieldBegin({
                fname: "empty_encrypt_result_ack_error",
                ftype: b("ThriftTypes").I64,
                fid: 40
            }), c.writeI64(BigInt(a.empty_encrypt_result_ack_error)), c.writeFieldEnd());
            a.invalid_message_type_error != null && (c.writeFieldBegin({
                fname: "invalid_message_type_error",
                ftype: b("ThriftTypes").I64,
                fid: 41
            }), c.writeI64(BigInt(a.invalid_message_type_error)), c.writeFieldEnd());
            a.server_state_deserialized_failed_error != null && (c.writeFieldBegin({
                fname: "server_state_deserialized_failed_error",
                ftype: b("ThriftTypes").I64,
                fid: 42
            }), c.writeI64(BigInt(a.server_state_deserialized_failed_error)), c.writeFieldEnd());
            a.crypto_engine_failure_error != null && (c.writeFieldBegin({
                fname: "crypto_engine_failure_error",
                ftype: b("ThriftTypes").I64,
                fid: 43
            }), c.writeI64(BigInt(a.crypto_engine_failure_error)), c.writeFieldEnd());
            a.empty_e2ee_client_state_error != null && (c.writeFieldBegin({
                fname: "empty_e2ee_client_state_error",
                ftype: b("ThriftTypes").I64,
                fid: 44
            }), c.writeI64(BigInt(a.empty_e2ee_client_state_error)), c.writeFieldEnd());
            a.group_e2ee_negotiated != null && (c.writeFieldBegin({
                fname: "group_e2ee_negotiated",
                ftype: b("ThriftTypes").I64,
                fid: 45
            }), c.writeI64(BigInt(a.group_e2ee_negotiated)), c.writeFieldEnd());
            a.negotiation_mode_kn != null && (c.writeFieldBegin({
                fname: "negotiation_mode_kn",
                ftype: b("ThriftTypes").I64,
                fid: 46
            }), c.writeI64(BigInt(a.negotiation_mode_kn)), c.writeFieldEnd());
            a.group_e2ee_setup_status != null && (c.writeFieldBegin({
                fname: "group_e2ee_setup_status",
                ftype: b("ThriftTypes").I64,
                fid: 47
            }), c.writeI64(BigInt(a.group_e2ee_setup_status)), c.writeFieldEnd());
            a.enable_group_e2ee != null && (c.writeFieldBegin({
                fname: "enable_group_e2ee",
                ftype: b("ThriftTypes").I64,
                fid: 48
            }), c.writeI64(BigInt(a.enable_group_e2ee)), c.writeFieldEnd());
            a.identity_key_mode_group != null && (c.writeFieldBegin({
                fname: "identity_key_mode_group",
                ftype: b("ThriftTypes").I64,
                fid: 49
            }), c.writeI64(BigInt(a.identity_key_mode_group)), c.writeFieldEnd());
            a.identity_key_num_persistent_group != null && (c.writeFieldBegin({
                fname: "identity_key_num_persistent_group",
                ftype: b("ThriftTypes").I64,
                fid: 50
            }), c.writeI64(BigInt(a.identity_key_num_persistent_group)), c.writeFieldEnd());
            a.identity_key_num_validated_group != null && (c.writeFieldBegin({
                fname: "identity_key_num_validated_group",
                ftype: b("ThriftTypes").I64,
                fid: 51
            }), c.writeI64(BigInt(a.identity_key_num_validated_group)), c.writeFieldEnd());
            a.identity_key_num_saved_group != null && (c.writeFieldBegin({
                fname: "identity_key_num_saved_group",
                ftype: b("ThriftTypes").I64,
                fid: 52
            }), c.writeI64(BigInt(a.identity_key_num_saved_group)), c.writeFieldEnd());
            a.identity_key_num_existing_group != null && (c.writeFieldBegin({
                fname: "identity_key_num_existing_group",
                ftype: b("ThriftTypes").I64,
                fid: 53
            }), c.writeI64(BigInt(a.identity_key_num_existing_group)), c.writeFieldEnd());
            a.max_key_message_latency_ms != null && (c.writeFieldBegin({
                fname: "max_key_message_latency_ms",
                ftype: b("ThriftTypes").I64,
                fid: 54
            }), c.writeI64(BigInt(a.max_key_message_latency_ms)), c.writeFieldEnd());
            a.max_key_message_latency_ms_joiner != null && (c.writeFieldBegin({
                fname: "max_key_message_latency_ms_joiner",
                ftype: b("ThriftTypes").I64,
                fid: 55
            }), c.writeI64(BigInt(a.max_key_message_latency_ms_joiner)), c.writeFieldEnd());
            a.max_smu_to_key_message_latency_ms != null && (c.writeFieldBegin({
                fname: "max_smu_to_key_message_latency_ms",
                ftype: b("ThriftTypes").I64,
                fid: 56
            }), c.writeI64(BigInt(a.max_smu_to_key_message_latency_ms)), c.writeFieldEnd());
            a.process_smu_time_ms != null && (c.writeFieldBegin({
                fname: "process_smu_time_ms",
                ftype: b("ThriftTypes").I64,
                fid: 57
            }), c.writeI64(BigInt(a.process_smu_time_ms)), c.writeFieldEnd());
            a.decryption_total_frames != null && (c.writeFieldBegin({
                fname: "decryption_total_frames",
                ftype: b("ThriftTypes").I64,
                fid: 58
            }), c.writeI64(BigInt(a.decryption_total_frames)), c.writeFieldEnd());
            a.decryption_total_error_frames != null && (c.writeFieldBegin({
                fname: "decryption_total_error_frames",
                ftype: b("ThriftTypes").I64,
                fid: 59
            }), c.writeI64(BigInt(a.decryption_total_error_frames)), c.writeFieldEnd());
            a.decryption_error_frames_alloc != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_alloc",
                ftype: b("ThriftTypes").I64,
                fid: 60
            }), c.writeI64(BigInt(a.decryption_error_frames_alloc)), c.writeFieldEnd());
            a.decryption_error_frames_invalid_params != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_invalid_params",
                ftype: b("ThriftTypes").I64,
                fid: 61
            }), c.writeI64(BigInt(a.decryption_error_frames_invalid_params)), c.writeFieldEnd());
            a.decryption_error_frames_cipher != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_cipher",
                ftype: b("ThriftTypes").I64,
                fid: 62
            }), c.writeI64(BigInt(a.decryption_error_frames_cipher)), c.writeFieldEnd());
            a.decryption_error_frames_parse != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_parse",
                ftype: b("ThriftTypes").I64,
                fid: 63
            }), c.writeI64(BigInt(a.decryption_error_frames_parse)), c.writeFieldEnd());
            a.decryption_error_frames_invalid_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_invalid_key",
                ftype: b("ThriftTypes").I64,
                fid: 64
            }), c.writeI64(BigInt(a.decryption_error_frames_invalid_key)), c.writeFieldEnd());
            a.decryption_error_frames_missing_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_missing_key",
                ftype: b("ThriftTypes").I64,
                fid: 65
            }), c.writeI64(BigInt(a.decryption_error_frames_missing_key)), c.writeFieldEnd());
            a.decryption_error_frames_out_of_ratchet_space != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_out_of_ratchet_space",
                ftype: b("ThriftTypes").I64,
                fid: 66
            }), c.writeI64(BigInt(a.decryption_error_frames_out_of_ratchet_space)), c.writeFieldEnd());
            a.decryption_error_frames_cipher_auth != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_cipher_auth",
                ftype: b("ThriftTypes").I64,
                fid: 67
            }), c.writeI64(BigInt(a.decryption_error_frames_cipher_auth)), c.writeFieldEnd());
            a.decryption_error_frames_frame_too_old != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_frame_too_old",
                ftype: b("ThriftTypes").I64,
                fid: 68
            }), c.writeI64(BigInt(a.decryption_error_frames_frame_too_old)), c.writeFieldEnd());
            a.decryption_error_frames_seen_frame != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_seen_frame",
                ftype: b("ThriftTypes").I64,
                fid: 69
            }), c.writeI64(BigInt(a.decryption_error_frames_seen_frame)), c.writeFieldEnd());
            a.decryption_error_frames_invalid_frame != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_invalid_frame",
                ftype: b("ThriftTypes").I64,
                fid: 70
            }), c.writeI64(BigInt(a.decryption_error_frames_invalid_frame)), c.writeFieldEnd());
            a.decryption_error_frames_setting_invalid_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_setting_invalid_key",
                ftype: b("ThriftTypes").I64,
                fid: 71
            }), c.writeI64(BigInt(a.decryption_error_frames_setting_invalid_key)), c.writeFieldEnd());
            a.decryption_error_frames_setting_existing_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_setting_existing_key",
                ftype: b("ThriftTypes").I64,
                fid: 72
            }), c.writeI64(BigInt(a.decryption_error_frames_setting_existing_key)), c.writeFieldEnd());
            a.decryption_error_frames_escape_data != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_escape_data",
                ftype: b("ThriftTypes").I64,
                fid: 73
            }), c.writeI64(BigInt(a.decryption_error_frames_escape_data)), c.writeFieldEnd());
            a.decryption_error_frames_deescape_data != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_deescape_data",
                ftype: b("ThriftTypes").I64,
                fid: 74
            }), c.writeI64(BigInt(a.decryption_error_frames_deescape_data)), c.writeFieldEnd());
            a.decryption_error_frames_parse_frame_or_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_parse_frame_or_key",
                ftype: b("ThriftTypes").I64,
                fid: 75
            }), c.writeI64(BigInt(a.decryption_error_frames_parse_frame_or_key)), c.writeFieldEnd());
            a.decryption_error_frames_unknown != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_unknown",
                ftype: b("ThriftTypes").I64,
                fid: 76
            }), c.writeI64(BigInt(a.decryption_error_frames_unknown)), c.writeFieldEnd());
            a.decryption_unencrypted_frames != null && (c.writeFieldBegin({
                fname: "decryption_unencrypted_frames",
                ftype: b("ThriftTypes").I64,
                fid: 77
            }), c.writeI64(BigInt(a.decryption_unencrypted_frames)), c.writeFieldEnd());
            a.encryption_total_frames != null && (c.writeFieldBegin({
                fname: "encryption_total_frames",
                ftype: b("ThriftTypes").I64,
                fid: 78
            }), c.writeI64(BigInt(a.encryption_total_frames)), c.writeFieldEnd());
            a.encryption_error_frames != null && (c.writeFieldBegin({
                fname: "encryption_error_frames",
                ftype: b("ThriftTypes").I64,
                fid: 79
            }), c.writeI64(BigInt(a.encryption_error_frames)), c.writeFieldEnd());
            a.encryption_escape_bytes != null && (c.writeFieldBegin({
                fname: "encryption_escape_bytes",
                ftype: b("ThriftTypes").I64,
                fid: 80
            }), c.writeI64(BigInt(a.encryption_escape_bytes)), c.writeFieldEnd());
            a.encryption_total_error_frames != null && (c.writeFieldBegin({
                fname: "encryption_total_error_frames",
                ftype: b("ThriftTypes").I64,
                fid: 81
            }), c.writeI64(BigInt(a.encryption_total_error_frames)), c.writeFieldEnd());
            a.encryption_error_frames_alloc != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_alloc",
                ftype: b("ThriftTypes").I64,
                fid: 82
            }), c.writeI64(BigInt(a.encryption_error_frames_alloc)), c.writeFieldEnd());
            a.encryption_error_frames_invalid_params != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_invalid_params",
                ftype: b("ThriftTypes").I64,
                fid: 83
            }), c.writeI64(BigInt(a.encryption_error_frames_invalid_params)), c.writeFieldEnd());
            a.encryption_error_frames_cipher != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_cipher",
                ftype: b("ThriftTypes").I64,
                fid: 84
            }), c.writeI64(BigInt(a.encryption_error_frames_cipher)), c.writeFieldEnd());
            a.encryption_error_frames_parse != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_parse",
                ftype: b("ThriftTypes").I64,
                fid: 85
            }), c.writeI64(BigInt(a.encryption_error_frames_parse)), c.writeFieldEnd());
            a.encryption_error_frames_invalid_key != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_invalid_key",
                ftype: b("ThriftTypes").I64,
                fid: 86
            }), c.writeI64(BigInt(a.encryption_error_frames_invalid_key)), c.writeFieldEnd());
            a.encryption_error_frames_cipher_auth != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_cipher_auth",
                ftype: b("ThriftTypes").I64,
                fid: 87
            }), c.writeI64(BigInt(a.encryption_error_frames_cipher_auth)), c.writeFieldEnd());
            a.encryption_error_frames_escape_data != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_escape_data",
                ftype: b("ThriftTypes").I64,
                fid: 88
            }), c.writeI64(BigInt(a.encryption_error_frames_escape_data)), c.writeFieldEnd());
            a.encryption_error_frames_unsupported_codec != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_unsupported_codec",
                ftype: b("ThriftTypes").I64,
                fid: 89
            }), c.writeI64(BigInt(a.encryption_error_frames_unsupported_codec)), c.writeFieldEnd());
            a.encryption_error_frames_unknown != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_unknown",
                ftype: b("ThriftTypes").I64,
                fid: 90
            }), c.writeI64(BigInt(a.encryption_error_frames_unknown)), c.writeFieldEnd());
            a.decryption_total_frames_data_channel != null && (c.writeFieldBegin({
                fname: "decryption_total_frames_data_channel",
                ftype: b("ThriftTypes").I64,
                fid: 91
            }), c.writeI64(BigInt(a.decryption_total_frames_data_channel)), c.writeFieldEnd());
            a.decryption_total_error_frames_data_channel != null && (c.writeFieldBegin({
                fname: "decryption_total_error_frames_data_channel",
                ftype: b("ThriftTypes").I64,
                fid: 92
            }), c.writeI64(BigInt(a.decryption_total_error_frames_data_channel)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_alloc != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_alloc",
                ftype: b("ThriftTypes").I64,
                fid: 93
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_alloc)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_invalid_params != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_invalid_params",
                ftype: b("ThriftTypes").I64,
                fid: 94
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_invalid_params)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_cipher != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_cipher",
                ftype: b("ThriftTypes").I64,
                fid: 95
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_cipher)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_parse != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_parse",
                ftype: b("ThriftTypes").I64,
                fid: 96
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_parse)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_invalid_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_invalid_key",
                ftype: b("ThriftTypes").I64,
                fid: 97
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_invalid_key)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_missing_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_missing_key",
                ftype: b("ThriftTypes").I64,
                fid: 98
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_missing_key)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_out_of_ratchet_space != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_out_of_ratchet_space",
                ftype: b("ThriftTypes").I64,
                fid: 99
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_out_of_ratchet_space)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_cipher_auth != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_cipher_auth",
                ftype: b("ThriftTypes").I64,
                fid: 100
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_cipher_auth)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_frame_too_old != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_frame_too_old",
                ftype: b("ThriftTypes").I64,
                fid: 101
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_frame_too_old)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_seen_frame != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_seen_frame",
                ftype: b("ThriftTypes").I64,
                fid: 102
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_seen_frame)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_invalid_frame != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_invalid_frame",
                ftype: b("ThriftTypes").I64,
                fid: 103
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_invalid_frame)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_setting_invalid_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_setting_invalid_key",
                ftype: b("ThriftTypes").I64,
                fid: 104
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_setting_invalid_key)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_setting_existing_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_setting_existing_key",
                ftype: b("ThriftTypes").I64,
                fid: 105
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_setting_existing_key)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_escape_data != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_escape_data",
                ftype: b("ThriftTypes").I64,
                fid: 106
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_escape_data)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_deescape_data != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_deescape_data",
                ftype: b("ThriftTypes").I64,
                fid: 107
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_deescape_data)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_parse_frame_or_key != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_parse_frame_or_key",
                ftype: b("ThriftTypes").I64,
                fid: 108
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_parse_frame_or_key)), c.writeFieldEnd());
            a.decryption_error_frames_data_channel_unknown != null && (c.writeFieldBegin({
                fname: "decryption_error_frames_data_channel_unknown",
                ftype: b("ThriftTypes").I64,
                fid: 109
            }), c.writeI64(BigInt(a.decryption_error_frames_data_channel_unknown)), c.writeFieldEnd());
            a.decryption_unencrypted_frames_data_channel != null && (c.writeFieldBegin({
                fname: "decryption_unencrypted_frames_data_channel",
                ftype: b("ThriftTypes").I64,
                fid: 110
            }), c.writeI64(BigInt(a.decryption_unencrypted_frames_data_channel)), c.writeFieldEnd());
            a.encryption_total_frames_data_channel != null && (c.writeFieldBegin({
                fname: "encryption_total_frames_data_channel",
                ftype: b("ThriftTypes").I64,
                fid: 111
            }), c.writeI64(BigInt(a.encryption_total_frames_data_channel)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel",
                ftype: b("ThriftTypes").I64,
                fid: 112
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel)), c.writeFieldEnd());
            a.encryption_total_error_frames_data_channel != null && (c.writeFieldBegin({
                fname: "encryption_total_error_frames_data_channel",
                ftype: b("ThriftTypes").I64,
                fid: 113
            }), c.writeI64(BigInt(a.encryption_total_error_frames_data_channel)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_alloc != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_alloc",
                ftype: b("ThriftTypes").I64,
                fid: 114
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_alloc)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_invalid_params != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_invalid_params",
                ftype: b("ThriftTypes").I64,
                fid: 115
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_invalid_params)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_cipher != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_cipher",
                ftype: b("ThriftTypes").I64,
                fid: 116
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_cipher)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_parse != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_parse",
                ftype: b("ThriftTypes").I64,
                fid: 117
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_parse)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_invalid_key != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_invalid_key",
                ftype: b("ThriftTypes").I64,
                fid: 118
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_invalid_key)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_cipher_auth != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_cipher_auth",
                ftype: b("ThriftTypes").I64,
                fid: 119
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_cipher_auth)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_escape_data != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_escape_data",
                ftype: b("ThriftTypes").I64,
                fid: 120
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_escape_data)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_unsupported_codec != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_unsupported_codec",
                ftype: b("ThriftTypes").I64,
                fid: 121
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_unsupported_codec)), c.writeFieldEnd());
            a.encryption_error_frames_data_channel_unknown != null && (c.writeFieldBegin({
                fname: "encryption_error_frames_data_channel_unknown",
                ftype: b("ThriftTypes").I64,
                fid: 122
            }), c.writeI64(BigInt(a.encryption_error_frames_data_channel_unknown)), c.writeFieldEnd());
            a.num_removed_data_decryptors != null && (c.writeFieldBegin({
                fname: "num_removed_data_decryptors",
                ftype: b("ThriftTypes").I64,
                fid: 123
            }), c.writeI64(BigInt(a.num_removed_data_decryptors)), c.writeFieldEnd());
            a.num_frame_decryptor_with_unencrypted_data != null && (c.writeFieldBegin({
                fname: "num_frame_decryptor_with_unencrypted_data",
                ftype: b("ThriftTypes").I64,
                fid: 124
            }), c.writeI64(BigInt(a.num_frame_decryptor_with_unencrypted_data)), c.writeFieldEnd());
            a.num_removed_decryptors != null && (c.writeFieldBegin({
                fname: "num_removed_decryptors",
                ftype: b("ThriftTypes").I64,
                fid: 125
            }), c.writeI64(BigInt(a.num_removed_decryptors)), c.writeFieldEnd());
            a.data_channel_encryption_not_ready_in_mandated_calls_error != null && (c.writeFieldBegin({
                fname: "data_channel_encryption_not_ready_in_mandated_calls_error",
                ftype: b("ThriftTypes").I64,
                fid: 126
            }), c.writeI64(BigInt(a.data_channel_encryption_not_ready_in_mandated_calls_error)), c.writeFieldEnd());
            a.num_e2ee_message_total_encrypt != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_total_encrypt",
                ftype: b("ThriftTypes").I64,
                fid: 127
            }), c.writeI64(BigInt(a.num_e2ee_message_total_encrypt)), c.writeFieldEnd());
            a.num_e2ee_message_error_encrypt != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_error_encrypt",
                ftype: b("ThriftTypes").I64,
                fid: 128
            }), c.writeI64(BigInt(a.num_e2ee_message_error_encrypt)), c.writeFieldEnd());
            a.num_e2ee_message_total_decrypt != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_total_decrypt",
                ftype: b("ThriftTypes").I64,
                fid: 129
            }), c.writeI64(BigInt(a.num_e2ee_message_total_decrypt)), c.writeFieldEnd());
            a.num_e2ee_message_error_decrypt != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_error_decrypt",
                ftype: b("ThriftTypes").I64,
                fid: 130
            }), c.writeI64(BigInt(a.num_e2ee_message_error_decrypt)), c.writeFieldEnd());
            a.negotiate_off_time != null && (c.writeFieldBegin({
                fname: "negotiate_off_time",
                ftype: b("ThriftTypes").I64,
                fid: 131
            }), c.writeI64(BigInt(a.negotiate_off_time)), c.writeFieldEnd());
            a.negotiated_version != null && (c.writeFieldBegin({
                fname: "negotiated_version",
                ftype: b("ThriftTypes").I64,
                fid: 132
            }), c.writeI64(BigInt(a.negotiated_version)), c.writeFieldEnd());
            a.decryptor_removed_time != null && (c.writeFieldBegin({
                fname: "decryptor_removed_time",
                ftype: b("ThriftTypes").I64,
                fid: 133
            }), c.writeI64(BigInt(a.decryptor_removed_time)), c.writeFieldEnd());
            a.is_e2ee_mandated_group != null && (c.writeFieldBegin({
                fname: "is_e2ee_mandated_group",
                ftype: b("ThriftTypes").I64,
                fid: 134
            }), c.writeI64(BigInt(a.is_e2ee_mandated_group)), c.writeFieldEnd());
            if (a.events != null) {
                c.writeFieldBegin({
                    fname: "events",
                    ftype: b("ThriftTypes").LIST,
                    fid: 135
                });
                c.writeListBegin({
                    etype: b("ThriftTypes").I64,
                    size: a.events.length
                });
                for (var d = a.events, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var g;
                    if (e) {
                        if (f >= d.length) break;
                        g = d[f++]
                    } else {
                        f = d.next();
                        if (f.done) break;
                        g = f.value
                    }
                    g = g;
                    c.writeI64(BigInt(g))
                }
                c.writeListEnd();
                c.writeFieldEnd()
            }
            a.num_e2ee_message_received != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_received",
                ftype: b("ThriftTypes").I64,
                fid: 136
            }), c.writeI64(BigInt(a.num_e2ee_message_received)), c.writeFieldEnd());
            a.num_e2ee_message_error_decrypt_non_e2ee_received != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_error_decrypt_non_e2ee_received",
                ftype: b("ThriftTypes").I64,
                fid: 137
            }), c.writeI64(BigInt(a.num_e2ee_message_error_decrypt_non_e2ee_received)), c.writeFieldEnd());
            a.num_e2ee_message_error_decrypt_missing_sender != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_error_decrypt_missing_sender",
                ftype: b("ThriftTypes").I64,
                fid: 138
            }), c.writeI64(BigInt(a.num_e2ee_message_error_decrypt_missing_sender)), c.writeFieldEnd());
            a.num_e2ee_message_error_decrypt_exceeding_retry != null && (c.writeFieldBegin({
                fname: "num_e2ee_message_error_decrypt_exceeding_retry",
                ftype: b("ThriftTypes").I64,
                fid: 139
            }), c.writeI64(BigInt(a.num_e2ee_message_error_decrypt_exceeding_retry)), c.writeFieldEnd());
            a.max_media_channel_key_message_retry_count != null && (c.writeFieldBegin({
                fname: "max_media_channel_key_message_retry_count",
                ftype: b("ThriftTypes").I64,
                fid: 140
            }), c.writeI64(BigInt(a.max_media_channel_key_message_retry_count)), c.writeFieldEnd());
            c.writeFieldStop();
            c.writeStructEnd()
        };
    c = function(a, c) {
        c.writeStructBegin("E2eeMetrics");
        c.writeFieldBegin({
            fname: "p2p_e2ee",
            ftype: b("ThriftTypes").STRUCT,
            fid: 1
        });
        if (a.p2p_e2ee != null) i(a.p2p_e2ee, c);
        else {
            var d = g();
            i(d, c)
        }
        c.writeFieldEnd();
        c.writeFieldBegin({
            fname: "group_e2ee",
            ftype: b("ThriftTypes").STRUCT,
            fid: 2
        });
        if (a.group_e2ee != null) j(a.group_e2ee, c);
        else {
            d = h();
            j(d, c)
        }
        c.writeFieldEnd();
        c.writeFieldStop();
        c.writeStructEnd()
    };
    var k = function(a) {
            var c = {};
            a.readStructBegin();
            while (!0) {
                var d = a.readFieldBegin(),
                    e = d.ftype;
                d = d.fid;
                if (e === b("ThriftTypes").STOP) break;
                switch (d) {
                    case 1:
                        e === b("ThriftTypes").I32 ? c.engine_type = a.readI32() : a.skip(e);
                        break;
                    case 2:
                        e === b("ThriftTypes").I32 ? c.status = a.readI32() : a.skip(e);
                        break;
                    case 3:
                        e === b("ThriftTypes").I32 ? c.version = a.readI32() : a.skip(e);
                        break;
                    case 4:
                        e === b("ThriftTypes").I32 ? c.gen_prekey_bundle_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 5:
                        e === b("ThriftTypes").I32 ? c.encrypted_msg_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 6:
                        e === b("ThriftTypes").I32 ? c.decrypted_msg_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 7:
                        e === b("ThriftTypes").I32 ? c.process_sdp_crypto_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 8:
                        e === b("ThriftTypes").I32 ? c.create_crypto_offer_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 9:
                        e === b("ThriftTypes").I32 ? c.create_crypto_answer_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 10:
                        e === b("ThriftTypes").I32 ? c.get_ik_time_ms = a.readI32() : a.skip(e);
                        break;
                    case 11:
                        e === b("ThriftTypes").I32 ? c.peer_id = a.readI32() : a.skip(e);
                        break;
                    case 12:
                        e === b("ThriftTypes").I32 ? c.peer_connection_index = a.readI32() : a.skip(e);
                        break;
                    case 13:
                        e === b("ThriftTypes").I32 ? c.srtp_crypto_suite = a.readI32() : a.skip(e);
                        break;
                    case 14:
                        e === b("ThriftTypes").I32 ? c.engine_error = a.readI32() : a.skip(e);
                        break;
                    case 15:
                        e === b("ThriftTypes").I32 ? c.libsignal_error = a.readI32() : a.skip(e);
                        break;
                    case 16:
                        e === b("ThriftTypes").I32 ? c.identity_key_mode = a.readI32() : a.skip(e);
                        break;
                    case 17:
                        e === b("ThriftTypes").I32 ? c.identity_key_num_persistent = a.readI32() : a.skip(e);
                        break;
                    case 18:
                        e === b("ThriftTypes").I32 ? c.identity_key_num_validated = a.readI32() : a.skip(e);
                        break;
                    case 19:
                        e === b("ThriftTypes").I32 ? c.identity_key_num_saved = a.readI32() : a.skip(e);
                        break;
                    case 20:
                        e === b("ThriftTypes").I32 ? c.identity_key_num_existing = a.readI32() : a.skip(e);
                        break;
                    case 21:
                        e === b("ThriftTypes").I32 ? c.is_e2ee_mandated = a.readI32() : a.skip(e);
                        break;
                    case 22:
                        e === b("ThriftTypes").I32 ? c.local_trace_id = a.readI32() : a.skip(e);
                        break;
                    case 23:
                        e === b("ThriftTypes").I32 ? c.remote_trace_id = a.readI32() : a.skip(e);
                        break;
                    case 24:
                        e === b("ThriftTypes").I32 ? c.local_device_id = a.readI32() : a.skip(e);
                        break;
                    case 25:
                        e === b("ThriftTypes").I32 ? c.remote_device_id = a.readI32() : a.skip(e);
                        break;
                    case 26:
                        if (e === b("ThriftTypes").LIST) {
                            c.events = [];
                            d = a.readListBegin();
                            for (var f = 0; f < d.size; f++) {
                                var g = a.readI32();
                                c.events.push(g)
                            }
                        } else a.skip(e);
                        break;
                    default:
                        a.skip(e)
                }
                a.readFieldEnd()
            }
            a.readStructEnd();
            return c
        },
        l = function(a) {
            var c = {};
            a.readStructBegin();
            while (!0) {
                var d = a.readFieldBegin(),
                    e = d.ftype;
                d = d.fid;
                if (e === b("ThriftTypes").STOP) break;
                switch (d) {
                    case 1:
                        e === b("ThriftTypes").I64 ? c.received_key_message_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 2:
                        e === b("ThriftTypes").I64 ? c.sent_key_message_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 3:
                        e === b("ThriftTypes").I64 ? c.cached_key_message_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 4:
                        e === b("ThriftTypes").I64 ? c.used_cached_key_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 5:
                        e === b("ThriftTypes").I64 ? c.unused_smu_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 6:
                        e === b("ThriftTypes").I64 ? c.missing_key_message_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 7:
                        e === b("ThriftTypes").I64 ? c.negotiate_off_status = a.readI64().toString() : a.skip(e);
                        break;
                    case 8:
                        e === b("ThriftTypes").I64 ? c.cipher_suite_status = a.readI64().toString() : a.skip(e);
                        break;
                    case 9:
                        e === b("ThriftTypes").I64 ? c.decrypt_used_cached_session_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 10:
                        e === b("ThriftTypes").I64 ? c.encrypt_used_cached_session_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 11:
                        e === b("ThriftTypes").I64 ? c.sent_ack_message_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 12:
                        e === b("ThriftTypes").I64 ? c.reuse_ackd_uid_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 13:
                        e === b("ThriftTypes").I64 ? c.total_uids_created_counter = a.readI64().toString() : a.skip(e);
                        break;
                    case 14:
                        e === b("ThriftTypes").I64 ? c.generate_chain_key_failed_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 15:
                        e === b("ThriftTypes").I64 ? c.set_chain_key_failed_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 16:
                        e === b("ThriftTypes").I64 ? c.key_provider_not_found_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 17:
                        e === b("ThriftTypes").I64 ? c.key_message_parse_failed_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 18:
                        e === b("ThriftTypes").I64 ? c.empty_pkb_result_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 19:
                        e === b("ThriftTypes").I64 ? c.empty_encrypt_result_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 20:
                        e === b("ThriftTypes").I64 ? c.empty_decrypt_result_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 21:
                        e === b("ThriftTypes").I64 ? c.empty_version_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 22:
                        e === b("ThriftTypes").I64 ? c.unsupported_version_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 23:
                        e === b("ThriftTypes").I64 ? c.midcall_version_change_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 24:
                        e === b("ThriftTypes").I64 ? c.inconsistent_remote_maps_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 25:
                        e === b("ThriftTypes").I64 ? c.key_message_pkb_mismatch_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 26:
                        e === b("ThriftTypes").I64 ? c.no_key_or_ack_in_e2ee_message_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 27:
                        e === b("ThriftTypes").I64 ? c.receiver_key_provider_not_found_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 28:
                        e === b("ThriftTypes").I64 ? c.pkb_parse_failed_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 29:
                        e === b("ThriftTypes").I64 ? c.message_deserialized_failed_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 30:
                        e === b("ThriftTypes").I64 ? c.decrypt_no_identity_key_and_cached_session_not_used_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 31:
                        e === b("ThriftTypes").I64 ? c.encrypt_no_identity_key_and_cached_session_not_used_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 32:
                        e === b("ThriftTypes").I64 ? c.decrypt_ack_wrong_message_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 33:
                        e === b("ThriftTypes").I64 ? c.invalid_uid_received_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 34:
                        e === b("ThriftTypes").I64 ? c.ack_for_absent_user = a.readI64().toString() : a.skip(e);
                        break;
                    case 35:
                        e === b("ThriftTypes").I64 ? c.uid_not_awaiting_ack_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 36:
                        e === b("ThriftTypes").I64 ? c.decrypt_ack_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 37:
                        e === b("ThriftTypes").I64 ? c.empty_decrypt_result_ack_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 38:
                        e === b("ThriftTypes").I64 ? c.decrypt_ack_cached_session_not_used_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 39:
                        e === b("ThriftTypes").I64 ? c.encrypt_ack_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 40:
                        e === b("ThriftTypes").I64 ? c.empty_encrypt_result_ack_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 41:
                        e === b("ThriftTypes").I64 ? c.invalid_message_type_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 42:
                        e === b("ThriftTypes").I64 ? c.server_state_deserialized_failed_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 43:
                        e === b("ThriftTypes").I64 ? c.crypto_engine_failure_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 44:
                        e === b("ThriftTypes").I64 ? c.empty_e2ee_client_state_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 45:
                        e === b("ThriftTypes").I64 ? c.group_e2ee_negotiated = a.readI64().toString() : a.skip(e);
                        break;
                    case 46:
                        e === b("ThriftTypes").I64 ? c.negotiation_mode_kn = a.readI64().toString() : a.skip(e);
                        break;
                    case 47:
                        e === b("ThriftTypes").I64 ? c.group_e2ee_setup_status = a.readI64().toString() : a.skip(e);
                        break;
                    case 48:
                        e === b("ThriftTypes").I64 ? c.enable_group_e2ee = a.readI64().toString() : a.skip(e);
                        break;
                    case 49:
                        e === b("ThriftTypes").I64 ? c.identity_key_mode_group = a.readI64().toString() : a.skip(e);
                        break;
                    case 50:
                        e === b("ThriftTypes").I64 ? c.identity_key_num_persistent_group = a.readI64().toString() : a.skip(e);
                        break;
                    case 51:
                        e === b("ThriftTypes").I64 ? c.identity_key_num_validated_group = a.readI64().toString() : a.skip(e);
                        break;
                    case 52:
                        e === b("ThriftTypes").I64 ? c.identity_key_num_saved_group = a.readI64().toString() : a.skip(e);
                        break;
                    case 53:
                        e === b("ThriftTypes").I64 ? c.identity_key_num_existing_group = a.readI64().toString() : a.skip(e);
                        break;
                    case 54:
                        e === b("ThriftTypes").I64 ? c.max_key_message_latency_ms = a.readI64().toString() : a.skip(e);
                        break;
                    case 55:
                        e === b("ThriftTypes").I64 ? c.max_key_message_latency_ms_joiner = a.readI64().toString() : a.skip(e);
                        break;
                    case 56:
                        e === b("ThriftTypes").I64 ? c.max_smu_to_key_message_latency_ms = a.readI64().toString() : a.skip(e);
                        break;
                    case 57:
                        e === b("ThriftTypes").I64 ? c.process_smu_time_ms = a.readI64().toString() : a.skip(e);
                        break;
                    case 58:
                        e === b("ThriftTypes").I64 ? c.decryption_total_frames = a.readI64().toString() : a.skip(e);
                        break;
                    case 59:
                        e === b("ThriftTypes").I64 ? c.decryption_total_error_frames = a.readI64().toString() : a.skip(e);
                        break;
                    case 60:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_alloc = a.readI64().toString() : a.skip(e);
                        break;
                    case 61:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_invalid_params = a.readI64().toString() : a.skip(e);
                        break;
                    case 62:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_cipher = a.readI64().toString() : a.skip(e);
                        break;
                    case 63:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_parse = a.readI64().toString() : a.skip(e);
                        break;
                    case 64:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_invalid_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 65:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_missing_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 66:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_out_of_ratchet_space = a.readI64().toString() : a.skip(e);
                        break;
                    case 67:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_cipher_auth = a.readI64().toString() : a.skip(e);
                        break;
                    case 68:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_frame_too_old = a.readI64().toString() : a.skip(e);
                        break;
                    case 69:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_seen_frame = a.readI64().toString() : a.skip(e);
                        break;
                    case 70:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_invalid_frame = a.readI64().toString() : a.skip(e);
                        break;
                    case 71:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_setting_invalid_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 72:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_setting_existing_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 73:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_escape_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 74:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_deescape_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 75:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_parse_frame_or_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 76:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_unknown = a.readI64().toString() : a.skip(e);
                        break;
                    case 77:
                        e === b("ThriftTypes").I64 ? c.decryption_unencrypted_frames = a.readI64().toString() : a.skip(e);
                        break;
                    case 78:
                        e === b("ThriftTypes").I64 ? c.encryption_total_frames = a.readI64().toString() : a.skip(e);
                        break;
                    case 79:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames = a.readI64().toString() : a.skip(e);
                        break;
                    case 80:
                        e === b("ThriftTypes").I64 ? c.encryption_escape_bytes = a.readI64().toString() : a.skip(e);
                        break;
                    case 81:
                        e === b("ThriftTypes").I64 ? c.encryption_total_error_frames = a.readI64().toString() : a.skip(e);
                        break;
                    case 82:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_alloc = a.readI64().toString() : a.skip(e);
                        break;
                    case 83:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_invalid_params = a.readI64().toString() : a.skip(e);
                        break;
                    case 84:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_cipher = a.readI64().toString() : a.skip(e);
                        break;
                    case 85:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_parse = a.readI64().toString() : a.skip(e);
                        break;
                    case 86:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_invalid_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 87:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_cipher_auth = a.readI64().toString() : a.skip(e);
                        break;
                    case 88:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_escape_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 89:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_unsupported_codec = a.readI64().toString() : a.skip(e);
                        break;
                    case 90:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_unknown = a.readI64().toString() : a.skip(e);
                        break;
                    case 91:
                        e === b("ThriftTypes").I64 ? c.decryption_total_frames_data_channel = a.readI64().toString() : a.skip(e);
                        break;
                    case 92:
                        e === b("ThriftTypes").I64 ? c.decryption_total_error_frames_data_channel = a.readI64().toString() : a.skip(e);
                        break;
                    case 93:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_alloc = a.readI64().toString() : a.skip(e);
                        break;
                    case 94:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_invalid_params = a.readI64().toString() : a.skip(e);
                        break;
                    case 95:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_cipher = a.readI64().toString() : a.skip(e);
                        break;
                    case 96:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_parse = a.readI64().toString() : a.skip(e);
                        break;
                    case 97:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_invalid_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 98:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_missing_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 99:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_out_of_ratchet_space = a.readI64().toString() : a.skip(e);
                        break;
                    case 100:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_cipher_auth = a.readI64().toString() : a.skip(e);
                        break;
                    case 101:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_frame_too_old = a.readI64().toString() : a.skip(e);
                        break;
                    case 102:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_seen_frame = a.readI64().toString() : a.skip(e);
                        break;
                    case 103:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_invalid_frame = a.readI64().toString() : a.skip(e);
                        break;
                    case 104:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_setting_invalid_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 105:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_setting_existing_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 106:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_escape_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 107:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_deescape_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 108:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_parse_frame_or_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 109:
                        e === b("ThriftTypes").I64 ? c.decryption_error_frames_data_channel_unknown = a.readI64().toString() : a.skip(e);
                        break;
                    case 110:
                        e === b("ThriftTypes").I64 ? c.decryption_unencrypted_frames_data_channel = a.readI64().toString() : a.skip(e);
                        break;
                    case 111:
                        e === b("ThriftTypes").I64 ? c.encryption_total_frames_data_channel = a.readI64().toString() : a.skip(e);
                        break;
                    case 112:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel = a.readI64().toString() : a.skip(e);
                        break;
                    case 113:
                        e === b("ThriftTypes").I64 ? c.encryption_total_error_frames_data_channel = a.readI64().toString() : a.skip(e);
                        break;
                    case 114:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_alloc = a.readI64().toString() : a.skip(e);
                        break;
                    case 115:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_invalid_params = a.readI64().toString() : a.skip(e);
                        break;
                    case 116:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_cipher = a.readI64().toString() : a.skip(e);
                        break;
                    case 117:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_parse = a.readI64().toString() : a.skip(e);
                        break;
                    case 118:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_invalid_key = a.readI64().toString() : a.skip(e);
                        break;
                    case 119:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_cipher_auth = a.readI64().toString() : a.skip(e);
                        break;
                    case 120:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_escape_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 121:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_unsupported_codec = a.readI64().toString() : a.skip(e);
                        break;
                    case 122:
                        e === b("ThriftTypes").I64 ? c.encryption_error_frames_data_channel_unknown = a.readI64().toString() : a.skip(e);
                        break;
                    case 123:
                        e === b("ThriftTypes").I64 ? c.num_removed_data_decryptors = a.readI64().toString() : a.skip(e);
                        break;
                    case 124:
                        e === b("ThriftTypes").I64 ? c.num_frame_decryptor_with_unencrypted_data = a.readI64().toString() : a.skip(e);
                        break;
                    case 125:
                        e === b("ThriftTypes").I64 ? c.num_removed_decryptors = a.readI64().toString() : a.skip(e);
                        break;
                    case 126:
                        e === b("ThriftTypes").I64 ? c.data_channel_encryption_not_ready_in_mandated_calls_error = a.readI64().toString() : a.skip(e);
                        break;
                    case 127:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_total_encrypt = a.readI64().toString() : a.skip(e);
                        break;
                    case 128:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_error_encrypt = a.readI64().toString() : a.skip(e);
                        break;
                    case 129:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_total_decrypt = a.readI64().toString() : a.skip(e);
                        break;
                    case 130:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_error_decrypt = a.readI64().toString() : a.skip(e);
                        break;
                    case 131:
                        e === b("ThriftTypes").I64 ? c.negotiate_off_time = a.readI64().toString() : a.skip(e);
                        break;
                    case 132:
                        e === b("ThriftTypes").I64 ? c.negotiated_version = a.readI64().toString() : a.skip(e);
                        break;
                    case 133:
                        e === b("ThriftTypes").I64 ? c.decryptor_removed_time = a.readI64().toString() : a.skip(e);
                        break;
                    case 134:
                        e === b("ThriftTypes").I64 ? c.is_e2ee_mandated_group = a.readI64().toString() : a.skip(e);
                        break;
                    case 135:
                        if (e === b("ThriftTypes").LIST) {
                            c.events = [];
                            d = a.readListBegin();
                            for (var f = 0; f < d.size; f++) {
                                var g = a.readI64().toString();
                                c.events.push(g)
                            }
                        } else a.skip(e);
                        break;
                    case 136:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_received = a.readI64().toString() : a.skip(e);
                        break;
                    case 137:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_error_decrypt_non_e2ee_received = a.readI64().toString() : a.skip(e);
                        break;
                    case 138:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_error_decrypt_missing_sender = a.readI64().toString() : a.skip(e);
                        break;
                    case 139:
                        e === b("ThriftTypes").I64 ? c.num_e2ee_message_error_decrypt_exceeding_retry = a.readI64().toString() : a.skip(e);
                        break;
                    case 140:
                        e === b("ThriftTypes").I64 ? c.max_media_channel_key_message_retry_count = a.readI64().toString() : a.skip(e);
                        break;
                    default:
                        a.skip(e)
                }
                a.readFieldEnd()
            }
            a.readStructEnd();
            return c
        };
    d = function(a) {
        var c = {};
        a.readStructBegin();
        while (!0) {
            var d = a.readFieldBegin(),
                e = d.ftype;
            d = d.fid;
            if (e === b("ThriftTypes").STOP) break;
            switch (d) {
                case 1:
                    e === b("ThriftTypes").STRUCT ? c.p2p_e2ee = k(a) : a.skip(e);
                    break;
                case 2:
                    e === b("ThriftTypes").STRUCT ? c.group_e2ee = l(a) : a.skip(e);
                    break;
                default:
                    a.skip(e)
            }
            a.readFieldEnd()
        }
        a.readStructEnd();
        c.p2p_e2ee === void 0 && (c.p2p_e2ee = g());
        c.group_e2ee === void 0 && (c.group_e2ee = h());
        return c
    };
    e.exports = {
        E2eeMetrics$DefaultConstructor: a,
        GroupE2eeMetrics$DefaultConstructor: h,
        P2pE2eeMetrics$DefaultConstructor: g,
        deserializeE2eeMetrics: d,
        deserializeGroupE2eeMetrics: l,
        deserializeP2pE2eeMetrics: k,
        serializeE2eeMetrics: c,
        serializeGroupE2eeMetrics: j,
        serializeP2pE2eeMetrics: i
    }
}), null);
__d("ZenonCallSummaryMediaStatsUtil", ["ZenonCallFalcoEventUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a != null) {
            var b = a.screen;
            a = a.video;
            var c = {};
            if (a != null) {
                c.video = {};
                var e = ["vrtt", "efr", "qp"];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f],
                        h = a[g];
                    h != null && (c.video[g] = {
                        avg: d("ZenonCallFalcoEventUtils").nonNullIntNumber(h.avg),
                        cnt: null,
                        p5: d("ZenonCallFalcoEventUtils").nonNullIntNumber(h.p5),
                        p50: d("ZenonCallFalcoEventUtils").nonNullIntNumber(h.p50),
                        p95: d("ZenonCallFalcoEventUtils").nonNullIntNumber(h.p95)
                    })
                }
                if (a.vqs != null) {
                    c.video.vqs = {
                        avg: d("ZenonCallFalcoEventUtils").nonNullIntNumber((g = a.vqs) == null ? void 0 : g.avg),
                        p5: d("ZenonCallFalcoEventUtils").nonNullIntNumber((h = a.vqs) == null ? void 0 : h.p5)
                    }
                }
            }
            if (b != null && b.vqs != null) {
                c.screen = {
                    vqs: {
                        avg: d("ZenonCallFalcoEventUtils").nonNullIntNumber((e = b.vqs) == null ? void 0 : e.avg),
                        p5: d("ZenonCallFalcoEventUtils").nonNullIntNumber((f = b.vqs) == null ? void 0 : f.p5)
                    }
                }
            }
            return c
        }
        return {}
    }
    g.getSenderPctStats = a
}), 98);
__d("ZenonDeviceInfoHelper", ["regeneratorRuntime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = -1,
        h = !1,
        i = {
            getBatteryStats: function() {
                var a, c;
                return b("regeneratorRuntime").async(function(d) {
                    while (1) switch (d.prev = d.next) {
                        case 0:
                            d.next = 2;
                            return b("regeneratorRuntime").awrap(i.internalGetWindow().navigator.getBattery);
                        case 2:
                            a = d.sent;
                            if (!(typeof a !== "function")) {
                                d.next = 5;
                                break
                            }
                            return d.abrupt("return", {
                                level: g,
                                placeholder: !0,
                                wasCharged: !1
                            });
                        case 5:
                            d.next = 7;
                            return b("regeneratorRuntime").awrap(a.call(navigator));
                        case 7:
                            c = d.sent;
                            c.charging ? h = !0 : c.onchargingchange = function(a) {
                                a.target.charging && (h = !0), a.target.onchargingchange = null
                            };
                            return d.abrupt("return", {
                                level: c.level * 100,
                                placeholder: !1,
                                wasCharged: h
                            });
                        case 10:
                        case "end":
                            return d.stop()
                    }
                }, null, this)
            },
            internalGetWindow: function() {
                return window
            }
        };
    a = i;
    f["default"] = a
}), 66);
__d("ZenonDeviceInfoUtils", ["UserAgentData"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("UserAgentData").browserName,
            b = c("UserAgentData").platformName;
        window.navigator.userAgent.toLowerCase().includes("mobile") && (b += " Mobile", a === "Chrome" && (a = "Mobile " + a));
        window.external && window.external.pinPage && (a === "Chrome" && (a += " Edge"));
        return {
            browser: a,
            browser_version: c("UserAgentData").browserFullVersion,
            device: c("UserAgentData").deviceName,
            os: b,
            os_version: c("UserAgentData").platformFullVersion,
            screen_height: window.screen.availHeight,
            screen_width: window.screen.availWidth
        }
    }
    g.getDeviceSoftwareInfo = a
}), 98);
__d("ZenonVCSTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        DIRECT_VIDEO: "direct_video",
        ESCALATED: "escalated",
        ESCALATION_DECLINED: "escalation_declined",
        MWS: "mws",
        VOIP: "voip"
    });
    c = b("$InternalEnum")({
        LL_BASIC: 1,
        LL_DEBUG: 2,
        LL_INFO: 4,
        LL_NIL: 0,
        LL_VERBOSE: 5,
        LL_WARNING: 3
    });
    f.ZenonCallType = a;
    f.ZenonUploadLogLevel = c
}), 66);
__d("ZenonLocalUploadLogLevel", ["CurrentUser", "ZenonVCSTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return Math.max(h(), a)
    }

    function h() {
        return c("CurrentUser").isEmployee() || c("CurrentUser").isTestUser() ? d("ZenonVCSTypes").ZenonUploadLogLevel.LL_DEBUG : d("ZenonVCSTypes").ZenonUploadLogLevel.LL_NIL
    }
    g.getUploadLogLevel = a;
    g.getLocalUploadLogLevel = h
}), 98);
__d("ZenonLoggingEventTypes", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["Send", "Receive"]);
    c = b("$InternalEnum")({
        Primary: "primary",
        Secondary: "secondary"
    });
    d = "rtc_www";
    f.ZenonUpdateIceInfoDirection = a;
    f.ZenonJoinMode = c;
    f.tslogSource = d
}), 66);
__d("ZenonCallSummary", ["ChannelClientID", "E2eeMetricsSerializers", "SiteData", "WebPerformanceDeviceInfo", "ZenonCallFalcoEventUtils", "ZenonCallSummaryMediaStatsUtil", "ZenonDeviceInfoHelper", "ZenonDeviceInfoUtils", "ZenonDismissReason", "ZenonIceStatsParser", "ZenonLocalUploadLogLevel", "ZenonLoggingEventTypes", "ZenonPeerID", "ZenonSignalingProtocol", "ZenonVCSTypes", "performanceNow", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        PRESSED_ANSWER: "p_a"
    };

    function i() {
        return "ZenonPlatform"
    }
    var j = 19,
        k = 24,
        l = {
            AT_LEAST_ONE_PARTICIPANT_ALERTED: "p_alert",
            AT_LEAST_ONE_PARTICIPANT_ANSWERED: "p_answer",
            CALL_CONNECTED: "connected",
            CALL_ENDED: "ended",
            CALL_STARTED: "started",
            NEGOTIATION_COMPLETED: "negotiation_completed",
            NETWORK_READY: "network_ready",
            PROC_JOIN_RESPONSE: "p_jresp",
            PROC_SERVER_MEDIA_UPDATE_WITH_ANSWER: "p_sreqa",
            RECV_ANSWER: "r_a",
            RECV_ANSWER_ACK: "r_aack",
            RECV_JOIN_RESPONSE: "r_jresp",
            RECV_OFFER: "r_o",
            RECV_OFFER_ACK: "r_oack",
            RECV_OK: "r_ok",
            RECV_PRANSWER: "r_pr",
            RECV_RETRIED_ANSWER: "r_a2",
            RECV_RETRIED_ANSWER_ACK: "r_aack2",
            RECV_RETRIED_OFFER: "r_o2",
            RECV_RETRIED_OFFER_ACK: "r_oack2",
            RECV_RING_REQUEST: "r_rreq",
            RECV_SERVER_MEDIA_UPDATE_WITH_ANSWER: "r_sreqa",
            SENT_ANSWER: "s_a",
            SENT_ANSWER_ACK: "s_aack",
            SENT_JOIN_REQUEST: "s_jreq",
            SENT_OFFER: "s_o",
            SENT_OFFER_ACK: "s_oack",
            SENT_OK: "s_ok",
            SENT_PRANSWER: "s_pr",
            SENT_RETRIED_ANSWER: "s_a2",
            SENT_RETRIED_ANSWER_ACK: "s_aack2",
            SENT_RETRIED_OFFER: "s_o2",
            SENT_RETRIED_OFFER_ACK: "s_oack2",
            SENT_RING_RESPONSE: "s_rresp"
        },
        m = {
            FIRST_MEDIA: "r_media",
            FIRST_VIDEO: "r_video"
        },
        n = {
            BATTERY_END: "battery_end",
            BATTERY_START: "battery_start",
            CONNECTION_EFFECTIVE_TYPE: "conn_effective_type",
            DESKTOP_DEVICE_CLASS: "desktop_device_class",
            DEVICE_INFO: "device_info",
            INITIATED_BY_APP_ID: "initiated_by_app_id",
            INITIATED_BY_PAGE_ID: "initiated_by_page_id",
            MAX_CONCURRENT_CONNECTED_PARTICIPANTS: "max_concurrent_connected_participants",
            PEER_IS_MOBILE: "peer_is_mobile",
            RATING: "rating5",
            RATING_SHOWN: "rating_shown",
            ROOM_SURFACE: "room_surface",
            SURVEY_CHOICE: "survey_choice",
            SURVEY_DETAILS: "survey_details",
            SURVEY_SHOWN: "survey_shown",
            YEAR_CLASS: "year_class"
        };
    a = function() {
        function a(a) {
            var b = a.callID,
                e = a.callTrigger,
                f = a.isCaller,
                g = a.isVideo,
                h = a.joinMode;
            h = h === void 0 ? d("ZenonLoggingEventTypes").ZenonJoinMode.Primary : h;
            var j = a.localCallID,
                l = a.peerID;
            a = a.uploadLogLevel;
            this.$24 = 0;
            this.$25 = 0;
            this.$30 = {};
            this.$31 = {};
            this.$32 = {};
            this.$33 = {};
            this.$34 = !1;
            this.$36 = 0;
            this.$37 = 0;
            this.$38 = 0;
            this.$39 = !1;
            this.$40 = 0;
            this.$41 = 0;
            this.$42 = {};
            this.$43 = {};
            this.$44 = {};
            this.$45 = {};
            this.$51 = {
                CoreAudioMetrics: {
                    isstall: "0",
                    voice_detect_pct: []
                },
                CoreVideoMetrics: {
                    screen: {
                        capture_stall: {
                            is_stall: "0"
                        },
                        encode_stall: {
                            is_stall: "0"
                        },
                        sent_stall: {
                            is_stall: "0"
                        }
                    },
                    video: {
                        capture_stall: {
                            is_stall: "0"
                        },
                        encode_stall: {
                            is_stall: "0"
                        },
                        sent_stall: {
                            is_stall: "0"
                        }
                    }
                },
                DebugAudioMetrics: {
                    NetworkReceive: {}
                },
                extraInfo: {},
                receiver: {},
                receiver_pct: {
                    audio: {}
                },
                sender: {},
                sender_pct: {
                    screen: {},
                    video: {}
                },
                video: {}
            };
            this.$52 = {
                error_count_decrypted: 0,
                error_count_encrypted: 0,
                frames_decrypted: 0,
                frames_encrypted: 0,
                group_e2ee_metrics: d("E2eeMetricsSerializers").GroupE2eeMetrics$DefaultConstructor(),
                total_decrypt_time: 0,
                total_encrypt_time: 0
            };
            this.$54 = {};
            this.$55 = {};
            this.$57 = {};
            this.peerID = l;
            this.callID = b;
            this.localCallID = j;
            this.$1 = d("ChannelClientID").getID();
            this.$3 = f;
            this.$2 = k;
            this.$6 = i();
            this.$4 = (l = a) != null ? l : d("ZenonLocalUploadLogLevel").getLocalUploadLogLevel();
            this.$5 = e;
            this.$27 = new Date().valueOf();
            this.$7 = "mws";
            this.$20 = null;
            this.$19 = null;
            this.$35 = this.peerID === d("ZenonPeerID").ZenonMWPeerID;
            this.$14 = c("SiteData").push_phase;
            this.$15 = h;
            this.$7 === "p2p" ? this.setCallType(g ? d("ZenonVCSTypes").ZenonCallType.DIRECT_VIDEO : d("ZenonVCSTypes").ZenonCallType.VOIP) : this.setCallType(d("ZenonVCSTypes").ZenonCallType.MWS);
            this.$29 = c("performanceNow")();
            this.$28 = 0;
            this.$26 = this.$29;
            this.$56 = 0;
            this.$57[n.DEVICE_INFO] = d("ZenonDeviceInfoUtils").getDeviceSoftwareInfo();
            this.$59();
            this.updateBatteryStart();
            this.$60();
            this.$61()
        }
        a.$62 = function(a) {
            try {
                return JSON.parse(a)
            } catch (a) {
                return null
            }
        };
        a.fromJsonString = function(b) {
            var e;
            b = this.$62(b);
            if (b == null) return null;
            if (b.version < j) return null;
            if (!Object.prototype.hasOwnProperty.call(b, "peerID") || !Object.prototype.hasOwnProperty.call(b, "callID") || !Object.prototype.hasOwnProperty.call(b, "isCaller") || !Object.prototype.hasOwnProperty.call(b, "startTime") || !Object.prototype.hasOwnProperty.call(b, "trigger") || !Object.prototype.hasOwnProperty.call(b, "signalingTime") || !Object.prototype.hasOwnProperty.call(b, "lastUpdatedTime") || !Object.prototype.hasOwnProperty.call(b, "lastSerializedTime")) return null;
            var f = c("ZenonSignalingProtocol").MW;
            f = new a({
                callID: b.callID,
                isCaller: b.isCaller,
                isVideo: b.callType === d("ZenonVCSTypes").ZenonCallType.DIRECT_VIDEO,
                localCallID: b.localCallID,
                peerID: b.peerID,
                protocol: f
            });
            f.$1 = b.deviceID;
            f.$2 = b.version;
            f.$4 = b.uploadLogLevel;
            f.$27 = b.startTime;
            f.$5 = b.trigger;
            f.$35 = b.isUsingMultiway;
            f.$34 = b.hasOfferInRingRequest;
            f.$36 = (e = b.renegotiationCmuRequestSent) != null ? e : 0;
            f.$37 = (e = b.renegotiationSmuReqWithAnswerReceived) != null ? e : 0;
            f.$38 = (e = b.renegotiationSmuReqWithOfferReceived) != null ? e : 0;
            f.$6 = b.clientVersion;
            f.$30 = b.signalingTime;
            f.$16 = b.endCallReason;
            f.$17 = b.endCallSubreason;
            f.$18 = b.isRemoteEnded;
            f.$24 = b.lastUpdatedTime;
            f.$25 = b.lastSerializedTime;
            f.$9 = b.joinWithSID;
            f.$20 = (e = b.endIsConnected) != null ? e : null;
            f.$19 = (e = b.pcIsConnected) != null ? e : null;
            f.$39 = b.hasAnswerInJoinResponse;
            f.$40 = (e = b.numIceConnectionStateConnected) != null ? e : 0;
            f.$41 = (e = b.numIceConnectionStateDisconnected) != null ? e : 0;
            f.$15 = b.joinMode;
            b.conferenceName != null && (f.$8 = b.conferenceName);
            b.escP2PCallID != null && (f.$10 = b.escP2PCallID);
            b.activeConn != null && (f.$7 = b.activeConn);
            b.serverInfoData != null && (f.$12 = b.serverInfoData);
            b.localVideoDuration != null && (f.$46 = b.localVideoDuration);
            b.remoteVideoDuration != null && (f.$47 = b.remoteVideoDuration);
            b.unsetOnRetrieve != null && (f.$23 = b.unsetOnRetrieve);
            b.openCount != null && (f.$56 = b.openCount);
            b.extraInfo && (f.$57 = b.extraInfo);
            b.gen0IceSentCount && (f.$42 = b.gen0IceSentCount);
            b.gen0IceReceivedCount && (f.$43 = b.gen0IceReceivedCount);
            b.iceConnections && (f.$54 = b.iceConnections);
            b.iceSentCount && (f.$44 = b.iceSentCount);
            b.iceReceivedCount && (f.$45 = b.iceReceivedCount);
            b.pcConnectionStates && (f.$55 = b.pcConnectionStates);
            b.accumulatedCallTime != null && (f.$28 = b.accumulatedCallTime);
            b.escStateTimes && (f.$31 = b.escStateTimes);
            b.applicationEventTime && (f.$32 = b.applicationEventTime);
            b.videoEscTimes && (f.$33 = b.videoEscTimes);
            b.mediaStats && (f.$51 = b.mediaStats);
            b.e2eeStats && (f.$52 = b.e2eeStats);
            b.connectionType !== void 0 && (f.$21 = b.connectionType);
            b.deviceCharged != null && (f.$58 = b.deviceCharged);
            b.videoReceivedCodec !== null && (f.$48 = b.videoReceivedCodec);
            b.videoSentCodec !== null && (f.$49 = b.videoSentCodec);
            b.audioSentCodec !== null && (f.$50 = b.audioSentCodec);
            b.relayIP != null && (f.$22 = b.relayIP);
            b.startReach != null && (f.$53 = b.startReach);
            b.sdpFormat != null && (f.$13 = b.sdpFormat);
            return f
        };
        var e = a.prototype;
        e.toJsonString = function() {
            var a;
            this.$25 = new Date().valueOf();
            a = {
                accumulatedCallTime: this.$63(),
                activeConn: (a = this.$7) != null ? a : "p2p",
                applicationEventTime: this.$32,
                audioSentCodec: this.$50,
                callID: this.callID,
                callType: this.$11,
                clientVersion: this.$6,
                conferenceName: this.$8,
                connectionType: this.$21,
                deviceCharged: this.$58,
                deviceID: this.$1,
                e2eeStats: this.$52,
                endCallReason: this.$16,
                endCallSubreason: this.$17,
                endIsConnected: this.$20,
                escP2PCallID: this.$10,
                escStateTimes: this.$31,
                extraInfo: this.$57,
                gen0IceReceivedCount: this.$43,
                gen0IceSentCount: this.$42,
                hasAnswerInJoinResponse: this.$39,
                hasOfferInRingRequest: this.$34,
                iceConnections: this.$54,
                iceReceivedCount: this.$45,
                iceSentCount: this.$44,
                isCaller: this.$3,
                isRemoteEnded: this.$18,
                isUsingMultiway: this.$35,
                joinMode: this.$15,
                joinWithSID: this.$9,
                lastSerializedTime: this.$25,
                lastUpdatedTime: this.$24,
                localCallID: this.localCallID,
                localVideoDuration: this.$46,
                mediaStats: this.$51,
                numIceConnectionStateConnected: this.$40,
                numIceConnectionStateDisconnected: this.$41,
                pcConnectionStates: this.$55,
                pcIsConnected: this.$19,
                peerID: this.peerID,
                relayIP: this.$22,
                remoteVideoDuration: this.$47,
                renegotiationCmuRequestSent: this.$36,
                renegotiationSmuReqWithAnswerReceived: this.$37,
                renegotiationSmuReqWithOfferReceived: this.$38,
                sdpFormat: this.$13,
                serverInfoData: this.$12,
                signalingTime: this.$30,
                startReach: this.$53,
                startTime: this.$27,
                trigger: this.$5,
                unsetOnRetrieve: this.$23,
                uploadLogLevel: this.$4,
                version: this.$2,
                videoEscTimes: this.$33,
                videoReceivedCodec: this.$48,
                videoSentCodec: this.$49
            };
            return JSON.stringify(a)
        };
        e.unsetEndCallFields = function() {
            this.$23 === !0 && (this.$16 = null, this.$17 = null, this.$18 = null, this.$20 = null, delete this.$30[l.CALL_ENDED], this.$29 = 0, this.$23 = null)
        };
        e.isNull = function() {
            return this.peerID === "0" && this.callID === "0" && !this.$3 && this.$5 === "NULL_SUMMARY"
        };
        e.getExtraInfo = function() {
            return this.$57
        };
        e.getLastUpdatedTime = function() {
            return this.$24
        };
        e.getMediaStats_DEBUG = function() {
            return this.$51
        };
        e.getDeviceID = function() {
            return this.$1
        };
        e.setDeviceID = function(a) {
            this.$1 = a
        };
        e.getSdpFormat = function() {
            return this.$13
        };
        e.setSdpFormat = function(a) {
            this.$13 = a
        };
        e.getJoinMode = function() {
            return this.$15
        };
        e.getLoggingArgs = function() {
            var a;
            return {
                call_id: this.callID,
                conf_name: (a = this.$8) != null ? a : "",
                peer_id: d("ZenonPeerID").convertPeerIDForLogging(this.peerID),
                serv_info: (a = this.$12) != null ? a : "",
                web_device_id: this.$1
            }
        };
        e.getDeviceCharged = function() {
            return this.$58
        };
        e.setDeviceCharged = function(a) {
            this.$58 !== !0 && (this.$58 = a)
        };
        e.updateLastSavedTime = function() {
            this.$26 = c("performanceNow")()
        };
        e.onCallAccepted = function(a) {
            this.$32[h.PRESSED_ANSWER] = this.$63(), this.$5 = a, this.$61()
        };
        e.onCallJoinRequest = function(a) {
            this.$34 = a, this.$35 = this.peerID === d("ZenonPeerID").ZenonMWPeerID, this.$61()
        };
        e.onCallConnected = function() {
            this.$64(l.CALL_CONNECTED), this.$61()
        };
        e.onNegotiationComplete = function() {
            this.$64(l.NEGOTIATION_COMPLETED), this.$61()
        };
        e.onCallEscalated = function() {
            this.$36 = this.$63(), this.$61()
        };
        e.onIceConnectionStateChangeToConnected = function() {
            this.$40++, this.$61()
        };
        e.onIceConnectionStateChangeToDisconnected = function() {
            this.$41++, this.$61()
        };
        e.onRenegotiationSmuReqWithAnswerReceived = function() {
            this.$37 = this.$63(), this.$61()
        };
        e.onRenegotiationSmuReqWithOfferReceived = function() {
            this.$38 = this.$63(), this.$61()
        };
        e.onCallEnded = function(a, b, c, d) {
            this.$23 = c, this.$16 = a, this.$17 = d, this.$18 = b, this.$64(l.CALL_ENDED), this.$20 == null && (this.$20 = this.$19), this.$61()
        };
        e.setPCIsConnected = function(a) {
            this.$19 !== a && (this.$19 = a, this.$55[d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$63())] = a)
        };
        e.onInviteResponded = function() {
            var a = this.$7 === "p2p" ? l.SENT_OFFER_ACK : l.SENT_RING_RESPONSE;
            this.$64(a);
            this.$61()
        };
        e.onInviteReceived = function() {
            var a = this.$7 === "p2p" ? l.RECV_OFFER : l.RECV_RING_REQUEST;
            this.$64(a);
            this.$61()
        };
        e.onInviteSent = function() {
            this.$64(l.SENT_JOIN_REQUEST), this.$61()
        };
        e.onInviteResponseReceived = function() {
            this.$64(l.RECV_JOIN_RESPONSE), this.$61()
        };
        e.onInviteResponseProcessed = function() {
            this.$64(l.PROC_JOIN_RESPONSE), this.$61()
        };
        e.onSmuWithAnswerReceived = function() {
            this.$64(l.RECV_SERVER_MEDIA_UPDATE_WITH_ANSWER), this.$61()
        };
        e.onSmuWithAnswerProcessed = function() {
            this.$64(l.PROC_SERVER_MEDIA_UPDATE_WITH_ANSWER), this.$61()
        };
        e.onAtLeastOneParticipantAlerted = function() {
            this.$64(l.AT_LEAST_ONE_PARTICIPANT_ALERTED), this.$61()
        };
        e.onAtLeastOneParticipantAnswered = function() {
            this.$64(l.AT_LEAST_ONE_PARTICIPANT_ANSWERED), this.$61()
        };
        e.onMediaConnected = function() {
            this.$64(l.NETWORK_READY), this.$61()
        };
        e.setIsPeerMobile = function(a) {
            this.$57[n.PEER_IS_MOBILE] = a ? "1" : "0", this.$61()
        };
        e.setCallType = function(a) {
            this.$11 = a, this.$61()
        };
        e.setConferenceName = function(a) {
            this.$8 = a, this.$61()
        };
        e.setConnectionType = function(a) {
            this.$21 = a, this.$61()
        };
        e.setInitByPageID = function(a) {
            this.$57[n.INITIATED_BY_PAGE_ID] = a, this.$61()
        };
        e.setInitByAppID = function(a) {
            a != null && (this.$57[n.INITIATED_BY_APP_ID] = a, this.$61())
        };
        e.setJoinWithSID = function(a) {
            this.$9 = a, this.$61()
        };
        e.setMediaStats = function(a) {
            var b = this;
            this.$51 = a;
            a = a.extraInfo;
            var c = a.localIceCandidate,
                d = a.mediaPacketTimes;
            a = a.remoteIceCandidate;
            if (c) {
                (this.$53 == null || this.$53 === "") && (this.$53 = c.networkType);
                if (a) {
                    var e = c.candidateType;
                    c = c.protocol;
                    var f = a.candidateType;
                    a = a.protocol;
                    if (e != null && c != null && f != null && a != null) {
                        e = "l:" + e + "-" + c + ";r:" + f + "-" + a;
                        this.$54[e] == null && (this.$54[e] = this.$63())
                    }
                }
            }
            if (d != null) {
                c = new Map([
                    [m.FIRST_MEDIA, d.audio],
                    [m.FIRST_VIDEO, d.video]
                ]);
                c.forEach(function(a, c) {
                    if (a != null) {
                        a = a - b.$29;
                        b.$30[c] == null && (b.$30[c] = Math.floor(b.$28 + a))
                    }
                })
            }
            this.updateBatteryEnd();
            this.$61()
        };
        e.setServerInfoData = function(a) {
            this.$12 = a, this.$61()
        };
        e.setRating = function(a) {
            this.$57[n.RATING] = d("ZenonCallFalcoEventUtils").nonNullIntNumber(a), this.$61()
        };
        e.setFeedback = function(a) {
            this.$57[n.SURVEY_DETAILS] = a, this.$61()
        };
        e.setSurveyChoice = function(a) {
            this.$57[n.SURVEY_CHOICE] = a, this.$61()
        };
        e.setMaxConnectedParticipants = function(a) {
            this.$57[n.MAX_CONCURRENT_CONNECTED_PARTICIPANTS] = d("ZenonCallFalcoEventUtils").nonNullIntNumber(a), this.$61()
        };
        e.setHasAnswerInJoinResponse = function(a) {
            this.$39 = a, this.$61()
        };
        e.setLinkSurface = function(a) {
            this.$57[n.ROOM_SURFACE] = a, this.$61()
        };
        e.updateIceInfo = function(a, b) {
            var c = b === d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send ? this.$42 : this.$43,
                e = b === d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send ? this.$44 : this.$45;
            b = d("ZenonIceStatsParser").extractIceInfo(a);
            b.forEach(function(a) {
                var b = a.gen;
                a = a.type;
                b === 0 && (c[a] == null ? c[a] = 1 : c[a]++);
                e[a] == null ? e[a] = 1 : e[a]++
            })
        };
        e.updateE2EEStats = function(a) {
            this.$52 = a, this.$61()
        };
        e.$65 = function(a) {
            return ((a = a.group_e2ee_metrics) == null ? void 0 : a.enable_group_e2ee) === 1
        };
        e.$66 = function(a) {
            a = a.group_e2ee_metrics;
            return a == null || a.group_e2ee_negotiated == null ? null : a.group_e2ee_negotiated === "1"
        };
        e.$64 = function(a) {
            if (this.$30[a] != null) return;
            this.$30[a] = this.$63()
        };
        e.$63 = function() {
            var a = c("performanceNow")() - this.$29;
            return Math.floor(this.$28 + a)
        };
        e.$61 = function() {
            this.$24 = new Date().valueOf()
        };
        e.$60 = function() {
            var a = d("WebPerformanceDeviceInfo").getMobileYearClass();
            a != null && a > 0 ? this.$57[n.YEAR_CLASS] = d("ZenonCallFalcoEventUtils").nonNullIntNumber(a) : this.$57[n.DESKTOP_DEVICE_CLASS] = d("WebPerformanceDeviceInfo").getDeviceLevel()
        };
        e.updateBatteryStart = function() {
            var a, d, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        f.next = 2;
                        return b("regeneratorRuntime").awrap(c("ZenonDeviceInfoHelper").getBatteryStats());
                    case 2:
                        a = f.sent, d = a.level, e = a.placeholder, e !== !0 && (this.$57[n.BATTERY_START] = d);
                    case 6:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        e.updateBatteryEnd = function() {
            var a, d, e, f;
            return b("regeneratorRuntime").async(function(g) {
                while (1) switch (g.prev = g.next) {
                    case 0:
                        g.next = 2;
                        return b("regeneratorRuntime").awrap(c("ZenonDeviceInfoHelper").getBatteryStats());
                    case 2:
                        a = g.sent, d = a.level, e = a.placeholder, f = a.wasCharged, e !== !0 && (this.$57[n.BATTERY_END] = d, this.setDeviceCharged(f));
                    case 7:
                    case "end":
                        return g.stop()
                }
            }, null, this)
        };
        e.toString = function() {
            var a = {
                core_metrics: this.$67(),
                time_series: null
            };
            return JSON.stringify(a)
        };
        e.getGroupE2eeMetricsInFalcoShape = function() {
            return babelHelpers["extends"]({
                local_call_id: this.localCallID,
                shared_call_id: this.$7 === "p2p" ? this.callID : this.$12,
                steady_time_ms: d("ZenonCallFalcoEventUtils").performanceNowParsed(),
                system_time_ms: String(Date.now())
            }, this.$52.group_e2ee_metrics)
        };
        e.toFalco = function() {
            return {
                CoreAudioMetrics: this.$51.CoreAudioMetrics,
                CoreVideoMetrics: this.$51.CoreVideoMetrics,
                DebugAudioMetrics: this.$51.DebugAudioMetrics,
                active_conn: this.$7,
                answer_in_join_resp: this.$39,
                app_event_times: {
                    opened: d("ZenonCallFalcoEventUtils").intNumberOrNull(this.$32.opened),
                    p_a: d("ZenonCallFalcoEventUtils").intNumberOrNull(this.$32.p_a)
                },
                call_type: this.$11,
                caller: this.$3,
                client_version: this.$6,
                conf_name: this.$8,
                conn: this.$68(),
                device_charged: this.$58,
                e2ee: {
                    g: {
                        DE: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$52.error_count_decrypted),
                        DF: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$52.frames_decrypted),
                        DT: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$52.total_decrypt_time),
                        EE: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$52.error_count_encrypted),
                        EF: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$52.frames_encrypted),
                        ET: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$52.total_encrypt_time),
                        Ng: this.$66(this.$52),
                        en: this.$65(this.$52),
                        mKL: this.$52.group_e2ee_metrics.max_key_message_latency_ms,
                        mKLj: this.$52.group_e2ee_metrics.max_key_message_latency_ms_joiner,
                        mSL: this.$52.group_e2ee_metrics.max_smu_to_key_message_latency_ms
                    }
                },
                end: this.$69(),
                esc_p2p_call_id: this.$10,
                esc_state_times: {
                    esc_available: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.esc_available),
                    mw_call_ended: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.mw_call_ended),
                    out_started: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.out_started),
                    p_connected_mw: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.p_connected_mw),
                    p_connecting_mw: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.p_connecting_mw),
                    p_fail_conn: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.p_fail_conn),
                    ready_esc: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.ready_esc),
                    rej_invalid_state: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.rej_invalid_state),
                    timed_out: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.timed_out),
                    u_connected_mw: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.u_connected_mw),
                    u_connecting_mw: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$31.u_connecting_mw)
                },
                is_using_multiway: this.$35,
                join_mode: this.$15,
                join_with_sid: this.$9,
                log_level: this.$70(d("ZenonVCSTypes").ZenonUploadLogLevel.cast(this.$4)),
                num_ice_conn_change_conn: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$40),
                num_ice_conn_change_disconn: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$41),
                offer_in_ring_req: this.$34,
                open_count: this.$56,
                peer_id: d("ZenonPeerID").convertPeerIDForLogging(this.peerID),
                perf: this.$71(),
                push_phase: this.$14,
                receiver: this.$72(this.$51.receiver),
                sdp_reneg_times: [{
                    crs: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$36),
                    srar: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$37),
                    sror: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$38)
                }],
                sender: this.$73(this.$51.sender),
                sender_pct: d("ZenonCallSummaryMediaStatsUtil").getSenderPctStats(this.$51.sender_pct),
                serv_info: this.$12,
                signaling: this.$74(),
                ver: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$2),
                vid_esc_times: this.$33,
                video: this.$75()
            }
        };
        e.$67 = function() {
            return {
                CoreAudioMetrics: this.$51.CoreAudioMetrics,
                CoreVideoMetrics: this.$51.CoreVideoMetrics,
                DebugAudioMetrics: this.$51.DebugAudioMetrics,
                active_conn: this.$7,
                answer_in_join_resp: this.$39,
                app_event_times: this.$32,
                call_type: this.$11,
                caller: this.$3,
                client_version: this.$6,
                conf_name: this.$8,
                conn: this.$68(),
                device_charged: this.$58,
                e2ee_stats: this.$52,
                end: this.$69(),
                esc_p2p_call_id: this.$10,
                esc_state_times: this.$31,
                is_using_multiway: this.$35,
                join_mode: this.$15,
                join_with_sid: this.$9,
                log_level: this.$70(d("ZenonVCSTypes").ZenonUploadLogLevel.cast(this.$4)),
                num_ice_conn_change_conn: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$40),
                num_ice_conn_change_disconn: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$41),
                offer_in_ring_req: this.$34,
                open_count: this.$56,
                peer_id: d("ZenonPeerID").convertPeerIDForLogging(this.peerID),
                perf: this.$71(),
                push_phase: this.$14,
                receiver: this.$72(this.$51.receiver),
                sdp_reneg_times: [{
                    crs: this.$36,
                    srar: this.$37,
                    sror: this.$38
                }],
                sender: this.$73(this.$51.sender),
                serv_info: this.$12,
                signaling: this.$74(),
                ver: this.$2,
                vid_esc_times: this.$33,
                video: this.$51.video
            }
        };
        e.$70 = function(a) {
            if (a == null) return "";
            switch (a) {
                case d("ZenonVCSTypes").ZenonUploadLogLevel.LL_BASIC:
                    return "basic";
                case d("ZenonVCSTypes").ZenonUploadLogLevel.LL_DEBUG:
                    return "debug";
                case d("ZenonVCSTypes").ZenonUploadLogLevel.LL_WARNING:
                    return "warning";
                case d("ZenonVCSTypes").ZenonUploadLogLevel.LL_INFO:
                    return "info";
                case d("ZenonVCSTypes").ZenonUploadLogLevel.LL_VERBOSE:
                    return "verbose";
                default:
                    return ""
            }
        };
        e.$68 = function() {
            var a = {},
                b = this.$51.sender,
                c = b.avgrtt,
                e = b.maxrtt;
            b = b.minrtt;
            c != null && (a.avgrtt = c, a.maxrtt = d("ZenonCallFalcoEventUtils").nonNullIntNumber(e), a.minrtt = d("ZenonCallFalcoEventUtils").nonNullIntNumber(b));
            this.$22 != null && (a.relay_ip = this.$22);
            this.$53 != null && this.$53 !== "" && (a.start_reach = this.$53);
            var f = {};
            Object.entries(this.$54).forEach(function(a) {
                var b = a[0];
                a = a[1];
                typeof a === "number" && (f[d("ZenonCallFalcoEventUtils").nonNullIntNumber(a)] = b)
            });
            a.types = f;
            a.ctd = this.$55;
            return a
        };
        e.$74 = function() {
            var a = {
                start_time: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$27),
                time_from_start: p(this.$30)
            };
            this.$5 != null && (a.trigger = this.$5);
            var b = this.$76();
            b > 0 && (a.duration = d("ZenonCallFalcoEventUtils").nonNullIntNumber(b));
            return a
        };
        e.$73 = function(a) {
            return {
                avgrtt: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.avgrtt),
                bytes: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.bytes),
                codec: a.codec,
                ice: o(this.$44),
                ice_g0: o(this.$42),
                maxrtt: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.maxrtt),
                minrtt: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.minrtt),
                plost: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.plost),
                psent: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.psent),
                taulc: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.taulc),
                tx_sum_lvl: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.tx_sum_lvl),
                ube_avg: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.ube_avg)
            }
        };
        e.$72 = function(a) {
            return {
                bytes: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.bytes),
                codec: a.codec,
                dbe_avg: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dbe_avg),
                dec_ar: a.dec_ar,
                dec_cng: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dec_cng),
                dec_normal: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dec_normal),
                dec_pack_flush: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dec_pack_flush),
                dec_per: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dec_per),
                dec_plc: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dec_plc),
                dec_plc_cng: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.dec_plc_cng),
                decel_cnt: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.decel_cnt),
                e2el: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.e2el),
                fecpd: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.fecpd),
                fecpr: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.fecpr),
                ice: o(this.$45),
                ice_g0: o(this.$43),
                jbd: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.jbd),
                jbec: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.jbec),
                jitter: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.jitter),
                neteq_calls: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.neteq_calls),
                plost: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.plost),
                precv: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.precv),
                rx_sum_lvl: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.rx_sum_lvl),
                sp_dur: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.sp_dur),
                sp_r: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.sp_r),
                taue: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.taue),
                taulc: d("ZenonCallFalcoEventUtils").intNumberOrNull(a.taulc)
            }
        };
        e.$75 = function() {
            var a;
            return {
                bwe: this.$51.video.bwe,
                ld: this.$51.video.ld,
                rd: this.$51.video.rd,
                receiver: {
                    av: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.av),
                    avabs: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.avabs),
                    dec_bytes: (a = this.$51.video.receiver) == null ? void 0 : a.dec_bytes,
                    dec_frame: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.dec_frame),
                    dec_time: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.dec_time),
                    dec_time_all_streams: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.dec_time_all_streams),
                    dname: (a = this.$51.video.receiver) == null ? void 0 : a.dname,
                    dpxl: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.dpxl),
                    e2el: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.e2el),
                    fir: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.fir),
                    frcnt: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.frcnt),
                    frd: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.frd),
                    frdur: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.frdur),
                    frdur500: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.frdur500),
                    jbd: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.jbd),
                    jbec: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.jbec),
                    jtasb: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.jtasb),
                    jtfrm: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.jtfrm),
                    jtkey: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.jtkey),
                    nack: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.nack),
                    pact: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.pact),
                    padur: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.padur),
                    pli: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.pli),
                    plost: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.plost),
                    precv: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.precv),
                    qps: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.qps),
                    recjbl: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.recjbl),
                    recv: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.recv),
                    rh: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.rh),
                    rw: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.rw),
                    tdt: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : a.tdt),
                    vqs: {
                        avg: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.receiver) == null ? void 0 : (a = a.vqs) == null ? void 0 : a.avg)
                    }
                },
                sender: {
                    ah: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.ah),
                    aw: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.aw),
                    ch: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.ch),
                    cw: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.cw),
                    efrate: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.efrate),
                    ehist: (a = this.$51.video.sender) == null ? void 0 : a.ehist,
                    eiframes: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.eiframes),
                    eipxl: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.eipxl),
                    ename: (a = this.$51.video.sender) == null ? void 0 : a.ename,
                    eopxl: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.eopxl),
                    eqps: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.eqps),
                    fcap: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.fcap),
                    fcsn: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.fcsn),
                    fir: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.fir),
                    frames: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.frames),
                    histResScale: ((a = (a = this.$51.video.sender) == null ? void 0 : a.histResScale) != null ? a : []).map(function(a) {
                        return d("ZenonCallFalcoEventUtils").nonNullIntNumber(a)
                    }),
                    kframes: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.kframes),
                    nack: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.nack),
                    pli: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.pli),
                    plost: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.plost),
                    psent: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.psent),
                    sim_l_chg: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.sim_l_chg),
                    ss: {
                        avbr: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.avbr),
                        avbw: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.avbw),
                        dur: (a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.dur,
                        eiframes: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.eiframes),
                        eipxl: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.eipxl),
                        eopxl: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.eopxl),
                        eqps: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.eqps),
                        frames: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : (a = a.ss) == null ? void 0 : a.frames)
                    },
                    tet: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.tet),
                    tpsd: d("ZenonCallFalcoEventUtils").intNumberOrNull((a = this.$51.video.sender) == null ? void 0 : a.tpsd)
                }
            }
        };
        e.$76 = function(a) {
            var b = this.$30[l.CALL_CONNECTED] || this.$30[l.NETWORK_READY];
            if (!b) return 0;
            a = this.$30[l.CALL_ENDED] || !(a == null ? void 0 : a.assumeOngoing) && this.$28 || this.$63();
            return Math.max(0, a - b)
        };
        e.$69 = function() {
            var a, b = {};
            this.$16 != null && (b.end_call_reason_string = d("ZenonDismissReason").dismissToEndCallReason(this.$16), this.$17 !== null && (b.end_call_subreason_string = this.$17), b.remote_ended = this.$18, b.end_ctd = this.$20);
            this.$21 != null && (b.conn_type = this.$21);
            a = (a = this.$51.extraInfo) != null ? a : {};
            a = a.localIceCandidate;
            a && a.networkType !== "" && (b.reach = a.networkType);
            return b
        };
        e.$71 = function() {
            var a, b, c = this.$76();
            if (c <= 0) return;
            a = (a = (a = this.$51.video.receiver) == null ? void 0 : a.tdt) != null ? a : 0;
            b = (b = (b = this.$51.video.sender) == null ? void 0 : b.tet) != null ? b : 0;
            a = a + b;
            b = d("ZenonCallFalcoEventUtils").nonNullIntNumber(Math.round(100 * (a / c)));
            return {
                cpu: {
                    proc: {
                        avg: b
                    }
                }
            }
        };
        e.$59 = function() {
            var a;
            ((a = window.navigator.connection) == null ? void 0 : a.effectiveType) != null && (this.$57[n.CONNECTION_EFFECTIVE_TYPE] = window.navigator.connection.effectiveType)
        };
        return a
    }();

    function o(a) {
        return {
            host: d("ZenonCallFalcoEventUtils").nonNullIntNumber(a.host),
            relay: d("ZenonCallFalcoEventUtils").nonNullIntNumber(a.relay),
            srflx: d("ZenonCallFalcoEventUtils").nonNullIntNumber(a.srflx)
        }
    }

    function p(a) {
        var b = {},
            c = Object.keys(a);
        for (var e = 0; e < c.length; e++) {
            var f = c[e];
            b[f] = d("ZenonCallFalcoEventUtils").intNumberOrNull(a[f])
        }
        return b
    }
    g["default"] = a
}), 98);
__d("ZenonGenericLocalStorageStore", ["CacheStorage", "WebStorage", "ZenonInfraActionsLogger", "ZenonUserActionLogger", "areEqual", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 2e3,
        i = 3;
    a = function() {
        function a(a, b, d) {
            this.$1 = a, this.$2 = new(c("CacheStorage"))(b, d)
        }
        var b = a.prototype;
        b.getLocalStorageObjects = function() {
            return this.$2.get(this.$1) || {}
        };
        b.removeLocalStorageObjects = function(a) {
            this.mutateLocalStorageObjects(function(b) {
                a.forEach(function(a) {
                    var d = a.callID;
                    a = a.peerID;
                    c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                        checkpoint: "NSL - removeLocalStorageObjects peerID: " + a + " callID: " + d
                    });
                    b[a] && b[a][d] && (delete b[a][d], Object.entries(b[a]).length === 0 && delete b[a])
                });
                return b
            })
        };
        b.mutateLocalStorageObjects = function(a, b, d, e) {
            var f = this;
            b === void 0 && (b = i);
            d === void 0 && (d = !1);
            e === void 0 && (e = null);
            var g = this.getLocalStorageObjects(),
                j = this.getLocalStorageObjects();
            g = a(g);
            var k = this.getLocalStorageObjects();
            if (c("areEqual")(j, k)) this.$2.set(this.$1, g), this.logStorageError(this.$2.getLastSetException(), e);
            else if (b > 0)
                if (d) c("setTimeout")(function() {
                    var d;
                    c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                        checkpoint: "NSL - mutateLocalStorageObjects retry in timeout retryCount: " + b + " peerID: " + ((d = (d = e) == null ? void 0 : d.peerID) != null ? d : "") + " callID: " + ((d = (d = e) == null ? void 0 : d.callID) != null ? d : "")
                    });
                    f.mutateLocalStorageObjects(a, b - 1, !0)
                }, h);
                else {
                    c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                        checkpoint: "NSL - mutateLocalStorageObjects first try peerID: " + ((k = (j = e) == null ? void 0 : j.peerID) != null ? k : "") + " callID: " + ((d = (g = e) == null ? void 0 : g.callID) != null ? d : "")
                    });
                    this.mutateLocalStorageObjects(a, b - 1, !0)
                }
        };
        b.logStorageError = function(a, b) {
            a != null && (d("ZenonUserActionLogger").logError({
                call_id: b == null ? void 0 : b.callID,
                error_domain: "ZenonGenericLocalStorageStore_storeLocalStorageObjects",
                error_type: a.name,
                peer_id: b == null ? void 0 : b.peerID
            }), c("WebStorage").isLocalStorageQuotaExceeded() && c("ZenonInfraActionsLogger").logCounter("local_storage_quota_exceeded"))
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("ZenonCallSummaryStore", ["FBLogger", "ZenonCallSummary", "ZenonGenericLocalStorageStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "localstorage",
        i = "RTC_CALL_SUMMARY_",
        j = "summary",
        k = 3;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.call(this, j, h, i) || this
        }
        var d = b.prototype;
        d.retrieveCallSummary = function(a, b) {
            var d = this.getLocalStorageObjects();
            d = d[a] ? d[a][b] : null;
            if (d) return c("ZenonCallSummary").fromJsonString(d.__d);
            else return null
        };
        d.storeCallSummary = function(a) {
            if (a.isNull()) {
                c("FBLogger")("rtweb").mustfix("Storing invalid ZenonCallSummary!");
                return
            }
            var b = a.peerID,
                d = a.callID;
            this.mutateLocalStorageObjects(function(c) {
                c[b] || (c[b] = {});
                c[b][d] = {
                    __d: a.toJsonString(),
                    __t: Date.now(),
                    __z: !0
                };
                return c
            }, k, !1, {
                callID: d,
                peerID: b
            });
            a.updateLastSavedTime()
        };
        return b
    }(c("ZenonGenericLocalStorageStore"));
    b = new a();
    g.ZenonCallSummaryStoreInstance = b
}), 98);
__d("LsRtcGroupE2eeFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1066");
    c = b("FalcoLoggerInternal").create("ls_rtc_group_e2ee", a);
    e.exports = c
}), null);
__d("RtcClientCallSummaryFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("799");
    c = b("FalcoLoggerInternal").create("rtc_client_call_summary", a);
    e.exports = c
}), null);
__d("ZenonCallIDType", ["randomInt"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return a
    }

    function b() {
        return c("randomInt")(0, 4294967294) + 1
    }
    g.convertNumberToZenonCallID = a;
    g.generateZenonCallID = b
}), 98);
__d("ZenonCallSummaryUploader", ["LsRtcGroupE2eeFalcoEvent", "ODS", "PersistedQueue", "RtcClientCallSummaryFalcoEvent", "WebStorage", "ZenonCallIDType", "ZenonCallSummary", "ZenonCallSummaryStore", "ZenonInfraActionsLogger", "ZenonPeerID", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 3 * 60 * 1e3,
        i = new Set();

    function j(a) {
        var b = a.callID,
            e = a.callSummary;
        a = a.peerID;
        c("WebStorage").isLocalStorageQuotaExceeded() && c("ZenonInfraActionsLogger").logCounter("local_storage_quota_exceeded");
        var f = d("ZenonCallIDType").convertNumberToZenonCallID(Number(b));
        c("ZenonInfraActionsLogger").updateCachedValues({
            callID: f
        });
        c("ZenonInfraActionsLogger").logCheckpoint({
            checkpoint: "[ZP] Attempting to upload CallSummary via Falco"
        });
        f = b + "-" + a;
        i.has(f) && c("ZenonInfraActionsLogger").logCounter("duplicate_call_summary_upload");
        i.add(f);
        f = e.getSdpFormat();
        var g = !c("gkx")("5993"),
            h = babelHelpers["extends"]({
                call_id: b,
                channel_session_id: e.getDeviceID(),
                content: {
                    core_metrics: e.toFalco()
                },
                is_stateful2: g,
                local_call_id: e.localCallID,
                peer_id: d("ZenonPeerID").convertPeerIDForLogging(a),
                sdp_format: f ? f : null,
                tag: "endcallstats"
            }, e.getExtraInfo());
        c("PersistedQueue").eventEmitter.emit("active", null);
        c("ZenonInfraActionsLogger").logCheckpoint({
            checkpoint: "[ZP] CallSummary data length after stringified: " + JSON.stringify(h).length + " via Falco"
        });
        if (c("gkx")("2715")) return;
        c("RtcClientCallSummaryFalcoEvent").logCritical(function() {
            return h
        });
        b = g ? "call_summary.log_attempt.stateful" : "call_summary.log_attempt.stateless";
        d("ODS").bumpEntityKey(4083, "zenon_logging", b);
        c("LsRtcGroupE2eeFalcoEvent").logCritical(function() {
            return e.getGroupE2eeMetricsInFalcoShape()
        });
        c("ZenonInfraActionsLogger").logCheckpoint({
            checkpoint: "[ZP] Complete uploading CallSummary"
        })
    }

    function k() {
        var a = d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.getLocalStorageObjects(),
            b = [];
        for (var e in a)
            for (var f in a[e]) {
                var g = a[e][f];
                if (g.__z) {
                    var i = g.__t;
                    if (Date.now() - i > h) {
                        i = c("ZenonCallSummary").fromJsonString(g.__d);
                        i && b.push({
                            callID: f,
                            callSummary: i,
                            peerID: e
                        })
                    }
                }
            }
        return b
    }

    function a() {
        var a = k();
        a.forEach(function(a) {
            var b = a.callID,
                e = a.callSummary;
            a = a.peerID;
            try {
                j({
                    callID: b,
                    callSummary: e,
                    peerID: a
                }), d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.removeLocalStorageObjects([{
                    callID: b,
                    peerID: a
                }])
            } catch (a) {
                c("ZenonInfraActionsLogger").logError({
                    error: a.message,
                    errorDomain: "ZenonCallSummaryUploader"
                })
            }
        })
    }

    function b(a) {
        var b = a.callID,
            c = a.peerID;
        j({
            callID: b,
            callSummary: a,
            peerID: c
        });
        d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.removeLocalStorageObjects([{
            callID: b,
            peerID: c
        }])
    }
    g.getLoggableSummaries = k;
    g.logCallSummaries = a;
    g.logCallSummary = b
}), 98);
__d("ZenonParentCallSummaryLogProcessor", ["ZenonActorHooks", "ZenonCallSummary", "ZenonCallSummaryStore", "ZenonDismissReason", "ZenonPeerID", "ZenonSignalingProtocolUtils", "pageID", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b, e) {
            this.$2 = a.protocol, c("ZenonSignalingProtocolUtils").isMwSupportedProtocol(a.protocol) && (a.peerID = d("ZenonPeerID").ZenonMWPeerID), this.$1 = new(c("ZenonCallSummary"))(a), e && e({
                localCallID: this.$1.localCallID
            })
        }
        var e = a.prototype;
        e.$3 = function(a) {
            if (a != null) {
                a = a.deviceID;
                a = a === "mobile";
                this.$1.setIsPeerMobile(a)
            }
        };
        e.processEvent = function(a) {
            return b("regeneratorRuntime").async(function(b) {
                while (1) switch (b.prev = b.next) {
                    case 0:
                        b.t0 = a.name;
                        b.next = b.t0 === "inviteResponded" ? 3 : b.t0 === "inviteReceived" ? 5 : b.t0 === "callEnded" ? 8 : b.t0 === "callAccepted" ? 10 : b.t0 === "popupOpened" ? 13 : 16;
                        break;
                    case 3:
                        this.$1.onInviteResponded();
                        return b.abrupt("break", 16);
                    case 5:
                        this.$1.onInviteReceived();
                        this.$3(a.remoteDeviceInfo);
                        return b.abrupt("break", 16);
                    case 8:
                        this.$4(a);
                        return b.abrupt("break", 16);
                    case 10:
                        this.$1.onCallAccepted(a.trigger);
                        d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.storeCallSummary(this.$1);
                        return b.abrupt("break", 16);
                    case 13:
                        this.$5(a);
                        d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.storeCallSummary(this.$1);
                        return b.abrupt("break", 16);
                    case 16:
                    case "end":
                        return b.stop()
                }
            }, null, this)
        };
        e.$5 = function(a) {
            this.$1.setInitByPageID(c("pageID")), this.$1.setInitByAppID(d("ZenonActorHooks").ZenonActor.getAppID()), this.$1.onCallEnded(d("ZenonDismissReason").ZenonDismissReason.ClientError, !1, !0, a.isPopupBlocked ? "PopupBlocked" : "PopupPending"), d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.storeCallSummary(this.$1)
        };
        e.$4 = function(a) {
            if (c("ZenonSignalingProtocolUtils").isMwSupportedProtocol(this.$2) && a.isRemoteEnded) return;
            var b = a.endCallReason,
                e = a.endCallSubreason;
            a = a.isRemoteEnded;
            if (b === d("ZenonDismissReason").ZenonDismissReason.OtherInstanceHandled && a) return;
            this.$1.onCallEnded(b, a, !1, e);
            d("ZenonCallSummaryStore").ZenonCallSummaryStoreInstance.storeCallSummary(this.$1)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LsRtcCallSummaryFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743880");
    c = b("FalcoLoggerInternal").create("ls_rtc_call_summary", a);
    e.exports = c
}), null);
__d("LsRtcConnectionStartFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743881");
    c = b("FalcoLoggerInternal").create("ls_rtc_connection_start", a);
    e.exports = c
}), null);
__d("LsRtcPeerConnectionSummaryFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743883");
    c = b("FalcoLoggerInternal").create("ls_rtc_peer_connection_summary", a);
    e.exports = c
}), null);
__d("ZenonLSCallStartEventManager", ["ZenonCallFalcoEventUtils", "ZenonCallInfoManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$ZenonLSCallStartEventManager1 = {}, c.$ZenonLSCallStartEventManager2 = !1, c.$ZenonLSCallStartEventManager3 = !1, b) || babelHelpers.assertThisInitialized(c)
        }
        var c = b.prototype;
        c.updateEventTimestamp = function(a) {
            this.$ZenonLSCallStartEventManager1[a] == null && (this.$ZenonLSCallStartEventManager1[a] = d("ZenonCallFalcoEventUtils").performanceNowParsed())
        };
        c.receivedFromInvite = function() {
            this.$ZenonLSCallStartEventManager2 = !0
        };
        c.receivedFromServer = function() {
            this.$ZenonLSCallStartEventManager3 = !0
        };
        c.getStartEventData = function() {
            var a = this.getParsedCallInfo();
            a = a.signalingID;
            var b = babelHelpers["extends"]({}, this.getTimestamps(), this.getSharedStartCallEventData());
            a !== "" && (b.local_signaling_id = a);
            return b
        };
        c.getSharedStartCallEventData = function() {
            var a = this.getParsedCallInfo(),
                b = a.callID,
                c = a.deviceID,
                e = a.localCallID;
            a = a.peerID;
            return babelHelpers["extends"]({
                answer_sdp_received_from_server: this.$ZenonLSCallStartEventManager3,
                connection_logging_id: b,
                local_call_id: e,
                offer_sdp_received_from_invite: this.$ZenonLSCallStartEventManager2,
                peer_id: a,
                protocol: "multiway"
            }, this.$ZenonLSCallStartEventManager4 != null && {
                shared_call_id: this.$ZenonLSCallStartEventManager4
            }, {
                steady_time_ms: d("ZenonCallFalcoEventUtils").performanceNowParsed(),
                system_time_ms: String(Date.now()),
                web_device_id: c
            })
        };
        c.getTimestamps = function() {
            return this.$ZenonLSCallStartEventManager1
        };
        c.setSharedCallId = function(a) {
            this.$ZenonLSCallStartEventManager4 = a
        };
        c.save = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.storeCallStartEventManager(b, c, this)
        };
        c["delete"] = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.removeLocalStorageObjects([{
                callID: c,
                peerID: b
            }])
        };
        c.toJsonString = function() {
            var a = this.getCallInfo(),
                b = a.callID;
            a = {
                callInfo: a,
                connectionLoggingId: b,
                receivedFromInvite: this.$ZenonLSCallStartEventManager2,
                receivedFromServer: this.$ZenonLSCallStartEventManager3,
                sharedCallId: this.$ZenonLSCallStartEventManager4,
                timestamps: this.getTimestamps()
            };
            return JSON.stringify(a)
        };
        b.fromJsonString = function(a) {
            var c;
            try {
                c = JSON.parse(a)
            } catch (a) {
                return null
            }
            a = c.callInfo;
            a.deviceID;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["deviceID"]);
            a = new b(a);
            a.$ZenonLSCallStartEventManager2 = c.receivedFromInvite;
            a.$ZenonLSCallStartEventManager3 = c.receivedFromServer;
            a.$ZenonLSCallStartEventManager1 = c.timestamps;
            a.$ZenonLSCallStartEventManager4 = c.sharedCallId;
            return a
        };
        return b
    }(c("ZenonCallInfoManager"));
    g["default"] = a
}), 98);
__d("ZenonLSCallStartEventStore", ["ZenonGenericLocalStorageStore", "ZenonLSCallStartEventManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "localstorage",
        i = "RTC_LS_CALL_START_",
        j = "ls_call_start",
        k = 3;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.call(this, j, h, i) || this
        }
        var d = b.prototype;
        d.retrieveCallStartEventManager = function(a, b) {
            var d = this.getLocalStorageObjects();
            d = d[a] ? d[a][b] : null;
            if (d) return c("ZenonLSCallStartEventManager").fromJsonString(d.__d);
            else return null
        };
        d.storeCallStartEventManager = function(a, b, c) {
            this.mutateLocalStorageObjects(function(d) {
                d[a] || (d[a] = {});
                d[a][b] = {
                    __d: c.toJsonString(),
                    __t: Date.now(),
                    __z: !0
                };
                return d
            }, k, !1, {
                callID: b,
                peerID: a
            })
        };
        return b
    }(c("ZenonGenericLocalStorageStore"));
    b = new a();
    g.ZenonLSCallStartEventStoreInstance = b
}), 98);
__d("ZenonLSCallSummary", ["ZenonCallFalcoEventUtils", "ZenonCallInfoManager", "ZenonDeviceInfoHelper", "ZenonDismissReason", "ZenonLoggingEventTypes", "performanceNow", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(e, a);

        function e(b) {
            var e;
            e = a.call(this, b) || this;
            e.$ZenonLSCallSummary1 = {
                call_answered_time: "-1",
                call_connected_time: "-1",
                call_created_time: "-1",
                call_ended_time: "-1",
                last_updated_time: "-1"
            };
            e.$ZenonLSCallSummary2 = !1;
            e.$ZenonLSCallSummary3 = null;
            e.$ZenonLSCallSummary6 = null;
            e.$ZenonLSCallSummary8 = null;
            e.$ZenonLSCallSummary9 = null;
            e.$ZenonLSCallSummary10 = null;
            e.$ZenonLSCallSummary11 = null;
            e.$ZenonLSCallSummary19 = !1;
            e.$ZenonLSCallSummary12 = b.callTrigger;
            e.$ZenonLSCallSummary7 = b.isVideo;
            e.$ZenonLSCallSummary4 = 0;
            e.$ZenonLSCallSummary15 = (b = b.joinMode) != null ? b : d("ZenonLoggingEventTypes").ZenonJoinMode.Primary;
            e.$ZenonLSCallSummary5 = c("performanceNow")();
            e.setTimestamp("call_created_time");
            e.updateLastUpdatedTime();
            e.updateBatteryStart();
            return e
        }
        var f = e.prototype;
        f.setTimestamp = function(a) {
            if (this.$ZenonLSCallSummary1[a] !== "-1") return;
            this.$ZenonLSCallSummary1[a] = String(this.$ZenonLSCallSummary20())
        };
        f.getTimestamps = function() {
            return this.$ZenonLSCallSummary1
        };
        f.getExtraInfo = function() {
            var a = {};
            this.$ZenonLSCallSummary9 != null && !isNaN(this.$ZenonLSCallSummary9) && (a.battery_end_level = String(this.$ZenonLSCallSummary9));
            this.$ZenonLSCallSummary8 != null && !isNaN(this.$ZenonLSCallSummary8) && (a.battery_start_level = String(this.$ZenonLSCallSummary8));
            this.$ZenonLSCallSummary10 != null && (a.was_device_charged = this.$ZenonLSCallSummary10);
            this.$ZenonLSCallSummary11 != null && (a.max_concurrent_connected_participant = this.$ZenonLSCallSummary11);
            return a
        };
        f.getVideoStats = function() {
            var a = {};
            if (this.$ZenonLSCallSummary6 != null) {
                var b;
                isNaN(this.$ZenonLSCallSummary6.ld) || (a.local_video_duration = String(this.$ZenonLSCallSummary6.ld));
                if (!isNaN((b = this.$ZenonLSCallSummary6) == null ? void 0 : b.rd)) {
                    a.remote_video_duration = String((b = (b = this.$ZenonLSCallSummary6) == null ? void 0 : b.rd) != null ? b : 0)
                }
            }
            return a
        };
        f.getEndCallStats = function() {
            var a = {};
            this.$ZenonLSCallSummary16 != null && (a.end_call_reason = d("ZenonDismissReason").dismissToEndCallReason(this.$ZenonLSCallSummary16));
            this.$ZenonLSCallSummary17 != null && (a.end_call_subreason = this.$ZenonLSCallSummary17);
            this.$ZenonLSCallSummary19 != null && (a.remote_ended = this.$ZenonLSCallSummary19);
            this.$ZenonLSCallSummary3 != null && (a.is_connected_end = this.$ZenonLSCallSummary3);
            return a
        };
        f.getLoggingArgs = function() {
            var a = this.getParsedCallInfo(),
                b = a.callID,
                c = a.deviceID;
            a = a.peerID;
            return {
                call_id: b,
                conf_name: (b = this.$ZenonLSCallSummary14) != null ? b : "",
                peer_id: a,
                serv_info: (b = this.$ZenonLSCallSummary13) != null ? b : "",
                web_device_id: c
            }
        };
        f.getSummaryLoggingInfo = function() {
            var a, b = this.getParsedCallInfo(),
                c = b.deviceID,
                e = b.isCaller,
                f = b.localCallID;
            b = b.peerID;
            return babelHelpers["extends"]({}, this.getTimestamps(), this.getExtraInfo(), this.getVideoStats(), this.getEndCallStats(), this.$ZenonLSCallSummary13 != null && {
                shared_call_id: this.$ZenonLSCallSummary13
            }, {
                call_trigger: (a = this.$ZenonLSCallSummary12) != null ? a : "",
                invite_requested_video: this.$ZenonLSCallSummary7,
                is_caller: e,
                join_mode: String(this.$ZenonLSCallSummary15),
                local_call_id: f,
                peer_id: b,
                steady_time: d("ZenonCallFalcoEventUtils").performanceNowParsed(),
                system_time: String(Date.now()),
                web_device_id: c
            })
        };
        f.onCallEscalated = function() {
            this.updateLastUpdatedTime()
        };
        f.onCallAccepted = function(a) {
            this.$ZenonLSCallSummary12 = a, this.setTimestamp("call_answered_time"), this.updateLastUpdatedTime()
        };
        f.onCallConnected = function() {
            this.setTimestamp("call_connected_time"), this.updateLastUpdatedTime()
        };
        f.setMediaStats = function(a) {
            this.$ZenonLSCallSummary6 = a.video, this.updateLastUpdatedTime()
        };
        f.setMaxConnectedParticipants = function(a) {
            this.$ZenonLSCallSummary11 = d("ZenonCallFalcoEventUtils").nonNullIntNumber(a), this.updateLastUpdatedTime()
        };
        f.setSharedCallId = function(a) {
            this.$ZenonLSCallSummary13 = a, this.updateLastUpdatedTime()
        };
        f.unsetEndCallFields = function() {
            this.$ZenonLSCallSummary18 === !0 && (this.$ZenonLSCallSummary16 = null, this.$ZenonLSCallSummary17 = null, this.$ZenonLSCallSummary19 = null, this.$ZenonLSCallSummary3 = null, this.$ZenonLSCallSummary1.call_ended_time = "-1", this.$ZenonLSCallSummary5 = 0, this.$ZenonLSCallSummary18 = null)
        };
        f.onCallEnded = function(a, c, d, e) {
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        this.$ZenonLSCallSummary16 = a;
                        this.$ZenonLSCallSummary17 = e;
                        this.$ZenonLSCallSummary18 = d;
                        this.$ZenonLSCallSummary19 = c;
                        this.$ZenonLSCallSummary3 == null && (this.$ZenonLSCallSummary3 = this.$ZenonLSCallSummary2);
                        f.next = 7;
                        return b("regeneratorRuntime").awrap(this.updateBatteryEnd());
                    case 7:
                        this.setTimestamp("call_ended_time"), this.updateLastUpdatedTime();
                    case 9:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        f.onPCStateChange = function(a) {
            this.$ZenonLSCallSummary2 = a, this.updateLastUpdatedTime()
        };
        f.updateBatteryStart = function() {
            var a, d, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        f.next = 2;
                        return b("regeneratorRuntime").awrap(c("ZenonDeviceInfoHelper").getBatteryStats());
                    case 2:
                        a = f.sent, d = a.level, e = a.placeholder, e !== !0 && (this.$ZenonLSCallSummary8 = parseInt(d, 10));
                    case 6:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        f.updateBatteryEnd = function() {
            var a, d, e, f;
            return b("regeneratorRuntime").async(function(g) {
                while (1) switch (g.prev = g.next) {
                    case 0:
                        g.next = 2;
                        return b("regeneratorRuntime").awrap(c("ZenonDeviceInfoHelper").getBatteryStats());
                    case 2:
                        a = g.sent, d = a.level, e = a.placeholder, f = a.wasCharged, e !== !0 && (this.$ZenonLSCallSummary9 = parseInt(d, 10), this.setDeviceCharged(f));
                    case 7:
                    case "end":
                        return g.stop()
                }
            }, null, this)
        };
        f.setDeviceCharged = function(a) {
            this.$ZenonLSCallSummary10 !== !0 && (this.$ZenonLSCallSummary10 = a)
        };
        f.setConferenceName = function(a) {
            this.$ZenonLSCallSummary14 = a, this.updateLastUpdatedTime()
        };
        f.getDeviceCharged = function() {
            return this.$ZenonLSCallSummary10
        };
        e.fromJsonString = function(a) {
            var b;
            try {
                b = JSON.parse(a)
            } catch (a) {
                return null
            }
            a = b.callInfo;
            var c = a.deviceID;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["deviceID"]);
            a = new e(a);
            a.setDeviceID(c);
            a.$ZenonLSCallSummary1 = b.timestamps;
            a.$ZenonLSCallSummary2 = b.pcIsConnected;
            a.$ZenonLSCallSummary3 = b.endIsConnected;
            a.$ZenonLSCallSummary16 = b.endCallReason;
            a.$ZenonLSCallSummary17 = b.endCallSubreason;
            a.$ZenonLSCallSummary19 = b.isRemoteEnded;
            a.$ZenonLSCallSummary7 = b.isVideo;
            a.$ZenonLSCallSummary13 = b.sharedCallId;
            a.$ZenonLSCallSummary6 = {
                ld: parseInt(b.videoStats.local_video_duration, 10),
                rd: parseInt(b.videoStats.remote_video_duration, 10)
            };
            a.$ZenonLSCallSummary8 = parseInt(b.extraInfo.battery_start_level, 10);
            a.$ZenonLSCallSummary9 = parseInt(b.extraInfo.battery_end_level, 10);
            b.extraInfo.was_device_charged != null && (a.$ZenonLSCallSummary10 = b.extraInfo.was_device_charged);
            b.extraInfo.max_concurrent_connected_participant != null && (a.$ZenonLSCallSummary11 = b.extraInfo.max_concurrent_connected_participant);
            b.unsetOnRetrieve != null && (a.$ZenonLSCallSummary18 = b.unsetOnRetrieve);
            b.accumulatedCallTime != null && (a.$ZenonLSCallSummary4 = b.accumulatedCallTime);
            b.conferenceName != null && (a.$ZenonLSCallSummary14 = b.conferenceName);
            return a
        };
        f.toJsonString = function() {
            var a = {
                accumulatedCallTime: this.$ZenonLSCallSummary20(),
                callInfo: this.getCallInfo(),
                conferenceName: this.$ZenonLSCallSummary14,
                endCallReason: this.$ZenonLSCallSummary16,
                endCallSubreason: this.$ZenonLSCallSummary17,
                endIsConnected: this.$ZenonLSCallSummary3,
                extraInfo: this.getExtraInfo(),
                isRemoteEnded: this.$ZenonLSCallSummary19,
                isVideo: this.$ZenonLSCallSummary7,
                joinMode: this.$ZenonLSCallSummary15,
                pcIsConnected: this.$ZenonLSCallSummary2,
                sharedCallId: this.$ZenonLSCallSummary13,
                timestamps: this.getTimestamps(),
                unsetOnRetrieve: this.$ZenonLSCallSummary18,
                videoStats: this.getVideoStats()
            };
            return JSON.stringify(a)
        };
        f.$ZenonLSCallSummary20 = function() {
            var a = c("performanceNow")() - this.$ZenonLSCallSummary5;
            return Math.floor(this.$ZenonLSCallSummary4 + a)
        };
        f.updateLastUpdatedTime = function() {
            this.$ZenonLSCallSummary1.last_updated_time = String(this.$ZenonLSCallSummary20())
        };
        f.save = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.storeCallSummary(b, c, this)
        };
        f.remove = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.removeLocalStorageObjects([{
                callID: c,
                peerID: b
            }])
        };
        return e
    }(c("ZenonCallInfoManager"));
    g["default"] = a
}), 98);
__d("ZenonLSCallSummaryStore", ["ZenonGenericLocalStorageStore", "ZenonLSCallSummary"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "localstorage",
        i = "RTC_LS_CALL_SUMMARY_",
        j = "ls_summary",
        k = 3;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.call(this, j, h, i) || this
        }
        var d = b.prototype;
        d.retrieveCallSummary = function(a, b) {
            var d = this.getLocalStorageObjects();
            d = d[a] ? d[a][b] : null;
            if (d) return c("ZenonLSCallSummary").fromJsonString(d.__d);
            else return null
        };
        d.storeCallSummary = function(a, b, c) {
            this.mutateLocalStorageObjects(function(d) {
                d[a] || (d[a] = {});
                d[a][b] = {
                    __d: c.toJsonString(),
                    __t: Date.now(),
                    __z: !0
                };
                return d
            }, k, !1, {
                callID: b,
                peerID: a
            })
        };
        return b
    }(c("ZenonGenericLocalStorageStore"));
    b = new a();
    g.ZenonLSCallSummaryStoreInstance = b
}), 98);
__d("ZenonLSE2EEStatsManager", ["E2eeMetricsSerializers", "ZenonCallFalcoEventUtils", "ZenonCallInfoManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = c = a.call.apply(a, [this].concat(f)) || this, c.$ZenonLSE2EEStatsManager1 = {
                error_count_decrypted: 0,
                error_count_encrypted: 0,
                frames_decrypted: 0,
                frames_encrypted: 0,
                group_e2ee_metrics: d("E2eeMetricsSerializers").GroupE2eeMetrics$DefaultConstructor(),
                total_decrypt_time: 0,
                total_encrypt_time: 0
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var c = b.prototype;
        c.updateE2eeStats = function(a) {
            this.$ZenonLSE2EEStatsManager1 = a
        };
        c.getGroupE2eeMetricsInFalcoShape = function() {
            var a = this.getParsedCallInfo();
            a = a.localCallID;
            return babelHelpers["extends"]({
                local_call_id: a
            }, this.$ZenonLSE2EEStatsManager2 != null && {
                shared_call_id: this.$ZenonLSE2EEStatsManager2
            }, {
                steady_time_ms: d("ZenonCallFalcoEventUtils").performanceNowParsed(),
                system_time_ms: String(Date.now())
            }, this.$ZenonLSE2EEStatsManager1.group_e2ee_metrics)
        };
        c.setSharedCallId = function(a) {
            this.$ZenonLSE2EEStatsManager2 = a
        };
        c.save = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.storeE2eeStats(b, c, this)
        };
        c["delete"] = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.removeLocalStorageObjects([{
                callID: c,
                peerID: b
            }])
        };
        c.toJsonString = function() {
            var a = {
                callInfo: this.getCallInfo(),
                groupE2eeMetrics: this.$ZenonLSE2EEStatsManager1.group_e2ee_metrics,
                sharedCallId: this.$ZenonLSE2EEStatsManager2
            };
            return JSON.stringify(a)
        };
        b.fromJsonString = function(a) {
            var c;
            try {
                c = JSON.parse(a)
            } catch (a) {
                return null
            }
            a = c.callInfo;
            a.deviceID;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["deviceID"]);
            a = new b(a);
            a.$ZenonLSE2EEStatsManager1 = {
                error_count_decrypted: 0,
                error_count_encrypted: 0,
                frames_decrypted: 0,
                frames_encrypted: 0,
                group_e2ee_metrics: c.groupE2eeMetrics,
                total_decrypt_time: 0,
                total_encrypt_time: 0
            };
            a.$ZenonLSE2EEStatsManager2 = c.sharedCallId;
            return a
        };
        return b
    }(c("ZenonCallInfoManager"));
    g["default"] = a
}), 98);
__d("ZenonLSE2EEStore", ["ZenonGenericLocalStorageStore", "ZenonLSE2EEStatsManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "localstorage",
        i = "RTC_LS_E2EE_STATS_",
        j = "ls_e2ee_stats",
        k = 3;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.call(this, j, h, i) || this
        }
        var d = b.prototype;
        d.retrieveE2eeStats = function(a, b) {
            var d = this.getLocalStorageObjects();
            d = d[a] ? d[a][b] : null;
            if (d) return c("ZenonLSE2EEStatsManager").fromJsonString(d.__d);
            else return null
        };
        d.storeE2eeStats = function(a, b, c) {
            this.mutateLocalStorageObjects(function(d) {
                d[a] || (d[a] = {});
                d[a][b] = {
                    __d: c.toJsonString(),
                    __t: Date.now(),
                    __z: !0
                };
                return d
            }, k, !1, {
                callID: b,
                peerID: a
            })
        };
        return b
    }(c("ZenonGenericLocalStorageStore"));
    b = new a();
    g.ZenonLSE2EEStoreInstance = b
}), 98);
__d("ZenonLSPeerConnectionSummary", ["ZenonCallFalcoEventUtils", "ZenonCallInfoManager", "ZenonIceStatsParser", "ZenonLoggingEventTypes", "ZenonMWMessageTypes", "immutable", "performanceNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            b = a.call(this, b) || this;
            b.$ZenonLSPeerConnectionSummary1 = {
                CoreAudioMetrics: {
                    isstall: "0",
                    voice_detect_pct: []
                },
                CoreVideoMetrics: {
                    screen: {
                        capture_stall: {
                            is_stall: "0"
                        },
                        encode_stall: {
                            is_stall: "0"
                        },
                        sent_stall: {
                            is_stall: "0"
                        }
                    },
                    video: {
                        capture_stall: {
                            is_stall: "0"
                        },
                        encode_stall: {
                            is_stall: "0"
                        },
                        sent_stall: {
                            is_stall: "0"
                        }
                    }
                },
                DebugAudioMetrics: {
                    NetworkReceive: {}
                },
                extraInfo: {},
                receiver: {},
                receiver_pct: {
                    audio: {}
                },
                sender: {},
                sender_pct: {
                    screen: {},
                    video: {}
                },
                video: {}
            };
            b.$ZenonLSPeerConnectionSummary2 = {};
            b.$ZenonLSPeerConnectionSummary3 = {};
            b.$ZenonLSPeerConnectionSummary5 = -1;
            b.$ZenonLSPeerConnectionSummary8 = null;
            b.$ZenonLSPeerConnectionSummary9 = new Map();
            b.$ZenonLSPeerConnectionSummary11 = "unknown";
            b.$ZenonLSPeerConnectionSummary6 = c("performanceNow")();
            b.$ZenonLSPeerConnectionSummary4 = 0;
            b.$ZenonLSPeerConnectionSummary7 = null;
            return b
        }
        var e = b.prototype;
        e.$ZenonLSPeerConnectionSummary12 = function() {
            var a = this.$ZenonLSPeerConnectionSummary1.sender,
                b = a.codec;
            b = b === void 0 ? {} : b;
            var c = {
                gen0_ice_sent_host: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$ZenonLSPeerConnectionSummary2.host),
                gen0_ice_sent_relay: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$ZenonLSPeerConnectionSummary2.relay),
                gen0_ice_sent_srflx: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$ZenonLSPeerConnectionSummary2.srflx)
            };
            b = b.www;
            b != null && (c.audio_send_codec = String(b));
            this.$ZenonLSPeerConnectionSummary13(c, "audio_send_bytes_sent", a.bytes);
            this.$ZenonLSPeerConnectionSummary13(c, "audio_send_level_count", a.taulc);
            this.$ZenonLSPeerConnectionSummary13(c, "audio_send_level_sum", a.tx_sum_lvl);
            this.$ZenonLSPeerConnectionSummary13(c, "audio_send_packets_lost", a.plost);
            this.$ZenonLSPeerConnectionSummary13(c, "audio_send_packets_sent", a.psent);
            this.$ZenonLSPeerConnectionSummary13(c, "avg_video_uplink_bandwidth_estimate", a.ube_avg);
            this.$ZenonLSPeerConnectionSummary13(c, "transport_conn_rtt_avg", a.avgrtt);
            return c
        };
        e.$ZenonLSPeerConnectionSummary13 = function(a, b, c) {
            c != null && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(c))
        };
        e.$ZenonLSPeerConnectionSummary14 = function() {
            var a, b, c;
            a = (a = this.$ZenonLSPeerConnectionSummary1.video.sender) == null ? void 0 : a.ss;
            b = (b = a == null ? void 0 : a.frames) != null ? b : 0;
            c = (c = a == null ? void 0 : a.eqps) != null ? c : 0;
            c = b > 0 && c > 0 ? c / b : null;
            b = {};
            this.$ZenonLSPeerConnectionSummary15(b, "avg_video_actual_encode_bitrate_ss", a == null ? void 0 : a.avbr);
            this.$ZenonLSPeerConnectionSummary15(b, "avg_video_uplink_bandwidth_estimate_ss", a == null ? void 0 : a.avbw);
            this.$ZenonLSPeerConnectionSummary15(b, "video_send_duration_ss", a == null ? void 0 : a.dur);
            this.$ZenonLSPeerConnectionSummary15(b, "video_send_frames_send_to_encoder_ss", a == null ? void 0 : a.eiframes);
            this.$ZenonLSPeerConnectionSummary15(b, "video_send_total_input_pixel_ss", a == null ? void 0 : a.video_sum_capture_pixel);
            this.$ZenonLSPeerConnectionSummary15(b, "video_send_total_output_pixel_ss", a == null ? void 0 : a.video_sum_encoded_pixel);
            this.$ZenonLSPeerConnectionSummary15(b, "video_send_frames_encoded_ss", a == null ? void 0 : a.frames);
            this.$ZenonLSPeerConnectionSummary15(b, "video_send_qp_sum_ss", c);
            return b
        };
        e.$ZenonLSPeerConnectionSummary15 = function(a, b, c) {
            c != null && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(c))
        };
        e.$ZenonLSPeerConnectionSummary16 = function() {
            var a = this.$ZenonLSPeerConnectionSummary1.video.bwe,
                b = {};
            this.$ZenonLSPeerConnectionSummary17(b, "avg_video_actual_encode_bitrate", a == null ? void 0 : a.avg_enc_bitrate);
            this.$ZenonLSPeerConnectionSummary17(b, "avg_video_retransmit_bitrate", a == null ? void 0 : a.avg_retrans_bitrate);
            this.$ZenonLSPeerConnectionSummary17(b, "avg_video_transmit_bitrate", a == null ? void 0 : a.avg_trans_bitrate);
            this.$ZenonLSPeerConnectionSummary17(b, "avg_video_uplink_bandwidth_estimate", a == null ? void 0 : a.avg_send_bw);
            return b
        };
        e.$ZenonLSPeerConnectionSummary17 = function(a, b, c) {
            c != null && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(c))
        };
        e.$ZenonLSPeerConnectionSummary18 = function() {
            var a;
            a = (a = this.$ZenonLSPeerConnectionSummary1.sender_pct.video) == null ? void 0 : a.vqs;
            var b = {};
            (a == null ? void 0 : a.avg) != null && (b.video_send_quality_score = d("ZenonCallFalcoEventUtils").truncateNumber(a == null ? void 0 : a.avg));
            return b
        };
        e.$ZenonLSPeerConnectionSummary19 = function() {
            var a = this.$ZenonLSPeerConnectionSummary1.video.sender,
                b = {
                    video_send_codec: a == null ? void 0 : a.ename
                };
            this.$ZenonLSPeerConnectionSummary20(b, "video_recv_firs_sent", a == null ? void 0 : a.fir);
            this.$ZenonLSPeerConnectionSummary20(b, "video_recv_nacks_sent", a == null ? void 0 : a.nack);
            this.$ZenonLSPeerConnectionSummary20(b, "video_recv_plis_sent", a == null ? void 0 : a.pli);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frame_height", a == null ? void 0 : a.ah);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frame_height_input", a == null ? void 0 : a.ch);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frame_width", a == null ? void 0 : a.aw);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frame_width_input", a == null ? void 0 : a.cw);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frames_captured", a == null ? void 0 : a.fcap);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frames_encoded", a == null ? void 0 : a.frames);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frames_sent", a == null ? void 0 : a.fcsn);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_frames_send_to_encoder", a == null ? void 0 : a.eiframes);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_capture_duration_ms", this.$ZenonLSPeerConnectionSummary1.video.ld);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_key_frames_encoded", a == null ? void 0 : a.kframes);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_packets_lost", a == null ? void 0 : a.plost);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_packets_sent", a == null ? void 0 : a.psent);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_qp_sum", a == null ? void 0 : a.eqps);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_total_input_pixel", a == null ? void 0 : a.video_sum_capture_pixel);
            this.$ZenonLSPeerConnectionSummary20(b, "video_send_total_output_pixel", a == null ? void 0 : a.video_sum_encoded_pixel);
            return b
        };
        e.$ZenonLSPeerConnectionSummary20 = function(a, b, c) {
            c != null && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(c))
        };
        e.$ZenonLSPeerConnectionSummary21 = function() {
            var a, b = this.$ZenonLSPeerConnectionSummary1.video.receiver,
                c = {
                    video_recv_codec: b == null ? void 0 : b.dname
                };
            this.$ZenonLSPeerConnectionSummary22(c, "audio_recv_jitter_buffer_frames_assembled", b == null ? void 0 : b.jtasb);
            this.$ZenonLSPeerConnectionSummary22(c, "audio_recv_jitter_buffer_frames_out", b == null ? void 0 : b.jtfrm);
            this.$ZenonLSPeerConnectionSummary22(c, "audio_recv_jitter_buffer_keyframes_out", b == null ? void 0 : b.jtkey);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_agg_bytes_decoded", b == null ? void 0 : b.dec_bytes);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_agg_packets_lost", b == null ? void 0 : b.plost);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_agg_packets_recv", b == null ? void 0 : b.precv);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_av_sync_abs", b == null ? void 0 : b.avabs);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_avg_e2e_latency_ms", b == null ? void 0 : b.e2el);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_frame_height", b == null ? void 0 : b.rh);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_frame_width", b == null ? void 0 : b.rw);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_frames_decoded", b == null ? void 0 : b.frd);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_freeze_count", b == null ? void 0 : b.frcnt);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_freeze_duration", b == null ? void 0 : b.frdur);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_freeze_duration_above_500_ms", b == null ? void 0 : b.frdur500);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_pause_count", b == null ? void 0 : b.pact);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_pause_duration_ms", b == null ? void 0 : b.padur);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_qp_sum", b == null ? void 0 : b.qps);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_total_pixels_decoded", b == null ? void 0 : b.agg_video_sum_decoded_pixel);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_union_decode_time_ms", b == null ? void 0 : b.dec_time);
            this.$ZenonLSPeerConnectionSummary22(c, "video_send_firs_recv", b == null ? void 0 : b.fir);
            this.$ZenonLSPeerConnectionSummary22(c, "video_send_nacks_recv", b == null ? void 0 : b.nack);
            this.$ZenonLSPeerConnectionSummary22(c, "video_send_plis_recv", b == null ? void 0 : b.pli);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_weighted_vqs", b == null ? void 0 : (a = b.vqs) == null ? void 0 : a.avg);
            a = b == null ? void 0 : b.dec_time_all_streams;
            b = b == null ? void 0 : b.dec_frame;
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_agg_decode_time_ms", a);
            this.$ZenonLSPeerConnectionSummary22(c, "video_recv_agg_frames_decoded", b);
            a != null && a > 0 && b != null && b > 0 && this.$ZenonLSPeerConnectionSummary22(c, "video_recv_framerate_decoded", b * 1e3 / a);
            return c
        };
        e.$ZenonLSPeerConnectionSummary22 = function(a, b, c) {
            c != null && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(c))
        };
        e.$ZenonLSPeerConnectionSummary23 = function() {
            var a, b, c = this.$ZenonLSPeerConnectionSummary1.DebugAudioMetrics.NetworkReceive.jb_nm;
            a = c == null ? void 0 : (a = c.neteq) == null ? void 0 : a.meanWait;
            b = c == null ? void 0 : (b = c.speech_expand_rate) == null ? void 0 : b.avg;
            c = c == null ? void 0 : (c = c.speech_expand_rate) == null ? void 0 : c.M;
            var d = {};
            a != null && (d.audio_recv_neteq_mean_wait_ms = String(a));
            b != null && (d.audio_recv_neteq_speech_expand_rate_avg = String(b));
            c != null && (d.audio_recv_neteq_speech_expand_rate_max = String(c));
            return d
        };
        e.$ZenonLSPeerConnectionSummary24 = function() {
            var a = this.$ZenonLSPeerConnectionSummary1.CoreAudioMetrics,
                b = a.audio_device,
                c = a.isstall,
                d = a.sdur;
            a = a.astall;
            var e = {};
            b != null && (e.audio_device = String(b));
            c != null && (e.audio_device_is_stalled = String(c));
            d != null && (e.audio_device_stall_duration = String(d));
            a != null && (e.audio_device_total_stall = String(a));
            return e
        };
        e.$ZenonLSPeerConnectionSummary25 = function() {
            var a = this.$ZenonLSPeerConnectionSummary1,
                b = a.receiver;
            a = a.receiver_pct;
            var c = null;
            b.codec != null && (c = String(Object.values(b.codec).pop()));
            var e = {
                gen0_ice_received_host: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$ZenonLSPeerConnectionSummary3.host),
                gen0_ice_received_relay: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$ZenonLSPeerConnectionSummary3.relay),
                gen0_ice_received_srflx: d("ZenonCallFalcoEventUtils").nonNullIntNumber(this.$ZenonLSPeerConnectionSummary3.srflx)
            };
            c != null && (e.audio_recv_codec = String(c));
            this.$ZenonLSPeerConnectionSummary26(e, "audio_ctp_latency_avg_us", (c = a.audio.jbd) == null ? void 0 : c.avg, (c = a.audio.rtt) == null ? void 0 : c.avg);
            this.$ZenonLSPeerConnectionSummary26(e, "audio_ctp_latency_p5_us", (c = a.audio.jbd) == null ? void 0 : c.p5, (c = a.audio.rtt) == null ? void 0 : c.p5);
            this.$ZenonLSPeerConnectionSummary26(e, "audio_ctp_latency_p50_us", (c = a.audio.jbd) == null ? void 0 : c.p50, (c = a.audio.rtt) == null ? void 0 : c.p50);
            this.$ZenonLSPeerConnectionSummary26(e, "audio_ctp_latency_p95_us", (c = a.audio.jbd) == null ? void 0 : c.p95, (c = a.audio.rtt) == null ? void 0 : c.p95);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_avg_e2e_latency_ms", b.e2el);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_bytes_recv", b.bytes);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_fec_packets_discarded", b.fecpd);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_fec_packets_received", b.fecpr);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_jitter", b.jitter);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_jitter_buffer_flushes", b.dec_pack_flush);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_level_count", b.taulc);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_level_sum", b.rx_sum_lvl);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_total_samples_duration", b.sp_dur);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_accelerate", b.dec_ar);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_cng", b.dec_cng);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_normal", b.dec_normal);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_operations", b.neteq_calls);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_plc", b.dec_plc);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_plccng", b.dec_plc_cng);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_neteq_preemptive_expand", b.dec_per);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_packets_lost", b.plost);
            this.$ZenonLSPeerConnectionSummary27(e, "audio_recv_packets_recv", b.precv);
            return e
        };
        e.$ZenonLSPeerConnectionSummary27 = function(a, b, c) {
            c != null && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(c))
        };
        e.$ZenonLSPeerConnectionSummary28 = function() {
            var a = c("immutable").OrderedMap(this.$ZenonLSPeerConnectionSummary9),
                b = {};
            if (Object.keys(a).length === 0) return b;
            var e = 0,
                f = !1,
                g = 0,
                h = 0;
            a.forEach(function(a, b) {
                f !== a && (a ? e > 0 && (h++, g += b - e, e = 0) : e = b, f = a)
            });
            if (e > 0) {
                a = this.$ZenonLSPeerConnectionSummary5;
                a > -1 && a > e && (h++, g += a - e)
            }
            b.transport_num_gaps = d("ZenonCallFalcoEventUtils").nonNullIntNumber(h);
            b.transport_total_gap_duration_ms = d("ZenonCallFalcoEventUtils").nonNullIntNumber(g);
            this.$ZenonLSPeerConnectionSummary8 != null && (b.transport_connected = this.$ZenonLSPeerConnectionSummary8 ? "1" : "0");
            return b
        };
        e.onCallEnded = function() {
            this.$ZenonLSPeerConnectionSummary5 = this.$ZenonLSPeerConnectionSummary29(), this.$ZenonLSPeerConnectionSummary8 == null && (this.$ZenonLSPeerConnectionSummary8 = this.$ZenonLSPeerConnectionSummary7)
        };
        e.$ZenonLSPeerConnectionSummary26 = function(a, b, c, e) {
            var f = 0;
            c != null && (f += c);
            e != null && (f += e / 2);
            f > 0 && (a[b] = d("ZenonCallFalcoEventUtils").truncateNumber(f))
        };
        e.getPeerConnectionSummary = function() {
            var a = this.getParsedCallInfo(),
                b = a.callID,
                c = a.deviceID,
                e = a.localCallID;
            a = a.peerID;
            return babelHelpers["extends"]({}, this.$ZenonLSPeerConnectionSummary24(), this.$ZenonLSPeerConnectionSummary12(), this.$ZenonLSPeerConnectionSummary25(), this.$ZenonLSPeerConnectionSummary14(), this.$ZenonLSPeerConnectionSummary16(), this.$ZenonLSPeerConnectionSummary18(), this.$ZenonLSPeerConnectionSummary19(), this.$ZenonLSPeerConnectionSummary21(), this.$ZenonLSPeerConnectionSummary23(), this.$ZenonLSPeerConnectionSummary28(), this.$ZenonLSPeerConnectionSummary10 != null && {
                shared_call_id: this.$ZenonLSPeerConnectionSummary10
            }, {
                connection_logging_id: b,
                local_call_id: e,
                media_path: this.$ZenonLSPeerConnectionSummary11,
                peer_id: a,
                protocol: "multiway",
                steady_time_ms: d("ZenonCallFalcoEventUtils").performanceNowParsed(),
                system_time_ms: String(Date.now()),
                web_device_id: c
            })
        };
        e.$ZenonLSPeerConnectionSummary29 = function() {
            var a = c("performanceNow")() - this.$ZenonLSPeerConnectionSummary6;
            return Math.floor(this.$ZenonLSPeerConnectionSummary4 + a)
        };
        e.updateIceInfo = function(a, b) {
            var c = b === d("ZenonLoggingEventTypes").ZenonUpdateIceInfoDirection.Send ? this.$ZenonLSPeerConnectionSummary2 : this.$ZenonLSPeerConnectionSummary3;
            b = d("ZenonIceStatsParser").extractIceInfo(a);
            b.forEach(function(a) {
                var b = a.gen;
                a = a.type;
                b === 0 && (c[a] == null ? c[a] = 1 : c[a]++)
            })
        };
        e.onPCStateChange = function(a) {
            this.$ZenonLSPeerConnectionSummary7 !== a && (this.$ZenonLSPeerConnectionSummary7 = a, this.$ZenonLSPeerConnectionSummary9.set(this.$ZenonLSPeerConnectionSummary29(), a))
        };
        e.$ZenonLSPeerConnectionSummary30 = function(a) {
            switch (a) {
                case d("ZenonMWMessageTypes").ZenonMWMediaPath.SFU:
                    return "sfu";
                case d("ZenonMWMessageTypes").ZenonMWMediaPath.P2P:
                    return "p2p";
                case d("ZenonMWMessageTypes").ZenonMWMediaPath.UNKNOWN:
                default:
                    return "unknown"
            }
        };
        e.setMediaPath = function(a) {
            this.$ZenonLSPeerConnectionSummary11 = this.$ZenonLSPeerConnectionSummary30(a)
        };
        e.setMediaStats = function(a) {
            this.$ZenonLSPeerConnectionSummary1 = a
        };
        e.setSharedCallId = function(a) {
            this.$ZenonLSPeerConnectionSummary10 = a
        };
        e.save = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.storePeerConnectionSummary(b, c, this)
        };
        e["delete"] = function(a) {
            var b = this.getCallInfo(),
                c = b.callID;
            b = b.peerID;
            a.removeLocalStorageObjects([{
                callID: c,
                peerID: b
            }])
        };
        e.toJsonString = function() {
            var a = this.getCallInfo();
            a = a.callID;
            a = {
                accumulatedCallTime: this.$ZenonLSPeerConnectionSummary29(),
                callInfo: this.getCallInfo(),
                connectionLoggingId: a,
                endIsConnected: this.$ZenonLSPeerConnectionSummary8,
                gen0IceReceivedCount: this.$ZenonLSPeerConnectionSummary3,
                gen0IceSentCount: this.$ZenonLSPeerConnectionSummary2,
                mediaPath: this.$ZenonLSPeerConnectionSummary11,
                mediaStats: this.$ZenonLSPeerConnectionSummary1,
                pcIsConnected: this.$ZenonLSPeerConnectionSummary7,
                sharedCallId: this.$ZenonLSPeerConnectionSummary10
            };
            return JSON.stringify(a)
        };
        b.fromJsonString = function(a) {
            var c, d;
            try {
                d = JSON.parse(a)
            } catch (a) {
                return null
            }
            a = d.callInfo;
            a.deviceID;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["deviceID"]);
            a = new b(a);
            a.$ZenonLSPeerConnectionSummary11 = d.mediaPath;
            a.$ZenonLSPeerConnectionSummary1 = d.mediaStats;
            a.$ZenonLSPeerConnectionSummary3 = d.gen0IceReceivedCount;
            a.$ZenonLSPeerConnectionSummary2 = d.gen0IceSentCount;
            a.$ZenonLSPeerConnectionSummary10 = d.sharedCallId;
            a.$ZenonLSPeerConnectionSummary7 = (c = d.pcIsConnected) != null ? c : null;
            a.$ZenonLSPeerConnectionSummary8 = d.endIsConnected;
            d.accumulatedCallTime != null && (a.$ZenonLSPeerConnectionSummary4 = d.accumulatedCallTime);
            return a
        };
        return b
    }(c("ZenonCallInfoManager"));
    g["default"] = a
}), 98);
__d("ZenonLSPeerConnectionSummaryStore", ["ZenonGenericLocalStorageStore", "ZenonLSPeerConnectionSummary"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "localstorage",
        i = "RTC_LS_PCS_",
        j = "ls_pcs",
        k = 3;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.call(this, j, h, i) || this
        }
        var d = b.prototype;
        d.retrievePeerConnectionSummary = function(a, b) {
            var d = this.getLocalStorageObjects();
            d = d[a] ? d[a][b] : null;
            if (d) return c("ZenonLSPeerConnectionSummary").fromJsonString(d.__d);
            else return null
        };
        d.storePeerConnectionSummary = function(a, b, c) {
            this.mutateLocalStorageObjects(function(d) {
                d[a] || (d[a] = {});
                d[a][b] = {
                    __d: c.toJsonString(),
                    __t: Date.now(),
                    __z: !0
                };
                return d
            }, k, !1, {
                callID: b,
                peerID: a
            })
        };
        return b
    }(c("ZenonGenericLocalStorageStore"));
    b = new a();
    g.ZenonLSPeerConnectionSummaryStoreInstance = b
}), 98);
__d("ZenonLSLogsUploader", ["DateConsts", "LsRtcCallSummaryFalcoEvent", "LsRtcConnectionStartFalcoEvent", "LsRtcGroupE2eeFalcoEvent", "LsRtcPeerConnectionSummaryFalcoEvent", "ZenonInfraActionsLogger", "ZenonLSCallStartEventManager", "ZenonLSCallStartEventStore", "ZenonLSCallSummary", "ZenonLSCallSummaryStore", "ZenonLSE2EEStatsManager", "ZenonLSE2EEStore", "ZenonLSPeerConnectionSummary", "ZenonLSPeerConnectionSummaryStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("DateConsts").MS_PER_MIN * 30,
        i = {
            getLoggableEndCallLogs: function(a) {
                a = a.getLocalStorageObjects();
                var b = [];
                for (var c in a)
                    for (var d in a[c]) {
                        var e = a[c][d];
                        if (e.__z) {
                            var f = e.__t;
                            if (Date.now() - f > h) {
                                f = e.__d;
                                b.push({
                                    callID: d,
                                    endCallLogStr: f,
                                    peerID: c
                                })
                            }
                        }
                    }
                return b
            },
            logCallStartEventManager: function(a) {
                var b = a.callID,
                    e = a.callStartEventManager;
                a = a.peerID;
                c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                    checkpoint: "Uploading NSL call start summary from local storage peerID: " + a + ", callID: " + b
                });
                c("LsRtcConnectionStartFalcoEvent").logCritical(function() {
                    return e.getStartEventData()
                });
                d("ZenonLSCallStartEventStore").ZenonLSCallStartEventStoreInstance.removeLocalStorageObjects([{
                    callID: b,
                    peerID: a
                }])
            },
            logCallStartEvents: function() {
                var a = i.getLoggableEndCallLogs(d("ZenonLSCallStartEventStore").ZenonLSCallStartEventStoreInstance);
                a.forEach(function(a) {
                    var b = a.callID,
                        d = a.endCallLogStr;
                    a = a.peerID;
                    try {
                        d = c("ZenonLSCallStartEventManager").fromJsonString(d);
                        d && i.logCallStartEventManager({
                            callID: b,
                            callStartEventManager: d,
                            peerID: a
                        })
                    } catch (a) {
                        c("ZenonInfraActionsLogger").logError({
                            error: a.message,
                            errorDomain: "ZenonLSLogsUploader_callStartEvent"
                        })
                    }
                })
            },
            logCallSummaries: function() {
                var a = i.getLoggableEndCallLogs(d("ZenonLSCallSummaryStore").ZenonLSCallSummaryStoreInstance);
                a.forEach(function(a) {
                    var b = a.callID,
                        d = a.endCallLogStr;
                    a = a.peerID;
                    try {
                        d = c("ZenonLSCallSummary").fromJsonString(d);
                        d && i.logCallSummary({
                            callID: b,
                            callSummary: d,
                            peerID: a
                        })
                    } catch (a) {
                        c("ZenonInfraActionsLogger").logError({
                            error: a.message,
                            errorDomain: "ZenonLSLogsUploader_callSummary"
                        })
                    }
                })
            },
            logCallSummary: function(a) {
                var b = a.callID,
                    e = a.callSummary;
                a = a.peerID;
                c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                    checkpoint: "Uploading NSL call summary from local storage peerID: " + a + ", callID: " + b
                });
                c("LsRtcCallSummaryFalcoEvent").logCritical(function() {
                    return babelHelpers["extends"]({}, e.getSummaryLoggingInfo())
                });
                d("ZenonLSCallSummaryStore").ZenonLSCallSummaryStoreInstance.removeLocalStorageObjects([{
                    callID: b,
                    peerID: a
                }])
            },
            logE2eeStats: function() {
                var a = i.getLoggableEndCallLogs(d("ZenonLSE2EEStore").ZenonLSE2EEStoreInstance);
                a.forEach(function(a) {
                    var b = a.callID,
                        d = a.endCallLogStr;
                    a = a.peerID;
                    try {
                        d = c("ZenonLSE2EEStatsManager").fromJsonString(d);
                        d && i.logE2eeStatsManager({
                            callID: b,
                            e2eeStatsManager: d,
                            peerID: a
                        })
                    } catch (a) {
                        c("ZenonInfraActionsLogger").logError({
                            error: a.message,
                            errorDomain: "ZenonLSLogsUploader_e2eeStats"
                        })
                    }
                })
            },
            logE2eeStatsManager: function(a) {
                var b = a.callID,
                    e = a.e2eeStatsManager;
                a = a.peerID;
                c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                    checkpoint: "Uploading NSL E2EE summary from local storage peerID: " + a + ", callID: " + b
                });
                c("LsRtcGroupE2eeFalcoEvent").logCritical(function() {
                    return e.getGroupE2eeMetricsInFalcoShape()
                });
                d("ZenonLSE2EEStore").ZenonLSE2EEStoreInstance.removeLocalStorageObjects([{
                    callID: b,
                    peerID: a
                }])
            },
            logEndCallLogEvents: function() {
                i.logCallSummaries(), i.logE2eeStats(), i.logPeerConnectionSummaries(), i.logCallStartEvents()
            },
            logPeerConnectionSummaries: function() {
                var a = i.getLoggableEndCallLogs(d("ZenonLSPeerConnectionSummaryStore").ZenonLSPeerConnectionSummaryStoreInstance);
                a.forEach(function(a) {
                    var b = a.callID,
                        d = a.endCallLogStr;
                    a = a.peerID;
                    try {
                        d = c("ZenonLSPeerConnectionSummary").fromJsonString(d);
                        d && i.logPeerConnectionSummary({
                            callID: b,
                            peerConnectionSummary: d,
                            peerID: a
                        })
                    } catch (a) {
                        c("ZenonInfraActionsLogger").logError({
                            error: a.message,
                            errorDomain: "ZenonLSLogsUploader_peerConnectionSummary"
                        })
                    }
                })
            },
            logPeerConnectionSummary: function(a) {
                var b = a.callID,
                    e = a.peerConnectionSummary;
                a = a.peerID;
                c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                    checkpoint: "Uploading NSL PCS summary from local storage peerID: " + a + ", callID: " + b
                });
                c("LsRtcPeerConnectionSummaryFalcoEvent").logCritical(function() {
                    return e.getPeerConnectionSummary()
                });
                d("ZenonLSPeerConnectionSummaryStore").ZenonLSPeerConnectionSummaryStoreInstance.removeLocalStorageObjects([{
                    callID: b,
                    peerID: a
                }])
            }
        };
    a = i;
    g["default"] = a
}), 98);
__d("ZenonParentLSCallSummaryLogProcessor", ["ZenonDismissReason", "ZenonInfraActionsLogger", "ZenonLSCallStartEventManager", "ZenonLSCallStartEventStore", "ZenonLSCallSummary", "ZenonLSCallSummaryStore", "ZenonLSE2EEStatsManager", "ZenonLSE2EEStore", "ZenonLSPeerConnectionSummary", "ZenonLSPeerConnectionSummaryStore", "ZenonPeerID", "ZenonSignalingProtocolUtils", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            c("ZenonSignalingProtocolUtils").isMwSupportedProtocol(a.protocol) && (a.peerID = d("ZenonPeerID").ZenonMWPeerID), this.$5 = a.protocol, this.$1 = new(c("ZenonLSCallSummary"))(a), this.$2 = new(c("ZenonLSPeerConnectionSummary"))(a), this.$3 = new(c("ZenonLSCallStartEventManager"))(a), this.$4 = new(c("ZenonLSE2EEStatsManager"))(a), c("ZenonInfraActionsLogger").logCheckpointEmployeesTestUsersOnly({
                checkpoint: "NSL - created call summaries in parent window"
            })
        }
        var e = a.prototype;
        e.processEvent = function(a) {
            return b("regeneratorRuntime").async(function(c) {
                while (1) switch (c.prev = c.next) {
                    case 0:
                        c.t0 = a.name;
                        c.next = c.t0 === "callAccepted" ? 3 : c.t0 === "callEnded" ? 9 : c.t0 === "inviteReceived" ? 12 : c.t0 === "popupOpened" ? 14 : 21;
                        break;
                    case 3:
                        this.$1.onCallAccepted(a.trigger);
                        this.$1.save(d("ZenonLSCallSummaryStore").ZenonLSCallSummaryStoreInstance);
                        this.$2.save(d("ZenonLSPeerConnectionSummaryStore").ZenonLSPeerConnectionSummaryStoreInstance);
                        this.$3.save(d("ZenonLSCallStartEventStore").ZenonLSCallStartEventStoreInstance);
                        this.$4.save(d("ZenonLSE2EEStore").ZenonLSE2EEStoreInstance);
                        return c.abrupt("break", 21);
                    case 9:
                        c.next = 11;
                        return b("regeneratorRuntime").awrap(this.$6(a));
                    case 11:
                        return c.abrupt("break", 21);
                    case 12:
                        this.$7(a);
                        return c.abrupt("break", 21);
                    case 14:
                        c.next = 16;
                        return b("regeneratorRuntime").awrap(this.$8(a));
                    case 16:
                        this.$1.save(d("ZenonLSCallSummaryStore").ZenonLSCallSummaryStoreInstance);
                        this.$2.save(d("ZenonLSPeerConnectionSummaryStore").ZenonLSPeerConnectionSummaryStoreInstance);
                        this.$3.save(d("ZenonLSCallStartEventStore").ZenonLSCallStartEventStoreInstance);
                        this.$4.save(d("ZenonLSE2EEStore").ZenonLSE2EEStoreInstance);
                        return c.abrupt("break", 21);
                    case 21:
                    case "end":
                        return c.stop()
                }
            }, null, this)
        };
        e.$7 = function(a) {
            a = a.serverInfoData;
            if (a == null) return;
            this.$1.setSharedCallId(a);
            this.$2.setSharedCallId(a);
            this.$3.setSharedCallId(a);
            this.$4.setSharedCallId(a)
        };
        e.$8 = function(a) {
            return b("regeneratorRuntime").async(function(c) {
                while (1) switch (c.prev = c.next) {
                    case 0:
                        c.next = 2;
                        return b("regeneratorRuntime").awrap(this.$1.onCallEnded(d("ZenonDismissReason").ZenonDismissReason.ClientError, !1, !0, a.isPopupBlocked ? "PopupBlocked" : "PopupPending"));
                    case 2:
                        this.$1.save(d("ZenonLSCallSummaryStore").ZenonLSCallSummaryStoreInstance);
                    case 3:
                    case "end":
                        return c.stop()
                }
            }, null, this)
        };
        e.$6 = function(a) {
            var e, f, g;
            return b("regeneratorRuntime").async(function(h) {
                while (1) switch (h.prev = h.next) {
                    case 0:
                        if (!(c("ZenonSignalingProtocolUtils").isMwSupportedProtocol(this.$5) && a.isRemoteEnded)) {
                            h.next = 2;
                            break
                        }
                        return h.abrupt("return");
                    case 2:
                        e = a.endCallReason, f = a.endCallSubreason, g = a.isRemoteEnded;
                        if (!(e === d("ZenonDismissReason").ZenonDismissReason.OtherInstanceHandled && g)) {
                            h.next = 5;
                            break
                        }
                        return h.abrupt("return");
                    case 5:
                        h.next = 7;
                        return b("regeneratorRuntime").awrap(this.$1.onCallEnded(e, g, !1, f));
                    case 7:
                        this.$1.save(d("ZenonLSCallSummaryStore").ZenonLSCallSummaryStoreInstance), this.$2.save(d("ZenonLSPeerConnectionSummaryStore").ZenonLSPeerConnectionSummaryStoreInstance), this.$3.save(d("ZenonLSCallStartEventStore").ZenonLSCallStartEventStoreInstance), this.$4.save(d("ZenonLSE2EEStore").ZenonLSE2EEStoreInstance);
                    case 11:
                    case "end":
                        return h.stop()
                }
            }, null, this)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("FBRTCCallSummaryUploader", ["DateConsts", "ZenonCallSummaryUploader", "cr:4943"], (function(a, b, c, d, e, f, g) {
    var h = 1 * d("DateConsts").MS_PER_MIN,
        i = null,
        j = 10 * d("DateConsts").MS_PER_MIN,
        k = null;

    function a() {
        if (i !== null && k !== null) return;
        i = window.setInterval(function() {
            d("ZenonCallSummaryUploader").logCallSummaries()
        }, h);
        k = window.setInterval(function() {
            b("cr:4943") == null ? void 0 : b("cr:4943").logEndCallLogEvents()
        }, j)
    }
    g.init = a
}), 98);