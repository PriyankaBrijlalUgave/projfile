if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("usePremiumMusicVideoInterruptionSubscription_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5597508366945721"
}), null);
__d("usePremiumMusicVideoInterruptionSubscription.graphql", ["usePremiumMusicVideoInterruptionSubscription_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "data",
                    variableName: "input"
                }],
                concreteType: "PremiumMusicVideoInterruptionSubscribeResponsePayload",
                kind: "LinkedField",
                name: "premium_music_video_interruption_subscribe",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "disable_autoplay",
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "usePremiumMusicVideoInterruptionSubscription",
                selections: c,
                type: "Subscription",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "usePremiumMusicVideoInterruptionSubscription",
                selections: c
            },
            params: {
                id: b("usePremiumMusicVideoInterruptionSubscription_facebookRelayOperation"),
                metadata: {
                    subscriptionName: "premium_music_video_interruption_subscribe"
                },
                name: "usePremiumMusicVideoInterruptionSubscription",
                operationKind: "subscription",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("VideoPlayerRelay_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            defaultValue: null,
            kind: "LocalArgument",
            name: "playerOrigin"
        }, {
            defaultValue: null,
            kind: "LocalArgument",
            name: "playerSuborigin"
        }],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerRelay_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "animated_image_caption",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "original_width",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "original_height",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "broadcaster_origin",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "broadcast_id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "broadcast_status",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "dash_manifest",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_live_streaming",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_live_trace_enabled",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_looping",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_video_broadcast",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_podcast_video",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "loop_count",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_spherical",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_spherical_enabled",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "unsupported_browser_message",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "MusicVideoMetadata",
            kind: "LinkedField",
            name: "pmv_metadata",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "LatencySensitiveConfig",
            kind: "LinkedField",
            name: "latency_sensitive_config",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "broadcast_latency_sensitivity",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "LivePlaybackInstrumentationConfigParams",
            kind: "LinkedField",
            name: "live_playback_instrumentation_configs",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_client_triggered_trace_enabled",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_ncsr",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "permalink_url",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "captions_url",
            storageKey: null
        }, {
            alias: null,
            args: [{
                kind: "Variable",
                name: "player_origin",
                variableName: "playerOrigin"
            }, {
                kind: "Variable",
                name: "player_suborigin",
                variableName: "playerSuborigin"
            }],
            kind: "ScalarField",
            name: "dash_prefetch_experimental",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "VideoCaptionLocale",
            kind: "LinkedField",
            name: "video_available_captions_locales",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "localized_creation_method",
                storageKey: null
            }],
            storageKey: null
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoImplementationsImpl_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerShakaConfig_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useResolvedVideoPlayerConfigs_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerShakaPerformanceLoggerRelayImpl_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerShakaPerformanceLoggerBuilder_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useGraphQLVideoAutoplayGatingResult_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useGraphQLVideoDRMInfo_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useGraphQLVideoP2PSettings_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerAudioSettings_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerCaptionsSettings_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerLiveLatencyKnobSettings_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerAudioAvailabilityInfoRelay_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useProgressiveImplementationData_video"
        }, {
            alias: null,
            args: null,
            concreteType: "SphericalVideoRenderer",
            kind: "LinkedField",
            name: "spherical_video_renderer",
            plural: !1,
            selections: [{
                args: null,
                documentName: "VideoPlayerRelay_video_spherical_video_renderer",
                fragmentName: "VideoPlayerSphericalRelay_sphericalVideoRenderer",
                fragmentPropName: "sphericalVideoRenderer",
                kind: "ModuleImport"
            }],
            storageKey: null
        }, {
            kind: "Defer",
            selections: [{
                args: null,
                kind: "FragmentSpread",
                name: "InstreamVideoAdBreaksPlayer_video"
            }]
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerVideoIsCastingCover_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useVideoPlayerIMFFromVideoMetadataRelay_video"
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerAudioSettings_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerAudioSettings_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "AudioSettings",
            kind: "LinkedField",
            name: "audio_settings",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "video_volume_setting",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerAudioAvailabilityInfoRelay_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerAudioAvailabilityInfoRelay_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "audio_availability",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "VideoMutedSegment",
            kind: "LinkedField",
            name: "muted_segments",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mute_start_time_in_sec",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mute_end_time_in_sec",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useGraphQLVideoAutoplayGatingResult_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useGraphQLVideoAutoplayGatingResult_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "autoplay_gating_result",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "viewer_autoplay_setting",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "can_autoplay",
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerDefaultControls_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerDefaultControls_video",
        selections: [{
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerDefaultControlsImplLive_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerDefaultControlsImplNotLive_video"
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useGraphQLVideoDRMInfo_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useGraphQLVideoDRMInfo_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "drm_info",
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useOzImplementationData_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useOzImplementationData_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "can_use_oz",
            storageKey: null
        }, {
            alias: "playable_url_dash",
            args: [{
                kind: "Literal",
                name: "scrubbing_preference",
                value: "MPEG_DASH"
            }],
            kind: "ScalarField",
            name: "playable_url",
            storageKey: 'playable_url(scrubbing_preference:"MPEG_DASH")'
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "dash_manifest",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "min_quality_preference",
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useProgressiveImplementationData_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useProgressiveImplementationData_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_rss_podcast_video",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_spherical",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "min_quality_preference",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "playable_url",
            storageKey: null
        }, {
            alias: "playable_url_quality_hd",
            args: [{
                kind: "Literal",
                name: "quality",
                value: "HD"
            }],
            kind: "ScalarField",
            name: "playable_url",
            storageKey: 'playable_url(quality:"HD")'
        }, {
            alias: null,
            args: null,
            concreteType: "SphericalVideoFallbackUrls",
            kind: "LinkedField",
            name: "spherical_video_fallback_urls",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "hd",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "sd",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useShakaImplementationData_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useShakaImplementationData_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_rss_podcast_video",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "VideoPlayerShakaLiveP2PInit",
            kind: "LinkedField",
            name: "video_player_shaka_live_p2p_init",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "json_encoded_video_data",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("InstreamVideoAdBreaksPlayer_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "InstreamVideoAdBreaksPlayer_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "InstreamExtraConfig",
            kind: "LinkedField",
            name: "instream_extra_config",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "instream_halo_delay_time_seconds",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "InstreamVideoAdBreaks",
            kind: "LinkedField",
            name: "instream_video_ad_breaks_comet",
            plural: !1,
            selections: [{
                args: null,
                documentName: "InstreamVideoAdBreaksPlayer_video_instream_video_ad_breaks_comet",
                fragmentName: "InstreamVideoAdBreaksPlayerImpl_adBreaks",
                fragmentPropName: "adBreaks",
                kind: "ModuleImport"
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerShakaPerformanceLoggerBuilder_init.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerShakaPerformanceLoggerBuilder_init",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "__typename",
            storageKey: null
        }],
        type: "VideoPlayerShakaPerformanceLoggerInit",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerShakaPerformanceLoggerBuilder_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerShakaPerformanceLoggerBuilder_video",
        selections: [{
            alias: "video_player_shaka_performance_logger_init2",
            args: null,
            concreteType: "VideoPlayerShakaPerformanceLoggerInit",
            kind: "LinkedField",
            name: "video_player_shaka_performance_logger_init",
            plural: !1,
            selections: [{
                args: null,
                documentName: "useVideoPlayerShakaPerformanceLoggerBuilder_video",
                fragmentName: "useVideoPlayerShakaPerformanceLoggerBuilder_init",
                fragmentPropName: "init",
                kind: "ModuleImport"
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "per_session_sampling_rate",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerShakaPerformanceLoggerRelayImpl_init.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerShakaPerformanceLoggerRelayImpl_init",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "__typename",
            storageKey: null
        }],
        type: "VideoPlayerShakaPerformanceLoggerInit",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerShakaPerformanceLoggerRelayImpl_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerShakaPerformanceLoggerRelayImpl_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "VideoPlayerShakaPerformanceLoggerInit",
            kind: "LinkedField",
            name: "video_player_shaka_performance_logger_init",
            plural: !1,
            selections: [{
                args: null,
                documentName: "useVideoPlayerShakaPerformanceLoggerRelayImpl_video",
                fragmentName: "useVideoPlayerShakaPerformanceLoggerRelayImpl_init",
                fragmentPropName: "init",
                kind: "ModuleImport"
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "video_player_shaka_performance_logger_should_sample",
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useGraphQLVideoP2PSettings_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useGraphQLVideoP2PSettings_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "VideoP2PSettings",
            kind: "LinkedField",
            name: "p2p_settings",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "ticket",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "VideoP2PSettingsConfig",
                kind: "LinkedField",
                name: "config",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "delay_p2p_until_play",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "disable_hivejava_for_livevc",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "VideoHiveCommunityInfo",
                kind: "LinkedField",
                name: "community_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "community_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "community_name",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "VideoHiveInitializationOptions",
                kind: "LinkedField",
                name: "hive_initialization_options",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "VideoHiveInitializationOptionHiveJava",
                    kind: "LinkedField",
                    name: "hive_java",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "min_version",
                        storageKey: null
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "hive_tech_order",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "debug_level",
                    storageKey: null
                }],
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoImplementationsImpl_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoImplementationsImpl_video",
        selections: [{
            args: null,
            kind: "FragmentSpread",
            name: "useOzImplementationData_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useShakaImplementationData_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "useProgressiveImplementationData_video"
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerCaptionsSettings_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerCaptionsSettings_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "CaptionsSettings",
            kind: "LinkedField",
            name: "captions_settings",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "always_show_captions",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "captions_background_color",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "captions_background_opacity",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "captions_text_color",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "captions_text_size",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerLiveLatencyKnobSettings_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerLiveLatencyKnobSettings_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "VideoBroadcastLowLatencyConfig",
            kind: "LinkedField",
            name: "broadcast_low_latency_config",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "ll_desired_latency_ms",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "ll_latency_tolerance_ms",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useVideoPlayerShakaConfig_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoPlayerShakaConfig_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_spherical",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_gaming_video",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_latency_menu_enabled",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_live_streaming",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "fbls_tier",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_latency_sensitive_broadcast",
            storageKey: null
        }, {
            kind: "ClientExtension",
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "selected_latency_setting",
                storageKey: null
            }]
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("BaseContainerQueryElement.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            root: {
                boxSizing: "x9f619",
                flexShrink: "x2lah0s",
                position: "x1n2onr6"
            }
        };

    function a(a, b) {
        var d = a.breakpoint,
            e = a.inverseToContainer;
        e = e === void 0 ? !1 : e;
        var f = a.maxWidth,
            g = a.minWidth,
            j = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["breakpoint", "inverseToContainer", "maxWidth", "minWidth", "xstyle"]);
        d = d - .1;
        return h.jsx("div", babelHelpers["extends"]({}, a, {
            className: c("stylex")(i.root, j),
            ref: b,
            style: {
                maxWidth: f,
                minWidth: g,
                width: e ? "calc((" + d + "px - 100%) * 9999)" : "calc((100% - " + d + "px) * 9999)"
            }
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("Dots3HorizontalFilled24.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            fill: "currentColor",
            viewBox: "0 0 24 24",
            width: "1em",
            height: "1em"
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("circle", {
                cx: 12,
                cy: 12,
                r: 2.5
            }), h.jsx("circle", {
                cx: 19.5,
                cy: 12,
                r: 2.5
            }), h.jsx("circle", {
                cx: 4.5,
                cy: 12,
                r: 2.5
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("CometOverlappingFacepile.react", ["fbt", "BaseContainerQueryElement.react", "CometComponentWithKeyCommands.react", "CometIcon.react", "CometKeys", "CometPressable.react", "CometProfilePhoto.react", "CometTooltip.react", "CometVisualCompletionAttributes", "Dots3HorizontalFilled24.svg.react", "FocusGroup.react", "ReactDOMComet", "SVGIcon", "TetraText.react", "focusScopeQueries", "react", "stylex", "useCometUniqueID", "useIntersectionObserver"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useCallback,
        k = b.useRef,
        l = b.useState;
    e = d("FocusGroup.react").createFocusGroup(d("focusScopeQueries").tabbableScopeQuery);
    var m = e[0],
        n = e[1],
        o = -4,
        p = {
            item: {
                marginBottom: "xieb3on",
                position: "x1n2onr6"
            },
            items: {
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                flexShrink: "x2lah0s",
                flexWrap: "x1a02dak",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x1n2onr6"
            },
            itemWithoutMargin: {
                position: "x1n2onr6"
            },
            itemWithSpacing: {
                marginStart: "x139jcc6"
            },
            overflow16: {
                height: "xlup9mm",
                width: "x1kky2od"
            },
            overflow16Child: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginStart: "xbmpl8g"
            },
            overflow16Frame: {
                marginStart: "x1mnrxsn",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                width: "x1fsd2vl"
            },
            overflow24: {
                height: "xxk0z11",
                width: "xvy4d1p"
            },
            overflow32: {
                height: "x10w6t97",
                width: "x1td3qas"
            },
            overflow36: {
                height: "xc9qbxq",
                width: "x14qfxbe"
            },
            overflow40: {
                height: "x1vqgdyp",
                width: "x100vrsf"
            },
            overflow48: {
                height: "xsdox4t",
                width: "x1useyqa"
            },
            overflowItem: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                display: "x78zum5",
                flexShrink: "x2lah0s",
                justifyContent: "xl56j7k",
                pointerEvents: "x71s49j"
            },
            overflowItemBg: {
                fill: "x1wnuiir"
            },
            overflowItemContainer: {
                bottom: "x1ey2m1c",
                boxSizing: "x9f619",
                display: "x78zum5",
                end: "xds687c",
                flexDirection: "x1q0g3np",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy"
            },
            overflowItemOverlay: {
                fill: "x1wnuiir",
                opacity: "xg01cxk",
                transitionDuration: "x1ebt8du",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1dhq9h"
            },
            overflowItemOverlayHovered: {
                fill: "x4bmajx",
                opacity: "x1hc1fzr",
                transitionDuration: "x1mq3mr6"
            },
            overflowItemOverlayPressed: {
                fill: "x1tgjyoi",
                opacity: "x1hc1fzr",
                transitionDuration: "x1mq3mr6"
            },
            overflowItemSVG: {
                bottom: "x1ey2m1c",
                end: "xds687c",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy"
            },
            root: {
                display: "x78zum5",
                flexDirection: "xdt5ytf"
            },
            rootInline: {
                alignItems: "x6s0dn4",
                flexDirection: "x1q0g3np"
            },
            text: {
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                paddingTop: "xz9dl7a"
            },
            textInline: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                paddingStart: "x1e558r4",
                paddingTop: "xexx8yu"
            },
            wrapper: {
                paddingEnd: "xn6708d",
                paddingStart: "x1swvt13",
                paddingTop: "xyamay9"
            }
        },
        q = {
            16: {
                minWidth: "x1fns5xo"
            },
            24: {
                minWidth: "x4m7ku4"
            },
            32: {
                minWidth: "xwrg52n"
            },
            36: {
                minWidth: "xktpd3l"
            },
            40: {
                minWidth: "x1c7vg25"
            },
            48: {
                minWidth: "x1wc95rx"
            }
        },
        r = {
            center: {
                alignItems: "x6s0dn4"
            },
            end: {
                alignItems: "xuk3077"
            },
            start: {
                alignItems: "x1cy8zhl"
            }
        },
        s = {
            center: {
                justifyContent: "xl56j7k"
            },
            end: {
                justifyContent: "x13a6bvl"
            },
            start: {
                justifyContent: "x1nhvcw1"
            }
        };

    function a(a) {
        var b = a.align;
        b = b === void 0 ? "start" : b;
        var e = a.items,
            f = a.isOverlapping;
        f === void 0 ? !0 : f;
        f = a.isTextInline;
        f = f === void 0 ? !1 : f;
        var g = a.count,
            j = g === void 0 ? e.length : g;
        g = a.ellipsisTooltip;
        var l = a.linkProps,
            x = a.onPress,
            y = a.screenReaderLabel,
            z = a.size,
            A = a.testid;
        A = a.testOnly_pressed;
        var B = A === void 0 ? !1 : A;
        A = a.text;
        var C = a.disableMarginOnItems,
            D = C === void 0 ? !1 : C;
        C = a.withWrapper;
        var E = o,
            F = Math.min(j, e.length, f ? 3 : Infinity),
            G = k(null);
        a = [{
            command: {
                key: c("CometKeys").LEFT
            },
            description: h._("Previous item"),
            handler: function() {}
        }, {
            command: {
                key: c("CometKeys").RIGHT
            },
            description: h._("Next item"),
            handler: function() {}
        }];
        e = i.jsxs("div", babelHelpers["extends"]({
            className: c("stylex")(p.items),
            ref: G,
            role: "row",
            style: {
                height: z
            }
        }, c("CometVisualCompletionAttributes").IGNORE_DYNAMIC, {
            children: [e.slice(0, F).map(function(a, b) {
                var d = a.containerComponent,
                    e = a.linkProps,
                    f = a.onPress,
                    g = a.testOnly_pressed;
                a = babelHelpers.objectWithoutPropertiesLoose(a, ["containerComponent", "linkProps", "onPress", "testOnly_pressed"]);
                return i.jsxs(i.Fragment, {
                    children: [i.jsx(c("BaseContainerQueryElement.react"), {
                        breakpoint: (b + 1) * (z + E) - E,
                        inverseToContainer: !0,
                        maxWidth: "100%",
                        minWidth: 0
                    }), i.jsx(t, babelHelpers["extends"]({}, a, {
                        Container: d,
                        FocusItemComponent: y != null ? void 0 : n,
                        divClassName: c("stylex")(D ? p.itemWithoutMargin : p.item, b > 0 && p.itemWithSpacing),
                        isOverlapped: b > 0,
                        linkProps: e,
                        onPress: f,
                        parentRef: G,
                        role: "cell",
                        shape: "circle",
                        size: z,
                        testOnly_pressed: g,
                        testid: void 0
                    }))]
                }, b)
            }), i.jsxs("div", {
                className: c("stylex")(p.overflowItemContainer),
                children: [e.slice(0, Math.min(e.length, F < j ? F : j)).map(function(a, b) {
                    return b === 0 && j > 1 ? null : i.jsx(c("BaseContainerQueryElement.react"), {
                        breakpoint: (b + 1) * (z + E) - E,
                        maxWidth: b === j - 1 ? "100%" : z + E,
                        minWidth: 0
                    }, "overflowPusher" + b)
                }), i.jsx(v, {
                    FocusItemComponent: y != null ? void 0 : n,
                    "aria-label": h._("Link to see everyone"),
                    count: j,
                    ellipsisTooltip: g,
                    linkProps: l,
                    onPress: x,
                    overlayDisabled: !0,
                    parentRef: G,
                    size: z,
                    spacing: E,
                    testid: void 0,
                    xstyle: [p.overflowItem, z === 16 && p.overflow16, z === 24 && p.overflow24, z === 32 && p.overflow32, z === 36 && p.overflow36, z === 40 && p.overflow40, z === 48 && p.overflow48],
                    children: function(a) {
                        var b = a.hovered;
                        a = a.pressed;
                        return i.jsxs(i.Fragment, {
                            children: [i.jsx(w, {
                                hovered: b,
                                isOverlapped: F > 1,
                                pressed: a || B,
                                size: z
                            }), z === 16 ? i.jsx("div", {
                                className: c("stylex")(p.overflow16Frame),
                                children: i.jsx("div", {
                                    className: c("stylex")(p.overflow16Child),
                                    children: i.jsx(c("CometIcon.react"), {
                                        color: "white",
                                        icon: d("SVGIcon").svgIcon(c("Dots3HorizontalFilled24.svg.react")),
                                        size: u(z)
                                    })
                                })
                            }) : i.jsx(c("CometIcon.react"), {
                                color: "white",
                                icon: d("SVGIcon").svgIcon(c("Dots3HorizontalFilled24.svg.react")),
                                size: u(z)
                            })]
                        })
                    }
                })]
            })]
        }));
        g = f ? s : r;
        l = q[z];
        x = i.jsxs("div", {
            "aria-label": y,
            className: c("stylex")(p.root, f && p.rootInline, g[b]),
            "data-testid": void 0,
            role: y == null ? "grid" : "img",
            children: [y != null ? i.jsx("div", {
                "aria-hidden": !0,
                className: c("stylex")(f && F >= 3 && l),
                children: e
            }) : i.jsx(c("CometComponentWithKeyCommands.react"), {
                commandConfigs: a,
                xstyle: f && F >= 3 && l,
                children: i.jsx(m, {
                    orientation: "horizontal",
                    tabScopeQuery: d("focusScopeQueries").tabbableScopeQuery,
                    wrap: !0,
                    children: e
                })
            }), A != null && i.jsx("div", {
                "aria-hidden": y != null ? !0 : void 0,
                className: c("stylex")(p.text, f && p.textInline, g[b]),
                children: i.jsx(c("TetraText.react"), {
                    color: "secondary",
                    type: "body3",
                    children: A
                })
            })]
        });
        return C ? i.jsx("div", {
            className: c("stylex")(p.wrapper),
            children: x
        }) : x
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function t(a) {
        var b = a.Container,
            e = a.FocusItemComponent,
            f = a.divClassName,
            g = a.parentRef,
            h = babelHelpers.objectWithoutPropertiesLoose(a, ["Container", "FocusItemComponent", "divClassName", "parentRef"]);
        a = l(!1);
        var k = a[0],
            m = a[1];
        a = j(function(a) {
            var b = a.intersectionRatio;
            d("ReactDOMComet").flushSync(function() {
                m(b < .5)
            })
        }, []);
        a = c("useIntersectionObserver")(a, {
            root: function() {
                var a;
                return (a = g.current) != null ? a : null
            },
            threshold: .5
        });
        b = b ? i.jsx(b, {
            children: function(a) {
                return i.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, h, {
                    overlayDisabled: !0,
                    ref: a
                }))
            }
        }) : i.jsx(c("CometProfilePhoto.react"), babelHelpers["extends"]({}, h, {
            overlayDisabled: !0
        }));
        return i.jsx("div", {
            className: f,
            ref: a,
            role: "cell",
            children: e != null ? i.jsx(e, {
                disabled: k,
                children: b
            }) : b
        })
    }
    t.displayName = t.name + " [from " + f.id + "]";

    function u(a) {
        switch (a) {
            case 36:
            case 32:
                return 16;
            case 40:
            case 48:
                return 24;
            default:
                return 12
        }
    }

    function v(a) {
        var b = a.FocusItemComponent;
        a.count;
        var e = a.ellipsisTooltip,
            f = a.parentRef,
            g = a.size,
            h = a.spacing;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["FocusItemComponent", "count", "ellipsisTooltip", "parentRef", "size", "spacing"]);
        var k = l(!1),
            m = k[0],
            n = k[1];
        k = l(null);
        var o = k[0],
            p = k[1];
        k = j(function(a) {
            var b = a.intersectionRatio;
            d("ReactDOMComet").flushSync(function() {
                n(b < .5)
            })
        }, []);
        k = c("useIntersectionObserver")(k, {
            root: function() {
                var a;
                return (a = f.current) != null ? a : null
            },
            threshold: .5
        });
        var q = function(a) {
            if (!a) return;
            a = f.current;
            if (!a) return;
            a = a.getBoundingClientRect();
            a = a.width;
            a = Math.floor((a + h) / (g + h));
            p(a - 1)
        };
        a = i.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, a, {
            ref: k,
            role: "cell"
        }));
        e && (a = i.jsx(c("CometTooltip.react"), {
            align: "middle",
            onVisibilityChange: q,
            position: "below",
            tooltip: o != null ? e(o) : "",
            children: a
        }));
        return b != null ? i.jsxs(b, {
            disabled: m,
            children: [" ", a, " "]
        }) : a
    }
    v.displayName = v.name + " [from " + f.id + "]";

    function w(a) {
        var b = a.hovered,
            d = a.isOverlapped,
            e = a.pressed;
        a = a.size;
        var f = c("useCometUniqueID")();
        return i.jsxs("svg", {
            className: c("stylex")(p.overflowItemSVG),
            height: a,
            viewBox: "0 0 " + a + " " + a,
            width: a,
            children: [d && i.jsxs("mask", {
                id: f,
                suppressHydrationWarning: !0,
                children: [i.jsx("circle", {
                    cx: a / 2,
                    cy: a / 2,
                    fill: "white",
                    r: a / 2
                }), i.jsx("circle", {
                    cx: -a / 2 + 4,
                    cy: a / 2,
                    fill: "black",
                    r: a / 2 + 2
                })]
            }), i.jsx("circle", babelHelpers["extends"]({
                className: c("stylex")(p.overflowItemBg),
                cx: a / 2,
                cy: a / 2,
                r: a / 2,
                role: "cell",
                suppressHydrationWarning: !0
            }, d ? {
                mask: "url(#" + f + ")"
            } : null)), i.jsx("circle", babelHelpers["extends"]({
                className: c("stylex")(p.overflowItemOverlay, b && p.overflowItemOverlayHovered, e && p.overflowItemOverlayPressed),
                cx: a / 2,
                cy: a / 2,
                r: a / 2,
                role: "cell",
                suppressHydrationWarning: !0
            }, d ? {
                mask: "url(#" + f + ")"
            } : null))]
        })
    }
    w.displayName = w.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("TetraOverlappingFacepileUnstyled.react", ["CometOverlappingFacepile.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("CometOverlappingFacepile.react"), babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("usePremiumMusicVideoInterruptionSubscription", ["CometRelay", "react", "usePremiumMusicVideoInterruptionSubscription.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useEffect,
        j = h !== void 0 ? h : h = b("usePremiumMusicVideoInterruptionSubscription.graphql");

    function a(a) {
        var b = d("CometRelay").useRelayEnvironment();
        i(function() {
            if (a == null) return;
            var c = d("CometRelay").requestSubscription(b, {
                subscription: j,
                variables: {
                    input: {
                        user_id: a
                    }
                }
            });
            return function() {
                c.dispose()
            }
        }, [a, b])
    }
    g["default"] = a
}), 98);
__d("useSEOLoggedOutWebCrawler", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("gkx")("1779508")
    }
    g["default"] = a
}), 98);
__d("CometFullScreen", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var c = a.requestFullscreen || a.mozRequestFullScreen || a.msRequestFullscreen || a.webkitRequestFullscreen;
        return typeof c === "function" ? c.call(a) : b("Promise").reject()
    }

    function c() {
        var a = document.exitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen || document.webkitExitFullscreen;
        return typeof a === "function" ? a.call(document) : b("Promise").reject()
    }

    function d() {
        return (document.webkitFullscreenEnabled === !0 || document.mozFullScreenEnabled === !0 || document.msFullscreenEnabled === !0 || document.fullscreenEnabled === !0) && (typeof document.webkitExitFullscreen === "function" || typeof document.mozCancelFullScreen === "function" || typeof document.msExitFullscreen === "function" || typeof document.exitFullscreen === "function")
    }

    function g() {
        return document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement || document.mozFullScreenElement || null
    }

    function e() {
        return g() != null
    }

    function h() {
        return ["webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange", "fullscreenchange"]
    }

    function i(a) {
        var b = window.document,
            c = !1,
            d = !0;
        h().forEach(function(e) {
            b.addEventListener(e, a, {
                capture: c,
                passive: d
            })
        });
        return function() {
            h().forEach(function(d) {
                b.removeEventListener(d, a, c)
            })
        }
    }
    f.requestFullScreen = a;
    f.exitFullScreen = c;
    f.isSupported = d;
    f.getFullScreenElement = g;
    f.isFullScreen = e;
    f.getFullScreenChangeEventNames = h;
    f.subscribeToFullScreenChangeEvent = i
}), 66);
__d("OzOneSemanticHandlerUtils", ["ConstUriUtils", "qex", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, c) {
        b != null && (b.indexOf("+RE") >= 0 && a.retry()), c != null && c()
    }

    function a(a, b) {
        var d = b.error;
        d = d.getExtra();
        var e = d.code;
        d = d.headers;
        var f = null;
        e == null && c("recoverableViolation")("A ONE Semantic error response must have an error code.", "comet_video_player");
        d == null && c("recoverableViolation")("A ONE Semantic error response must contain response Headers.", "comet_video_player");
        if (d != null) {
            d = d.get("x-fb-one-variant");
            f = (d = d) != null ? d : null
        }
        d = JSON.parse(a.getString("network_retry_intervals_json", "{}"));
        a = d[e];
        switch (e) {
            case "410":
                b.endStream();
                break;
            case "404":
                h(b, f, function() {
                    var a = c("qex")._("1634") || !1;
                    a && b.retry({
                        behavior: "recover_failed_request"
                    })
                });
                break;
            case "429":
                b.retry(a);
                break;
            case "403":
            default:
        }
    }

    function i(a) {
        if (a != null) {
            a = parseInt(a, 10);
            var b = c("qex")._("1635");
            if (b != null && b > 0) return !isNaN(a) && a > 0 && a <= b
        }
        return !1
    }

    function j(a, b) {
        if (a != null && b != null) {
            a = parseInt(a, 10);
            b = parseInt(b, 10);
            return !isNaN(a) && !isNaN(b) && a > 0 && a <= b
        }
        return !1
    }

    function k(a) {
        if (a != null) {
            a = d("ConstUriUtils").getUri(a);
            if (a) {
                a = a.getQueryParam("os_param");
                return a ? String(a).toString() : null
            }
        }
        return null
    }

    function l(a, b) {
        var d = a != null;
        return i(b) || (d || !!c("qex")._("1636")) && j(b, a)
    }

    function b(a) {
        var b = a.getExtra();
        b = b.headers;
        b = m(b);
        a = a.getExtra();
        var d = a.code;
        a = a.url;
        if (b != null && d == null) {
            c("recoverableViolation")("A ONE Semantic error response must have an error code.", "comet_video_player");
            return !1
        }
        d = k(a);
        return l(d, b)
    }

    function m(a) {
        if (a) {
            a = a.get("x-fb-one");
            if (a != null) return parseInt(a, 10) > 0 ? a : null
        }
        return null
    }

    function e(a, b, c) {
        var d = null,
            e = null;
        b != null && (d = k(b), d != null && a.setOneReqWave(parseInt(d, 10)));
        b = c == null ? void 0 : c.headers;
        b && (e = m(b), e != null && a.setOneResWave(parseInt(e, 10)));
        a.setOneObserved(l(d, e))
    }
    g.maybeRetryForVariant = h;
    g.evaluateOneSemanticsResponse = a;
    g.isOneSemanticsForcedForResponseWave = i;
    g.isOneSemanticsEnabledForWave = j;
    g.getOneSemanticRequestWave = k;
    g.shouldRespondWithOneSemantics = b;
    g.getOneSemanticResponseWave = m;
    g.setOneSemanticFetchStreamLoggingAttributes = e
}), 98);
__d("OzOneSemanticHandler", ["OzOneSemanticHandlerUtils", "handleOzManifestFetchErrorEvent", "handleOzStreamErrorEvent", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var e = b.error;
        !!c("qex")._("1633") && d("OzOneSemanticHandlerUtils").shouldRespondWithOneSemantics(e) ? d("OzOneSemanticHandlerUtils").evaluateOneSemanticsResponse(a, b) : c("handleOzManifestFetchErrorEvent")(a, b)
    }

    function b(a, b) {
        var e = b.error;
        !!c("qex")._("1633") && d("OzOneSemanticHandlerUtils").shouldRespondWithOneSemantics(e) ? d("OzOneSemanticHandlerUtils").evaluateOneSemanticsResponse(a, b) : c("handleOzStreamErrorEvent")(a, b)
    }
    g.handleManifestFetchErrorEvent = a;
    g.handleStreamErrorEvent = b
}), 98);
__d("useEventCallbackOn", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect;

    function a(a, b, c) {
        h(function() {
            a.addEventListener(b, c);
            return function() {
                a.removeEventListener(b, c)
            }
        }, [a, b, c])
    }
    g["default"] = a
}), 98);
__d("useIsBackgrounded", ["emptyFunction", "react", "useEventCallbackOn"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f = d("react");
    var h = f.useCallback,
        i = f.useState;

    function b() {
        var b = a.document;
        if (typeof b.hidden !== "undefined") return "visibilitychange";
        else if (typeof b.mozHidden !== "undefined") return "mozvisibilitychange";
        else if (typeof b.msHidden !== "undefined") return "msvisibilitychange";
        else if (typeof b.webkitHidden !== "undefined") return "webkitvisibilitychange";
        return "visibilitychange"
    }

    function j() {
        var b = a.document;
        if (typeof b.hidden !== "undefined") return b.hidden;
        else if (typeof b.mozHidden !== "undefined") return b.mozHidden;
        else if (typeof b.msHidden !== "undefined") return b.msHidden;
        else if (typeof b.webkitHidden !== "undefined") return b.webkitHidden;
        return !1
    }
    var k = b();

    function l(b) {
        var c = a.document.hasFocus ? a.document.hasFocus() : !0,
            d = j();
        return d || (b ? !1 : !c)
    }

    function e(b) {
        var d = (b == null ? void 0 : b.noPauseOnBlurOrFocus) === !0,
            e = i(function() {
                return l(d)
            }),
            f = e[0],
            g = e[1],
            j = !!b && b.scrollTerminatesBackgrounded === !0;
        e = h(function() {
            g(l(d))
        }, [g, d]);
        b = e;
        var m = h(function() {
            var a = l(d);
            a && j && f && g(!1)
        }, [f, d, j]);
        d && (b = c("emptyFunction"));
        c("useEventCallbackOn")(a.window, "blur", b);
        c("useEventCallbackOn")(a.window, "focus", b);
        c("useEventCallbackOn")(a.document, k, e);
        c("useEventCallbackOn")(a.window, "scroll", m);
        return f
    }
    g["default"] = e
}), 98);
__d("OzCDNSignedQueryParams", ["ConstUriUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {}
        }
        var b = a.prototype;
        b.$2 = function(a, b, c) {
            this.$1[a] == null && (this.$1[a] = {}), this.$1[a][b] = c
        };
        b.get = function(a) {
            a = this.$1[a];
            return a == null ? null : a
        };
        b.update = function(a) {
            a = d("ConstUriUtils").getUri(a);
            if (a != null) {
                var b = a.getQueryParams();
                a = a.getDomain() + a.getPath();
                var c = b.get("oe");
                c != null && this.$2(a, "oe", String(b.get("oe")));
                b.get("oh") != null && this.$2(a, "oh", String(b.get("oh")))
            }
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoPlayerViewabilityProvider.react", ["VideoPlayerViewabilityContexts", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children,
            c = a.isDesktopPictureInPicture,
            e = a.isFullscreen;
        a = a.videoPlayerPassiveViewabilityInfo;
        return h.jsx(d("VideoPlayerViewabilityContexts").VideoPlayerPassiveViewabilityInfoContext.Provider, {
            value: a,
            children: h.jsx(d("VideoPlayerViewabilityContexts").VideoPlayerDesktopPictureInPictureContext.Provider, {
                value: c,
                children: h.jsx(d("VideoPlayerViewabilityContexts").VideoPlayerFullscreenContext.Provider, {
                    value: e,
                    children: b
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("wrapWithContextProviders", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        return b.reduceRight(function(a, b) {
            return b(a)
        }, a)
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a, b) {
        return function(c) {
            return h.jsx(a.Provider, {
                value: b,
                children: c
            })
        }
    }
    g.wrapWithContextProviders = a;
    g.makeRenderProviderFn = b
}), 98);
__d("VideoPlayerComponentContainer.react", ["CometVisualCompletionAttributes", "VideoPlayerContexts", "VideoPlayerHooks", "VideoPlayerViewabilityProvider.react", "clearTimeout", "cr:1269159", "react", "setTimeout", "wrapWithContextProviders"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useEffect,
        k = e.useRef,
        l = e.useState;

    function m(a) {
        var b = k(a);
        j(function() {
            b.current = a
        }, [a]);
        var d = l(!1),
            e = d[0],
            f = d[1];
        d = l(function() {
            var a = null;
            return {
                cleanup: function() {
                    a && a()
                },
                pingNotIdle: function() {
                    a && a();
                    f(!1);
                    var d = c("setTimeout")(function() {
                        f(!0)
                    }, b.current);
                    a = function() {
                        c("clearTimeout")(d), a = null
                    }
                }
            }
        });
        d = d[0];
        var g = d.cleanup;
        d = d.pingNotIdle;
        j(function() {
            return g
        }, [g]);
        return {
            isIdle: e,
            pingNotIdle: d
        }
    }

    function n() {
        var a = l(!1),
            b = a[0],
            c = a[1];
        a = 3e3;
        a = m(a);
        var d = a.isIdle,
            e = a.pingNotIdle;
        a = i(function() {
            c(!0), e()
        }, [e]);
        var f = i(function() {
                c(!1), e()
            }, [e]),
            g = i(function() {
                c(!0), e()
            }, [e]),
            h = i(function() {
                e()
            }, [e]),
            j = i(function() {
                e()
            }, [e]);
        return {
            isHovering: b,
            isIdle: d,
            onMouseDown: h,
            onMouseEnter: a,
            onMouseLeave: f,
            onMouseMove: g,
            onMouseUp: j
        }
    }

    function o(a) {
        var b = n(),
            e = b.isHovering,
            f = b.isIdle,
            g = b.onMouseDown,
            i = b.onMouseEnter,
            j = b.onMouseLeave,
            k = b.onMouseMove;
        b = b.onMouseUp;
        var l = d("VideoPlayerHooks").useIsFullscreen();
        return h.jsx("div", babelHelpers["extends"]({
            className: "xh8yej3 x13vifvy x10l6tqk x5yr21d" + (l && f ? " xjfk50j" : "")
        }, c("CometVisualCompletionAttributes").IGNORE, {
            onMouseDown: g,
            onMouseEnter: i,
            onMouseLeave: j,
            onMouseMove: k,
            onMouseUp: b,
            children: h.jsx(d("VideoPlayerContexts").VideoPlayerMouseHoverContext.Provider, {
                value: e,
                children: h.jsx(d("VideoPlayerContexts").VideoPlayerMouseIdleContext.Provider, {
                    value: f,
                    children: a.children
                })
            })
        }))
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function a(a) {
        var e = a.children;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children"]);
        var f = a.adClientToken,
            g = a.audioAvailabilityInfo,
            i = a.autoplayGatingResult,
            j = a.broadcastStatus,
            k = a.canAutoplay,
            m = a.controller,
            n = a.dimensions,
            p = a.initialTracePolicy,
            q = a.instanceKey,
            r = a.isDesktopPictureInPicture,
            s = a.isFullscreen,
            t = a.isNCSR,
            u = a.isPremiumMusicVideo,
            v = a.lastMuteReason,
            w = a.lastPauseReason,
            x = a.lastPlayReason,
            y = a.originalHeight,
            z = a.originalWidth,
            A = a.videoFBID,
            B = a.videoPlayerPassiveViewabilityInfo,
            C = a.videoState,
            D = a.volumeSetting,
            E = C.activeCaptions,
            F = C.activeEmsgBoxes,
            G = C.availableVideoQualities,
            H = C.bufferEnd,
            I = C.captionDisplayStyle,
            J = C.captionsLoaded,
            K = C.captionsVisible,
            L = C.currentVideoQuality,
            M = C.duration,
            N = C.ended,
            O = C.error,
            P = C.inbandCaptionsAutogenerated,
            Q = C.inPlayStalling,
            R = C.isAbrEnabled,
            S = C.isExternalMedia,
            T = C.isLiveRewindActive,
            U = C.lastPlayedTimeMs,
            V = C.latencyLevel,
            W = C.loopCount,
            X = C.loopCurrent,
            Y = C.muted,
            Z = C.paused,
            aa = C.playerImplementationName,
            ba = C.playing,
            ca = C.seekableRanges,
            da = C.seeking,
            ea = C.selectedVideoQuality,
            fa = C.stalling,
            ga = C.streamInterrupted,
            ha = C.targetAudioQuality,
            ia = C.targetPlaybackRate,
            ja = C.targetVideoQuality,
            $ = C.volume;
        C = C.watchTimeMs;
        e = h.jsx(o, {
            children: e
        });
        $ = l($);
        var ka = $[0];
        $ = $[1];
        b("cr:1269159")(q, {
            controller: m,
            coreVideoStates: a,
            videoPlayerPassiveViewabilityInfo: B
        });
        a = d("wrapWithContextProviders").wrapWithContextProviders(e, [d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").VideoFBIDContext, A), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").StallingContext, fa), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").PlayingContext, ba), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").InPlayStallingContext, Q), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").BufferEndContext, H), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LastMuteReasonContext, v), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LastPlayReasonContext, x), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LastPauseReasonContext, w), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").PausedContext, Z), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").CurrentVideoQualityContext, L), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").MutedContext, Y), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").VolumeContext, {
            setVolume: $,
            volume: ka
        }), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").SelectedVideoQualityContext, ea), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").SeekingContext, da), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").DurationContext, M), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").EndedContext, N), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").ErrorContext, O), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").DimensionsContext, n || null), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").InstanceKeyContext, q), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").ControllerContext, m), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").AvailableVideoQualitiesContext, G), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").PlayerImplementationNameContext, aa), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").IsAbrEnabledContext, R), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").TargetAudioQualityContext, ha), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").TargetVideoQualityContext, ja), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").PlaybackRateContext, ia), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").CanAutoplayContext, k), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").VolumeSettingContext, D), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").AutoplayGatingResultContext, i), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").BroadcastStatusContext, j), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LoopCountContext, W), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LoopCurrentContext, X), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").AdClientTokenContext, f), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").ActiveCaptionsContext, E), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").CaptionsVisibleContext, K), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").CaptionDisplayStyleContext, I), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").CaptionsLoadedContext, J), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").InbandCaptionsAutogeneratedContext, P), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").StreamInterruptedContext, ga), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").WatchTimeContext, C), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LastPlayedTimeContext, U), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").SeekableRangesContext, ca), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").LatencyLevelContext, V), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").IsLiveRewindActiveContext, T), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").AudioAvailabilityInfoContext, g), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").IsNCSRContext, t), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").IsPremiumMusicVideoContext, u), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").InitialTracePolicyContext, p), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").ActiveEmsgBoxesContext, F), d("wrapWithContextProviders").makeRenderProviderFn(d("VideoPlayerContexts").IsExternalMediaContext, S), function(a) {
            return h.jsx(d("VideoPlayerContexts").VideoOriginalDimensionsContextMemoProvider, {
                originalHeight: y,
                originalWidth: z,
                children: a
            })
        }, function(a) {
            return h.jsx(c("VideoPlayerViewabilityProvider.react"), {
                isDesktopPictureInPicture: r,
                isFullscreen: s,
                videoPlayerPassiveViewabilityInfo: B,
                children: a
            })
        }]);
        return h.jsx("div", {
            "data-instancekey": q,
            "data-testid": void 0,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.memo(a);
    g["default"] = e
}), 98);
__d("GlobalVideoPortsID", ["cometUniqueID", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return "id-pv-" + c("cometUniqueID")()
    }

    function b(a) {
        if (typeof a === "string") {
            var b = "id-pv-";
            if (a.indexOf(b) === 0 && a.length > b.length) return a;
            else throw c("unrecoverableViolation")('Expected a GlobalVideoPortsVideoID, got a string that does not look like it: "' + a + '"', "comet_video_player")
        } else return null
    }

    function d() {
        return "id-pp-" + c("cometUniqueID")()
    }
    g.makeVideoID = a;
    g.ensureVideoID = b;
    g.makePlaceID = d
}), 98);
__d("VideoPlayerFullscreenController", ["CometFullScreen", "removeFromArray", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return a.current != null && d("CometFullScreen").getFullScreenElement() === a.current
    }

    function a(a) {
        var b = [];

        function e() {
            b.forEach(function(a) {
                a()
            })
        }
        var f = null;
        return {
            getIsFullscreen: function() {
                return h(a)
            },
            requestSetIsFullscreen: function(b, e) {
                var f = a.current;
                if (f == null) throw c("unrecoverableViolation")("Requested full screen while the element is not present", "comet_video_player");
                d("CometFullScreen").isSupported() ? b !== h(a) && (b === !0 ? d("CometFullScreen").requestFullScreen(f) : b === !1 && d("CometFullScreen").exitFullScreen()) : b && e != null && typeof e.webkitEnterFullScreen === "function" ? e.webkitEnterFullScreen() : !b && e != null && typeof e.webkitExitFullScreen === "function" && e.webkitExitFullscreen()
            },
            subscribe: function(a) {
                b.length === 0 && f == null && (f = d("CometFullScreen").subscribeToFullScreenChangeEvent(e));
                b.push(a);
                return {
                    remove: function() {
                        c("removeFromArray")(b, a), b.length === 0 && f != null && (f(), f = null)
                    }
                }
            }
        }
    }
    g.createFullscreenController = a
}), 98);
__d("VideoPlayerPortalingPlaceState", ["GlobalVideoPortsContexts", "GlobalVideoPortsID", "gkx", "react", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useState;
    e = function(a, b) {
        var e = c("usePrevious")(a);
        h(function() {
            a !== e && (e !== null && e && !a && b(d("GlobalVideoPortsID").makeVideoID()))
        }, [a, e, b])
    };
    f = function(a, b) {
        var c = i(null),
            e = c[0];
        c = c[1];
        a !== e && (e !== null && e && !a && b(d("GlobalVideoPortsID").makeVideoID()), c(a))
    };
    var j = c("gkx")("1375802") ? f : e;

    function a(a) {
        var b = a.portalingEnabled;
        a = a.portalingFromVideoID;
        var c = d("GlobalVideoPortsContexts").useGlobalVideoPortsLoader(),
            e = d("GlobalVideoPortsContexts").useGlobalVideoPortsManager(),
            f = d("GlobalVideoPortsContexts").useGlobalVideoPortsState(),
            g = e != null && f != null,
            k = (g || c != null) && (b || a != null),
            l = i(function() {
                return d("GlobalVideoPortsID").makePlaceID()
            });
        l = l[0];
        var m = i(function() {
                return d("GlobalVideoPortsID").makeVideoID()
            }),
            n = m[0];
        m = m[1];
        b = k && b && a != null;
        a = b && a != null ? a : n;
        j(b, m);
        h(function() {
            k && !g && c && c()
        }, [g, k, c]);
        return {
            canBecomePortableLater: k,
            currentVideoID: a,
            globalVideoPortsManager: e,
            globalVideoPortsState: f,
            thisPlaceID: l
        }
    }
    g.useRegenerateUniqueVideoID_exportedForTest = j;
    g.useVideoPlayerPortalingPlaceState = a
}), 98);
__d("VideoPlayerPortalingPlaceWithPortaling.react", ["BaseContextualLayerAnchorRootContext", "CoreVideoPlayerFitParentContainer.react", "GlobalVideoPortsRenderers.react", "getOwnObjectValues", "killswitch", "qex", "react", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext;
    e = b.useEffect;
    var j = b.useRef,
        k = b.useState,
        l = c("qex")._("109") || c("qex")._("110") ? e : c("useLayoutEffect_SAFE_FOR_SSR"),
        m = c("qex")._("109") || c("qex")._("111") ? e : c("useLayoutEffect_SAFE_FOR_SSR");

    function a(a) {
        var b = a.coreVideoPlayerMetaData,
            e = a.currentPlaceID,
            f = a.currentVideoID,
            g = a.fullscreenController,
            n = a.globalVideoPortsManager,
            o = a.globalVideoPortsState_DEPRECATED,
            p = a.implementations,
            q = a.isFullscreen,
            r = a.portablePlaceMetaData,
            s = a.previousPlaceMetaData,
            t = a.renderComponents,
            u = a.renderPlaceholder,
            v = a.thisPlaceID,
            w = a.trackingDataEncrypted,
            x = a.trackingNodes,
            y = a.viewportMarginsForViewability;
        a = k(function() {
            return d("CoreVideoPlayerFitParentContainer.react").createFitParentContainerDiv({
                debugRole: null
            })
        });
        var z = a[0],
            A = j(null);
        l(function() {
            n.addOrUpdatePlace({
                coreVideoPlayerMetaData: b,
                fullscreenController: g,
                implementations: p,
                injectCoreVideoStatesRef: A,
                isFullscreen: q,
                portablePlaceContainer: z,
                portablePlaceID: v,
                portablePlaceMetaData: r,
                portableVideoID: f,
                renderComponents: t,
                renderPlaceholder: u,
                trackingDataEncrypted: w,
                trackingNodes: x,
                viewportMarginsForViewability: y
            })
        }, [].concat(c("getOwnObjectValues")(b), [f, g, q, n, z], c("getOwnObjectValues")(r || {}), [t, u, v, w, x, y]));
        m(function() {
            return function() {
                n.removePlace({
                    portablePlaceID: v
                })
            }
        }, [n, v]);
        a = i(c("BaseContextualLayerAnchorRootContext"));
        var B = j(null);
        return h.jsxs(c("BaseContextualLayerAnchorRootContext").Provider, {
            value: q && !c("killswitch")("WORKPLACE_VIDEO_FULLSCREEN_CONTEXT_LAYER_ROOT") ? B : a,
            children: [h.jsx(d("CoreVideoPlayerFitParentContainer.react").CoreVideoPlayerFitParentDOMContainer, {
                debugRole: null,
                domElement: z
            }, v), h.jsx(d("GlobalVideoPortsRenderers.react").GlobalVideoPortsVideoComponentsRenderer, {
                currentPlaceID: o != null ? (a = (a = n.getCurrentPlaceStateForVideo(o, f)) == null ? void 0 : a.portablePlaceID) != null ? a : null : e,
                currentVideoID: f,
                injectCoreVideoStatesRef: A,
                previousPlaceMetaData: o != null ? (e = (a = n.getPortableVideoState(o, f)) == null ? void 0 : a.previousPlaceMetaData) != null ? e : null : s,
                renderComponents: t,
                thisPlaceID: v
            }), h.jsx("div", {
                ref: B
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerPortalingPlace.react", ["BaseViewportMarginsContext", "CometTrackingCodeContext", "CometTrackingNodesContext", "CoreVideoPlayer.react", "CoreVideoPlayerFitParentContainer.react", "GlobalVideoPortsID", "GlobalVideoPortsRenderers.react", "VideoPlayerFullscreenController", "VideoPlayerPortalingPlaceInfoProvider.react", "VideoPlayerPortalingPlaceState", "VideoPlayerPortalingPlaceWithPortaling.react", "gkx", "react", "recoverableViolation", "useStable", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useState,
        l = {
            bottom: 0,
            left: 0,
            right: 0,
            top: 0
        },
        m = h.forwardRef(function(a, b) {
            var c = a.children;
            a = a.debugRole;
            return h.jsx(d("CoreVideoPlayerFitParentContainer.react").CoreVideoPlayerFitParentContainer, {
                debugRole: a,
                ref: b,
                children: c
            })
        });

    function a(a) {
        var b = a.implementations,
            e = a.portalingEnabled,
            f = a.portalingFromVideoID,
            g = a.portalingPlaceMetaData,
            n = a.renderComponents,
            o = a.renderPlaceholder;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["implementations", "portalingEnabled", "portalingFromVideoID", "portalingPlaceMetaData", "renderComponents", "renderPlaceholder"]);
        j(function() {
            return function() {}
        }, []);
        var p = f != null ? d("GlobalVideoPortsID").ensureVideoID(f) : null;
        f != null && p == null && c("recoverableViolation")("The provided portalingFromVideoID (" + String(f) + ") does not look like such an ID. The video player will not use portaling until a valid ID is provided", "comet_video_player");
        f = d("VideoPlayerPortalingPlaceState").useVideoPlayerPortalingPlaceState({
            portalingEnabled: e,
            portalingFromVideoID: p
        });
        e = f.canBecomePortableLater;
        p = f.currentVideoID;
        var q = f.globalVideoPortsManager,
            r = f.globalVideoPortsState;
        f = f.thisPlaceID;
        var s = i(c("BaseViewportMarginsContext")),
            t = c("useUnsafeRef_DEPRECATED")(null),
            u = c("useStable")(function() {
                return d("VideoPlayerFullscreenController").createFullscreenController(t)
            }),
            v = k(u.getIsFullscreen()),
            w = v[0],
            x = v[1];
        j(function() {
            var a = u.subscribe(function() {
                var a = u.getIsFullscreen();
                x(a)
            });
            x(u.getIsFullscreen());
            return function() {
                a.remove()
            }
        }, [u, x]);
        v = i(c("CometTrackingNodesContext"));
        v = v.join("");
        var y = i(c("CometTrackingCodeContext"));
        y = (y = y.encrypted_tracking[0]) != null ? y : "";
        s = w ? l : s;
        if (!e) return h.jsx(m, {
            debugRole: null,
            ref: t,
            children: h.jsx(d("VideoPlayerPortalingPlaceInfoProvider.react").VideoPlayerPortalingPlaceInfoProvider, {
                currentPlaceID: f,
                currentVideoID: p,
                portalingEnabled: !1,
                previousPlaceMetaData: null,
                thisPlaceID: f,
                children: h.jsx(c("CoreVideoPlayer.react"), babelHelpers["extends"]({}, a, {
                    fullscreenController: u,
                    implementations: b,
                    isFullscreen: w,
                    renderWithCoreVideoStates: n,
                    trackingDataEncrypted: y,
                    trackingNodes: v,
                    viewportMarginsForViewability: s
                }))
            })
        });
        if (q && r) {
            return h.jsx(m, {
                debugRole: null,
                ref: t,
                children: h.jsx(c("VideoPlayerPortalingPlaceWithPortaling.react"), {
                    coreVideoPlayerMetaData: a,
                    currentPlaceID: c("gkx")("4184") ? (e = (e = q.getCurrentPlaceStateForVideo(r, p)) == null ? void 0 : e.portablePlaceID) != null ? e : null : null,
                    currentVideoID: p,
                    fullscreenController: u,
                    globalVideoPortsManager: q,
                    globalVideoPortsState_DEPRECATED: c("gkx")("4184") ? null : r,
                    implementations: b,
                    isFullscreen: w,
                    portablePlaceMetaData: g,
                    previousPlaceMetaData: c("gkx")("4184") ? (b = (e = q.getPortableVideoState(r, p)) == null ? void 0 : e.previousPlaceMetaData) != null ? b : null : null,
                    renderComponents: n,
                    renderPlaceholder: o,
                    thisPlaceID: f,
                    trackingDataEncrypted: y,
                    trackingNodes: v,
                    viewportMarginsForViewability: s
                })
            })
        } else return h.jsx(m, {
            debugRole: null,
            ref: t,
            children: h.jsx(d("GlobalVideoPortsRenderers.react").GlobalVideoPortsPlaceholderRenderer, {
                currentPlaceID: null,
                currentVideoID: p,
                originalHeight: a.originalHeight,
                originalWidth: a.originalWidth,
                previousPlaceMetaData: null,
                renderPlaceholder: o,
                thisPlaceID: f
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerTracePolicyContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = d("react").useContext;
    c = {
        initialTracePolicy: null,
        routeTracePolicy: null
    };
    var i = b.createContext(c);

    function a() {
        return h(i)
    }
    g.VideoPlayerTracePolicyContext = i;
    g.useVideoPlayerTracePolicy = a
}), 98);
__d("VideoPlayerTracePolicyProvider.react", ["VideoPlayerTracePolicyContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useState;

    function a(a) {
        var b = a.children,
            c = a.initialTracePolicy,
            e = a.routeTracePolicy;
        a = j(c);
        var f = a[0],
            g = a[1];
        a = j(e);
        var k = a[0],
            l = a[1];
        i(function() {
            f !== c && g(c), k !== e && l(e)
        }, [c, e, f, k]);
        return h.jsx(d("VideoPlayerTracePolicyContext").VideoPlayerTracePolicyContext.Provider, {
            value: {
                initialTracePolicy: f,
                routeTracePolicy: k
            },
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CoreVideoPlayerWithComponents.react", ["VideoPlayerComponentContainer.react", "VideoPlayerPortalingPlace.react", "VideoPlayerTracePolicyProvider.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useCallback;

    function a(a) {
        var b = a.children,
            d = a.implementations,
            e = a.portalingEnabled,
            f = a.portalingFromVideoID,
            g = a.portalingPlaceMetaData,
            j = a.portalingRenderPlaceholder;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "implementations", "portalingEnabled", "portalingFromVideoID", "portalingPlaceMetaData", "portalingRenderPlaceholder"]);
        var k = i(function(a) {
            return h.jsx(c("VideoPlayerComponentContainer.react"), babelHelpers["extends"]({}, a, {
                children: b
            }))
        }, [b]);
        return h.jsx(c("VideoPlayerTracePolicyProvider.react"), {
            initialTracePolicy: a.initialTracePolicy,
            routeTracePolicy: a.routeTracePolicy,
            children: h.jsx(c("VideoPlayerPortalingPlace.react"), babelHelpers["extends"]({}, a, {
                implementations: d,
                portalingEnabled: e,
                portalingFromVideoID: f,
                portalingPlaceMetaData: g,
                renderComponents: k,
                renderPlaceholder: j
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerErrorBoundary.react", ["FBLogger", "getErrorSafe", "oz-player/utils/OzError", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.state = {
                error: null
            }, c.suppressReactDefaultErrorLogging = !0, b) || babelHelpers.assertThisInitialized(c)
        }
        b.getDerivedStateFromError = function(a) {
            return {
                error: c("getErrorSafe")(a)
            }
        };
        var d = b.prototype;
        d.componentDidCatch = function(a, b) {
            b = b.componentStack;
            var d = c("getErrorSafe")(a);
            d.componentStack = b;
            b = this.props;
            var e = b.description,
                f = b.onError;
            b = b.project;
            a = a instanceof c("oz-player/utils/OzError") ? a.getType() : a != null && typeof a.name === "string" ? a.name : d.name;
            d.name = a;
            a = "VideoPlayerErrorBoundary caught an " + a;
            e != null && (a = a + " (" + e + ")");
            e = ["OZ_NETWORK", "BUFFERING_TIMEOUT", "MEDIA_ERR_DECODE", "OZ_NETWORK_REQUEST_STREAM_RETRY_HANDLER_ERROR"];
            var g = ["Network failure:", "Network failure.", "HTTP error.", "Bad URL timestamp", "URL signature expired", "No license for com.widevine.alpha"];
            e = e.every(function(a) {
                return d.name !== a
            }) && g.every(function(a) {
                return !d.message.startsWith(a)
            });
            g = c("FBLogger")(b == null ? "comet_video_player" : b).catching(d);
            e ? g.fatal(a) : g.warn(a);
            f != null && f(d)
        };
        d.render = function() {
            var a = this.props,
                b = a.children;
            a = a.fallback;
            var c = this.state.error;
            return c ? typeof a === "function" ? a(c) : a : b
        };
        return b
    }(a.PureComponent);
    g["default"] = b
}), 98);
__d("InstreamVideoAdBreaksPlayer.react", ["CometPlaceholder.react", "CometRelay", "InstreamVideoAdBreaksPlayer_video.graphql", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");

    function a(a) {
        var e = a.playerFormat,
            f = a.subOrigin;
        a = a.video;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("InstreamVideoAdBreaksPlayer_video.graphql"), a);
        var g = a.id,
            j = a.instream_extra_config;
        a = a.instream_video_ad_breaks_comet;
        return i.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            children: i.jsx(d("CometRelay").MatchContainer, {
                match: a,
                props: {
                    instreamExtraConfig: {
                        instreamHaloDelayTimeSeconds: j == null ? void 0 : j.instream_halo_delay_time_seconds
                    },
                    instreamVideoAdBreaksComet: a,
                    playerFormat: e,
                    subOrigin: f,
                    videoFBID: g
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerFallbackCover.react", ["fbt", "cr:1405514", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var c;
        c = (c = a.message) != null ? c : h._("Sorry, we're having trouble playing this video.");
        return i.jsx(b("cr:1405514"), {
            debugError: a.debugError,
            message: c,
            onRetry: a.onRetry
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerRetryableErrorBoundary.react", ["VideoPlayerErrorBoundary.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useState;

    function a(a) {
        var b = a.children,
            d = a.description,
            e = a.fallback;
        a = j(0);
        var f = a[0],
            g = a[1],
            k = i(function() {
                g(function(a) {
                    return a + 1
                })
            }, []);
        a = i(function(a) {
            return f >= 3 ? e({
                error: a,
                retry: null
            }) : e({
                error: a,
                retry: k
            })
        }, [e, k, f]);
        return h.jsx(c("VideoPlayerErrorBoundary.react"), {
            description: d,
            fallback: a,
            project: "comet_video_player",
            children: b
        }, f)
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAudioManagerHooks", ["CometAudioManagerContexts", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(d("CometAudioManagerContexts").AudioApiContext);
        return a
    }
    g.useAudioApi = a
}), 98);
__d("makeAudioSymbol", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return b + "::" + a
    }
    f["default"] = a
}), 66);
__d("CoreVideoPlayerAudioClient.react", ["CometAudioManagerContexts", "CometAudioManagerHooks", "CometThrottle", "VideoPlayerHooks", "VideoPlayerPortalingPlaceInfoProvider.react", "makeAudioSymbol", "react", "useCometUniqueID", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useContext,
        i = b.useEffect,
        j = b.useMemo,
        k = b.useRef,
        l = b.useState;

    function a() {
        var a = c("useCometUniqueID")(),
            b = d("VideoPlayerHooks").useInstanceKey(),
            e = j(function() {
                return c("makeAudioSymbol")(a, b)
            }, [a, b]),
            f = d("CometAudioManagerHooks").useAudioApi(),
            g = k(f);
        i(function() {
            g.current = f
        }, [f]);
        var m = d("VideoPlayerHooks").useController(),
            n = 200,
            o = d("VideoPlayerHooks").useLastPlayReason(),
            p = d("VideoPlayerHooks").useLastMuteReason(),
            q = d("VideoPlayerHooks").useMuted();
        n = c("CometThrottle")(d("VideoPlayerHooks").useVolume, n, {
            trailing: !0
        });
        var r = n(),
            s = c("usePrevious")(r),
            t = d("VideoPlayerHooks").usePaused(),
            u = h(d("CometAudioManagerContexts").CometAudioLocalScopeContext),
            v = h(d("CometAudioManagerContexts").CometAudioGroupContext),
            w = d("VideoPlayerPortalingPlaceInfoProvider.react").useVideoPlayerPortalingPlaceInfo(),
            x = d("VideoPlayerHooks").useVolumeSetting(),
            y = j(function() {
                return (v == null ? void 0 : v.groupID) || d("CometAudioManagerContexts").makeAudioGroupID()
            }, [v == null ? void 0 : v.groupID]);
        n = l(!0);
        var z = n[0];
        n = n[1];
        var A = j(function() {
            return {
                audioLocalScope: u,
                controller: m,
                groupID: y,
                instanceKey: b,
                lastMuteReason: p,
                lastPlayReason: o,
                muted: q,
                paused: t,
                previousVolume: s,
                symbol: e,
                videoPlayerPortalingPlaceInfo: w,
                volume: r
            }
        }, [u, m, y, b, p, o, q, t, s, e, w, r]);
        i(function() {
            x != null && m.setVolume(x)
        }, [m, x]);
        n = v || {
            allowSound: z,
            groupID: y,
            setAllowSound: n
        };
        var B = k(n);
        i(function() {
            f && f.register(A, B.current);
            return function() {
                f && f.unregister(e, y)
            }
        }, [f, A, y, e]);
        i(function() {
            f && f.update(A)
        }, [f, A]);
        i(function() {
            !z && g.current && m.setMuted(!0, "audio_manager_initiated")
        }, [z, g, m]);
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerAutoplayHooks", ["VideoPlayerAutoplayContexts", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(d("VideoPlayerAutoplayContexts").AutoplayApiContext);
        if (a == null) throw c("unrecoverableViolation")("Empty AutoplayApiContext. Are you rendering useAutoplayApi outside of VideoAutoplayManagerX?", "comet_video_player");
        return a
    }

    function b() {
        return h(d("VideoPlayerAutoplayContexts").VideoAutoplayLocalScopeContext)
    }
    g.useAutoplayApi = a;
    g.useVideoAutoplayLocalScope = b
}), 98);
__d("VideoPlayerDebugAutoplayAPI", ["cr:1453865", "emptyFunction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d = (a = b("cr:1453865")) != null ? a : {
        useVideoPlayerDebugAPI: c("emptyFunction").thatReturns(null),
        useVideoPlayerDebugAPIDefinition: c("emptyFunction"),
        useVideoPlayerDebugInfo: c("emptyFunction").thatReturns(null)
    };
    g["default"] = d
}), 98);
__d("evaluateVideoAutoplayDefaultAllowRule", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return "ALLOW"
    }
    a.displayName = "evaluateVideoAutoplayDefaultRule";
    f["default"] = a
}), 66);
__d("makeSelectedAutoplayVideoSymbol", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return b + "::" + a
    }
    f["default"] = a
}), 66);
__d("AutoplayRulesEngine", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = -2,
        h = -1;
    a = function() {
        function a(a) {
            this.$1 = g, this.$2 = a
        }
        var b = a.prototype;
        b.evaluateAutoplay = function(a, b) {
            b = b();
            var c = h;
            if (a)
                for (var d = 0; d < this.$2.length; d++) {
                    var e = this.$2[d](a);
                    if (e !== "SKIP") {
                        b = e;
                        c = d;
                        break
                    }
                }
            this.$1 = c;
            return b
        };
        b.getIndexOfLastWinningRule = function() {
            return this.$1
        };
        b.getRules = function() {
            return this.$2
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("useAutoplayRulesEngine", ["AutoplayRulesEngine", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = b.useState;

    function a(a) {
        var b = i(a),
            d = j(function() {
                return new(c("AutoplayRulesEngine"))(a)
            }),
            e = d[0],
            f = d[1];
        h(function() {
            b.current !== a && f(function() {
                return new(c("AutoplayRulesEngine"))(a)
            })
        }, [a]);
        h(function() {
            b.current = e.getRules()
        }, [e]);
        return e
    }
    g["default"] = a
}), 98);
__d("useConcurrentAutoplayManagementAPI", ["react", "removeFromArray", "useCometUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useState;

    function a() {
        return c("useCometUniqueID")()
    }

    function i() {
        var a = [];
        return {
            isControllingComponent: function(b) {
                var c = a.length;
                return a[c - 1] === b
            },
            registerControllingComponent: function(b) {
                c("removeFromArray")(a, b), a.push(b)
            },
            unregisterControllingComponent: function(b) {
                var d = a.length;
                d > 1 && c("removeFromArray")(a, b);
                return d > 1
            }
        }
    }

    function b() {
        var a = h(function() {
            return i()
        });
        a = a[0];
        return a
    }
    g.useAutoplayControlID = a;
    g.createConcurrentAutoplayManagementAPI = i;
    g.useConcurrentAutoplayManagementAPI = b
}), 98);
__d("useVideoPlayerBandwidthEstimate", ["VideoPlayerOzWWWGlobalConfig", "oz-player/networks/OzBandwidthEstimator", "react", "useInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useState,
        i = 5e3;

    function a() {
        var a = function() {
                return c("oz-player/networks/OzBandwidthEstimator").getBandwidth(c("VideoPlayerOzWWWGlobalConfig"))
            },
            b = h(a()),
            d = b[0],
            e = b[1];
        c("useInterval")(function() {
            return e(a())
        }, i);
        return d
    }
    g["default"] = a
}), 98);
__d("useVideoAutoplayState", ["HiddenSubtreePassiveContext", "VideoPlayerHooks", "VideoPlayerShakaGlobalConfig", "VideoPlayerViewabilityHooks", "gkx", "react", "useIsBackgrounded", "useVideoPlayerBandwidthEstimate"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.startTransition,
        i = b.useContext,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState;

    function a(a) {
        var b = d("VideoPlayerHooks").useAdClientToken(),
            e = d("VideoPlayerHooks").useAutoplayGatingResult(),
            f = d("VideoPlayerHooks").useBroadcastStatus(),
            g = d("VideoPlayerHooks").useEnded(),
            n = d("VideoPlayerHooks").useIsExternalMedia(),
            o = d("VideoPlayerHooks").useIsFrozenPassive(),
            p = d("VideoPlayerHooks").useLastPauseReason(),
            q = d("VideoPlayerHooks").useLastPlayReason(),
            r = d("VideoPlayerHooks").useMuted(),
            s = d("VideoPlayerHooks").usePaused(),
            t = i(c("HiddenSubtreePassiveContext")),
            u = !b;
        a = (a == null ? void 0 : a.noPauseOnBlurOrFocus) === !0 || d("VideoPlayerShakaGlobalConfig").getBool("comet_www_no_pause_on_blur_or_focus_events", !1);
        var v = c("useIsBackgrounded")({
                noPauseOnBlurOrFocus: a,
                scrollTerminatesBackgrounded: u
            }),
            w = c("useVideoPlayerBandwidthEstimate")(),
            x = d("VideoPlayerViewabilityHooks").useVideoPlayerPassiveViewabilityInfo(),
            y = d("VideoPlayerViewabilityHooks").useVideoPlayerExtendedPassiveViewabilityInfo();
        a = m(t.getCurrentState().backgrounded);
        var z = a[0],
            A = a[1];
        u = m(t.getCurrentState().hidden);
        var B = u[0],
            C = u[1];
        j(function() {
            function a(a, b) {
                C(a), A(b)
            }
            var b = t.subscribeToChanges(function(b) {
                    c("gkx")("1500552") ? h(function() {
                        var b = t.getCurrentState();
                        a(b.hidden, b.backgrounded)
                    }) : a(b.hidden, b.backgrounded)
                }),
                d = t.getCurrentState().hidden,
                e = t.getCurrentState().backgrounded;
            c("gkx")("1500552") ? h(function() {
                var b = t.getCurrentState();
                a(b.hidden, b.backgrounded)
            }) : a(d, e);
            return function() {
                b.remove()
            }
        }, [t, A, C]);
        a = m(function() {
            return o.getCurrentState()
        });
        var D = a[0],
            E = a[1];
        j(function() {
            var a = o.subscribeToChanges(function(a) {
                    E(a)
                }),
                b = o.getCurrentState();
            E(b);
            return function() {
                a.remove()
            }
        }, [o, E]);
        var F = k(function() {
            return {
                adClientToken: b,
                autoplayGatingResult: e,
                bandwidthEstimate: w,
                broadcastStatus: f,
                controllerIsFrozen: D,
                currentSubtreeIsBackgrounded: z,
                currentSubtreeIsHidden: B,
                ended: g,
                hiddenSubtreePassive: t,
                isBackgrounded: v,
                isExternalMedia: n,
                isFrozenPassive: o,
                lastPauseReason: p,
                lastPlayReason: q,
                muted: r,
                paused: s,
                videoPlayerExtendedPassiveViewabilityInfo: y,
                videoPlayerPassiveViewabilityInfo: x
            }
        }, [b, e, w, f, D, z, B, g, t, v, n, o, p, q, r, s, y, x]);
        u = m(F);
        var G = u[0],
            H = u[1],
            I = l(G);
        j(function() {
            I.current = G
        }, [G]);
        j(function() {
            var a = !1;
            for (var b in F)
                if (Object.prototype.hasOwnProperty.call(F, b) && F[b] !== I.current[b]) {
                    a = !0;
                    break
                }
            a && H(F)
        }, [F, H]);
        return G
    }
    g["default"] = a
}), 98);
__d("CoreVideoPlayerAutoplayClient.react", ["CoreVideoPlayerAutoplayClientUtils", "HiddenSubtreePassiveContext", "VideoPlayerAutoplayHooks", "VideoPlayerDebugAutoplayAPI", "VideoPlayerHooks", "VideoPlayerViewabilityConstants", "WwwCometVideoAutoplayFalcoEvent", "evaluateVideoAutoplayDefaultAllowRule", "evaluateVideoAutoplayDefaultIgnoreRule", "makeSelectedAutoplayVideoSymbol", "react", "useAutoplayRulesEngine", "useCometUniqueID", "useConcurrentAutoplayManagementAPI", "useVideoAutoplayState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useCallback,
        i = b.useContext,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState;

    function a() {
        var a = c("useCometUniqueID")(),
            b = d("VideoPlayerHooks").useCanAutoplay(),
            e = d("VideoPlayerHooks").useInstanceKey(),
            f = k(function() {
                return c("makeSelectedAutoplayVideoSymbol")(a, e)
            }, [a, e]),
            g = l(f);
        j(function() {
            g.current = f
        }, [f]);
        var n = i(c("HiddenSubtreePassiveContext")),
            o = d("VideoPlayerHooks").useController(),
            p = l(!1),
            q = d("useConcurrentAutoplayManagementAPI").useAutoplayControlID();
        j(function() {
            d("CoreVideoPlayerAutoplayClientUtils").log(g.current, "[ASSUME CONTROL] " + q), o.registerControllingComponent(q)
        }, [o, q]);
        var r = d("VideoPlayerHooks").useVideoPlayerPassiveViewabilityInfo(),
            s = o.getCurrentState();
        s = s.paused;
        var t = l(s),
            u = d("VideoPlayerAutoplayHooks").useVideoAutoplayLocalScope(),
            v = l(u);
        j(function() {
            v.current = u
        }, [u]);
        var w = h(function() {
                var a = o.getCurrentState(),
                    b = a.lastPlayReason;
                a = a.paused;
                var d = t.current;
                t.current = a;
                var e = r == null ? void 0 : r.getCurrent();
                if (e) {
                    e = e.visiblePercentage;
                    a = !a && a !== d;
                    d = e < c("VideoPlayerViewabilityConstants").DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE && e > 0;
                    v.current.disableScrollBeforePlayWhenOffscreen !== !0 && a && b === "user_initiated" && d && (p.current = !0)
                }
            }, [o, r]),
            x = l(w);
        j(function() {
            x.current = w
        }, [w]);
        j(function() {
            var a = o.subscribe(function() {
                w()
            });
            return function() {
                a.remove()
            }
        }, [o, w]);
        var y = c("useVideoAutoplayState")({
                noPauseOnBlurOrFocus: u.noPauseOnBlurOrFocus
            }),
            z = c("useAutoplayRulesEngine")(u.autoplayLocalRules),
            A = b === "allow" ? c("evaluateVideoAutoplayDefaultAllowRule") : c("evaluateVideoAutoplayDefaultIgnoreRule");
        s = m(function() {
            return A
        });
        var B = s[0],
            C = s[1];
        s = m(null);
        var D = s[0],
            E = s[1];
        s = m(function() {
            return z.evaluateAutoplay(y, A)
        });
        var F = s[0],
            G = s[1];
        s = m(null);
        var H = s[0],
            I = s[1],
            J = l(F),
            K = d("VideoPlayerAutoplayHooks").useAutoplayApi(),
            L = l(K);
        j(function() {
            L.current = K
        }, [K]);
        var M = b !== "dangerously_disable_autoplay_management";
        j(function() {
            K.register(f, e, u, o, n, M);
            c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                return {
                    autoplay_event_name: "register",
                    autoplay_scope_id: v.current.autoplayScopeID,
                    event_creation_time: Date.now(),
                    initiator: g.current,
                    initiator_type: "autoplay_component",
                    selected_autoplay_video_symbol: K.getAutoplayManagerDebugInfo(v.current).selectedAutoplayVideoSymbol,
                    target: g.current,
                    target_current_autoplay_decision: J.current
                }
            });
            return function() {
                K.unregister(f), c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                    return {
                        autoplay_event_name: "unregister",
                        autoplay_scope_id: v.current.autoplayScopeID,
                        event_creation_time: Date.now(),
                        initiator: g.current,
                        initiator_type: "autoplay_component",
                        selected_autoplay_video_symbol: K.getAutoplayManagerDebugInfo(v.current).selectedAutoplayVideoSymbol,
                        target: g.current,
                        target_current_autoplay_decision: J.current
                    }
                })
            }
        }, [K, u, o, n, e, M, f]);
        j(function() {
            var a = function() {
                    var b = z.evaluateAutoplay(y, A);
                    J.current = b;
                    var e = z.getRules(),
                        h = z.getIndexOfLastWinningRule(),
                        a = h >= 0 ? e[h] : A;
                    e = r && r.getCurrent();
                    h = o.getCurrentState();
                    h = h.paused;
                    (H === null || H !== b) && (G(b), I(b));
                    if (b === "PAUSE" && !h && o.isControllingComponent(q)) {
                        h = !0;
                        x.current();
                        if (p.current) {
                            p.current = !1;
                            var i = e == null ? void 0 : e.positionToViewport;
                            i && o.scrollIntoView(i.top < 0);
                            h = !1
                        }
                        if (h) {
                            i = "[PAUSE] via short-circuit on " + a.name + ".";
                            d("CoreVideoPlayerAutoplayClientUtils").log(g.current, i);
                            o.pause("autoplay_initiated");
                            c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                                return {
                                    autoplay_event_name: "pause",
                                    autoplay_scope_id: v.current.autoplayScopeID,
                                    event_creation_time: Date.now(),
                                    initiator: g.current,
                                    initiator_type: "autoplay_component",
                                    selected_autoplay_video_symbol: K.getAutoplayManagerDebugInfo(v.current).selectedAutoplayVideoSymbol,
                                    target: g.current,
                                    target_current_autoplay_decision: b
                                }
                            })
                        }
                    }(D === null || D !== a) && (C(function() {
                        return a
                    }), E(function() {
                        return a
                    }), c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                        return {
                            autoplay_event_name: "rule_changed",
                            autoplay_scope_id: v.current.autoplayScopeID,
                            event_creation_time: Date.now(),
                            initiator: g.current,
                            initiator_type: "autoplay_component",
                            selected_autoplay_video_symbol: K.getAutoplayManagerDebugInfo(v.current).selectedAutoplayVideoSymbol,
                            target: g.current,
                            target_current_autoplay_decision: b
                        }
                    }));
                    d("CoreVideoPlayerAutoplayClientUtils").log(g.current, "[DECISION: " + b + "] from " + a.name);
                    e && K.update(f, b, e)
                },
                b = n.subscribeToChanges(function(a) {
                    n.getCurrentState().hidden || n.getCurrentState().backgrounded ? o.isControllingComponent(q) || o.unregisterControllingComponent(q) : o.registerControllingComponent(q)
                }),
                e = r ? r.subscribe(function() {
                    n.getCurrentState().hidden || n.getCurrentState().backgrounded ? o.isControllingComponent(q) || o.unregisterControllingComponent(q) : o.registerControllingComponent(q), a()
                }) : null;
            a();
            return function() {
                b.remove(), e && e.remove()
            }
        }, [K, q, z, o, A, n, D, H, C, G, E, I, f, y, r]);
        j(function() {
            var a = o.isControllingComponent(q),
                b = o.getCurrentState();
            b = b.paused;
            d("CoreVideoPlayerAutoplayClientUtils").componentShouldPause(F, J.current, b, a) && (d("CoreVideoPlayerAutoplayClientUtils").log(g.current, "[PAUSE] the video for " + F), o.pause("autoplay_initiated"), c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                return {
                    autoplay_event_name: "pause",
                    autoplay_scope_id: v.current.autoplayScopeID,
                    event_creation_time: Date.now(),
                    initiator: g.current,
                    initiator_type: "autoplay_component",
                    selected_autoplay_video_symbol: L.current.getAutoplayManagerDebugInfo(v.current).selectedAutoplayVideoSymbol,
                    target: g.current,
                    target_current_autoplay_decision: F
                }
            }))
        }, [F, o, q]);
        j(function() {
            return function() {
                d("CoreVideoPlayerAutoplayClientUtils").log(g.current, "[RELEASE CONTROL] " + q), o.unregisterControllingComponent(q)
            }
        }, [o, q]);
        c("VideoPlayerDebugAutoplayAPI").useVideoPlayerDebugAPIDefinition({
            applicableRule: B,
            autoplayApiRef: L,
            autoplayDecision: F,
            autoplayLocalScope: u,
            symbol: f
        });
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerCaptionsAreaDeferred.react", ["deferredLoadComponent", "react", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    a = c("deferredLoadComponent")(c("requireDeferredForDisplay")("VideoPlayerCaptionsArea.react").__setRef("VideoPlayerCaptionsAreaDeferred.react"));
    g["default"] = a
}), 98);
__d("VideoPlayerWebSessionExtender.react", ["VideoPlayerHooks", "WebSessionExtender", "react", "useCometUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect;

    function a() {
        var a = d("VideoPlayerHooks").usePlaying(),
            b = c("useCometUniqueID")();
        h(function() {
            if (a) {
                d("WebSessionExtender").subscribe(b, "video");
                return function() {
                    d("WebSessionExtender").unsubscribe(b)
                }
            }
        }, [a, b]);
        return null
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerDefaultLoadingIndicatorsLogic", ["VideoPlayerHooks"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = d("VideoPlayerHooks").useStalling(),
            b = d("VideoPlayerHooks").useStreamInterrupted(),
            c = d("VideoPlayerHooks").useIsLiveRewindActive();
        b = b && !c;
        c = a;
        a = b ? "live_video_interrupted_overlay" : c ? "spinner" : "none";
        return {
            liveVideoInterruptedOverlayVisible: b,
            loadingIndicatorType: a,
            spinnerVisible: c
        }
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerDefaultLoadingIndicators", ["CometPlaceholder.react", "deferredLoadComponent", "gkx", "once", "react", "requireDeferred", "requireDeferredForDisplay", "useVideoPlayerDefaultLoadingIndicatorsLogic"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = c("deferredLoadComponent")(c("requireDeferredForDisplay")("VideoPlayerSpinner.react").__setRef("useVideoPlayerDefaultLoadingIndicators")),
        j = c("deferredLoadComponent")(c("requireDeferred")("VideoPlayerWithLiveVideoInterruptedOverlay.react").__setRef("useVideoPlayerDefaultLoadingIndicators")),
        k = c("once")(function() {
            return c("gkx")("5900") ? null : h.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                children: h.jsx(j, {})
            })
        });

    function a() {
        var a = c("useVideoPlayerDefaultLoadingIndicatorsLogic")(),
            b = a.loadingIndicatorType;
        a = a.spinnerVisible;
        a = h.jsx(i, {
            isVisible: a
        });
        var d = null;
        switch (b) {
            case "spinner":
                d = a;
                break;
            case "live_video_interrupted_overlay":
                d = k();
                break;
            case "none":
            default:
                d = a
        }
        return {
            loadingIndicatorElement: d,
            loadingIndicatorType: b
        }
    }
    g["default"] = a
}), 98);
__d("XVideoUnifiedCVCControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/video/unified_cvc/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("UnifiedVideoCVCSubscription", ["CVCv3DisabledPlayerOrigins", "CVCv3DisabledPlayerSubOrigins", "CVCv3SubscriptionHelper", "DateConsts", "XVideoUnifiedCVCControllerRouteBuilder", "clearTimeout", "cometAsyncFetch", "gkx", "promiseDone", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = Object.values(c("CVCv3DisabledPlayerOrigins")),
        i = Object.values(c("CVCv3DisabledPlayerSubOrigins")),
        j = 10;
    a = function() {
        function a(a, b, d, e, f, g) {
            var j = this;
            this.$1 = new(c("CVCv3SubscriptionHelper"))(a, b, d);
            this.$5 = f;
            this.$6 = null;
            this.$9 = null;
            this.$10 = !this.$1.isValidSubscription();
            this.$3 = null;
            this.$2 = null;
            a = b != null ? h.includes(b) : !1;
            f = d != null ? i.includes(d) : !1;
            !a && !f && (this.$3 = e, this.$11 = g, this.$4 = e.subscribe(function() {
                if (j.$3 == null) {
                    j.$1.logDebugInfo("empty_video_controller");
                    return
                }
                var a = j.$3.getCurrentState();
                a.playing ? j.$12(a) : j.$13()
            }))
        }
        var b = a.prototype;
        b.$12 = function(a) {
            if (this.$3 == null) {
                this.$1.logDebugInfo("empty_video_controller");
                return
            }
            var b = !1;
            b || (b = this.$5 ? !0 : c("gkx")("1124976"));
            if (!b) {
                this.$1.logDebugInfo("ineligible_to_comet_cvc");
                return
            }
            if (a.playing) {
                if (this.$2 == null) {
                    b = this.$3.getPlayheadPosition();
                    b >= 0 && (this.$2 = b)
                }
            } else this.$2 = null;
            this.$14(0)
        };
        b.stopUnifiedCVC = function() {
            this.$13()
        };
        b.destroy = function() {
            this.$13(), this.$4 != null && this.$4.remove(), this.$4 = null, this.$3 = null
        };
        b.$13 = function() {
            c("clearTimeout")(this.$8), c("clearTimeout")(this.$7), this.$8 = null, this.$7 = null, this.$2 = null, this.$1.clearAnyPreviousContext(), this.$9 = null
        };
        b.$15 = function() {
            c("clearTimeout")(this.$7), this.$7 = null
        };
        b.$16 = function() {
            this.$9 = null, this.$15(), this.$14(0)
        };
        b.$14 = function(a) {
            var b = this;
            if (this.$3 == null || this.$8 != null || this.$9 != null || this.$10) return;
            this.$8 = c("setTimeout")(function() {
                b.$8 = null;
                var a = b.$17();
                if (a == null) {
                    b.$1.logDebugInfo("empty_request");
                    return
                }
                b.$9 = a;
                var e = Date.now(),
                    f = !1;
                c("promiseDone")(a, function(c) {
                    if (a !== b.$9) return;
                    b.$9 = null;
                    if (c != null) {
                        c = b.$1.processUnifiedResponse(c);
                        b.$18(c, e)
                    } else b.$1.logHttpResponseBad("null payload", Date.now() - e)
                }, function(a) {
                    f = !0, b.$1.logHttpRequestFailure(a != null ? JSON.stringify(a) : null, Date.now() - e)
                });
                b.$7 = c("setTimeout")(function() {
                    f || b.$1.logHttpRequestTimeout(Date.now() - e), b.$16()
                }, j * d("DateConsts").MS_PER_SEC)
            }, a)
        };
        b.$18 = function(a, b) {
            this.$15();
            b = Date.now() - b;
            a.d != null ? (this.$1.logHttpRequestSuccess(b), this.$11 != null && this.$11(a.d)) : this.$1.logHttpResponseBad("no data field", b);
            if (a.a != null) {
                b = a.a.t;
                switch (b) {
                    case "p":
                        b = a.a.pi;
                        b == null && (b = j);
                        this.$14(b * d("DateConsts").MS_PER_SEC);
                        break;
                    case "s":
                        this.$10 = !0;
                        break
                }
            }
        };
        b.$17 = function() {
            var a = this.$19();
            if (a == null) return null;
            a = {
                d: JSON.stringify(a)
            };
            return c("cometAsyncFetch")(c("XVideoUnifiedCVCControllerRouteBuilder").buildURL({}), {
                data: a,
                method: "POST"
            })
        };
        b.$19 = function() {
            if (this.$3 == null) return null;
            var a = {};
            this.$6 != null && (a.lc = this.$6);
            this.$5 && (a.ls = !0);
            var b = 0,
                c = 0;
            this.$2 != null && (b = this.$2, c = this.$3.getPlayheadPosition());
            var d = this.$3.getCurrentState();
            b = this.$1.makeUnifiedVideoCVCUpdate(b, c, this.$20(d), d.muted, a);
            return b
        };
        b.$20 = function(a) {
            if (a.playing || a.seeking) return "playing";
            else if (a.ended) return "ended";
            else if (a.paused) return "paused";
            else return "unknown"
        };
        b.testing_setLastStartPosition = function(a) {
            this.$2 = a
        };
        b.testing_makeUnifiedStateUpdate = function() {
            return this.$19()
        };
        b.testing_handleUnifiedResponse = function(a) {
            return this.$18(a, Date.now())
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("getPlayerFormatForLogData", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        a = a.isFullscreen;
        return a === !0 ? "full_screen" : b != null ? b : "inline"
    }
    f["default"] = a
}), 66);
__d("useVideoPlayerUnifiedCVCProvider", ["CvcV3HttpEventFalcoEvent", "UnifiedVideoCVCSubscription", "VideoPlayerHooks", "createVideoStateHook", "getPlayerFormatForLogData", "qex", "react", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react").useEffect;
    var h = c("qex")._("109") ? b : c("useLayoutEffect_SAFE_FOR_SSR");
    e = d("createVideoStateHook").createVideoStateHook(null);
    var i = e.setterHook;
    f = d("createVideoStateHook").createVideoStateHook(null);
    var j = f.setterHook;
    b = f.valueHook;

    function a(a) {
        var b = a.disableSubscription,
            e = a.playerFormat,
            f = a.subOrigin,
            g = a.videoFBID,
            k = d("VideoPlayerHooks").useIsLive(),
            l = d("VideoPlayerHooks").useIsFullscreen(),
            m = d("VideoPlayerHooks").useIsDesktopPictureInPicture(),
            n = d("VideoPlayerHooks").useController(),
            o = i(),
            p = j();
        h(function() {
            if (b === !0) {
                c("CvcV3HttpEventFalcoEvent").log(function() {
                    return {
                        countable_id: g,
                        name: "disable_subscription"
                    }
                });
                return
            }
            var a = new(c("UnifiedVideoCVCSubscription"))(g, c("getPlayerFormatForLogData")({
                isDesktopPictureInPicture: m,
                isFullscreen: l
            }, e), f, n, k, function(a) {
                p(a)
            });
            o(a);
            return function() {
                a.destroy()
            }
        }, [m, l, k, b, e, p, o, f, n, g])
    }
    e = b;
    g.useVideoPlayerUnifiedCVCProvider = a;
    g.useVideoPlayerUnifiedCVCData = e
}), 98);
__d("VideoPlayerXImplSurface.react", ["CoreVideoPlayerAudioClient.react", "CoreVideoPlayerAutoplayClient.react", "VideoPlayerCaptionsAreaDeferred.react", "VideoPlayerIMFStateContext", "VideoPlayerInteractionOverlay.react", "VideoPlayerWebSessionExtender.react", "cr:1954434", "cr:3916", "cr:902", "cr:908", "emptyFunction", "gkx", "react", "useVideoPlayerDefaultLoadingIndicators", "useVideoPlayerUnifiedCVCProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = (e = b("cr:902")) != null ? e : c("emptyFunction");
    e = (e = b("cr:908")) != null ? e : {
        useVideoPlayerIMFStateContainerInternal: c("emptyFunction")
    };
    var j = e.useVideoPlayerIMFStateContainerInternal;

    function a(a) {
        var e = a.children,
            f = a.disableCVCSubscription,
            g = a.disableLoadingIndicator;
        g = g === void 0 ? !1 : g;
        var k = a.disableLogging,
            l = a.instreamVideoAdBreaksPlayer,
            m = a.playerFormat,
            n = a.subOrigin,
            o = a.videoFBID,
            p = a.videoPlayerIMFFromVideoMetadata;
        a = a.videoPlayerSpherical;
        d("useVideoPlayerUnifiedCVCProvider").useVideoPlayerUnifiedCVCProvider({
            disableSubscription: k === !0 || f,
            playerFormat: m,
            subOrigin: n,
            videoFBID: o
        });
        i();
        k = c("useVideoPlayerDefaultLoadingIndicators")();
        f = k.loadingIndicatorElement;
        m = j({
            videoPlayerIMFFromVideoMetadata: p
        });
        return h.jsxs(d("VideoPlayerIMFStateContext").VideoPlayerIMFStateContextProvider, {
            value: (o = m == null ? void 0 : m.exposedState) != null ? o : null,
            children: [a, g ? null : f, c("gkx")("1586633") ? h.jsx(d("VideoPlayerInteractionOverlay.react").VideoPlayerInteractionOverlay, {}) : null, h.jsxs(c("VideoPlayerCaptionsAreaDeferred.react"), {
                children: [e, l]
            }), h.jsx(c("CoreVideoPlayerAutoplayClient.react"), {}), h.jsx(c("CoreVideoPlayerAudioClient.react"), {}), b("cr:1954434") ? h.jsx(b("cr:1954434"), {}) : null, b("cr:3916") ? h.jsx(b("cr:3916"), {
                subOrigin: n
            }) : null, h.jsx(c("VideoPlayerWebSessionExtender.react"), {})]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("normalizeVideoPlayerLoopCount", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        b === void 0 && (b = null);
        d === void 0 && (d = null);
        if (a == null) {
            var e;
            d = ((e = b) != null ? e : !1) ? (e = d) != null ? e : 0 : 0;
            d === -1 ? e = -1 : d < 0 || !Number.isFinite(d) || Math.floor(d) !== d ? e = 0 : d === 0 && b === !0 ? e = -1 : e = d
        } else if (a === -1 || a === Number.POSITIVE_INFINITY) e = -1;
        else if (a < 0 || !Number.isFinite(a) || Math.floor(a) !== a) throw c("unrecoverableViolation")("Invalid loopingCount: " + a, "comet_video_player");
        else e = a;
        return e
    }
    g["default"] = a
}), 98);
__d("VideoPlayerXImpl.react", ["CoreVideoPlayerWithComponents.react", "VideoPlayerXImplSurface.react", "normalizeVideoPlayerLoopCount", "react", "usePlayerOriginRouteTracePolicy", "useRouteProductAttribution"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children,
            d = a.disableCVCSubscription;
        d = d === void 0 ? !1 : d;
        var e = a.disableLoadingIndicator,
            f = a.disableLogging,
            g = a.implementations,
            i = a.instreamVideoAdBreaksPlayer,
            j = a.portalingEnabled,
            k = a.portalingFromVideoID,
            l = a.portalingPlaceMetaData,
            m = a.portalingRenderPlaceholder,
            n = a.videoPlayerIMFFromVideoMetadata,
            o = a.videoPlayerSpherical;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "disableCVCSubscription", "disableLoadingIndicator", "disableLogging", "implementations", "instreamVideoAdBreaksPlayer", "portalingEnabled", "portalingFromVideoID", "portalingPlaceMetaData", "portalingRenderPlaceholder", "videoPlayerIMFFromVideoMetadata", "videoPlayerSpherical"]);
        var p = c("usePlayerOriginRouteTracePolicy")(),
            q = c("useRouteProductAttribution")();
        q || (q = a.productAttribution);
        var r = a.loopCount,
            s = a.playerFormat,
            t = a.subOrigin,
            u = a.videoFBID;
        r = c("normalizeVideoPlayerLoopCount")(r);
        return h.jsx(c("CoreVideoPlayerWithComponents.react"), babelHelpers["extends"]({}, a, {
            disableLogging: f,
            implementations: g,
            loopCount: r,
            portalingEnabled: j,
            portalingFromVideoID: k,
            portalingPlaceMetaData: l,
            portalingRenderPlaceholder: m,
            productAttribution: q,
            routeTracePolicy: p,
            children: h.jsx(c("VideoPlayerXImplSurface.react"), {
                children: b,
                disableCVCSubscription: d,
                disableLoadingIndicator: e,
                disableLogging: f,
                instreamVideoAdBreaksPlayer: i,
                playerFormat: s,
                subOrigin: t,
                videoFBID: u,
                videoPlayerIMFFromVideoMetadata: n,
                videoPlayerSpherical: o
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerXImplRelayWrapper.react", ["VideoPlayerXImpl.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("VideoPlayerXImpl.react")
}), 98);
__d("LatencySensitiveType", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        NORMAL: 0,
        LOW: 1,
        ULTRA_LOW: 2
    });
    c = a;
    f["default"] = c
}), 66);
__d("XFBLatencySensitiveTypeUtils.facebook", ["$InternalEnumUtils", "LatencySensitiveType"], (function(a, b, c, d, e, f, g) {
    a = d("$InternalEnumUtils").createToJSEnum(c("LatencySensitiveType"));
    b = d("$InternalEnumUtils").createFromJSEnum(c("LatencySensitiveType"));
    g.toJSEnum = a;
    g.fromJSEnum = b
}), 98);
__d("defaultErrorBoundaryFallback", ["fbt", "VideoPlayerFallbackCover.react", "gkx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function j(a) {
        return a && c("gkx")("1792489") ? a.message.toLowerCase().indexOf("audio_renderer_error") >= 0 : !1
    }

    function a(a) {
        var b = a.error;
        a = a.retry;
        var d = j(b),
            e = null;
        a = a;
        d && (e = h._("Audio renderer error: Please restart your computer."), a = null);
        return i.jsx(c("VideoPlayerFallbackCover.react"), {
            debugError: b,
            message: e,
            onRetry: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getVideoPlayerAutoplayProps", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        b = b != null ? b : "respect_user_settings";
        var d = b === "dangerously_always_autoplay";
        c = c != null ? c : "unknown";
        var e = a.autoplaySetting || "default_autoplay",
            f = e === "off";
        d = d || b === "respect_user_settings" && !f && a.canAutoplay;
        f = b === "do_not_autoplay" ? c : a.autoplayGatingResult;
        c = d ? "allow" : b === "dangerously_disable_autoplay_management" ? "dangerously_disable_autoplay_management" : "deny";
        return {
            autoplayGatingResult: f,
            autoplaySetting: e,
            canAutoplay: c
        }
    }
    f["default"] = a
}), 66);
__d("manifestHasPlayableRepresentations", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a.length <= 0) return !1;
        var b = !1,
            c = !1,
            d = !1,
            e = !1;
        for (var a = a, f = Array.isArray(a), g = 0, a = f ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var h;
            if (f) {
                if (g >= a.length) break;
                h = a[g++]
            } else {
                g = a.next();
                if (g.done) break;
                h = g.value
            }
            h = h;
            h.representationType === "video" && (b = !0, h.isTypeSupported && (c = !0));
            h.representationType === "audio" && (d = !0, h.isTypeSupported && (e = !0));
            if (e && c) break
        }
        return (e || !d) && (c || !b)
    }
    f["default"] = a
}), 66);
__d("GraphQLVideoAutoplayGatingResult", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        a = a != null ? a : "unknown";
        b = b ? b : null;
        return {
            autoplayGatingResult: a,
            autoplaySetting: b,
            canAutoplay: c != null ? c : !1
        }
    }
    f.makeGraphQLVideoAutoplayGatingResult = a
}), 66);
__d("useGraphQLVideoAutoplayGatingResult", ["CometRelay", "GraphQLVideoAutoplayGatingResult", "useGraphQLVideoAutoplayGatingResult_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useGraphQLVideoAutoplayGatingResult_video.graphql"), a);
        return d("GraphQLVideoAutoplayGatingResult").makeGraphQLVideoAutoplayGatingResult(a.autoplay_gating_result, a.viewer_autoplay_setting, a.can_autoplay)
    }
    g["default"] = a
}), 98);
__d("GraphQLVideoDRMInfo", ["isEmptyObject"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.fairplay_cert,
            d = a.graph_api_video_license_uri,
            e = a.video_license_uri_map;
        a = a.widevine_cert;
        d = {
            fairplayCert: b,
            graphApiVideoLicenseUri: (b = d) != null ? b : null,
            videoLicenseUriMap: e,
            widevineCert: a
        };
        return d.graphApiVideoLicenseUri === null && c("isEmptyObject")(d.videoLicenseUriMap) ? null : d
    }
    g.makeGraphQLVideoDRMInfo = a
}), 98);
__d("useGraphQLVideoDRMInfo", ["CometRelay", "GraphQLVideoDRMInfo", "react", "useGraphQLVideoDRMInfo_video.graphql", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useRef;

    function j(a) {
        if (a != null) {
            a = k(a);
            return d("GraphQLVideoDRMInfo").makeGraphQLVideoDRMInfo(a)
        }
        return null
    }

    function k(a) {
        a = JSON.parse(a) || {};
        var b = a.fairplay_cert,
            c = a.graph_api_video_license_uri,
            d = a.video_license_uri_map;
        a = a.widevine_cert;
        return {
            fairplay_cert: b,
            graph_api_video_license_uri: c,
            video_license_uri_map: d,
            widevine_cert: a
        }
    }

    function a(a) {
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useGraphQLVideoDRMInfo_video.graphql"), a);
        var e = i(null),
            f = j(a.drm_info),
            g = c("useUnsafeRef_DEPRECATED")(null);
        e.current !== a.drm_info && (e.current = a.drm_info, g.current = f);
        return g.current
    }
    g["default"] = a
}), 98);
__d("GraphQLVideoP2PSettings", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("$InternalEnum").Mirrored(["HiveJava", "HiveJS", "StatsJS"]);

    function a(a) {
        return (a = g.cast(a)) != null ? a : null
    }
    f.HiveTechOrder = g;
    f.hiveTechOrderOrNull = a
}), 66);
__d("useGraphQLVideoP2PSettings", ["CometRelay", "GraphQLVideoP2PSettings", "recoverableViolation", "useGraphQLVideoP2PSettings_video.graphql", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function i(a) {
        var b = null;
        if (a) {
            var e, f, g, h, i;
            e = {
                delay_p2p_until_play: (e = (e = a.config) == null ? void 0 : e.delay_p2p_until_play) != null ? e : !1,
                disable_hivejava_for_livevc: (e = (e = a.config) == null ? void 0 : e.disable_hivejava_for_livevc) != null ? e : !1
            };
            var j = a.ticket,
                k = a.community_info;
            f = (f = a.hive_initialization_options) == null ? void 0 : f.debug_level;
            g = (g = (g = a.hive_initialization_options) == null ? void 0 : g.hive_tech_order.map(function(a) {
                var b = d("GraphQLVideoP2PSettings").hiveTechOrderOrNull(a);
                b == null && a != null && c("recoverableViolation")("Invalid hive tech order: '" + a + "'", "comet_video_player");
                return b
            }).filter(Boolean)) != null ? g : [];
            h = (h = a.hive_initialization_options) == null ? void 0 : (h = h.hive_java) == null ? void 0 : h.min_version;
            i = ((i = a.hive_initialization_options) == null ? void 0 : i.hive_java) ? {
                minVersion: h
            } : null;
            h = a.hive_initialization_options ? {
                HiveJava: i,
                debugLevel: f,
                hiveTechOrder: g
            } : null;
            f = {
                communityId: (a = k == null ? void 0 : k.community_id) != null ? a : "unknowncustomer",
                communityName: (i = k == null ? void 0 : k.community_name) != null ? i : "Unknown Customer"
            };
            b = {
                community_info: f,
                config: e,
                hive_initialization_options: h,
                ticket: j
            }
        }
        return b
    }

    function a(a) {
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useGraphQLVideoP2PSettings_video.graphql"), a);
        var e = c("useUnsafeRef_DEPRECATED")(null),
            f = c("useUnsafeRef_DEPRECATED")(null);
        a = i((a = a.p2p_settings) != null ? a : null);
        var g = JSON.stringify(a);
        if (e.current !== g) {
            e.current = (e = g) != null ? e : null;
            f.current = (g = a) != null ? g : null
        }
        return f.current
    }
    g["default"] = a
}), 98);
__d("VideoPlayerProgressiveImplementationData", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.hdSrc,
            c = a.hdSrcPreferred,
            d = a.isExternalMedia;
        a = a.sdSrc;
        return a == null ? null : {
            hdSrc: b,
            hdSrcPreferred: c,
            isExternalMedia: d,
            sdSrc: a
        }
    }
    f.makeProgressiveImplementationData = a
}), 66);
__d("useProgressiveImplementationData", ["CometRelay", "VideoPlayerProgressiveImplementationData", "gkx", "useProgressiveImplementationData_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, e) {
        var f, g;
        e = e.initialForceHD;
        e = e === void 0 ? !1 : e;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useProgressiveImplementationData_video.graphql"), a);
        f = a.is_spherical === !0 ? (f = (f = a.spherical_video_fallback_urls) == null ? void 0 : f.hd) != null ? f : a.playable_url_quality_hd : a.playable_url_quality_hd;
        g = a.is_spherical === !0 ? (g = (g = a.spherical_video_fallback_urls) == null ? void 0 : g.sd) != null ? g : a.playable_url : a.playable_url;
        var i = a.is_rss_podcast_video === !0,
            j = c("gkx")("1129");
        return d("VideoPlayerProgressiveImplementationData").makeProgressiveImplementationData({
            hdSrc: f,
            hdSrcPreferred: e === !0 || j || a.min_quality_preference === "HD" || a.min_quality_preference === "UHD",
            isExternalMedia: i,
            sdSrc: g
        })
    }
    g["default"] = a
}), 98);
__d("MediaPlaybackCompoundEventStateMachineLogger", ["emptyFunction", "gkx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = .5;
    b = c("emptyFunction");
    d = c("emptyFunction");
    e = c("emptyFunction");

    function i() {
        return {
            canLogPausedOrFinishedPlaying: !1,
            canLogPlayingEvent: !0,
            hasLoggedStartedPlaying: !1,
            hasPendingRequestedPlaying: !1,
            isLoggingScrubbingSequence: !1,
            lastLoggedCaptionState: null,
            lastLoggedFullscreenState: !1,
            lastLoggedSoundOnState: null,
            shouldIgnoreDomPause: !1,
            shouldIgnoreDomPlay: !1,
            shouldLogRequestedPlayingForScrub: !1
        }
    }

    function a(a) {
        var b = {},
            d = a.initialLoggingMetaData;
        d;
        var e = [],
            f = i();

        function g(a) {
            var b, c = a.eventType,
                g = a.snaplOverrides,
                h = a.state;
            a = a.tags;
            var i = null,
                j = null,
                k = (a == null ? void 0 : a.fullscreen) != null ? a == null ? void 0 : a.fullscreen : f.lastLoggedFullscreenState,
                l = (a == null ? void 0 : a.captions_displayed) != null ? a == null ? void 0 : a.captions_displayed : f.lastLoggedCaptionState,
                m = (a == null ? void 0 : a.player_sound_on) != null ? a == null ? void 0 : a.player_sound_on : f.lastLoggedSoundOnState;
            b = (b = d.coreVideoPlayerMetaData.videoFBID) != null ? b : "-1";
            var n = d.coreVideoPlayerMetaData.adClientToken == null ? "organic" : "paid";
            b = {
                current_watching_module: "",
                media_id: b,
                player_origin: d.coreVideoPlayerMetaData.playerOriginOverride,
                player_suborigin: d.coreVideoPlayerMetaData.subOrigin,
                tracking_type: n
            };
            n = "";
            (g == null ? void 0 : g.video_time_position) != null ? n = Math.round(g.video_time_position * 1e3).toString() : h.uncontrolledState.videoElementPlayheadPosition != null && (n = Math.round(h.uncontrolledState.videoElementPlayheadPosition * 1e3).toString());
            g = {
                client_time_ms: Date.now().toString(),
                event_name: c,
                media_time_ms: n,
                tag_metadata: {
                    captions_displayed: a == null ? void 0 : a.captions_displayed,
                    fullscreen: a == null ? void 0 : a.fullscreen,
                    player_sound_on: a == null ? void 0 : a.player_sound_on
                }
            };
            h = {
                client_high_res_packaging_time_ms: i,
                event: g,
                operational_metadata: j,
                required_metadata: b
            };
            e.push(h);
            f.lastLoggedSoundOnState = m;
            f.lastLoggedFullscreenState = k;
            f.lastLoggedCaptionState = l
        }

        function j(a) {
            d;
            if (a.type === "notify_logging_metadata_change") {
                a = a.payload.loggingMetaData;
                d = a
            }
        }

        function k(a, c, d) {
            if (a.controlledState.playbackState !== c.controlledState.playbackState && c.controlledState.playbackState === "ended" && f.canLogPausedOrFinishedPlaying) {
                g({
                    eventType: "completed",
                    state: c
                });
                f.canLogPausedOrFinishedPlaying = !1;
                return b
            } else return b
        }

        function l(a, c) {
            g({
                eventType: "requested_playing",
                snaplOverrides: c,
                state: a
            });
            f.hasPendingRequestedPlaying = !0;
            f.canLogPausedOrFinishedPlaying = !0;
            return b
        }

        function m(a) {
            if (!f.canLogPausedOrFinishedPlaying) return b;
            else if (f.hasPendingRequestedPlaying) {
                n(a);
                f.canLogPausedOrFinishedPlaying = !1;
                f.hasPendingRequestedPlaying = !1;
                return b
            } else {
                g({
                    eventType: "paused",
                    state: a
                });
                f.canLogPausedOrFinishedPlaying = !1;
                f.hasPendingRequestedPlaying = !1;
                return b
            }
        }

        function n(a) {
            g({
                eventType: "cancelled",
                state: a
            });
            return b
        }

        function o(a, c, d) {
            if (d.type === "dom_event_play_promise_rejected" && f.hasPendingRequestedPlaying) {
                a = d.payload.playPromiseRejectionReason;
                if (a != null && a.name === "NotAllowedError") {
                    n(c);
                    return b
                } else return b
            } else return b
        }

        function p(a, c, d) {
            if ((d.type === "controller_play_requested" || d.type === "dom_event_play" && !f.shouldIgnoreDomPlay) && a.controlledState.playbackState !== c.controlledState.playbackState) {
                l(c);
                return b
            } else return b
        }

        function q(a, c, d) {
            var e = c.controlledState.playbackState,
                g = a.controlledState.playbackState;
            if (d.type === "controller_scrub_begin_requested" && !a.controlledState.scrubbing && e !== "paused" && e !== "ended") {
                m(c);
                f.isLoggingScrubbingSequence = !0;
                return b
            } else if (!a.controlledState.seeking && c.controlledState.seeking && !f.isLoggingScrubbingSequence && e !== "paused" && e !== "ended" && !f.hasPendingRequestedPlaying) {
                m(c);
                f.shouldLogRequestedPlayingForScrub = !0;
                return b
            } else if (d.type === "controller_scrub_end_requested" && a.controlledState.scrubbing && e !== "paused" && e !== "ended") {
                l(c, {
                    video_time_position: d.payload.seekTargetPosition
                });
                return b
            } else if (a.controlledState.seeking && !c.controlledState.seeking) {
                d = c.uncontrolledState.videoElementPlayheadPosition;
                a = a.controlledState.implementationSeekSourcePosition;
                a != null && d != null && Math.abs(a - d) > h && (f.shouldLogRequestedPlayingForScrub && e !== "paused" && e !== "ended" && l(c), f.isLoggingScrubbingSequence = !1, f.shouldLogRequestedPlayingForScrub = !1, g !== "paused" && g !== "ended" && (f.canLogPlayingEvent = !0));
                return b
            } else return b
        }

        function r(a, c, d) {
            if (a.controlledState.playbackState === "stalling" && c.controlledState.playbackState === "playing" && f.canLogPlayingEvent) {
                g({
                    eventType: f.hasLoggedStartedPlaying ? "unpaused" : "started_playing",
                    state: c
                });
                f.hasLoggedStartedPlaying = !0;
                f.canLogPlayingEvent = !1;
                f.hasPendingRequestedPlaying = !1;
                return b
            } else return b
        }

        function s(a, c, d) {
            if ((d.type === "controller_pause_requested" || d.type === "dom_event_pause" && !f.shouldIgnoreDomPause) && a.controlledState.playbackState !== c.controlledState.playbackState) {
                m(c);
                return b
            } else return b
        }

        function t(a, d, e) {
            a = d.controlledState.playbackState;
            if (a !== "paused" && a !== "ended") {
                c("gkx")("1469813") && e.type === "implementation_video_node_unmounted" ? m(d) : (e.type === "implementation_unmounted" || e.type === "implementation_engine_destroy_requested") && m(d);
                return b
            } else return b
        }

        function u(a, c, d) {
            if (d.type !== "notify_fullscreen_changed") return b;
            a = f.lastLoggedFullscreenState;
            d = c.uncontrolledState.isFullscreen;
            if (a !== !0 && d === !0) {
                x(c, !0);
                return b
            } else if (a === !0 && d === !1) {
                x(c, !1);
                return b
            } else return b
        }

        function v(a, c, d) {
            if (d.type !== "controller_muted_requested" && d.type !== "controller_volume_requested") return b;
            a = c.controlledState.muted;
            d = c.controlledState.volume;
            a = !(a || d === 0);
            d = f.lastLoggedSoundOnState;
            if (d !== !0 && a === !0) {
                g({
                    eventType: "tags_changed",
                    state: c,
                    tags: {
                        player_sound_on: !0
                    }
                });
                return b
            } else if (d !== !1 && a === !1) {
                g({
                    eventType: "tags_changed",
                    state: c,
                    tags: {
                        player_sound_on: !1
                    }
                });
                return b
            } else return b
        }

        function w(a, c, d) {
            if (d.type !== "controller_set_captions_visible_requested") return b;
            a = f.lastLoggedCaptionState;
            d = c.controlledState.captionsVisible;
            if (a !== !0 && d === !0) {
                g({
                    eventType: "tags_changed",
                    state: c,
                    tags: {
                        captions_displayed: !0
                    }
                });
                return b
            } else if (a !== !1 && d === !1) {
                g({
                    eventType: "tags_changed",
                    state: c,
                    tags: {
                        captions_displayed: !1
                    }
                });
                return b
            } else return b
        }

        function x(a, b) {
            g({
                eventType: "tags_changed",
                state: a,
                tags: {
                    fullscreen: b
                }
            })
        }
        return {
            consumeLoggerEvents: function() {
                if (e.length > 0)
                    if (c("qex")._("1217")) {
                        var a = e.some(function(a) {
                            return a.event.event_name === "paused" || a.event.event_name === "completed" || a.event.event_name === "cancelled"
                        });
                        if (a) return e.splice(0)
                    } else return e.splice(0);
                return []
            },
            handleStateMachine: function(a, b, c) {
                j(c);
                var d = b.controlledState.playbackState,
                    e = [u, o, p, q, r, k, s, v, t, w];
                e.forEach(function(d) {
                    d(a, b, c)
                });
                (d === "paused" || d === "ended") && (f.canLogPlayingEvent = !0);
                c.type === "controller_pause_requested" && (f.shouldIgnoreDomPause = !0);
                c.type === "controller_play_requested" && (f.shouldIgnoreDomPlay = !0);
                c.type === "dom_event_pause" && (f.shouldIgnoreDomPause = !1);
                c.type === "dom_event_play" && (f.shouldIgnoreDomPlay = !1)
            }
        }
    }
    g.createMediaPlaybackCompoundEventStateMachineLogger = a
}), 98);
__d("VideoPlayerWwwLogger", ["VideoPlayerWwwFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b, c = a.logData.live_trace_stream_id !== null && a.logData.live_trace_stream_type !== null;
        return {
            access_token: a.logData.access_token,
            ad_client_token: a.logData.ad_client_token,
            attribution_id: a.logData.attribution_id,
            attribution_id_v2: a.logData.attribution_id_v2,
            attribution_id_v2_root: a.logData.attribution_id_v2_root,
            audio_only: a.logData.audio_only,
            audio_representation_id: a.logData.audio_representation_id,
            autoplay_eligible: a.logData.autoplay_eligible,
            autoplay_failure_reasons: a.logData.autoplay_failure_reasons,
            autoplay_setting: a.logData.autoplay_setting,
            available_qualities: a.logData.available_qualities,
            broadcaster_origin: a.logData.broadcaster_origin,
            browser_tab_id: a.logData.browser_tab_id,
            caption_state: a.logData.caption_state,
            cast_client_app_id: a.logData.cast_client_app_id,
            client_latency_setting: a.logData.client_latency_setting,
            current_playback_speed: a.logData.current_playback_speed,
            current_viewability_percentage: Number(a.logData.current_viewability_percentage),
            current_volume: a.logData.current_volume,
            dash_perf_logging_enabled: a.logData.dash_perf_logging_enabled,
            data_connection_quality: a.logData.data_connection_quality,
            debug_reason: a.logData.debug_reason,
            device_id: a.logData.device_id,
            device_type: a.logData.device_type,
            dropped_frame_count: Number(a.logData.dropped_frame_count),
            error: a.logData.error,
            error_code: a.logData.error_code,
            error_description: a.logData.error_description,
            error_domain: a.logData.error_domain,
            error_type: a.logData.error_type,
            error_user_info: a.logData.error_user_info,
            event_name: a.eventType,
            event_seq_num: a.logData.event_seq_num,
            external_log_id: a.logData.external_log_id,
            external_log_type: a.logData.external_log_id,
            fb_manifest_identifier: a.logData.fb_manifest_identifier,
            feed_aggregation_type: a.logData.feed_aggregation_type,
            feed_position: a.logData.feed_position,
            frame_events: a.logData.frame_events,
            ft: a.logData.ft,
            interrupt_count: a.logData.interrupt_count !== null ? Number(a.logData.interrupt_count) : null,
            interrupt_time: Number(a.logData.interrupt_time),
            is_abr_enabled: a.logData.is_abr_enabled,
            is_fbms: a.logData.is_fbms,
            is_live_preview: (b = a.logData.is_live_preview) != null ? b : !1,
            is_live_video_rewound: a.logData.is_live_video_rewound,
            is_p2p_playback: a.logData.is_p2p_playback,
            is_pip: a.logData.is_pip,
            is_predictive_playback: a.logData.is_predictive_playback,
            is_sound_on: a.logData.is_sound_on,
            is_stalling: a.logData.is_stalling,
            is_templated_manifest: a.logData.is_templated_manifest,
            last_viewability_percentage: Number(a.logData.last_viewability_percentage),
            live_trace_source_id: a.logData.live_trace_source_id,
            live_trace_stream_id: c ? a.logData.live_trace_stream_id : null,
            live_trace_stream_type: c ? a.logData.live_trace_stream_type : null,
            mpd_validation_errors: a.logData.mpd_validation_errors,
            network_connected: a.logData.network_connected,
            next_representation_id: a.logData.next_representation_id,
            notification_id: a.logData.notification_id,
            notification_medium: a.logData.notification_medium,
            permalink_share_id: a.logData.permalink_share_id,
            playback_caption_format: a.logData.playback_caption_format,
            playback_caption_locale: a.logData.playback_caption_locale,
            playback_duration: a.logData.playback_duration,
            playback_is_broadcast: a.logData.playback_is_broadcast,
            playback_is_drm: a.logData.playback_is_drm,
            playback_is_live_streaming: a.logData.playback_is_live_streaming,
            player_format: a.logData.player_format,
            player_instance_key: a.logData.player_instance_key,
            player_mode: a.logData.player_mode,
            player_origin: a.logData.player_origin,
            player_state: a.logData.player_state,
            player_suborigin: a.logData.player_suborigin,
            player_version: a.logData.player_version,
            reaction_video_channel_type: a.logData.reaction_video_channel_type,
            representation_id: a.logData.representation_id,
            resource_url: a.logData.resource_url,
            routeTracePolicy: a.routeTracePolicy,
            seq_num: a.logData.seq_num,
            source: a.source_VPL_LOGGING_HACK,
            source_VPL_LOGGING_HACK: a.logData.source_VPL_LOGGING_HACK,
            stall_count: Number(a.logData.stall_count),
            stall_count_200_ms: Number(a.logData.stall_count_200_ms),
            stall_time: Number(a.logData.stall_time),
            state: a.logData.state,
            streaming_format: a.logData.streaming_format,
            time_ms: a.logData.time_ms,
            total_frame_count: Number(a.logData.total_frame_count),
            tracking_data_encrypted: a.logData.tracking_data_encrypted,
            tracking_nodes: a.logData.tracking_nodes,
            tv_session_id: a.logData.tv_session_id,
            v2_heart_beat: a.logData.v2_heart_beat,
            video_bandwidth: a.logData.video_bandwidth,
            video_buffer_end_position: a.logData.video_buffer_end_position,
            video_chaining_depth_level: a.logData.video_chaining_depth_level,
            video_chaining_parent_video_id: a.logData.video_chaining_parent_video_id,
            video_chaining_session_id: a.logData.video_chaining_session_id,
            video_channel_id: a.logData.video_channel_id,
            video_id: a.logData.video_id,
            video_last_start_time_position: a.logData.video_last_start_time_position,
            video_play_reason: a.logData.video_play_reason,
            video_player_height: Number(a.logData.video_player_height),
            video_player_width: Number(a.logData.video_player_width),
            video_time_position: a.logData.video_time_position,
            vpts: a.logData.vpts,
            web_client_revision: a.logData.web_client_revision
        }
    }
    a = {
        logComet: function(a) {
            c("VideoPlayerWwwFalcoEvent").log(function() {
                return h(a)
            })
        },
        logCometImmediately: function(a) {
            c("VideoPlayerWwwFalcoEvent").logImmediately(function() {
                return h(a)
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("VideoPlayerBanzaiLogFlusher", ["VideoPlayerWwwLogger", "emptyFunction", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("emptyFunction");
    b = function() {
        function a(a) {
            this.$1 = a
        }
        var b = a.prototype;
        b.flushLogs = function() {
            var a = this.$1.consumeLoggerEvents();
            a.forEach(function(a) {
                var b = {
                    event: a.eventType,
                    logData: a.logData,
                    routeTracePolicy: a.routeTracePolicy,
                    source: a.source_VPL_LOGGING_HACK
                };
                if (a.source_VPL_LOGGING_HACK === "animated_image_share" && c("gkx")("1710047")) return;
                b = (b = a.logData) == null ? void 0 : b.ad_client_token;
                b != null ? c("VideoPlayerWwwLogger").logCometImmediately(a) : c("VideoPlayerWwwLogger").logComet(a)
            })
        };
        b.discardLogsWithoutFlushing = function() {
            var a = this.$1.consumeLoggerEvents()
        };
        return a
    }();
    g["default"] = b
}), 98);
__d("VideoPlayerCaptionsController", ["JSResourceForInteraction", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("JSResourceForInteraction")("VideoPlayerHTML5ApiCea608State").__setRef("VideoPlayerCaptionsController"),
        i = c("JSResourceForInteraction")("VideoPlayerHTML5ApiWebVttState").__setRef("VideoPlayerCaptionsController");

    function a(a) {
        var b = a.captionsUrl,
            d = a.inbandCaptionsExpected,
            e = a.onCaptionsLoaded,
            f = null,
            g = null,
            j = null,
            k = null;

        function l(a) {
            var b = i.load().then(function(c) {
                if (b !== j) return;
                f = new c({
                    captionsDisplay: null,
                    onCaptionsLoaded: e,
                    onReady: function(b) {
                        b.loadFromUrl(a)
                    }
                })
            })["catch"](function(a) {
                if (b !== j) return;
                c("recoverableViolation")("Failed to load the VideoPlayerHTML5ApiWebVttState module: " + a.message, "comet_video_player")
            });
            return b
        }

        function m() {
            var a = h.load().then(function(b) {
                if (a !== k) return;
                g = new b({
                    captionsDisplay: null,
                    onCaptionsLoaded: e,
                    onReady: function(a) {
                        a.processQueue()
                    }
                })
            })["catch"](function(b) {
                if (a !== k) return;
                c("recoverableViolation")("Failed to load the VideoPlayerHTML5ApiCea608State module: " + b.message, "comet_video_player")
            });
            return a
        }
        b != null ? j = l(b) : d === !0 && (k = m());
        return {
            destroy: function() {
                f && (f.destroy(), f = null), g && (g.destroy(), g = null), j && (j = null), k && (k = null)
            },
            getCaptionFormat: function() {
                return f ? "webvtt" : g ? "cea608" : null
            },
            handleCea608BytesReceived: function(a) {
                g && g.enqueueBytes(a)
            },
            handleTimeUpdate: function(a) {
                if (f) {
                    var b;
                    f.source && f.source.handleTimeUpdate(a);
                    return (b = (b = f) == null ? void 0 : b.getCurrentScreenRepresentation()) != null ? b : null
                } else if (g) {
                    g.source && g.source.handleTimeUpdate(a);
                    return (a = (b = g) == null ? void 0 : b.getCurrentScreenRepresentation()) != null ? a : null
                }
                return null
            },
            updateCaptionsUrl: function(a) {
                f && (f.destroy(), f = null), a != null && (j = l(a))
            },
            updateInbandCaptionsExpected: function(a) {
                g && (g.destroy(), g = null), a && (k = m())
            }
        }
    }
    g.createCaptionsController = a
}), 98);
__d("VideoPlayerImplementationErrorNormalization", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.getType();
        switch (b) {
            case "OZ_NETWORK":
                b = (b = (b = a.getExtra()) == null ? void 0 : b.code) != null ? b : "0";
                b = parseInt(b, 10);
                return b < 100 || b > 599 ? "NetworkError" : "HTTPError";
            case "OZ_SOURCE_BUFFER_QUOTA_EXCEEDED":
                a = (b = a.getExtra()) == null ? void 0 : b.mimeType;
                if (a != null && a.indexOf("video") > -1) return "VideoDecodeError";
                else if (a != null && a.indexOf("audio") > -1) return "AudioDecodeError";
                else return "GenericDecodeError"
        }
        return null
    }

    function b(a) {
        switch (a) {
            case "MEDIA_ERR_NETWORK":
                return "NetworkError";
            case "MEDIA_ERR_ABORTED":
            case "MEDIA_ERR_DECODE":
            case "MEDIA_ERR_SRC_NOT_SUPPORTED":
            case "MEDIA_ERR_UNKNOWN":
                return "GenericDecodeError";
            case "OZ_REPRESENTATION_PARSER":
            case "OZ_XML_PARSER":
                return "ManifestParseError";
            case "BUFFERING_TIMEOUT":
            case "OZ_DRM_MANAGER":
            case "OZ_INITIALIZATION":
            case "OZ_JAVASCRIPT_NATIVE":
            case "OZ_SOURCE_BUFFER":
            case "OZ_STREAM_APPEND_QUOTA_EXCEEDED_HANDLER_ERROR":
            case "OZ_NETWORK_REQUEST_STREAM_RETRY_HANDLER_ERROR":
                return "RuntimeError"
        }
        return null
    }
    f.getVideoPlayerNormalizedErrorTypeFromOzError = a;
    f.getErrorTypeFromErrorName = b
}), 66);
__d("VideoPlayerImplementationErrors", ["NetworkStatus", "VideoPlayerImplementationErrorNormalization", "getErrorMessageFromMediaErrorCode", "getErrorNameFromMediaErrorCode", "gkx", "oz-player/utils/OzError"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        BUFFERING_TIMEOUT_INPLAY: "30000",
        BUFFERING_TIMEOUT_INPLAY_NO_NETWORK: "30001",
        BUFFERING_TIMEOUT_LIVEREWIND_INPLAY: "30010",
        BUFFERING_TIMEOUT_LIVEREWIND_INPLAY_NO_NETWORK: "30011",
        BUFFERING_TIMEOUT_LIVEREWIND_START: "30012",
        BUFFERING_TIMEOUT_LIVEREWIND_START_NO_NETWORK: "30013",
        BUFFERING_TIMEOUT_START: "30002",
        BUFFERING_TIMEOUT_START_NO_NETWORK: "30003"
    };

    function a(a) {
        var b = a.errorLocation,
            d = a.hostCallError,
            e = a.videoElementError,
            f = a.videoElementNetworkState;
        a = a.videoElementReadyState;
        var g = e == null ? void 0 : e.code,
            h = d != null && typeof d.message === "string" ? d.message : null;
        h == null && (h = e == null ? void 0 : e.message);
        h == null && g != null && (h = c("getErrorMessageFromMediaErrorCode")(g));
        return {
            createdTimestamp: Date.now(),
            errorDescription: ((e = h) != null ? e : "Empty error") + ("; code: " + ((h = g) != null ? h : "undefined")) + ("; readyState: " + a) + ("; networkState: " + f),
            errorLocation: b,
            errorName: c("getErrorNameFromMediaErrorCode")(g),
            originalError: d
        }
    }

    function b(a, b) {
        return a == null ? {
            createdTimestamp: Date.now(),
            errorDescription: "Empty rejection reason from video play()",
            errorLocation: b,
            errorName: "PlayRejectedError"
        } : {
            createdTimestamp: Date.now(),
            errorCode: typeof a.code === "string" ? a.code : typeof a.code === "number" ? String(a.code) : void 0,
            errorDescription: typeof a.message === "string" ? a.message : String(a),
            errorLocation: b,
            errorName: typeof a.name === "string" ? a.name : "PlayRejectedError"
        }
    }

    function e(a, b, d, e, f) {
        var g, i = function() {
            if (f)
                if (e === "in_play" && c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_LIVEREWIND_INPLAY;
                else if (e === "in_play" && !c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_LIVEREWIND_INPLAY_NO_NETWORK;
            else if (e === "start/unpause" && c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_LIVEREWIND_START;
            else if (e === "start/unpause" && !c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_LIVEREWIND_START_NO_NETWORK;
            else return 0;
            else if (e === "in_play" && c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_INPLAY;
            else if (e === "in_play" && !c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_INPLAY_NO_NETWORK;
            else if (e === "start/unpause" && c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_START;
            else if (e === "start/unpause" && !c("NetworkStatus").isOnline()) return h.BUFFERING_TIMEOUT_START_NO_NETWORK;
            else return 0
        }();
        g = {
            message: String((g = b == null ? void 0 : b.message) != null ? g : ""),
            name: String((g = b == null ? void 0 : b.name) != null ? g : "UnknownError"),
            stack: String((b == null ? void 0 : b.stack) || new Error().stack)
        };
        return {
            createdTimestamp: Date.now(),
            errorCode: String(i),
            errorDescription: g.name + " " + g.message,
            errorLocation: d,
            errorName: a,
            stack: g.stack,
            url: null
        }
    }

    function i(a, b, d, e) {
        var f;
        e === void 0 && (e = null);
        f = {
            message: String((f = b == null ? void 0 : b.message) != null ? f : ""),
            name: String((f = b == null ? void 0 : b.name) != null ? f : "UnknownError"),
            stack: String((b == null ? void 0 : b.stack) || new Error().stack)
        };
        return {
            createdTimestamp: Date.now(),
            errorCode: null,
            errorDescription: f.name + " " + f.message,
            errorLocation: d,
            errorName: a,
            stack: f.stack,
            url: e != null && c("gkx")("1526990") ? e : null
        }
    }

    function f(a, b) {
        if (a instanceof c("oz-player/utils/OzError")) {
            var e = a,
                f = e.getExtra();
            return {
                createdTimestamp: Date.now(),
                errorCode: f.code,
                errorDescription: e.getDescription(),
                errorLocation: b,
                errorName: e.getType(),
                errorType: d("VideoPlayerImplementationErrorNormalization").getVideoPlayerNormalizedErrorTypeFromOzError(e),
                stack: e.stack,
                url: f.url
            }
        } else return i("OZ_JAVASCRIPT_NATIVE", a, b)
    }

    function j(a, b) {
        a = a.message;
        var c = "The video node set its error property to a MediaError",
            d = a.split(": ");
        d.length > 1 && (a = d.shift(), c = d.join(": "));
        return {
            createdTimestamp: Date.now(),
            errorDescription: c,
            errorLocation: b,
            errorName: a,
            errorType: "GenericDecodeError"
        }
    }
    g.createVideoPlayerErrorFromHTMLVideoElementError = a;
    g.createVideoPlayerErrorFromVideoElementPlayPromiseRejectionReason = b;
    g.createVideoPlayerBufferingErrorFromGenericError = e;
    g.createVideoPlayerErrorFromGenericError = i;
    g.createVideoPlayerErrorFromOzImplementationError = f;
    g.createVideoPlayerErrorFromVideoNodeError = j
}), 98);
__d("VideoPlayerImplementationReactVideoElement.react", ["gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.alt,
            d = a.implementationExposedState,
            e = a.seoWebCrawlerVideoTracks,
            f = a.src,
            g = a.videoElementCallbacks,
            i = a.videoElementPreloadDisabled;
        a = a.videoElementRefCallback;
        var j = d.hasPlayEverBeenRequested;
        d = d.isExternalMedia;
        j = d && !j ? null : f;
        f = d && c("gkx")("2449") ? babelHelpers["extends"]({
            crossOrigin: "anonymous"
        }, g) : babelHelpers["extends"]({}, g);
        return h.jsx("video", babelHelpers["extends"]({
            "aria-label": (d = b) != null ? d : void 0,
            className: "xh8yej3 x5yr21d x1lliihq",
            controls: !1,
            muted: !0,
            playsInline: !0,
            preload: i === !0 ? "none" : void 0
        }, f, {
            ref: a,
            src: j,
            children: e
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerImplementationStateMachine", ["VideoPlayerImplementationErrors", "cr:4964", "gkx", "recoverableViolation", "shallowEqual", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = (f = b("cr:4964")) != null ? f : {
        makeUpdatedActiveEmsgBoxes: null,
        makeUpdatedAllEmsgBoxes: null
    };
    var h = b.makeUpdatedActiveEmsgBoxes,
        i = b.makeUpdatedAllEmsgBoxes;

    function j(a) {
        var b = a.bufferingDetected,
            c = a.seeking;
        a = a.waitingForDomPlaying;
        return !b && !c && !a
    }

    function k(a) {
        var b = a.bufferingDetected,
            d = a.prevPlaybackState,
            e = a.seeking;
        a = a.waitingForDomPlaying;
        b = j({
            bufferingDetected: b,
            seeking: e,
            waitingForDomPlaying: a
        });
        e = d;
        switch (d) {
            case "stalling":
                e = b ? "playing" : "stalling";
                break;
            case "ended":
            case "paused":
            case "playing":
                break;
            default:
                d;
                c("recoverableViolation")("unexpected playbackState: " + d, "comet_video_player");
                break
        }
        return e
    }

    function l(a) {
        return a.loopCount > 0 && a.loopCurrent < a.loopCount || a.loopCount === -1
    }

    function m(a, b, e) {
        switch (e.type) {
            case "host_call_pause":
            case "host_call_play":
            case "host_call_set_current_time":
            case "host_call_set_volume":
            case "host_call_set_muted":
            case "host_call_set_playback_rate":
            case "host_call_set_video_quality":
            case "host_call_set_latency_level":
                return babelHelpers["extends"]({}, a, {
                    hostCallQueue: a.hostCallQueue.concat([e])
                });
            case "controller_set_latency_level_requested":
            case "implementation_set_latency_level_requested":
                return babelHelpers["extends"]({}, a, {
                    latencyLevel: e.payload.latencyLevel
                });
            case "controller_override_player_format":
                return babelHelpers["extends"]({}, a, {
                    overriddenPlayerFormat: a.playerFormat,
                    playerFormat: e.payload.playerFormat
                });
            case "controller_set_player_format":
                return babelHelpers["extends"]({}, a, {
                    playerFormat: e.payload.playerFormat
                });
            case "dom_event_ended":
                return babelHelpers["extends"]({}, a, {
                    playbackState: "ended",
                    waitingForDomPlaying: !1
                });
            case "dom_event_pause":
                if (a.playbackState === "ended") return a;
                if (b.videoElementEnded === !0) return babelHelpers["extends"]({}, a, {
                    playbackState: "ended",
                    waitingForDomPlaying: !1
                });
                return a.playbackState === "paused" ? a : babelHelpers["extends"]({}, a, {
                    playbackState: "paused",
                    waitingForDomPlaying: !1
                });
            case "dom_event_play":
                var f = a.playbackState,
                    g = f;
                switch (f) {
                    case "playing":
                    case "stalling":
                    case "ended":
                    case "paused":
                        g = "stalling";
                        break;
                    default:
                        f;
                        c("recoverableViolation")("unexpected playbackState: " + f, "comet_video_player");
                        break
                }
                f = !0;
                return babelHelpers["extends"]({}, a, {
                    playbackState: g,
                    waitingForDomPlaying: f
                });
            case "dom_event_playing":
                g = a.bufferingDetected;
                f = a.seeking;
                var j = !1,
                    m = a.playbackState;
                return babelHelpers["extends"]({}, a, {
                    playbackState: k({
                        bufferingDetected: g,
                        prevPlaybackState: m,
                        seeking: f,
                        waitingForDomPlaying: j
                    }),
                    waitingForDomPlaying: j
                });
            case "dom_event_timeupdate":
                g = h ? h(a.allEmsgBoxes, b.videoElementPlayheadPosition, a.activeEmsgBoxes) : a.activeEmsgBoxes;
                if (a.waitingForDomTimeUpdateAfterSeeked) {
                    m = a.bufferingDetected;
                    f = a.seeking;
                    j = !1;
                    var n = a.playbackState;
                    return babelHelpers["extends"]({}, a, {
                        activeEmsgBoxes: g,
                        playbackState: k({
                            bufferingDetected: m,
                            prevPlaybackState: n,
                            seeking: f,
                            waitingForDomPlaying: j
                        }),
                        waitingForDomPlaying: j,
                        waitingForDomTimeUpdateAfterSeeked: !1
                    })
                }
                return babelHelpers["extends"]({}, a, {
                    activeEmsgBoxes: g
                });
            case "dom_event_seeking":
                m = a.playbackState;
                n = m;
                switch (m) {
                    case "paused":
                    case "ended":
                        break;
                    case "stalling":
                    case "playing":
                        n = "stalling";
                        break;
                    default:
                        m, c("recoverableViolation")("unexpected playbackState: " + m, "comet_video_player")
                }
                return babelHelpers["extends"]({}, a, {
                    playbackState: n,
                    seeking: !0,
                    waitingForDomPlaying: !0
                });
            case "dom_event_seeked":
                f = a.bufferingDetected;
                j = a.waitingForDomPlaying;
                g = !1;
                m = a.playbackState;
                return babelHelpers["extends"]({}, a, {
                    implementationSeekSourcePosition: null,
                    playbackState: k({
                        bufferingDetected: f,
                        prevPlaybackState: m,
                        seeking: g,
                        waitingForDomPlaying: j
                    }),
                    seeking: g,
                    waitingForDomTimeUpdateAfterSeeked: !0
                });
            case "dom_event_error":
                n = d("VideoPlayerImplementationErrors").createVideoPlayerErrorFromHTMLVideoElementError({
                    errorLocation: "dom_event_error",
                    hostCallError: null,
                    videoElementError: e.payload.videoElementError,
                    videoElementNetworkState: e.payload.videoElementNetworkState,
                    videoElementReadyState: e.payload.videoElementReadyState
                });
                return babelHelpers["extends"]({}, a, {
                    error: c("gkx")("2011") ? a.error : n,
                    playbackState: "paused",
                    waitingForDomPlaying: !1
                });
            case "dom_event_play_promise_created":
                return babelHelpers["extends"]({}, a, {
                    hostCallPlayIDLast: e.payload.hostCallPlayID
                });
            case "dom_event_play_promise_resolved":
                return a.hostCallPlayIDLast !== e.payload.hostCallPlayID ? a : babelHelpers["extends"]({}, a, {
                    hostCallPlayIDLast: null
                });
            case "dom_event_play_promise_rejected":
                return a.hostCallPlayIDLast !== e.payload.hostCallPlayID ? a : babelHelpers["extends"]({}, a, {
                    hostCallPlayIDLast: null,
                    playbackState: a.playbackState === "stalling" ? "paused" : a.playbackState,
                    waitingForDomPlaying: !1
                });
            case "implementation_host_call_queue_flushed":
                return babelHelpers["extends"]({}, a, {
                    hostCallQueue: []
                });
            case "implementation_host_call_failed":
                f = d("VideoPlayerImplementationErrors").createVideoPlayerErrorFromHTMLVideoElementError({
                    errorLocation: e.payload.errorLocation,
                    hostCallError: e.payload.hostCallError,
                    videoElementError: e.payload.videoElementError,
                    videoElementNetworkState: e.payload.videoElementNetworkState,
                    videoElementReadyState: e.payload.videoElementReadyState
                });
                return babelHelpers["extends"]({}, a, {
                    error: f,
                    playbackState: "paused",
                    waitingForDomPlaying: !1
                });
            case "implementation_video_node_unmounted":
                return a;
            case "implementation_engine_initialized":
                j = (m = e.payload.streamingFormat) != null ? m : a.streamingFormat;
                return babelHelpers["extends"]({}, a, {
                    availableQualities: e.payload.availableQualities,
                    selectedVideoQuality: e.payload.selectedVideoQuality,
                    streamingFormat: j,
                    targetVideoQuality: e.payload.targetVideoQuality,
                    videoProjection: e.payload.videoProjection
                });
            case "implementation_engine_representation_blocked":
                return babelHelpers["extends"]({}, a, {
                    availableQualities: e.payload.availableQualities
                });
            case "implementation_engine_destroyed":
                return a;
            case "implementation_fatal_error":
                return babelHelpers["extends"]({}, a, {
                    error: e.payload.fatalError,
                    playbackState: "paused",
                    waitingForDomPlaying: !1
                });
            case "implementation_seek_requested":
                return babelHelpers["extends"]({}, a, {
                    implementationSeekSourcePosition: e.payload.seekSourcePosition
                });
            case "representation_changed":
                return babelHelpers["extends"]({}, a, {
                    targetVideoQuality: e.payload.targetVideoQuality
                });
            case "controller_pause_requested":
                return a.playbackState === "ended" ? a : babelHelpers["extends"]({}, a, {
                    lastPausedTimeMs: Date.now(),
                    lastPauseReason: e.payload.reason,
                    lastPlayedTimeMs: 0,
                    playbackState: "paused",
                    waitingForDomPlaying: !1,
                    watchTimeMs: a.lastPlayedTimeMs > 0 ? a.watchTimeMs + (Date.now() - a.lastPlayedTimeMs) : a.watchTimeMs
                });
            case "controller_play_requested":
                return a.playbackState !== "paused" && a.playbackState !== "ended" ? a : babelHelpers["extends"]({}, a, {
                    hasPlayEverBeenRequested: !0,
                    lastPlayedTimeMs: a.lastPlayedTimeMs === 0 ? Date.now() : a.lastPlayedTimeMs,
                    lastPlayReason: e.payload.reason,
                    loopCurrent: l(a) ? e.payload.reason === "loop_initiated" ? a.loopCurrent + 1 : a.loopCurrent : 0,
                    playbackState: "stalling",
                    waitingForDomPlaying: !0
                });
            case "controller_seek_requested":
                return babelHelpers["extends"]({}, a, {
                    implementationSeekSourcePosition: (g = b.videoElementPlayheadPosition) != null ? g : a.implementationSeekSourcePosition,
                    seeking: !0,
                    seekTargetPosition: e.payload.seekTargetPosition
                });
            case "controller_quality_requested":
                return babelHelpers["extends"]({}, a, {
                    selectedVideoQuality: e.payload.selectedVideoQuality
                });
            case "controller_set_caption_display_style_requested":
                return babelHelpers["extends"]({}, a, {
                    captionDisplayStyle: e.payload.captionDisplayStyle
                });
            case "controller_set_picture_in_picture_state_requested":
                return babelHelpers["extends"]({}, a, {
                    isDesktopPictureInPicture: e.payload.isInPictureInPictureMode
                });
            case "controller_set_caption_format_requested":
                return babelHelpers["extends"]({}, a, {
                    captionFormat: e.payload.captionFormat
                });
            case "controller_set_playback_rate":
                return babelHelpers["extends"]({}, a, {
                    targetPlaybackRate: e.payload.playbackRate
                });
            case "controller_muted_requested":
                return babelHelpers["extends"]({}, a, {
                    lastMuteReason: e.payload.reason,
                    muted: e.payload.muted
                });
            case "controller_volume_requested":
                return babelHelpers["extends"]({}, a, {
                    volume: e.payload.volume
                });
            case "controller_scrub_begin_requested":
                return a.scrubbing ? a : babelHelpers["extends"]({}, a, {
                    scrubbing: !0,
                    seekTargetPosition: null
                });
            case "controller_scrub_end_requested":
                return !a.scrubbing ? a : babelHelpers["extends"]({}, a, {
                    implementationSeekSourcePosition: (n = b.videoElementPlayheadPosition) != null ? n : a.implementationSeekSourcePosition,
                    scrubbing: !1,
                    seeking: e.payload.seekTargetPosition != null,
                    seekTargetPosition: e.payload.seekTargetPosition
                });
            case "buffering_begin_requested":
                f = a.playbackState;
                m = f;
                switch (f) {
                    case "paused":
                    case "ended":
                        break;
                    case "playing":
                    case "stalling":
                        m = "stalling";
                        break;
                    default:
                        f;
                        c("recoverableViolation")("unexpected playbackState: " + f, "comet_video_player");
                        break
                }
                j = e.payload.bufferingType;
                return babelHelpers["extends"]({}, a, {
                    bufferingDetected: !0,
                    lastBufferingType: j,
                    playbackState: m
                });
            case "buffering_end_requested":
                g = a.seeking;
                n = a.waitingForDomPlaying;
                f = !1;
                j = a.playbackState;
                return babelHelpers["extends"]({}, a, {
                    bufferingDetected: f,
                    playbackState: k({
                        bufferingDetected: f,
                        prevPlaybackState: j,
                        seeking: g,
                        waitingForDomPlaying: n
                    })
                });
            case "controller_set_captions_visible_requested":
                m = e.payload.captionsVisible;
                return a.captionsVisible === m ? a : babelHelpers["extends"]({}, a, {
                    activeCaptions: m ? a.activeCaptions : null,
                    captionsLocale: m ? a.captionsLocale : null,
                    captionsVisible: m
                });
            case "controller_set_active_captions_requested":
                f = e.payload.activeCaptions;
                g = (j = f == null ? void 0 : f.rows) != null ? j : [];
                n = e.payload.captionsLocale;
                m = a.activeCaptions;
                var o = (j = m == null ? void 0 : m.rows) != null ? j : [];
                return o.length === g.length && g.every(function(a, b) {
                    return o[b] === a
                }) ? a : babelHelpers["extends"]({}, a, {
                    activeCaptions: f,
                    captionsLocale: n
                });
            case "captions_loaded":
                return babelHelpers["extends"]({}, a, {
                    activeCaptions: a.activeCaptions,
                    captionsLoaded: !0
                });
            case "captions_unloaded":
                return babelHelpers["extends"]({}, a, {
                    activeCaptions: null,
                    captionsLoaded: !1,
                    captionsLocale: null
                });
            case "inband_captions_autogenerated_changed":
                m = e.payload.inbandCaptionsAutogenerated;
                return a.inbandCaptionsAutogenerated === m ? a : babelHelpers["extends"]({}, a, {
                    inbandCaptionsAutogenerated: m
                });
            case "stream_ended":
                return babelHelpers["extends"]({}, a, {
                    streamEnded: !0
                });
            case "stream_gone_before_start":
                return babelHelpers["extends"]({}, a, {
                    playbackState: "ended",
                    streamEnded: !0,
                    waitingForDomPlaying: !1
                });
            case "stream_interrupted":
                return babelHelpers["extends"]({}, a, {
                    streamInterrupted: !0
                });
            case "stream_resumed":
                return babelHelpers["extends"]({}, a, {
                    streamInterrupted: !1
                });
            case "seekable_ranges_changed":
                j = e.payload.seekableRanges;
                return babelHelpers["extends"]({}, a, {
                    seekableRanges: j
                });
            case "controller_set_is_live_rewind_active_requested":
                g = e.payload.isLiveRewindActive;
                return babelHelpers["extends"]({}, a, {
                    isLiveRewindActive: g
                });
            case "loop_count_change_requested":
                f = e.payload.loopCount;
                return f === a.loopCount ? a : babelHelpers["extends"]({}, a, {
                    loopCount: f,
                    loopCurrent: 0
                });
            case "player_dimensions_changed":
                n = e.payload.dimensions;
                m = n.height;
                j = n.width;
                return j === a.dimensions.width && m === a.dimensions.height ? a : babelHelpers["extends"]({}, a, {
                    dimensions: {
                        height: m,
                        width: j
                    }
                });
            case "emsg_boxes_parsed":
                g = i ? i(a.allEmsgBoxes, e.payload.emsgBoxes) : a.allEmsgBoxes;
                f = h ? h(g, b.videoElementPlayheadPosition, a.activeEmsgBoxes) : a.activeEmsgBoxes;
                return babelHelpers["extends"]({}, a, {
                    activeEmsgBoxes: f,
                    allEmsgBoxes: g
                });
            case "register_emsg_observer":
                n = new Set(a.emsgObserverTokens);
                n.add(e.payload.token);
                return babelHelpers["extends"]({}, a, {
                    emsgObserverTokens: n
                });
            case "unregister_emsg_observer":
                m = new Set(a.emsgObserverTokens);
                m["delete"](e.payload.token);
                return babelHelpers["extends"]({}, a, {
                    emsgObserverTokens: m
                });
            default:
                return a
        }
    }

    function n(a, b, d) {
        var e = b.type !== "dom_seeking";
        e = e ? d : a.uncontrolledState;
        d = !c("shallowEqual")(e, a.uncontrolledState);
        b = m(a.controlledState, e, b);
        var f = !c("shallowEqual")(b, a.controlledState);
        return d || f ? babelHelpers["extends"]({}, a, {
            controlledState: f ? b : a.controlledState,
            uncontrolledState: d ? e : a.uncontrolledState
        }) : a
    }
    var o, p;

    function q(a) {
        var b = a.collectUncontrolledState,
            d = a.debugLogId;
        d = a.initialState;
        var e = a.onDispatched,
            f = a.onFatalError,
            g = d,
            h = g,
            i = 0,
            j = !1,
            k = !1,
            l = !0,
            m = !0;
        return {
            dispatch: function(a) {
                if (!m) return;
                var d = null,
                    g = null;
                try {
                    ++i;
                    if (i >= 10)
                        if (!j) {
                            j = !0;
                            throw c("unrecoverableViolation")("Video player state machine loop detected", "comet_video_player")
                        } else return;
                    var o = h.uncontrolledState;
                    if (l) try {
                        o = b()
                    } catch (a) {
                        l = !1, g = a
                    }
                    var p = h;
                    o = n(p, a, o);
                    h = o;
                    e(p, o, a)
                } catch (a) {
                    m = !1, d = a
                } finally {
                    if (!k && (d != null || g != null)) {
                        k = !0;
                        try {
                            f((p = d) != null ? p : g)
                        } catch (a) {}
                    }--i
                }
            },
            getCurrentState: function() {
                return h
            },
            getInitialState: function() {
                return g
            }
        }
    }
    var r, s;

    function a(a) {
        var b = a.collectUncontrolledState,
            c = a.debugLogId,
            d = a.initialState,
            e = a.onFatalError,
            f = a.stateTransitionHandlers;

        function g(a, b, c) {
            try {
                var d = !0,
                    e = 0;
                while (d && e < f.length) {
                    var g = f[e];
                    d = g(a, b, c);
                    ++e
                }
            } finally {}
        }
        return q({
            collectUncontrolledState: b,
            debugLogId: c,
            initialState: d,
            onDispatched: g,
            onFatalError: e
        })
    }

    function e(a, b) {
        function c() {}

        function d(a) {
            return a
        }

        function e(c) {
            return function(e) {
                var f = d(e.currentTarget);
                b(f, ["reactEvent(" + e.type + ")"]);
                a.dispatch(c)
            }
        }

        function f(c) {
            return function(e) {
                var f = d(e.currentTarget);
                b(f, ["reactEvent(" + e.type + ")"]);
                a.dispatch(c(e, f))
            }
        }
        return {
            onAbort: c,
            onCanPlay: c,
            onCanPlayThrough: c,
            onDurationChange: e({
                type: "dom_event_durationchange"
            }),
            onEmptied: c,
            onEncrypted: c,
            onEnded: e({
                type: "dom_event_ended"
            }),
            onError: f(function(a, b) {
                return {
                    payload: {
                        videoElementError: b.error,
                        videoElementNetworkState: b.networkState,
                        videoElementReadyState: b.readyState
                    },
                    type: "dom_event_error"
                }
            }),
            onLoadedData: c,
            onLoadedMetadata: c,
            onLoadStart: c,
            onPause: e({
                type: "dom_event_pause"
            }),
            onPlay: e({
                type: "dom_event_play"
            }),
            onPlaying: f(function(a) {
                return {
                    payload: {
                        domEventPerfTimestamp: a.timeStamp
                    },
                    type: "dom_event_playing"
                }
            }),
            onProgress: e({
                type: "dom_event_progress"
            }),
            onRateChange: e({
                type: "dom_event_ratechange"
            }),
            onSeeked: e({
                type: "dom_event_seeked"
            }),
            onSeeking: e({
                type: "dom_event_seeking"
            }),
            onStalled: c,
            onSuspend: c,
            onTimeUpdate: e({
                type: "dom_event_timeupdate"
            }),
            onVolumeChange: e({
                type: "dom_event_volumechange"
            }),
            onWaiting: e({
                type: "dom_event_waiting"
            })
        }
    }
    g.createVideoPlayerImplementationStateMachine = q;
    g.createVideoPlayerImplementationStateMachineWithStateTransitionHandlers = a;
    g.createReactVideoElementCallbacksForStateMachine = e
}), 98);
__d("VideoPlayerImplementationStateMachineHostCallQueue", ["cometUniqueID", "emptyFunction", "gkx", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = c("emptyFunction");

    function h() {
        return "id-vpdom-" + c("cometUniqueID")()
    }

    function i(a) {
        var b = a.engineExtrasAPI,
            d = a.hostCall,
            e = a.machine;
        a = a.videoElementAPI;
        switch (d.type) {
            case "host_call_play":
                var f = a.play();
                f && (e.dispatch({
                    payload: {
                        hostCallPlayID: d.payload.hostCallID
                    },
                    type: "dom_event_play_promise_created"
                }), c("promiseDone")(f.then(function() {
                    e.dispatch({
                        payload: {
                            hostCallPlayID: d.payload.hostCallID
                        },
                        type: "dom_event_play_promise_resolved"
                    })
                }, function(a) {
                    e.dispatch({
                        payload: {
                            hostCallPlayID: d.payload.hostCallID,
                            playPromiseRejectionReason: a
                        },
                        type: "dom_event_play_promise_rejected"
                    })
                })));
                break;
            case "host_call_pause":
                a.pause();
                break;
            case "host_call_set_playback_rate":
                a.setPlaybackRate(d.payload.playbackRate);
                break;
            case "host_call_set_muted":
                a.setMuted(d.payload.muted);
                break;
            case "host_call_set_volume":
                a.setVolume(d.payload.volume);
                break;
            case "host_call_set_current_time":
                a.setPlayheadPosition(d.payload.currentTime);
                break;
            case "host_call_set_video_quality":
                b.setUserSelectedVideoQuality(d.payload.selectedVideoQuality);
                break;
            case "host_call_set_latency_level":
                b.setLatencyLevel(d.payload.latencyLevel);
                break;
            case "host_call_picture_in_picture":
                a.requestPictureInPicture();
                break;
            case "host_call_exit_picture_in_picture":
                a.exitPictureInPicture();
                break;
            default:
                d.type;
                return !1
        }
        return !0
    }

    function j(a) {
        var b = a.engineExtrasAPI,
            c = a.hostCall,
            d = a.machine;
        a = a.videoElementAPI;
        if (!a || !b) d.dispatch(c);
        else {
            var e = !1;
            try {
                e = i({
                    engineExtrasAPI: b,
                    hostCall: c,
                    machine: d,
                    videoElementAPI: a
                })
            } catch (b) {
                d.dispatch({
                    payload: {
                        errorLocation: "apply_host_call_catch",
                        hostCall: c,
                        hostCallError: b,
                        videoElementError: a.getError(),
                        videoElementNetworkState: a.getNetworkState(),
                        videoElementReadyState: a.getReadyState()
                    },
                    type: "implementation_host_call_failed"
                })
            }
            e && d.dispatch({
                payload: {
                    hostCall: c
                },
                type: "implementation_host_call_applied"
            })
        }
    }

    function k(a) {
        var b = [];

        function c() {
            b = b.filter(function(a) {
                return a.type !== "host_call_play" && a.type !== "host_call_pause"
            })
        }

        function d(a) {
            b = b.filter(function(b) {
                return b.type !== a
            })
        }
        a.forEach(function(a) {
            switch (a.type) {
                case "host_call_play":
                    c();
                    break;
                case "host_call_pause":
                    c();
                    break;
                case "host_call_set_playback_rate":
                    d(a.type);
                    break;
                case "host_call_set_muted":
                    d(a.type);
                    break;
                case "host_call_set_volume":
                    d(a.type);
                    break;
                case "host_call_set_current_time":
                    d(a.type);
                    break;
                case "host_call_set_video_quality":
                    d(a.type);
                    break;
                case "host_call_set_latency_level":
                    d(a.type);
                    break;
                case "host_call_picture_in_picture":
                    d(a.type);
                    break;
                case "host_call_exit_picture_in_picture":
                    d(a.type);
                    break;
                default:
                    a.type
            }
            b = b.concat([a])
        });
        return b
    }

    function a(a) {
        var b = a.engineExtrasAPI,
            c = a.machine,
            d = a.reason,
            e = a.state,
            f = a.videoElementAPI;
        a = [{
            payload: {
                hostCallID: h(),
                reason: d,
                volume: e.controlledState.volume
            },
            type: "host_call_set_volume"
        }, {
            payload: {
                hostCallID: h(),
                muted: e.controlledState.muted,
                reason: d
            },
            type: "host_call_set_muted"
        }, {
            payload: {
                hostCallID: h(),
                reason: d,
                selectedVideoQuality: e.controlledState.selectedVideoQuality
            },
            type: "host_call_set_video_quality"
        }];
        d = k(e.controlledState.hostCallQueue.concat(a));
        d.forEach(function(a) {
            j({
                engineExtrasAPI: b,
                hostCall: a,
                machine: c,
                videoElementAPI: f
            })
        });
        c.dispatch({
            payload: {
                hostCallsFlushed: d
            },
            type: "implementation_host_call_queue_flushed"
        })
    }
    g.makeHostCallID = h;
    g.applyOrQueueHostCall = j;
    g.flushHostCallQueue = a
}), 98);
__d("VideoPlayerMutedStateChange", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.currMuted,
            c = a.currVolume,
            d = a.prevMuted;
        a = a.prevVolume;
        b = b || c === 0;
        c = d || a === 0;
        if (c === b) return null;
        return b ? "muted" : "unmuted"
    }
    f.getVideoPlayerMutedStateChange = a
}), 66);
__d("VideoPlayerImplementationStateMachineLogger", ["CometProductAttribution", "NetworkStatus", "PlaybackSpeedExperiments", "SiteData", "VideoMimeTypes", "VideoPlayerConnectionQuality", "VideoPlayerImplementationErrorNormalization", "VideoPlayerLoggerPlayerStates", "VideoPlayerMutedStateChange", "VideoPlayerStateBasedLoggingEvents", "emptyFunction", "getPlayerFormatForLogData", "getVideoBrowserTabId", "gkx", "mapObject", "performanceAbsoluteNow", "qex", "recoverableViolation", "removeFromArray"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6e4,
        i = .5,
        j = (b = c("qex")._("1675")) != null ? b : 0,
        k = c("gkx")("3954") ? 1e3 : Number.POSITIVE_INFINITY,
        l = null,
        m = function(a) {
            var b;
            l = (b = l) != null ? b : document.createElement("video");
            return !("canPlayType" in l) ? "" : l.canPlayType(a)
        };
    e = c("emptyFunction");
    f = c("emptyFunction");
    b = c("emptyFunction");
    e = c("emptyFunction");
    var n = (f = d("PlaybackSpeedExperiments").enablePlaybackSpeedLogging()) != null ? f : !1;

    function o() {
        return {
            canLogPausedOrFinishedPlaying: !1,
            canLogPlayingEvent: !0,
            debugSubscribers: [],
            dontLogPauseOnUnpausedSeeking: !1,
            errorRecoveryAttemptState: {
                currentRecoverableError: null,
                eventsLogged: 0,
                repeatCount: 0
            },
            hasLoggedStallData: !1,
            hasLoggedStartedPlaying: !1,
            hasPausedOnce: !1,
            hasPendingRequestedPlaying: !1,
            initialSuborigin: void 0,
            interruptCount: 0,
            interruptDuration: 0,
            interruptEndTimestamp: 0,
            interruptStartTimestamp: 0,
            isLoggingScrubbingSequence: !1,
            lastLoggedError: null,
            lastLoggedFullscreenState: !1,
            lastLoggedPlaybackSpeed: null,
            lastLoggedViewabilityPercentage: void 0,
            lastStartTimePosition: null,
            lastTrackedRepresentation: null,
            nextHeartbeatTime: null,
            nextPlayedThreeSecondsPlayheadPosition: null,
            sequenceNumber: 0,
            shouldIgnoreDomPause: !1,
            shouldIgnoreDomPlay: !1,
            shouldLogRequestedPlayingForScrub: !1,
            stallCount: 0,
            stallCount200ms: 0,
            stallCountTotal: 0,
            stallDuration: 0,
            stallDurationTotal: 0,
            stallStartTimestamp: 0,
            startStallCountTotal: 0,
            startStallDurationTotal: 0,
            vplEventSequenceNumber: 0
        }
    }

    function p(a, b) {
        return b === "muted" || b === "unmuted" || b === "started_playing" || b === "caption_change" || b === "unpaused" ? a.controlledState.captionsVisible ? "on" : "off" : void 0
    }

    function a(a) {
        var b = new Map(),
            e = a.initialLoggingMetaData,
            f = e,
            g = [],
            l = o(),
            q = new Set(c("VideoPlayerStateBasedLoggingEvents").StateBasedLoggingEventNames);

        function r(a) {
            l.debugSubscribers.push(a);
            return function() {
                c("removeFromArray")(l.debugSubscribers, a)
            }
        }

        function s(a) {
            l.debugSubscribers.forEach(function(b) {
                return b(a)
            })
        }

        function t(a) {
            var b = l.stallStartTimestamp;
            if (b > 0) {
                l.stallCount += 1;
                l.stallCountTotal += 1;
                l.hasPendingRequestedPlaying && (l.startStallCountTotal += 1);
                a = a - b;
                l.stallDurationTotal += a;
                l.stallDuration += a;
                l.stallCount200ms += a > 200 ? 1 : 0;
                l.hasPendingRequestedPlaying && (l.startStallDurationTotal += a)
            }
        }

        function u(a, b) {
            a = a.uncontrolledState.videoElementPlayheadPosition == null ? null : a.uncontrolledState.videoElementPlayheadPosition;
            var c = null;
            switch (b) {
                case "paused":
                case "cancelled_requested_playing":
                case "finished_playing":
                case "heart_beat":
                case "playback_speed_changed":
                case "representation_ended":
                    c = l.lastStartTimePosition;
                    break;
                case "scrubbed":
                    c = a;
                    break;
                default:
                    break
            }
            switch (b) {
                case "paused":
                case "cancelled_requested_playing":
                case "finished_playing":
                case "scrubbed":
                    l.lastStartTimePosition = null;
                    break;
                case "started_playing":
                case "unpaused":
                case "heart_beat":
                case "playback_speed_changed":
                case "representation_ended":
                    l.lastStartTimePosition = a;
                    break;
                default:
                    break
            }
            return {
                video_last_start_time_position: c
            }
        }

        function v(a, b) {
            var c = b.uncontrolledState.clockTimestamp;
            a = a.controlledState.streamInterrupted;
            b = b.controlledState.streamInterrupted;
            !a && b ? l.interruptStartTimestamp = c : a && !b && l.interruptStartTimestamp > 0 && (l.interruptEndTimestamp = c, l.interruptCount += 1, l.interruptDuration += l.interruptEndTimestamp - l.interruptStartTimestamp)
        }

        function w(a, b, d) {
            var e = b.uncontrolledState.clockTimestamp;
            a = a.controlledState.playbackState;
            var f = b.controlledState.playbackState;
            a !== "stalling" && f === "stalling" && (s("stall_start"), l.stallStartTimestamp = e);
            if (a === "stalling" && f !== "stalling") {
                e = 0;
                c("gkx")("3881") && (d.type === "dom_event_playing" || d.type === "buffering_end_requested") && d.payload.domEventPerfTimestamp != null && (e = Math.max(b.uncontrolledState.perfTimestamp - d.payload.domEventPerfTimestamp, 0));
                t(b.uncontrolledState.clockTimestamp - e);
                l.stallStartTimestamp = 0;
                s("stall_end")
            }
        }

        function x(a, b, c) {
            a = b.uncontrolledState;
            b = a.videoElementPlayheadPosition;
            switch (c) {
                case "unpaused":
                case "started_playing":
                    l.nextPlayedThreeSecondsPlayheadPosition = ((a = b) != null ? a : 0) + 3;
                    break;
                case "paused":
                case "finished_playing":
                    l.nextPlayedThreeSecondsPlayheadPosition = null;
                    break;
                default:
                    break
            }
        }

        function y(a, b, c) {
            if (l.interruptCount > 0 && l.interruptDuration > 0) {
                a = {
                    interrupt_count: l.interruptCount,
                    interrupt_time: l.interruptDuration
                };
                l.interruptCount = 0;
                l.interruptDuration = 0;
                l.interruptStartTimestamp = 0;
                l.interruptEndTimestamp = 0;
                return a
            }
            return {
                interrupt_count: null,
                interrupt_time: null
            }
        }

        function z(a, b, c) {
            var d = {
                    stall_count: null,
                    stall_count_200_ms: null,
                    stall_time: null
                },
                e = b.uncontrolledState.clockTimestamp,
                f = function() {
                    var a = {
                        stall_count: l.stallCount,
                        stall_count_200_ms: l.stallCount200ms,
                        stall_time: l.stallDuration
                    };
                    l.stallCount = 0;
                    l.stallCount200ms = 0;
                    l.stallDuration = 0;
                    l.stallStartTimestamp = 0;
                    return a
                };
            a = a.controlledState.playbackState;
            var g = b.controlledState.playbackState;
            a !== "stalling" && g === "stalling" && (l.stallStartTimestamp = e);
            switch (c) {
                case "started_playing":
                case "unpaused":
                case "finished_playing":
                case "paused":
                case "cancelled_requested_playing":
                case "playback_speed_changed":
                case "representation_ended":
                    t(b.uncontrolledState.clockTimestamp);
                    d = f();
                    break;
                case "heart_beat":
                    b.controlledState.playbackState !== "stalling" && (t(b.uncontrolledState.clockTimestamp), d = f());
                    break;
                default:
                    break
            }
            return d
        }

        function A(a, b, d) {
            a = b.controlledState.playbackState === "paused" && a.controlledState.playbackState === "stalling";
            return c("gkx")("2914") ? d > 0 && (b.controlledState.playbackState === "stalling" || a) : b.controlledState.playbackState === "stalling"
        }

        function B(a, b) {
            a = a.current;
            var c = null;
            switch (b) {
                case "finished_playing":
                case "paused":
                case "heart_beat":
                    a && (c = a.getAndFlushTracedFrames());
                    return c != null ? JSON.stringify(c) : null;
                default:
                    return null
            }
        }

        function C(a) {
            a = a.controlledState.playbackState;
            switch (a) {
                case "playing":
                case "stalling":
                    return "playing";
                case "paused":
                    return "paused";
                case "ended":
                    return "finished";
                default:
                    a;
                    return "unknown"
            }
        }

        function D(a) {
            switch (a) {
                case "normal":
                    return "normal";
                case "low":
                    return "low";
                case "ultra-low":
                    return "ultra_low";
                default:
                    return null
            }
        }

        function E() {
            return {
                state: l.hasLoggedStartedPlaying ? c("VideoPlayerLoggerPlayerStates").UNPAUSED : c("VideoPlayerLoggerPlayerStates").STARTED
            }
        }

        function F(a) {
            if (c("gkx")("2714") && (a == null ? void 0 : a.v2) && (a == null ? void 0 : a.v2.length) > 0) {
                var b = a == null ? void 0 : a.v2;
                b = b[b.length - 1];
                return [b["class"], b.module].map(d("CometProductAttribution").filterEntryValue).join(":")
            }
            return (a = a == null ? void 0 : (b = a.v2) == null ? void 0 : b.map(function(a) {
                return [a["class"], a.module].map(d("CometProductAttribution").filterEntryValue).join(":")
            }).join(";")) != null ? a : ""
        }

        function G(f) {
            var h, i = f.eventType,
                j = f.logDataOverrides,
                k = f.prevState,
                m = f.state;
            f = u(m, i);
            f = f.video_last_start_time_position;
            var o = z(k, m, i),
                r = o.stall_count,
                s = o.stall_count_200_ms;
            o = o.stall_time;
            var t = y(k, m, i),
                v = t.interrupt_count;
            t = t.interrupt_time;
            var w = B(a.videoLiveTraceRef, i),
                E = [],
                G = a.initialLoggingMetaData.coreVideoPlayerMetaData.autoplayGatingResult;
            G && E.push(G);
            G = i === "entered_fs" ? !0 : i === "exited_fs" ? !1 : l.lastLoggedFullscreenState;
            h = c("getPlayerFormatForLogData")({
                isDesktopPictureInPicture: (h = m.controlledState.isDesktopPictureInPicture) != null ? h : !1,
                isFullscreen: G
            }, e.coreVideoPlayerMetaData.playerFormat);
            var H = m.uncontrolledState.viewabilityPercentage,
                I = Boolean(m.uncontrolledState.isFBIsLiveTemplated),
                J = Boolean(m.uncontrolledState.isFBWasLive),
                K = m.uncontrolledState.videoElementPlaybackRate;
            K = K == null || K === 0 ? l.lastLoggedPlaybackSpeed : K;
            var L = a.initialLoggingMetaData.productAttribution;
            if (h === "watch_scroll" && L && L.v2) {
                var M, N = {
                    0: babelHelpers["extends"]({}, L["0"]),
                    v2: [babelHelpers["extends"]({}, L.v2[0])]
                };
                M = (M = e.productAttribution) == null ? void 0 : (M = M.v2) == null ? void 0 : M[0];
                if (M) {
                    var O = N.v2[0];
                    O["class"] = M["class"];
                    O.scope_id = M.scope_id;
                    O.ts = M.ts
                }
                L = N
            }
            O = null;
            M = null;
            c("gkx")("3013") && (O = L != null ? d("CometProductAttribution").minifyProductAttributionV2(L) : null, M = L != null ? F(L) : null);
            N = A(k, m, (N = o) != null ? N : 0);
            M = {
                access_token: a.initialLoggingMetaData.accessToken,
                ad_client_token: e.coreVideoPlayerMetaData.adClientToken,
                attribution_id: L != null && Object.prototype.hasOwnProperty.call(L, "0") ? JSON.stringify({
                    0: L["0"]
                }) : null,
                attribution_id_v2: O,
                attribution_id_v2_root: M,
                audio_only: e.coreVideoPlayerMetaData.audioOnly,
                audio_representation_id: m.uncontrolledState.audioRepresentationID,
                autoplay_eligible: a.initialLoggingMetaData.coreVideoPlayerMetaData.canAutoplay === "allow",
                autoplay_failure_reasons: JSON.stringify(E),
                autoplay_setting: a.initialLoggingMetaData.coreVideoPlayerMetaData.autoplaySetting,
                available_qualities: m.controlledState.availableQualities.length,
                broadcaster_origin: a.initialLoggingMetaData.coreVideoPlayerMetaData.broadcasterOrigin,
                browser_tab_id: c("getVideoBrowserTabId")(),
                caption_state: p(m, i),
                client_latency_setting: D(m.controlledState.latencyLevel),
                current_playback_speed: n ? K : null,
                current_viewability_percentage: H,
                dash_perf_logging_enabled: e.coreVideoPlayerMetaData.VideoPlayerShakaPerformanceLoggerClass != null && e.coreVideoPlayerMetaData.VideoPlayerShakaPerformanceLoggerClass.isEnabled(),
                data_connection_quality: d("VideoPlayerConnectionQuality").evaluate(function() {
                    return m.uncontrolledState.estimatedBandwidth
                }),
                dropped_frame_count: m.uncontrolledState.videoElementDroppedFrameCount,
                external_log_id: e.coreVideoPlayerMetaData.externalLogID,
                external_log_type: e.coreVideoPlayerMetaData.externalLogType,
                fb_manifest_identifier: m.uncontrolledState.manifestIdentifier,
                frame_events: w,
                interrupt_count: v,
                interrupt_time: t,
                is_abr_enabled: m.isAbrEnabled,
                is_fbms: m.uncontrolledState.isFBMS,
                is_live_video_rewound: m.controlledState.isLiveRewindActive,
                is_pip: m.controlledState.isDesktopPictureInPicture,
                is_predictive_playback: m.uncontrolledState.isPredictiveDash,
                is_sound_on: !m.controlledState.muted,
                is_stalling: N,
                is_templated_manifest: I || J,
                last_viewability_percentage: l.lastLoggedViewabilityPercentage,
                mpd_validation_errors: m.uncontrolledState.mpdValidationErrors,
                network_connected: m.uncontrolledState.networkConnected,
                playback_caption_format: m.controlledState.captionFormat,
                playback_caption_locale: m.controlledState.captionsLocale,
                playback_duration: m.uncontrolledState.videoElementDuration,
                playback_is_broadcast: a.initialLoggingMetaData.coreVideoPlayerMetaData.isVideoBroadcast,
                playback_is_drm: Boolean(a.initialLoggingMetaData.coreVideoPlayerMetaData.graphQLVideoDRMInfo),
                playback_is_live_streaming: a.initialLoggingMetaData.coreVideoPlayerMetaData.isLiveStreaming,
                player_format: h,
                player_instance_key: e.instanceKey,
                player_origin: e.coreVideoPlayerMetaData.playerOriginOverride,
                player_state: C(m),
                player_suborigin: e.coreVideoPlayerMetaData.subOrigin,
                player_version: m.playerVersion,
                representation_id: m.uncontrolledState.videoRepresentationID,
                source_VPL_LOGGING_HACK: e.coreVideoPlayerMetaData.source_VPL_LOGGING_HACK,
                stall_count: r,
                stall_count_200_ms: s,
                stall_time: o,
                streaming_format: m.controlledState.streamingFormat,
                total_frame_count: m.uncontrolledState.videoElementTotalFrameCount,
                tracking_data_encrypted: a.initialLoggingMetaData.trackingDataEncrypted,
                tracking_nodes: a.initialLoggingMetaData.trackingNodes,
                v2_heart_beat: c("gkx")("1434599") && i === "heart_beat" ? !0 : null,
                video_bandwidth: m.uncontrolledState.estimatedBandwidth,
                video_buffer_end_position: m.uncontrolledState.videoElementLastBufferEndPosition,
                video_id: e.coreVideoPlayerMetaData.videoFBID,
                video_last_start_time_position: f,
                video_play_reason: m.controlledState.lastPlayReason,
                video_player_height: (L = e.dimensions) == null ? void 0 : L.height,
                video_player_width: (O = e.dimensions) == null ? void 0 : O.width,
                video_time_position: m.uncontrolledState.videoElementPlayheadPosition,
                web_client_revision: c("SiteData").client_revision
            };
            E = c("gkx")("1286") && i === "error_recovery_attempt" ? null : q.has(i) ? ++l.sequenceNumber : null;
            v = {
                event_seq_num: ++l.vplEventSequenceNumber,
                seq_num: E,
                time_ms: Date.now(),
                vpts: ((w = c("qex")._("33")) != null ? w : !1) ? c("performanceAbsoluteNow")() : null
            };
            var P = {};
            b.forEach(function(a, b) {
                P[b] = a
            });
            t = e.coreVideoPlayerMetaData.additionalLogData;
            N = babelHelpers["extends"]({}, t, P);
            I = babelHelpers["extends"]({}, N, M, j, v);
            h = (J = l.initialSuborigin) != null ? J : e.coreVideoPlayerMetaData.subOrigin;
            s = (r = I.source_VPL_LOGGING_HACK) != null ? r : h;
            f = (o = e.coreVideoPlayerMetaData.initialTracePolicy) != null ? o : e.coreVideoPlayerMetaData.routeTracePolicy;
            L = {
                eventType: i,
                logData: I,
                routeTracePolicy: f,
                source_VPL_LOGGING_HACK: s
            };
            g.push(L);
            x(k, m, i);
            l.initialSuborigin == null && h != null && (l.initialSuborigin = h);
            l.lastLoggedFullscreenState = G;
            l.lastLoggedPlaybackSpeed = K;
            i === "viewability_changed" && (l.lastLoggedViewabilityPercentage = H)
        }
        var H = {};

        function I(a, b, c) {
            G({
                eventType: "requested_playing",
                logDataOverrides: babelHelpers["extends"]({}, c, E()),
                prevState: a,
                state: b
            });
            l.hasPendingRequestedPlaying = !0;
            l.canLogPausedOrFinishedPlaying = !0;
            return H
        }

        function J(a, b, c) {
            if (!l.canLogPausedOrFinishedPlaying) return H;
            else if (l.hasPendingRequestedPlaying) {
                K(a, b, c);
                l.canLogPausedOrFinishedPlaying = !1;
                l.hasPendingRequestedPlaying = !1;
                return H
            } else {
                G({
                    eventType: "paused",
                    logDataOverrides: c,
                    prevState: a,
                    state: b
                });
                l.canLogPausedOrFinishedPlaying = !1;
                l.hasPendingRequestedPlaying = !1;
                return H
            }
        }

        function K(a, b, c) {
            var d = b.uncontrolledState.liveTraceContext;
            c = babelHelpers["extends"]({}, c, E(), {
                live_trace_source_id: d ? d.sourceId : void 0,
                live_trace_stream_id: d ? d.streamId : void 0,
                live_trace_stream_type: d ? d.streamType : void 0
            });
            G({
                eventType: "cancelled_requested_playing",
                logDataOverrides: c,
                prevState: a,
                state: b
            });
            return H
        }

        function L(a, b, c) {
            if (c.type === "dom_event_play_promise_rejected" && l.hasPendingRequestedPlaying) {
                c = c.payload.playPromiseRejectionReason;
                if (c != null && c.name === "NotAllowedError") {
                    K(a, b, {
                        debug_reason: "not_allowed"
                    });
                    return H
                } else return H
            } else return H
        }

        function M(a, b, c) {
            if ((c.type === "controller_play_requested" || c.type === "dom_event_play" && !l.shouldIgnoreDomPlay) && a.controlledState.playbackState !== b.controlledState.playbackState) {
                c = b.uncontrolledState.liveTraceContext;
                c = c ? {
                    live_trace_source_id: c.sourceId,
                    live_trace_stream_id: c.streamId,
                    live_trace_stream_type: c.streamType
                } : null;
                I(a, b, c);
                return H
            } else return H
        }

        function N(a, b, c) {
            if (a.controlledState.playbackState === "stalling" && b.controlledState.playbackState === "playing" && l.canLogPlayingEvent) {
                c = b.uncontrolledState.liveTraceContext;
                c = c ? {
                    live_trace_source_id: c.sourceId,
                    live_trace_stream_id: c.streamId,
                    live_trace_stream_type: c.streamType
                } : null;
                G({
                    eventType: l.hasLoggedStartedPlaying ? "unpaused" : "started_playing",
                    logDataOverrides: c,
                    prevState: a,
                    state: b
                });
                l.hasLoggedStartedPlaying = !0;
                l.canLogPlayingEvent = !1;
                l.hasPendingRequestedPlaying = !1;
                return H
            } else return H
        }

        function O(a, b, d) {
            var e = b.controlledState.playbackState,
                f = a.controlledState.playbackState;
            if (d.type === "controller_scrub_begin_requested" && !a.controlledState.scrubbing && e !== "paused" && e !== "ended") {
                J(a, b);
                l.isLoggingScrubbingSequence = !0;
                return H
            } else if (!a.controlledState.seeking && b.controlledState.seeking && !l.isLoggingScrubbingSequence && e !== "paused" && e !== "ended" && !l.hasPendingRequestedPlaying) {
                J(a, b);
                l.shouldLogRequestedPlayingForScrub = !0;
                return H
            } else if (d.type === "controller_scrub_end_requested" && a.controlledState.scrubbing && e !== "paused" && e !== "ended") {
                I(a, b, {
                    video_time_position: d.payload.seekTargetPosition
                });
                return H
            } else if (a.controlledState.seeking && !b.controlledState.seeking) {
                d = b.uncontrolledState.videoElementPlayheadPosition;
                var g = a.controlledState.implementationSeekSourcePosition;
                (!c("gkx")("1482680") || g != null && d != null && Math.abs(g - d) > i) && (l.shouldLogRequestedPlayingForScrub && e !== "paused" && e !== "ended" && I(a, b), G({
                    eventType: "scrubbed",
                    prevState: a,
                    state: b
                }), l.isLoggingScrubbingSequence = !1, l.shouldLogRequestedPlayingForScrub = !1, f !== "paused" && f !== "ended" && (l.canLogPlayingEvent = !0));
                return H
            } else return H
        }

        function P(a, b, c) {
            if (a.controlledState.playbackState !== b.controlledState.playbackState && b.controlledState.playbackState === "ended" && l.canLogPausedOrFinishedPlaying) {
                G({
                    eventType: "finished_playing",
                    prevState: a,
                    state: b
                });
                l.canLogPausedOrFinishedPlaying = !1;
                return H
            } else return H
        }

        function Q(a, b, c) {
            if ((c.type === "controller_pause_requested" || c.type === "dom_event_pause" && !l.shouldIgnoreDomPause) && a.controlledState.playbackState !== b.controlledState.playbackState) {
                J(a, b);
                return H
            } else return H
        }

        function R(a, b, d) {
            var e = b.controlledState.playbackState;
            if (e !== "paused" && e !== "ended") {
                c("gkx")("1469813") && d.type === "implementation_video_node_unmounted" ? J(a, a, {
                    debug_reason: "unloaded"
                }) : (d.type === "implementation_unmounted" || d.type === "implementation_engine_destroy_requested") && J(a, b, {
                    debug_reason: "unloaded"
                });
                return H
            } else return H
        }

        function S(a, b, c) {
            if (c.type === "implementation_engine_representation_blocked") {
                c = c.payload.blockedRepresentationID;
                G({
                    eventType: "video_playback_fallback",
                    logDataOverrides: {
                        representation_id: c
                    },
                    prevState: a,
                    state: b
                })
            }
            return H
        }

        function T(a, b, e) {
            e = b.controlledState.muted;
            var f = b.controlledState.volume,
                g = a.controlledState.muted,
                h = a.controlledState.volume;
            e = d("VideoPlayerMutedStateChange").getVideoPlayerMutedStateChange({
                currMuted: e,
                currVolume: f,
                prevMuted: g,
                prevVolume: h
            });
            g = {
                current_volume: Math.round(f * 100)
            };
            switch (e) {
                case "muted":
                    G({
                        eventType: "muted",
                        logDataOverrides: g,
                        prevState: a,
                        state: b
                    });
                    return H;
                case "unmuted":
                    G({
                        eventType: "unmuted",
                        logDataOverrides: g,
                        prevState: a,
                        state: b
                    });
                    return H;
                case null:
                    if (h < f) {
                        G({
                            eventType: "volume_increase",
                            logDataOverrides: g,
                            prevState: a,
                            state: b
                        });
                        return H
                    } else if (h > f) {
                        G({
                            eventType: "volume_decrease",
                            logDataOverrides: g,
                            prevState: a,
                            state: b
                        });
                        return H
                    } else return H;
                default:
                    e;
                    c("recoverableViolation")('Unexpected mutedStateChange "' + e + '"', "comet_video_player");
                    return H
            }
        }

        function U(a, b, c) {
            c = b.uncontrolledState.videoRepresentationID;
            var d = l.lastTrackedRepresentation,
                e = b.controlledState.playbackState,
                f = b.controlledState.seeking;
            if (!f && e !== "paused" && e !== "ended" && d != null && d !== c) {
                G({
                    eventType: "representation_ended",
                    logDataOverrides: {
                        next_representation_id: c,
                        representation_id: d
                    },
                    prevState: a,
                    state: b
                });
                l.lastTrackedRepresentation = c;
                s("quality_change");
                return H
            } else if (d == null && d !== c) {
                l.lastTrackedRepresentation = c;
                return H
            } else return H
        }

        function V(a, b) {
            var d = a.controlledState.error;
            return {
                currentVideo: {
                    audioStreamId: a.uncontrolledState.audioRepresentationID,
                    dashAudioFormat: void 0,
                    hasHD: void 0,
                    hasRateLimit: void 0,
                    hasSubtitles: a.controlledState.captionsLoaded,
                    isDrm: Boolean(e.coreVideoPlayerMetaData.graphQLVideoDRMInfo),
                    isHD: void 0,
                    isLiveStream: e.coreVideoPlayerMetaData.isLiveStreaming,
                    isRateLimited: void 0,
                    liveManifestUrl: void 0,
                    projection: void 0,
                    resourceUrl: void 0,
                    streamId: a.uncontrolledState.videoRepresentationID,
                    streamType: a.controlledState.streamingFormat,
                    tagHD: void 0,
                    tagSD: void 0,
                    videoID: e.coreVideoPlayerMetaData.videoFBID
                },
                player: {
                    canPlayType: c("mapObject")(c("VideoMimeTypes"), m),
                    dimensions: e.dimensions ? {
                        height: e.dimensions.height,
                        width: e.dimensions.width
                    } : null,
                    droppedFrames: a.uncontrolledState.videoElementDroppedFrameCount,
                    initializationTime: void 0,
                    initializationTimestamp: void 0,
                    inPlayStallCount: void 0,
                    inPlayStallTime: void 0,
                    interruptCount: void 0,
                    interruptTime: void 0,
                    lastError: d,
                    loggedError: l.lastLoggedError,
                    stack: d == null ? void 0 : d.stack,
                    stallCount: l.stallCount,
                    stallTime: l.stallDuration,
                    state: C(a),
                    totalFrames: a.uncontrolledState.videoElementTotalFrameCount,
                    version: a.playerVersion,
                    videoSource: void 0,
                    viewabilityPercentage: a.uncontrolledState.viewabilityPercentage
                },
                playerStateMachine: {
                    action: b,
                    state: a
                }
            }
        }

        function W(a, b, e) {
            var f = b.controlledState.error;
            if (f != null && f !== l.lastLoggedError && f.errorCode !== "410") {
                var g = f.errorDescription,
                    h = f.errorName,
                    i = f.errorType,
                    j = f.url,
                    k = f.errorCode == null || f.errorCode === "" ? h : f.errorCode;
                e = V(b, e);
                G({
                    eventType: "error",
                    logDataOverrides: babelHelpers["extends"]({}, c("gkx")("1565232") ? E() : null, {
                        error: h,
                        error_code: k,
                        error_description: g,
                        error_domain: h,
                        error_type: (k = i) != null ? k : d("VideoPlayerImplementationErrorNormalization").getErrorTypeFromErrorName(h),
                        error_user_info: JSON.stringify(e),
                        resource_url: j
                    }),
                    prevState: a,
                    state: b
                });
                l.lastLoggedError = f
            }
            return H
        }

        function X(a, b) {
            var c = l.errorRecoveryAttemptState.currentRecoverableError;
            if (c != null) {
                var d = c.errorCode,
                    e = c.errorDescription,
                    f = c.errorName,
                    g = c.errorType;
                c = c.url;
                l.errorRecoveryAttemptState.eventsLogged++;
                l.errorRecoveryAttemptState.repeatCount = 0;
                G({
                    eventType: "error_recovery_attempt",
                    logDataOverrides: {
                        error: f,
                        error_code: d,
                        error_description: e,
                        error_domain: f,
                        error_type: g,
                        resource_url: c
                    },
                    prevState: a,
                    state: b
                })
            }
            return H
        }

        function Y(a, b, d) {
            if (d.type === "error_recovery_attempt" && l.errorRecoveryAttemptState.eventsLogged < k) {
                var e = l.errorRecoveryAttemptState.currentRecoverableError;
                d = d.payload.recoverableError;
                if (c("gkx")("1541") && d != null && d.errorName === "OZ_NETWORK" && !c("NetworkStatus").isOnline()) return H;
                l.errorRecoveryAttemptState.currentRecoverableError = d;
                e == null || e.errorName !== d.errorName || e.errorCode !== d.errorCode ? X(a, b) : (l.errorRecoveryAttemptState.repeatCount++, l.errorRecoveryAttemptState.repeatCount > j && X(a, b))
            }
            return H
        }

        function Z(a, b, c) {
            if (!n) return H;
            var d = b.uncontrolledState.videoElementPlaybackRate;
            c.type === "dom_event_ratechange" && l.lastLoggedPlaybackSpeed != null && d !== 0 && d !== l.lastLoggedPlaybackSpeed && G({
                eventType: "playback_speed_changed",
                prevState: a,
                state: b
            });
            return H
        }

        function aa(a, b, c) {
            c = b.controlledState.playbackState;
            c === "paused" || c === "ended" ? l.nextHeartbeatTime = null : c !== "stalling" && l.nextHeartbeatTime == null && (l.nextHeartbeatTime = Date.now() + h);
            var d = l.nextHeartbeatTime;
            if (d != null) {
                var e = Date.now();
                e >= d && (c !== "stalling" && G({
                    eventType: "heart_beat",
                    prevState: a,
                    state: b
                }), l.nextHeartbeatTime = e + h)
            }
            return H
        }

        function ba(a, b, c) {
            if (c.type === "implementation_mounted") {
                G({
                    eventType: "player_loaded",
                    prevState: a,
                    state: b
                });
                return H
            } else return H
        }

        function $(a, b, c) {
            G({
                eventType: c ? "entered_fs" : "exited_fs",
                prevState: a,
                state: b
            })
        }

        function ca(a, b, c) {
            var d = e.coreVideoPlayerMetaData.playerFormat;
            (f.coreVideoPlayerMetaData.playerFormat !== d || c.type === "controller_override_player_format") && G({
                eventType: "player_format_changed",
                prevState: a,
                state: b
            });
            return H
        }

        function da(a, b, c) {
            if (c.type === "dom_event_timeupdate") {
                c = l.nextPlayedThreeSecondsPlayheadPosition;
                if (c != null) {
                    var d = b.uncontrolledState;
                    d = d.videoElementPlayheadPosition;
                    d != null && c <= d && (G({
                        eventType: "played_for_three_seconds",
                        prevState: a,
                        state: b
                    }), l.nextPlayedThreeSecondsPlayheadPosition = null)
                }
            }
            return H
        }

        function ea(a, b, c) {
            if (c.type !== "notify_fullscreen_changed") return H;
            c = l.lastLoggedFullscreenState;
            var d = b.uncontrolledState.isFullscreen;
            if (c !== !0 && d === !0) {
                $(a, b, d);
                return H
            } else if (c === !0 && d === !1) {
                $(a, b, d);
                return H
            } else return H
        }

        function fa(a, b, d) {
            d = e.coreVideoPlayerMetaData.adClientToken;
            if ((d == null || d === "") && c("gkx")("1401747")) return H;
            d = b.controlledState.playbackState;
            var f = l.lastLoggedViewabilityPercentage,
                g = b.uncontrolledState.viewabilityPercentage;
            if (d !== "paused" && d !== "ended" && f != null && f !== g) {
                G({
                    eventType: "viewability_changed",
                    prevState: a,
                    state: b
                });
                return H
            } else return H
        }

        function ga(a, b, c) {
            if (c.type === "controller_set_captions_visible_requested") {
                G({
                    eventType: "caption_change",
                    prevState: a,
                    state: b
                });
                return H
            } else return H
        }

        function ha(a) {
            f = e;
            if (a.type === "notify_logging_metadata_change") {
                a = a.payload.loggingMetaData;
                e = a
            }
        }
        return {
            addDebugSubscriber: function(a) {
                return r(a)
            },
            consumeLoggerEvents: function() {
                var a = g.splice(0);
                return a
            },
            getLoggerState: function() {
                return l
            },
            handleStateMachine: function(a, b, c) {
                ha(c);
                var d = b.controlledState.playbackState;
                w(a, b, c);
                v(a, b);
                var e = [ca, ea, fa, L, M, O, N, P, Q, S, T, R, ba, ga, U, W, Y, aa, Z, da];
                e.forEach(function(d) {
                    d(a, b, c)
                });
                (d === "paused" || d === "ended") && (l.canLogPlayingEvent = !0);
                c.type === "controller_pause_requested" && (l.hasPausedOnce = !0, l.shouldIgnoreDomPause = !0);
                c.type === "controller_play_requested" && (l.hasPausedOnce = !0, l.shouldIgnoreDomPlay = !0);
                c.type === "dom_event_pause" && (l.shouldIgnoreDomPause = !1);
                c.type === "dom_event_play" && (l.shouldIgnoreDomPlay = !1, l.lastLoggedViewabilityPercentage = b.uncontrolledState.viewabilityPercentage)
            },
            logVPLEvent: function(a) {
                var b = a.eventType,
                    c = a.logDataOverrides;
                a = a.state;
                G({
                    eventType: b,
                    logDataOverrides: c,
                    prevState: a,
                    state: a
                })
            },
            setAdditionalLogData: function(a, c) {
                b.set(a, c)
            }
        }
    }
    g.HEARTBEAT_INTERVAL = h;
    g.createVideoPlayerImplementationStateMachineLogger = a
}), 98);
__d("convertToViewabilityPercentage", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a >= .99) return 100;
        else if (a >= .75) return 75;
        else if (a >= .5) return 50;
        else if (a >= .25) return 25;
        else if (a >= 0) return 0;
        else return -2
    }
    f["default"] = a
}), 66);
__d("VideoPlayerImplementationStateMachineStateUncontrolledState", ["NetworkStatus", "convertToViewabilityPercentage", "gkx", "performance"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.engineExtrasAPI,
            d = a.fullscreenControllerRef,
            e = a.videoElementAPI,
            f = a.videoLiveTraceRef;
        a = a.videoPlayerPassiveViewabilityInfoRef;
        f = f.current;
        var g = Date.now(),
            h = typeof c("performance").now === "function" ? c("performance").now() : 0;
        if (e == null) {
            var i;
            return {
                audioRepresentationID: void 0,
                clockTimestamp: g,
                currentPlayingVideoQuality: void 0,
                estimatedBandwidth: void 0,
                isFBIsLiveTemplated: void 0,
                isFBMS: void 0,
                isFBWasLive: void 0,
                isFullscreen: d.current ? d.current.getIsFullscreen() : void 0,
                isPredictiveDash: void 0,
                liveTraceContext: f ? (i = f.getLiveTraceContext()) != null ? i : void 0 : void 0,
                manifestIdentifier: void 0,
                mpdValidationErrors: void 0,
                networkConnected: void 0,
                perfTimestamp: h,
                videoElementDebugCurrentSrc: void 0,
                videoElementDebugSrc: void 0,
                videoElementDroppedFrameCount: void 0,
                videoElementDuration: void 0,
                videoElementEnded: void 0,
                videoElementError: void 0,
                videoElementLastBufferEndPosition: void 0,
                videoElementMuted: void 0,
                videoElementNetworkState: void 0,
                videoElementPaused: void 0,
                videoElementPlaybackRate: void 0,
                videoElementPlayheadPosition: void 0,
                videoElementReadyState: void 0,
                videoElementTotalFrameCount: void 0,
                videoElementVolume: void 0,
                videoRepresentationID: void 0,
                viewabilityPercentage: void 0
            }
        }
        i = e.getPlayheadPosition();
        a = a && a.current;
        a = a && a.getCurrent();
        return {
            audioRepresentationID: b ? b.getAudioRepresentationIDAtTime(i) : void 0,
            clockTimestamp: g,
            currentPlayingVideoQuality: b ? b.getCurrentPlayingVideoQuality() : void 0,
            estimatedBandwidth: b ? b.getEstimatedBandwidth() : void 0,
            isFBIsLiveTemplated: b ? b.isFBIsLiveTemplated() : void 0,
            isFBMS: b ? b.isFBMS() : void 0,
            isFBWasLive: b ? b.isFBWasLive() : void 0,
            isFullscreen: d.current ? d.current.getIsFullscreen() : void 0,
            isPredictiveDash: b ? b.isPredictiveDash() : void 0,
            liveTraceContext: f ? (g = f.getLiveTraceContext()) != null ? g : void 0 : void 0,
            manifestIdentifier: b ? b.getManifestIdentifier() : void 0,
            mpdValidationErrors: b ? b.getMpdValidationErrors() : void 0,
            networkConnected: c("NetworkStatus").isOnline(),
            perfTimestamp: h,
            videoElementDebugCurrentSrc: c("gkx")("1526990") ? (d = e.getUnderlyingVideoElement()) == null ? void 0 : d.currentSrc : void 0,
            videoElementDebugSrc: c("gkx")("1526990") ? (f = e.getUnderlyingVideoElement()) == null ? void 0 : f.src : void 0,
            videoElementDroppedFrameCount: e.getDroppedFrameCount(),
            videoElementDuration: e.getDuration(),
            videoElementEnded: e.getEnded(),
            videoElementError: e.getError(),
            videoElementLastBufferEndPosition: e.getLastBufferEndPosition(),
            videoElementMuted: e.getMuted(),
            videoElementNetworkState: e.getNetworkState(),
            videoElementPaused: e.getPaused(),
            videoElementPlaybackRate: e.getPlaybackRate(),
            videoElementPlayheadPosition: i,
            videoElementReadyState: e.getReadyState(),
            videoElementTotalFrameCount: e.getTotalFrameCount(),
            videoElementVolume: e.getVolume(),
            videoRepresentationID: b ? b.getVideoRepresentationIDAtTime(i) : void 0,
            viewabilityPercentage: a ? c("convertToViewabilityPercentage")(a.visiblePercentage) : void 0
        }
    }
    g.createVideoPlayerImplementationStateMachineStateUncontrolledState = a
}), 98);
__d("VideoPlayerImplementationStateMachineState", ["VideoPlayerImplementationStateMachineStateUncontrolledState"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.alwaysShowCaptions,
            c = a.areCaptionsAutogenerated,
            e = a.captionDisplayStyle,
            f = a.dimensions,
            g = a.isAbrEnabled,
            h = a.playerImplementationName,
            i = a.playerVersion;
        a = a.streamingFormat;
        var j = !0,
            k = 1,
            l = d("VideoPlayerImplementationStateMachineStateUncontrolledState").createVideoPlayerImplementationStateMachineStateUncontrolledState({
                engineExtrasAPI: null,
                fullscreenControllerRef: {
                    current: null
                },
                videoElementAPI: null,
                videoLiveTraceRef: {
                    current: null
                },
                videoPlayerPassiveViewabilityInfoRef: {
                    current: null
                }
            });
        return {
            controlledState: {
                activeCaptions: null,
                activeEmsgBoxes: [],
                allEmsgBoxes: new Map(),
                availableQualities: [],
                bufferingDetected: !1,
                captionDisplayStyle: e,
                captionFormat: null,
                captionsLoaded: !1,
                captionsLocale: null,
                captionsVisible: b,
                dimensions: f,
                emsgObserverTokens: new Set(),
                error: null,
                hasPlayEverBeenRequested: !1,
                hostCallPlayIDLast: null,
                hostCallQueue: [],
                implementationSeekSourcePosition: null,
                inbandCaptionsAutogenerated: c,
                isDesktopPictureInPicture: !1,
                isLiveRewindActive: !1,
                lastBufferingType: null,
                lastMuteReason: null,
                lastPausedTimeMs: 0,
                lastPauseReason: null,
                lastPlayedTimeMs: 0,
                lastPlayReason: null,
                latencyLevel: "normal",
                loopCount: 0,
                loopCurrent: 0,
                muted: j,
                overriddenPlayerFormat: "unknown",
                playbackState: "paused",
                playerFormat: "unknown",
                scrubbing: !1,
                seekableRanges: null,
                seeking: !1,
                seekTargetPosition: null,
                selectedVideoQuality: "notselected",
                streamEnded: !1,
                streamingFormat: a,
                streamInterrupted: !1,
                targetAudioQuality: "",
                targetPlaybackRate: 1,
                targetVideoQuality: "",
                videoProjection: null,
                volume: k,
                waitingForDomPlaying: !1,
                waitingForDomTimeUpdateAfterSeeked: !1,
                watchTimeMs: 0
            },
            isAbrEnabled: g,
            playerImplementationName: h,
            playerVersion: i,
            uncontrolledState: l
        }
    }
    g.createVideoPlayerImplementationStateMachineInitialState = a
}), 98);
__d("VideoPlayerODS", ["ODS", "Random"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a, b, c) {
        d("Random").coinflip(c) && d("ODS").bumpEntityKey(2079, a, b, c)
    };
    g.bumpEntityKey = a
}), 98);
__d("VideoPlayerImplementationEngineAPI", ["CometEventListener", "CometVideoPictureInPictureManagerContext", "CurrentUser", "ErrorMetadata", "FBLogger", "MediaPlaybackCompoundEventStateMachineLogger", "NetworkStatus", "PlaybackSpeedExperiments", "RunComet", "SubscriptionsHandler", "VideoLiveTrace", "VideoPlayerBanzaiLogFlusher", "VideoPlayerCaptionsController", "VideoPlayerImplementationErrors", "VideoPlayerImplementationReactVideoElement.react", "VideoPlayerImplementationStateMachine", "VideoPlayerImplementationStateMachineHostCallQueue", "VideoPlayerImplementationStateMachineLogger", "VideoPlayerImplementationStateMachineState", "VideoPlayerImplementationStateMachineStateUncontrolledState", "VideoPlayerODS", "clearTimeout", "cr:4081", "cr:506", "cr:683059", "deepEquals", "err", "gkx", "killswitch", "qex", "react", "recoverableViolation", "removeFromArray", "setTimeout", "unrecoverableViolation", "useConcurrentAutoplayManagementAPI", "useSEOLoggedOutWebCrawler", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    f = d("react");
    var i = f.useEffect,
        j = f.useRef,
        k = f.useState,
        l = (f = c("qex")._("1653")) != null ? f : 0,
        m = function() {
            function a(a) {
                var b = a.pauseRequestCallbacks,
                    c = a.playRequestCallbacks,
                    d = a.scrubBeginRequestCallbacks;
                a = a.scrubEndRequestCallbacks;
                this.$1 = c;
                this.$2 = b;
                this.$3 = d;
                this.$4 = a
            }
            var b = a.prototype;
            b.playRequest = function(a) {
                var b = this;
                this.$1.push(a);
                return function() {
                    c("removeFromArray")(b.$1, a)
                }
            };
            b.pauseRequest = function(a) {
                var b = this;
                this.$2.push(a);
                return function() {
                    c("removeFromArray")(b.$2, a)
                }
            };
            b.scrubBeginRequest = function(a) {
                var b = this;
                this.$3.push(a);
                return function() {
                    c("removeFromArray")(b.$3, a)
                }
            };
            b.scrubEndRequest = function(a) {
                var b = this;
                this.$4.push(a);
                return function() {
                    c("removeFromArray")(b.$4, a)
                }
            };
            return a
        }();

    function n(a) {
        var b = a.concurrentAutoplayManagementAPI,
            d = a.debugAPI,
            e = a.exitPictureInPictureImpl,
            f = a.fullscreenControllerRef,
            g = a.getCurrentExposedState,
            h = a.getCurrentIsDesktopPictureInPicture,
            i = a.getCurrentIsFullscreen,
            j = a.getCurrentLiveRewindPlayheadPosition,
            k = a.getCurrentPlayheadPosition,
            l = a.internal_getCurrentStateMachineState,
            n = a.loggerAPI,
            o = a.overridePlayerFormatImpl,
            p = a.pauseImpl,
            q = a.playImpl,
            r = a.registerEmsgObserverImpl,
            s = a.requestPictureInPictureImpl,
            t = a.scrubBeginImpl,
            u = a.scrubEndImpl,
            v = a.seekImpl,
            w = a.selectVideoQualityImpl,
            x = a.setCaptionsDisplayStyleImpl,
            y = a.setCaptionsUrlImpl,
            z = a.setCaptionsVisibleImpl,
            A = a.setIsLiveRewindActiveImpl,
            B = a.setLatencyLevelImpl,
            C = a.setMutedImpl,
            D = a.setPictureInPictureStateImpl,
            E = a.setPlaybackRateImpl,
            F = a.setVolumeImpl,
            G = a.subscribers,
            H = a.unregisterEmsgObserverImpl,
            I = a.videoElementAPIRef,
            J = new Set(),
            K = !1,
            L = null,
            M = [],
            N = [],
            O = [],
            P = [],
            Q = new m({
                pauseRequestCallbacks: N,
                playRequestCallbacks: M,
                scrubBeginRequestCallbacks: O,
                scrubEndRequestCallbacks: P
            }),
            R = {
                freeze: function() {
                    if (!g().paused) throw c("unrecoverableViolation")("Video player must be paused before the controller freeze", "comet_video_player");
                    var a = {};
                    try {
                        var b = !1;
                        J.size === 0 && (b = !0, L = {
                            exposedState: g(),
                            isFullscreen: i(),
                            liveRewindPlayheadPosition: j(),
                            playheadPosition: k(),
                            stateMachineState: l()
                        });
                        J.add(a);
                        b && (K = !0, G.forEach(function(a) {
                            a()
                        }))
                    } finally {
                        K = !1
                    }
                    return a
                },
                isFrozen: function() {
                    return L != null
                },
                unfreeze: function(a) {
                    if (!J.has(a)) throw c("unrecoverableViolation")("Video player controller unfreeze token not found", "comet_video_player");
                    J["delete"](a);
                    J.size === 0 && (L = null, G.forEach(function(a) {
                        a()
                    }))
                }
            },
            S = babelHelpers["extends"]({}, b, R, n, {
                debugAPI: d,
                exitPictureInPicture: function() {
                    if (R.isFrozen()) return;
                    e()
                },
                getCurrentState: function() {
                    return L != null ? L.exposedState : g()
                },
                getIsDesktopPictureInPicture: function() {
                    return L != null ? L.isFullscreen : h()
                },
                getIsFullscreen: function() {
                    return L != null ? L.isFullscreen : i()
                },
                getLiveRewindPlayheadPosition: function() {
                    return L != null ? L.liveRewindPlayheadPosition : j()
                },
                getPlayheadPosition: function() {
                    return L != null ? L.playheadPosition : k()
                },
                internal_getStateMachineState: function() {
                    return L != null ? L.stateMachineState : l()
                },
                internal_getVideoElement: function() {
                    var a = I.current;
                    if (a != null) {
                        a = a.getUnderlyingVideoElement();
                        return a
                    }
                    return null
                },
                observeOn: function() {
                    return Q
                },
                overridePlayerFormat: function(a) {
                    if (R.isFrozen()) return;
                    o(a)
                },
                pause: function(a) {
                    if (R.isFrozen()) return;
                    N.forEach(function(b) {
                        return b(a)
                    });
                    p(a)
                },
                play: function(a) {
                    if (R.isFrozen()) return;
                    M.forEach(function(b) {
                        return b(a)
                    });
                    q(a)
                },
                registerEmsgObserver: function() {
                    var a = {};
                    r(a);
                    return a
                },
                requestPictureInPicture: function() {
                    if (R.isFrozen()) return;
                    s()
                },
                requestSetIsFullscreen: function(a) {
                    if (R.isFrozen()) return;
                    var b = f.current;
                    if (b) {
                        var c = S.internal_getVideoElement();
                        b.requestSetIsFullscreen(a, c)
                    }
                },
                scrollIntoView: function(a) {
                    var b = S.internal_getVideoElement();
                    b && b.scrollIntoView(a)
                },
                scrubBegin: function() {
                    if (R.isFrozen()) return;
                    O.forEach(function(a) {
                        return a()
                    });
                    t()
                },
                scrubEnd: function(a) {
                    if (R.isFrozen()) return;
                    P.forEach(function(b) {
                        return b(a)
                    });
                    u(a)
                },
                seek: function(a) {
                    if (R.isFrozen()) return;
                    v(a)
                },
                selectVideoQuality: function(a) {
                    if (R.isFrozen()) return;
                    w(a)
                },
                setCaptionsDisplayStyle: function(a) {
                    if (R.isFrozen()) return;
                    x(a)
                },
                setCaptionsUrl: function(a) {
                    if (R.isFrozen()) return;
                    y(a)
                },
                setCaptionsVisible: function(a) {
                    if (R.isFrozen()) return;
                    z(a)
                },
                setIsLiveRewindActive: function(a) {
                    if (R.isFrozen()) return;
                    A(a)
                },
                setLatencyLevel: function(a) {
                    if (R.isFrozen()) return;
                    B(a)
                },
                setMuted: function(a, b) {
                    if (R.isFrozen()) return;
                    C(a, b)
                },
                setPictureInPictureState: function(a) {
                    if (R.isFrozen()) return;
                    D(a)
                },
                setPlaybackRate: function(a) {
                    if (R.isFrozen()) return;
                    E(a)
                },
                setVolume: function(a) {
                    if (R.isFrozen()) return;
                    F(a)
                },
                subscribe: function(a) {
                    var b = function() {
                            if (R.isFrozen() && !K) return;
                            a()
                        },
                        d = f.current,
                        e = d ? d.subscribe(b) : null;
                    G.push(b);
                    return {
                        remove: function() {
                            e && e.remove(), c("removeFromArray")(G, b)
                        }
                    }
                },
                unregisterEmsgObserver: function(a) {
                    H(a)
                },
                videoElementAPIRef: I
            });
        return S
    }

    function o(a) {
        var b = a.concurrentAutoplayManagementAPI,
            d = a.createExposedState,
            e = a.debugAPI,
            f = a.fullscreenControllerRef,
            g = a.logger,
            h = a.machine,
            i = a.subscribers,
            j = a.videoElementAPIRef;
        a = {
            setAdditionalLogData: function(a, b) {
                g.setAdditionalLogData(a, b)
            }
        };
        return n({
            concurrentAutoplayManagementAPI: b,
            debugAPI: e,
            exitPictureInPictureImpl: function() {
                h.dispatch({
                    type: "controller_picture_in_picture_exit_requested"
                })
            },
            fullscreenControllerRef: f,
            getCurrentExposedState: function() {
                return d(h.getCurrentState())
            },
            getCurrentIsDesktopPictureInPicture: function() {
                var a;
                return (a = h.getCurrentState().controlledState.isDesktopPictureInPicture) != null ? a : !1
            },
            getCurrentIsFullscreen: function() {
                var a = f.current;
                return a ? a.getIsFullscreen() : !1
            },
            getCurrentLiveRewindPlayheadPosition: function() {
                var a = h.getCurrentState();
                a = a.controlledState;
                var b = a.isLiveRewindActive,
                    c = a.seekableRanges;
                a = a.seekTargetPosition;
                if (!b || a == null) return null;
                c = (b = c == null ? void 0 : c.end(0)) != null ? b : 0;
                return a - c
            },
            getCurrentPlayheadPosition: function() {
                var a, b = 0;
                return (a = (a = c("gkx")("3464") ? (a = j.current) == null ? void 0 : a.getPlayheadPosition() : void 0) != null ? a : h.getCurrentState().uncontrolledState.videoElementPlayheadPosition) != null ? a : b
            },
            internal_getCurrentStateMachineState: function() {
                return h.getCurrentState()
            },
            loggerAPI: a,
            overridePlayerFormatImpl: function(a) {
                h.dispatch({
                    payload: {
                        playerFormat: a
                    },
                    type: "controller_override_player_format"
                })
            },
            pauseImpl: function(a) {
                h.dispatch({
                    payload: {
                        reason: a
                    },
                    type: "controller_pause_requested"
                })
            },
            playImpl: function(a) {
                h.dispatch({
                    payload: {
                        reason: a
                    },
                    type: "controller_play_requested"
                })
            },
            registerEmsgObserverImpl: function(a) {
                h.dispatch({
                    payload: {
                        token: a
                    },
                    type: "register_emsg_observer"
                })
            },
            requestPictureInPictureImpl: function() {
                h.dispatch({
                    type: "controller_picture_in_picture_requested"
                })
            },
            scrubBeginImpl: function() {
                h.dispatch({
                    type: "controller_scrub_begin_requested"
                })
            },
            scrubEndImpl: function(a) {
                h.dispatch({
                    payload: {
                        seekTargetPosition: a
                    },
                    type: "controller_scrub_end_requested"
                })
            },
            seekImpl: function(a) {
                h.dispatch({
                    payload: {
                        seekTargetPosition: a
                    },
                    type: "controller_seek_requested"
                })
            },
            selectVideoQualityImpl: function(a) {
                h.dispatch({
                    payload: {
                        selectedVideoQuality: a
                    },
                    type: "controller_quality_requested"
                })
            },
            setCaptionsDisplayStyleImpl: function(a) {
                h.dispatch({
                    payload: {
                        captionDisplayStyle: a
                    },
                    type: "controller_set_caption_display_style_requested"
                })
            },
            setCaptionsUrlImpl: function(a) {
                h.dispatch({
                    payload: {
                        captionsUrl: a
                    },
                    type: "controller_set_captions_url_requested"
                })
            },
            setCaptionsVisibleImpl: function(a) {
                h.dispatch({
                    payload: {
                        captionsVisible: a
                    },
                    type: "controller_set_captions_visible_requested"
                })
            },
            setIsLiveRewindActiveImpl: function(a) {
                h.dispatch({
                    payload: {
                        isLiveRewindActive: a
                    },
                    type: "controller_set_is_live_rewind_active_requested"
                })
            },
            setLatencyLevelImpl: function(a) {
                h.dispatch({
                    payload: {
                        latencyLevel: a
                    },
                    type: "controller_set_latency_level_requested"
                })
            },
            setMutedImpl: function(a, b) {
                h.dispatch({
                    payload: {
                        muted: a,
                        reason: b
                    },
                    type: "controller_muted_requested"
                })
            },
            setPictureInPictureStateImpl: function(a) {
                h.dispatch({
                    payload: {
                        isInPictureInPictureMode: a
                    },
                    type: "controller_set_picture_in_picture_state_requested"
                })
            },
            setPlaybackRateImpl: function(a) {
                h.dispatch({
                    payload: {
                        playbackRate: a
                    },
                    type: "controller_set_playback_rate"
                })
            },
            setVolumeImpl: function(a) {
                h.dispatch({
                    payload: {
                        volume: a
                    },
                    type: "controller_volume_requested"
                })
            },
            subscribers: i,
            unregisterEmsgObserverImpl: function(a) {
                h.dispatch({
                    payload: {
                        token: a
                    },
                    type: "unregister_emsg_observer"
                })
            },
            videoElementAPIRef: j
        })
    }

    function p(a) {
        a = a.current;
        if (a == null) throw c("unrecoverableViolation")("Attempted to access VideoElementAPI while it is not available.", "comet_video_player");
        return a
    }

    function q(a) {
        var e = a.alwaysShowCaptions,
            f = a.areCaptionsAutogenerated,
            g = a.captionDisplayStyle,
            h = a.captionsControllerRef,
            i = a.debugLogId,
            j = a.dimensions,
            k = a.engineExtrasAPI,
            m = a.engineMetadata,
            n = a.fullscreenControllerRef,
            o = a.handleFatalError,
            q = a.handleStateMachine,
            s = a.videoElementAPIRef,
            t = a.videoLiveTraceRef,
            u = a.videoPlayerPassiveViewabilityInfoRef;

        function v(a) {
            d("VideoPlayerImplementationStateMachineHostCallQueue").applyOrQueueHostCall({
                engineExtrasAPI: k,
                hostCall: a,
                machine: y,
                videoElementAPI: s.current
            })
        }
        var w = null,
            x = null;
        a = [function(a, c, d) {
            b("cr:683059") && d.type === "implementation_host_call_applied" && d.payload.hostCall.type === "host_call_play" && c.controlledState.lastPlayReason === "autoplay_initiated" ? b("cr:683059").addFirstMarkerPoint("firstVideoAutoplayStalling") : b("cr:683059") && c.controlledState.playbackState !== a.controlledState.playbackState && c.controlledState.playbackState === "playing" && c.controlledState.lastPlayReason === "autoplay_initiated" && b("cr:683059").addFirstMarkerPoint("firstVideoAutoplayPlaying");
            return !0
        }, function(a, b, c) {
            q(a, b, c);
            return !0
        }, function(a, b, e) {
            if (c("gkx")("1633455") && (a.controlledState.streamInterrupted === !1 && b.controlledState.streamInterrupted === !0 || a.controlledState.streamInterrupted === !0 && b.controlledState.streamInterrupted === !1)) {
                a = b.controlledState;
                b = a.bufferingDetected;
                var f = a.lastBufferingType,
                    g = a.streamInterrupted;
                a = a.targetPlaybackRate;
                g ? (b && y.dispatch({
                    payload: {
                        domEventPerfTimestamp: null
                    },
                    type: "buffering_end_requested"
                }), v({
                    payload: {
                        hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                        playbackRate: 0,
                        reason: e.type
                    },
                    type: "host_call_set_playback_rate"
                })) : (v({
                    payload: {
                        hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                        playbackRate: a,
                        reason: e.type
                    },
                    type: "host_call_set_playback_rate"
                }), b && y.dispatch({
                    payload: {
                        bufferingType: f || "in_play"
                    },
                    type: "buffering_begin_requested"
                }))
            }
            return !0
        }, function(a, b, e) {
            if (a.controlledState.bufferingDetected === !1 && b.controlledState.bufferingDetected === !0 || a.controlledState.bufferingDetected === !0 && b.controlledState.bufferingDetected === !1) {
                w !== null && (c("clearTimeout")(w), w = null);
                if (b.controlledState.bufferingDetected && (!c("gkx")("1633455") || !b.controlledState.streamInterrupted)) {
                    e = function a() {
                        w = null;
                        if (c("gkx")("1849507") && !c("NetworkStatus").isOnline()) w = c("setTimeout")(a, g);
                        else {
                            var e = d("VideoPlayerImplementationErrors").createVideoPlayerBufferingErrorFromGenericError("BUFFERING_TIMEOUT", c("err")("The video has been in a buffering state for over " + g + " ms."), "buffering_timeout", f, b.controlledState.isLiveRewindActive);
                            x && (x.log(), x = null);
                            y.dispatch({
                                payload: {
                                    fatalError: e
                                },
                                type: "implementation_fatal_error"
                            });
                            e = k.getPerfLoggerProvider();
                            e == null ? void 0 : e.getOperationLogger("buffering_timeout").setType(f).setInitiator("engine_api").setLength(g).setResult("failed").log()
                        }
                    };
                    var f = (a = b.controlledState.lastBufferingType) != null ? a : "in_play";
                    a = (a = c("qex")._("1654")) != null ? a : l;
                    var g = f === "in_play" ? a : l;
                    g > 0 && (w = c("setTimeout")(e, g));
                    a = k.getPerfLoggerProvider();
                    x = a ? a.getOperationLogger("buffering").setState("buffering").setType(f).start() : null
                } else !b.controlledState.bufferingDetected && x != null && (x.log(), x = null)
            }
            return !0
        }, function(a, b, d) {
            if (d.type !== "implementation_engine_destroy_requested") return !0;
            w !== null && c("clearTimeout")(w);
            w = null;
            return !1
        }, function(a, b, c) {
            if (c.type !== "implementation_engine_initialized") return !0;
            a = p(s);
            c = c.type;
            d("VideoPlayerImplementationStateMachineHostCallQueue").flushHostCallQueue({
                engineExtrasAPI: k,
                machine: y,
                reason: c,
                state: b,
                videoElementAPI: a
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "dom_event_ended") return !0;
            a = b.controlledState;
            (a.loopCount > 0 && a.loopCurrent < a.loopCount || a.loopCount === -1) && y.dispatch({
                payload: {
                    reason: "loop_initiated"
                },
                type: "controller_play_requested"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_pause_requested") return !0;
            a = b.controlledState.playbackState;
            if (a !== "paused") return !1;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type
                },
                type: "host_call_pause"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_play_requested") return !0;
            a = b.controlledState.playbackState;
            if (a !== "stalling") return !1;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type
                },
                type: "host_call_play"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_seek_requested") return !0;
            a = b.controlledState;
            b = a.seeking;
            a = a.seekTargetPosition;
            b && a != null && v({
                payload: {
                    currentTime: a,
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type
                },
                type: "host_call_set_current_time"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_muted_requested") return !0;
            a = b.controlledState.muted;
            if (a !== c.payload.muted) return !1;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    muted: a,
                    reason: c.type
                },
                type: "host_call_set_muted"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_scrub_begin_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    playbackRate: 0,
                    reason: c.type
                },
                type: "host_call_set_playback_rate"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_scrub_end_requested") return !0;
            a = b.controlledState;
            b = a.seeking;
            var e = a.seekTargetPosition;
            a = a.targetPlaybackRate;
            b && e != null ? (v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    playbackRate: a,
                    reason: c.type + ":seek"
                },
                type: "host_call_set_playback_rate"
            }), v({
                payload: {
                    currentTime: e,
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type + ":seek"
                },
                type: "host_call_set_current_time"
            })) : v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    playbackRate: a,
                    reason: c.type + ":cancel"
                },
                type: "host_call_set_playback_rate"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "buffering_begin_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    playbackRate: 0,
                    reason: c.type
                },
                type: "host_call_set_playback_rate"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_set_playback_rate") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    playbackRate: c.payload.playbackRate,
                    reason: c.type
                },
                type: "host_call_set_playback_rate"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "buffering_end_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    playbackRate: b.controlledState.targetPlaybackRate,
                    reason: c.type
                },
                type: "host_call_set_playback_rate"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_volume_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type,
                    volume: b.controlledState.volume
                },
                type: "host_call_set_volume"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_quality_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type,
                    selectedVideoQuality: b.controlledState.selectedVideoQuality
                },
                type: "host_call_set_video_quality"
            });
            return !1
        }, function(a, b, c) {
            if (!(c.type === "controller_set_latency_level_requested" || c.type === "implementation_set_latency_level_requested")) return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    latencyLevel: c.payload.latencyLevel,
                    reason: c.type
                },
                type: "host_call_set_latency_level"
            });
            return !1
        }, function(a, b, c) {
            if (!(c.type === "dom_event_timeupdate" || c.type === "captions_loaded")) return !0;
            c = h.current;
            var e = b.controlledState.captionsVisible,
                f = s.current;
            f = f ? f.getPlayheadPosition() : 0;
            if (d("PlaybackSpeedExperiments").enableCometPlaybackSpeedControl() && b.controlledState.isLiveRewindActive) {
                var g = b.controlledState.seekableRanges;
                g = g != null ? (g = g.end(g.length() - 1)) != null ? g : 0 : 0;
                f >= g && y.dispatch({
                    payload: {
                        isLiveRewindActive: !1
                    },
                    type: "controller_set_is_live_rewind_active_requested"
                })
            }
            if (!k.getRepresentationCaptionsExpectedFromManifest() && c && e && b.controlledState.captionsLoaded) {
                g = c.handleTimeUpdate(f);
                e = c.getCaptionFormat();
                b = a.controlledState.activeCaptions;
                c = a.controlledState.captionFormat;
                e !== c && y.dispatch({
                    payload: {
                        captionFormat: e
                    },
                    type: "controller_set_caption_format_requested"
                });
                r(b, g) && y.dispatch({
                    payload: {
                        activeCaptions: g,
                        captionsLocale: null
                    },
                    type: "controller_set_active_captions_requested"
                })
            }
            a = t.current;
            a != null && a.onUpdateStatus({
                position: f
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "cea608_bytes_received") return !0;
            a = h.current;
            if (a) {
                b = c.payload;
                c = b.timescale;
                b = b.videoBytes;
                a.handleCea608BytesReceived({
                    timescale: c,
                    videoBytes: b
                })
            }
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_set_captions_url_requested") return !0;
            a = h.current;
            if (a) {
                b = c.payload.captionsUrl;
                a.updateCaptionsUrl(b)
            }
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_set_is_live_rewind_active_requested") return !0;
            k.setEnableLiveheadCatchup(!c.payload.isLiveRewindActive);
            !!d("PlaybackSpeedExperiments").enableCometPlaybackSpeedControl() && !c.payload.isLiveRewindActive && y.dispatch({
                payload: {
                    playbackRate: 1
                },
                type: "controller_set_playback_rate"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_picture_in_picture_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type
                },
                type: "host_call_picture_in_picture"
            });
            return !1
        }, function(a, b, c) {
            if (c.type !== "controller_picture_in_picture_exit_requested") return !0;
            v({
                payload: {
                    hostCallID: d("VideoPlayerImplementationStateMachineHostCallQueue").makeHostCallID(),
                    reason: c.type
                },
                type: "host_call_exit_picture_in_picture"
            });
            return !1
        }];
        var y = d("VideoPlayerImplementationStateMachine").createVideoPlayerImplementationStateMachineWithStateTransitionHandlers({
            collectUncontrolledState: function() {
                var a = s.current;
                return d("VideoPlayerImplementationStateMachineStateUncontrolledState").createVideoPlayerImplementationStateMachineStateUncontrolledState({
                    engineExtrasAPI: k,
                    fullscreenControllerRef: n,
                    videoElementAPI: a,
                    videoLiveTraceRef: t,
                    videoPlayerPassiveViewabilityInfoRef: u
                })
            },
            debugLogId: i,
            initialState: d("VideoPlayerImplementationStateMachineState").createVideoPlayerImplementationStateMachineInitialState({
                alwaysShowCaptions: e,
                areCaptionsAutogenerated: f,
                captionDisplayStyle: g,
                dimensions: j,
                isAbrEnabled: m.isAbrEnabled,
                playerImplementationName: m.playerImplementationName,
                playerVersion: m.playerVersion,
                streamingFormat: m.streamingFormat
            }),
            onFatalError: o,
            stateTransitionHandlers: a
        });
        return y
    }

    function r(a, b) {
        if (a === null && b === null) return !1;
        if (a === null || b === null) return !0;
        var c = (b = b.rows) != null ? b : [];
        a = (b = a.rows) != null ? b : [];
        return a.length !== c.length || a.some(function(a, b) {
            return a !== c[b]
        })
    }

    function s(a, b, c, d) {
        a !== b.current && (c.current && (c.current.remove(), c.current = null), b.current = a), b.current && !c.current && (c.current = b.current.subscribe(function() {
            d.dispatch({
                type: "notify_fullscreen_changed"
            })
        }))
    }

    function t(a, b, c, d) {
        a !== b.current && (c.current && (c.current.remove(), c.current = null), b.current = a), b.current && !c.current && (c.current = b.current.subscribe(function() {
            d.dispatch({
                type: "notify_viewability_changed"
            })
        }))
    }

    function u(a) {
        var b = a.engineMetadata;
        a = a.state;
        var c = a.controlledState,
            d = c.activeCaptions,
            e = c.activeEmsgBoxes,
            f = c.availableQualities,
            g = c.captionDisplayStyle,
            h = c.captionsLoaded,
            i = c.captionsVisible,
            j = c.error,
            k = c.hasPlayEverBeenRequested,
            l = c.implementationSeekSourcePosition,
            m = c.inbandCaptionsAutogenerated,
            n = c.isDesktopPictureInPicture,
            o = c.isLiveRewindActive,
            p = c.lastMuteReason,
            q = c.lastPauseReason,
            r = c.lastPlayedTimeMs,
            s = c.lastPlayReason,
            t = c.latencyLevel,
            u = c.loopCount,
            v = c.loopCurrent,
            w = c.muted,
            x = c.overriddenPlayerFormat,
            y = c.playbackState,
            z = c.seekableRanges,
            A = c.seeking,
            B = c.seekTargetPosition,
            C = c.selectedVideoQuality,
            D = c.streamInterrupted,
            E = c.targetAudioQuality,
            F = c.targetPlaybackRate,
            G = c.targetVideoQuality,
            H = c.videoProjection,
            I = c.volume;
        c = c.watchTimeMs;
        var J = a.uncontrolledState,
            K = J.currentPlayingVideoQuality,
            L = J.videoElementDuration,
            M = J.videoElementLastBufferEndPosition;
        J = J.videoRepresentationID;
        var N = y === "ended",
            O = y === "paused" || N,
            P = y === "playing",
            Q = y === "inPlayStalling";
        y = y === "stalling" || Q;
        d = {
            activeCaptions: d,
            activeEmsgBoxes: e,
            availableVideoQualities: f,
            bufferEnd: (d = M) != null ? d : 0,
            captionDisplayStyle: g,
            captionsLoaded: h,
            captionsVisible: i,
            currentVideoQuality: (e = K) != null ? e : "",
            duration: (f = L) != null ? f : 0,
            ended: N,
            error: j,
            hasPlayEverBeenRequested: k,
            inbandCaptionsAutogenerated: m,
            inPlayStalling: Q,
            isAbrEnabled: b.isAbrEnabled,
            isDesktopPictureInPicture: (M = n) != null ? M : !1,
            isExternalMedia: b.isExternalMedia,
            isLiveRewindActive: o,
            lastMuteReason: p,
            lastPauseReason: q,
            lastPlayedTimeMs: r,
            lastPlayReason: s,
            latencyLevel: t,
            loopCount: u,
            loopCurrent: v,
            muted: w,
            overriddenPlayerFormat: x,
            paused: O,
            playerImplementationName: a.playerImplementationName,
            playerVersion: a.playerVersion,
            playing: P,
            seekableRanges: z,
            seeking: A,
            seekSourcePosition: l,
            seekTargetPosition: B,
            selectedVideoQuality: C,
            stalling: y,
            streamInterrupted: D,
            targetAudioQuality: E,
            targetPlaybackRate: F,
            targetVideoQuality: G,
            videoProjection: H,
            videoRepresentationID: J,
            volume: I,
            watchTimeMs: c
        };
        return d
    }

    function a(a) {
        var e = a.createDebugAPI,
            f = a.createVideoPlayerError,
            g = a.debugLog,
            h = a.debugLogId,
            i = a.destroyEngineParts,
            j = a.engineExtrasAPI,
            k = a.engineMetadata,
            l = a.handleFatalError,
            m = a.handleVideoElementMounted,
            n = a.handleVideoElementUnmounted,
            p = a.handleVideoInfoChange,
            r = a.initialProps,
            v = a.setExposedStateInReact;
        g = r.loggingMetaData.instanceKey;
        a = r.loggingMetaData.coreVideoPlayerMetaData;
        var w = a.broadcastId,
            x = a.isLiveStreaming;
        a = a.isLiveTraceEnabled;
        var y = {
                current: Boolean(x) && Boolean(a) && w != null ? new(c("VideoLiveTrace"))(w, g, c("CurrentUser").getAccountID()) : null
            },
            z = d("VideoPlayerImplementationStateMachineLogger").createVideoPlayerImplementationStateMachineLogger({
                debugLogId: h,
                initialLoggingMetaData: r.loggingMetaData,
                videoLiveTraceRef: y
            }),
            A = b("cr:4081") ? d("MediaPlaybackCompoundEventStateMachineLogger").createMediaPlaybackCompoundEventStateMachineLogger({
                debugLogId: h,
                initialLoggingMetaData: r.loggingMetaData
            }) : null,
            B = b("cr:4081") && A ? new(b("cr:4081"))(A) : null,
            C = new(c("VideoPlayerBanzaiLogFlusher"))(z),
            D = {
                current: (x = r.videoPlayerPassiveViewabilityInfo) != null ? x : null
            },
            E = {
                current: (a = r.fullscreenController) != null ? a : null
            },
            F = {
                current: null
            };
        w = d("useConcurrentAutoplayManagementAPI").createConcurrentAutoplayManagementAPI();
        var G = [],
            H = function() {
                G.forEach(function(a) {
                    a()
                }), r.disableLogging ? (C.discardLogsWithoutFlushing(), b("cr:4081") && (B == null ? void 0 : B.discardLogsWithoutFlushing())) : (C.flushLogs(), B == null ? void 0 : B.flushLogs())
            },
            I = {
                current: null
            },
            J = null,
            K = {
                current: {
                    inbandCaptionsAutogeneratedFromManifest: !1,
                    inbandCaptionsExpectedFromManifest: !1,
                    inbandCaptionsExpectedFromProps: r.inbandCaptionsExpected,
                    representationCaptionsExpectedFromManifest: !1,
                    sideLoadCaptionsExpectedFromProps: r.sideLoadCaptionsExpected,
                    sideLoadCaptionsUrlFromProps: (g = r.captionsUrl) != null ? g : null
                }
            },
            L = {
                current: null
            },
            M = {
                current: null
            },
            N = new(c("SubscriptionsHandler"))(),
            O = new(c("SubscriptionsHandler"))(),
            P = "before_mounted";

        function Q() {
            return P === "mounted"
        }
        var R = {
                current: null
            },
            S = function(a) {
                a = u({
                    engineMetadata: k,
                    state: a
                });
                return a
            },
            T = {
                current: null
            },
            U = {
                current: null
            },
            aa = function(a) {
                if (Q()) {
                    if (a === T.current) return;
                    var b = S(a);
                    if (U.current != null && c("deepEquals")(U.current, b)) return;
                    T.current = a;
                    U.current = b;
                    v(b)
                }
            };
        x = function(a, b, c) {
            z.handleStateMachine(a, b, c), A == null ? void 0 : A.handleStateMachine(a, b, c), aa(b), H()
        };
        var V = function(a, b) {};
        a = function(a) {
            V(a, "state_machine_fatal_error")
        };
        var W = q({
                alwaysShowCaptions: Boolean(r.alwaysShowCaptions),
                areCaptionsAutogenerated: Boolean(r.areCaptionsAutogenerated),
                captionDisplayStyle: r.captionDisplayStyle,
                captionsControllerRef: F,
                debugLogId: h,
                dimensions: r.dimensions,
                engineExtrasAPI: j,
                engineMetadata: k,
                fullscreenControllerRef: E,
                handleFatalError: a,
                handleStateMachine: x,
                videoElementAPIRef: R,
                videoLiveTraceRef: y,
                videoPlayerPassiveViewabilityInfoRef: D
            }),
            X = !1,
            Y = function(a) {
                var b = I.current != null,
                    d = R.current != null;
                N.release();
                W.dispatch({
                    payload: {
                        reason: a,
                        videoElementAPIExisted: d,
                        videoElementExisted: b
                    },
                    type: "implementation_engine_destroy_requested"
                });
                try {
                    c("gkx")("1494163") ? i(["destroyEngine(" + a + ")"]) : X || (X = !0, i(["destroyEngine(" + a + ")"]))
                } catch (e) {
                    if (c("gkx")("1494163")) try {
                        c("FBLogger")("comet_video_player").catching(e).warn("Error thrown by destroyEngineParts: %s %s", e.message, JSON.stringify({
                            playerImplementationName: k.playerImplementationName,
                            reason: a,
                            videoElementAPIExisted: d,
                            videoElementExisted: b
                        }))
                    } catch (a) {}
                }
                var e = F.current;
                e != null && (W.getCurrentState().controlledState.captionsLoaded && W.dispatch({
                    type: "captions_unloaded"
                }), F.current = null, e.destroy());
                s(null, E, L, W);
                t(null, D, M, W);
                W.dispatch({
                    payload: {
                        reason: a,
                        videoElementAPIExisted: d,
                        videoElementExisted: b
                    },
                    type: "implementation_engine_destroyed"
                })
            };
        V = function(a, b) {
            a = f(a, b);
            W.dispatch({
                payload: {
                    fatalError: a
                },
                type: "implementation_fatal_error"
            });
            Y("implementation_fatal_error");
            l(a)
        };

        function ba(a) {
            return a.sideLoadCaptionsExpectedFromProps && a.sideLoadCaptionsUrlFromProps !== null
        }

        function Z(a) {
            return a.inbandCaptionsExpectedFromProps && ((a = a.inbandCaptionsExpectedFromManifest) != null ? a : !1)
        }

        function $(a) {
            return (a = a.inbandCaptionsAutogeneratedFromManifest) != null ? a : !1
        }
        var ca = function(a) {
                var b = ba(a),
                    c = Z(a),
                    e = $(a),
                    f = F.current;
                e !== $(K.current) && W.dispatch({
                    payload: {
                        inbandCaptionsAutogenerated: e
                    },
                    type: "inband_captions_autogenerated_changed"
                });
                f != null ? c !== Z(K.current) && (f.updateInbandCaptionsExpected(c), !c && W.getCurrentState().controlledState.captionsLoaded && W.dispatch({
                    type: "captions_unloaded"
                })) : (b || c) && f == null && (F.current = d("VideoPlayerCaptionsController").createCaptionsController({
                    captionsUrl: b ? a.sideLoadCaptionsUrlFromProps : null,
                    inbandCaptionsExpected: c,
                    onCaptionsLoaded: function() {
                        W.getCurrentState().controlledState.captionsLoaded || W.dispatch({
                            type: "captions_loaded"
                        })
                    }
                }));
                K.current = a
            },
            da = function(a) {
                j != null && a && a.width > 0 && a.height > 0 && (j.setDimensions(a), W.dispatch({
                    payload: {
                        dimensions: {
                            height: a.height,
                            width: a.width
                        }
                    },
                    type: "player_dimensions_changed"
                }))
            },
            ea = function(a) {
                a !== W.getCurrentState().controlledState.loopCount && W.dispatch({
                    payload: {
                        loopCount: a
                    },
                    type: "loop_count_change_requested"
                })
            },
            fa = function(a) {
                "srcObject" in a && (a.srcObject = null), c("gkx")("8054") && a.removeAttribute("src"), O.release(), O.engage()
            },
            ga = function(a, e) {
                if (I.current === a) return;
                if (!Q() && c("gkx")("1405244")) return;
                if (!Q()) {
                    var f = function(a) {
                        switch (a) {
                            case "unmounted":
                                return "EngineAPI.handleVideoElement.unmounted";
                            case "before_mounted":
                                return "EngineAPI.handleVideoElement.before_mounted";
                            case "mounted":
                                return null;
                            default:
                                a;
                                return null
                        }
                    }(P);
                    f && d("VideoPlayerODS").bumpEntityKey("comet_video_player", f, 1)
                }
                a != null && I.current != null && I.current !== a && c("recoverableViolation")("The video element was recreated", "comet_video_player");
                J != null && J();
                f = I.current;
                f && fa(f);
                I.current = a;
                b("cr:506") != null && a != null && (J = b("cr:506")(a, h));
                a != null && O.addSubscriptions(c("CometEventListener").listen(a, "enterpictureinpicture", function() {
                    var a = d("CometVideoPictureInPictureManagerContext").isInPictureInPictureExp();
                    a && W.dispatch({
                        payload: {
                            isInPictureInPictureMode: !0
                        },
                        type: "controller_set_picture_in_picture_state_requested"
                    })
                }), c("CometEventListener").listen(a, "leavepictureinpicture", function() {
                    var a = d("CometVideoPictureInPictureManagerContext").isInPictureInPictureExp();
                    a && W.dispatch({
                        payload: {
                            isInPictureInPictureMode: !1
                        },
                        type: "controller_set_picture_in_picture_state_requested"
                    })
                }));
                c("gkx")("1494163") && (a == null && (R.current = null));
                I.current != null ? (W.dispatch({
                    type: "implementation_video_node_mounted"
                }), m([].concat(e, ["handleVideoElement(non-null)"]))) : (W.dispatch({
                    type: "implementation_video_node_unmounted"
                }), n([].concat(e, ["handleVideoElement(null)"])))
            };
        g = r.loggingMetaData.instanceKey;
        a = function(a) {
            var b;
            if (!Q()) return;
            s((b = a.fullscreenController) != null ? b : null, E, L, W);
            t((b = a.videoPlayerPassiveViewabilityInfo) != null ? b : null, D, M, W);
            if (!p(a)) {
                b = {
                    inbandCaptionsAutogeneratedFromManifest: K.current.inbandCaptionsAutogeneratedFromManifest,
                    inbandCaptionsExpectedFromManifest: K.current.inbandCaptionsExpectedFromManifest,
                    inbandCaptionsExpectedFromProps: a.inbandCaptionsExpected,
                    representationCaptionsExpectedFromManifest: K.current.representationCaptionsExpectedFromManifest,
                    sideLoadCaptionsExpectedFromProps: a.sideLoadCaptionsExpected,
                    sideLoadCaptionsUrlFromProps: (b = a.captionsUrl) != null ? b : null
                };
                ca(b);
                da(a.dimensions);
                ea((b = a.loopCount) != null ? b : 0)
            }
            W.dispatch({
                payload: {
                    loggingMetaData: a.loggingMetaData
                },
                type: "notify_logging_metadata_change"
            })
        };
        x = function() {
            if (P !== "before_mounted") {
                var a = function(a) {
                    switch (a) {
                        case "before_mounted":
                            return null;
                        case "unmounted":
                            return "EngineAPI.handleReactMount.unmounted";
                        case "mounted":
                            return "EngineAPI.handleReactMount.mounted";
                        default:
                            a;
                            return null
                    }
                }(P);
                a && d("VideoPlayerODS").bumpEntityKey("comet_video_player", a, 1)
            }
            Q() || (P = "mounted", N.addSubscriptions(d("RunComet").onUnload(function() {
                Y("page_unload")
            })), W.dispatch({
                type: "implementation_mounted"
            }), m(["handleReactMount"]))
        };
        g = function() {
            if (!Q()) {
                var a = function(a) {
                    switch (a) {
                        case "unmounted":
                            return "EngineAPI.handleReactUnmount.unmounted";
                        case "before_mounted":
                            return "EngineAPI.handleReactUnmount.before_mounted";
                        case "mounted":
                            return null;
                        default:
                            a;
                            return null
                    }
                }(P);
                a && d("VideoPlayerODS").bumpEntityKey("comet_video_player", a, 1)
            }
            Q() && (P = "unmounted", W.dispatch({
                payload: {
                    reason: "react_effect_cleanup"
                },
                type: "implementation_unmounted"
            }), Y("implementation_unmounted:react_effect_cleanup"))
        };
        w = o({
            concurrentAutoplayManagementAPI: w,
            createExposedState: S,
            debugAPI: e({
                getVideoElementAPI: function() {
                    return R.current
                },
                logger: z
            }),
            fullscreenControllerRef: E,
            logger: z,
            machine: W,
            subscribers: G,
            videoElementAPIRef: R
        });
        e = d("VideoPlayerImplementationStateMachine").createReactVideoElementCallbacksForStateMachine(W, ga);
        var ha = S(W.getInitialState());
        x = {
            destroy: Y,
            handleReactMount: x,
            handleReactPropsChanged: a,
            handleReactUnmount: g,
            implementationController: w,
            initialExposedState: ha,
            logFlusher: C,
            machine: W,
            notifySubscribers: H,
            videoElementCallbacks: e,
            videoElementRefCallback: function(a) {
                ga(a, ["videoElementRefCallback"])
            }
        };
        return {
            engine: x,
            getCaptionsInfo: function() {
                return K.current
            },
            getVideoElement: function() {
                return I.current
            },
            getVideoLiveTrace: function() {
                return y.current
            },
            handleCaptionsInfoChange: ca,
            handleFatalImplementationError: V,
            logger: z,
            machine: W,
            videoElementAPIRef: R
        }
    }

    function v(a, b) {
        var d, e = c("err")(a.errorName + ": " + a.errorDescription);
        e.name = a.errorName;
        e.errorName = a.errorName;
        e.type = "error";
        a.stack != null && a.stack !== "" && (e.stack = a.stack);
        var f = new(c("ErrorMetadata"))();
        f.addEntries(["COMET_VIDEO", "ERROR_LOCATION", a.errorLocation], ["COMET_VIDEO", "ERROR_CODE", (d = a.errorCode) != null ? d : ""], ["COMET_VIDEO", "ERROR_URL", (d = a.url) != null ? d : ""]);
        b != null && f.addEntry("COMET_VIDEO", "VIDEO_ID", b);
        d = a.originalError;
        d != null && (typeof d === "string" ? f.addEntry("COMET_VIDEO", "ORIGINAL_ERROR", d) : d instanceof Error && d.message != null && f.addEntry("COMET_VIDEO", "ORIGINAL_ERROR", d.message));
        e.metadata = f;
        return e
    }

    function e(a, b) {
        var d = k(null),
            e = d[0],
            f = d[1],
            g = j(!1),
            l = j(null);
        d = k(null);
        var m = d[0],
            n = d[1];
        d = a.wrapVideoPixels_EXPERIMENTAL;
        i(function() {
            m || (l.current = null)
        }, [m]);
        var o = j(a),
            p = j(b),
            q = c("useStable")(function() {
                return p.current({
                    debugLogId: String(o.current.loggingMetaData.instanceKey),
                    handleFatalError: function(a) {
                        if (g.current && c("gkx")("1722590")) return;
                        c("gkx")("1444664") ? l.current || (l.current = a, n(a)) : n(a)
                    },
                    initialProps: o.current,
                    setExposedStateInReact: f
                })
            });
        e = (b = e) != null ? b : q.initialExposedState;
        b = (b = e.error) != null ? b : m;
        if (b != null) {
            if (c("killswitch")("COMET_VIDEO_ERROR_DEAGGREGATION")) throw c("unrecoverableViolation")(b.errorName + ": " + b.errorDescription, "comet_video_player", {
                error: b.originalError instanceof Error ? b.originalError : void 0
            });
            var r = a.VideoPlayerShakaPerformanceLoggerClass;
            r && (c("gkx")("2007883") || c("qex")._("1655")) && r.flushQueuedLogs();
            throw v(b, o.current.videoFBID)
        }
        i(function() {
            q.handleReactMount();
            return function() {
                g.current = !0, q.handleReactUnmount()
            }
        }, [q]);
        var s = j(null);
        i(function() {
            a !== s.current && q.handleReactPropsChanged(a), s.current = a
        });
        r = c("useSEOLoggedOutWebCrawler")();
        b = h.jsx(c("VideoPlayerImplementationReactVideoElement.react"), {
            alt: a.alt,
            implementationExposedState: e,
            seoWebCrawlerVideoTracks: r && a.seoWebCrawlerVideoTracks != null ? a.seoWebCrawlerVideoTracks : null,
            src: r ? a.seoWebCrawlerLookasideUrl : null,
            videoElementCallbacks: r ? null : q.videoElementCallbacks,
            videoElementPreloadDisabled: a.preloadForProgressiveDisabled,
            videoElementRefCallback: r ? null : q.videoElementRefCallback
        });
        r = a.renderWithExposedState({
            implementationController: q.implementationController,
            implementationExposedState: e
        });
        d = h.jsxs(h.Fragment, {
            children: [d ? d(b) : b, r]
        });
        return {
            engine: q,
            exposedState: e,
            reactVideoComponents: r,
            reactVideoFrame: b,
            reactVideoFrameAndComponents: d
        }
    }
    g.internal_createVideoPlayerImplementationControllerImpl = n;
    g.internal_createVideoPlayerImplementationEngineStateMachineWithEffects = q;
    g.internal_createVideoPlayerImplementationExposedStateFromStateMachineState = u;
    g.createVideoPlayerImplementationEngine = a;
    g.internal_makeExpandedErrorFromVideoPlayerError = v;
    g.useVideoPlayerImplementationEngine = e
}), 98);
__d("VideoPlayerImplementationEngineVideoElementAPI", ["Promise", "VideoPlaybackQuality", "VideoPlayerOzWWWGlobalConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return isNaN(a) ? 0 : a
    }

    function i(a) {
        return h(a.duration)
    }

    function j(a) {
        a = a.buffered;
        return a.length > 0 ? a.end(a.length - 1) : 0
    }

    function k(a) {
        return h(a.currentTime)
    }

    function l(a) {
        return a.buffered.length === 0 ? 0 : a.buffered.start(0)
    }

    function a(a, e) {
        var f = e !== !0,
            g = null,
            h = function(b) {
                f ? b == null || b === "" ? a.removeAttribute("src") : a.setAttribute("src", b) : g = b
            };
        return {
            exitPictureInPicture: function() {
                window.document.exitPictureInPicture()
            },
            getCanPlayPromise: function() {
                return new(b("Promise"))(function(b, c) {
                    a.readyState === 4 ? b() : a.addEventListener("canplay", function() {
                        return b()
                    })
                })
            },
            getDOMLoadedMetadataPromise: function() {
                return new(b("Promise"))(function(b, c) {
                    a.addEventListener("loadedmetadata", function() {
                        return b()
                    })
                })
            },
            getDroppedFrameCount: function() {
                return d("VideoPlaybackQuality").getDroppedFrames(a)
            },
            getDuration: function() {
                return i(a)
            },
            getEnded: function() {
                return a.ended
            },
            getError: function() {
                return a.error
            },
            getLastBufferEndPosition: function() {
                return j(a)
            },
            getMuted: function() {
                return a.muted
            },
            getNetworkState: function() {
                return a.networkState
            },
            getPaused: function() {
                return a.paused
            },
            getPlaybackRate: function() {
                return a.playbackRate
            },
            getPlayheadPosition: function() {
                return k(a)
            },
            getReadyState: function() {
                return a.readyState
            },
            getTotalFrameCount: function() {
                return d("VideoPlaybackQuality").getTotalFrames(a)
            },
            getUnderlyingVideoElement: function() {
                return a
            },
            getVolume: function() {
                return a.volume
            },
            pause: function() {
                a.pause()
            },
            play: function() {
                f || (f = !0, h(g), g = null);
                var c = a.play();
                c = c && typeof c.then === "function" ? b("Promise").resolve(c) : null;
                return c
            },
            requestPictureInPicture: function() {
                typeof a.requestPictureInPicture === "function" && a.requestPictureInPicture()
            },
            setDuration: function(b) {
                a.duration = b
            },
            setMuted: function(b) {
                a.muted = b
            },
            setPlaybackRate: function(b) {
                a.playbackRate = b
            },
            setPlayheadPosition: function(b) {
                var d = b;
                if (b === 0) {
                    b = c("VideoPlayerOzWWWGlobalConfig").getNumber("clamp_seek_to_first_buffer_range_epsilon", 0);
                    if (b > 0) {
                        var e = l(a);
                        e > 0 && e <= b && (d = e)
                    }
                }
                a.currentTime = d
            },
            setSrc: h,
            setVolume: function(b) {
                a.volume = b
            }
        }
    }
    g.getDurationFromVideoElement = i;
    g.getLastBufferEndPositionFromVideoElement = j;
    g.getPlayheadPositionFromVideoElement = k;
    g.createVideoPlayerImplementationEngineVideoElementAPI = a
}), 98);
__d("VideoPlayerImplementationLoadSequenceManager", ["setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = [], this.$2 = []
        }
        var b = a.prototype;
        b.schedule = function(a, b, d) {
            var e = this,
                f = {
                    load: d,
                    maximumBlockTimeMs: a.getNumber("load_sequence_max_delay_ms", 0),
                    sequence: b
                },
                g = a.getNumber("load_sequence_only_prioritize_first_count", 0);
            g > 0 ? d = !this.$2.find(function(a) {
                return a.sequence < g
            }) : d = !this.$2.find(function(a) {
                return a.sequence < b
            });
            d ? this.$3(f) : (this.$1.push(f), c("setTimeout")(function() {
                return e.$4(f)
            }, f.maximumBlockTimeMs));
            return function() {
                return e.$5(f)
            }
        };
        b.$4 = function(a) {
            var b = this.$1.find(function(b) {
                return b === a
            });
            b && (this.$1 = this.$1.filter(function(b) {
                return b !== a
            }), this.$3(b))
        };
        b.$3 = function(a) {
            var b = this;
            this.$2.push(a);
            a.load().then(function() {
                return b.$6(a)
            })["catch"](function(c) {
                b.$6(a);
                throw c
            });
            c("setTimeout")(function() {
                return b.$6(a)
            }, a.maximumBlockTimeMs)
        };
        b.$7 = function() {
            var a = this,
                b = Math.min.apply(Math, this.$1.map(function(a) {
                    return a.sequence
                })),
                c = this.$1.filter(function(a) {
                    return a.sequence === b
                });
            c.forEach(function(b) {
                return a.$4(b)
            })
        };
        b.$5 = function(a) {
            this.$1 = this.$1.filter(function(b) {
                return b !== a
            })
        };
        b.$6 = function(a) {
            if (!this.$2.find(function(b) {
                    return b === a
                })) return;
            this.$2 = this.$2.filter(function(b) {
                return b !== a
            });
            var b = !!this.$2.find(function(b) {
                return b.sequence === a.sequence
            });
            b && this.$7()
        };
        return a
    }();
    b = new a();
    d = b;
    g["default"] = d
}), 98);
__d("handleVideoPlayerLatencyLevelChange", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c, d) {
        if (a && b && c) {
            var e = a.getAllContexts().latency_level;
            c = [];
            try {
                c = JSON.parse(a.getString("seek_on_latency_level_change_allowed", "[]"))
            } catch (a) {}
            c = c.some(function(a) {
                return a.length === 2 && a[0] === e && a[1] === d
            });
            a.setContext("latency_level", d);
            if (!c) return;
            c = b.getDuration();
            c = c != null ? c + a.getNumber("live_initial_playback_position", 0) : null;
            c != null && b.setPlayheadPosition(c)
        }
    }
    f["default"] = a
}), 66);
__d("VideoPlayerOzImplementationEngineExtrasAPI", ["VideoPlayerOzWWWGlobalConfig", "emptyFunction", "gkx", "handleVideoPlayerLatencyLevelChange", "oz-player/networks/OzBandwidthEstimator"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = c("emptyFunction");

    function h(a) {
        return a.getSelectedVideoQuality()
    }

    function i(a) {
        a = a.getCurrentVideoRepresentation();
        return a == null ? "" : a.getQualityLabel()
    }

    function j(a) {
        a = a.getIsVideoQualityAdaptationEnabled() ? "auto" : a.getSelectedVideoQuality();
        return a
    }

    function k(a) {
        return (a = (a = a.getMpd()) == null ? void 0 : a.getCustomField("fbProjection")) != null ? a : null
    }

    function l(a, b) {
        var c = j(a);
        if (b === "notselected" || b === c) return !1;
        else if (b === "auto") {
            a.enableVideoQualityAdaptation();
            return !0
        } else if (b !== a.getSelectedVideoQuality()) {
            c = b;
            a.switchToVideoQuality(c);
            return !0
        } else return !1
    }

    function a(a) {
        var b = a.getConfig,
            d = a.getOzPlayer,
            e = a.getVideoElementAPI;
        a = {
            getApproximateFBLSToPlayerDisplayLatency: function() {
                var a;
                return (a = (a = d()) == null ? void 0 : a.getApproximateFBLSToPlayerDisplayLatency()) != null ? a : null
            },
            getAudioRepresentationIDAtTime: function(a) {
                var b;
                b = (b = d()) == null ? void 0 : b.getAudioRepresentationIDAtTime(a);
                return (a = b) != null ? a : null
            },
            getAvailableVideoQualities: function() {
                var a;
                return (a = (a = d()) == null ? void 0 : a.getVideoQualities()) != null ? a : []
            },
            getCurrentAudioRepresentation: function() {
                var a;
                return (a = (a = d()) == null ? void 0 : a.getCurrentAudioRepresentation()) != null ? a : null
            },
            getCurrentPlayingVideoQuality: function() {
                var a = d();
                return a ? i(a) : ""
            },
            getCurrentTargetVideoQuality: function() {
                var a = d();
                return a ? h(a) : ""
            },
            getCurrentVideoRepresentation: function() {
                var a;
                return (a = (a = d()) == null ? void 0 : a.getCurrentVideoRepresentation()) != null ? a : null
            },
            getEstimatedBandwidth: function() {
                return c("oz-player/networks/OzBandwidthEstimator").getBandwidth(c("VideoPlayerOzWWWGlobalConfig"))
            },
            getInbandCaptionsAutogeneratedFromManifest: function() {
                var a;
                a = (a = d()) == null ? void 0 : a.getMpd();
                return Boolean(a == null ? void 0 : a.getCustomField("hasInbandCaptionsFromUsingASRCaptions"))
            },
            getInbandCaptionsExpectedFromManifest: function() {
                var a;
                a = (a = d()) == null ? void 0 : a.getMpd();
                return Boolean(a == null ? void 0 : a.getCustomField("hasInbandCaptionsFromUsingASRCaptions")) || Boolean(a == null ? void 0 : a.getCustomField("hasInbandCaptionsFromAccessibility"))
            },
            getManifestIdentifier: function() {
                var a;
                a = (a = d()) == null ? void 0 : (a = a.getMpd()) == null ? void 0 : a.getCustomField("fbManifestIdentifier");
                return a != null ? String(a) : null
            },
            getMpdValidationErrors: function() {
                var a;
                a = (a = d()) == null ? void 0 : (a = a.getMpd()) == null ? void 0 : a.getCustomField("validationErrors");
                return a != null ? String(a) : null
            },
            getPerfLoggerProvider: function() {
                var a = d();
                return a ? a.getPerfLoggerProvider() : null
            },
            getRepresentationCaptionsExpectedFromManifest: function() {
                var a;
                a = (a = d()) == null ? void 0 : a.getMpd();
                return Boolean(a == null ? void 0 : a.getCustomField("hasVTTRepresentationCaptions"))
            },
            getStreamType: function() {
                return "dash"
            },
            getUserSelectedVideoQuality: function() {
                var a = d();
                return a ? j(a) : ""
            },
            getVideoProjectionType: function() {
                var a = d();
                return a != null ? k(a) : null
            },
            getVideoRepresentationIDAtTime: function(a) {
                var b;
                b = (b = d()) == null ? void 0 : b.getVideoRepresentationIDAtTime(a);
                return (a = b) != null ? a : null
            },
            getVideoRepresentations: function() {
                var a;
                return (a = (a = d()) == null ? void 0 : (a = a.getMpd()) == null ? void 0 : a.getVideoRepresentations()) != null ? a : null
            },
            isDrm: function() {
                var a;
                return Boolean((a = d()) == null ? void 0 : a.isDrm())
            },
            isFBIsLiveTemplated: function() {
                var a;
                a = (a = d()) == null ? void 0 : a.getMpd();
                return Boolean(a == null ? void 0 : a.getCustomField("isLiveTemplated"))
            },
            isFBMS: function() {
                var a;
                a = (a = d()) == null ? void 0 : a.getMpd();
                return Boolean(a == null ? void 0 : a.getCustomField("isFBMS"))
            },
            isFBWasLive: function() {
                var a;
                a = (a = d()) == null ? void 0 : a.getMpd();
                return Boolean(a == null ? void 0 : a.getCustomField("isFBWasLive"))
            },
            isPredictiveDash: function() {
                var a;
                a = (a = (a = d()) == null ? void 0 : (a = a.getMpd()) == null ? void 0 : a.getVideoRepresentations()[0]) != null ? a : null;
                return a !== null && a.canPredict()
            },
            setDimensions: function(a) {},
            setEnableLiveheadCatchup: function(a) {
                var b = d();
                b != null && b.setEnableLiveheadCatchup(a)
            },
            setLatencyLevel: function(a) {
                c("handleVideoPlayerLatencyLevelChange")(b(), e(), d(), a)
            },
            setUserSelectedVideoQuality: function(a) {
                var b = d();
                b != null && l(b, a)
            }
        };
        return a
    }
    g.createVideoPlayerOzImplementationEngineExtrasAPI = a
}), 98);
__d("OzBufferVTTCaptionsVisibleStrategy", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            this.$1 = a
        }
        var b = a.prototype;
        b.isActive = function() {
            return !this.$1()
        };
        b.getBufferTarget = function() {
            return 0
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("OzSystemicRiskABRManager", ["MosUtils", "OzSystemicRiskUtils", "oz-player/networks/OzBandwidthEstimator", "oz-player/utils/OzAbrUtils", "oz-player/utils/OzBufferingUtils", "oz-player/utils/OzPlaybackRestrictionsUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6e4,
        i = 2e3,
        j = {
            BANDWIDTH: "br",
            BUFFER: "vb",
            ENCODING: "er",
            LOW_MOS: "lm",
            MULTIPLIER: "m",
            PREVIOUS_MOS: "pm",
            PREVIOUS_RESOLUTION: "pr"
        };
    a = function() {
        function a(a, b, c, d, e, f, g, h) {
            this.$11 = !1, this.$1 = a, this.$2 = b, this.$3 = c, this.$4 = d, this.$5 = e, this.$7 = f, this.$8 = g, this.$9 = h
        }
        var b = a.prototype;
        b.setSourceBuffer = function(a) {
            this.$6 = a
        };
        b.updateRepresentations = function(a) {
            var b = this;
            this.$3 = a;
            a = this.$3.find(function(a) {
                return a.getQualityLabel() === b.$2.getQualityLabel()
            });
            this.$2 = (a = a) != null ? a : this.$3[0]
        };
        b.getBestRepresentation = function(a) {
            var b = this.$1.getLegacyConfig(),
                e = d("oz-player/utils/OzBufferingUtils").getBufferAheadFromPlaybackStates(this.$6, this.$5),
                f = this.$5.getDuration();
            f = isNaN(f) ? h : f;
            if (this.$3.length === 0) {
                this.$10 = "no available representations";
                return this.$2
            }
            var g = this.$5.getCurrentTime();
            f = this.$9 === "static" ? (f - g) * 1e3 : h;
            g = this.$8();
            a = b.getBool("systemic_risk_use_fetch_range_duration", !1) ? this.$12(a) : i;
            var j = b.getBool("use_bandwidth_estimate_from_headers_in_abr", !1) ? c("oz-player/networks/OzBandwidthEstimator").getBandwidthDiagnosticsFromHeaders(b) : c("oz-player/networks/OzBandwidthEstimator").getBandwidthDiagnostics(b);
            if (j == null) {
                this.$10 = "missing bandwidth diagnostics";
                return this.$2
            }
            var k = this.$13(this.$3).sort(function(a, b) {
                    return a.getBandwidth() - b.getBandwidth()
                }),
                l = null,
                m = null,
                n = null;
            for (var o = 0; o < k.length; o++) {
                var p = k[Math.max(o - 1, 0)],
                    q = this.$14(p, g);
                p = Math.min(p.getHeight(), p.getWidth());
                m = d("OzSystemicRiskUtils").getRiskFactorsForRepresentation({
                    bandwidthDiagnostics: j,
                    bitrate: k[o].getBandwidth(),
                    bufferAhead: e,
                    config: this.$1.getLegacyConfig(),
                    hasMadeInitialDecision: this.$11,
                    initialRiskFactor: b.getNumber("systemic_risk_abr_initial_risk_factor", 1),
                    lowMosResolution: b.getNumber("systemic_risk_abr_low_mos_resolution", 0),
                    minWatchableMos: b.getNumber("systemic_risk_abr_min_watchable_mos", 0),
                    previousMos: q,
                    previousResolution: p,
                    remainingVideoDurationMs: f,
                    segmentFetchRangeDurationMs: a
                });
                q = m;
                p = q.multiplier;
                if (isNaN(p)) {
                    n = m;
                    l = this.$2;
                    break
                }
                q = d("OzSystemicRiskUtils").isEffectiveBitrateBelowBandwidthEstimate(k[o].getBandwidth(), m.multiplier, a, j);
                if (q) n = m, l = k[o];
                else break
            }
            l == null ? this.$2 = b.getBool("respect_playback_restrictions_in_abr_fallback", !1) && k.length > 0 ? k[0] : this.$3[0] : this.$2 = l;
            this.$15((p = n) != null ? p : m, {
                isSystemicRiskABREnabled: b.getBool("use_systemic_risk_abr", !1),
                noRepresentationSelected: l == null,
                representationCount: k.length
            });
            this.$11 || (this.$11 = !0);
            return this.$2
        };
        b.$12 = function(a) {
            var b = i;
            if (a != null && a.length > 0) {
                var c = a[0].getTimeRange().startTime;
                a = a[a.length - 1].getTimeRange().endTime;
                a - c > 0 && (b = (a - c) * 1e3)
            }
            return b
        };
        b.$14 = function(a, b) {
            a = a.getCustomField("playbackResolutionMos");
            a = d("MosUtils").parsePlaybackMos(String(a));
            return a != null ? d("MosUtils").getMosValue(a, d("MosUtils").getQualityLabel(b.width, b.height)) : null
        };
        b.$13 = function(a) {
            var b = this;
            if (!this.$1.getLegacyConfig().getBool("systemic_risk_abr_apply_representation_restrictions", !1)) return a;
            var c = this.$1.getLegacyConfig().getBool("exclude_large_representations_after_restrictions", !1),
                e = a;
            a = function() {
                e = d("oz-player/utils/OzAbrUtils").excludeLargeRepresentations(b.$1, e, b.$8(), b.$7)
            };
            var f = function() {
                e = d("oz-player/utils/OzPlaybackRestrictionsUtils").applyVideoPlaybackRestrictions(b.$1, b.$4, b.$8(), e)
            };
            c || (a(), f());
            c && (f(), a());
            return e
        };
        b.$15 = function(a, b) {
            if (a == null) return;
            var c = b.isSystemicRiskABREnabled,
                d = b.noRepresentationSelected;
            b = b.representationCount;
            this.$10 = [
                [j.LOW_MOS, a.lowMos],
                [j.ENCODING, a.encoding],
                [j.BANDWIDTH, a.bandwidth],
                [j.MULTIPLIER, a.multiplier],
                [j.BUFFER, a.buffer],
                [j.PREVIOUS_MOS, a.previousMos],
                [j.PREVIOUS_RESOLUTION, a.previousResolution]
            ].reduce(function(a, b) {
                var c = b[1],
                    d = "";
                switch (typeof c) {
                    case "number":
                        d = c.toFixed(1);
                        break;
                    case "boolean":
                        d = c ? "1" : "0";
                        break;
                    default:
                        d = "null"
                }
                return a + (b[0] + ": " + d + ";")
            }, "");
            c || (this.$10 += "disabled;");
            d && (this.$10 += "none-selected-of-" + b + ";")
        };
        b.getLastEvaluationReason = function() {
            return this.$10
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoPlayerOzImplementationEnginePartsImplUtils", ["OzSystemicRiskABRManager", "OzWidevineDrmProvider", "cr:72", "gkx", "justknobx", "oz-player/networks/OzBandwidthEstimator", "oz-player/strategies/OzBufferingDetector", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = /(livestream-)?lookaside\.(facebook|workplace)\.com$/,
        i = c("qex")._("1658");

    function j(a) {
        return i != null && i !== "" ? i : null
    }

    function a(a) {
        return h.test(a.getDomain())
    }

    function b(a, b, d, e, f, g) {
        if (f.current != null) return;
        var h = !0,
            i = function() {
                if (h) return !1;
                var a = f.current !== j;
                return a && c("gkx")("1508440") ? !0 : !1
            },
            j = new(c("oz-player/strategies/OzBufferingDetector"))(a, d, function() {
                var a = e.getCurrentState();
                a = a.controlledState;
                return a.streamEnded ? b.getDuration() : Infinity
            });
        f.current = j;
        h = !1;
        a = function(a) {
            if (i()) return;
            if (c("gkx")("1235655")) return;
            e.dispatch({
                payload: {
                    bufferingType: a
                },
                type: "buffering_begin_requested"
            });
            a = d.getNumber("ull_fallback_stall_count", 0);
            a > 0 && (e.getCurrentState().controlledState.latencyLevel === "ultra-low" && g.getLoggerState().stallCountTotal > a && e.dispatch({
                payload: {
                    latencyLevel: "low"
                },
                type: "implementation_set_latency_level_requested"
            }))
        };
        var k = function(a) {
            if (i()) return;
            e.dispatch({
                payload: {
                    domEventPerfTimestamp: a.domEventPerfTimestamp
                },
                type: "buffering_end_requested"
            })
        };
        j.addListener("enterBuffering", a);
        j.addListener("leaveBuffering", k)
    }

    function d(a) {
        var b = a.accessToken,
            d = a.graphQLVideoDRMInfo;
        a = a.videoFBID;
        var e = [];
        if (d && a != null) {
            var f = c("justknobx")._("717") ? null : d.widevineCert;
            e.push(new(c("OzWidevineDrmProvider"))(a, d.graphApiVideoLicenseUri, d.videoLicenseUriMap, b, (a = f) != null ? a : null))
        }
        return e
    }

    function e(a) {
        var b = a.VideoPlayerShakaPerformanceLoggerClass,
            c = a.accessToken,
            d = a.disableLogging,
            e = a.getApproximateFBLSToPlayerDisplayLatency,
            f = a.getBandwidthEstimate,
            g = a.getPlayerDimensions,
            h = a.getPlayerFormat,
            i = a.playbackIsLiveStreaming,
            j = a.playerInstanceCount,
            k = a.playerInstanceKey,
            l = a.playerSuborigin,
            m = a.playerVersion,
            n = a.videoElement,
            o = a.videoFBID;
        a = a.videoPlayerShakaPerformanceLoggerBuilder;
        if (d || !a && (!b || !b.shouldInitialize())) return [];
        c = {
            accessToken: c,
            getApproximateFBLSToPlayerDisplayLatency: e,
            getBandwidthEstimate: f,
            getPlayerDimensions: g,
            getPlayerFormat: h,
            isLive: i,
            isServableViaFbms: !1,
            playerInstanceCount: j,
            playerOrigin: null,
            playerSuborigin: l,
            playerVersion: m,
            representationId: null,
            uniqueID: k,
            video: n,
            videoID: (d = o) != null ? d : ""
        };
        return a != null ? [a.build(c)] : b ? [new b(c)] : []
    }

    function f(a, b) {
        return b > 0 ? b / 1e3 * -1 : a.getNumber("live_initial_playback_position", 0)
    }

    function k(a, b, c) {
        return b > 0 && c > 0 ? (b + c) / 1e3 : a.getNumber("livehead_fall_behind_block_threshold", 0)
    }

    function l(a, b) {
        return b > 0 ? b / 2 / 1e3 : a.getNumber("live_time_range_block_margin", 0)
    }

    function m() {
        return function(a, b, d, e, f, g, h, i) {
            return a.getLegacyConfig().getBool("use_systemic_risk_abr", !1) ? new(c("OzSystemicRiskABRManager"))(a, b, d, e, f, g, h, i) : null
        }
    }

    function n(a, b) {
        var d = b.experimentationConfig,
            e = b.getCurrentVideoRepresentation,
            f = b.getOzCDNSignedQueryParams,
            g = b.isClientTriggeredTraceEnabled,
            h = b.playbackIsLiveStreaming,
            i = b.playbackSessionId;
        b = b.shouldRefresh403;
        var k = a.getQueryData(),
            l;
        if (h) {
            l = {};
            var m = j(a);
            m !== null && m !== "" && (l = babelHelpers["extends"]({}, l, {
                os_param: m
            }));
            if (d.getBool("server_side_abr_send_client_estimates", !1)) {
                m = c("oz-player/networks/OzBandwidthEstimator").getBandwidthDiagnostics(d);
                m && (l = babelHelpers["extends"]({}, l, {
                    _nc_bwe: String(m.bandwidthEstimate),
                    _nc_bwe_std: String(m.bandwidthStandardDeviation),
                    _nc_ttfb: String(m.timeToFirstByteMsEstimate),
                    _nc_ttfb_std: String(m.timeToFirstByteMsStandardDeviation)
                }));
                d = e();
                d && (l = babelHelpers["extends"]({}, l, {
                    _nc_abr_bitrate: String(d.getBandwidth()),
                    _nc_abr_qlabel: d.getQualityLabel()
                }))
            }
            c("gkx")("2047") && (l = babelHelpers["extends"]({}, l, {
                _nc_wclk: "1",
                _nc_wclk_ms: "1"
            }))
        }
        h && c("gkx")("1998922") && (l = babelHelpers["extends"]({}, l, {
            _nc_nc: "1"
        }));
        c("gkx")("1836350") && (k.uss != null && k.odm != null && (l = babelHelpers["extends"]({}, l, {
            manual_redirect: "1"
        })));
        g && (l = babelHelpers["extends"]({}, l, {
            _nc_psid: i
        }));
        if (b) {
            m = f();
            if (m != null) {
                e = a.getDomain() + a.getPath();
                d = m.get(e);
                if (d != null)
                    for (var h in d) {
                        l = babelHelpers["extends"]({}, l, (k = {}, k[h] = d[h], k))
                    }
            }
        }
        return l
    }
    g.getOsParamValue = j;
    g.checkShouldIncludeCredentials = a;
    g.createOzBufferingDetector = b;
    g.createOzDrmProviders = d;
    g.createOzPerfLoggerProviders = e;
    g.calculateInitialPlaybackPositionForDynamicMpd = f;
    g.calculateLiveheadFallBehindBlockThreshold = k;
    g.calculateLiveheadFallBehindBlockMargin = l;
    g.getVideoAbrManagerFactory = m;
    g.getCustomRequestParametersForURI = n
}), 98);
__d("VideoPlayerOzImplementationEnginePartsImplFunction", ["CometThrottle", "ConstUriUtils", "Deferred", "FBLogger", "NetworkStatus", "OzActiveActiveFailoverNetworkRequestStreamHandler", "OzBufferVTTCaptionsVisibleStrategy", "OzCDNSignedQueryParams", "OzCustomParsers", "OzCustomRepresentationParsers", "OzOneSemanticHandler", "OzOneSemanticHandlerUtils", "OzPredictedSegmentTimelineParser", "OzVideoLiveTraceNetworkRequestStreamHandler", "Promise", "QE2Logger", "TimeRanges", "VideoPlayerConnectionQuality", "VideoPlayerImplementationErrors", "VideoPlayerOzImplementationEnginePartsImplUtils", "clearTimeout", "cr:1836099", "cr:1871597", "cr:1947728", "cr:1993377", "cr:4964", "getErrorSafe", "getOzPlaybackRestrictions", "gkx", "md5", "oz-player/configs/OzConfigUtils", "oz-player/networks/OzBandwidthEstimator", "oz-player/networks/OzClockSyncNetworkRequestStreamHandler", "qex", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f = (e = b("cr:4964")) != null ? e : {
        parseEmsgBoxesFromMP4Segment: null
    };
    var h = f.parseEmsgBoxesFromMP4Segment,
        i = (e = c("qex")._("592")) != null ? e : 1e4,
        j = null,
        k = null;
    b("cr:1836099") && (j = b("cr:1836099").getHiveConfig(), k = b("cr:1836099").HiveOz);

    function a(a) {
        var e, f = a.OzPlayerClass,
            g = a.callChain,
            l = a.destroyOzPlayerPartsRef,
            m = a.engineDebugAPI,
            n = a.engineExtrasAPI,
            o = a.getCaptionsInfo,
            aa = a.getLatencyLevelManager,
            p = a.getVideoLiveTrace,
            q = a.handleCaptionsInfoChange,
            ba = a.handleFatalImplementationError,
            r = a.hivePluginRef,
            s = a.initialProps,
            t = a.logger,
            u = a.machine,
            v = a.overrideOzRequestImplementationRef,
            w = a.ozBufferingDetectorRef,
            x = a.ozPlayerRef,
            y = a.p2pSessionLoggerRef,
            z = a.playerVersion,
            A = a.resolvedVideoInfo,
            B = a.videoElement,
            C = {
                current: !1
            },
            D = {
                current: null
            },
            E = {
                current: null
            };
        l.current = function(a) {
            var b = w.current;
            b && (w.current = null, b.destroy());
            b = x.current;
            if (b) {
                m && m.handleOzPlayerChanged(null);
                x.current = null;
                try {
                    b.destroy([].concat(a, ["destroyOzPlayerParts"]).join(":"))
                } catch (a) {
                    c("FBLogger")("comet_video_player").catching(a).mustfix("Error in ozPlayer.destroy: %s", String(a))
                }
            }
            b = D.current;
            b && (D.current = null, b());
            E.current && (E.current = null);
            Z();
            r.current && (r.current = null);
            y.current && (y.current = null);
            v.current && (v.current = null)
        };
        a = A.accessToken;
        l = A.audioOnly;
        var F = A.experimentationConfig,
            G = A.graphQLVideoDRMInfo,
            H = A.graphQLVideoP2PSettings,
            I = A.manifestUrl,
            ca = A.manifestXmlStringResolved,
            da = A.minQualityPreference,
            ea = A.ozPrefetchCache,
            J = A.videoFBID,
            K = s.disableLogging ? null : A.VideoPlayerShakaPerformanceLoggerClass,
            L = Boolean(s.loggingMetaData.coreVideoPlayerMetaData.isLiveStreaming),
            M = Boolean((e = s.isClientTriggeredTraceEnabled) != null ? e : !1),
            N = function(a) {
                return n.getEstimatedBandwidth()
            };
        e = function() {
            return n.getApproximateFBLSToPlayerDisplayLatency()
        };
        var fa = function() {
                F.setContext("connection_quality", d("VideoPlayerConnectionQuality").evaluate(function() {
                    return N(L)
                }))
            },
            O = function() {
                var a = F.getNumber("connection_quality_context_throttle_frequency", 0);
                if (a === 0) return null;
                var b = c("CometThrottle")(fa, a),
                    d = c("oz-player/networks/OzBandwidthEstimator").addListener("bandwidth_sampled", b);
                return function() {
                    d.remove(), b.cancel()
                }
            };
        D.current = O();
        O = d("VideoPlayerOzImplementationEnginePartsImplUtils").createOzDrmProviders({
            accessToken: a,
            graphQLVideoDRMInfo: G,
            videoFBID: J
        });
        G = function() {
            return u.getCurrentState().controlledState.captionsVisible
        };
        var P = [];
        F.getBool("use_vtt_captions_visible_buffer_strategy", !0) && P.push(new(c("OzBufferVTTCaptionsVisibleStrategy"))(G));
        G = function() {
            return u.getCurrentState().controlledState.dimensions
        };
        var Q = function() {
            return u.getCurrentState().controlledState.playerFormat
        };
        a = d("VideoPlayerOzImplementationEnginePartsImplUtils").createOzPerfLoggerProviders({
            VideoPlayerShakaPerformanceLoggerClass: K,
            accessToken: a,
            disableLogging: s.disableLogging,
            getApproximateFBLSToPlayerDisplayLatency: e,
            getBandwidthEstimate: N,
            getPlayerDimensions: G,
            getPlayerFormat: Q,
            playbackIsLiveStreaming: L,
            playerInstanceCount: s.loggingMetaData.playerImplementationInstanceCountRef.current,
            playerInstanceKey: s.loggingMetaData.instanceKey,
            playerSuborigin: s.loggingMetaData.coreVideoPlayerMetaData.subOrigin,
            playerVersion: z,
            videoElement: B,
            videoFBID: J,
            videoPlayerShakaPerformanceLoggerBuilder: A.videoPlayerShakaPerformanceLoggerBuilder
        });
        E.current == null && (E.current = new(c("OzCDNSignedQueryParams"))());
        if (H && J != null) {
            e = H.community_info;
            Q = H.config;
            z = H.hive_initialization_options;
            A = y.current = (A = y.current) != null ? A : b("cr:1871597") ? new(b("cr:1871597"))(J, e) : null;
            try {
                if (!r.current) {
                    A && A.logEnableP2P();
                    e = function(a) {
                        y.current && y.current.logHiveError(a)
                    };
                    var R = function(b) {
                            var a = x.current;
                            a && a.injectExternalDebugEvent("P2PTech", b.tech);
                            y.current && y.current.logSessionActive(b.tech)
                        },
                        S = function(b) {
                            var a = x.current;
                            a && a.injectExternalDebugEvent("P2PStats", b);
                            y.current && y.current.setCurrentHiveStats(b)
                        },
                        T = function(a) {
                            a = a.state;
                            var b = u.getCurrentState();
                            b = b.controlledState;
                            b = b.playbackState;
                            if (r.current && a === "CLOSED") {
                                Z();
                                a = x.current;
                                a && b !== "ended" && (C.current && I != null ? a.updatePlayerRunTimeConfig({
                                    manifestUrl: I
                                }) : a.load(I))
                            }
                        };
                    S = {
                        HiveJava: {},
                        HiveJS: {
                            maximumTrimming: {
                                dash: void 0,
                                hls: void 0
                            },
                            renderStatsCallback: S
                        },
                        debugLevel: "off",
                        hiveTechOrder: ["HiveJS", "StatsJS", "HiveJava"],
                        onActiveSession: R,
                        onError: e,
                        onSessionStateChange: T,
                        telemetryId: A ? A.getSessionID() : 0
                    };
                    R = F.getNumber("hive_maximum_trimming_seconds", 0);
                    R > 0 && (S.HiveJS.maximumTrimming = {
                        dash: R,
                        hls: R
                    });
                    if (z) {
                        e = z.HiveJava;
                        T = z.debugLevel;
                        R = z.hiveTechOrder;
                        S.hiveTechOrder = R.slice();
                        S.HiveJava = e ? {
                            minVersion: e.minVersion
                        } : {};
                        S.debugLevel = (z = T) != null ? z : S.debugLevel
                    }
                    c("gkx")("2047688") && (S = babelHelpers["extends"]({}, S, {
                        testId: "fb_video_player_p2p_jest_e2e"
                    }));
                    if (Q.disable_hivejava_for_livevc === !0 && I != null && I.startsWith("https://livestream-lookaside")) {
                        R = S.hiveTechOrder.indexOf("HiveJava");
                        R >= 0 && S.hiveTechOrder.splice(R, 1)
                    }
                    if (j) j.SensitiveInfo.restrictedConnectivityInfo = !0;
                    else throw c("unrecoverableViolation")("HiveConfig does not exist", "comet_video_player");
                    if (k) r.current = new k(S);
                    else throw c("unrecoverableViolation")("HiveOz does not exist", "comet_video_player");
                    if (r.current) {
                        if (!b("cr:1947728")) throw c("unrecoverableViolation")("OzConfigurableRequestImplementation does not exist", "comet_video_player");
                        v.current = b("cr:1947728")(r.current.getRequestImplementation(), {
                            inferResponseStatusIsOK: c("gkx")("3951"),
                            inferResponseStatusIsOk2xx: c("gkx")("277")
                        })
                    }
                }
            } catch (a) {
                A && A.logError(a), Z()
            }
        }
        e = [new(c("OzVideoLiveTraceNetworkRequestStreamHandler"))(function(a, b, c) {
            var d = p();
            d != null && d.handleHeadersAndBody(a, b, c)
        }, F.getBool("live_trace_parse_emsg", !1)), new(c("oz-player/networks/OzClockSyncNetworkRequestStreamHandler"))()];
        c("OzActiveActiveFailoverNetworkRequestStreamHandler") && e.push(new(c("OzActiveActiveFailoverNetworkRequestStreamHandler"))(function(a, b) {
            if (c("gkx")("1664503")) {
                var e = x.current,
                    f = a.headers;
                if (e && f) {
                    f = parseInt(f.get("x-fb-video-replica"), 10);
                    t.logVPLEvent({
                        eventType: "replica_switch",
                        logDataOverrides: {
                            error_code: a.status.toString(),
                            error_user_info: JSON.stringify({
                                failover_response_code: a.status.toString(),
                                replica: f,
                                url: b
                            })
                        },
                        state: u.getCurrentState()
                    });
                    a = e.getMpdUrl();
                    if (a != null) {
                        b = d("ConstUriUtils").getUri(a);
                        if (b) {
                            a = b.addQueryParam("replica", f);
                            a && (Z(), e.updatePlayerRunTimeConfig({
                                manifestUrl: a.toString(),
                                resetStreamAnchor: !0
                            }))
                        }
                    }
                }
            }
        }));
        var U = s.expiredVideoUrlRefreshHandler,
            ga = s.loggingMetaData.instanceKey;
        T = c("gkx")("221");
        z = c("gkx")("1836350") || c("gkx")("1993562");
        var V = L ? T : z;
        F.getBool("log_exposure_on_oz_initialization", !1) && d("QE2Logger").logExposureForUser("www_videos_html5_mpeg_dash");
        Q = {
            audioOnly: (Q = l) != null ? Q : !1,
            bufferEndLimit: s.bufferEndLimit != null ? s.bufferEndLimit : null,
            bufferingDetector: (R = w.current) != null ? R : void 0,
            config: d("oz-player/configs/OzConfigUtils").provideConfigWithDefaults(F),
            configureCustomRequestParametersForSegment: function(a) {
                var b = null;
                if (L && M) {
                    var d = a.getByteRange();
                    d = d ? d.startByte + ", " + (d.endByte != null ? d.endByte : "null") : "null";
                    a = c("md5")(a.getURI().toString() + d);
                    b = (d = b) != null ? d : {};
                    a != null && (b = babelHelpers["extends"]({}, b, {
                        _nc_tsid: a
                    }));
                    b = babelHelpers["extends"]({}, b, {
                        _nc_e2e: "live"
                    })
                }
                return b
            },
            customParsers: d("OzCustomParsers").createOzCustomParser(),
            customRepresentationParsers: d("OzCustomRepresentationParsers").createOzCustomRepresentationParsers({
                ozConfig: F
            }),
            customSegmentTimelineParser: F.getBool("enable_predictive_dash", !1) ? new(c("OzPredictedSegmentTimelineParser"))() : void 0,
            customVTTBufferTargetStrategies: P,
            debugCreateInitiator: [].concat(g, ["proceedWithOzPlayerCreation"]).join(":"),
            drmProviders: O,
            getCustomRequestParametersForURI: function(a) {
                return d("VideoPlayerOzImplementationEnginePartsImplUtils").getCustomRequestParametersForURI(a, {
                    experimentationConfig: F,
                    getCurrentVideoRepresentation: function() {
                        var a = x.current;
                        return a == null ? void 0 : a.getCurrentVideoRepresentation()
                    },
                    getOzCDNSignedQueryParams: function() {
                        return E.current
                    },
                    isClientTriggeredTraceEnabled: M,
                    playbackIsLiveStreaming: L,
                    playbackSessionId: ga,
                    shouldRefresh403: V
                })
            },
            getOverrideOzRequestImplementation: function() {
                return v.current
            },
            getShouldIncludeCredentials: F.getBool("use_oz_credentials_provider", !1) ? d("VideoPlayerOzImplementationEnginePartsImplUtils").checkShouldIncludeCredentials : null,
            getVideoDimensions: G,
            initialPlaybackPositionForDynamicMpd: d("VideoPlayerOzImplementationEnginePartsImplUtils").calculateInitialPlaybackPositionForDynamicMpd(F, (S = s.initialDesiredLatencyMs) != null ? S : 0),
            initialRepresentationIDs: (A = s.initialRepresentationIds) != null ? A : [],
            isClientTriggeredTraceEnabled: M,
            liveheadFallBehindBlockMargin: d("VideoPlayerOzImplementationEnginePartsImplUtils").calculateLiveheadFallBehindBlockMargin(F, (T = s.initialDesiredLatencyMs) != null ? T : 0),
            liveheadFallBehindBlockThreshold: d("VideoPlayerOzImplementationEnginePartsImplUtils").calculateLiveheadFallBehindBlockThreshold(F, (z = s.initialDesiredLatencyMs) != null ? z : 0, (l = s.initialLatencyToleranceMs) != null ? l : 0),
            loggerConfig: {
                isOzDevConsoleEnabled: c("gkx")("722076"),
                observedOperationLoggers: [],
                perfLoggerProviders: a
            },
            mpdUrl: I,
            networkRequestStreamHandlers: e,
            networkRequestStreamRetryHandler: V ? function(a, d, e) {
                var f = a.headers,
                    g = f == null ? void 0 : f.get("x-fb-url-refresh"),
                    h = E.current;
                if (a.status === 403 && h != null) {
                    t.logVPLEvent({
                        eventType: "video_cdn_url_expired",
                        logDataOverrides: {
                            error_user_info: JSON.stringify({
                                expired_url: e
                            })
                        },
                        state: u.getCurrentState()
                    });
                    var i = g != null && b("cr:1993377") != null ? {
                        name: "refreshShortExpiryVideoUrl",
                        promise: b("cr:1993377")(g)
                    } : U != null ? {
                        name: "expiredVideoUrlRefreshHandler",
                        promise: U(e)
                    } : null;
                    if (i != null) return i.promise.then(function(a) {
                        var b;
                        b = (b = a.refreshedUrl) != null ? b : null;
                        a = (a = a.reason) != null ? a : null;
                        if (b != null && (c("gkx")("5837") ? b !== "" : !0)) {
                            t.logVPLEvent({
                                eventType: "video_cdn_url_refreshed",
                                logDataOverrides: {
                                    error_user_info: JSON.stringify({
                                        refresh_handler: i.name,
                                        refreshed_url: b
                                    })
                                },
                                state: u.getCurrentState()
                            });
                            h.update(b);
                            return d(b)
                        } else {
                            throw c("unrecoverableViolation")(i.name + " refreshedUrl is " + (b === "" ? "an empty string" : "null") + ", reason: " + ((b = a) != null ? b : "null"), "comet_video_player")
                        }
                    })["catch"](function(a) {
                        a = c("gkx")("5837") ? c("getErrorSafe")(a) : a;
                        t.logVPLEvent({
                            eventType: "video_cdn_url_refresh_error",
                            logDataOverrides: {
                                error_description: a.message,
                                error_user_info: JSON.stringify({
                                    expired_url: e,
                                    refresh_handler: i.name,
                                    refresh_url: g
                                })
                            },
                            state: u.getCurrentState()
                        });
                        throw a
                    })
                }
                return b("Promise").resolve(a)
            } : null,
            prefetchCache: F.getBool("use_prefetch_cache", !1) ? ea : null,
            rawMpdXml: r.current ? void 0 : ca,
            seekHandler: c("gkx")("1482680") ? function(a) {
                var b = B.currentTime;
                u.dispatch({
                    payload: {
                        seekSourcePosition: b
                    },
                    type: "implementation_seek_requested"
                });
                B.currentTime = a
            } : null,
            setCustomFetchStreamLoggingAttributes: function(a, b, e) {
                a.setIsOnline(c("NetworkStatus").isOnline());
                if (c("gkx")("951")) {
                    var f = e == null ? void 0 : e.headers;
                    if (f) try {
                        a.setProxyStatusHeader(f.get("proxy-status")), a.setDynamicStatusHeader(f.get("x-fb-dynamic-status"))
                    } catch (a) {}
                }
                d("OzOneSemanticHandlerUtils").setOneSemanticFetchStreamLoggingAttributes(a, b, e)
            },
            startTimeStamp: F.getBool("fix_start_timestamp", !1) ? s.startTimestamp : 0,
            videoAbrManagerFactory: d("VideoPlayerOzImplementationEnginePartsImplUtils").getVideoAbrManagerFactory(),
            videoNode: B,
            videoPlaybackRestrictions: c("getOzPlaybackRestrictions")(da, F)
        };
        var W = new f(Q);
        x.current = W;
        w.current && w.current.attachPerfLoggerProvider(W.getPerfLoggerProvider());
        R = s.loggingMetaData.playerImplementationInstanceCountRef;
        R.current++;
        W.onError(function(a) {
            K && K.flushQueuedLogs(), ba(a, "oz_player_error")
        });
        W.addListener("switchVideoRepresentation", function() {
            u.dispatch({
                payload: {
                    targetVideoQuality: n.getCurrentTargetVideoQuality()
                },
                type: "representation_changed"
            })
        });
        var ha = function(a) {
            if (F.getBool("enable_error_recovery_attempt_logging", !1)) {
                a = d("VideoPlayerImplementationErrors").createVideoPlayerErrorFromOzImplementationError(a, "oz_player_stream_error_retry");
                u.dispatch({
                    payload: {
                        recoverableError: a
                    },
                    type: "error_recovery_attempt"
                })
            }
        };
        W.addListener("manifestFetchError", function(a) {
            d("OzOneSemanticHandler").handleManifestFetchErrorEvent(F, a)
        });
        W.addListener("manifestFetchErrorRetry", function(a) {
            ha(a)
        });
        W.addListener("streamError", function(a) {
            return d("OzOneSemanticHandler").handleStreamErrorEvent(F, a)
        });
        W.addListener("streamErrorRetry", function(a) {
            var b;
            (((b = a.getExtra()) == null ? void 0 : b.mimeType) !== "application" || F.getBool("enable_era_logging_for_application_stream", !0)) && ha(a)
        });
        W.addListener("streamInterruptAt", function() {
            u.dispatch({
                type: "stream_interrupted"
            })
        });
        W.addListener("streamResumedAt", function() {
            u.dispatch({
                type: "stream_resumed"
            })
        });
        W.addListener("streamGoneBeforeStart", function() {
            Z(), u.dispatch({
                type: "stream_gone_before_start"
            })
        });
        W.addListener("streamEnd", function() {
            Z(), u.dispatch({
                type: "stream_ended"
            })
        });
        W.addListener("videoNodeErrorRetry", function(a) {
            if (F.getBool("enable_error_recovery_attempt_logging", !1)) {
                a = d("VideoPlayerImplementationErrors").createVideoPlayerErrorFromVideoNodeError(a, "oz_player_stream_error_retry");
                u.dispatch({
                    payload: {
                        recoverableError: a
                    },
                    type: "error_recovery_attempt"
                })
            }
        });
        W.addListener("enterBuffering", function(a) {
            if (c("gkx")("1235655")) return;
            u.dispatch({
                payload: {
                    bufferingType: a
                },
                type: "buffering_begin_requested"
            })
        });
        W.addListener("leaveBuffering", function(a) {
            u.dispatch({
                payload: {
                    domEventPerfTimestamp: a.domEventPerfTimestamp
                },
                type: "buffering_end_requested"
            })
        });
        m && m.handleOzPlayerChanged(W);
        var ia = function() {
                var a = o();
                a = {
                    inbandCaptionsAutogeneratedFromManifest: n.getInbandCaptionsAutogeneratedFromManifest(),
                    inbandCaptionsExpectedFromManifest: n.getInbandCaptionsExpectedFromManifest(),
                    inbandCaptionsExpectedFromProps: a == null ? void 0 : a.inbandCaptionsExpectedFromProps,
                    representationCaptionsExpectedFromManifest: n.getRepresentationCaptionsExpectedFromManifest(),
                    sideLoadCaptionsExpectedFromProps: a == null ? void 0 : a.sideLoadCaptionsExpectedFromProps,
                    sideLoadCaptionsUrlFromProps: a == null ? void 0 : a.sideLoadCaptionsUrlFromProps
                };
                var b = u.getCurrentState();
                b = b.controlledState;
                (a.inbandCaptionsExpectedFromManifest !== b.captionsLoaded || a.inbandCaptionsAutogeneratedFromManifest !== b.inbandCaptionsAutogenerated) && q(a)
            },
            ja = function(a, b) {
                a = a.getCustomField("timescale");
                a = typeof a === "number" ? a : 0;
                u.dispatch({
                    payload: {
                        timescale: a,
                        videoBytes: b
                    },
                    type: "cea608_bytes_received"
                })
            },
            ka = function() {
                var a = n.getVideoRepresentations();
                if (a != null && a.length > 0) {
                    a = a[0].getTimeRanges();
                    if (a != null && a.length > 0) {
                        var b = a[0].startTime;
                        a = Math.max(a[a.length - 1].endTime - F.getNumber("live_rewind_seek_to_live_delta", 8), b);
                        u.dispatch({
                            payload: {
                                seekableRanges: new(c("TimeRanges"))([{
                                    endTime: a,
                                    startTime: b
                                }])
                            },
                            type: "seekable_ranges_changed"
                        })
                    }
                }
            },
            la = function() {
                var a = W.getMpd();
                if (!a) return;
                a = a.getCustomField("loapStreamType");
                var b = p();
                typeof a === "number" && b != null && b.setStreamType(a)
            },
            X = function(a) {
                if (a != null) {
                    a = d("ConstUriUtils").getUri(a);
                    if (a) {
                        a = a.getQueryParam("lvp");
                        return a === "1"
                    }
                }
                return !1
            },
            ma = function(a) {
                var b = function() {
                    ka(), ia(), la()
                };
                a.addListener("updated", b);
                c("gkx")("1656434") && b();
                W.updatePlayerRunTimeConfig({
                    audioStreamDataHandler: h != null ? function(a, b) {
                        if (u.getCurrentState().controlledState.emsgObserverTokens.size > 0) {
                            b = h(b, J, a.getID());
                            u.dispatch({
                                payload: {
                                    emsgBoxes: b
                                },
                                type: "emsg_boxes_parsed"
                            })
                        }
                    } : null,
                    videoStreamDataHandler: ja
                });
                if (n.isPredictiveDash()) {
                    F.setContext("streaming_implementation", "pdash");
                    a = aa();
                    a && a.maybeUpdateLatencyLevel()
                }
                b = o();
                q({
                    inbandCaptionsAutogeneratedFromManifest: n.getInbandCaptionsAutogeneratedFromManifest(),
                    inbandCaptionsExpectedFromManifest: n.getInbandCaptionsExpectedFromManifest(),
                    inbandCaptionsExpectedFromProps: b == null ? void 0 : b.inbandCaptionsExpectedFromProps,
                    representationCaptionsExpectedFromManifest: n.getRepresentationCaptionsExpectedFromManifest(),
                    sideLoadCaptionsExpectedFromProps: b == null ? void 0 : b.sideLoadCaptionsExpectedFromProps,
                    sideLoadCaptionsUrlFromProps: b == null ? void 0 : b.sideLoadCaptionsUrlFromProps
                })
            };
        W.addListener("vttCaptionsUpdated", function(a, b) {
            var c = "webvtt",
                d = u.getCurrentState().controlledState.captionFormat;
            c !== d && u.dispatch({
                payload: {
                    captionFormat: c
                },
                type: "controller_set_caption_format_requested"
            });
            u.dispatch({
                payload: {
                    activeCaptions: a,
                    captionsLocale: b
                },
                type: "controller_set_active_captions_requested"
            })
        });
        W.addListener("mpdParsed", function(a) {
            n.isPredictiveDash() && F.setContext("streaming_implementation", "pdash")
        });
        W.addListener("mpdReady", function(a) {
            C.current = !0;
            ma(a);
            u.dispatch({
                payload: {
                    availableQualities: n.getAvailableVideoQualities(),
                    selectedVideoQuality: n.getUserSelectedVideoQuality(),
                    targetVideoQuality: n.getCurrentTargetVideoQuality(),
                    videoProjection: (a = n.getVideoProjectionType()) != null ? a : null
                },
                type: "implementation_engine_initialized"
            })
        });
        W.addListener("representationBlocked", function(a) {
            u.dispatch({
                payload: {
                    availableQualities: n.getAvailableVideoQualities(),
                    blockedRepresentationID: a
                },
                type: "implementation_engine_representation_blocked"
            })
        });
        var Y = null;

        function Z() {
            c("clearTimeout")(Y);
            var a = r.current,
                b = y.current;
            if (a != null) {
                r.current = null;
                y.current = null;
                v.current = null;
                try {
                    a && a.closeHiveSession(), b && b.logEndSession()
                } catch (a) {
                    b && b.logHiveError(a)
                }
            }
        }
        P = r.current;
        g = H == null ? void 0 : H.ticket;
        if (I != null && H && P && g != null) {
            O = W.getPerfLoggerProvider();
            O && O.setIsP2pPlayback(!0);
            G = I.substring(I.indexOf("?"));
            S = P.initSession(g + G, W, B);
            var $ = new(c("Deferred"))();
            i > 0 && (Y = c("setTimeout")(function() {
                $.reject(new Error("Hive initialization timed out after " + i + "ms"))
            }, i));
            S.then(function(a) {
                $.resolve(a)
            })["catch"](function(a) {
                $.reject(a)
            });
            $.getPromise().then(function(a) {
                c("clearTimeout")(Y);
                var b = a.manifest;
                a = a.tech;
                var d = y.current;
                b !== I && d && d.logManifestMismatch(b, I);
                d && d.logSessionInit(a, b);
                t.setAdditionalLogData("is_p2p_playback", !0);
                t.setAdditionalLogData("is_live_preview", X(b));
                W.load(b)
            })["catch"](function(a) {
                c("clearTimeout")(Y);
                var b = y.current;
                b && b.logError(a);
                Z();
                t.setAdditionalLogData("is_live_preview", X(I));
                W.load(I)
            })
        } else t.setAdditionalLogData("is_p2p_playback", !1), t.setAdditionalLogData("is_live_preview", X(I)), W.load(I)
    }
    g.proceedWithOzPlayerCreation = a
}), 98);
__d("VideoPlayerOzImplementationLatencyLevelManager", [], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b) {
            this.$2 = "normal", this.$4 = null, this.$1 = a, this.$3 = b
        }
        var b = a.prototype;
        b.updatePlayerFormat = function(a) {
            this.$4 !== a && (this.$4 = a, this.maybeUpdateLatencyLevel())
        };
        b.updateBroadcastLatencySensitivity = function(a) {
            this.$5 !== a && (this.$5 = a, this.maybeUpdateLatencyLevel())
        };
        b.maybeUpdateLatencyLevel = function() {
            var a;
            this.$1.getBool("ull_use_broadcast_sensitivity_type", !1) ? a = this.$6(this.$5) : a = this.$7();
            a !== this.$2 && (this.$2 = a, this.$3.dispatch({
                payload: {
                    latencyLevel: a
                },
                type: "implementation_set_latency_level_requested"
            }))
        };
        b.$7 = function() {
            var a = [];
            try {
                a = JSON.parse(this.$1.getString("player_formats_for_low_latency", "[]"))
            } catch (a) {}
            return a.includes("*") || a.includes(this.$4) ? "low" : "normal"
        };
        b.$6 = function(a) {
            if (a == null) return "normal";
            switch (a) {
                case 1:
                    return "low";
                case 2:
                    return "ultra-low";
                case 0:
                    return "normal"
            }
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("VideoPlayerOzImplementationEngine", ["CometDASHPrefetchCacheManager", "VideoPlayerImplementationEngineAPI", "VideoPlayerImplementationEngineVideoElementAPI", "VideoPlayerImplementationErrors", "VideoPlayerImplementationLoadSequenceManager", "VideoPlayerODS", "VideoPlayerOzImplementationEngineExtrasAPI", "VideoPlayerOzImplementationEnginePartsImplFunction", "VideoPlayerOzImplementationEnginePartsImplUtils", "VideoPlayerOzImplementationLatencyLevelManager", "cr:1473549", "cr:1494460", "cr:1534629", "cr:72", "emptyFunction", "gkx", "promiseDone", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = !1;
    var h = c("emptyFunction");

    function a(a) {
        var e = a.debugLogId,
            f = a.handleFatalError,
            g = a.initialProps;
        a = a.setExposedStateInReact;
        var i = {
                current: null
            },
            j = {
                current: null
            },
            k = {
                current: null
            },
            l = {
                current: null
            },
            m = {
                current: null
            },
            n = {
                current: null
            },
            o = {
                current: null
            },
            p = {
                current: null
            },
            q = {
                current: null
            },
            r = {
                current: null
            },
            s = {
                current: null
            },
            t = {
                current: null
            },
            u = {
                current: null
            };

        function v() {
            var a;
            return (a = o.current) != null ? a : null
        }

        function w() {
            var a;
            return (a = n.current) != null ? a : null
        }

        function x() {
            var a;
            return (a = (a = j.current) == null ? void 0 : a.experimentationConfig) != null ? a : null
        }

        function y() {
            var a;
            return (a = X.current) != null ? a : null
        }

        function z() {
            var a;
            return (a = u.current) != null ? a : null
        }
        var A;
        b("cr:1473549") && (A = new(b("cr:1473549"))());
        var B = "comet_oz",
            C = function(a, b) {
                return b.manifestXmlStringInitial !== null ? a.manifestXmlStringInitial !== b.manifestXmlStringInitial : a.manifestUrl !== b.manifestUrl
            },
            D = function(a, b) {
                return a.videoFBID !== b.videoFBID
            },
            E = function(a, b) {
                return a.playerFormat !== b.playerFormat
            },
            F = function(a) {
                return a.getBool("use_full_player_if_cached", !1) && b("cr:1534629") ? b("cr:1534629")().getModuleIfRequireable() : null
            },
            G = function(a, b, c) {
                b != null ? j.current = babelHelpers["extends"]({}, a, {
                    manifestXmlStringResolved: b
                }) : j.current = a, W.dispatch({
                    type: "implementation_engine_oz_manifest_downloading"
                }), m.current = F(a.experimentationConfig), K(m.current, [].concat(c, ["proceedWithOzManifestDownloading"]))
            },
            H = function(a) {
                var b, e, f = a.manifestUrl,
                    g = a.manifest,
                    h = null;
                c("CometDASHPrefetchCacheManager") && (a.videoFBID != null && (h = c("CometDASHPrefetchCacheManager").get(a.videoFBID)));
                b = {
                    VideoPlayerShakaPerformanceLoggerClass: a.VideoPlayerShakaPerformanceLoggerClass,
                    accessToken: a.loggingMetaData.accessToken,
                    audioOnly: a.audioOnly,
                    experimentationConfig: a.experimentationConfig,
                    graphQLVideoDRMInfo: a.graphQLVideoDRMInfo,
                    graphQLVideoP2PSettings: a.graphQLVideoP2PSettings,
                    manifestUrl: (b = f) != null ? b : null,
                    manifestXmlStringInitial: (b = g) != null ? b : null,
                    minQualityPreference: a.minQualityPreference,
                    ozPrefetchCache: h,
                    playerFormat: a.loggingMetaData.coreVideoPlayerMetaData.playerFormat,
                    videoFBID: a.videoFBID,
                    videoPlayerShakaPerformanceLoggerBuilder: a.videoPlayerShakaPerformanceLoggerBuilder
                };
                h = i.current;
                u.current == null && (u.current = new(c("VideoPlayerOzImplementationLatencyLevelManager"))(a.experimentationConfig, W));
                b.playerFormat != null && (h == null || E(b, h)) && W.dispatch({
                    payload: {
                        playerFormat: b.playerFormat
                    },
                    type: "controller_set_player_format"
                });
                u.current.updatePlayerFormat((e = a.loggingMetaData.coreVideoPlayerMetaData.playerFormat) != null ? e : null);
                (e = u.current) == null ? void 0 : e.updateBroadcastLatencySensitivity(a.broadcastLatencySensitivity);
                e = !1;
                if (h == null) e = !0;
                else if (h != null && !D(b, h) && C(b, h)) {
                    a = 14;
                    d("VideoPlayerODS").bumpEntityKey("OzImplementation", "manifest_reloaded", a);
                    e = !1
                } else if (h != null && D(b, h)) throw c("unrecoverableViolation")("videoFBID changed after player initialization", "comet_video_player");
                if (!e) return !1;
                f = b.manifestUrl;
                g = b.manifestXmlStringInitial;
                if (g == null && f == null) throw c("unrecoverableViolation")("Empty manifestXmlStringInitial and manifestUrl", "comet_video_player");
                i.current = b;
                G(b, g, ["handleVideoInfoChangeForOzImplementation", "downloadManifestInOz"]);
                return !0
            },
            I = function(a, b) {
                var d = function(c) {
                        if (l.current !== a) return;
                        m.current = c;
                        K(c, [].concat(b, ["handleOzPlayerModuleLoadSuccess"]))
                    },
                    e = function(b) {
                        if (l.current !== a) return;
                        U(b, "oz_player_module_load_failed")
                    };
                l.current = a;
                c("promiseDone")(a, d, e)
            },
            J = function(a) {
                a = d("VideoPlayerImplementationEngineVideoElementAPI").createVideoPlayerImplementationEngineVideoElementAPI(a);
                X.current = a;
                return a
            },
            K = function(a, c) {
                var e = R(),
                    f = j.current;
                if (e == null || f == null) return;
                var g = J(e),
                    h = f.experimentationConfig;
                a ? L(a, e, g, f, [].concat(c, ["proceedWithResolvedVideoInfo", "OzPlayerModuleFromRef"])) : b("cr:1494460") ? L(b("cr:1494460")(), e, g, f, [].concat(c, ["proceedWithResolvedVideoInfo", "VideoPlayerOzPlayerModuleLoaderSync"])) : b("cr:1534629") ? (h.getBool("instantiate_buffering_detector_before_quick_starter", !1) && d("VideoPlayerOzImplementationEnginePartsImplUtils").createOzBufferingDetector(e, g, f.experimentationConfig, W, o, V), I(b("cr:1534629")().load(), [].concat(c, ["proceedWithResolvedVideoInfo", "VideoPlayerOzPlayerModuleLoaderAsync"]))) : U(new Error("Neither of OzPlayerModuleLoader is available."), "oz_player_module_loaders_missing")
            },
            L = function(a, b, e, f, h) {
                try {
                    var i = {
                        OzPlayerClass: a,
                        callChain: [].concat(h, ["proceedWithResolvedVideoInfoAndOzPlayerModuleSync"]),
                        destroyOzPlayerPartsRef: t,
                        engineDebugAPI: A,
                        engineExtrasAPI: P,
                        getCaptionsInfo: Q,
                        getLatencyLevelManager: z,
                        getVideoLiveTrace: S,
                        handleCaptionsInfoChange: T,
                        handleFatalImplementationError: U,
                        initialProps: g,
                        logger: V,
                        machine: W,
                        ozBufferingDetectorRef: o,
                        playerVersion: B,
                        resolvedVideoInfo: f,
                        videoElement: b
                    };
                    a = x();
                    h = g.loadSequence;
                    a && a.getNumber("load_sequence_max_delay_ms", 0) > 0 && h != null ? s.current = c("VideoPlayerImplementationLoadSequenceManager").schedule(a, h, function() {
                        d("VideoPlayerOzImplementationEnginePartsImplFunction").proceedWithOzPlayerCreation(babelHelpers["extends"]({}, i, {
                            hivePluginRef: p,
                            overrideOzRequestImplementationRef: r,
                            ozPlayerRef: n,
                            p2pSessionLoggerRef: q
                        }));
                        return e.getCanPlayPromise()
                    }) : d("VideoPlayerOzImplementationEnginePartsImplFunction").proceedWithOzPlayerCreation(babelHelpers["extends"]({}, i, {
                        hivePluginRef: p,
                        overrideOzRequestImplementationRef: r,
                        ozPlayerRef: n,
                        p2pSessionLoggerRef: q
                    }));
                    k.current = f
                } catch (a) {
                    U(a, "oz_player_create_exception")
                }
            };

        function M(a) {
            c("gkx")("1494163") && (k.current = null);
            var b = t.current;
            b != null && (t.current = null, b(a));
            s.current != null && (s.current(), s.current = null)
        }

        function N() {
            if (c("gkx")("1494163")) i.current = null, j.current = null, k.current = null;
            else return
        }

        function O() {
            l.current = null, m.current = null
        }
        var P = d("VideoPlayerOzImplementationEngineExtrasAPI").createVideoPlayerOzImplementationEngineExtrasAPI({
            getConfig: x,
            getOzPlayer: w,
            getVideoElementAPI: y
        });
        y = d("VideoPlayerImplementationEngineAPI").createVideoPlayerImplementationEngine({
            createDebugAPI: function(b) {
                var a = b.getVideoElementAPI;
                b = b.logger;
                return A ? A.createDebugAPI({
                    engineExtrasAPI: P,
                    getConfig: function() {
                        var a;
                        return (a = (a = k.current) == null ? void 0 : a.experimentationConfig) != null ? a : null
                    },
                    getManifest: function() {
                        var a;
                        return (a = (a = k.current) == null ? void 0 : a.manifestXmlStringResolved) != null ? a : null
                    },
                    getManifestUrl: function() {
                        var a;
                        return (a = (a = k.current) == null ? void 0 : a.manifestUrl) != null ? a : null
                    },
                    getOzBufferingDetector: v,
                    getOzPlayer: w,
                    getVideoElementAPI: a,
                    logger: b
                }) : null
            },
            createVideoPlayerError: d("VideoPlayerImplementationErrors").createVideoPlayerErrorFromOzImplementationError,
            debugLog: h,
            debugLogId: e,
            destroyEngineParts: function(a) {
                M([].concat(a, ["destroyEngineParts"])), N(), O()
            },
            engineExtrasAPI: P,
            engineMetadata: {
                isAbrEnabled: !0,
                isExternalMedia: !1,
                playerImplementationName: "oz_v2",
                playerVersion: B,
                streamingFormat: "dash"
            },
            handleFatalError: f,
            handleVideoElementMounted: function(a) {
                var b = R();
                K(m.current, [].concat(a, ["handleVideoElementMounted"]))
            },
            handleVideoElementUnmounted: function(a) {
                (c("gkx")("1494163") || c("gkx")("1380112")) && M([].concat(a, ["handleVideoElementUnmounted"]))
            },
            handleVideoInfoChange: H,
            initialProps: g,
            setExposedStateInReact: a
        });
        e = y.engine;
        var Q = y.getCaptionsInfo,
            R = y.getVideoElement,
            S = y.getVideoLiveTrace,
            T = y.handleCaptionsInfoChange,
            U = y.handleFatalImplementationError,
            V = y.logger,
            W = y.machine,
            X = y.videoElementAPIRef;
        return e
    }
    g.createVideoPlayerOzImplementationEngine = a
}), 98);
__d("VideoPlayerOzImplementationV2.react", ["VideoPlayerImplementationEngineAPI", "VideoPlayerOzImplementationEngine", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function a(a) {
        a = d("VideoPlayerImplementationEngineAPI").useVideoPlayerImplementationEngine(a, d("VideoPlayerOzImplementationEngine").createVideoPlayerOzImplementationEngine);
        a = a.reactVideoFrameAndComponents;
        return a
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerProgressiveImplementationEngineExtrasAPI", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        return a !== null && a.indexOf(".m3u8") !== -1
    }

    function a(a) {
        var b = a.getPlayingVideoInfo;
        a = a.setUserSelectedVideoQuality;
        return {
            getApproximateFBLSToPlayerDisplayLatency: function() {
                return null
            },
            getAudioRepresentationIDAtTime: function(a) {
                return null
            },
            getAvailableVideoQualities: function() {
                var a;
                return (a = (a = b()) == null ? void 0 : a.availableQualities) != null ? a : []
            },
            getCurrentAudioRepresentation: function() {
                return null
            },
            getCurrentPlayingVideoQuality: function() {
                var a;
                return (a = (a = b()) == null ? void 0 : a.targetQuality) != null ? a : ""
            },
            getCurrentTargetVideoQuality: function() {
                var a;
                return (a = (a = b()) == null ? void 0 : a.targetQuality) != null ? a : ""
            },
            getCurrentVideoRepresentation: function() {
                return null
            },
            getEstimatedBandwidth: function() {
                return null
            },
            getInbandCaptionsAutogeneratedFromManifest: function() {
                return !1
            },
            getInbandCaptionsExpectedFromManifest: function() {
                return !1
            },
            getManifestIdentifier: function() {
                return null
            },
            getMpdValidationErrors: function() {
                return null
            },
            getPerfLoggerProvider: function() {
                return null
            },
            getRepresentationCaptionsExpectedFromManifest: function() {
                return !1
            },
            getStreamType: function() {
                var a = b();
                return a == null ? "progressive" : g(a.hdSrc) || g(a.sdSrc) ? "hls" : "progressive"
            },
            getUserSelectedVideoQuality: function() {
                var a;
                return (a = (a = b()) == null ? void 0 : a.selectedQuality) != null ? a : "notselected"
            },
            getVideoProjectionType: function() {
                return "cubemap"
            },
            getVideoRepresentationIDAtTime: function(a) {
                return "oep_hd"
            },
            getVideoRepresentations: function() {
                return null
            },
            isDrm: function() {
                var a;
                return ((a = b()) == null ? void 0 : a.graphQLVideoDRMInfo) != null
            },
            isFBIsLiveTemplated: function() {
                return !1
            },
            isFBMS: function() {
                return !1
            },
            isFBWasLive: function() {
                return !1
            },
            isPredictiveDash: function() {
                return !1
            },
            setDimensions: function(a) {},
            setEnableLiveheadCatchup: function() {},
            setLatencyLevel: function() {},
            setUserSelectedVideoQuality: a
        }
    }
    f.createVideoPlayerProgressiveImplementationEngineExtrasAPI = a
}), 66);
__d("VideoPlayerProgressiveImplementationEngineUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "hd",
        h = "sd";

    function a(a) {
        var b = [];
        a.sdSrc != null && b.push(h);
        a.hdSrc != null && b.push(g);
        var c = a.hdSrcPreferred && a.hdSrc != null ? g : h;
        return babelHelpers["extends"]({}, a, {
            availableQualities: b,
            playingQuality: null,
            playingSrc: null,
            selectedQuality: c,
            targetQuality: c,
            targetSrc: null
        })
    }

    function b(a, b) {
        var c = a.hdSrc,
            d = a.sdSrc,
            e, f;
        b === "notselected" || b === "auto" ? (e = d != null ? h : c != null ? g : h, f = d != null ? d : c != null ? c : null) : b === g && c != null ? (e = g, f = c) : b === h && d != null ? (e = h, f = d) : (e = h, f = null);
        f === "" && (f = null);
        return babelHelpers["extends"]({}, a, {
            selectedQuality: b,
            targetQuality: e,
            targetSrc: f
        })
    }

    function c(a, b, c) {
        return babelHelpers["extends"]({}, a, {
            playingQuality: b,
            playingSrc: c
        })
    }
    f.createResolvedVideoInfoProgressive = a;
    f.updatePlayingVideoInfoProgressiveWithUserSelectedQuality = b;
    f.updatePlayingVideoInfoProgressiveWithCurrentPlayingQuality = c
}), 66);
__d("VideoPlayerProgressiveImplementationEngine", ["FBLogger", "UserAgent", "VideoPlayerImplementationEngineAPI", "VideoPlayerImplementationEngineVideoElementAPI", "VideoPlayerImplementationErrors", "VideoPlayerODS", "VideoPlayerProgressiveImplementationEngineExtrasAPI", "VideoPlayerProgressiveImplementationEngineUtils", "cr:1473550", "cr:1512856", "cr:1680308", "emptyFunction", "err", "gkx", "promiseDone", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("emptyFunction");

    function i(a, b, c) {
        return d("VideoPlayerImplementationErrors").createVideoPlayerErrorFromGenericError("PROGRESSIVE_JAVASCRIPT_NATIVE", a, b, c)
    }

    function a(a) {
        var e = a.debugLogId,
            f = a.handleFatalError,
            g = a.initialProps;
        a = a.setExposedStateInReact;
        var j = {
                current: null
            },
            k = {
                current: null
            },
            l = {
                current: null
            },
            m = {
                current: null
            },
            n = function() {
                var a = m.current;
                a != null && (m.current = null, a())
            },
            o = function(a) {
                n();
                var e = w();
                if (e == null) throw c("unrecoverableViolation")("Need videoElement in startSwitchingSource", "comet_video_player");
                if (b("cr:1512856") == null) throw c("unrecoverableViolation")("Need SourceSwitcher in startSwitchingSource", "comet_video_player");
                m.current = b("cr:1512856").startSwitchingVideoElementSource({
                    getShouldBePlaying: function() {
                        return z.getCurrentState().controlledState.playbackState === "playing" || z.getCurrentState().controlledState.playbackState === "stalling"
                    },
                    onSourceSwitchCancelled: function() {
                        z.dispatch({
                            payload: {
                                domEventPerfTimestamp: null
                            },
                            type: "buffering_end_requested"
                        })
                    },
                    onSourceSwitchFailed: function(a) {
                        c("FBLogger")("comet_video_player").catching(a).warn("Progressive source switch failed: %s", String(a)), z.dispatch({
                            payload: {
                                domEventPerfTimestamp: null
                            },
                            type: "buffering_end_requested"
                        })
                    },
                    onSourceSwitchStarted: function() {
                        z.dispatch({
                            payload: {
                                bufferingType: "in_play"
                            },
                            type: "buffering_begin_requested"
                        })
                    },
                    onSourceSwitchSucceeded: function() {
                        var a = l.current;
                        a != null && a.targetQuality != null && (l.current = d("VideoPlayerProgressiveImplementationEngineUtils").updatePlayingVideoInfoProgressiveWithCurrentPlayingQuality(a, a.targetQuality, a.targetSrc));
                        z.dispatch({
                            payload: {
                                domEventPerfTimestamp: null
                            },
                            type: "buffering_end_requested"
                        })
                    },
                    targetSrc: a,
                    videoElement: e
                })
            },
            p = {
                current: null
            },
            q = function() {
                var a = w(),
                    e = k.current;
                if (a == null || e == null) return;
                c("gkx")("6737") && a.addEventListener("error", function() {
                    y(a.error, "progressive_implementation_error")
                });
                try {
                    var f, h = e.graphQLVideoDRMInfo,
                        i = e.videoFBID;
                    f = h ? (f = h.fairplayCert) != null ? f : null : null;
                    if (b("cr:1680308") && h && f != null && i != null) {
                        p.current = b("cr:1680308").newIfSupported(f, a, i, h.videoLicenseUriMap);
                        if (p.current == null) {
                            f = c("err")("Fairplay not supported");
                            y(f, "progressive_player_fairplay_handler_missing")
                        } else p.current.addListener("error", function(a) {
                            a = c("err")(a.error);
                            y(a, "progressive_player_fairplay_handler_error")
                        })
                    }
                    var j = d("VideoPlayerImplementationEngineVideoElementAPI").createVideoPlayerImplementationEngineVideoElementAPI(a, g.isExternalMedia);
                    A.current = j;
                    l.current = e;
                    i = v();
                    x({
                        inbandCaptionsAutogeneratedFromManifest: t.getInbandCaptionsAutogeneratedFromManifest(),
                        inbandCaptionsExpectedFromManifest: t.getInbandCaptionsExpectedFromManifest(),
                        inbandCaptionsExpectedFromProps: i == null ? void 0 : i.inbandCaptionsExpectedFromProps,
                        representationCaptionsExpectedFromManifest: t.getRepresentationCaptionsExpectedFromManifest(),
                        sideLoadCaptionsExpectedFromProps: i == null ? void 0 : i.sideLoadCaptionsExpectedFromProps,
                        sideLoadCaptionsUrlFromProps: i == null ? void 0 : i.sideLoadCaptionsUrlFromProps
                    });
                    z.dispatch({
                        payload: {
                            availableQualities: t.getAvailableVideoQualities(),
                            selectedVideoQuality: t.getUserSelectedVideoQuality(),
                            streamingFormat: t.getStreamType(),
                            targetVideoQuality: t.getCurrentTargetVideoQuality(),
                            videoProjection: t.getVideoProjectionType()
                        },
                        type: "implementation_engine_initialized"
                    });
                    h = function() {
                        j.setPlayheadPosition(g.startTimestamp)
                    };
                    c("UserAgent").isBrowser("IE11") ? c("promiseDone")(j.getDOMLoadedMetadataPromise().then(h)) : h()
                } catch (a) {
                    y(a, "progressive_player_create_exception")
                }
            },
            r = function(a, b) {
                if (b == null) return !0;
                else if (a.videoFBID !== b.videoFBID) {
                    var c = 14;
                    d("VideoPlayerODS").bumpEntityKey("comet_video_player", "ProgressiveImplementation.video_fbid_changed", c);
                    return !1
                } else if (a.hdSrc !== b.hdSrc || a.sdSrc !== b.sdSrc) {
                    c = 14;
                    d("VideoPlayerODS").bumpEntityKey("comet_video_player", "ProgressiveImplementation.src_changed", c);
                    return !1
                } else return !1
            },
            s = function(a) {
                var b;
                b = {
                    graphQLVideoDRMInfo: (b = a.graphQLVideoDRMInfo) != null ? b : null,
                    hdSrc: a.hdSrc === "" ? null : (b = a.hdSrc) != null ? b : null,
                    hdSrcPreferred: a.hdSrcPreferred,
                    sdSrc: a.sdSrc === "" ? null : (b = a.sdSrc) != null ? b : null,
                    videoFBID: a.videoFBID
                };
                if (!r(b, j.current)) return !1;
                if (b.hdSrc == null && b.sdSrc == null) throw c("unrecoverableViolation")("Empty hdSrc and sdSrc", "comet_video_player");
                j.current = b;
                k.current = d("VideoPlayerProgressiveImplementationEngineUtils").createResolvedVideoInfoProgressive(b);
                q();
                return !0
            },
            t = d("VideoPlayerProgressiveImplementationEngineExtrasAPI").createVideoPlayerProgressiveImplementationEngineExtrasAPI({
                getPlayingVideoInfo: function() {
                    return l.current
                },
                setUserSelectedVideoQuality: function(a) {
                    var b = l.current;
                    if (!b) throw c("unrecoverableViolation")("Attempt to switch quality when playingVideoInfo does not exist", "comet_video_player");
                    var e = A.current;
                    if (!e) throw c("unrecoverableViolation")("Attempt to switch quality when videoElementAPI does not exist", "comet_video_player");
                    var f = b.targetQuality,
                        g = b.targetSrc;
                    l.current = d("VideoPlayerProgressiveImplementationEngineUtils").updatePlayingVideoInfoProgressiveWithUserSelectedQuality(b, a);
                    b = l.current;
                    a = b.targetQuality;
                    b = b.targetSrc;
                    if (c("gkx")("1467411")) b !== g && (b == null ? (n(), e.setSrc(null)) : o(b)), f != null && a !== f && a != null && z.dispatch({
                        payload: {
                            targetVideoQuality: a
                        },
                        type: "representation_changed"
                    });
                    else {
                        e.setSrc(b);
                        if (b != null) {
                            f = (g = z.getCurrentState().uncontrolledState.videoElementPlayheadPosition) != null ? g : 0;
                            f > 0 && e.setPlayheadPosition(f);
                            z.getCurrentState().controlledState.playbackState === "playing" && e.play();
                            z.dispatch({
                                payload: {
                                    targetVideoQuality: t.getCurrentTargetVideoQuality()
                                },
                                type: "representation_changed"
                            })
                        }
                    }
                }
            }),
            u = function() {
                p.current && (p.current.destroy(), p.current = null)
            };
        e = d("VideoPlayerImplementationEngineAPI").createVideoPlayerImplementationEngine({
            createDebugAPI: function(a) {
                var c = a.getVideoElementAPI;
                a = a.logger;
                return b("cr:1473550") ? b("cr:1473550").createVideoPlayerImplementationDebugAPI({
                    engineExtrasAPI: t,
                    getVideoElementAPI: c,
                    logger: a
                }) : null
            },
            createVideoPlayerError: function(a, b) {
                return i(a, b, (a = l.current) == null ? void 0 : a.targetSrc)
            },
            debugLog: h,
            debugLogId: e,
            destroyEngineParts: function() {
                if (c("gkx")("1467411")) {
                    n();
                    var a = A.current;
                    a && a.setSrc(null);
                    l.current = null
                }
                u()
            },
            engineExtrasAPI: t,
            engineMetadata: {
                isAbrEnabled: !1,
                isExternalMedia: g.isExternalMedia,
                playerImplementationName: "progressive_v2",
                playerVersion: "comet_progressive",
                streamingFormat: "progressive"
            },
            handleFatalError: f,
            handleVideoElementMounted: q,
            handleVideoElementUnmounted: function() {
                c("gkx")("1467411") && n()
            },
            handleVideoInfoChange: s,
            initialProps: g,
            setExposedStateInReact: a
        });
        f = e.engine;
        var v = e.getCaptionsInfo,
            w = e.getVideoElement,
            x = e.handleCaptionsInfoChange,
            y = e.handleFatalImplementationError,
            z = e.machine,
            A = e.videoElementAPIRef;
        return f
    }
    g.createVideoPlayerProgressiveImplementationEngine = a
}), 98);
__d("VideoPlayerProgressiveImplementationV2.react", ["VideoPlayerImplementationEngineAPI", "VideoPlayerProgressiveImplementationEngine", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function a(a) {
        a = d("VideoPlayerImplementationEngineAPI").useVideoPlayerImplementationEngine(a, d("VideoPlayerProgressiveImplementationEngine").createVideoPlayerProgressiveImplementationEngine);
        a = a.reactVideoFrameAndComponents;
        return a
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerOzImplementationData", ["err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.canUseOz,
            d = a.dashManifest,
            e = a.dashUrl,
            f = a.experimentationConfig,
            g = a.minQualityPreference;
        a = a.videoFBID;
        if (b !== !0) {
            b = c("err")("The DASH player is not available for this video");
            b.name = "VideoImplementationsDashPlayerUnavailable";
            return b
        }
        if (a == null) {
            b = c("err")("video has no FBID");
            b.name = "VideoImplementationsNoFBID";
            return b
        }
        a = d == null || d === "" ? null : d;
        b = e == null || e === "" ? null : e;
        if (a == null && b == null) {
            d = c("err")("video has no manifest and no manifest URL");
            d.name = "VideoImplementationsNoManifestOrURL";
            return d
        }
        return {
            experimentationConfig: f,
            manifest: a,
            manifestUrl: b,
            minQualityPreference: (e = g) != null ? e : null,
            seoWebCrawlerLookasideUrl: b
        }
    }
    g.makeOzImplementationData = a
}), 98);
__d("useOzImplementationData", ["CometRelay", "VideoPlayerOzImplementationData", "VideoPlayerOzWWWConfig", "react", "useOzImplementationData_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useMemo;

    function a(a, e) {
        var f = e.manifestURL_DO_NOT_USE,
            g = e.videoPlayerShakaConfig,
            j = i(function() {
                return new(c("VideoPlayerOzWWWConfig"))(g)
            }, [g]),
            k = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useOzImplementationData_video.graphql"), a);
        return i(function() {
            return d("VideoPlayerOzImplementationData").makeOzImplementationData({
                canUseOz: k.can_use_oz,
                dashManifest: f != null ? null : k.dash_manifest,
                dashUrl: f != null ? f : k.playable_url_dash,
                experimentationConfig: j,
                minQualityPreference: k.min_quality_preference,
                videoFBID: k.id
            })
        }, [k, f, j])
    }
    g["default"] = a
}), 98);
__d("VideoPlayerShakaImplementationData", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.videoData;
        a = a.videoPlayerShakaConfig;
        return b == null ? null : {
            videoData: b,
            videoPlayerShakaConfig: a
        }
    }
    f.makeShakaImplementationData = a
}), 66);
__d("useShakaImplementationData", ["CometRelay", "VideoPlayerShakaImplementationData", "cr:1604324", "react", "recoverableViolation", "useShakaImplementationData_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useMemo;

    function a(a, e) {
        var f = e.videoPlayerShakaConfig,
            g = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useShakaImplementationData_video.graphql"), a);
        return i(function() {
            var a;
            if (g.is_rss_podcast_video === !0) return null;
            a = (a = g.video_player_shaka_live_p2p_init) == null ? void 0 : a.json_encoded_video_data;
            if (a == null) return null;
            if (b("cr:1604324") == null) return c("recoverableViolation")("VideoData is not supported", "comet_video_player");
            var e = null;
            try {
                e = new(b("cr:1604324"))(JSON.parse(a))
            } catch (a) {
                c("recoverableViolation")("VideoData JSON is broken", "comet_video_player")
            }
            return d("VideoPlayerShakaImplementationData").makeShakaImplementationData({
                videoData: e,
                videoPlayerShakaConfig: f
            })
        }, [g, f])
    }
    g["default"] = a
}), 98);
__d("useVideoImplementationsImpl", ["CometRelay", "ErrorMetadata", "VideoPlayerOzImplementationV2.react", "VideoPlayerProgressiveImplementationV2.react", "cr:1604325", "err", "gkx", "manifestHasUnsupportedCodecs", "recoverableViolation", "unrecoverableViolation", "useOzImplementationData", "useProgressiveImplementationData", "useShakaImplementationData", "useVideoImplementationsImpl_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a, e) {
        var f = [],
            g = e.forceProgressiveImpl;
        g = g === void 0 ? !1 : g;
        var i = e.initialForceHD;
        i = i === void 0 ? !1 : i;
        var j = e.manifestURL_DO_NOT_USE,
            k = e.videoFBID;
        e = e.videoPlayerShakaConfig;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoImplementationsImpl_video.graphql"), a);
        var l = c("useShakaImplementationData")(a, {
            videoPlayerShakaConfig: e
        });
        l != null && (b("cr:1604325") == null ? c("recoverableViolation")("VideoPlayerShakaImplementation is not supported", "comet_video_player") : f.push({
            Component: b("cr:1604325"),
            data: l,
            typename: "VideoPlayerShakaImplementation"
        }));
        l = null;
        var m = null,
            n = !1;
        j = c("useOzImplementationData")(a, {
            manifestURL_DO_NOT_USE: j,
            videoPlayerShakaConfig: e
        });
        if (j instanceof Error) l = j;
        else {
            m = j;
            if (m.manifest === null && m.manifestUrl === null) throw c("unrecoverableViolation")("If ozImplementationData exists, it should have either manifest or manifestUrl", "comet_video_player");
            n = c("manifestHasUnsupportedCodecs")(m.manifest);
            g || (m.manifest != null && !n || m.manifestUrl != null ? f.push({
                Component: c("VideoPlayerOzImplementationV2.react"),
                data: m,
                typename: "VideoPlayerOzImplementation"
            }) : l = c("err")("unsupported DASH codecs"))
        }
        e = c("useProgressiveImplementationData")(a, {
            initialForceHD: i
        });
        c("VideoPlayerProgressiveImplementationV2.react") != null && e != null && f.push({
            Component: c("VideoPlayerProgressiveImplementationV2.react"),
            data: e,
            typename: "VideoPlayerProgressiveImplementation"
        });
        if (f.length === 0) {
            l != null ? (j = c("err")("Cannot play video: " + l.message + " and no progressive URL is available"), l.name && (j.name = l.name)) : (j = c("err")("Cannot play video: No progressive URL is available"), j.name = "VideoImplementationsNoProgressiveURL");
            j.project = "comet_video_player";
            a = new(c("ErrorMetadata"))();
            j.metadata = a;
            a.addEntry("COMET_VIDEO", "VIDEO_ID", String(k));
            if (c("gkx")("1611172")) {
                k = {
                    forced_progressive: g,
                    has_oz_data: m != null,
                    has_oz_manifest: ((i = m) == null ? void 0 : i.manifest) != null,
                    has_oz_manifest_url: ((l = m) == null ? void 0 : l.manifestUrl) != null,
                    has_oz_unsupported_codecs: n,
                    has_progressive_data: e != null
                };
                a.addEntry("COMET_VIDEO", "VIDEO_IMPLEMENTATION_DEBUG_DATA", JSON.stringify(k));
                c("recoverableViolation")(j.message, "comet_video_player", {
                    error: j
                })
            }
            throw j
        }
        return f
    }
    g["default"] = a
}), 98);
__d("useVideoImplementations", ["useVideoImplementationsImpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("useVideoImplementationsImpl")
}), 98);
__d("useVideoPlayerAudioAvailabilityInfoRelay", ["CometRelay", "VideoPlayerAudioAvailabilityInfo", "react", "useVideoPlayerAudioAvailabilityInfoRelay_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useMemo;

    function a(a) {
        var c = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoPlayerAudioAvailabilityInfoRelay_video.graphql"), a);
        return i(function() {
            return d("VideoPlayerAudioAvailabilityInfo").makeVideoPlayerAudioAvailabilityInfo({
                audioAvailability: c.audio_availability,
                mutedSegmentsUnsanitized: c.muted_segments == null ? [] : c.muted_segments.map(function(a) {
                    return {
                        muteEndTimeInSec: a.mute_end_time_in_sec,
                        muteStartTimeInSec: a.mute_start_time_in_sec
                    }
                })
            })
        }, [c.audio_availability, c.muted_segments])
    }
    g["default"] = a
}), 98);
__d("AudioSettingsVolumeSetting", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        DEFAULT: "default",
        QUIET: "quiet"
    });
    f["default"] = a
}), 66);
__d("useVideoPlayerAudioSettings", ["AudioSettingsVolumeSetting", "CometRelay", "react", "useVideoPlayerAudioSettings_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useMemo,
        j = 1;
    e = .5;
    var k = new Map([
        ["default", j],
        ["quiet", e]
    ]);

    function a(a) {
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoPlayerAudioSettings_video.graphql"), a);
        a = (a = a.audio_settings) == null ? void 0 : a.video_volume_setting;
        var e = "DEFAULT";
        switch (a) {
            case "DEFAULT":
            case "QUIET":
                e = a;
                break;
            default:
                break
        }
        a = c("AudioSettingsVolumeSetting")[e];
        var f = (e = k.get(a)) != null ? e : j;
        return i(function() {
            return {
                preferredVolumeSetting: f
            }
        }, [f])
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerCaptionsSettings", ["CometRelay", "useVideoPlayerCaptionsSettings_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = "DEFAULT",
        j = "BLACK",
        k = "WHITE",
        l = "DEFAULT";

    function a(a) {
        var c;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoPlayerCaptionsSettings_video.graphql"), a);
        return {
            alwaysShowCaptions: (c = (c = a.captions_settings) == null ? void 0 : c.always_show_captions) != null ? c : !1,
            captionDisplayStyle: {
                captionsBackgroundColor: (c = (c = a.captions_settings) == null ? void 0 : c.captions_background_color) != null ? c : j,
                captionsBackgroundOpacity: (c = (c = a.captions_settings) == null ? void 0 : c.captions_background_opacity) != null ? c : i,
                captionsTextColor: (c = (c = a.captions_settings) == null ? void 0 : c.captions_text_color) != null ? c : k,
                captionsTextSize: (a = (c = a.captions_settings) == null ? void 0 : c.captions_text_size) != null ? a : l
            }
        }
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerLiveLatencyKnobSettings", ["CometRelay", "useVideoPlayerLiveLatencyKnobSettings_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        var c;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoPlayerLiveLatencyKnobSettings_video.graphql"), a);
        return {
            desiredLatencyMs: (c = (c = a.broadcast_low_latency_config) == null ? void 0 : c.ll_desired_latency_ms) != null ? c : 0,
            latencyToleranceMs: (a = (c = a.broadcast_low_latency_config) == null ? void 0 : c.ll_latency_tolerance_ms) != null ? a : 0
        }
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerShakaPerformanceLoggerBuilder", ["CometRelay", "useVideoPlayerShakaPerformanceLoggerBuilder_init.graphql", "useVideoPlayerShakaPerformanceLoggerBuilder_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    h !== void 0 ? h : h = b("useVideoPlayerShakaPerformanceLoggerBuilder_init.graphql");

    function a(a) {
        a = d("CometRelay").useFragment(i !== void 0 ? i : i = b("useVideoPlayerShakaPerformanceLoggerBuilder_video.graphql"), a);
        var c = a.video_player_shaka_performance_logger_init2 ? d("CometRelay").ModuleResource.read(a.video_player_shaka_performance_logger_init2) : null;
        a = (a = a.video_player_shaka_performance_logger_init2) == null ? void 0 : a.per_session_sampling_rate;
        return c != null && a != null ? new c({
            perSessionSampleRate: a
        }) : null
    }
    g["default"] = a
}), 98);
__d("VideoPlayerRelay.react", ["fbt", "CastingStateHooks", "CometPlaceholder.react", "CometRelay", "CometTrackingNodeProvider.react", "CurrentUser", "ErrorMetadata", "InstreamVideoAdBreaksPlayer.react", "JSResourceForInteraction", "VideoPlayerFallbackCover.react", "VideoPlayerRelay_video.graphql", "VideoPlayerRetryableErrorBoundary.react", "VideoPlayerXImplRelayWrapper.react", "XFBLatencySensitiveTypeUtils.facebook", "cr:1446473", "cr:1701936", "cr:759", "cr:835", "defaultErrorBoundaryFallback", "deferredLoadComponent", "emptyFunction", "err", "getAvailableMimeCodecsFromDashManifest", "getVideoPlayerAutoplayProps", "gkx", "lazyLoadComponent", "manifestHasPlayableRepresentations", "normalizeVideoPlayerLoopCount", "react", "recoverableViolation", "requireDeferredForDisplay", "unrecoverableViolation", "useGraphQLVideoAutoplayGatingResult", "useGraphQLVideoDRMInfo", "useGraphQLVideoP2PSettings", "usePremiumMusicVideoInterruptionSubscription", "useProgressiveImplementationData", "useVideoImplementations", "useVideoPlayerAudioAvailabilityInfoRelay", "useVideoPlayerAudioSettings", "useVideoPlayerCaptionsSettings", "useVideoPlayerLiveLatencyKnobSettings", "useVideoPlayerShakaPerformanceLoggerBuilder"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = d("react"),
        k = d("react").useMemo,
        l = (e = b("cr:759")) != null ? e : c("emptyFunction"),
        m = (e = b("cr:835")) != null ? e : c("emptyFunction"),
        n = c("gkx")("5128"),
        o = c("gkx")("5194"),
        p = c("deferredLoadComponent")(c("requireDeferredForDisplay")("VideoPlayerSphericalFallbackCover.react").__setRef("VideoPlayerRelay.react")),
        q = c("lazyLoadComponent")(c("JSResourceForInteraction")("VideoPlayerVideoIsCastingCover.react").__setRef("VideoPlayerRelay.react"));

    function r(a) {
        var e, f, g = a.accessToken,
            r = a.adClientToken,
            s = a.additionalLogData,
            t = a.audioOnly,
            u = a.autoplayGatingResult,
            v = a.bufferEndLimit,
            w = a.canAutoplay,
            x = a.children,
            y = a.disableCVCSubscription;
        y = y === void 0 ? !1 : y;
        var z = a.disableLoadingIndicator;
        z = z === void 0 ? !1 : z;
        var A = a.disableLogging,
            B = a.externalLogID,
            C = a.externalLogType,
            D = a.graphQLVideoDRMInfo,
            E = a.initialForceHD,
            F = E === void 0 ? !1 : E;
        E = a.initialTracePolicy;
        var G = a.loadSequence,
            H = a.loopCount,
            I = a.manifestURL_DO_NOT_USE,
            J = a.playerFormat;
        J = J === void 0 ? "inline" : J;
        var aa = a.playerOriginOverride,
            ba = a.portalingEnabled,
            ca = a.portalingFromVideoID,
            da = a.portalingPlaceMetaData,
            ea = a.portalingRenderPlaceholder,
            fa = a.productAttribution,
            ga = a.seoWebCrawlerVideoTracks,
            ha = a.source_VPL_LOGGING_HACK,
            ia = a.startTimestamp,
            K = a.subOrigin,
            L = a.video,
            M = a.volumeSetting;
        a = a.wrapVideoPixels_EXPERIMENTAL;
        c("usePremiumMusicVideoInterruptionSubscription")(c("CurrentUser").getID());
        var N = d("CometRelay").useFragment(i !== void 0 ? i : i = b("VideoPlayerRelay_video.graphql"), L);
        L = N.dash_prefetch_experimental;
        e = ((e = N.video_available_captions_locales) != null ? e : []).find(function(a) {
            a = a.localized_creation_method;
            return a != null
        }) != null;
        f = d("XFBLatencySensitiveTypeUtils.facebook").toJSEnum((f = N.latency_sensitive_config) == null ? void 0 : f.broadcast_latency_sensitivity);
        var O = b("cr:1701936")(N, {
                adClientToken: r
            }),
            ja = l(N.id),
            ka = c("useGraphQLVideoP2PSettings")(N),
            P = c("useGraphQLVideoDRMInfo")(N);
        P = (D = D) != null ? D : P;
        D = !!(P && P.fairplayCert !== null);
        var Q = D || n && !!N.is_live_streaming || o && typeof MediaSource === "undefined";
        D = c("useProgressiveImplementationData")(N, {
            initialForceHD: !1
        });
        D = (D == null ? void 0 : D.hdSrc) != null || (D == null ? void 0 : D.sdSrc) != null;
        var R = !1;
        if (!Q && D && c("gkx")("8319") && N.dash_manifest != null && N.dash_manifest !== "" && N.is_live_streaming !== !0) {
            D = c("getAvailableMimeCodecsFromDashManifest")(N.dash_manifest);
            D.length > 0 && !c("manifestHasPlayableRepresentations")(D) && c("gkx")("2938") && (R = !0)
        }
        D = k(function() {
            return {
                forceProgressiveImpl: Q || R,
                initialForceHD: F,
                manifestURL_DO_NOT_USE: I,
                videoFBID: N.id,
                videoPlayerShakaConfig: O
            }
        }, [Q, R, F, I, N.id, O]);
        D = c("useVideoImplementations")(N, D);
        var S = c("useVideoPlayerCaptionsSettings")(N),
            la = c("useVideoPlayerAudioSettings")(N),
            T = c("useVideoPlayerLiveLatencyKnobSettings")(N),
            ma = T.desiredLatencyMs;
        T = T.latencyToleranceMs;
        var na = c("useVideoPlayerAudioAvailabilityInfoRelay")(N),
            U = c("useGraphQLVideoAutoplayGatingResult")(N);
        U = c("getVideoPlayerAutoplayProps")(U, w, u);
        w = b("cr:1446473")(N);
        u = c("useVideoPlayerShakaPerformanceLoggerBuilder")(N);
        var oa = m(N),
            pa = j.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                children: j.jsx(c("InstreamVideoAdBreaksPlayer.react"), {
                    playerFormat: J,
                    subOrigin: K,
                    video: N
                })
            }),
            V = d("CastingStateHooks").useCastingVideoID(),
            W = N.id;
        if (W == null) throw c("unrecoverableViolation")("Cannot play video: Empty video ID", "comet_video_player");
        var X = null;
        if (c("gkx")("1076") && !Q && N.dash_manifest != null && N.dash_manifest !== "") {
            var Y = c("getAvailableMimeCodecsFromDashManifest")(N.dash_manifest);
            (Y.length <= 0 || !Y.every(function(a) {
                return a.isRequiredForPlayback && a.isTypeSupported || !a.isRequiredForPlayback
            })) && (X = N.is_live_streaming === !0 ? h._("Sorry, this live video cannot be played on your current browser or hardware.") : null)
        }
        Y = N.unsupported_browser_message != null ? N.unsupported_browser_message : X;
        if (Y != null) {
            X = c("err")("Cannot play video: Browser is not supported");
            X.metadata = new(c("ErrorMetadata"))();
            X.metadata.addEntry("COMET_VIDEO", "VIDEO_ID", W);
            c("recoverableViolation")("Cannot play video: Browser is not supported", "comet_video_player", {
                error: X
            });
            return j.jsx(c("VideoPlayerFallbackCover.react"), {
                message: Y
            })
        }
        X = N.permalink_url;
        Y = N.spherical_video_renderer;
        Y = Y ? j.jsx(d("CometRelay").MatchContainer, {
            match: Y,
            props: {
                playerFormat: J,
                sphericalVideoRenderer: Y,
                subOrigin: K,
                videoTahoeUrl: X
            }
        }) : null;
        X = N.is_spherical;
        var Z = N.is_spherical_enabled,
            $ = N.permalink_url;
        if (X === !0 && Z !== !0) {
            if ($ == null || $ === "") throw c("unrecoverableViolation")("Cannot play video: Empty permalink URL for a spherical video", "comet_video_player");
            return j.jsx(p, {
                videoTahoeUrl: $
            })
        }
        if (V != null && V === N.id) return j.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            children: j.jsx(q, {
                video: N
            })
        });
        $ = (Z = (X = N.live_playback_instrumentation_configs) == null ? void 0 : X.is_client_triggered_trace_enabled) != null ? Z : !1;
        V = c("normalizeVideoPlayerLoopCount")(H, N.is_looping, N.loop_count);
        return j.jsx(c("VideoPlayerXImplRelayWrapper.react"), {
            VideoPlayerShakaPerformanceLoggerClass: w,
            accessToken: g,
            adClientToken: r,
            additionalLogData: s,
            alt: c("gkx")("1924962") ? N.animated_image_caption : void 0,
            alwaysShowCaptions: S.alwaysShowCaptions,
            areCaptionsAutogenerated: e,
            audioAvailabilityInfo: na,
            audioOnly: N.is_podcast_video === !0 || t,
            autoplayGatingResult: U.autoplayGatingResult,
            autoplaySetting: U.autoplaySetting,
            broadcastId: N.broadcast_id,
            broadcastLatencySensitivity: f,
            broadcastStatus: N.broadcast_status,
            broadcasterOrigin: N.broadcaster_origin,
            bufferEndLimit: v,
            canAutoplay: U.canAutoplay,
            captionDisplayStyle: S.captionDisplayStyle,
            captionsUrl: N.captions_url,
            children: x,
            desiredLatencyMs: ma,
            disableCVCSubscription: y,
            disableLoadingIndicator: z,
            disableLogging: A,
            expiredVideoUrlRefreshHandler: ja,
            externalLogID: B,
            externalLogType: C,
            graphQLVideoDRMInfo: P,
            graphQLVideoP2PSettings: ka,
            implementations: D,
            initialRepresentationIds: L,
            initialTracePolicy: E,
            instreamVideoAdBreaksPlayer: pa,
            isClientTriggeredTraceEnabled: $,
            isLiveStreaming: N.is_live_streaming,
            isLiveTraceEnabled: N.is_live_trace_enabled,
            isNCSR: N.is_ncsr,
            isPremiumMusicVideo: N.pmv_metadata != null,
            isVideoBroadcast: N.is_video_broadcast,
            latencyToleranceMs: T,
            loadSequence: G,
            loopCount: V,
            originalHeight: N.original_height,
            originalWidth: N.original_width,
            playerFormat: J,
            playerOriginOverride: aa,
            portalingEnabled: ba,
            portalingFromVideoID: ca,
            portalingPlaceMetaData: da,
            portalingRenderPlaceholder: ea,
            productAttribution: fa,
            seoWebCrawlerVideoTracks: ga,
            source_VPL_LOGGING_HACK: ha,
            startTimestamp: ia,
            subOrigin: K,
            videoFBID: W,
            videoPlayerIMFFromVideoMetadata: oa,
            videoPlayerShakaPerformanceLoggerBuilder: u,
            videoPlayerSpherical: Y,
            volumeSetting: M !== void 0 ? M : la.preferredVolumeSetting,
            wrapVideoPixels_EXPERIMENTAL: a
        }, W)
    }
    r.displayName = r.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.doNotRenderErrorBoundaryIUnderstandIMustProvideMyOwn;
        b = b === void 0 ? !1 : b;
        var d = a.errorBoundaryFallback;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["doNotRenderErrorBoundaryIUnderstandIMustProvideMyOwn", "errorBoundaryFallback"]);
        a = j.jsx(c("CometTrackingNodeProvider.react"), {
            trackingNode: 13,
            children: j.jsx(r, babelHelpers["extends"]({}, a))
        });
        return b ? a : j.jsx(c("VideoPlayerRetryableErrorBoundary.react"), {
            description: "VideoPlayerRelayBoundary",
            fallback: (b = d) != null ? b : c("defaultErrorBoundaryFallback"),
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("handleCometRelayExpiredVideoUrlRefresh", ["ErrorMetadata", "ErrorSerializer", "FBLogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var d = b == null ? void 0 : b.video,
            e = d == null ? void 0 : d.rmd_refreshed_url,
            f = e == null ? void 0 : e.new_url,
            g = e == null ? void 0 : e.reason,
            h = null;
        b == null ? h = c("err")("Video URL refresh GraphQL response data is " + (b === null ? "null" : "undefined")) : d == null ? h = c("err")("Video URL refresh GraphQL response video is " + (d === null ? "null" : "undefined")) : e == null ? h = c("err")("Video URL refresh GraphQL response video.rmd_refreshed_url is " + (e === null ? "null" : "undefined")) : (f == null || f === "") && (g == null || g === "") && (h = c("err")("Video URL refresh GraphQL response video.rmd_refreshed_url.new_url is " + (f === "" ? "an empty string" : f === null ? "null" : "undefined") + " and video.rmd_refreshed_url.reason is " + (g === "" ? "an empty string" : g === null ? "null" : "undefined")));
        if (h != null) {
            b = new(c("ErrorMetadata"))();
            b.addEntry("COMET_VIDEO", "VIDEO_ID", String(a));
            h.metadata = b;
            throw c("FBLogger")("comet_video_player").catching(h).mustfixThrow("Video URL refresh failed for ID: %s - %s", String(a), c("ErrorSerializer").toReadableMessage(h))
        }
        return {
            reason: (d = g) != null ? d : null,
            refreshedUrl: (e = f) != null ? e : null
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerCaptionsDisplayConfigContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        liveCaptionsTextAlignment: null,
        textSizeMapping: null
    });
    g["default"] = b
}), 98);
__d("VideoPlayerCaptionsDisplay.react", ["VideoPlayerCaptionsDisplayConfigContext", "VideoPlayerControlsBottomRowAddOnContext", "VideoPlayerHooks", "react", "recoverableViolation", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            captionsCenterAlign: {
                justifyContent: "xl56j7k",
                textAlign: "x2b8uid"
            },
            captionsContainer: {
                bottom: "xfqi8uc",
                boxSizing: "x9f619",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                position: "x10l6tqk",
                textAlign: "x2b8uid",
                transitionDuration: "xu6gjpd",
                transitionProperty: "x11xpdln",
                transitionTimingFunction: "x1r7x56h",
                width: "xh8yej3"
            },
            captionsDefault: {
                backgroundColor: "x18l40ae",
                color: "x14ctfv",
                fontSize: "x1lkfr7t",
                fontWeight: "xk50ysn",
                lineHeight: "x37zpob",
                marginTop: "xdj266r",
                marginEnd: "xv81d3b",
                marginBottom: "xat24cr",
                marginStart: "x5jn1jc",
                paddingTop: "xulzisn",
                paddingEnd: "x1msn8f2",
                paddingBottom: "x1uwfbks",
                paddingStart: "x1qobr7z"
            },
            captionsLeftAlign: {
                justifyContent: "x1nhvcw1",
                textAlign: "x1yc453h"
            },
            captionsRightAlign: {
                justifyContent: "x13a6bvl",
                textAlign: "xp4054r"
            }
        },
        k = {
            BIG: "25px",
            BIGGER: "30px",
            BIGGEST: "34px",
            DEFAULT: "17px",
            MEDIUM: "21px",
            SMALL: "13px",
            SMALLEST: "8px"
        },
        l = {
            DARK: .75,
            DEFAULT: .45,
            LIGHT: .25,
            OPAQUE: 1,
            TRANSPARENT: 0
        },
        m = {
            BLACK: "20, 22, 26",
            BLUE: "0, 0, 255",
            CYAN: "0, 255, 255",
            GREEN: "0, 255, 0",
            MAGENTA: "255, 0, 255",
            RED: "255, 0, 0",
            WHITE: "255, 255, 255",
            YELLOW: "255, 255, 0"
        };

    function n(a) {
        switch (a) {
            case "center":
                return j.captionsCenterAlign;
            case "left":
                return j.captionsLeftAlign;
            case "right":
                return j.captionsRightAlign;
            default:
                c("recoverableViolation")("Unsupported captions text alignment: " + a, "comet_video_player")
        }
    }

    function o(a, b, c) {
        var d = {},
            e = a.captionsBackgroundColor,
            f = a.captionsBackgroundOpacity,
            g = a.captionsTextColor;
        a = a.captionsTextSize;
        if (e !== null) {
            f = f !== null ? l[f] : 1;
            d.backgroundColor = "rgba(" + m[e] + "," + f + ")"
        }
        g !== null && (d.color = "rgba(" + m[g] + ")");
        a !== null && (d.fontSize = b != null ? babelHelpers["extends"]({}, k, b)[a] : k[a]);
        c && (d.marginBottom = 35);
        return d
    }

    function a(a) {
        var b = a.activeCaptions,
            e = a.adjustments;
        a = a.captionDisplayStyle;
        var f = b == null ? void 0 : b.rows,
            g = i(c("VideoPlayerCaptionsDisplayConfigContext")),
            k = g.liveCaptionsTextAlignment;
        g = g.textSizeMapping;
        var l = i(d("VideoPlayerControlsBottomRowAddOnContext").VideoPlayerControlsBottomRowAddOnContext);
        l = (l == null ? void 0 : l.getBottomRowAddOn()) != null;
        var m = {};
        a && (m = o(a, g, l));
        a = d("VideoPlayerHooks").useIsLive();
        b = (l = b == null ? void 0 : (g = b.styles) == null ? void 0 : g.textAlignment) != null ? l : "center";
        if (f != null && f.length > 0) {
            g = f.map(function(a) {
                return a.trim()
            }).filter(function(a) {
                return !!a
            });
            return g.length > 0 ? h.jsx("div", {
                className: c("stylex")(j.captionsContainer, n(a ? (l = k) != null ? l : b : b)),
                style: {
                    paddingLeft: e.left,
                    paddingRight: e.right,
                    transform: "translateY(" + -e.bottom + "px)"
                },
                children: h.jsx("div", {
                    className: c("stylex")(j.captionsDefault),
                    style: m,
                    children: g.map(function(a, b) {
                        return h.jsxs("span", {
                            children: [a, h.jsx("br", {})]
                        }, b)
                    })
                })
            }) : null
        }
        return null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.memo(a);
    e = b;
    g["default"] = e
}), 98);
__d("useVideoPlayerCaptionsDisplayAdjustments", ["VideoPlayerHooks", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;

    function a() {
        var a = d("VideoPlayerHooks").useVideoPlayerCaptionsReservations();
        return h(function() {
            var b = {
                bottom: 0,
                left: 0,
                right: 0,
                top: 0
            };
            a.length > 0 && a.forEach(function(a) {
                b[a.location] += a.size
            });
            return b
        }, [a])
    }
    g["default"] = a
}), 98);
__d("VideoPlayerCaptions.react", ["VideoPlayerCaptionsDisplay.react", "VideoPlayerHooks", "react", "useVideoPlayerCaptionsDisplayAdjustments"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a() {
        var a = d("VideoPlayerHooks").useActiveCaptions(),
            b = c("useVideoPlayerCaptionsDisplayAdjustments")(),
            e = d("VideoPlayerHooks").useCaptionDisplayStyle();
        return h.jsx(c("VideoPlayerCaptionsDisplay.react"), {
            activeCaptions: a,
            adjustments: b,
            captionDisplayStyle: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerCaptionsArea.react", ["VideoPlayerCaptions.react", "VideoPlayerContexts", "VideoPlayerHooks", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useReducer,
        j = b.useState;

    function k(a, b) {
        switch (b.type) {
            case "reserve":
                return a.concat(b.reservation);
            case "release":
                return a.filter(function(a) {
                    return a !== b.reservation
                });
            default:
                return a
        }
    }

    function a(a) {
        a = a.children;
        var b = i(k, []),
            e = b[0],
            f = b[1];
        b = j({
            release: function(a) {
                f({
                    reservation: a,
                    type: "release"
                })
            },
            reserve: function(a) {
                f({
                    reservation: a,
                    type: "reserve"
                });
                return a
            }
        });
        b = b[0];
        var g = d("VideoPlayerHooks").useCaptionsVisible();
        return h.jsx(d("VideoPlayerContexts").VideoPlayerCaptionsReservationActionsContext.Provider, {
            value: b,
            children: h.jsxs(d("VideoPlayerContexts").VideoPlayerCaptionsReservationsContext.Provider, {
                value: e,
                children: [g ? h.jsx(c("VideoPlayerCaptions.react"), {}) : null, a]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerFallbackLearnMoreLink.react", ["fbt", "CometLink.react", "TetraText.react", "gkx", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        a = c("gkx")("1224637") ? "/help/work/1876956335887765/i-cant-view-or-play-videos-on-workplace" : "https://www.facebook.com/help/396404120401278/list";
        return i.jsx(c("TetraText.react"), {
            color: "primaryOnMedia",
            type: "headlineEmphasized3",
            children: i.jsx(c("CometLink.react"), {
                href: a,
                children: h._("Learn More")
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerFallbackCoverImplWithRetry.react", ["fbt", "ix", "TetraText.react", "VideoPlayerActionButton.react", "VideoPlayerFallbackLearnMoreLink.react", "cr:1672302", "cr:4149", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var e = a.debugError,
            f = a.message;
        a = a.onRetry;
        return j.jsx("div", {
            className: "x1sln4lm x1a8lsjc x1iji9kk x889kno x10wlt62 x6ikm8r xl56j7k x5yr21d x78zum5 xatbrnm x6s0dn4",
            children: j.jsxs("div", {
                className: "x3es6ox xdt5ytf x78zum5 x6s0dn4",
                children: [j.jsx("div", {
                    className: "x193iq5w xdt5ytf x78zum5 x6s0dn4",
                    children: j.jsx(c("TetraText.react"), {
                        align: "center",
                        color: "primaryOnMedia",
                        type: "bodyLink3",
                        children: f
                    })
                }), b("cr:4149") ? j.jsx(b("cr:4149"), {
                    error: e
                }) : null, a ? j.jsx("div", {
                    className: "x193iq5w xw7yly9 xdt5ytf x78zum5 x6s0dn4",
                    children: j.jsx(c("VideoPlayerActionButton.react"), {
                        icon: d("fbicon")._(i("534218"), 16),
                        label: h._("Try Again"),
                        onPress: a,
                        testid: void 0
                    })
                }) : j.jsx("div", {
                    className: "x193iq5w xw7yly9 xdt5ytf x78zum5 x6s0dn4",
                    children: j.jsx(c("VideoPlayerFallbackLearnMoreLink.react"), {})
                }), b("cr:1672302") ? j.jsx(b("cr:1672302"), {
                    error: e
                }) : null]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerFallbackCoverImplWithoutRetry.react", ["TetraText.react", "VideoPlayerFallbackLearnMoreLink.react", "cr:1672302", "cr:4149", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var d = a.debugError,
            e = a.message;
        a.onRetry;
        return h.jsx("div", {
            className: "x13vifvy x17qophe x10l6tqk x10wlt62 x6ikm8r xl56j7k xds687c x78zum5 x9f619 x1ey2m1c xatbrnm x6s0dn4",
            children: h.jsxs("div", {
                className: "x3es6ox xdt5ytf x78zum5 x6s0dn4",
                children: [h.jsx("div", {
                    className: "x193iq5w xdt5ytf x78zum5 x6s0dn4",
                    children: h.jsx(c("TetraText.react"), {
                        align: "center",
                        color: "primaryOnMedia",
                        type: "bodyLink3",
                        children: e
                    })
                }), h.jsx("div", {
                    className: "x193iq5w xw7yly9 xdt5ytf x78zum5 x6s0dn4",
                    children: h.jsx(c("VideoPlayerFallbackLearnMoreLink.react"), {})
                }), b("cr:4149") ? h.jsx(b("cr:4149"), {
                    error: d
                }) : null, b("cr:1672302") ? h.jsx(b("cr:1672302"), {
                    error: d
                }) : null]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSphericalFallbackCover.react", ["fbt", "TetraText.react", "VideoPlayerSphericalMediaGyroOverlay.react", "react", "unrecoverableViolation", "useCometRouterDispatcher", "useFeedClickEventHandler"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = d("react").useState;

    function a(a) {
        var b = a.videoTahoeUrl,
            d = c("useCometRouterDispatcher")();
        a = j(!1);
        var e = a[0],
            f = a[1];
        if (d == null) throw c("unrecoverableViolation")("Missing CometRouterDispatcher", "comet_video_player");
        a = c("useFeedClickEventHandler")(function() {
            d.go(b, {})
        });
        return i.jsxs("div", {
            className: "x13vifvy x17qophe x10l6tqk x13a6bvl xdt5ytf xds687c x78zum5 x1ypdohk x9f619 x1ey2m1c x6s0dn4",
            onClick: a,
            onMouseEnter: function() {
                return f(!0)
            },
            onMouseLeave: function() {
                return f(!1)
            },
            role: "link",
            tabIndex: 0,
            children: [i.jsx(c("VideoPlayerSphericalMediaGyroOverlay.react"), {
                isActive: !0
            }), i.jsx("div", {
                className: "x1n2onr6 xwajptj",
                children: e ? i.jsx(c("TetraText.react"), {
                    color: "primaryOnMedia",
                    type: "bodyLink3",
                    children: h._("Click to expand")
                }) : null
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSpinner.react", ["CometLoadingAnimation.react", "react", "stylex", "useDebouncedValue"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = 36;

    function a(a) {
        a = a.isVisible;
        var b = c("useDebouncedValue")(a, a ? 200 : 500);
        return h.jsx("div", {
            className: c("stylex")({
                "height-1": "xc9qbxq",
                "opacity-1": "x1hc1fzr",
                "position-1": "x10l6tqk",
                "start-1": "xtzzx4i",
                "top-1": "xwa60dl",
                "transform-0.1": "x11lhmoz",
                "transition-delay-1": "x5w5eug",
                "transition-duration-1": "x13dflua",
                "transition-property-1": "x19991ni",
                "transition-timing-function-1": "xl405pv",
                "width-1": "x14qfxbe"
            }, a ? null : {
                "opacity-1": "xg01cxk",
                "transition-delay-1": "x2p8vrm",
                "transition-duration-1": "x13dflua",
                "transition-property-1": "x1jl3cmp",
                "transition-timing-function-1": "xl405pv",
                "visibility-1": "xlshs6z"
            }),
            children: h.jsx(c("CometLoadingAnimation.react"), {
                animationPaused: !b,
                size: i
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSurface.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.render = function() {
            return this.props.children != null ? this.props.children : null
        };
        return b
    }(a.PureComponent);
    g["default"] = b
}), 98);
__d("VideoPlayerFullscreenControl.react", ["fbt", "ix", "VideoPlayerControlIcon.react", "VideoPlayerHooks", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.onPress,
            e = a.onUserInteraction,
            f = a.shouldUnmute,
            g = d("VideoPlayerHooks").useController(),
            k = d("VideoPlayerHooks").useIsFullscreen(),
            l = d("VideoPlayerHooks").useLastMuteReason();
        a = k ? h._("Exit fullscreen") : h._("Enter fullscreen");
        var m = function() {
            b && b(), g.requestSetIsFullscreen(!k), f === !0 && l !== "user_initiated" && g.setMuted(!1, "product_initiated"), e && e({
                name: "video_fullscreen_button",
                type: "happened"
            })
        };
        return j.jsx(c("VideoPlayerControlIcon.react"), {
            icon: k ? d("fbicon")._(i("517758"), 20) : d("fbicon")._(i("517763"), 20),
            label: a,
            onPress: m,
            tooltip: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useVideoPlayerDefaultControlsVisibility", ["VideoPlayerHooks", "VideoPlayerInstreamAdsStateHooks", "VideoPlayerUserInteractionCounter", "clearTimeout", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useState,
        j = 5e3;

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.forceVisible,
            e = a.forceVisibleOnMount;
        a.isInteracting;
        a = d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteractionCounter();
        var f = a.ongoingInteractionsCount;
        a = a.onUserInteraction;
        var g = d("VideoPlayerHooks").useEnded(),
            k = d("VideoPlayerHooks").useIsHovering(),
            l = d("VideoPlayerHooks").usePaused(),
            m = d("VideoPlayerHooks").useIsMouseIdle(),
            n = d("VideoPlayerHooks").useVideoPlaybackEnded(),
            o = d("VideoPlayerInstreamAdsStateHooks").useInstreamAdsIsStart();
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_pointer_active", k && !m, a);
        k = i(e === !0);
        var p = k[0],
            q = k[1];
        h(function() {
            if (!l && p) {
                var a = c("setTimeout")(function() {
                    q(!1)
                }, j);
                return function() {
                    c("clearTimeout")(a)
                }
            }
        }, [p, l]);
        b === !0 || b === !1 ? m = b : o ? m = !1 : f > 0 || p ? m = !0 : l ? m = g ? n : !0 : m = !1;
        return {
            isControlsVisible: m,
            onUserInteraction: a
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerDefaultControls.react", ["CometPlaceholder.react", "CometRelay", "CometWarningScreenContext", "VideoPlayerDefaultControlsProperties", "VideoPlayerDefaultControls_video.graphql", "VideoPlayerFullscreenControl.react", "VideoPlayerHooks", "cr:1875194", "deferredLoadComponent", "emptyFunction", "react", "requireDeferred", "useVideoPlayerBigPlayButtonOverlay", "useVideoPlayerDefaultControlsVisibility"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react"),
        j = (e = b("cr:1875194")) != null ? e : c("emptyFunction"),
        k = c("deferredLoadComponent")(c("requireDeferred")("VideoPlayerDefaultControlsImplLive.react").__setRef("VideoPlayerDefaultControls.react")),
        l = c("deferredLoadComponent")(c("requireDeferred")("VideoPlayerDefaultControlsImplNotLive.react").__setRef("VideoPlayerDefaultControls.react"));

    function a(a) {
        var e, f = a.forceVisible,
            g = a.forceVisibleOnMount,
            m = a.mutedButtonVisibility,
            n = a.pictureInPictureControl,
            o = a.renderExpandControl,
            p = a.shouldRenderBigPlayButton,
            q = a.shouldRenderCaptionsControl,
            r = a.shouldRenderCostreamControl,
            s = a.shouldRenderLivePauseControl,
            t = a.shouldRenderModeratorControl,
            u = a.shouldRenderQuietModeControl,
            v = a.shouldRenderWatchAndScrollControl,
            w = a.shouldUnmuteForBigPlayButton,
            x = a.skipControl,
            y = a.subOrigin,
            z = a.video;
        a = a.videoTahoeUrl;
        z = d("CometRelay").useFragment(h !== void 0 ? h : h = b("VideoPlayerDefaultControls_video.graphql"), z);
        e = (e = d("CometWarningScreenContext").useIsContentVisible()) != null ? e : !1;
        var A = j();
        A = A != null ? A.isSilentAtPlayhead : !1;
        var B = d("VideoPlayerHooks").useMuted(),
            C = d("VideoPlayerHooks").useIsLive();
        g = c("useVideoPlayerDefaultControlsVisibility")({
            forceVisible: f,
            forceVisibleOnMount: g
        });
        var D = g.isControlsVisible;
        g = g.onUserInteraction;
        p = c("useVideoPlayerBigPlayButtonOverlay")({
            forceVisible: p != null ? p : f === !1 ? !1 : void 0,
            shouldUnmute: w
        });
        f = p.bigPlayButtonElement;
        w = p.bigPlayButtonIsVisible;
        p = D && !w && e;
        D = m === d("VideoPlayerDefaultControlsProperties").MutedButtonVisibility.SAME_AS_OTHER_CONTROLS ? p : (B || p || A) && !w;
        e = o != null ? o({
            onUserInteraction: g
        }) : i.jsx(c("VideoPlayerFullscreenControl.react"), {
            onUserInteraction: g
        });
        m = C ? i.jsx(k, {
            expandControl: e,
            isControlsVisible: p,
            isVolumeControlVisible: D,
            onUserInteraction: g,
            pictureInPictureControl: n,
            shouldRenderCaptionsControl: q,
            shouldRenderCostreamControl: r,
            shouldRenderModeratorControl: t,
            shouldRenderPauseControl: s,
            shouldRenderQuietModeControl: u,
            shouldRenderWatchAndScrollControl: v,
            subOrigin: y,
            video: z,
            videoTahoeUrl: a
        }) : i.jsx(l, {
            expandControl: e,
            isControlsVisible: p,
            isVolumeControlVisible: D,
            onUserInteraction: g,
            pictureInPictureControl: n,
            shouldRenderCaptionsControl: q,
            shouldRenderQuietModeControl: u,
            shouldRenderWatchAndScrollControl: v,
            skipControl: x,
            subOrigin: y,
            video: z,
            videoTahoeUrl: a
        });
        return i.jsxs(i.Fragment, {
            children: [f, i.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                children: m
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("parseJSONMixed", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a == null ? null : JSON.parse(a, b)
    }
    f["default"] = a
}), 66);
__d("tryParseJSONMixed", ["parseJSONMixed"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        try {
            return c("parseJSONMixed")(a, b)
        } catch (a) {
            return null
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerEmsg", ["DataViewReader", "FBLogger", "Mp4DASHEventMessageBox", "Mp4Demuxer", "err", "getErrorSafe", "refine", "shallowArrayEqual", "tryParseJSONMixed"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f = d("refine").custom(function(a) {
        return typeof a === "number" ? a : typeof a === "string" && /^[0-9]+$/.test(a) ? a : void 0
    });
    var h = d("refine").object({
            rosterData: d("refine").object({
                activeSpeaker: d("refine").nullable(f),
                speakerInfoList: d("refine").array(d("refine").object({
                    audioMuted: d("refine").bool(),
                    id: f
                }))
            })
        }),
        i = d("refine").object({
            imf: d("refine").object({
                pluginEventData: d("refine").mixed(),
                pluginEventType: d("refine").string()
            })
        });

    function j(a, b, e) {
        try {
            return d("refine").jsonParserEnforced(a)(b)
        } catch (d) {
            if (c("tryParseJSONMixed")(b) == null) throw c("err")('Failed to parse emsg payload as JSON for scheme "%s"', e);
            else {
                a = c("getErrorSafe")(d);
                throw c("err")('Unsupported emsg payload format for scheme "%s": %s', e, a.message)
            }
        }
    }

    function k(a) {
        var b = a.dataStr,
            d = a.emsgDurationInSec,
            e = a.emsgFields,
            f = a.emsgStartTimeInSec,
            g = a.representationID;
        a = a.videoID;
        g = {
            emsgDataStr: void 0,
            emsgDurationInSec: void 0,
            emsgId: void 0,
            emsgScheme: void 0,
            emsgSchemeTopic: void 0,
            emsgStartTimeInSec: void 0,
            representationID: g,
            videoID: a
        };
        try {
            g.emsgDataStr = b;
            g.emsgStartTimeInSec = f;
            g.emsgDurationInSec = d;
            var k = e == null ? void 0 : e.id;
            g.emsgId = k;
            var l = e == null ? void 0 : e.schemeIdUri;
            g.emsgScheme = e == null ? void 0 : e.schemeIdUri;
            if (l == null ? void 0 : l.startsWith("livedash:trace:")) return null;
            e = (e = /^urn:fb:(.*)$/.exec((e = l) != null ? e : "")) == null ? void 0 : e[1];
            g.emsgSchemeTopic = e;
            if (l == null || e == null || e === "") throw c("err")('Unrecognized emsg scheme "%s"', String(l));
            if (f == null) throw c("err")('Missing start time in emsg "%s"', String(l));
            switch (l) {
                case "urn:fb:metadata":
                    var m = j(h, b, l);
                    return {
                        data: m.rosterData,
                        emsgDurationInSec: d,
                        emsgId: k,
                        emsgScheme: l,
                        emsgSchemeTopic: e,
                        emsgStartTimeInSec: f,
                        type: "roster_data"
                    };
                case "urn:fb:interactive_plugin":
                    m = j(i, b, l);
                    return {
                        data: m.imf,
                        emsgDurationInSec: d,
                        emsgId: k,
                        emsgScheme: l,
                        emsgSchemeTopic: e,
                        emsgStartTimeInSec: f,
                        type: "imf_interactive_plugin_event"
                    };
                case "urn:fb:lvstickr":
                    return {
                        dataStr: b,
                        emsgDurationInSec: d,
                        emsgId: k,
                        emsgScheme: l,
                        emsgSchemeTopic: e,
                        emsgStartTimeInSec: f,
                        type: "imf_live_sticker"
                    };
                default:
                    return {
                        dataStr: b,
                        emsgDurationInSec: d,
                        emsgId: k,
                        emsgScheme: l,
                        emsgSchemeTopic: e,
                        emsgStartTimeInSec: f,
                        type: "imf_other"
                    }
            }
        } catch (d) {
            m = c("getErrorSafe")(d);
            b = c("FBLogger")("comet_video_player").catching(m);
            a != null && b.addMetadata("COMET_VIDEO", "VIDEO_ID", a);
            b.addMetadata("COMET_VIDEO", "VIDEO_IMPLEMENTATION_DEBUG_DATA", JSON.stringify(g));
            b.warn("Failed to parse emsg data: %s", String(m))
        }
        return null
    }

    function a(a, b, d) {
        var e = [];
        a = new(c("Mp4Demuxer"))(new DataView(a));
        while (!a.atEnd()) {
            var f = a.parseBox();
            if (f.getType() === c("Mp4DASHEventMessageBox").canonicalType) {
                var g = a.parseCanonicalBox(c("Mp4DASHEventMessageBox"), a.parseFullBox(f));
                if (g instanceof c("Mp4DASHEventMessageBox")) {
                    var h = g.getMessageData();
                    h = new(c("DataViewReader"))(h).readZeroTerminatedString(h.byteLength);
                    g = k({
                        dataStr: h,
                        emsgDurationInSec: (h = g.getDuration()) != null ? h : void 0,
                        emsgFields: g.getEmsgFields(),
                        emsgStartTimeInSec: (h = g.getStartTime()) != null ? h : void 0,
                        representationID: d,
                        videoID: b
                    });
                    g != null && e.push(g)
                }
            }
            a.skipBox(f)
        }
        return e
    }

    function l(a) {
        var b;
        return [(b = a.emsgSchemeTopic) != null ? b : "", (b = a.emsgId) != null ? b : "", (b = a.emsgStartTimeInSec) != null ? b : "", (b = a.emsgDurationInSec) != null ? b : ""].join(":")
    }

    function m(a, b) {
        a.set(l(b), b);
        return a
    }

    function b(a, b) {
        return b.reduce(m, new Map(a))
    }

    function e(a, b, d) {
        a = b == null ? [] : Array.from(a.values()).filter(function(a) {
            var c = a.emsgStartTimeInSec;
            a = a.emsgDurationInSec || 0;
            return c != null && b >= c && b < c + a
        }).sort(function(a, b) {
            return (a.emsgStartTimeInSec || 0) - (b.emsgStartTimeInSec || 0)
        });
        return c("shallowArrayEqual")(d, a) ? d : a
    }
    g.parseEmsgBoxMessagePayload = k;
    g.parseEmsgBoxesFromMP4Segment = a;
    g.makeUpdatedAllEmsgBoxes = b;
    g.makeUpdatedActiveEmsgBoxes = e
}), 98);
__d("VideoPlayerOzPlayerModuleLoaderDeferredForDisplay", ["requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferredForDisplay")("oz-player").__setRef("VideoPlayerOzPlayerModuleLoaderDeferredForDisplay");

    function a() {
        return {
            getModuleIfRequireable: function() {
                return h.getModuleIfRequireable() || null
            },
            load: function() {
                return h.load()
            }
        }
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerShakaPerformanceLoggerRelayImpl", ["CometRelay", "useVideoPlayerShakaPerformanceLoggerRelayImpl_init.graphql", "useVideoPlayerShakaPerformanceLoggerRelayImpl_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i;
    h !== void 0 ? h : h = b("useVideoPlayerShakaPerformanceLoggerRelayImpl_init.graphql");

    function a(a) {
        a = d("CometRelay").useFragment(i !== void 0 ? i : i = b("useVideoPlayerShakaPerformanceLoggerRelayImpl_video.graphql"), a);
        var c = a.video_player_shaka_performance_logger_init ? d("CometRelay").ModuleResource.read(a.video_player_shaka_performance_logger_init) : null;
        c != null && a.video_player_shaka_performance_logger_should_sample === !0 && c.forceShouldSample();
        return c
    }
    g["default"] = a
}), 98);
__d("useVideoPlayerShakaPerformanceLoggerRelay", ["useVideoPlayerShakaPerformanceLoggerRelayImpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("useVideoPlayerShakaPerformanceLoggerRelayImpl")
}), 98);
__d("useVideoPlayerShakaConfig", ["CometRelay", "VideoPlayerConnectionQuality", "VideoPlayerOzWWWGlobalConfig", "VideoPlayerShakaConfig", "oz-player/networks/OzBandwidthEstimator", "react", "useSelectedLatencySetting", "useVideoPlayerShakaConfig_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    e = d("react");
    var i = e.useEffect,
        j = e.useState;

    function a(a, e) {
        e = e.adClientToken;
        var f = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoPlayerShakaConfig_video.graphql"), a),
            g = e != null,
            k = f.is_spherical === !0,
            l = f.is_gaming_video === !0;
        e = c("useSelectedLatencySetting")((a = f.id) != null ? a : "null", f.selected_latency_setting);
        var m = e[0];
        a = j(function() {
            var a;
            return new(c("VideoPlayerShakaConfig"))({
                connection_quality: d("VideoPlayerConnectionQuality").evaluate(function() {
                    return c("oz-player/networks/OzBandwidthEstimator").getBandwidth(c("VideoPlayerOzWWWGlobalConfig"))
                }),
                content_category: l ? "gaming" : "general",
                fbls_tier: ((a = f.fbls_tier) == null ? void 0 : a.startsWith("user")) ? "user" : "general",
                is_ad: g,
                is_latency_sensitive_broadcast: f.is_latency_sensitive_broadcast === !0,
                is_live: f.is_live_streaming === !0,
                is_spherical: k,
                latency_level: f.is_latency_menu_enabled === !0 ? m : "normal",
                player_format: "inline",
                servable_via_fmbs: !1,
                streaming_implementation: "default"
            })
        });
        var n = a[0];
        i(function() {
            n.setContext("is_ad", g)
        }, [n, g]);
        i(function() {
            n.setContext("is_spherical", k)
        }, [n, k]);
        return n
    }
    g["default"] = a
}), 98);
__d("FocusTableUtils", ["FocusManager", "filterNulls", "focusKeyboardEventPropagation", "focusScopeQueries", "setElementCanTab"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return a.length === 1
    }

    function h(a) {
        return a instanceof HTMLElement || a instanceof SVGElement
    }

    function i(a, b) {
        var d, e = b instanceof HTMLElement && b.id !== "" ? b.id : null,
            f = new Set(b instanceof HTMLElement ? c("filterNulls")([].concat(((d = b.getAttribute("aria-labelledby")) != null ? d : "").split(" "), ((d = b.getAttribute("aria-describedby")) != null ? d : "").split(" "), ((d = b.getAttribute("aria-owns")) != null ? d : "").split(" "), [b.getAttribute("aria-errormessage")])).filter(function(a) {
                return a !== ""
            }) : []);
        d = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
            acceptNode: function(a) {
                if (a === b) return NodeFilter.FILTER_REJECT;
                if (a.nodeType === Node.TEXT_NODE && a.textContent.trim() === "") return NodeFilter.FILTER_REJECT;
                if (h(a) && f.has(a.id)) return NodeFilter.FILTER_REJECT;
                if (h(a) && a.getAttribute("aria-hidden") === "true") return NodeFilter.FILTER_REJECT;
                if (a instanceof HTMLLabelElement && (a.htmlFor === e || a.contains(b))) return NodeFilter.FILTER_REJECT;
                if (a.hasChildNodes()) return NodeFilter.FILTER_SKIP;
                return h(a) && a.getAttribute("aria-label") == null && a.getAttribute("aria-labelledby") == null && a.getAttribute("aria-describedby") == null && a.getAttribute("alt") == null && a.getAttribute("title") == null ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
            }
        });
        var g = d.currentNode;
        while (g === a) g = d.nextNode();
        return g != null
    }
    var j = new Set(["button", "checkbox", "radio", "reset", "submit"]),
        k = new Set(["checkbox", "link", "switch", "radio", "button"]),
        l = new Set(["a", "button"]);

    function m(a) {
        var b = a.getAttribute("role"),
            c = a.tagName.toLowerCase(),
            d = a instanceof HTMLInputElement ? a.type : null;
        if (a instanceof HTMLInputElement && j.has(d)) return !0;
        return k.has(b) || l.has(c) ? !0 : !1
    }

    function n(a) {
        var b = [];
        a = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT, {
            acceptNode: function(a) {
                return a instanceof HTMLElement && m(a) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
            }
        });
        var c = a.nextNode();
        while (c) b.push(c), c = a.nextNode();
        return b
    }

    function o(a, b) {
        if (!b) return null;
        b = a.DO_NOT_USE_queryFirstNode(d("focusScopeQueries").tableCellScopeQuery);
        if (b == null) return null;
        a = n(b);
        a = (a = a) != null ? a : [];
        var c = a[0];
        a = a.slice(1);
        if (c != null && a.length === 0 && !i(b, c)) return c
    }

    function p(a, b, c) {
        if (b) {
            var e = b.scopeRef.current;
            if (e !== null) {
                b = o(e, (b = b.allowWithinCellNavigation) != null ? b : !1);
                b = (b = b) != null ? b : e.DO_NOT_USE_queryFirstNode(a);
                b !== null && (document.activeElement != null && d("setElementCanTab").setElementCanTab(document.activeElement, !1), d("setElementCanTab").setElementCanTab(b, !0), d("FocusManager").focusElement(b), c != null && (c.preventDefault(), d("focusKeyboardEventPropagation").stopFocusKeyboardEventPropagation(c)))
            }
        }
    }

    function b(a, b, c) {
        if (b != null) {
            b = b.DO_NOT_USE_queryFirstNode(a);
            b !== null && (d("setElementCanTab").setElementCanTab(b, !0), d("FocusManager").focusElement(b), c.preventDefault(), d("focusKeyboardEventPropagation").stopFocusKeyboardEventPropagation(c))
        }
    }

    function q(a, b, c, d, e) {
        d = d[c];
        c = s(d, e);
        var f = 0,
            g, h, i;
        do {
            g = b - f;
            if (g >= 0) {
                i = r(d, g, e, a);
                if (i) return i
            }
            h = b + f;
            if (h <= c) {
                i = r(d, h, e, a);
                if (i) return i
            }
            f++
        } while (g >= 0 && h <= c);
        return null
    }

    function e(a, b, c, d, e, f, g, h) {
        var i = b.onNavigate;
        if (i) {
            var j = !1;
            e = v(e, d, h);
            var k = e[1];
            e = x(b, d, g);
            var l = e[0],
                m = e[1];
            if (l === null) return !1;
            b = {
                currentCellIndex: k,
                currentRowIndex: m,
                event: c,
                focusCell: function(a, b) {
                    p(b || f, a, c)
                },
                getCell: function(a, b) {
                    a = l[a];
                    return a != null ? r(a, b, h) : null
                },
                getCellByTag: function(a) {
                    var b = q(a, k, m, l, h);
                    if (b) return b;
                    var c = l.length,
                        d = m + 1;
                    while (!0) {
                        if (d === m) return null;
                        if (d > c - 1) {
                            d = 0;
                            continue
                        }
                        b = q(a, k, d, l, h);
                        if (b) return b;
                        d++
                    }
                    return null
                },
                preventDefault: function() {
                    j = !0
                },
                type: a
            };
            i(b);
            if (j) return !0
        }
        return !1
    }

    function r(a, b, c, d) {
        a = a.getChildContextValues(c).filter(function(a) {
            return a != null && (d === void 0 || a.tag === d)
        });
        c = 0;
        for (var e = 0; e < a.length; e++) {
            var f = a[e];
            if (f) {
                c += f && f.colSpan || 1;
                if (c > b) return f
            }
        }
        return null
    }

    function f(a, b, c, d, e) {
        c = r(b, c, d);
        if (c !== null) {
            p(a, c, e);
            return
        }
        c = b.getChildContextValues(d).filter(Boolean);
        c.length > 0 && p(a, c[c.length - 1], e)
    }

    function s(a, b) {
        b = (a = a.getChildContextValues(b).filter(Boolean)) != null ? a : [];
        a = 0;
        for (var c = 0; c < b.length; c++) {
            var d = b[c];
            d = d && ((d = d.colSpan) != null ? d : 1);
            a += d
        }
        return a
    }

    function t(a, b) {
        var c = 0;
        for (var d = 0; d < a.length; d++) {
            var e = a[d];
            if (e === null) continue;
            if (e.scopeRef.current === b) return [d, d + c];
            e = e.colSpan;
            typeof e === "number" && (c += e - 1)
        }
        return [-1, -1]
    }

    function u(a, b) {
        return a.getChildContextValues(b).filter(Boolean)
    }

    function v(a, b, c) {
        b = u(b, c);
        if (b.length > 0) {
            c = t(b, a);
            a = c[0];
            c = c[1];
            return [b, a, c]
        }
        return [null, -1, -1]
    }

    function w(a, b, c) {
        if (a) {
            a = a.scopeRef.current;
            if (a !== null) {
                a = a.getChildContextValues(b);
                b = [];
                for (var d = 0; d < a.length; d++) {
                    var e = a[d];
                    if (e) {
                        var f;
                        f = (f = e.scopeRef) == null ? void 0 : f.current;
                        e = (e = c == null ? void 0 : c(e)) != null ? e : !0;
                        f && e && b.push(f)
                    }
                }
                return b
            }
        }
        return null
    }

    function x(a, b, c, d) {
        a = w(a, c, d);
        if (b && a && a.length > 0) {
            c = a.indexOf(b);
            return [a, c]
        }
        return [null, -1]
    }

    function y(a) {
        var b = a.altKey,
            c = a.ctrlKey,
            d = a.metaKey;
        a = a.shiftKey;
        return b === !0 || c === !0 || d === !0 || a === !0
    }
    g.isPrintableCharacter = a;
    g.hasUnassociatedLeafNodes = i;
    g.isArrowKeyLessOperationElement = m;
    g.getCellSingleInteractiveContentNode = o;
    g.focusCell = p;
    g.focusRow = b;
    g.checkRowForMatch = q;
    g.handleOnNavigateBehavior = e;
    g.getCellByColumnIndex = r;
    g.focusCellByColumnIndex = f;
    g.getLength = s;
    g.getCellIndexes = t;
    g.getRowCells = u;
    g.getRowCellsWithIndexes = v;
    g.getRows = w;
    g.getRowsWithIndex = x;
    g.hasModifierKey = y
}), 98);
__d("FocusTable.react", ["FocusManager", "FocusTableUtils", "Locale", "ReactFocusEvent.react", "ReactKeyboardEvent.react", "focusKeyboardEventPropagation", "react", "setElementCanTab"], (function(a, b, c, d, e, f, g) {
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = b.useRef,
        l = 5;

    function a(a) {
        var b = h.unstable_Scope,
            c = h.createContext(null),
            e = h.createContext(null),
            g = h.createContext(null);

        function n(e) {
            var f = e.children,
                g = e.wrapX,
                i = e.wrapY,
                m = e.wrapXToNextLine,
                n = e.tabScopeQuery,
                o = e.allowModifiers,
                q = e.pageJumpSize,
                r = q === void 0 ? l : q,
                s = e.onNavigate,
                t = e.disabled,
                u = e.withinCellTabScopeQuery,
                v = k(null);
            q = j(function() {
                return {
                    scopeRef: v,
                    wrapXToNextLine: m,
                    wrapX: g,
                    wrapY: i,
                    tabScopeQuery: n,
                    allowModifiers: o,
                    pageJumpSize: r,
                    onNavigate: s,
                    disabled: t,
                    withinCellTabScopeQuery: u
                }
            }, [m, g, i, n, o, r, s, t, u]);
            var w = k(!1);
            e = d("ReactFocusEvent.react").useFocusWithin(v, j(function() {
                return {
                    onFocusWithin: function(b) {
                        w.current || (w.current = !0, v.current && a && (p(v.current, a, !1), d("setElementCanTab").setElementCanTab(b.target, !0)))
                    }
                }
            }, [w]));
            return h.jsx(c.Provider, {
                value: q,
                children: h.jsx(b, {
                    ref: e,
                    children: f
                })
            })
        }
        n.displayName = n.name + " [from " + f.id + "]";

        function o(a) {
            a = a.children;
            var c = k(null),
                d = j(function() {
                    return {
                        scopeRef: c
                    }
                }, []);
            return h.jsx(e.Provider, {
                value: d,
                children: h.jsx(b, {
                    ref: c,
                    children: a
                })
            })
        }
        o.displayName = o.name + " [from " + f.id + "]";

        function p(a, b, c) {
            a = a.DO_NOT_USE_queryAllNodes(b);
            if (a != null)
                for (var b = 0; b < a.length; b++) {
                    var e = a[b];
                    d("setElementCanTab").setElementCanTab(e, c)
                }
        }

        function q(f) {
            var l = f.children,
                n = f.colSpan,
                o = f.tag,
                q = i(c),
                r = (f = i(e)) == null ? void 0 : f.scopeRef,
                s = k(null),
                t = k(!1),
                u = (q == null ? void 0 : q.withinCellTabScopeQuery) != null;
            d("ReactKeyboardEvent.react").useKeyboard(s, j(function() {
                return {
                    onKeyDown: function(b) {
                        if (q && q.disabled === !0) return;
                        if (d("focusKeyboardEventPropagation").hasFocusKeyboardEventPropagationStopped(b)) return;
                        var c = s.current;
                        if (c === null || q === null) return;
                        if (r == null) return;
                        var f = r.current;
                        if (f === null) return;
                        var h = b.key,
                            i = u && d("FocusTableUtils").getCellSingleInteractiveContentNode(c, u) == null,
                            j = t.current;
                        if (h === "Tab" && q) {
                            var k = q.tabScopeQuery,
                                l = q.scopeRef.current;
                            if (k && l) {
                                if (d("FocusTableUtils").handleOnNavigateBehavior("TAB", q, b, f, c, k, e, g)) return;
                                var n = q.withinCellTabScopeQuery;
                                j && n != null ? b.shiftKey ? d("FocusManager").focusPreviousContained(n, c, b, !0) : d("FocusManager").focusNextContained(n, c, b, !0) : (p(l, k, !1), document.activeElement != null && d("setElementCanTab").setElementCanTab(document.activeElement, !0))
                            }
                            return
                        }
                        n = b.ctrlKey || b.metaKey;
                        l = h;
                        d("Locale").isRTL() && (h === "ArrowRight" ? l = "ArrowLeft" : h === "ArrowLeft" && (l = "ArrowRight"));
                        switch (l) {
                            case "Home":
                                if (d("FocusTableUtils").handleOnNavigateBehavior("HOME", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                k = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                l = k[0];
                                k = k[1];
                                var o = d("FocusTableUtils").getRowsWithIndex(q, f, e),
                                    v = o[0];
                                o = o[1];
                                if (l !== null && v !== null)
                                    if (n) {
                                        if (o !== 0 || k !== 0) {
                                            l = v[0];
                                            d("FocusTableUtils").focusCellByColumnIndex(a, l, 0, g, b)
                                        }
                                    } else if (k !== 0) {
                                    l = v[o];
                                    d("FocusTableUtils").focusCellByColumnIndex(a, l, 0, g, b)
                                }
                                return;
                            case "End":
                                if (d("FocusTableUtils").handleOnNavigateBehavior("END", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                k = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                v = k[0];
                                o = k[1];
                                l = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                k = l[0];
                                l = l[1];
                                if (v !== null && k !== null)
                                    if (n) {
                                        if (l !== k.length - 1 || o !== v.length - 1) {
                                            l = k[k.length - 1];
                                            k = l.getChildContextValues(g).filter(Boolean);
                                            k.length > 0 && d("FocusTableUtils").focusCell(a, k[k.length - 1], b)
                                        }
                                    } else o !== v[v.length - 1] && d("FocusTableUtils").focusCell(a, v[v.length - 1], b);
                                return;
                            case "ArrowUp":
                                if (m(b, q)) return;
                                if (d("FocusTableUtils").handleOnNavigateBehavior("PREV_ROW", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                l = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                k = l[0];
                                o = l[2];
                                if (k !== null && q) {
                                    v = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                    l = v[0];
                                    k = v[1];
                                    if (l !== null)
                                        if (k === 0) {
                                            v = q.wrapY;
                                            if (v === !0 && !n) {
                                                v = l[l.length - 1];
                                                d("FocusTableUtils").focusCellByColumnIndex(a, v, o, g, b)
                                            }
                                        } else if (n) {
                                        v = l[0];
                                        d("FocusTableUtils").focusCellByColumnIndex(a, v, o, g, b)
                                    } else {
                                        v = l[k - 1];
                                        d("FocusTableUtils").focusCellByColumnIndex(a, v, o, g, b)
                                    }
                                }
                                return;
                            case "PageUp":
                                if (d("FocusTableUtils").handleOnNavigateBehavior("PAGE_UP", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                l = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                k = l[0];
                                v = l[2];
                                o = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                l = o[0];
                                o = o[1];
                                if (k !== null && l !== null && q && o !== 0) {
                                    k = q.pageJumpSize;
                                    l = l[Math.max(0, o - k)];
                                    d("FocusTableUtils").focusCellByColumnIndex(a, l, v, g, b)
                                }
                                return;
                            case "ArrowDown":
                                if (m(b, q)) return;
                                if (d("FocusTableUtils").handleOnNavigateBehavior("NEXT_ROW", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                o = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                k = o[0];
                                l = o[2];
                                v = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                o = v[0];
                                v = v[1];
                                if (k !== null && o !== null && q && v !== -1)
                                    if (v === o.length - 1) {
                                        k = q.wrapY;
                                        if (k === !0 && !n) {
                                            k = o[0];
                                            d("FocusTableUtils").focusCellByColumnIndex(a, k, l, g, b)
                                        }
                                    } else if (n) {
                                    k = o[o.length - 1];
                                    d("FocusTableUtils").focusCellByColumnIndex(a, k, l, g, b)
                                } else {
                                    n = o[v + 1];
                                    d("FocusTableUtils").focusCellByColumnIndex(a, n, l, g, b)
                                }
                                return;
                            case "PageDown":
                                if (d("FocusTableUtils").handleOnNavigateBehavior("PAGE_DOWN", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                k = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                o = k[0];
                                v = k[2];
                                n = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                l = n[0];
                                k = n[1];
                                if (o !== null && l !== null && q && k !== l.length - 1) {
                                    n = q.pageJumpSize;
                                    o = l[Math.min(l.length - 1, k + n)];
                                    d("FocusTableUtils").focusCellByColumnIndex(a, o, v, g, b)
                                }
                                return;
                            case "ArrowLeft":
                                if (m(b, q)) return;
                                if (d("FocusTableUtils").handleOnNavigateBehavior("PREV_CELL", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                l = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                k = l[0];
                                n = l[1];
                                o = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                v = o[0];
                                l = o[1];
                                if (k !== null && v !== null && q)
                                    if (n > 0) d("FocusTableUtils").focusCell(a, k[n - 1], b);
                                    else if (n === 0) {
                                    o = q.wrapX;
                                    n = q.wrapXToNextLine;
                                    o === !0 ? d("FocusTableUtils").focusCell(a, k[k.length - 1], b) : n === !0 && v[l - 1] && d("FocusTableUtils").focusCellByColumnIndex(a, v[l - 1], d("FocusTableUtils").getLength(v[l - 1], g), g, b)
                                }
                                return;
                            case "ArrowRight":
                                if (m(b, q)) return;
                                if (d("FocusTableUtils").handleOnNavigateBehavior("NEXT_CELL", q, b, f, c, a, e, g)) return;
                                if (j) return;
                                o = d("FocusTableUtils").getRowCellsWithIndexes(c, f, g);
                                k = o[0];
                                n = o[1];
                                v = d("FocusTableUtils").getRowsWithIndex(q, f, e);
                                l = v[0];
                                o = v[1];
                                if (k !== null && l !== null && q && n !== -1)
                                    if (n === k.length - 1) {
                                        v = q.wrapX;
                                        var w = q.wrapXToNextLine;
                                        v === !0 ? d("FocusTableUtils").focusCell(a, k[0], b) : w === !0 && l[o + 1] && d("FocusTableUtils").focusCellByColumnIndex(a, l[o + 1], 0, g, b)
                                    } else d("FocusTableUtils").focusCell(a, k[n + 1], b);
                                return;
                            case "Enter":
                                if (!i || j) return;
                                if (d("FocusTableUtils").handleOnNavigateBehavior("ENTER", q, b, f, c, a, e, g)) return;
                                v = q == null ? void 0 : q.withinCellTabScopeQuery;
                                if (v) {
                                    w = c.DO_NOT_USE_queryFirstNode(v);
                                    w != null && (t.current = !0, p(c, v, !0), d("FocusManager").focusElement(w))
                                }
                                return;
                            case "Escape":
                                if (!i || !j) return;
                                if (d("FocusTableUtils").handleOnNavigateBehavior("ESC", q, b, f, c, a, e, g)) return;
                                l = q == null ? void 0 : q.tabScopeQuery;
                                if (l) {
                                    t.current = !1;
                                    o = c.DO_NOT_USE_queryAllNodes(l);
                                    if (o !== null)
                                        for (var k = 0; k < o.length; k++) {
                                            n = o[k];
                                            d("setElementCanTab").setElementCanTab(n, !1)
                                        }
                                    d("FocusTableUtils").focusCell(l, {
                                        scopeRef: s
                                    }, b)
                                }
                                return;
                            default:
                                d("FocusTableUtils").isPrintableCharacter(h) && d("FocusTableUtils").handleOnNavigateBehavior("PRINT_CHAR", q, b, f, c, a, e, g)
                        }
                    }
                }
            }, [r, q, u]));
            var v = j(function() {
                    return {
                        scopeRef: s,
                        colSpan: n,
                        tag: o,
                        allowWithinCellNavigation: u
                    }
                }, [n, u, o]),
                w = q == null ? void 0 : q.tabScopeQuery;
            f = d("ReactFocusEvent.react").useFocusWithin(s, j(function() {
                return {
                    onFocusWithin: function(b) {
                        if (a != null) {
                            var c;
                            c = (c = s.current) == null ? void 0 : c.DO_NOT_USE_queryFirstNode(a);
                            var e = b.target === c;
                            if (e && (c && !d("setElementCanTab").canElementTab(c))) {
                                e = q == null ? void 0 : q.scopeRef.current;
                                e && p(e, a, !1);
                                d("setElementCanTab").setElementCanTab(c, !0)
                            }
                        }
                        if (w != null) {
                            c = (e = s.current) == null ? void 0 : e.DO_NOT_USE_queryFirstNode(w);
                            e = b.target === c;
                            c = v.allowWithinCellNavigation === !0;
                            e && c && d("FocusTableUtils").focusCell(w, v);
                            !e && c && b.target instanceof HTMLElement && !d("FocusTableUtils").isArrowKeyLessOperationElement(b.target) && (t.current = !0)
                        }
                    },
                    onBlurWithin: function() {
                        t.current = !1
                    }
                }
            }, [w, v, q == null ? void 0 : q.scopeRef]));
            return h.jsx(g.Provider, {
                value: v,
                children: h.jsx(b, {
                    ref: f,
                    children: l
                })
            })
        }
        q.displayName = q.name + " [from " + f.id + "]";
        return [n, o, q]
    }

    function m(a, b) {
        if (d("FocusTableUtils").hasModifierKey(a) && b) {
            a = b.allowModifiers;
            if (a !== !0) return !0
        }
    }
    g.createFocusTable = a
}), 98);
__d("XRefererFrameController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/common/referer_frame.php", {})
}), null);
__d("isDollyFBURI", ["isFacebookURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("isFacebookURI")(a) && a.getSubdomain() === "store"
    }
    g["default"] = a
}), 98);
__d("isMetaDotComURI", [], (function(a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)(figowa|meta)\\.com$", "i"),
        h = ["https"];

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        return !a.getDomain() && !a.getProtocol() ? !0 : h.indexOf(a.getProtocol()) !== -1 && g.test(a.getDomain())
    }
    f["default"] = a
}), 66);
__d("isWhatsAppBlogURI", [], (function(a, b, c, d, e, f) {
    var g = new RegExp("^blog\\.whatsapp\\.com$", "i"),
        h = ["https"];

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        return !a.getDomain() && !a.getProtocol() ? !1 : h.indexOf(a.getProtocol()) !== -1 && g.test(a.getDomain())
    }
    f["default"] = a
}), 66);
__d("ControlledReferer", ["Bootloader", "CookieConsent", "XRefererFrameController", "getRequestConstUri", "isDollyFBURI", "isInstagramURI", "isInternalFBURI", "isMessengerDotComURI", "isMetaDotComURI", "isOculusDotComURI", "isWhatsAppBlogURI", "isWorkplaceDotComURI", "justknobx", "lowerFacebookDomain"], (function(a, b, c, d, e, f, g) {
    var h = c("justknobx")._("452");

    function i(a, b, d) {
        if (!c("CookieConsent").isThirdPartyIframeAllowed(a)) {
            c("Bootloader").loadModules(["ODS"], function(a) {
                a.bumpEntityKey(2966, "defer_cookies", "block_controlled_referer_iframe")
            }, "ControlledReferer");
            return
        }
        var e = !1;

        function f() {
            if (e) return;
            var c = a.contentWindow.location.pathname;
            if (c !== "/intern/common/referer_frame.php" && c !== "/common/referer_frame.php" && c !== "/common/referer_frame.php/") return;
            e = !0;
            a.contentWindow.document.body.style.margin = 0;
            b()
        }
        var g;
        c("isMessengerDotComURI")(c("getRequestConstUri")()) || c("justknobx")._("186") && c("isInstagramURI")(c("getRequestConstUri")()) || c("isWhatsAppBlogURI")(c("getRequestConstUri")()) || c("isMetaDotComURI")(c("getRequestConstUri")()) || c("isDollyFBURI")(c("getRequestConstUri")()) ? g = c("XRefererFrameController").getURIBuilder().getURI().toString() : c("isOculusDotComURI")(c("getRequestConstUri")()) ? g = "/common/referer_frame.php" : h && c("isInternalFBURI")(c("getRequestConstUri")()) || !h && !c("lowerFacebookDomain").isValidDocumentDomain() ? g = "/intern/common/referer_frame.php" : g = c("XRefererFrameController").getURIBuilder().getURI().toString();
        d == null && c("isWorkplaceDotComURI")(c("getRequestConstUri")()) && (d = "workplace");
        d && (g += "?fb_source=" + d);
        a.onload = f;
        a.src = g
    }

    function a(a, b, c) {
        i(a, function() {
            a.contentWindow.document.body.innerHTML = b
        }, c)
    }
    g.shouldUseFacebookReferer = i;
    g.useFacebookRefererHtml = a
}), 98);
__d("StaticContainer.react", ["React"], (function(a, b, c, d, e, f, g) {
    var h = d("React");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.shouldComponentUpdate = function(a) {
            return !!a.shouldUpdate
        };
        c.render = function() {
            var a = this.props.children;
            return a === null || a === !1 ? null : h.Children.only(a)
        };
        return b
    }(h.Component);
    g["default"] = a
}), 98);
__d("ControlledRefererIFrame.react", ["ControlledReferer", "ControlledRefererIFrameConfig", "SecurePostMessage", "StaticContainer.react", "URI", "createTrustedHTMLWithoutValidation_DO_NOT_USE", "isTruthy", "react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h, i = g || b("react");
    a = function(a) {
        babelHelpers.inheritsLoose(c, a);

        function c() {
            return a.apply(this, arguments) || this
        }
        var d = c.prototype;
        d.mountFrameRef = function(a) {
            this.frame = a
        };
        d.updateFrame = function() {
            var a = this,
                c = this.frame;
            if (!c) return;
            this.props.onBeforeFrameRender && this.props.onBeforeFrameRender(this.props);
            b("ControlledReferer").shouldUseFacebookReferer(c, function() {
                var d = c.contentWindow.document;
                d.body.innerHTML = b("createTrustedHTMLWithoutValidation_DO_NOT_USE")('\n        <form method="GET" id="theform"></form>\n        ' + b("ControlledRefererIFrameConfig").additional_markup + "\n      ");
                var e = new(h || (h = b("URI")))(a.props.src).qualify(),
                    f = d.getElementById("theform");
                f.action = e.toString();
                e = e.getQueryData();
                for (var g in e)
                    if (Object.prototype.hasOwnProperty.call(e, g)) {
                        var i = d.createElement("input");
                        i.name = g;
                        i.setAttribute("value", e[g]);
                        i.autocomplete = "off";
                        i.type = "hidden";
                        f.appendChild(i)
                    }
                i = '\n        <iframe\n          frameborder="0"\n          width="1"\n          height="1"\n          onload="document.getElementById(\'theform\').submit()"\n        />\n      ';
                if (b("isTruthy")(a.props.useTrustedHtml)) {
                    f = b("createTrustedHTMLWithoutValidation_DO_NOT_USE")(d.body.innerHTML + i);
                    a.props.onFrameRender && a.props.onFrameRender(a.props);
                    d.body.innerHTML = f
                } else d.body.innerHTML += i;
                a.props.onFrameRender && a.props.onFrameRender(a.props)
            })
        };
        d.componentDidMount = function() {
            this.updateFrame()
        };
        d.componentDidUpdate = function(a) {
            a.src !== this.props.src && this.updateFrame()
        };
        d.UNSAFE_componentWillReceiveProps = function(a) {
            var b = this.frame;
            b && (a.width !== this.props.width || a.height !== this.props.height) && (a.width != null && (b.width = "" + a.width), a.height != null && (b.height = "" + a.height))
        };
        d.render = function() {
            var a = this,
                c = this.props;
            c.src;
            c.onFrameRender;
            c.onBeforeFrameRender;
            c = babelHelpers.objectWithoutPropertiesLoose(c, ["src", "onFrameRender", "onBeforeFrameRender"]);
            return i.jsx(b("StaticContainer.react"), {
                children: i.jsx("iframe", babelHelpers["extends"]({}, c, {
                    ref: function(b) {
                        return a.mountFrameRef(b)
                    }
                }))
            })
        };
        d.postMessage = function(a, c) {
            this.frame && b("SecurePostMessage").sendMessageToSpecificOrigin(this.frame.contentWindow, a, c)
        };
        return c
    }(i.PureComponent);
    e.exports = a
}), null);