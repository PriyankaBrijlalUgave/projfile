if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ReStoreVaulting", ["cr:2075", "cr:2151", "cr:2203"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return b("cr:2075") != null ? b("cr:2075").vault(a) : a
    }

    function c(a) {
        return b("cr:2075") != null ? b("cr:2075").unvault(a) : a
    }

    function d(a, c) {
        return b("cr:2151") != null && b("cr:2203") != null ? b("cr:2151").unvaultDbRow(a, c, b("cr:2203").PERSISTED_DB_VAULT_DEFINITIONS) : a
    }

    function e(a, c) {
        return b("cr:2151") != null && b("cr:2203") != null ? b("cr:2151").vaultDbRow(a, c, b("cr:2203").PERSISTED_DB_VAULT_DEFINITIONS) : a
    }
    g.maybeVault = a;
    g.maybeUnvault = c;
    g.maybeUnvaultDbRow = d;
    g.maybeVaultDbRow = e
}), 98);
__d("MAWCurrentUser", ["CurrentUser", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    var h = Number(c("CurrentUser").getAppID());

    function a() {
        if (h === 772021112871879 || h === 2220391788200892 || h === 256281040558) return c("CurrentUser").getID();
        else if (h === 1217981644879628 || h === 936619743392459) return c("CurrentUser").getEIMU();
        else {
            c("recoverableViolation")("Try to getID from unsupported surface: " + h, "messenger_e2ee_web");
            return c("CurrentUser").getID()
        }
    }
    g.getID = a
}), 98);
__d("LSStaticDependencies", ["LSDeleteThenInsertContact", "LSDeleteThenInsertThread", "LSExecuteFinallyBlockForSyncTransaction", "LSExecuteFirstBlockForSyncTransaction", "LSRemoveTask", "LSSetRegionHint", "LSTaskExists", "LSUpdateLastSyncCompletedTimestampMsToNow", "LSUpsertSequenceId", "LSVerifyContactRowExists"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        deleteThenInsertContact: c("LSDeleteThenInsertContact"),
        deleteThenInsertThread: c("LSDeleteThenInsertThread"),
        executeFinallyBlockForSyncTransaction: c("LSExecuteFinallyBlockForSyncTransaction"),
        executeFirstBlockForSyncTransaction: c("LSExecuteFirstBlockForSyncTransaction"),
        removeTask: c("LSRemoveTask"),
        setRegionHint: c("LSSetRegionHint"),
        taskExists: c("LSTaskExists"),
        updateLastSyncCompletedTimestampMsToNow: c("LSUpdateLastSyncCompletedTimestampMsToNow"),
        upsertSequenceId: c("LSUpsertSequenceId"),
        verifyContactRowExists: c("LSVerifyContactRowExists")
    };
    g.staticCachedModules = a
}), 98);
__d("formatDurationSeconds", ["fbt", "padNumber"], (function(a, b, c, d, e, f, g, h) {
    function a(a) {
        var b = Math.floor(a / 3600),
            d = Math.floor(a / 60 % 60);
        a = Math.floor(a % 60);
        if (b) return h._("{hours}:{minutes}:{seconds}", [h._param("hours", b), h._param("minutes", c("padNumber")(d, 2)), h._param("seconds", c("padNumber")(a, 2))]);
        else return h._("{minutes}:{seconds}", [h._param("minutes", d), h._param("seconds", c("padNumber")(a, 2))])
    }
    g["default"] = a
}), 98);
__d("CometRelayEF", ["Bootloader", "BootloaderEvents", "ClientConsistencyEventEmitter", "CometSSREntrypoint", "cometAsyncFetch", "gkx", "performanceAbsoluteNow", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();

    function i(a, b) {
        if (!c("gkx")("1334580")) return;
        a = d("CometSSREntrypoint").processRootEntryPoint(a, b);
        var e = [];
        a.forEach(function(a) {
            a = a.name;
            h.has(a) || (e.push(a), d("BootloaderEvents").notifyHasteResponseEFStart("relay_3d", a))
        });
        if (e.length === 0) return;
        var f = c("performanceAbsoluteNow")(),
            g = c("cometAsyncFetch")("/ajax/relay-ef/", {
                data: {
                    queries: e
                },
                method: "POST"
            }).then(function(a) {
                return {
                    fetchPredictionsEnd: c("performanceAbsoluteNow")(),
                    fetchPredictionsStart: f,
                    payload: a
                }
            });
        e.forEach(function(a) {
            return h.set(a, g)
        })
    }

    function a(a, b) {
        if (!c("gkx")("1334580")) return;
        var e = c("performanceAbsoluteNow")();
        i(a, b);
        a = d("CometSSREntrypoint").processRootEntryPoint(a, b);
        a.forEach(function(a) {
            var b = a.name,
                f = h.get(b);
            f && f !== !0 && c("promiseDone")(f, function(a) {
                var f = a.fetchPredictionsEnd,
                    g = a.fetchPredictionsStart;
                a = a.payload;
                a != null && typeof a === "object" && (c("Bootloader").loadPredictedResourceMap(a.predictions[b], {
                    onLog: function(a) {
                        return d("BootloaderEvents").notifyHasteResponseEF("relay_3d", b, {
                            fetchPredictionsEnd: f,
                            fetchPredictionsStart: g,
                            fetchRsrcsStart: e,
                            tierOne: a
                        })
                    }
                }, a.consistency.rev), c("ClientConsistencyEventEmitter").emit("newEntry", a.consistency))
            });
            h.set(a.name, !0)
        })
    }
    g.fetchPredictions = i;
    g.fetchPredictedResources = a
}), 98);