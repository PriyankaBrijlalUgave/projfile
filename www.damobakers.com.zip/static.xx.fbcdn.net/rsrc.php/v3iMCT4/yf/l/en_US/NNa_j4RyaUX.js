if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("AdsTimezoneConfig", [], (function(a, b, c, d, e, f) {
    e.exports = {
        byCountryCode: {
            US: [3, 4, 1, 2, 5, 6, 7],
            AE: [8],
            AR: [9, 10, 11],
            AT: [12],
            AU: [13, 14, 15, 144],
            BA: [16],
            BD: [17],
            BE: [18],
            BG: [19],
            BH: [20],
            BO: [21],
            BR: [22, 23, 24, 25],
            BS: [26],
            CA: [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38],
            CH: [39],
            CL: [40, 41],
            CN: [42],
            CO: [43],
            CR: [44],
            CY: [45],
            CZ: [46],
            DE: [47],
            DK: [48],
            DO: [49],
            EC: [50, 51],
            EE: [52],
            EG: [53],
            ES: [54, 55],
            FI: [56],
            FR: [57],
            GB: [58],
            GH: [59],
            GR: [60],
            GT: [61],
            HK: [62],
            HN: [63],
            HR: [64],
            HU: [65],
            ID: [66, 67, 68],
            IE: [69],
            IL: [70],
            IN: [71],
            IQ: [72],
            IS: [73],
            IT: [74],
            JM: [75],
            JO: [76],
            JP: [77],
            KE: [78],
            KR: [79],
            KW: [80],
            LB: [81],
            LK: [82],
            LT: [83],
            LU: [84],
            LV: [85],
            MA: [86],
            MK: [87],
            MT: [88],
            MU: [89],
            MV: [90],
            MX: [91, 92, 93, 94],
            MY: [95],
            NG: [96],
            NI: [97],
            NL: [98],
            NO: [99],
            NZ: [100],
            OM: [101],
            PA: [102],
            PE: [103],
            PH: [104],
            PK: [105],
            PL: [106],
            PR: [107],
            PS: [108],
            PT: [109, 110],
            PY: [111],
            QA: [112],
            RO: [113],
            RS: [114],
            RU: [115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125],
            SA: [126],
            SE: [127],
            SG: [128],
            SI: [129],
            SK: [130],
            SV: [131],
            TH: [132],
            TN: [133],
            TR: [134],
            TT: [135],
            TW: [136],
            UA: [137],
            UY: [138],
            VE: [139],
            VN: [140],
            ZA: [141],
            NP: [145],
            AZ: [146],
            BF: [187],
            AM: [347],
            MD: [404],
            "": [474],
            DZ: [1],
            AL: [1],
            MO: [1],
            ME: [1],
            SN: [1],
            GE: [1],
            BN: [1],
            UG: [1],
            GP: [1],
            BB: [1],
            TZ: [1],
            LY: [1],
            MQ: [1],
            CM: [1],
            BW: [1],
            ET: [1],
            KZ: [1],
            NA: [1],
            MG: [1],
            NC: [1],
            FJ: [1],
            BY: [1],
            JE: [1],
            GU: [1],
            YE: [1],
            ZM: [1],
            IM: [1],
            HT: [1],
            KH: [1],
            AW: [1],
            PF: [1],
            AF: [1],
            BM: [1],
            GY: [1],
            MW: [1],
            AG: [1],
            RW: [1],
            GG: [1],
            GM: [1],
            FO: [1],
            LC: [1],
            KY: [1],
            BJ: [1],
            AD: [1],
            GD: [1],
            VI: [1],
            BZ: [1],
            VC: [1],
            MN: [1],
            MZ: [1],
            ML: [1],
            AO: [1],
            GF: [1],
            UZ: [1],
            DJ: [1],
            MC: [1],
            TG: [1],
            GL: [1],
            GA: [1],
            GI: [1],
            CD: [1],
            KG: [1],
            PG: [1],
            BT: [1],
            KN: [1],
            SZ: [1],
            LS: [1],
            LA: [1],
            LI: [1],
            MP: [1],
            SR: [1],
            SC: [1],
            VG: [1],
            TC: [1],
            DM: [1],
            MR: [1],
            AX: [1],
            SM: [1],
            SL: [1],
            NE: [1],
            CG: [1],
            AI: [1],
            YT: [1],
            CV: [1],
            GN: [1],
            TM: [1],
            BI: [1],
            TJ: [1],
            VU: [1],
            SB: [1],
            ER: [1],
            WS: [1],
            AS: [1],
            FK: [1],
            GQ: [1],
            TO: [1],
            KM: [1],
            PW: [1],
            FM: [1],
            CF: [1],
            SO: [1],
            MH: [1],
            VA: [1],
            TD: [1],
            KI: [1],
            ST: [1],
            TV: [1],
            NR: [1],
            RE: [1],
            LR: [1],
            ZW: [1],
            CI: [1],
            MM: [1],
            AN: [1],
            AQ: [1],
            BQ: [1],
            BV: [1],
            IO: [1],
            CX: [1],
            CC: [1],
            CK: [1],
            CW: [1],
            TF: [1],
            GW: [1],
            HM: [1],
            XK: [1],
            MS: [1],
            NU: [1],
            NF: [1],
            PN: [1],
            BL: [1],
            SH: [1],
            MF: [1],
            PM: [1],
            SX: [1],
            GS: [1],
            SS: [1],
            SJ: [1],
            TL: [1],
            TK: [1],
            UM: [1],
            WF: [1],
            EH: [1]
        },
        offsets: ["-07:00", "-07:00", "-06:00", "-10:00", "-08:00", "-07:00", "-05:00", "-04:00", "+04:00", "-03:00", "-03:00", "-03:00", "+02:00", "+08:00", "+10:30", "+11:00", "+02:00", "+06:00", "+02:00", "+03:00", "+03:00", "-04:00", "-02:00", "-04:00", "-03:00", "-03:00", "-04:00", "-07:00", "-07:00", "-07:00", "-06:00", "-05:00", "-06:00", "-05:00", "-04:00", "-04:00", "-04:00", "-03:00", "-02:30", "+02:00", "-05:00", "-03:00", "+08:00", "-05:00", "-06:00", "+03:00", "+02:00", "+02:00", "+02:00", "-04:00", "-06:00", "-05:00", "+03:00", "+02:00", "+01:00", "+02:00", "+03:00", "+02:00", "+01:00", "+00:00", "+03:00", "-06:00", "+08:00", "-06:00", "+02:00", "+02:00", "+07:00", "+08:00", "+09:00", "+01:00", "+03:00", "+05:30", "+03:00", "+00:00", "+02:00", "-05:00", "+03:00", "+09:00", "+03:00", "+09:00", "+03:00", "+03:00", "+05:30", "+03:00", "+02:00", "+03:00", "+01:00", "+02:00", "+02:00", "+04:00", "+05:00", "-07:00", "-07:00", "-06:00", "-05:00", "+08:00", "+01:00", "-06:00", "+02:00", "+02:00", "+13:00", "+04:00", "-05:00", "-05:00", "+08:00", "+05:00", "+02:00", "-04:00", "+03:00", "+00:00", "+01:00", "-03:00", "+03:00", "+03:00", "+02:00", "+02:00", "+03:00", "+04:00", "+05:00", "+06:00", "+07:00", "+08:00", "+09:00", "+10:00", "+11:00", "+12:00", "+03:00", "+02:00", "+08:00", "+02:00", "+02:00", "-06:00", "+07:00", "+01:00", "+03:00", "-04:00", "+08:00", "+03:00", "-03:00", "-04:00", "+07:00", "+02:00", "-05:00", "-04:00", "+11:00", "+05:45", "+04:00", "+00:00", "+03:00", "+01:00", "+03:00", "+00:00", "+01:00", "+00:00", "+00:00", "+02:00", "+01:00", "+02:00", "+02:00", "+00:00", "+00:00", "+03:00", "+03:00", "+01:00", "+01:00", "+00:00", "+02:00", "+02:00", "+02:00", "+03:00", "+02:00", "+02:00", "+01:00", "+01:00", "+00:00", "+01:00", "+02:00", "+02:00", "+01:00", "+02:00", "+02:00", "+02:00", "+03:00", "+00:00", "+01:00", "+01:00", "+00:00", "+00:00", "+01:00", "+00:00", "+02:00", "+02:00", "-09:00", "-04:00", "-04:00", "-03:00", "-03:00", "-03:00", "-03:00", "-03:00", "-03:00", "-03:00", "-03:00", "-03:00", "-03:00", "-04:00", "-03:00", "-05:00", "-04:00", "-06:00", "-04:00", "-06:00", "-06:00", "-05:00", "-03:00", "-05:00", "-06:00", "-07:00", "-04:00", "-04:00", "+00:00", "-04:00", "-05:00", "-07:00", "-03:00", "-03:00", "-02:00", "-03:00", "-04:00", "-04:00", "-04:00", "-04:00", "-04:00", "-04:00", "-05:00", "-04:00", "-04:00", "-05:00", "-04:00", "-04:00", "-04:00", "-04:00", "-06:00", "-08:00", "-04:00", "-04:00", "-04:00", "-04:00", "-03:00", "-04:00", "-04:00", "-04:00", "-05:00", "-05:00", "-05:00", "-08:00", "-02:00", "-03:00", "-05:00", "-04:00", "-04:00", "-04:00", "-08:00", "-05:00", "-05:00", "-05:00", "-06:00", "-04:00", "-03:00", "-04:00", "-04:00", "-03:00", "-05:00", "-03:00", "-05:00", "-05:00", "-03:00", "+00:00", "-08:00", "-04:00", "-04:00", "-04:00", "-04:00", "-04:00", "-06:00", "-03:00", "-04:00", "-04:00", "-07:00", "-08:00", "-06:00", "+11:00", "+07:00", "+10:00", "+11:00", "+05:00", "+13:00", "-03:00", "-03:00", "+03:00", "+02:00", "+06:00", "+02:00", "+03:00", "+06:00", "+12:00", "+05:00", "+05:00", "+05:00", "+05:00", "+07:00", "+06:00", "+08:00", "+09:00", "+08:00", "+03:00", "+09:00", "+05:00", "+03:00", "+03:00", "+07:00", "+03:00", "+04:30", "+09:00", "+08:00", "+08:00", "+07:00", "+07:00", "+05:00", "+07:00", "+07:00", "+09:00", "+06:00", "+05:00", "+11:00", "+05:00", "+11:00", "+05:00", "+04:00", "+03:30", "+06:00", "+07:00", "+08:00", "+06:00", "+10:00", "+07:00", "+06:30", "+04:00", "-03:00", "-01:00", "+01:00", "+01:00", "-02:00", "+00:00", "-03:00", "+10:30", "+10:00", "+11:00", "+09:30", "+08:45", "+11:00", "+10:00", "+11:00", "+02:00", "-05:00", "+03:00", "-05:00", "-04:00", "+00:00", "+00:00", "-01:00", "-10:00", "-11:00", "-12:00", "-02:00", "-03:00", "-04:00", "-05:00", "-06:00", "-07:00", "-08:00", "-09:00", "+00:00", "+01:00", "+10:00", "+11:00", "+12:00", "+13:00", "+14:00", "+02:00", "+03:00", "+04:00", "+05:00", "+06:00", "+07:00", "+08:00", "+09:00", "+00:00", "+00:00", "+00:00", "+00:00", "+02:00", "+04:00", "+02:00", "+03:00", "+02:00", "+01:00", "+01:00", "+01:00", "+03:00", "+03:00", "+03:00", "+02:00", "+03:00", "+02:00", "+02:00", "+04:00", "+03:00", "+02:00", "+04:00", "+03:00", "+02:00", "+02:00", "+03:00", "+03:00", "+00:00", "-10:00", "+03:00", "+06:00", "+07:00", "+06:30", "+03:00", "+05:00", "+04:00", "+03:00", "+04:00", "+02:00", "-07:00", "-06:00", "-07:00", "+14:00", "+11:00", "+13:45", "+10:00", "+11:00", "+13:00", "+13:00", "+12:00", "+12:00", "-09:00", "+11:00", "+10:00", "+14:00", "+11:00", "+12:00", "+12:00", "-09:30", "-11:00", "+12:00", "-11:00", "+12:00", "+11:00", "-11:00", "+09:00", "-08:00", "+11:00", "+10:00", "-10:00", "+10:00", "-10:00", "+12:00", "+13:00", "+12:00", "+12:00", "+00:00", "+01:00", "+05:30", "+05:45", "-02:00", "-03:00"],
        names: ["", "America/Los_Angeles", "America/Denver", "Pacific/Honolulu", "America/Anchorage", "America/Phoenix", "America/Chicago", "America/New_York", "Asia/Dubai", "America/Argentina/San_Luis", "America/Argentina/Buenos_Aires", "America/Argentina/Salta", "Europe/Vienna", "Australia/Perth", "Australia/Broken_Hill", "Australia/Sydney", "Europe/Sarajevo", "Asia/Dhaka", "Europe/Brussels", "Europe/Sofia", "Asia/Bahrain", "America/La_Paz", "America/Noronha", "America/Campo_Grande", "America/Belem", "America/Sao_Paulo", "America/Nassau", "America/Dawson", "America/Vancouver", "America/Dawson_Creek", "America/Edmonton", "America/Rainy_River", "America/Regina", "America/Atikokan", "America/Iqaluit", "America/Toronto", "America/Blanc-Sablon", "America/Halifax", "America/St_Johns", "Europe/Zurich", "Pacific/Easter", "America/Santiago", "Asia/Shanghai", "America/Bogota", "America/Costa_Rica", "Asia/Nicosia", "Europe/Prague", "Europe/Berlin", "Europe/Copenhagen", "America/Santo_Domingo", "Pacific/Galapagos", "America/Guayaquil", "Europe/Tallinn", "Africa/Cairo", "Atlantic/Canary", "Europe/Madrid", "Europe/Helsinki", "Europe/Paris", "Europe/London", "Africa/Accra", "Europe/Athens", "America/Guatemala", "Asia/Hong_Kong", "America/Tegucigalpa", "Europe/Zagreb", "Europe/Budapest", "Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura", "Europe/Dublin", "Asia/Jerusalem", "Asia/Kolkata", "Asia/Baghdad", "Atlantic/Reykjavik", "Europe/Rome", "America/Jamaica", "Asia/Amman", "Asia/Tokyo", "Africa/Nairobi", "Asia/Seoul", "Asia/Kuwait", "Asia/Beirut", "Asia/Colombo", "Europe/Vilnius", "Europe/Luxembourg", "Europe/Riga", "Africa/Casablanca", "Europe/Skopje", "Europe/Malta", "Indian/Mauritius", "Indian/Maldives", "America/Tijuana", "America/Hermosillo", "America/Mazatlan", "America/Mexico_City", "Asia/Kuala_Lumpur", "Africa/Lagos", "America/Managua", "Europe/Amsterdam", "Europe/Oslo", "Pacific/Auckland", "Asia/Muscat", "America/Panama", "America/Lima", "Asia/Manila", "Asia/Karachi", "Europe/Warsaw", "America/Puerto_Rico", "Asia/Gaza", "Atlantic/Azores", "Europe/Lisbon", "America/Asuncion", "Asia/Qatar", "Europe/Bucharest", "Europe/Belgrade", "Europe/Kaliningrad", "Europe/Moscow", "Europe/Samara", "Asia/Yekaterinburg", "Asia/Omsk", "Asia/Krasnoyarsk", "Asia/Irkutsk", "Asia/Yakutsk", "Asia/Vladivostok", "Asia/Magadan", "Asia/Kamchatka", "Asia/Riyadh", "Europe/Stockholm", "Asia/Singapore", "Europe/Ljubljana", "Europe/Bratislava", "America/El_Salvador", "Asia/Bangkok", "Africa/Tunis", "Europe/Istanbul", "America/Port_of_Spain", "Asia/Taipei", "Europe/Kiev", "America/Montevideo", "America/Caracas", "Asia/Ho_Chi_Minh", "Africa/Johannesburg", "America/Winnipeg", "America/Detroit", "Australia/Melbourne", "Asia/Kathmandu", "Asia/Baku", "Africa/Abidjan", "Africa/Addis_Ababa", "Africa/Algiers", "Africa/Asmara", "Africa/Bamako", "Africa/Bangui", "Africa/Banjul", "Africa/Bissau", "Africa/Blantyre", "Africa/Brazzaville", "Africa/Bujumbura", "Africa/Ceuta", "Africa/Conakry", "Africa/Dakar", "Africa/Dar_es_Salaam", "Africa/Djibouti", "Africa/Douala", "Africa/El_Aaiun", "Africa/Freetown", "Africa/Gaborone", "Africa/Harare", "Africa/Juba", "Africa/Kampala", "Africa/Khartoum", "Africa/Kigali", "Africa/Kinshasa", "Africa/Libreville", "Africa/Lome", "Africa/Luanda", "Africa/Lubumbashi", "Africa/Lusaka", "Africa/Malabo", "Africa/Maputo", "Africa/Maseru", "Africa/Mbabane", "Africa/Mogadishu", "Africa/Monrovia", "Africa/Ndjamena", "Africa/Niamey", "Africa/Nouakchott", "Africa/Ouagadougou", "Africa/Porto-Novo", "Africa/Sao_Tome", "Africa/Tripoli", "Africa/Windhoek", "America/Adak", "America/Anguilla", "America/Antigua", "America/Araguaina", "America/Argentina/Catamarca", "America/Argentina/Cordoba", "America/Argentina/Jujuy", "America/Argentina/La_Rioja", "America/Argentina/Mendoza", "America/Argentina/Rio_Gallegos", "America/Argentina/San_Juan", "America/Argentina/Tucuman", "America/Argentina/Ushuaia", "America/Aruba", "America/Bahia", "America/Bahia_Banderas", "America/Barbados", "America/Belize", "America/Boa_Vista", "America/Boise", "America/Cambridge_Bay", "America/Cancun", "America/Cayenne", "America/Cayman", "America/Chihuahua", "America/Creston", "America/Cuiaba", "America/Curacao", "America/Danmarkshavn", "America/Dominica", "America/Eirunepe", "America/Fort_Nelson", "America/Fortaleza", "America/Glace_Bay", "America/Godthab", "America/Goose_Bay", "America/Grand_Turk", "America/Grenada", "America/Guadeloupe", "America/Guyana", "America/Havana", "America/Indiana/Indianapolis", "America/Indiana/Knox", "America/Indiana/Marengo", "America/Indiana/Petersburg", "America/Indiana/Tell_City", "America/Indiana/Vevay", "America/Indiana/Vincennes", "America/Indiana/Winamac", "America/Indianapolis", "America/Inuvik", "America/Juneau", "America/Kentucky/Louisville", "America/Kentucky/Monticello", "America/Kralendijk", "America/Lower_Princes", "America/Maceio", "America/Manaus", "America/Marigot", "America/Martinique", "America/Matamoros", "America/Menominee", "America/Merida", "America/Metlakatla", "America/Miquelon", "America/Moncton", "America/Monterrey", "America/Montreal", "America/Montserrat", "America/Nipigon", "America/Nome", "America/North_Dakota/Beulah", "America/North_Dakota/Center", "America/North_Dakota/New_Salem", "America/Ojinaga", "America/Pangnirtung", "America/Paramaribo", "America/Port-au-Prince", "America/Porto_Velho", "America/Punta_Arenas", "America/Rankin_Inlet", "America/Recife", "America/Resolute", "America/Rio_Branco", "America/Santarem", "America/Scoresbysund", "America/Sitka", "America/St_Barthelemy", "America/St_Kitts", "America/St_Lucia", "America/St_Thomas", "America/St_Vincent", "America/Swift_Current", "America/Thule", "America/Thunder_Bay", "America/Tortola", "America/Whitehorse", "America/Yakutat", "America/Yellowknife", "Antarctica/Casey", "Antarctica/Davis", "Antarctica/DumontDUrville", "Antarctica/Macquarie", "Antarctica/Mawson", "Antarctica/McMurdo", "Antarctica/Palmer", "Antarctica/Rothera", "Antarctica/Syowa", "Antarctica/Troll", "Antarctica/Vostok", "Arctic/Longyearbyen", "Asia/Aden", "Asia/Almaty", "Asia/Anadyr", "Asia/Aqtau", "Asia/Aqtobe", "Asia/Ashgabat", "Asia/Atyrau", "Asia/Barnaul", "Asia/Bishkek", "Asia/Brunei", "Asia/Chita", "Asia/Choibalsan", "Asia/Damascus", "Asia/Dili", "Asia/Dushanbe", "Asia/Famagusta", "Asia/Hebron", "Asia/Hovd", "Asia/Istanbul", "Asia/Kabul", "Asia/Khandyga", "Asia/Kuching", "Asia/Macau", "Asia/Novokuznetsk", "Asia/Novosibirsk", "Asia/Oral", "Asia/Phnom_Penh", "Asia/Pontianak", "Asia/Pyongyang", "Asia/Qostanay", "Asia/Qyzylorda", "Asia/Sakhalin", "Asia/Samarkand", "Asia/Srednekolymsk", "Asia/Tashkent", "Asia/Tbilisi", "Asia/Tehran", "Asia/Thimphu", "Asia/Tomsk", "Asia/Ulaanbaatar", "Asia/Urumqi", "Asia/Ust-Nera", "Asia/Vientiane", "Asia/Yangon", "Asia/Yerevan", "Atlantic/Bermuda", "Atlantic/Cape_Verde", "Atlantic/Faroe", "Atlantic/Madeira", "Atlantic/South_Georgia", "Atlantic/St_Helena", "Atlantic/Stanley", "Australia/Adelaide", "Australia/Brisbane", "Australia/Currie", "Australia/Darwin", "Australia/Eucla", "Australia/Hobart", "Australia/Lindeman", "Australia/Lord_Howe", "CET", "CST6CDT", "EET", "EST", "EST5EDT", "Etc/GMT", "Etc/GMT+0", "Etc/GMT+1", "Etc/GMT+10", "Etc/GMT+11", "Etc/GMT+12", "Etc/GMT+2", "Etc/GMT+3", "Etc/GMT+4", "Etc/GMT+5", "Etc/GMT+6", "Etc/GMT+7", "Etc/GMT+8", "Etc/GMT+9", "Etc/GMT-0", "Etc/GMT-1", "Etc/GMT-10", "Etc/GMT-11", "Etc/GMT-12", "Etc/GMT-13", "Etc/GMT-14", "Etc/GMT-2", "Etc/GMT-3", "Etc/GMT-4", "Etc/GMT-5", "Etc/GMT-6", "Etc/GMT-7", "Etc/GMT-8", "Etc/GMT-9", "Etc/GMT0", "Etc/Greenwich", "Etc/Universal", "Etc/Zulu", "Europe/Andorra", "Europe/Astrakhan", "Europe/Busingen", "Europe/Chisinau", "Europe/Gibraltar", "Europe/Guernsey", "Europe/Isle_of_Man", "Europe/Jersey", "Europe/Kirov", "Europe/Mariehamn", "Europe/Minsk", "Europe/Monaco", "Europe/Nicosia", "Europe/Podgorica", "Europe/San_Marino", "Europe/Saratov", "Europe/Simferopol", "Europe/Tirane", "Europe/Ulyanovsk", "Europe/Uzhgorod", "Europe/Vaduz", "Europe/Vatican", "Europe/Volgograd", "Europe/Zaporozhye", "GMT", "HST", "Indian/Antananarivo", "Indian/Chagos", "Indian/Christmas", "Indian/Cocos", "Indian/Comoro", "Indian/Kerguelen", "Indian/Mahe", "Indian/Mayotte", "Indian/Reunion", "MET", "MST", "MST7MDT", "PST8PDT", "Pacific/Apia", "Pacific/Bougainville", "Pacific/Chatham", "Pacific/Chuuk", "Pacific/Efate", "Pacific/Enderbury", "Pacific/Fakaofo", "Pacific/Fiji", "Pacific/Funafuti", "Pacific/Gambier", "Pacific/Guadalcanal", "Pacific/Guam", "Pacific/Kiritimati", "Pacific/Kosrae", "Pacific/Kwajalein", "Pacific/Majuro", "Pacific/Marquesas", "Pacific/Midway", "Pacific/Nauru", "Pacific/Niue", "Pacific/Norfolk", "Pacific/Noumea", "Pacific/Pago_Pago", "Pacific/Palau", "Pacific/Pitcairn", "Pacific/Pohnpei", "Pacific/Port_Moresby", "Pacific/Rarotonga", "Pacific/Saipan", "Pacific/Tahiti", "Pacific/Tarawa", "Pacific/Tongatapu", "Pacific/Wake", "Pacific/Wallis", "UTC", "WET", "Asia/Calcutta", "Asia/Katmandu", "America/Nuuk", "America/Buenos_Aires"]
    }
}), null);
__d("AdsTimezoneDisplayNamesStatic", ["fbt"], (function(a, b, c, d, e, f, g) {
    e.exports = {
        0: null,
        1: g._("Pacific Time"),
        2: g._("Mountain Time"),
        3: g._("Hawaii Time"),
        4: g._("Alaska Time"),
        5: g._("Mountain Standard Time (Arizona)"),
        6: g._("Central Time"),
        7: g._("Eastern Time"),
        8: g._("Dubai Time"),
        9: g._("San Luis Time"),
        10: g._("Buenos Aires Time"),
        11: g._("Salta Time"),
        12: g._("Vienna Time"),
        13: g._("Perth Time"),
        14: g._("Broken Hill Time"),
        15: g._("Sydney Time"),
        16: g._("Sarajevo Time"),
        17: g._("Dhaka Time"),
        18: g._("Brussels Time"),
        19: g._("Sofia Time"),
        20: g._("Bahrain Time"),
        21: g._("La Paz Time"),
        22: g._("Noronha Time"),
        23: g._("Campo Grande Time"),
        24: g._("Belem Time"),
        25: g._("Sao Paulo Time"),
        26: g._("Nassau Time"),
        27: g._("Dawson Time"),
        28: g._("Vancouver Time"),
        29: g._("Dawson Creek Time"),
        30: g._("Edmonton Time"),
        31: g._("Rainy River Time"),
        32: g._("Regina Time"),
        33: g._("Atikokan Time"),
        34: g._("Iqaluit Time"),
        35: g._("Toronto Time"),
        36: g._("Blanc-Sablon Time"),
        37: g._("Halifax Time"),
        38: g._("St Johns Time"),
        39: g._("Zurich Time"),
        40: g._("Easter Island Time"),
        41: g._("Santiago Time"),
        42: g._("Beijing Time"),
        43: g._("Bogota Time"),
        44: g._("Costa Rica Time"),
        45: g._("Nicosia Time"),
        46: g._("Prague Time"),
        47: g._("Berlin Time"),
        48: g._("Copenhagen Time"),
        49: g._("Santo Domingo Time"),
        50: g._("Galapagos Time"),
        51: g._("Guayaquil Time"),
        52: g._("Tallinn Time"),
        53: g._("Cairo Time"),
        54: g._("Canary Time"),
        55: g._("Madrid Time"),
        56: g._("Helsinki Time"),
        57: g._("Paris Time"),
        58: g._("London Time"),
        59: g._("Accra Time"),
        60: g._("Athens Time"),
        61: g._("Guatemala Time"),
        62: g._("Hong Kong Time"),
        63: g._("Tegucigalpa Time"),
        64: g._("Zagreb Time"),
        65: g._("Budapest Time"),
        66: g._("Jakarta Time"),
        67: g._("Makassar Time"),
        68: g._("Jayapura Time"),
        69: g._("Dublin Time"),
        70: g._("Jerusalem Time"),
        71: g._("Kolkata Time"),
        72: g._("Baghdad Time"),
        73: g._("Reykjavik Time"),
        74: g._("Rome Time"),
        75: g._("Jamaica Time"),
        76: g._("Amman Time"),
        77: g._("Tokyo Time"),
        78: g._("Nairobi Time"),
        79: g._("Seoul Time"),
        80: g._("Kuwait Time"),
        81: g._("Beirut Time"),
        82: g._("Colombo Time"),
        83: g._("Vilnius Time"),
        84: g._("Luxembourg Time"),
        85: g._("Riga Time"),
        86: g._("Casablanca Time"),
        87: g._("Skopje Time"),
        88: g._("Malta Time"),
        89: g._("Mauritius Time"),
        90: g._("Maldives Time"),
        91: g._("Tijuana Time"),
        92: g._("Hermosillo Time"),
        93: g._("Mazatlan Time"),
        94: g._("Mexico City Time"),
        95: g._("Kuala Lumpur Time"),
        96: g._("Lagos Time"),
        97: g._("Managua Time"),
        98: g._("Amsterdam Time"),
        99: g._("Oslo Time"),
        100: g._("Auckland Time"),
        101: g._("Muscat Time"),
        102: g._("Panama Time"),
        103: g._("Lima Time"),
        104: g._("Manila Time"),
        105: g._("Karachi Time"),
        106: g._("Warsaw Time"),
        107: g._("Puerto Rico Time"),
        108: g._("Gaza Time"),
        109: g._("Azores Time"),
        110: g._("Lisbon Time"),
        111: g._("Asuncion Time"),
        112: g._("Qatar Time"),
        113: g._("Bucharest Time"),
        114: g._("Belgrade Time"),
        115: g._("Kaliningrad Time"),
        116: g._("Moscow Time"),
        117: g._("Samara Time"),
        118: g._("Yekaterinburg Time"),
        119: g._("Omsk Time"),
        120: g._("Krasnoyarsk Time"),
        121: g._("Irkutsk Time"),
        122: g._("Yakutsk Time"),
        123: g._("Vladivostok Time"),
        124: g._("Magadan Time"),
        125: g._("Kamchatka Time"),
        126: g._("Riyadh Time"),
        127: g._("Stockholm Time"),
        128: g._("Singapore Time"),
        129: g._("Ljubljana Time"),
        130: g._("Bratislava Time"),
        131: g._("El Salvador Time"),
        132: g._("Bangkok Time"),
        133: g._("Tunis Time"),
        134: g._("Istanbul Time"),
        135: g._("Port of Spain Time"),
        136: g._("Taipei Time"),
        137: g._("Kiev Time"),
        138: g._("Montevideo Time"),
        139: g._("Caracas Time"),
        140: g._("Ho Chi Minh Time"),
        141: g._("Johannesburg Time"),
        142: g._("Winnipeg Time"),
        143: g._("Detroit Time"),
        144: g._("Melbourne Time"),
        145: g._("Kathmandu Time"),
        146: g._("Baku Time"),
        147: null,
        148: null,
        149: null,
        150: null,
        151: null,
        152: null,
        153: null,
        154: null,
        155: null,
        156: null,
        157: null,
        158: null,
        159: null,
        160: null,
        161: null,
        162: null,
        163: null,
        164: null,
        165: null,
        166: null,
        167: null,
        168: null,
        169: null,
        170: null,
        171: null,
        172: null,
        173: null,
        174: null,
        175: null,
        176: null,
        177: null,
        178: null,
        179: null,
        180: null,
        181: null,
        182: null,
        183: null,
        184: null,
        185: null,
        186: null,
        187: g._("Ouagadougou Time"),
        188: null,
        189: null,
        190: null,
        191: null,
        192: null,
        193: null,
        194: null,
        195: null,
        196: null,
        197: null,
        198: null,
        199: null,
        200: null,
        201: null,
        202: null,
        203: null,
        204: null,
        205: null,
        206: null,
        207: null,
        208: null,
        209: null,
        210: null,
        211: null,
        212: null,
        213: null,
        214: null,
        215: null,
        216: null,
        217: null,
        218: null,
        219: null,
        220: null,
        221: null,
        222: null,
        223: null,
        224: null,
        225: null,
        226: null,
        227: null,
        228: null,
        229: null,
        230: null,
        231: null,
        232: null,
        233: null,
        234: null,
        235: null,
        236: null,
        237: null,
        238: null,
        239: null,
        240: null,
        241: null,
        242: null,
        243: null,
        244: null,
        245: null,
        246: null,
        247: null,
        248: null,
        249: null,
        250: null,
        251: null,
        252: null,
        253: null,
        254: null,
        255: null,
        256: null,
        257: null,
        258: null,
        259: null,
        260: null,
        261: null,
        262: null,
        263: null,
        264: null,
        265: null,
        266: null,
        267: null,
        268: null,
        269: null,
        270: null,
        271: null,
        272: null,
        273: null,
        274: null,
        275: null,
        276: null,
        277: null,
        278: null,
        279: null,
        280: null,
        281: null,
        282: null,
        283: null,
        284: null,
        285: null,
        286: null,
        287: null,
        288: null,
        289: null,
        290: null,
        291: null,
        292: null,
        293: null,
        294: null,
        295: null,
        296: null,
        297: null,
        298: null,
        299: null,
        300: null,
        301: null,
        302: null,
        303: null,
        304: null,
        305: null,
        306: null,
        307: null,
        308: null,
        309: null,
        310: null,
        311: null,
        312: null,
        313: null,
        314: null,
        315: null,
        316: null,
        317: null,
        318: null,
        319: null,
        320: null,
        321: null,
        322: null,
        323: null,
        324: null,
        325: null,
        326: null,
        327: null,
        328: null,
        329: null,
        330: null,
        331: null,
        332: null,
        333: null,
        334: null,
        335: null,
        336: null,
        337: null,
        338: null,
        339: null,
        340: null,
        341: null,
        342: null,
        343: null,
        344: null,
        345: null,
        346: null,
        347: g._("Yerevan Time"),
        348: null,
        349: null,
        350: null,
        351: null,
        352: null,
        353: null,
        354: null,
        355: null,
        356: null,
        357: null,
        358: null,
        359: null,
        360: null,
        361: null,
        362: null,
        363: null,
        364: null,
        365: null,
        366: null,
        367: null,
        368: null,
        369: null,
        370: null,
        371: null,
        372: null,
        373: null,
        374: null,
        375: null,
        376: null,
        377: null,
        378: null,
        379: null,
        380: null,
        381: null,
        382: null,
        383: null,
        384: null,
        385: null,
        386: null,
        387: null,
        388: null,
        389: null,
        390: null,
        391: null,
        392: null,
        393: null,
        394: null,
        395: null,
        396: null,
        397: null,
        398: null,
        399: null,
        400: null,
        401: null,
        402: null,
        403: null,
        404: g._("Chisinau Time"),
        405: null,
        406: null,
        407: null,
        408: null,
        409: null,
        410: null,
        411: null,
        412: null,
        413: null,
        414: null,
        415: null,
        416: null,
        417: null,
        418: null,
        419: null,
        420: null,
        421: null,
        422: null,
        423: null,
        424: null,
        425: null,
        426: null,
        427: null,
        428: null,
        429: null,
        430: null,
        431: null,
        432: null,
        433: null,
        434: null,
        435: null,
        436: null,
        437: null,
        438: null,
        439: null,
        440: null,
        441: null,
        442: null,
        443: null,
        444: null,
        445: null,
        446: null,
        447: null,
        448: null,
        449: null,
        450: null,
        451: null,
        452: null,
        453: null,
        454: null,
        455: null,
        456: null,
        457: null,
        458: null,
        459: null,
        460: null,
        461: null,
        462: null,
        463: null,
        464: null,
        465: null,
        466: null,
        467: null,
        468: null,
        469: null,
        470: null,
        471: null,
        472: null,
        473: null,
        474: g._("UTC Time"),
        475: null,
        476: null,
        477: null,
        478: null,
        479: null
    }
}), null);
__d("LaminarDebugger", ["EventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "DEBUGGER";
    a = function() {
        function a() {
            this.$1 = [], this.$6 = {}, this.$3 = 100, this.$2 = new Array(this.$3), this.$4 = new(c("EventEmitter"))(), this.$5 = !1
        }
        var b = a.prototype;
        b.getDebuggerActionDispatchQueue = function() {
            return this.$2
        };
        b.addSnapshotToDebuggerActionDispatchQueue = function(a) {
            this.$6 = a.newState, this.$4.emit(h, a), this.$2.push(a), this.$2.shift()
        };
        b.updateCaptureRate = function(a) {
            a > 0 && (this.$2.length += a - this.$3, this.$3 = a)
        };
        b.addDebugListener = function(a) {
            return this.$4.addListener(h, a)
        };
        b.removeAllDebugListeners = function() {
            this.$4.removeAllListeners(h)
        };
        b.getPauseActionDispatches = function() {
            return this.$5
        };
        b.getAlteredStateSnapshot = function() {
            return this.$6
        };
        b.setPauseActionDispatches = function(a) {
            this.$5 = a
        };
        b.enqueueActionToDispatch = function(a, b) {
            this.$1.push([a, b])
        };
        b.dequeueActionToDispatch = function() {
            return this.$1.shift()
        };
        b.clearActionDispatchQueue = function() {
            this.$1 = []
        };
        b.isActionDispatchQueueEmpty = function() {
            return this.$1.length == 0
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("AdsDataAtomLaminarDebugger", ["LaminarDebugger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = new(c("LaminarDebugger"))();
    g["default"] = a
}), 98);
__d("AdsSpeedConfig", ["URI"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = new(c("URI"))(window.location.href).getQueryData();
    var h = e.browserlab_test,
        i = e.scenario,
        j = {
            editor_l1_dd: "edit_l1",
            change_level_dd: "change_level"
        };

    function a() {
        return !!h || !!i
    }

    function b() {
        return h || j[i]
    }

    function d() {
        return !1
    }
    g.hasBrowserLabTest = a;
    g.getBrowserLabTest = b;
    g.isDevToolsTimingEnabled = d
}), 98);
__d("AdsDataAtomPerformanceUtil", ["AdsSpeedConfig", "URI", "UserTimingUtils", "performanceNow", "requestAnimationFrameAcrossTransitions", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new(c("URI"))(window.location.href).getQueryData().dispatchereventtimer,
        i = new(c("URI"))(window.location.href).getQueryData().logdispatchtimes;
    a = function() {
        function a() {
            var a = this;
            this.$1 = {};
            this.$2 = {};
            this.$3 = {};
            this.startPerformanceMeasurements = function(b, e) {
                if (b == null) return;
                b = b.type;
                h && console.time && console.time(b);
                i && (a.$3[b] = c("performanceNow")());
                e && d("UserTimingUtils").measureStart("AdsDataAtom " + b)
            };
            this.endPerformanceMeasurements = function(b, e) {
                if (b == null) return;
                var f = b.type;
                h && console.timeEnd && console.timeEnd(f);
                if (i) {
                    var g = a.$3[f];
                    delete a.$3[f];
                    a.$1[f] || (a.$1[f] = {
                        count: 0,
                        totalFluxTime: 0,
                        totalTime: 0
                    });
                    a.$1[f].count += 1;
                    a.$1[f].totalFluxTime += c("performanceNow")() - g;
                    a.$5(f, function() {
                        a.$1[f].totalTime += c("performanceNow")() - g
                    })
                }
                e && d("UserTimingUtils").measureEnd("\u221e " + f, "AdsDataAtom " + f)
            };
            this.onDispatchStart = function(b) {
                a.startPerformanceMeasurements(b, a.$4)
            };
            this.onDispatchEnd = function(b) {
                a.endPerformanceMeasurements(b, a.$4)
            };
            this.$4 = d("AdsSpeedConfig").isDevToolsTimingEnabled()
        }
        var b = a.prototype;
        b.$5 = function(a, b) {
            var d = this;
            if (this.$2[a]) return;
            this.$2[a] = 1;
            c("requestAnimationFrameAcrossTransitions")(function() {
                c("setTimeoutAcrossTransitions")(function() {
                    delete d.$2[a], b()
                })
            })
        };
        b.resetTiming = function() {
            this.$1 = {}
        };
        b.getTiming = function() {
            return this.$1
        };
        b.outputTimingTable = function() {
            var a = this;
            console.table(Object.keys(this.$1).map(function(b) {
                return babelHelpers["extends"]({
                    action: b
                }, a.$1[b])
            }))
        };
        return a
    }();
    b = new a();
    g["default"] = b
}), 98);
__d("AdsBrowserExtensionErrorUtils", ["isFalsey"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "chrome-extension://";

    function a(a) {
        a = a.split(h);
        a = a[a.length - 1];
        return a.split("/")[0]
    }

    function b(a) {
        return !c("isFalsey")(a) && a.indexOf(h) > -1
    }
    g.CHROME_EXTENSION = h;
    g.extractExtensionID = a;
    g.isBrowserExtensionError = b
}), 98);
__d("AdsFluxContextInstrumentation", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function a(a) {
        g = a
    }

    function b(a) {}

    function c() {
        return g
    }
    f.actionStart = a;
    f.actionEnd = b;
    f.getLastAction = c
}), 66);
__d("AdsInterfacesLogger", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "primary",
        j = "secondary",
        k = "ads_interfaces_logger_primary_app",
        l = "ads_interfaces_logger_secondary_app",
        m = (a = {}, a[i] = {
            data: [],
            isRegistered: !1
        }, a[j] = {
            data: [],
            isRegistered: !1
        }, a),
        n = new Map(),
        o = new Set();
    b = function() {
        a.__reset = function() {
            m[i] = {
                data: [],
                isRegistered: !1
            }, n.has(k) && n["delete"](k), m[j] = {
                data: [],
                isRegistered: !1
            }, n.has(l) && n["delete"](l), o = new Set()
        };
        a.getPath = function(a) {
            return a === i ? k : l
        };
        a.log = function(b, c) {
            c === void 0 && (c = i);
            c === j && !m[c].isRegistered && m[i].isRegistered && (c = i);
            if (!m[c].isRegistered) {
                m[c].data.push(b);
                return
            }
            c = n.get(this.getPath(c));
            c || h(0, 2975);
            c instanceof a || h(0, 2976);
            c.__log(b)
        };
        a.logOnce = function(b, c) {
            c === void 0 && (c = i);
            var d = JSON.stringify(b);
            if (o.has(d)) return;
            a.log(b, c);
            o.add(d)
        };
        a.get = function(a) {
            a === void 0 && (a = i);
            a === j && !m[a].isRegistered && m[i].isRegistered && (a = i);
            a = n.get(this.getPath(a));
            return a
        };

        function a(a, b) {
            this.__log = a.log, this.__interfaceID = b
        }
        var b = a.prototype;
        b.getInterfaceID = function() {
            return this.__interfaceID
        };
        b.register = function(a) {
            n.set(this.constructor.getPath(a), this), m[a].isRegistered = !0, m[a].data.length > 0 && (m[a].data.forEach(this.__log), m[a].data = []), a === i && m[j].data.length > 0 && (m[j].data.forEach(this.__log), m[j].data = [])
        };
        b.unregister = function(a) {
            n["delete"](this.constructor.getPath(a)), m[a].isRegistered = !1
        };
        return a
    }();
    b.LOG_TYPE_PRIMARY_APP = i;
    b.LOG_TYPE_SECONDARY_APP = j;
    g["default"] = b
}), 98);
__d("PreloadingEvent.flow", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["ADS_INTERFACES_PRELOADING_SUCCESS", "ADS_INTERFACES_PRELOADING_ISSUE"]);
    c = b("$InternalEnum").Mirrored(["UNNECESSARY_SERVER_PRELOADING", "ERROR_LOADING_PRELOADED_DATA", "SERVER_DIDNT_SEND_ALL_NECESSARY_DATA", "SERVER_DIDNT_BEAT_JS_EXECUTION", "SERVER_DIDNT_BEAT_API_START", "SERVER_DIDNT_BEAT_API", "SERVER_DISABLED_DIDNT_SEND_DATA", "PRELOAD_HIT", "UNUSED_PRELOADED_DATA"]);
    f.PreloadingEventName = a;
    f.PreloadingEventType = c
}), 66);
__d("AdsInterfacesLoggerUtils", ["AdsBrowserExtensionErrorUtils", "AdsFluxContextInstrumentation", "AdsInterfacesLogger", "ErrorNormalizeUtils", "ErrorPubSub", "PreloadingEvent.flow", "getErrorSafe", "requireWeak"], (function(a, b, c, d, e, f, g) {
    "use strict";
    ({
        defaultJSErrorHandler: function() {}
    });
    c("requireWeak")("ErrorLogging", function(a) {
        return a
    });

    function h(a, b) {
        var e;
        e = (e = c("ErrorNormalizeUtils").ifNormalizedError(a)) != null ? e : c("ErrorNormalizeUtils").normalizeError(c("getErrorSafe")(a));
        try {
            JSON.stringify(b)
        } catch (a) {
            b = null
        }
        a = babelHelpers["extends"]({
            stack_trace: e.stack,
            action_type_on_error: d("AdsFluxContextInstrumentation").getLastAction()
        }, b, {
            normalized_error: e
        });
        a.error_name = e.name;
        a.message = e.message;
        a.meta_message = e.messageWithParams ? e.messageWithParams[0] : "-";
        a.error_line = e.line;
        a.error_script = e.script;
        return a
    }

    function i(a, b, e) {
        e = h(a, e);
        if (d("AdsBrowserExtensionErrorUtils").isBrowserExtensionError(a.stack) || d("AdsBrowserExtensionErrorUtils").isBrowserExtensionError(e.error_script)) return;
        if (a.message != null && a.message.includes("ResizeObserver loop limit exceeded")) return;
        c("AdsInterfacesLogger").log({
            eventName: b,
            eventCategory: "errors",
            data: e
        }, c("AdsInterfacesLogger").LOG_TYPE_PRIMARY_APP)
    }

    function a(a, b) {
        c("AdsInterfacesLogger").log({
            eventName: d("PreloadingEvent.flow").PreloadingEventName.getName(b),
            eventCategory: "preloading",
            data: a
        }, c("AdsInterfacesLogger").LOG_TYPE_PRIMARY_APP)
    }

    function b(a, b) {
        i(a, "ADS_INTERFACES_ERROR_EXCEPTION", b)
    }

    function e(a, b) {
        i(a, "ADS_INTERFACES_CRITICAL_EXCEPTION", b)
    }

    function j(a, b) {
        i(a, "ADS_INTERFACES_ERROR_FATAL", b)
    }

    function f(a, b) {
        i(a, "ADS_INTERFACES_USER_ERROR", b)
    }
    c("ErrorPubSub").addListener(function(a, b) {
        b === "ONERROR" && !a.message.toLowerCase().startsWith("script error") && j(a)
    });
    g.constructLogDataForError = h;
    g.logPreloading = a;
    g.logException = b;
    g.logCriticalException = e;
    g.logFatal = j;
    g.logUserError = f
}), 98);
__d("AdsPageTransitionActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "PAGE_TRANSITION"
    }
}), null);
__d("AdsDataAtomInstrumentation", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = [];

    function a(a) {
        g.push(a)
    }

    function b(a, b) {
        g.forEach(function(c) {
            return c.actionStart(a, b)
        })
    }

    function c(a, b) {
        g.forEach(function(c) {
            return c.actionEnd && c.actionEnd(a, b)
        })
    }

    function d(a, b) {
        g.forEach(function(c) {
            return c.dispatchCallbacksStart && c.dispatchCallbacksStart(a, b)
        })
    }

    function e(a, b) {
        g.forEach(function(c) {
            return c.dispatchCallbacksEnd && c.dispatchCallbacksEnd(a, b)
        })
    }

    function h() {
        var a = [];
        g.forEach(function(b) {
            b = b.measureDispatchCallbacks ? b.measureDispatchCallbacks() : null;
            b && a.push(b)
        });
        return a.length ? function(b) {
            a.forEach(function(a) {
                return a(b)
            })
        } : null
    }
    f.addInstrumentation = a;
    f.onActionStart = b;
    f.onActionEnd = c;
    f.onDispatchCallbacksStart = d;
    f.onDispatchCallbacksEnd = e;
    f.onMeasureDispatchCallbacks = h
}), 66);
__d("AdsDataDispatchUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = Object.freeze([]);

    function h(a, b) {
        return b.isDisabled || a.has(b.provider) ? a : a.set(b.provider, b)
    }

    function a(a, b, c, d, e) {
        return babelHelpers["extends"]({
            _dispatchConvention: e
        }, d, {
            type: a,
            _dataReducers: b,
            _dataLoggers: c
        })
    }

    function b(a) {
        return a._dataReducers ? a._dataReducers : g
    }

    function c(a) {
        return a._dataLoggers ? a._dataLoggers : g
    }

    function d(a, b) {
        return Array.from(b.reduce(h, a.reduce(h, new Map())).values())
    }

    function e(a) {
        return a._dispatchConvention === "laminar"
    }

    function i(a) {
        return a.actionType
    }
    f.mergeParameters = a;
    f.getDataReducers = b;
    f.getDataLoggers = c;
    f.mergeReducers = d;
    f.shouldSkipLegacyFluxDispatch = e;
    f.getActionType = i
}), 66);
__d("AdsDispatchCycle", ["invariant", "AdsDataAtomInstrumentation"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = ((a = window.performance) == null ? void 0 : a.now) != null ? function() {
            return window.performance.now()
        } : function() {
            return Date.now()
        },
        j = Object.freeze({
            PENDING: "PENDING",
            STARTED: "STARTED",
            COMPLETE: "COMPLETE"
        });
    b = function() {
        function a(a, b, c, e) {
            var f = this;
            this.$8 = null;
            this.$9 = [];
            this.$1 = [];
            this.$2 = {};
            this.$5 = {};
            this.$3 = e;
            this.$4 = c;
            e = d("AdsDataAtomInstrumentation").onMeasureDispatchCallbacks();
            e && (this.$7 = e, this.$8 = []);
            a.forEach(function(a, b) {
                return f.register(b, a)
            });
            this.$6 = b
        }
        var b = a.prototype;
        b.start = function() {
            for (var a = this.$1, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var d;
                if (b) {
                    if (c >= a.length) break;
                    d = a[c++]
                } else {
                    c = a.next();
                    if (c.done) break;
                    d = c.value
                }
                d = d;
                this.$10(d)
            }
            this.$8 && this.$7 && this.$7({
                entries: this.$8,
                actionType: this.$4
            })
        };
        b.waitFor = function(a) {
            for (var a = a, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var d;
                if (b) {
                    if (c >= a.length) break;
                    d = a[c++]
                } else {
                    c = a.next();
                    if (c.done) break;
                    d = c.value
                }
                d = d;
                this.$10(d)
            }
        };
        b.register = function(a, b) {
            this.$1.push(a), this.$2[a] = b, this.$5[a] = j.PENDING
        };
        b.getPayload = function() {
            return this.$6
        };
        b.$10 = function(a) {
            var b = this;
            switch (this.$5[a]) {
                case j.COMPLETE:
                    break;
                case j.PENDING:
                    this.$5[a] = j.STARTED;
                    this.$9.push(a);
                    var c = this.$7 ? i() : null;
                    this.$2[a](this.$6);
                    if (this.$8 && c != null) {
                        this.$8.push({
                            start: c,
                            end: i(),
                            name: (c = this.$3[a]) != null ? c : "unknown"
                        })
                    }
                    this.$9.pop();
                    this.$5[a] = j.COMPLETE;
                    break;
                case j.STARTED:
                    h(0, 15659, a, this.$3[a], this.$4, this.$9.map(function(a) {
                        return b.$3[a]
                    }).join(", "));
                default:
                    break
            }
        };
        return a
    }();
    g["default"] = b
}), 98);
__d("AdsReactBatchedUpdatesUtils", ["ifRequired"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        c("ifRequired")("ReactDOM", function(b) {
            return b.unstable_batchedUpdates(a)
        }, a)
    }
    g.batchUpdatesIfReactIsLoaded = a
}), 98);
__d("DataAtomBase", ["invariant", "AdsDataAtomInstrumentation", "AdsDataDispatchUtils", "AdsDispatchCycle", "AdsReactBatchedUpdatesUtils", "EventEmitter", "FBLogger"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = typeof jest !== "undefined";
    a = function() {
        function a(a, b) {
            var d = this;
            this.registerDependency = function(a, b) {
                d.$6[b] == null && (d.$6[b] = new Set()), d.$6[b].add(a)
            };
            this.$1 = {};
            this.__callbacksNames = {};
            this.$2 = {};
            this.$9 = {};
            this.$3 = {};
            this.$5 = {};
            this.$6 = {};
            this.$7 = {};
            this.$8 = {};
            this.__dispatchTokenActionTypes = {};
            this.$10 = 1;
            this.$11 = null;
            this.$12 = new Set();
            this.__dispatchSeqNumber = 0;
            this.__catchErrors = !i;
            this.$13 = [];
            this.__laminarAlteredState = {};
            this.$14 = new(c("EventEmitter"))();
            this.$15 = [];
            this.__previousLegacyFluxReducerProviderState = {};
            this.$16 = b;
            this.$17 = new Set();
            this.$4 = {};
            this.$18 = a != null ? a : []
        }
        var b = a.prototype;
        b.register = function(a, b, c, d) {
            var e = this;
            this.$18.forEach(function(c) {
                c.wrapCallback != null && (a = c.wrapCallback(a, b))
            });
            var f = this.$19(b),
                g = this.__invokeCallback.bind(this, f, a);
            this.$1[f] = g;
            this.__callbacksNames[f] = d;
            if (c == null) this.$4[f] = g;
            else {
                d = c.getActionTypes();
                d != null && Array.isArray(d) ? (d.forEach(function(a) {
                    e.$2[a] || (e.$2[a] = {}, e.$9[a] = {}), e.$2[a][f] = g, c != null && c.__setAsUnchanged && (e.$9[a][f] = c.__setAsUnchanged.bind(c))
                }), this.__dispatchTokenActionTypes[f] = d) : this.$3[f] = g;
                this.$20(c, f);
                this.$7[f] = new Set(c.__getActionTypes());
                this.$7[f].forEach(function(a) {
                    e.$8[a] || (e.$8[a] = new Set()), e.$8[a].add(f)
                })
            }
            this.$11 && this.$11.register(f, g);
            this.$18.forEach(function(a) {
                a.onRegistered != null && a.onRegistered(b, f, c)
            });
            return f
        };
        b.registerContainer = function(a, b) {
            b = this.$19(b);
            a = this.__invokeCallback.bind(this, b, a);
            this.$5[b] = a;
            return b
        };
        b.unregister = function(a) {
            var b = this;
            this.$1[a] || this.$5[a] || h(0, 1331, a);
            delete this.$1[a];
            delete this.$4[a];
            delete this.$5[a];
            var c = this.__dispatchTokenActionTypes[a];
            c ? (c.forEach(function(c) {
                delete b.$2[c][a], delete b.$9[c][a]
            }), delete this.__dispatchTokenActionTypes[a]) : delete this.$3[a];
            this.$6[a] && this.$6[a].size;
            delete this.$6[a];
            this.$18.forEach(function(b) {
                b.onUnregistered && b.onUnregistered(a)
            })
        };
        b.$20 = function(a, b) {
            if (typeof a.__getDependencyStores !== "function") return;
            a = a.__getDependencyStores();
            if (!a) return;
            for (var c = 0; c < a.length; c++) {
                var d = a[c] && a[c].getDispatchToken && a[c].getDispatchToken();
                if (d == null) continue;
                var e = this.registerDependency;
                e && e(b, d)
            }
        };
        b.waitFor = function(a) {
            this.$18.forEach(function(b) {
                b.doWaitFor != null && b.doWaitFor(a)
            });
            var b = this.$11;
            b || h(0, 1332);
            b.waitFor(a);
            this.$18.forEach(function(b) {
                b.didWaitFor != null && b.didWaitFor(a)
            })
        };
        b.isDispatching = function() {
            return !!this.$11
        };
        b.__invokeCallback = function(a, b, d) {
            if (this.__catchErrors) try {
                b(d)
            } catch (b) {
                var e;
                e = (e = this.__callbacksNames[a]) != null ? e : a;
                a = d && d.action && d.action.type;
                c("FBLogger")("laminar").catching(b).warn("Error in DataAtom callback (Store: %s, Action: %s)", e, a)
            } else b(d)
        };
        b.$19 = function(a) {
            return (a ? a + "_" : "ID_") + this.$10++
        };
        b.$21 = function(a) {
            a = a.action;
            if (a) {
                var b = a.type || a.actionType;
                a.type = b;
                a.actionType = b
            }
        };
        b.$22 = function(a, b, c) {
            if (b !== c) {
                this.__laminarAlteredState = babelHelpers["extends"]({}, this.__laminarAlteredState, (b = {}, b[a] = c, b));
                this.$12.add(a);
                this.$14.emit(a)
            }
        };
        b.$23 = function(a, b, c) {
            var d = this;
            b !== c && a.forEach(function(a) {
                var b = d.__laminarAlteredState[a.provider],
                    e = a.reduce(c);
                d.$22(a.provider, b, e)
            })
        };
        b.$24 = function(a, b, c) {
            var d = this;
            this.__invokeCallback(a.provider, function(c) {
                c = c.action;
                b != null && (d.$11 != null || h(0, 6393, a.provider), d.$11.waitFor(b));
                var e = d.__laminarAlteredState[a.provider];
                c = a.reduce(d.__laminarAlteredState, c);
                d.$22(a.provider, e, c);
                d.$23(a.triggerReducers, e, c)
            }, c)
        };
        b.$25 = function(a, b) {
            var c = this;
            this.__invokeCallback(a, function(b) {
                b = b.action;
                b = b.data;
                if (Object.prototype.hasOwnProperty.call(b, a)) {
                    var d;
                    c.__laminarAlteredState = babelHelpers["extends"]({}, c.__laminarAlteredState, (d = {}, d[a] = b[a], d))
                } else delete c.__laminarAlteredState[a];
                c.$14.emit(a)
            }, b)
        };
        b.$26 = function(a, b, c) {
            var e = this,
                f = [];
            this.$15.forEach(function(a) {
                e.__laminarAlteredState[a.provider] && e.__previousLegacyFluxReducerProviderState[a.provider] !== e.__laminarAlteredState[a.provider] && (f.push(a), e.__previousLegacyFluxReducerProviderState[a.provider] = e.__laminarAlteredState[a.provider])
            });
            var g = d("AdsDataDispatchUtils").mergeReducers(d("AdsDataDispatchUtils").getDataReducers(b), f),
                h = [],
                i = [],
                j = [],
                k = {};
            for (var g = g, l = Array.isArray(g), m = 0, g = l ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var n;
                if (l) {
                    if (m >= g.length) break;
                    n = g[m++]
                } else {
                    m = g.next();
                    if (m.done) break;
                    n = m.value
                }
                n = n;
                var o = this.__laminarAlteredState[n.provider],
                    p = n.reducerName;
                h.push({
                    providerName: n.provider,
                    alteredState: o
                });
                if (n != null) {
                    n.reducerName && i.push(n.reducerName);
                    j.push(n.provider);
                    if (p != null) {
                        k[p] = {
                            provider: n.provider,
                            triggerReducers: {}
                        };
                        for (var o = n.triggerReducers, n = Array.isArray(o), q = 0, o = n ? o : o[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                            var r;
                            if (n) {
                                if (q >= o.length) break;
                                r = o[q++]
                            } else {
                                q = o.next();
                                if (q.done) break;
                                r = q.value
                            }
                            r = r;
                            if (r != null) {
                                var s = r.triggerReducer;
                                k[p].triggerReducers[s] = {
                                    provider: r.provider
                                }
                            }
                        }
                    }
                }
            }
            r = {
                actionItem: b,
                alteredStates: h,
                providers: j,
                reducers: i,
                actionDispatchGraph: k,
                newState: this.__laminarAlteredState,
                sequenceNumber: a,
                siblings: [],
                shouldDisplay: !0,
                isActive: !0,
                debugging: {
                    stack: new Error().stack,
                    options: (s = c) != null ? s : {
                        line: "0",
                        module: "No Module"
                    }
                }
            };
            this.$16 != null && this.$16.addSnapshotToDebuggerActionDispatchQueue(r)
        };
        b.revert = function(a, b) {
            var d = this,
                e = new Map();
            this.$16 != null && this.$16.setPauseActionDispatches(!0);
            b.forEach(function(a) {
                e.set(a, d.$25.bind(d, a))
            });
            b = {
                type: "ADS_DATA_ATOM.REVERT",
                actionType: "ADS_DATA_ATOM.REVERT",
                data: a
            };
            a = {
                action: b
            };
            l(e, this.$1);
            l(e, this.$5);
            this.$11 = new(c("AdsDispatchCycle"))(e, a, j(a), this.__callbacksNames);
            this.$11.start();
            this.$11 = null
        };
        b.commitRevert = function() {
            var a = this.$16;
            a != null && (a.setPauseActionDispatches(!1), a.clearActionDispatchQueue())
        };
        b.undoRevert = function(a) {
            var b = this,
                c = Object.keys(a).filter(function(c) {
                    return a[c] !== b.__laminarAlteredState[c]
                });
            this.revert(a, c);
            this.$16 != null && this.$16.setPauseActionDispatches(!1);
            c = this.$16;
            while (c != null && !c.isActionDispatchQueueEmpty() && !c.getPauseActionDispatches()) c.setPauseActionDispatches(!1), this.dispatch.apply(this, c.dequeueActionToDispatch())
        };
        b.$27 = function(a) {
            var b = {},
                c = function() {
                    var c = a[d];
                    c.triggerReducers.forEach(function(a) {
                        a = a.provider;
                        b[a] = Object.prototype.hasOwnProperty.call(b, a) ? b[a].push(c.provider) : [c.provider]
                    })
                };
            for (var d = 0; d < a.length; d++) c();
            return b
        };
        b.$28 = function(a, b) {
            for (var b = b, c = Array.isArray(b), d = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= b.length) break;
                    e = b[d++]
                } else {
                    d = b.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                e = this.$6[e];
                if (e) {
                    for (var f = e, g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var i;
                        if (g) {
                            if (h >= f.length) break;
                            i = f[h++]
                        } else {
                            h = f.next();
                            if (h.done) break;
                            i = h.value
                        }
                        i = i;
                        a.has(i) || a.set(i, this.$1[i])
                    }
                    this.$28(a, e)
                }
            }
        };
        b.__dispatch = function(a) {
            var b = this,
                e = a.action;
            this.__dispatchSeqNumber++;
            var f = e.type;
            this.$18.forEach(function(a) {
                a.onDispatchStart != null && a.onDispatchStart(e)
            });
            this.$11 && k(this.$11.getPayload(), a);
            var g = new Map(),
                h = d("AdsDataDispatchUtils").mergeReducers(d("AdsDataDispatchUtils").getDataReducers(e), d("AdsDataDispatchUtils").shouldSkipLegacyFluxDispatch(e) ? [] : this.$15),
                i = this.$27(h);
            for (var h = h, m = Array.isArray(h), n = 0, h = m ? h : h[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var o;
                if (m) {
                    if (n >= h.length) break;
                    o = h[n++]
                } else {
                    n = h.next();
                    if (n.done) break;
                    o = n.value
                }
                o = o;
                (o.registries.length == 0 || o.registries.some(function(a) {
                    return b.$17.has(a)
                })) && (g.set(o.provider, this.$24.bind(this, o, i[o.provider])), this.__callbacksNames[o.provider] = o.provider)
            }
            d("AdsDataDispatchUtils").shouldSkipLegacyFluxDispatch(e) ? (this.$8[f] && this.$8[f].forEach(function(a) {
                g.set(a, b.$1[a])
            }), this.$28(g, g.keys()), l(g, this.$4)) : (l(g, this.$3), l(g, this.$2[f]), l(g, this.$4));
            o = d("AdsDataDispatchUtils").getDataLoggers(e);
            m = function() {
                if (q) {
                    if (r >= p.length) return "break";
                    n = p[r++]
                } else {
                    r = p.next();
                    if (r.done) return "break";
                    n = r.value
                }
                var a = n;
                (a.registries.length == 0 || a.registries.some(function(a) {
                    return b.$17.has(a)
                })) && (g.set(a.id, b.__invokeCallback.bind(b, a.id, function(b) {
                    b = b.action;
                    a(b)
                })), b.__callbacksNames[a.id] = a.id)
            };
            for (var p = o, q = Array.isArray(p), r = 0, p = q ? p : p[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                h = m();
                if (h === "break") break
            }
            this.$11 = new(c("AdsDispatchCycle"))(g, a, j(a), this.__callbacksNames);
            this.$11.start();
            this.$11 = null;
            this.$12 = new Set();
            if (this.$9[f])
                for (var i in this.$9[f]) this.$9[f][i]();
            this.$18.forEach(function(a) {
                a.onDispatchEnd != null && a.onDispatchEnd(e)
            })
        };
        b.__updateContainers = function(a) {
            var b = this;
            Object.keys(this.$5).forEach(function(c) {
                return b.$5[c] && b.$5[c](a)
            })
        };
        b.hasChangedInDispatchCycle = function(a) {
            this.$11 != null || h(0, 1335, a);
            return this.$12.has(a)
        };
        b.dispatch = function(a, b) {
            var c = this;
            if (this.$16 != null && this.$16.getPauseActionDispatches()) {
                this.$16.enqueueActionToDispatch(a, b);
                return
            }
            this.$21(a);
            var e = this.__dispatchSeqNumber;
            d("AdsDataAtomInstrumentation").onActionStart(a.action.type, e);
            var f = function() {
                d("AdsDataAtomInstrumentation").onDispatchCallbacksStart(a.action.type, e), c.__dispatch(a), d("AdsDataAtomInstrumentation").onDispatchCallbacksEnd(a.action.type, e), c.__updateContainers(a)
            };
            d("AdsReactBatchedUpdatesUtils").batchUpdatesIfReactIsLoaded(f);
            this.$26(e, a.action, b);
            this.$29();
            d("AdsDataAtomInstrumentation").onActionEnd(a.action.type, e)
        };
        b.dispatchAction = function(a, b) {
            this.dispatch({
                action: a
            }, b)
        };
        b.$29 = function() {
            var a = this.$13;
            this.$13 = [];
            a.forEach(function(a) {
                return a()
            });
            this.$13.length = 0
        };
        b.handleUpdateFromServerResponse = function(a) {
            this.dispatch({
                action: a
            })
        };
        b.handleUpdateFromViewAction = function(a) {
            this.dispatch({
                action: a
            })
        };
        b.addPostDispatchCallback = function(a) {
            this.isDispatching() ? this.$13.push(a) : a()
        };
        b.setCatchErrors = function(a) {
            this.__catchErrors = a
        };
        b.laminarRegisterLegacyFluxReducer = function(a) {
            this.$15.push(a), this.__previousLegacyFluxReducerProviderState[a.provider] = a.providerInitialState()
        };
        b.getAlteredState = function() {
            return this.__laminarAlteredState
        };
        b.addListener = function(a, b) {
            return this.$14.addListener(a, b)
        };
        b.loadRegistry = function(a) {
            this.$17.add(a)
        };
        b.unloadRegistry = function(a) {
            this.$17["delete"](a)
        };
        return a
    }();

    function j(a) {
        return a && a.action && a.action.type || "<unknown>"
    }

    function k(a, b) {
        h(0, 1336, j(b), j(a))
    }

    function l(a, b) {
        if (b != null) {
            var c = b;
            Object.keys(c).forEach(function(b) {
                return a.set(b, c[b])
            })
        }
    }
    g["default"] = a
}), 98);
__d("AdsDataAtom", ["AdsDataAtomDebugger", "AdsDataAtomLaminarDebugger", "AdsDataAtomPerformanceUtil", "AdsInterfacesLoggerUtils", "AdsPageTransitionActionFlux", "DataAtomBase", "ErrorSerializer", "Run"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            b = a.call(this, [c("AdsDataAtomPerformanceUtil")], h) || this;
            d("Run").onAfterUnload(function() {
                b.dispatch({
                    action: {
                        type: d("AdsPageTransitionActionFlux").actionType
                    }
                })
            });
            return b
        }
        var e = b.prototype;
        e.__invokeCallback = function(a, b, e) {
            if (this.__catchErrors) try {
                b(e)
            } catch (b) {
                a = {
                    action_type_on_error: e && e.action && e.action.type,
                    error_type: "FLUX_STORE",
                    payload_on_error: e,
                    store_name: this.__callbacksNames[a]
                };
                c("ErrorSerializer").aggregateError(b, {
                    type: "fatal"
                });
                d("AdsInterfacesLoggerUtils").logCriticalException(b, a)
            } else b(e)
        };
        return b
    }(c("DataAtomBase"));
    b = new a();
    e = b;
    g["default"] = e
}), 98);
__d("LaminarAction", ["AdsDataAtom", "AdsDataDispatchUtils", "filterNulls"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f) {
        var g = function(g, h) {
            var i = c("filterNulls")(a()),
                j = c("filterNulls")(b());
            c("AdsDataAtom").dispatchAction(d("AdsDataDispatchUtils").mergeParameters(e, i, j, g, f), h)
        };
        return {
            dispatch: g,
            actionType: e
        }
    }
    g.create = a
}), 98);
__d("AdsDataPluginsInternalUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a,
            c;
        return function() {
            b && (c = b(), b = null);
            return c
        }
    }
    f.memoize = a
}), 66);
__d("LaminarExperimentalSelector", ["AdsDataAtom", "AdsDataPluginsInternalUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b = new Set();
        for (var c in a)
            for (var d = a[c].providers, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.add(g)
            }
        return Array.from(b)
    }

    function i(a) {
        var b = new Set();
        for (var c in a)
            for (var d = a[c].toFluxSelector().getStores(), e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.add(g)
            }
        return Array.from(b)
    }

    function j(a, b, c) {
        var d = {};
        for (var e in a) d[e] = a[e].select(b, c);
        return d
    }

    function k(a, b) {
        var c = Object.keys(a);
        if (c.length !== Object.keys(b).length) return !1;
        for (var d = 0; d < c.length; d++) {
            var e = c[d];
            if (!Object.prototype.hasOwnProperty.call(b, e) || a[e] !== b[e]) return !1
        }
        return !0
    }

    function a(a, b) {
        var e = null,
            f = null,
            g = function(c, d) {
                c = j(a, c, d);
                (!f || !k(c, f)) && (e = b(c), f = c);
                return e
            },
            l = function(a) {
                return g(c("AdsDataAtom").getAlteredState(), a)
            },
            m = Object.assign(l, {
                providers: h(a),
                select: g,
                toFluxSelector: d("AdsDataPluginsInternalUtils").memoize(function() {
                    return Object.assign(function() {
                        return m(c("AdsDataAtom").getAlteredState())
                    }, {
                        getStores: function() {
                            return i(a)
                        },
                        isGetStoresStatic: !0,
                        isGetStoresPure: !0,
                        rawSelectFn: function() {
                            return m(c("AdsDataAtom").getAlteredState())
                        }
                    })
                })
            });
        return m
    }
    g.create = a
}), 98);
__d("AdsFluxCurrentContainer", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function a() {
        return g
    }

    function b(a) {
        g = a
    }
    f.getCurrentContainer = a;
    f.setCurrentContainer = b
}), 66);
__d("LaminarCurrentContainer", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function a() {
        return g
    }

    function b(a) {
        g = a
    }
    f.getCurrentContainer = a;
    f.setCurrentContainer = b
}), 66);
__d("LaminarReactHooks", ["invariant", "AdsDataAtom", "AdsFluxCurrentContainer", "FluxContainerNameUtils", "LaminarCurrentContainer", "react", "useSubscriptionValue", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = i.useCallback,
        k = i.useEffect,
        l = i.useMemo,
        m = i.useRef,
        n = "laminarContainer(unknown)";

    function a(a) {
        var b = d("LaminarCurrentContainer").getCurrentContainer(),
            e = a.provider;
        b = j(function(b) {
            b = a();
            return b
        }, [a]);
        var f = j(function(a) {
            var b = c("AdsDataAtom").addListener(e, a);
            return function() {
                return b.remove()
            }
        }, [e]);
        b = c("useSubscriptionValue")({
            getCurrentValue: b,
            subscribe: f
        });
        return b
    }

    function b(a, b, e) {
        var f, g = (f = (f = (f = e == null ? void 0 : e.containerName) != null ? f : a.displayName) != null ? f : a.name) != null ? f : n;

        function h(b) {
            var f = c("useUnsafeRef_DEPRECATED")(null),
                h = c("useUnsafeRef_DEPRECATED")(!0),
                i = m(null);
            k(function() {
                h.current && (i.current = b)
            });
            var j = (e == null ? void 0 : e.isFluxContainer) === !0 ? d("AdsFluxCurrentContainer") : d("LaminarCurrentContainer");
            j.setCurrentContainer(g);
            var n = l(function() {
                var a = b.forwardedRef,
                    c = babelHelpers.objectWithoutPropertiesLoose(b, ["forwardedRef"]);
                return a === void 0 ? b : babelHelpers["extends"]({}, c, {
                    ref: a
                })
            }, [b]);
            n = a(n);
            j.setCurrentContainer(null);
            h.current = f.current !== n;
            f.current = n;
            return n
        }
        d("FluxContainerNameUtils").nameContainer(h, g);
        h.displayName = g;
        f = function(a, b) {
            return i.jsx(h, babelHelpers["extends"]({}, a, {
                forwardedRef: b
            }))
        };
        f.displayName = g;
        f = i.forwardRef(f);
        f = i.memo(f, b);
        f.displayName = g;
        return f
    }
    g.useProvider = a;
    g.laminarContainer = b
}), 98);
__d("LaminarReducerWithFluxSelectors", ["AdsDataAtom", "AdsSelectorUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return function(e, f) {
            var g = Object.keys(a),
                h = g.map(function(b) {
                    return a[b]
                });
            c("AdsDataAtom").waitFor(d("AdsSelectorUtils").getStoreDispatchTokens(h));
            h = g.reduce(function(b, c) {
                return Object.assign(b, (b = {}, b[c] = a[c](), b))
            }, {});
            return b(e, f, h)
        }
    }
    g["default"] = a
}), 98);
__d("AdsSelectorProfilerUtils", ["AdsSelectorInstrumentation", "adsCacheSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f) {
        var g = {
            cacheHit: !0
        };
        a = a.bind(void 0, g);
        var h = c("adsCacheSelector")(a, b, e, void 0, f);
        a = function(a) {
            g.cacheHit = !0;
            var b = d("AdsSelectorInstrumentation").onSelectorCall();
            a = h(a);
            b && b({
                name: f,
                cacheHit: g.cacheHit
            });
            return a
        };
        return a
    }

    function b(a, b) {
        var c = {
            cacheHit: !0
        };
        return function(e) {
            c.cacheHit = !0;
            var f = d("AdsSelectorInstrumentation").onSelectorCall();
            e = a(e, c);
            f && f({
                name: b,
                cacheHit: c.cacheHit
            });
            return e
        }
    }
    g.instrumentSelectorInclusive = a;
    g.instrumentLaminarSelector = b
}), 98);
__d("LRUKeyedExpiringCache", ["invariant", "DateConsts", "firstx"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = 15,
        j = 1e3;
    a = function() {
        function a(a, b, c) {
            b === void 0 && (b = j), c === void 0 && (c = i), this.$5 = new Map(), b > 0 || h(0, 18721), this.$1 = b, this.$4 = a, this.$2 = c
        }
        var b = a.prototype;
        b.$6 = function() {
            clearTimeout(this.$3);
            if (this.$2 <= 0) return;
            this.$3 = setTimeout(this.$7.bind(this), this.$2 * d("DateConsts").SEC_PER_MIN * d("DateConsts").MS_PER_SEC)
        };
        b.$7 = function() {
            var a = this,
                b = Array.from(this.$5.keys());
            b.forEach(function(b) {
                var c = a.$5.get(b);
                if (c == null) return;
                !c.hasBeenAccessed ? a.$5["delete"](b) : c.hasBeenAccessed = !1
            });
            this.$5.size > 0 && this.$6()
        };
        b.get = function(a) {
            a = this.$4(a);
            var b = this.$5.get(a);
            if (b == null) return void 0;
            b.hasBeenAccessed = !0;
            this.$5["delete"](a);
            this.$5.set(a, b);
            return b.data
        };
        b.set = function(a, b) {
            this.$5.size === 0 && this.$6();
            a = this.$4(a);
            this.$5["delete"](a);
            var d = !1;
            if (this.$1 <= this.$5.size && this.$5.size > 0) {
                var e = c("firstx")(this.$5.keys());
                this.$5["delete"](e);
                d = !0
            }
            this.$5.set(a, {
                data: b,
                hasBeenAccessed: !0
            });
            return d
        };
        b.size = function() {
            return this.$5.size
        };
        b.clear = function() {
            this.$5.clear(), clearTimeout(this.$3)
        };
        b.getCacheSnapshot_DEBUG = function() {
            return new Map(this.$5)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LaminarSelector", ["invariant", "AdsSelectorProfilerUtils", "LRUKeyedExpiringCache", "distinctArray", "flattenArray", "shallowEqual"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = 1e3;

    function j(a) {
        var b = new Set();
        for (var c in a) {
            var d = [].concat(a[c].getProviders != null ? a[c].getProviders() : [], a[c].providers != null ? a[c].providers : []);
            for (var d = d, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= d.length) break;
                    g = d[f++]
                } else {
                    f = d.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                b.add(g)
            }
        }
        return Array.from(b)
    }

    function k(a, b) {
        var c = new Set();
        for (var d in a)
            for (var e = a[d].toFluxSelector().getStores(), f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var h;
                if (f) {
                    if (g >= e.length) break;
                    h = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    h = g.value
                }
                h = h;
                c.add(h)
            }
        b != null && b.forEach(function(a) {
            return c.add(a)
        });
        return Array.from(c)
    }
    var l = function() {
        function a() {
            this.$1 = {
                hasCached: !1,
                result: null,
                inputs: null
            }
        }
        var b = a.prototype;
        b.setCache = function(a, b) {
            this.$1 = {
                hasCached: !0,
                inputs: a,
                result: b
            }
        };
        b.areInputsEqual = function(a) {
            return this.$1.hasCached && c("shallowEqual")(this.$1.inputs, a)
        };
        b.getCachedResultEnforced = function() {
            this.$1.hasCached || h(0, 14851);
            return this.$1.result
        };
        return a
    }();

    function m(a, b) {
        var c = {};
        Object.keys(a).forEach(function(d) {
            c[d] = b(d, a[d])
        });
        return c
    }

    function n(a) {
        a = m(a, function(a, b) {
            return b()
        });
        return a
    }

    function a(a, b, e, f, g) {
        e === void 0 && (e = n);
        f === void 0 && (f = "unnamedLaminarSelector");
        g === void 0 && (g = void 0);
        var h = (g = g) != null ? g : new(c("LRUKeyedExpiringCache"))(function(a) {
            return a
        }, i);
        g = function(c, d) {
            var f = h.get(c);
            if (f != null) return f();
            var g = new l();
            f = function() {
                var f = e(a, c);
                if (g.areInputsEqual(f)) return g.getCachedResultEnforced();
                d.cacheHit = !1;
                var h = b(f, c);
                g.setCache(f, h);
                return h
            };
            h.set(c, f);
            return f()
        };
        var m = d("AdsSelectorProfilerUtils").instrumentLaminarSelector(g, f),
            o = j(a),
            p = k(a, e.attachedStoreDependencies),
            q = function(a) {
                return m(a)
            };
        q.getStores = function() {
            return p
        };
        q.isGetStoresStatic = !0;
        q.isGetStoresPure = !0;
        q.rawSelectFn = function(a) {
            return m(a)
        };
        return Object.assign(m.bind(void 0), {
            getProviders: function() {
                return o
            },
            toFluxSelector: function() {
                return q
            }
        })
    }

    function b(a, b) {
        var d = function(c, d) {
                var e = {};
                Object.keys(a).forEach(function(b) {
                    e[b] = a[b]()
                });
                return b(e, c, d)
            },
            e = c("distinctArray")(c("flattenArray")(Object.keys(a).map(function(b) {
                return a[b].getStores()
            })));
        d.attachedStoreDependencies = e;
        return d
    }

    function e(a, b) {
        var d = function(c, d) {
                return b(a, c, d)
            },
            e = c("distinctArray")(Object.keys(a).map(function(b) {
                return a[b]
            }));
        d.attachedStoreDependencies = e;
        return d
    }
    g.defaultPrepareFn = n;
    g.create = a;
    g.prepareWithFluxSelectors = b;
    g.prepareWithFluxStores = e
}), 98);
__d("LaminarTriggerReducer", ["AdsDataAtom"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        var e = function(b, c) {
                b = d.select(b);
                return a.reduce(b, c)
            },
            f = function(a) {
                return e(c("AdsDataAtom").getAlteredState(), a)
            };
        return {
            provider: d.provider,
            reduce: f,
            triggerReducer: b
        }
    }
    g.create = a
}), 98);
__d("Laminar", ["LaminarAction", "LaminarExperimentalSelector", "LaminarLogger", "LaminarProvider", "LaminarReactHooks", "LaminarReducer", "LaminarReducerWithFluxSelectors", "LaminarRefetchProvider", "LaminarSelector", "LaminarTriggerReducer"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g.__createAction = d("LaminarAction").create, g.__createExperimentalSelector = d("LaminarExperimentalSelector").create, g.__createLogger = d("LaminarLogger").create, g.__createProvider = d("LaminarProvider").create, g.__createReducer = d("LaminarReducer").create, g.__createLegacyReducer = d("LaminarReducer").createLegacy, g.__createRefetchProvider = d("LaminarRefetchProvider").create, g.__createSelector = d("LaminarSelector").create, g.__createTriggerReducer = d("LaminarTriggerReducer").create, g.__defaultPrepareFn = d("LaminarSelector").defaultPrepareFn, g.useProvider = d("LaminarReactHooks").useProvider, g.laminarContainer = d("LaminarReactHooks").laminarContainer, g.withFluxSelectors = c("LaminarReducerWithFluxSelectors"), g.prepareWithFluxSelectors = d("LaminarSelector").prepareWithFluxSelectors, g.prepareWithFluxStores = d("LaminarSelector").prepareWithFluxStores
}), 98);
__d("LaminarLogger", ["AdsDataAtom", "Laminar"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f) {
        var g = d("Laminar").__createExperimentalSelector(e, function(a) {
                return a
            }),
            h = function(a, c) {
                a = g.select(a);
                b.log(c, a)
            };
        e = function(a) {
            return h(c("AdsDataAtom").getAlteredState(), a)
        };
        return Object.assign(e, {
            id: a,
            log: h,
            registries: f == null ? [] : f
        })
    }
    g.create = a
}), 98);
__d("LaminarProvider", ["invariant", "AdsDataAtom", "AdsDataPluginsInternalUtils", "FluxReduceStore", "Laminar", "compactArray"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function i(a, b) {
        var d = function(e) {
            babelHelpers.inheritsLoose(d, e);

            function d() {
                var a, c;
                for (var d = arguments.length, f = new Array(d), g = 0; g < d; g++) f[g] = arguments[g];
                return (a = c = e.call.apply(e, [this].concat(f)) || this, c.__moduleID = b, a) || babelHelpers.assertThisInitialized(c)
            }
            var f = d.prototype;
            f.addListener = function(b) {
                return c("AdsDataAtom").addListener(a.provider, b)
            };
            f.__registerDispatcherCallback = function() {
                return
            };
            f.getInitialState = function() {
                return a.getInitialState()
            };
            f.reduce = function() {
                h(0, 5462)
            };
            f.hasChanged = function() {
                return c("AdsDataAtom").hasChangedInDispatchCycle(a.provider)
            };
            f.getState = function() {
                return a.select(c("AdsDataAtom").getAlteredState())
            };
            f.getDispatchToken = function() {
                return a.provider
            };
            f.__setState = function(a) {
                c("AdsDataAtom").__laminarAlteredState[b] = a
            };
            return d
        }(c("FluxReduceStore"));
        d.__moduleID = f.id;
        return new d(c("AdsDataAtom"))
    }

    function j(a, b, c, d) {
        var e = a.fetch,
            f = a.compare,
            g = a.setInitialState,
            h = !1;
        return function(a) {
            if (!h) {
                var i = b();
                g(i);
                h = !0;
                if (f != null) {
                    f(d, i, e());
                    return i
                } else return e()
            }
            i = e();
            a = c(a);
            if (f != null) {
                f(d, a, i);
                return a
            } else return i
        }
    }

    function k(a, b, c, d) {
        var e = null,
            f = null;
        a != null && (e = j(a, b, c, d), f = {
            fetch: a.fetch
        });
        return {
            unboundSelectorRelay: e,
            relay: f
        }
    }

    function a(a, b, e, f) {
        f === void 0 && (f = []);
        var g = a.initialState,
            j = a.legacyFluxReduce,
            l = a.relayClientSchema_EXPERIMENTAL,
            m = null,
            n = function(a) {
                m != null || h(0, 5463), m.dispatch({
                    reducer: a
                })
            },
            o = d("AdsDataPluginsInternalUtils").memoize(function() {
                return typeof g === "function" ? g(n) : g
            }),
            p = function(a) {
                if (!a) throw new Error("'state' must be present. If 'state' is 'undefined' make sure\n       you passed the altered state to the selector function. Example:\n         AdsExampleSelector(\n           AdsDataAtom.getAlteredState(),\n         );");
                return Object.prototype.hasOwnProperty.call(a, b) ? a[b] : o()
            };
        l = k(l, o, p, b);
        var q = l.unboundSelectorRelay;
        l = l.relay;
        var r = (q = q) != null ? q : p,
            s = function() {
                return r(c("AdsDataAtom").getAlteredState())
            },
            t = d("AdsDataPluginsInternalUtils").memoize(function() {
                return i(s, b)
            });
        q = d("AdsDataPluginsInternalUtils").memoize(function() {
            return Object.assign(s, {
                getStores: d("AdsDataPluginsInternalUtils").memoize(function() {
                    return [t()]
                }),
                isGetStoresStatic: !0,
                isGetStoresPure: !0,
                rawSelectFn: s
            })
        });
        p = e != null ? c("compactArray")(e()) : [];
        var u = Object.assign(s, {
            providers: [b],
            provider: b,
            select: r,
            getInitialState: o,
            shouldLegacyFluxReduceOnly: !!a.shouldLegacyFluxReduceOnly,
            toFluxStore: t,
            toFluxSelector: q,
            triggerReducers: p,
            registries: f == null ? [] : f,
            relay: l
        });
        m = d("Laminar").__createAction(function() {
            return [d("Laminar").__createReducer({
                reduce: function(a, b) {
                    return b.reducer(a)
                }
            }, u, {}, b + "SetStateReducer")]
        }, function() {
            return []
        }, b + "SetStateAction");
        j && c("AdsDataAtom").laminarRegisterLegacyFluxReducer(d("Laminar").__createLegacyReducer({
            reduce: j
        }, u, {}, b + "LegacyFluxReducer"));
        return u
    }
    g.create = a
}), 98);
__d("LaminarReducer", ["AdsDataAtom", "Laminar"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, e, f, g) {
        var h = d("Laminar").__createExperimentalSelector(f, function(a) {
                return a
            }),
            i = function(a, c) {
                var d, f = h.select(a);
                a = e.select(a);
                c = b.reduce(a, c, f);
                f = b.relayReduce_EXPERIMENTAL;
                d = (d = e.relay) == null ? void 0 : d.fetch;
                if (d != null && f != null && a !== c) {
                    f.update(c);
                    a = d();
                    if (f.compare != null) {
                        f.compare(c, a);
                        return c
                    } else return a
                }
                return c
            };
        f = function(a) {
            return i(c("AdsDataAtom").getAlteredState(), a)
        };
        f.isDisabled = !a && e.shouldLegacyFluxReduceOnly;
        f.provider = e.provider;
        f.providerInitialState = function() {
            return e.getInitialState()
        };
        f.reduce = i;
        f.registries = e.registries;
        f.triggerReducers = e.triggerReducers;
        f.reducerName = g;
        return f
    }

    function a(a, b, c, d) {
        return h(!1, a, b, c, d)
    }

    function b(a, b, c, d) {
        return h(!0, a, b, c, d)
    }
    g.create = a;
    g.createLegacy = b
}), 98);
__d("LaminarRefetchProvider", ["invariant", "AdsDataAtom", "Laminar", "LaminarProvider"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, e, f, g) {
        g === void 0 && (g = []);
        var i = d("LaminarProvider").create(a, e, f, g),
            j = null,
            k = function(a) {
                j != null || h(0, 5463), j.dispatch({
                    reducer: a
                })
            };
        a = function() {
            return i.select(c("AdsDataAtom").getAlteredState())
        };
        f = Object.assign(a, babelHelpers["extends"]({}, i, {
            refetch: function(a) {
                return b(k, a)
            }
        }));
        j = d("Laminar").__createAction(function() {
            return [d("Laminar").__createReducer({
                reduce: function(a, b) {
                    return b.reducer(a)
                }
            }, i, {}, e + "QuerySetStateReducer")]
        }, function() {
            return []
        }, e + "QuerySetStateAction");
        return f
    }
    g.create = a
}), 98);
__d("AdsAccountAddCapabilitiesDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.ADD_CAPABILITIES");
    e.exports = a
}), null);
__d("AdsAccountAddCapabilitiesDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.ADD_CAPABILITIES"
    }
}), null);
__d("AdsAccountAttributionSpecLoadErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.ATTRIBUTION_SPEC_LOAD_ERROR");
    e.exports = a
}), null);
__d("AdsAccountAttributionSpecLoadSuccessDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.ATTRIBUTION_SPEC_LOAD_SUCCESS");
    e.exports = a
}), null);
__d("AdsAccountAttributionSpecLoadSuccessDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.ATTRIBUTION_SPEC_LOAD_SUCCESS"
    }
}), null);
__d("AdsAccountAttributionSpecUpdateErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.ATTRIBUTION_SPEC_UPDATE_ERROR");
    e.exports = a
}), null);
__d("AdsAccountAttributionSpecUpdateStartDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.ATTRIBUTION_SPEC_UPDATE_START"
    }
}), null);
__d("AdsAccountAttributionSpecUpdateSuccessDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.ATTRIBUTION_SPEC_UPDATE_SUCCESS");
    e.exports = a
}), null);
__d("AdsAccountAttributionSpecUpdateSuccessDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.ATTRIBUTION_SPEC_UPDATE_SUCCESS"
    }
}), null);
__d("ifRequired_FOR_LAMINAR_CODEGEN", ["ifRequired"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("ifRequired")
}), 98);
__d("AdsAccountBatchLoadErrorDataAction", ["Laminar", "ifRequired_FOR_LAMINAR_CODEGEN"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return [b("ifRequired_FOR_LAMINAR_CODEGEN")("FameLoadAdAccountsLoggerPlugins", function(a) {
            return b("Laminar").__createLogger("FameLoadAdAccountsLoggerPlugins.FameLoadAdAccountsFailLoggerPlugin", a.FameLoadAdAccountsFailLoggerPlugin, {}, ["AdsFAMERegistry"])
        })]
    }, "ACCOUNT.BATCH_LOAD_ERROR");
    e.exports = a
}), null);
__d("AdsAccountBatchLoadErrorDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.BATCH_LOAD_ERROR"
    }
}), null);
__d("AdsAdditionalOptionsConsts", ["immutable", "keyMirror"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        campaignGroupBidStrategy: null,
        campaignGroupBuyingType: null,
        campaignGroupDeliveryType: null,
        campaignGroupObjective: null,
        campaignGroupScheduling: null,
        campaignGroupSpendLimits: null,
        campaignGroupAppInstallCampaignType: null
    });
    b = c("keyMirror")({
        age: null,
        bidStrategy: null,
        billingEvent: null,
        blockList: null,
        brandSafety: null,
        brandSafetyBlockLists: null,
        brandSafetyContentFilter: null,
        brandSafetyContentTypeExclusion: null,
        brandSafetyFeedInventoryFilter: null,
        brandSafetyNegativeKeywordLists: null,
        connections: null,
        conversionWindow: null,
        deliveryType: null,
        detailedTargeting: null,
        deviceAndOS: null,
        deviceType: null,
        exclusions: null,
        experimentalDetailedTargeting: null,
        experimentalLanguages: null,
        frequencyControlInterval: null,
        gender: null,
        installState: null,
        isConsentedToInspirationGallery: null,
        languages: null,
        locations: null,
        optimizationGoal: null,
        scheduling: null,
        skippableAdsExclusion: null,
        spendControls: null
    });
    d = {
        CAMPAIGN_GROUP: a,
        CAMPAIGN: b
    };
    e = c("keyMirror")({
        F0: null,
        F1: null,
        F2: null
    });
    f = c("keyMirror")({
        alwaysVisibie: null,
        automaticPlacement: null,
        budget: null,
        budgetAndDelivery: null,
        campaignGroupBudget: null,
        conversion: null,
        delivery: null,
        invisible: null,
        peCampaignGroupDetails: null,
        placement: null,
        targeting: null
    });
    c = c("immutable").Map(babelHelpers["extends"]({}, a, b)).map(function(a) {
        return {
            isEditable: !1,
            isSticky: !1,
            hasEdited: !1
        }
    });
    g.AdditionalOptions = d;
    g.AdditionalOptionsFrictionLevels = e;
    g.AdditionalOptionsSections = f;
    g.AdditionalOptionsDataProviderInitialState = c
}), 98);
__d("AdsAdditionalOptionsDataProviderPlugin", ["AdsAdditionalOptionsConsts"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        initialState: d("AdsAdditionalOptionsConsts").AdditionalOptionsDataProviderInitialState
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsAdditionalOptionsDataProvider", ["AdsAdditionalOptionsDataProviderPlugin", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("Laminar").__createProvider(b("AdsAdditionalOptionsDataProviderPlugin"), "AdsAdditionalOptionsDataProviderPlugin")
}), null);
__d("AdsApplicationIDs", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        ADS_AD_BUILDER: "4613280245667390",
        ADS_AND_PAGES_MANAGER__DEPRECATED: "6802152230",
        ADS_CAMPAIGN_MANAGER: "624541620938530",
        ADS_CAMPAIGN_PLANNER: "1902171089916558",
        ADS_CREATIVE_STUDIO: "814871115284314",
        ADS_CREATOR: "209787012415271",
        ADS_EVENTS_MANAGER: "2094176354154603",
        ADS_MANAGER: "484843564880080",
        ADS_PAYMENT: "123097351040126",
        ADS_POWER_EDITOR: "119211728144504",
        BOOSTED_POST: "205000946197077",
        BUSINESS_ACCOUNTS: "436761779744620",
        FBADDINS_EXCEL: "1103203559767608",
        LIFT_STUDY_CREATION: "367378623468359",
        MOBILE_ADS_MANAGER_FOR_ANDROID: "438142079694454",
        MOBILE_ADS_MANAGER_FOR_IOS: "1479723375646806",
        PAGE_ADMIN_APP_FOR_ANDROID: "121876164619130",
        PAGE_ADMIN_APP_FOR_IOS: "165907476854626",
        COMMERCE_MANAGER: "515496645328243"
    })
}), null);
__d("AdsApplicationUtils", ["AdsApplicationIDs", "ApiClient", "URI", "WebApiApplication"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").ADS_POWER_EDITOR
    }

    function a() {
        return h() && i()
    }

    function i() {
        var a = new(c("URI"))(window.location.href);
        a = a.getPath();
        return a.indexOf("adsmanager/reporting") > -1 || a.indexOf("adsreporting") > -1
    }

    function b() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").COMMERCE_MANAGER
    }

    function e() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").ADS_CAMPAIGN_MANAGER
    }

    function f() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").ADS_CREATIVE_STUDIO
    }

    function j() {
        var a = d("WebApiApplication").getClientID();
        return a === "1520381111604620"
    }

    function k() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").FBADDINS_EXCEL
    }

    function l() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").BOOSTED_POST
    }

    function m() {
        var a = c("ApiClient").getClientID();
        return a === c("AdsApplicationIDs").ADS_AD_BUILDER
    }

    function n() {
        var a = d("WebApiApplication").getClientID();
        return a === c("AdsApplicationIDs").LIFT_STUDY_CREATION
    }

    function o() {
        var a = c("ApiClient").getClientID();
        return a === 436761779744620
    }
    g.isPowerEditor = h;
    g.isAdsReporting = a;
    g.isAdsReportingPath = i;
    g.isCommerceManager = b;
    g.isCampaignManager = e;
    g.isCreativeStudio = f;
    g.isDynamicInstantAds = j;
    g.isFAME = k;
    g.isBoostedPost = l;
    g.isAdBuilder = m;
    g.isLiftStudyCreation = n;
    g.isFBS = o
}), 98);
__d("AdsAdditionalOptionsStateReducerUtils", ["invariant", "AdsInterfacesLogger"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        a = a.data.changedParamKeys;
        return !!(a.selected_ad_ids || a.selected_adset_ids || a.selected_campaign_ids)
    }

    function b(a) {
        return a.map(function(a) {
            return {
                isEditable: a.isSticky,
                isSticky: a.isSticky,
                hasEdited: !1
            }
        })
    }

    function d(a, b, c) {
        var d = a.get(b);
        d != null || h(0, 14128, b);
        return a.set(b, {
            isEditable: c,
            isSticky: d.isSticky,
            hasEdited: d.hasEdited
        })
    }

    function e(a, b, c) {
        var d = a.get(b);
        d != null || h(0, 14128, b);
        return a.set(b, {
            isEditable: d.isEditable,
            isSticky: d.isSticky,
            hasEdited: c
        })
    }

    function f(a, b, d) {
        return a.withMutations(function(a) {
            b.forEach(function(b) {
                var e = a.get(b);
                if (e != null) {
                    if (d === "increment") {
                        var f = e.isSticky === !1 ? "focus_framework_sticky_field_set" : "focus_framework_sticky_field_refreshed";
                        c("AdsInterfacesLogger").log({
                            data: {
                                field_names: [b]
                            },
                            eventName: f
                        })
                    }
                    a.set(b, {
                        isEditable: !0,
                        isSticky: !0,
                        hasEdited: e.hasEdited
                    })
                }
            });
            return a
        })
    }
    g.hasAdObjectChanged = a;
    g.resetDefaultState = b;
    g.setFieldValue = d;
    g.setHasEdited = e;
    g.setSticky = f
}), 98);
__d("AdsAdditionalOptionsSetStickyReducerPlugin", ["AdsAdditionalOptionsStateReducerUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            return d("AdsAdditionalOptionsStateReducerUtils").setSticky(a, b.fields, b.source)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsFocusFrameworkStickyFieldsLoadedLoggerPlugin", ["AdsInterfacesLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        log: function(a) {
            var b;
            if (a.source !== "load") return;
            a = (b = {}, b.field_names = a.fields, b);
            c("AdsInterfacesLogger").log({
                eventName: "focus_framework_sticky_fields_loaded",
                data: a
            }, c("AdsInterfacesLogger").LOG_TYPE_PRIMARY_APP)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsAdditionalOptionsSetStickyAction", ["AdsAdditionalOptionsDataProvider", "AdsAdditionalOptionsSetStickyReducerPlugin", "AdsFocusFrameworkStickyFieldsLoadedLoggerPlugin", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsAdditionalOptionsSetStickyReducerPlugin"), b("AdsAdditionalOptionsDataProvider"), {}, "")]
    }, function() {
        return [b("Laminar").__createLogger("AdsFocusFrameworkStickyFieldsLoadedLoggerPlugin", b("AdsFocusFrameworkStickyFieldsLoadedLoggerPlugin"), {})]
    }, "AdsAdditionalOptionsSetStickyActionPlugin");
    e.exports = a
}), null);
__d("XAdsFocusFrameworkFieldUsageController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ads/focus_framework/field_usage/", {
        ad_account_id: {
            type: "FBID",
            required: !0
        },
        field_key: {
            type: "String",
            required: !0
        }
    })
}), null);
__d("XAdsFocusFrameworkStickyFieldsController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ads/focus_framework/sticky_fields/", {
        ad_account_id: {
            type: "FBID",
            required: !0
        }
    })
}), null);
__d("AdsFocusFrameworkStickinessDataManager", ["AdsAdditionalOptionsSetStickyAction", "AdsInterfacesLogger", "AsyncTypedRequest", "XAdsFocusFrameworkFieldUsageController", "XAdsFocusFrameworkStickyFieldsController", "promiseDone"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {}
        var b = a.prototype;
        b.getStickyFields = function(a) {
            a = c("XAdsFocusFrameworkStickyFieldsController").getURIBuilder().setFBID("ad_account_id", a).getURI();
            c("promiseDone")(new(c("AsyncTypedRequest"))().setURI(a).exec().then(function(a) {
                a.payload.sticky_fields && c("AdsAdditionalOptionsSetStickyAction").dispatch({
                    fields: a.payload.sticky_fields,
                    source: "load"
                }, {
                    line: "36",
                    module: "AdsFocusFrameworkStickinessDataManager.js"
                })
            }, function(a) {
                c("AdsInterfacesLogger").log({
                    data: {
                        message: a.errorDescription
                    },
                    eventName: "focus_framework_sticky_field_fetch_error"
                })
            }))
        };
        b.incrementCounter = function(a, b) {
            a = c("XAdsFocusFrameworkFieldUsageController").getURIBuilder().setFBID("ad_account_id", a).setString("field_key", b).getURI();
            c("promiseDone")(new(c("AsyncTypedRequest"))().setURI(a).exec().then(function(a) {
                a.payload.is_sticky && c("AdsAdditionalOptionsSetStickyAction").dispatch({
                    fields: [b],
                    source: "increment"
                }, {
                    line: "67",
                    module: "AdsFocusFrameworkStickinessDataManager.js"
                })
            }, function(a) {
                c("AdsInterfacesLogger").log({
                    data: {
                        message: a.errorDescription
                    },
                    eventName: "focus_framework_sticky_counter_error"
                })
            }))
        };
        return a
    }();
    b = new a();
    g["default"] = b
}), 98);
__d("AdsAdditionalOptionsGetStickyFieldsReducerPlugin", ["AdsAdditionalOptionsConsts", "AdsApplicationUtils", "AdsFocusFrameworkStickinessDataManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            b.accountID != null && d("AdsApplicationUtils").isPowerEditor() && c("AdsFocusFrameworkStickinessDataManager").getStickyFields(b.accountID);
            return d("AdsAdditionalOptionsConsts").AdditionalOptionsDataProviderInitialState
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsAccountBatchLoadedDataAction", ["AdsAdditionalOptionsDataProvider", "AdsAdditionalOptionsGetStickyFieldsReducerPlugin", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsAdditionalOptionsGetStickyFieldsReducerPlugin"), b("AdsAdditionalOptionsDataProvider"), {}, "")]
    }, function() {
        return []
    }, "ACCOUNT.BATCH_LOADED");
    e.exports = a
}), null);
__d("AdsAccountBatchLoadedDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.BATCH_LOADED"
    }
}), null);
__d("AdsAccountChangeAccountCountryDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.CHANGE_ACCOUNT_COUNTRY"
    }
}), null);
__d("AdsAccountChangeAccountCurrencyDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.CHANGE_ACCOUNT_CURRENCY"
    }
}), null);
__d("AdsAccountChangeAccountNameDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.CHANGE_ACCOUNT_NAME"
    }
}), null);
__d("AdsAccountChangeAccountTimezoneIdDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.CHANGE_ACCOUNT_TIMEZONE_ID"
    }
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecLoadErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_LOAD_ERROR");
    e.exports = a
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_LOAD_SUCCESS");
    e.exports = a
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_LOAD_SUCCESS"
    }
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecUpdateErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_UPDATE_ERROR");
    e.exports = a
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecUpdateStartDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_UPDATE_START"
    }
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_UPDATE_SUCCESS");
    e.exports = a
}), null);
__d("AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.DEFAULT_UNIFIED_ATTRIBUTION_SPEC_UPDATE_SUCCESS"
    }
}), null);
__d("AdsAccountGKsErrorReducerPlugin", ["LoadObject"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            return a.set(b.accountID, c("LoadObject").withError(b.error))
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsAccountGKsErrorAction", ["AdsAccountGKsErrorReducerPlugin", "AdsAccountGKsProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsAccountGKsErrorReducerPlugin"), b("AdsAccountGKsProvider"), {}, "")]
    }, function() {
        return []
    }, "AdsAccountGKsErrorActionPlugin");
    e.exports = a
}), null);
__d("AdsAccountGKsLoadedReducerPlugin", ["LoadObject"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            return a.set(b.accountID, c("LoadObject").withValue(b.data))
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsAccountGKsLoadedAction", ["AdsAccountGKsLoadedReducerPlugin", "AdsAccountGKsProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsAccountGKsLoadedReducerPlugin"), b("AdsAccountGKsProvider"), {}, "")]
    }, function() {
        return []
    }, "AdsAccountGKsLoadedActionPlugin");
    e.exports = a
}), null);
__d("AdsAccountGKsProvider", ["AdsAccountGKsProviderPlugin", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("Laminar").__createProvider(b("AdsAccountGKsProviderPlugin"), "AdsAccountGKsProviderPlugin")
}), null);
__d("AdsAccountAdsReportingDataLoaderFields", [], (function(a, b, c, d, e, f) {
    a = {
        fields: ["account_id", "business", "business_country_code", "capabilities", "created_time", "currency", "name", "timezone_id", "timezone_name", "timezone_offset_hours_utc"]
    };
    f["default"] = a
}), 66);
__d("FBTraceIDsForFailedGraphAPIRequests", [], (function(a, b, c, d, e, f) {
    var g = [];

    function a(a) {
        g.push(a)
    }
    f.errorFBTraces = g;
    f.insert = a
}), 66);
__d("GraphAPIPerfLogging", ["ApiClient", "ResourceTimingsStore", "ResourceTypes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();

    function a() {
        c("ApiClient").subscribe("request.prepare", i), c("ApiClient").subscribe("request.complete", j), c("ApiClient").subscribe("request.error", j)
    }

    function i(a, b, e) {
        a = d("ResourceTimingsStore").getUID(c("ResourceTypes").XHR, a);
        h.set(e, a);
        d("ResourceTimingsStore").annotate(c("ResourceTypes").XHR, a).addStringAnnotation("request_name", b._reqName).addStringAnnotation("request_source", b._reqSrc).addStringAnnotation("request_method", b.method);
        d("ResourceTimingsStore").measureRequestSent(c("ResourceTypes").XHR, a)
    }

    function j(a, b, e, f, g, i) {
        a = h.get(i);
        a && (h["delete"](i), d("ResourceTimingsStore").measureResponseReceived(c("ResourceTypes").XHR, a), d("ResourceTimingsStore").annotate(c("ResourceTypes").XHR, a).addStringAnnotation("fbtrace_id", f.__fb_trace_id__ || "").addStringAnnotation("www_request_id", f.__fb_trace_id__ || ""))
    }
    g.register = a
}), 98);
__d("GraphAPIPreloadingOnlyMode", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = window.location.search.indexOf("preloadingonly") > -1;

    function a() {
        g = !1
    }

    function b() {
        g = !0
    }

    function c() {
        return g
    }
    f.disable = a;
    f.enable = b;
    f.isEnabled = c
}), 66);
__d("RequestProcessorBase", ["abstractMethod"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            this.runRequest = a
        }
        var b = a.prototype;
        b.scheduleRequest = function(a, b) {
            return c("abstractMethod")("RequestProcessorBase", "scheduleRequest")
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("RequestProcessorDefault", ["RequestProcessorBase"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.scheduleRequest = function(a, b) {
            this.runRequest(a, b)
        };
        return b
    }(c("RequestProcessorBase"));
    g["default"] = a
}), 98);
__d("getErrorFromAPIResponse", ["errorCode"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = {
        code: 1,
        error_subcode: 1357045,
        message: "unknown error (empty response)",
        type: "http",
        status: 0
    };

    function a(a) {
        var b;
        if (a == null || (a == null ? void 0 : (b = a.error) == null ? void 0 : b.error_subcode) === 1357045) return window.navigator.onLine === !1 ? {
            code: 1,
            error_subcode: 1357051,
            message: "unknown error (empty response), likely due to an unreliable network connection",
            type: "http",
            status: 0
        } : i;
        if (a.error) {
            return babelHelpers["extends"]({}, a.error, {
                fbtrace_id: (b = (b = a.error.fbtrace_id) != null ? b : a.__www_request_id__) != null ? b : a.__fbtrace_id__
            })
        }
        if (a.error_code && a.error_msg) {
            return {
                message: a.error_msg,
                code: a.error_code,
                type: a.error_type,
                error_subcode: a.error_subcode,
                fbtrace_id: (b = a.__www_request_id__) != null ? b : a.__fbtrace_id__
            }
        }
        return void 0
    }
    g["default"] = a
}), 98);
__d("AdsPreloaderMismatchesConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = ["AdsDynamicAdObjectDataManager", "AdsPEAdObjectTableDataManager", "AdsDraftDataManager._load", "AdsDraftDataManager.getOrCreateCurrentDraft", "AdsDraftFragmentListDataManager", "AdsPEFilterLiveDataManager._getDataForLevels", "AdsPETableDataFetchingPolicy.fetchBody.stats>fetchSync", "AdsInsightsColumnPresetDataLoader"];
    b = "preloader_has_no_queries_and_is_likely_disabled";
    c = {
        AdsDraftDataManagerPreloader: [{
            requestName: "objectByName:addraft_ID",
            stringArrayAnnotations: {
                fields: ["path"]
            }
        }]
    };
    f.IMPORTANT_PRELOADERS_REQUEST_SOURCE = a;
    f.NO_QUERIES_MSG = b;
    f.COMMON_KNOWN_MISMATCHES_TO_IGNORE = c
}), 66);
__d("preloadedGraphAPIUtils", ["areEqual", "isTruthy", "justknobx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, d, e) {
        d === void 0 && (d = "fields");
        e === void 0 && (e = {});
        var f = [];

        function g(a, b, c) {
            f.push({
                field: a,
                clientValue: typeof b === "string" ? b : JSON.stringify((a = b) != null ? a : null),
                serverValue: typeof c === "string" ? c : JSON.stringify((b = c) != null ? b : null)
            })
        }
        if (c("areEqual")(a, b)) return f;
        a == null || b == null ? g("queryDataParam", a, b) : (Object.keys(b).forEach(function(c) {
            !Object.prototype.hasOwnProperty.call(a, c) && b[c] != null && g(c, null, b[c])
        }), Object.keys(a).forEach(function(f) {
            var h;
            h = f === d ? n : (h = e[f]) != null ? h : c("areEqual");
            h(a[f], b[f]) || g(f, a[f], b[f])
        }));
        return f
    }

    function a(a, b, c, d) {
        c === void 0 && (c = "fields");
        return h(a, b, c, d).length === 0
    }

    function i(a, b) {
        if (c("areEqual")(a, b) || !a) return [];
        if (!b) return a instanceof Array ? a : [a];
        if (typeof a === "string" && a !== b) return [a];
        if (Array.isArray(a))
            if (c("justknobx")._("206")) {
                var d = Array.isArray(b) ? b : [b];
                return Array.from(k(a, d))
            } else return j(a, b);
        return []
    }

    function j(a, b) {
        var c = new Set(b);
        b = new Set(a.filter(function(a) {
            return !c.has(a)
        }));
        return Array.from(b)
    }

    function k(a, b) {
        a = l(a);
        var c = l(b),
            d = new Set(),
            e = function() {
                if (g) {
                    if (h >= f.length) return "break";
                    b = f[h++]
                } else {
                    h = f.next();
                    if (h.done) return "break";
                    b = h.value
                }
                var a = b,
                    e = a[0];
                i = a[1];
                a = i.subfields;
                var j = i.rawField,
                    k = c.get(e);
                if (k == null) d.add(j);
                else {
                    j = Array.from(a).filter(function(a) {
                        return !k.subfields.has(a)
                    });
                    j.length > 0 && d.add(e + "{" + j.join(",") + "}")
                }
            };
        for (var f = a, g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var i;
            a = e();
            if (a === "break") break
        }
        return d
    }

    function l(a) {
        var b = new Map();
        a.forEach(function(a) {
            var c = m(a),
                d = c.field;
            c = c.subfields;
            b.set(d, {
                subfields: c,
                rawField: a
            })
        });
        return b
    }

    function m(a) {
        var b = a.match(/(\w+)({[\w,]+})?/);
        b = (c("isTruthy")(b) ? b : []).filter(function(b) {
            return b != a
        });
        if (b.length === 0 || b.includes(void 0)) return {
            field: a,
            subfields: new Set()
        };
        var d = b[0];
        b = b[1];
        return {
            field: d,
            subfields: new Set(b.replace(/{|}/g, "").split(","))
        }
    }

    function n(a, b) {
        return i(a, b).length === 0
    }
    g.getSubsetDeltas = h;
    g.isSubsetOf = a;
    g.getFieldSubsetDeltas = i;
    g.isFieldsSubsetOf = n
}), 98);
__d("AdsPreloaderUtils", ["AdsPreloaderMismatchesConstants", "compareString", "filterObject", "preloadedGraphAPIUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = ["locale", "am_call_tags", "xref", "qpl_active_flow_ids", "qpl_active_flow_instance_ids"];

    function i(a) {
        a && (Array.isArray(a.filtering) && (a.filtering.sort(function(a, b) {
            return c("compareString")(a.field, b.field)
        }), a.filtering.forEach(function(a) {
            Array.isArray(a.value) && a.value.sort()
        })), Array.isArray(a.action_attribution_windows) && a.action_attribution_windows.sort());
        return a
    }

    function j(a) {
        a = a.preloadInfo;
        return a && a.fieldsParam ? a.fieldsParam : "fields"
    }

    function k(a, b, c) {
        var e = {
            fields: [],
            client_values: [],
            server_values: [],
            missing_server_fields: []
        };

        function f(a) {
            return typeof a === "string" ? a : JSON.stringify((a = a) != null ? a : null)
        }

        function g(a, b, c) {
            e.fields.push(a), e.client_values.push(f(b)), e.server_values.push(f(c))
        }
        var h = n(a);
        a = j(a);
        var k = l(c);
        h.path !== k.path && g("path", h.path, k.path);
        h.method !== k.method && g("method", h.method, k.method);
        b[c].error && g("error", null, "non-null");
        b = d("preloadedGraphAPIUtils").getSubsetDeltas(i(h.params), i(k.params), a);
        for (var c = b, b = Array.isArray(c), m = 0, c = b ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var o;
            if (b) {
                if (m >= c.length) break;
                o = c[m++]
            } else {
                m = c.next();
                if (m.done) break;
                o = m.value
            }
            o = o;
            if (o.field === a && h.params != null && k.params != null) {
                var p = d("preloadedGraphAPIUtils").getFieldSubsetDeltas(h.params[a], k.params[a]);
                e.missing_server_fields = p
            } else g(o.field, o.clientValue, o.serverValue)
        }
        o = (p = h.ids) != null ? p : [];
        var q = (m = k.ids) != null ? m : [];
        o.every(function(a) {
            return q.indexOf(a) !== -1
        }) || g("ids", o, q);
        return e
    }

    function a(a) {
        var b = m(a.params),
            c = Object.keys(b);
        for (var d = 0; d < c.length; d++) {
            var e = c[d];
            b[e] == null && delete b[e]
        }
        return a.method + a.path + JSON.stringify(b)
    }

    function l(a) {
        var b = a.indexOf("/"),
            c = a.indexOf("{"),
            d = a.substring(0, b);
        b = a.substring(b, c);
        a = a.substring(c);
        c = JSON.parse(a);
        a = c.ids;
        c = babelHelpers.objectWithoutPropertiesLoose(c, ["ids"]);
        return o({
            ids: a,
            params: c,
            path: b,
            method: d
        })
    }

    function m(a) {
        return a == null ? {} : c("filterObject")(a, function(a, b) {
            return !h.includes(b) && !b.startsWith("_")
        })
    }

    function n(a) {
        var b = a.path,
            c = a.method;
        a = m(a.params);
        var d = a.ids;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["ids"]);
        return o({
            ids: d,
            params: a,
            path: b,
            method: c
        })
    }

    function o(a) {
        var b = a.path,
            c = a.ids,
            d = a.params;
        a = a.method;
        var e = b.replace(/(\/v\d\.\d\/)\d*\/?$/, "$1"),
            f = !1;
        if (c == null && e !== b) {
            f = !0;
            var g = b.replace(/\/v\d\.\d\/(\d*)\/?$/, "$1");
            c = g;
            b = e
        }
        typeof c === "string" && (c = c.split(","));
        d && d.fields && d.fields.sort && d.fields.sort();
        if (d != null) {
            g = Object.keys(d);
            for (var e = 0; e < g.length; e++) {
                var h = g[e];
                d[h] == null && delete d[h]
            }
        }
        return {
            ids: c,
            isForSingleID: f,
            params: d,
            path: b,
            method: a
        }
    }

    function b(a, b) {
        if (Object.keys(b).length === 0) return {
            fields: [d("AdsPreloaderMismatchesConstants").NO_QUERIES_MSG],
            client_values: ["N/A"],
            server_values: ["true"]
        };
        var e = null,
            f = Object.keys(b);
        for (var g = 0; g < f.length; g++) {
            var h = f[g];
            h = k(a, b, h);
            (e === null || h.fields.length < e.fields.length) && (e = h)
        }
        return c("filterObject")((h = e) != null ? h : {}, function(a, b) {
            return a.length > 0
        })
    }
    g.normalizeParamsForComparison = i;
    g.getFieldsParamFromRequest = j;
    g.getQueryKey = a;
    g.extractMetadataFromServerKey = l;
    g.filterIgnoredParams = m;
    g.extractMetadataFromRequest = n;
    g.getStringArrayAnnotations = b
}), 98);
__d("getQueryParamFromURI", ["URI", "memoizeWithArgs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("memoizeWithArgs")(function() {
        return new(c("URI"))(window.location.href).getQueryData()
    }, function() {
        return String(window.location.href)
    });

    function a(a) {
        return h()[a]
    }
    g["default"] = a
}), 98);
__d("adsIsPreloadingDebugModeFromURI", ["getQueryParamFromURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("getQueryParamFromURI")("preloadingdebug") || c("getQueryParamFromURI")("preloadingonly")
    }
    g["default"] = a
}), 98);
__d("preloadedGraphAPI", ["AdsPreloaderUtils", "FBLogger", "PreloadingEvent.flow", "Promise", "adsIsPreloadingDebugModeFromURI", "clearTimeout", "cr:1612590", "performanceAbsoluteNow", "preloadedGraphAPIUtils", "qpl", "requireDeferred", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("QuickPerformanceLogger").__setRef("preloadedGraphAPI"),
        i = c("adsIsPreloadingDebugModeFromURI")(),
        j = new Set(),
        k = {},
        l = new Map(),
        m = [],
        n = {};

    function o(a) {
        ((a = n[a]) != null ? a : []).forEach(function(a) {
            return a()
        })
    }

    function p(a, b) {
        var c;
        ((c = n[a]) != null ? c : n[a] = []).push(b)
    }
    var q = .01;

    function e(e) {
        var f = e.preloadInfo,
            g = f.asyncData;
        f = f.isScenarioOngoing;
        if (!f()) return e.go();
        var h = s(e);
        b("cr:1612590") != null && b("cr:1612590").addDebugPreloadedCall({
            name: h.preloader,
            api_request_source: h.requestSource,
            timestamp: c("performanceAbsoluteNow")()
        });
        f = (f = a.__pendingPreloaders) != null ? f : {};
        g.onError(function(a) {
            y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.ERROR_LOADING_PRELOADED_DATA, e, h, a)
        });
        var i;
        r(g, h, function(a) {
            return i = a
        });
        if (i) return w(e, i, !0, h);
        g = f[h.preloader];
        f = 2e3;
        if (g != null)
            if (x(e, g) == null) return w(e, g, !0, h);
            else return t(e, f, h);
        else return t(e, f, h)
    }

    function r(b, d, e) {
        var f = a.__preloaderData || (a.__preloaderData = {});
        f.__onAdd = o;
        var g = function(a) {
                var b;
                g = function(a) {};
                d.serverEnd = (b = d.serverEnd) != null ? b : c("performanceAbsoluteNow")();
                e(a)
            },
            h = function() {
                var a, b = f[d.preloader],
                    c = b[0];
                b = b[1];
                d.wpdArrive = (a = d.wpdArrive) != null ? a : b;
                g(c)
            };
        f[d.preloader] ? h() : (p(d.preloader, h), b.onLoaded(function(a) {
            a.__wpd__ ? h() : g(a)
        }))
    }

    function s(a) {
        var b, d = a.preloadInfo.asyncData.getPreloaderName();
        a = (a = a.source) != null ? a : "unknown";
        var e = [d, a].join(":");
        b = (b = l.get(e)) != null ? b : 0;
        l.set(e, b + 1);
        e = {
            requestSource: a,
            requestedAt: c("performanceAbsoluteNow")(),
            preloader: d,
            queryIndex: b
        };
        m.push(e);
        return e
    }

    function t(a, e, f) {
        y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_BEAT_JS_EXECUTION, a, f);
        return e <= 0 ? u(a, f) : new(b("Promise"))(function(b) {
            var d = !1,
                g = c("setTimeoutAcrossTransitions")(function() {
                    d = !0, b(u(a, f))
                }, e);
            r(a.preloadInfo.asyncData, f, function(e) {
                d || (c("clearTimeout")(g), b(w(a, e, !0, f)))
            });
            a.preloadInfo.asyncData.onError(function(e) {
                d || (c("clearTimeout")(g), b(a.go()))
            })
        })
    }

    function u(a, e) {
        var f = a.preloadInfo,
            g = f.asyncData,
            h = f.isScenarioOngoing;
        y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_BEAT_API_START, a, e);
        e.apiStart = (f = e.apiStart) != null ? f : c("performanceAbsoluteNow")();
        var i = a.go(),
            j = null;
        return b("Promise").race([new(b("Promise"))(function(b) {
            r(g, e, function(c) {
                var d = j === null;
                d && !a.preloadInfo.winner && (a.preloadInfo.winner = "server");
                b(w(a, c, a.preloadInfo.winner === "server", e, i));
                j = c
            })
        }), i.then(function(b) {
            e.apiEnd = c("performanceAbsoluteNow")();
            j === null && (a.preloadInfo.winner || (a.preloadInfo.winner = "client", y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_BEAT_API, a, e)), j = b);
            return b
        })]).then(function(b) {
            h() || y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.UNNECESSARY_SERVER_PRELOADING, a, e, b);
            return b
        })
    }

    function v(b) {
        var c;
        c = (c = a.__pendingPreloaders) != null ? c : {};
        return c[b.preloadInfo.asyncData.getPreloaderName()] === null
    }

    function w(a, e, f, g, h) {
        var i = x(a, e);
        if (i) {
            f && y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_SUCCESS, d("PreloadingEvent.flow").PreloadingEventType.PRELOAD_HIT, a, g, e);
            return b("Promise").resolve(babelHelpers["extends"]({}, i, {
                __preloaded: !0
            }))
        } else if (f && !a.preloadInfo.ignoreMismatches && !(e == null ? void 0 : e.intentionally_empty))
            if (v(a)) y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.SERVER_DISABLED_DIDNT_SEND_DATA, a, g, e);
            else {
                y(d("PreloadingEvent.flow").PreloadingEventName.ADS_INTERFACES_PRELOADING_ISSUE, d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_SEND_ALL_NECESSARY_DATA, a, g, e);
                try {
                    A(g, a, e)
                } catch (a) {
                    c("FBLogger")("ads").catching(a).mustfix("Error logging preloader mismatch to QPL")
                }
            }
        if (h) return h;
        g.apiStart = (i = g.apiStart) != null ? i : c("performanceAbsoluteNow")();
        return a.go().then(function(a) {
            g.apiEnd = c("performanceAbsoluteNow")();
            return a
        })
    }

    function x(a, b) {
        b = b;
        var c = d("AdsPreloaderUtils").getQueryKey(a);
        if (b[c]) return b[c];
        var e = d("AdsPreloaderUtils").extractMetadataFromRequest(a),
            f = d("AdsPreloaderUtils").getFieldsParamFromRequest(a),
            g = d("AdsPreloaderUtils").normalizeParamsForComparison(e.params),
            h = e.ids,
            i = {},
            j = Object.keys(b);
        c = function() {
            var c = j[k],
                l = d("AdsPreloaderUtils").extractMetadataFromServerKey(c),
                m = b[c];
            if (e.path !== l.path || e.method !== l.method || m.error != null) return "continue";
            c = d("AdsPreloaderUtils").filterIgnoredParams(d("AdsPreloaderUtils").normalizeParamsForComparison(l.params));
            if (!d("preloadedGraphAPIUtils").isSubsetOf(g, c, f, a.preloadInfo.fieldComparators)) return "continue";
            var n = l.ids;
            if (h == null && n == null) return {
                v: m
            };
            if (h == null || n == null) return "continue";
            if (e.isForSingleID || l.isForSingleID) {
                if (!h.every(function(a) {
                        return n.indexOf(a) !== -1
                    })) return "continue";
                if (e.isForSingleID && l.isForSingleID) return {
                    v: m
                };
                if (e.isForSingleID) return {
                    v: babelHelpers["extends"]({
                        __fb_trace_id__: m.__fb_trace_id__
                    }, m[h[0]])
                };
                if (l.isForSingleID) {
                    c = m.__fb_trace_id__;
                    l = babelHelpers.objectWithoutPropertiesLoose(m, ["__fb_trace_id__"]);
                    return {
                        v: (c = {
                            __fb_trace_id__: c
                        }, c[n[0]] = l, c)
                    }
                }
            }
            i.__fb_trace_id__ = m.__fb_trace_id__;
            h = h.filter(function(a) {
                if (n.indexOf(a) !== -1) {
                    i[a] = m[a];
                    return !1
                }
                return !0
            });
            if (h.length === 0) return {
                v: i
            }
        };
        for (var k = 0; k < j.length; k++) {
            var l = c();
            switch (l) {
                case "continue":
                    continue;
                default:
                    if (typeof l === "object") return l.v
            }
        }
        return null
    }

    function y(a, b, c, e, f) {
        e.eventType = (e = e.eventType) != null ? e : b;
        i || b === d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_SEND_ALL_NECESSARY_DATA;
        e = {
            api_request_source: c.source,
            call_name: c.name,
            endpoint: c.path,
            error_type: b
        };
        Math.random() <= q && (e.search_query = d("AdsPreloaderUtils").getQueryKey(c), e.field_names = b === d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_SEND_ALL_NECESSARY_DATA ? Object.keys(f || {}) : null);
        c.preloadInfo.log(e, d("PreloadingEvent.flow").PreloadingEventName.getName(a))
    }

    function f(a) {
        switch (a) {
            case d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_SEND_ALL_NECESSARY_DATA:
                return "\n          Graph API call is not being preloaded by AdsPreloader as declared!\n          Notice that the server and client queries are matched based on their\n          parameters, so look out for any parameter or path difference between\n          client and server queries.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_BEAT_JS_EXECUTION:
                return "\n          The server query that preloads this Graph API call didn't respond\n          before the callsite in JavaScript executed.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_BEAT_API:
                return "\n          The server query that preloads this Graph API call didn't respond\n          before the actual API call, so it was not useful whatsoever.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.SERVER_DISABLED_DIDNT_SEND_DATA:
                return "\n          Graph API call is not being preloaded by AdsPreloader because it was\n          disabled on that run. Probably caused by some experiment.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.UNNECESSARY_SERVER_PRELOADING:
                return "\n          The AdsPreloader query that is meant to preload this request finished\n          after the given scenario was concluded. This means this API call might\n          not be needed for the scenario at hand, and thus the preloading could\n          be removed.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.ERROR_LOADING_PRELOADED_DATA:
                return "\n          There was an error in the execution of the AdsPreloader query that\n          backs this Graph API call.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.PRELOAD_HIT:
                return "\n          Preloaded data was successfully used by client query.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.SERVER_DIDNT_BEAT_API_START:
                return "\n          The server query that preloads this Graph API call didn't respond\n          before the actual API call and a subsequent delay, so it was not\n          useful whatsoever.\n        ";
            case d("PreloadingEvent.flow").PreloadingEventType.UNUSED_PRELOADED_DATA:
                return "\n          Preloaded data was unused.\n        "
        }
    }

    function f(a, b) {
        k[a] = b
    }

    function z() {
        return m
    }

    function A(a, e, f) {
        j.add(a.preloader);
        var g = d("AdsPreloaderUtils").getStringArrayAnnotations(e, f);
        g && (a.stringArrayAnnotations = g);
        b("cr:1612590") !== null && b("cr:1612590").record(a.preloader, e, f);
        var i = babelHelpers["extends"]({}, k, {
            call_name: (a = e.name) != null ? a : "null",
            endpoint: e.path,
            preloader: e.preloadInfo.asyncData.getID(),
            request_source: (f = e.source) != null ? f : "null",
            uri: window.location.href
        });
        h.onReady(function(a) {
            a.markEvent(c("qpl")._(41484301, "4983"), "preloader_mismatch", 3, {
                annotations: {
                    string: i,
                    string_array: g
                }
            })
        })
    }

    function B() {
        return Array.from(j)
    }
    g.preloadedGraphAPI = e;
    g.addPreloaderLoggingContext = f;
    g.getPreloadersUsageData = z;
    g.getMismatchedPreloaders = B
}), 98);
__d("GraphAPICore", ["errorCode", "invariant", "ApiClient", "ErrorSerializer", "FBLogger", "FBTraceIDsForFailedGraphAPIRequests", "GraphAPIPerfLogging", "GraphAPIPreloadingOnlyMode", "Promise", "RequestConstants", "RequestProcessorDefault", "UrlMap", "emptyFunction", "getErrorFromAPIResponse", "guid", "mixInEventEmitter", "performanceNow", "preloadedGraphAPI", "promiseDone", "sdk.URI", "setTimeout", "sprintf"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = 500,
        k = 960,
        l = window.location.href.indexOf("nobatch") > -1,
        m = !1,
        n = [],
        o = null,
        p = 1,
        q, r = u(c("RequestProcessorDefault"));

    function a(b) {
        var d = b.method + ":" + b.name,
            e = b.error,
            f = e && (e.error_user_msg || e.message) || "Unknown error",
            a = e.code || "";
        e.error_subcode && (a += "." + e.error_subcode);
        return c("sprintf")("%s%s | (%s) %s | URI: %s%s%s", b.source ? b.source + " | " : "", d, a, f, b.path, b.api_fbtrace_id ? " | fbtrace: " + b.api_fbtrace_id : "", (e == null ? void 0 : e.fbtrace_id) ? " | wwwRequestID: " + (e == null ? void 0 : e.fbtrace_id) : "")
    }

    function e(a) {
        n.push(a)
    }

    function s(a) {
        return n.some(function(b) {
            return b(a)
        })
    }

    function f(a) {
        a >= 1 || i(0, 2348), p = a
    }

    function h(a) {
        a && q && c("FBLogger")("graph_api").warn("You are replacing an active response injector!"), q = a
    }

    function a() {
        m = !0
    }

    function t() {
        m = !1
    }

    function u(a) {
        r instanceof c("RequestProcessorDefault") || a === c("RequestProcessorDefault") || i(0, 2349);
        r = new a(x);
        return r
    }

    function v() {
        r = u(c("RequestProcessorDefault"))
    }

    function w(a, e) {
        if (a.earlyRejectionError != null) {
            c("setTimeout")(function() {
                return e({
                    error: a.earlyRejectionError
                })
            }, 0);
            return
        }
        if (q) {
            var f = q(a);
            if (f) {
                c("setTimeout")(function() {
                    return f.response != null ? e(f.response) : r.scheduleRequest(a, e)
                }, f.latency || 0);
                return
            }
        }
        if (a.preloadInfo != null) {
            var g = a.preloadInfo;
            g = babelHelpers["extends"]({}, a, {
                preloadInfo: g,
                go: function() {
                    return new(b("Promise"))(function(b) {
                        return r.scheduleRequest(a, b)
                    })
                }
            });
            c("promiseDone")(d("preloadedGraphAPI").preloadedGraphAPI(g), e);
            return
        }
        r.scheduleRequest(a, e)
    }

    function x(a, b) {
        if (d("GraphAPIPreloadingOnlyMode").isEnabled()) {
            c("FBLogger")("graph_api").info("Attempted and canceled API request for a %s, options: %s", a.preloadInfo && a.preloadInfo.isScenarioOngoing() ? "critical request" : "non-critical request", JSON.stringify(a));
            return
        }
        var e = !a.batched && (!m || s(a)) || l;
        e ? c("ApiClient").graph(a.path, a.method, a.params, b) : c("ApiClient").scheduleBatchCall(a.path, a.method, a.params, b)
    }

    function y(a, e) {
        e === void 0 && (e = 1);
        var f = c("performanceNow")();
        o && !a.priority && (a.priority = o);
        return new(b("Promise"))(function(b, g) {
            a.params = babelHelpers["extends"]({}, a.params, {
                xref: c("guid")(),
                _reqName: a.name,
                _priority: a.priority
            });
            a.index != null && (a.params._index = a.index);
            a.source && (a.params._reqSrc = a.source);
            if (e < 1 || e > a.max_attempts) {
                g(C({
                    error: 1,
                    error_subcode: 1357005
                }));
                return
            }
            w(a, function(h) {
                var i = c("getErrorFromAPIResponse")(h),
                    k = h == null ? void 0 : h.__fb_trace_id__,
                    l = h == null ? void 0 : h.__www_request_id__,
                    m = babelHelpers["extends"]({}, a, {
                        api_fbtrace_id: k,
                        www_request_id: l,
                        attempt: e,
                        request_time: Math.round(c("performanceNow")() - f),
                        start_time: f
                    });
                if (i) {
                    var n = babelHelpers["extends"]({}, m, {
                        error: i
                    });
                    if (e < a.max_attempts && (z(i) || a.canRetry)) c("setTimeout")(function() {
                        b(y(a, e + 1))
                    }, Math.pow(2, e - 1) * j), K.emit("retry", n);
                    else {
                        k && d("FBTraceIDsForFailedGraphAPIRequests").insert(k);
                        if (!I(a.params)) {
                            var o;
                            K.emit("error", n);
                            n = (n = (n = a.params) == null ? void 0 : n._reqSrc) != null ? n : "unknown";
                            var p = i.code,
                                q = i.error_subcode;
                            o = (o = (o = a.params) == null ? void 0 : o._reqName) != null ? o : "";
                            o = a.method + ":" + o;
                            l = (l = l) != null ? l : k;
                            k = c("FBLogger")("graph_api").addToCategoryKey(n);
                            l != null && (k = k.addMetadata("GRAPH_API", "REQUEST_ID", l));
                            k.warn("Graph API failed: %s,%s,%s,%s", n, p, q, o)
                        }
                        g(a.earlyRejectionError == null ? C(i) : i)
                    }
                } else {
                    B(a, h);
                    k = (l = h == null ? void 0 : h.__preloaded) != null ? l : !1;
                    h == null ? void 0 : delete h.__preloaded;
                    h == null ? void 0 : delete h.__fb_trace_id__;
                    h == null ? void 0 : delete h.__www_request_id__;
                    b(h);
                    K.emit("success", babelHelpers["extends"]({}, m, {
                        preloaded: k
                    }))
                }
            })
        })
    }

    function z(a) {
        if (a.is_transient) return !0;
        if (a.error_subcode === 1357045 || a.error_subcode === 1357051) return !0;
        if (!a.code) return !0;
        return a.code === k ? !0 : !1
    }

    function A(a, b) {
        if (b) {
            var d = new(c("sdk.URI"))(b);
            return function() {
                return E(a.name, d.getPath(), d.getQueryData(), !1, a.source)
            }
        }
    }

    function B(a, b) {
        if (Array.isArray(b) || !b.paging) return;
        if (b.paging.next) {
            var d = a.params;
            d = d && d.after && b.paging.cursors && d.after === b.paging.cursors.after;
            d ? c("FBLogger")("graph_api").mustfix("[%s] Next page is the same as the current page! This should never happen. Ignoring the next page URL. Please report an API bug!", a.name) : b.next = A(a, b.paging.next)
        }
        d = A(a, b.paging.previous);
        d && (b.previous = d)
    }

    function C(a) {
        var b = new Error(a.message);
        c("ErrorSerializer").aggregateError(b, {
            type: "warn"
        });
        Object.assign(b, a);
        return b
    }

    function D(a, b, c, d, e, f, g, h) {
        return y({
            batched: d,
            canRetry: !1,
            max_attempts: 1,
            method: "delete",
            name: a,
            params: c,
            path: b,
            source: e,
            preloadInfo: f,
            priority: g,
            earlyRejectionError: h
        })
    }

    function E(a, b, c, d, e, f, g, h, i, j) {
        h === void 0 && (h = !1);
        return y({
            batched: d,
            canRetry: h,
            max_attempts: p,
            method: "get",
            name: a,
            params: c,
            path: b,
            source: e,
            preloadInfo: f,
            priority: g,
            earlyRejectionError: i,
            cacheInfo: j
        })
    }

    function F(a, b, c, d, e, f, g, h, i) {
        h === void 0 && (h = !1);
        return y({
            batched: d,
            canRetry: h,
            max_attempts: h ? p : 1,
            method: "post",
            name: a,
            params: c,
            path: b,
            source: e,
            preloadInfo: f,
            priority: g,
            earlyRejectionError: i
        })
    }

    function G(a, e, f, g) {
        var h = new(c("sdk.URI"))(d("UrlMap").resolve("graph_domain")).setPath(e).setQueryData({
            access_token: c("ApiClient").getAccessToken(),
            suppress_http_code: 1
        }).toString();
        return new(b("Promise"))(function(b, i) {
            if (g != null) {
                i(g);
                return
            }
            var j = new XMLHttpRequest();
            j.open("POST", h, !0);
            j.setRequestHeader("X-Requested-With", "XMLHttpRequest");
            c("ApiClient").getWithCredentials() && (j.withCredentials = !0);
            var k = function(g) {
                var h;
                try {
                    h = JSON.parse(j.responseText)
                } catch (a) {
                    i(new Error("Invalid JSON: " + j.responseText));
                    return
                }
                var k = c("getErrorFromAPIResponse")(h);
                !k && g && (k = d("RequestConstants").PARSE_ERROR_TEMPLATE);
                if (k) {
                    var l;
                    i(C(k));
                    g = (g = h) == null ? void 0 : g.__fb_trace_id__;
                    l = (l = h) == null ? void 0 : l.__www_request_id__;
                    K.emit("error", {
                        name: a,
                        path: e,
                        method: "POST",
                        params: f,
                        error: k,
                        api_fbtrace_id: g,
                        www_request_id: l
                    });
                    g = k.code;
                    l = k.error_subcode;
                    c("FBLogger")("graph_api").warn("Graph POST API failed: %s,%s", g, l)
                } else b(h)
            };
            j.onload = function() {
                k(!1)
            };
            j.onerror = function() {
                k(!0)
            };
            j.send(f)
        })
    }

    function H(a, b) {
        b = {
            batch: b.map(function(a) {
                var b = a.request;
                b.params instanceof FormData && i(0, 2350);
                var d = c("ApiClient").prepareBatchParams([b.path, b.method, b.params, function() {}]),
                    e = d.body;
                d = d.relative_url;
                return {
                    name: a.name,
                    method: b.method,
                    body: e,
                    relative_url: d,
                    omit_response_on_success: !1
                }
            })
        };
        return F(a, "/", b, !1)
    }

    function I(a) {
        return !!(a && a.execution_options && a.execution_options.some(function(a) {
            return a === "validate_only"
        }))
    }

    function J(a, b) {
        o = a, b(), o = null
    }
    var K = {
        blocklist: e,
        isBlocklistedForBatching: s,
        disableBatching: t,
        enableBatching: a,
        isRecoverableError: z,
        runInSpecifiedPriority: J,
        promiseBatch: H,
        promiseDelete: D,
        promiseGet: E,
        promisePost: F,
        promisePostFormData: G,
        disableDefaultErrorHandler: function() {
            return L && L.remove()
        },
        disableDefaultRetryLogHandler: function() {
            return M && M.remove()
        },
        registerProcessor: u,
        resetRequestProcessor: v,
        setMaxAPIRequestAttempts: f,
        setResponseInjector: h,
        addListener: c("emptyFunction"),
        emit: c("emptyFunction"),
        listeners: c("emptyFunction").thatReturnsArgument([])
    };
    c("mixInEventEmitter")(K, {
        error: !0,
        retry: !0,
        success: !0,
        preloaded: !0
    });
    var L = K.addListener("error", function(a) {
            return !1
        }),
        M = K.addListener("retry", function(a) {});
    d("GraphAPIPerfLogging").register();
    e = K;
    g["default"] = e
}), 98);
__d("GraphAPIFieldUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return b.length === 0 ? "" + a : a + "{" + b.join(",") + "}"
    }

    function g(a) {
        var b = a.match(/(\w+){(.+)}/);
        if (b === null) return {
            field: a
        };
        b[0];
        a = b[1];
        b = b[2];
        var c = [],
            d = 0,
            e = "";
        for (var f = 0; f < b.length; ++f) {
            var h = b.charAt(f);
            if (h === "," && d === 0) {
                c.push(e);
                e = "";
                continue
            }
            e += h;
            h === "{" ? d += 1 : h === "}" && (d -= 1)
        }
        e.length > 0 && c.push(e);
        h = new Set(c.map(g));
        return {
            field: a,
            subFields: h
        }
    }

    function b(a, b) {
        var c = Object.keys(b).map(function(a) {
            var c = b[a];
            if (c != null) {
                c = typeof c === "string" ? c : JSON.stringify(c);
                return "." + a + "(" + ((a = c) != null ? a : "undefined") + ")"
            }
        }).join("");
        return "" + a + c
    }
    f.getFieldWithSubfields = a;
    f.parseField = g;
    f.getFieldWithParameterizedSubfields = b
}), 66);
__d("arrayContainsArray", [], (function(a, b, c, d, e, f) {
    function a(a, b) {
        return a.length === 0 ? !1 : b.every(function(b) {
            return a.indexOf(b) >= 0
        })
    }
    f["default"] = a
}), 66);
__d("someSet", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c) {
        var d = a.entries(),
            e = d.next();
        while (!e.done) {
            var f = e.value;
            if (b.call(c, f[1], f[0], a)) return !0;
            e = d.next()
        }
        return !1
    }
    f["default"] = a
}), 66);
__d("GraphAPIRequestMatchingUtils", ["GraphAPIFieldUtils", "arrayContainsArray", "deepEquals", "filterObject", "objectKeys", "someSet"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = ["am_call_tags", "locale", "pretty", "sessionId", "xref", "access_token", "accessToken", "qpl_active_flow_instance_ids", "qpl_active_flow_ids"],
        i = ["fields", "column_fields", "action_attribution_windows"];

    function j(a, b, d) {
        b === void 0 && (b = []);
        var e = c("filterObject")((a = a) != null ? a : {}, function(a, c) {
            var e;
            if ((e = b) == null ? void 0 : e.includes(c)) return !0;
            else if (a == null && (d == null ? void 0 : d.allowIgnoreEmptyParams) === !0) return !1;
            else if (c.startsWith("_")) return !1;
            else if (h.includes(c)) return !1;
            return !0
        });
        Array.isArray(e.ids) ? e.ids = e.ids.slice().sort() : typeof e.ids === "string" && e.ids.includes(",") && (e.ids = e.ids.split(",").sort().join(","));
        Object.keys(e).forEach(function(a) {
            i.includes(a) && Array.isArray(e[a]) && (e[a] = e[a].slice().sort())
        });
        return e
    }

    function k(a, b) {
        var c = a.map(d("GraphAPIFieldUtils").parseField);
        a = b.map(d("GraphAPIFieldUtils").parseField);
        var e = function() {
            if (g) {
                if (h >= f.length) return "break";
                b = f[h++]
            } else {
                h = f.next();
                if (h.done) return "break";
                b = h.value
            }
            var a = b,
                d = c.find(function(b) {
                    return l(b, a)
                });
            if (d == null) return {
                v: !1
            }
        };
        _loop: for (var f = a, g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            a = e();
            switch (a) {
                case "break":
                    break _loop;
                default:
                    if (typeof a === "object") return a.v
            }
        }
        return !0
    }

    function l(a, b) {
        if (b.field !== a.field) return !1;
        if (b.subFields != null) {
            if (a.subFields == null) return !1;
            var d = function() {
                if (f) {
                    if (g >= e.length) return "break";
                    h = e[g++]
                } else {
                    g = e.next();
                    if (g.done) return "break";
                    h = g.value
                }
                var b = h,
                    d = c("someSet")(a.subFields, function(a) {
                        return l(a, b)
                    });
                if (!d) return {
                    v: !1
                }
            };
            _loop3: for (var e = b.subFields, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var h;
                b = d();
                switch (b) {
                    case "break":
                        break _loop3;
                    default:
                        if (typeof b === "object") return b.v
                }
            }
        }
        return !0
    }

    function m(a, b, c) {
        if (a === b) return !0;
        else if (typeof a === "string" && typeof b === "string") return n(a.split(","), b.split(","), c);
        else return n(a, b, c)
    }

    function n(a, b, d) {
        if (Array.isArray(a) && Array.isArray(b))
            if (d) {
                d = [];
                var e = [];
                for (var f = a, g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var i;
                    if (g) {
                        if (h >= f.length) break;
                        i = f[h++]
                    } else {
                        h = f.next();
                        if (h.done) break;
                        i = h.value
                    }
                    i = i;
                    typeof i === "string" && d.push(i)
                }
                for (var i = b, h = Array.isArray(i), g = 0, i = h ? i : i[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    if (h) {
                        if (g >= i.length) break;
                        f = i[g++]
                    } else {
                        g = i.next();
                        if (g.done) break;
                        f = g.value
                    }
                    f = f;
                    typeof f === "string" && e.push(f)
                }
                if (d.length === a.length && e.length === b.length) return k(d, e);
                else return c("arrayContainsArray")(a, b)
            } else return c("arrayContainsArray")(a, b);
        else return a === b
    }

    function o(a, b, c) {
        var d = j(a, null, c),
            e = j(b, null, c);
        a = Object.keys(d);
        return a.length !== Object.keys(e).length ? !1 : a.every(function(a) {
            var b = d[a],
                f = e[a];
            return p(a, b, f, c)
        })
    }

    function p(a, b, d, e) {
        switch (a) {
            case "ids":
                if ((e == null ? void 0 : e.allowIDsSubset) === !0) return m(b, d, !1);
                else return c("deepEquals")(b, d);
            case "fields":
            case "column_fields":
                return n(b, d, (a = e == null ? void 0 : e.allowSubfieldSuperset) != null ? a : !1);
            default:
                return c("deepEquals")(b, d)
        }
    }

    function a(a, b, c) {
        if (a.method !== b.method || a.path !== b.path) return !1;
        a = a.params;
        b = b.params;
        return a == null || b == null || a instanceof FormData || b instanceof FormData ? a === b : o(a, b, c)
    }

    function q(a) {
        return typeof a === "string" ? a : a === void 0 ? "undefined" : JSON.stringify((a = a) != null ? a : null)
    }

    function r(a) {
        return a == null ? new Set() : Array.isArray(a) ? new Set(a.map(q)) : typeof a === "string" ? new Set(a.split(",")) : new Set([q(a)])
    }

    function s(a, b, c, d, e) {
        e === void 0 && (e = 1), a.pairs[b] = {
            original: q(c),
            incoming: q(d)
        }, a.distance += c !== void 0 && d !== void 0 ? e : e * 2
    }

    function t(a, b) {
        a = new Set(c("objectKeys")(a));
        for (var b = c("objectKeys")(b), d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= b.length) break;
                f = b[e++]
            } else {
                e = b.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            if (a.has(f)) continue;
            a.add(f)
        }
        return Array.from(a)
    }

    function b(a, b, c) {
        var d = {
            pairs: {},
            distance: 0
        };
        a.method !== b.method && s(d, "method", a.method, b.method, 1e3);
        a.path !== b.path && s(d, "path", a.path, b.path, 100);
        a = a.params;
        b = b.params;
        if (a instanceof FormData || b instanceof FormData) {
            a !== b && s(d, "params_form_data", a instanceof FormData, b instanceof FormData, 100);
            return d
        }
        var e = j(a, null, c),
            f = j(b, null, c);
        a = t(e, f);
        a.forEach(function(a) {
            var b = e[a],
                g = f[a];
            if (a === "fields" || a === "column_fields") {
                var h = r(b),
                    i = r(g),
                    j = [];
                for (var k = i.values(), l = Array.isArray(k), m = 0, k = l ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var n;
                    if (l) {
                        if (m >= k.length) break;
                        n = k[m++]
                    } else {
                        m = k.next();
                        if (m.done) break;
                        n = m.value
                    }
                    n = n;
                    h.has(n) || j.push(n)
                }
                d.missingIncomingFields = j;
                if (d.missingIncomingFields.length > 0 && i.size > 0) {
                    n = d.missingIncomingFields.length / i.size;
                    s(d, a, b, g, n)
                }
            } else p(a, b, g, c) || s(d, a, b, g)
        });
        return d
    }
    g.normalizeParamsForMatching = j;
    g.matchGraphAPIFieldSubset = l;
    g.areRequestsEquivalent = a;
    g.getRequestDeltas = b
}), 98);
__d("GraphAPIPreloadedData", ["$InternalEnum", "DateConsts", "FBLogger", "GraphAPIConfig", "GraphAPIRequestMatchingUtils", "clearTimeout", "gkx", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 5,
        i = h * d("DateConsts").SEC_PER_MIN * d("DateConsts").MS_PER_SEC,
        j = 10 * d("DateConsts").MS_PER_SEC;
    b = b("$InternalEnum").Mirrored(["AP_ML", "EP", "AP_CS"]);
    var k = new Map(),
        l = new Map(),
        m;

    function a(a, b, c) {
        a.params != null && !(a.params instanceof FormData) && (a.params.__entryPointPreloaded = "1");
        var d = a.go();
        if (!(a.params instanceof FormData)) {
            var e;
            (e = a.params) == null ? void 0 : delete e.__entryPointPreloaded
        }
        k.set(a, {
            dataProvider: c,
            response: d,
            timeoutId: u(a, b),
            refCounter: 1
        });
        return d
    }

    function n(a) {
        return {
            allowIDsSubset: a.path === "/" + d("GraphAPIConfig").adsApiVersion + "/",
            allowIgnoreEmptyParams: !0,
            allowSubfieldSuperset: c("gkx")("6034")
        }
    }

    function o(a, b) {
        var c = l.get(b);
        c || (c = [], l.set(b, c));
        b = a.source != null && a.source.length > 0 ? a.source + "-" + a.name : a.name;
        c.push(b)
    }

    function p(a, b) {
        b === void 0 && (b = !0);
        var e = n(a);
        for (var f = k.entries(), g = Array.isArray(f), h = 0, f = g ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var i;
            if (g) {
                if (h >= f.length) break;
                i = f[h++]
            } else {
                h = f.next();
                if (h.done) break;
                i = h.value
            }
            i = i;
            var j = i[0];
            i = i[1];
            if (d("GraphAPIRequestMatchingUtils").areRequestsEquivalent(j, a, e)) {
                b && (c("clearTimeout")(i.cacheTTLTimeoutID), i.refCounter++);
                return j
            }
        }
        return null
    }

    function e(a, b) {
        b === void 0 && (b = !0);
        var c = p(a, !1);
        if (c != null) {
            var d = k.get(c);
            if (d != null) {
                o(a, c);
                return {
                    response: d.response,
                    dataProvider: d.dataProvider
                }
            }
        }
        c = m;
        c != null && b === !0 && !(a.params instanceof FormData) && ((d = a.params) == null ? void 0 : d.__entryPointPreloaded) !== "1" && c(Array.from(k.keys()), a, n(a));
        return null
    }

    function f(a) {
        return l.get(a)
    }

    function q(a, b) {
        b === void 0 && (b = !1);
        var d = k.get(a);
        if (d != null) {
            d.refCounter--;
            if (d.refCounter <= 0) {
                if (d.refCounter < 0) {
                    c("FBLogger")("ams_experimentation").warn("[Graph API Preloading] refCounter < 0 (reqName: %s) (reqSrc: %s)", a.name, (d = a.source) != null ? d : "")
                }
                b ? r(a) : s(a);
                l["delete"](a)
            }
        }
    }

    function r(a) {
        var b;
        c("clearTimeout")((b = k.get(a)) == null ? void 0 : b.timeoutId);
        k["delete"](a);
        l["delete"](a)
    }

    function s(a) {
        var b = k.get(a);
        b != null && (c("clearTimeout")(b.cacheTTLTimeoutID), b.cacheTTLTimeoutID = c("setTimeout")(function() {
            r(a)
        }, j))
    }

    function t(a) {
        m = a
    }

    function u(a, b) {
        var d = k.get(a);
        d != null && window.clearTimeout(d.timeoutId);
        return window.setTimeout(function() {
            if (k.has(a)) {
                var d;
                c("FBLogger")("ams_experimentation").warn("[Graph API Preloading] Cached graphAPI data name:%s source:%s interaction:%s wasn't removed after %s minutes.", a.name, (d = a.source) != null ? d : "", b, h)
            }
        }, i)
    }
    g.Provider = b;
    g.execute = a;
    g.findEquivalentRequest = p;
    g.find = e;
    g.getDataConsumers = f;
    g.remove = q;
    g.setLogMismatchCallback = t
}), 98);
__d("GraphAPIRequestSpec", ["invariant", "CurrentLocale", "GraphAPICore", "GraphAPIPreloadedData", "killswitch"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    b = function() {
        function a(a, b, c, d, e, f, g, h, i) {
            this.name = a, this.path = b, this.params = c, this.batch = d, this.source = e, this.preloadInfo = f, this.priority = g, this.canRetry = !1, this.earlyRejectionError = h, this.cacheInfo = i
        }
        var b = a.prototype;
        b.preloadedBy = function(a, b, c) {
            var d = {
                    ignoreMismatches: !1
                },
                e = b.isScenarioOngoing;
            b = b.log;
            this.preloadInfo = babelHelpers["extends"]({
                asyncData: a,
                isScenarioOngoing: e,
                log: b
            }, d, c);
            return this
        };
        b.batched = function() {
            this.batch = !0;
            return this
        };
        b.setPriority = function(a) {
            this.priority = a;
            return this
        };
        b.retriable = function() {
            this.canRetry = !0;
            return this
        };
        b.__setCacheInfo = function(a) {
            this.cacheInfo = a;
            return this
        };
        return a
    }();
    e = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d, e, f, g, h, i) {
            return a.call(this, b, c, d, !1, e, f, g, h, i) || this
        }
        var c = b.prototype;
        c.clone = function() {
            var a = new b(this.name, this.path, this.params, this.source, this.preloadInfo, this.priority, this.earlyRejectionError);
            return this.batch ? a.batched() : a
        };
        c.declareOnly = function() {
            return new i(this)
        };
        c.get = function(a) {
            return this.declareOnly().get(a).go()
        };
        c.post = function(a) {
            return this.declareOnly().post(a).go()
        };
        c.remove = function(a) {
            return this.declareOnly().remove(a).go()
        };
        return b
    }(b);
    var i = function(d) {
            babelHelpers.inheritsLoose(b, d);

            function b(a) {
                return d.call(this, a.name, a.path, a.params, a.batch, a.source, a.preloadInfo, a.priority, a.earlyRejectionError, a.cacheInfo) || this
            }
            var e = b.prototype;
            e.get = function(a) {
                a = this.$SemideclaredGraphAPIRequestSpec1(a);
                return new j(this, a, "get")
            };
            e.post = function(b) {
                b && a.FormData && b instanceof a.FormData ? b = this.$SemideclaredGraphAPIRequestSpec2(b) : b = this.$SemideclaredGraphAPIRequestSpec1(b);
                return new j(this, b, "post")
            };
            e.remove = function(a) {
                a = this.$SemideclaredGraphAPIRequestSpec1(a);
                return new j(this, a, "delete")
            };
            e.$SemideclaredGraphAPIRequestSpec1 = function(a) {
                return babelHelpers["extends"]({
                    locale: c("CurrentLocale").get()
                }, this.params, a)
            };
            e.$SemideclaredGraphAPIRequestSpec2 = function(a) {
                a.append("locale", c("CurrentLocale").get());
                var b = this.params;
                if (b)
                    for (var d in b) Object.prototype.hasOwnProperty.call(b, d) && a.append(d, b[d]);
                return a
            };
            return b
        }(b),
        j = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c, d) {
                c = b.call(this, a.name, a.path, c, a.batch, a.source, a.preloadInfo, a.priority, a.earlyRejectionError, a.cacheInfo) || this;
                c.method = d;
                return c
            }
            var e = a.prototype;
            e.go = function() {
                var a = this.params,
                    b = this.method;
                if (!c("killswitch")("ADS_MANAGER_ENTRY_POINT_DATA_PRELOADING")) {
                    var e = d("GraphAPIPreloadedData").find(this);
                    if (e != null) {
                        c("GraphAPICore").emit("preloaded", babelHelpers["extends"]({
                            reqSrc: this.source,
                            path: this.path
                        }, e));
                        return e.response
                    }
                }
                if (a instanceof FormData) {
                    b === "post" || h(0, 3975);
                    return c("GraphAPICore").promisePostFormData(this.name, this.path, a, this.earlyRejectionError)
                }
                a || h(0, 3976);
                switch (b) {
                    case "get":
                        return c("GraphAPICore").promiseGet(this.name, this.path, a, this.batch, this.source, this.preloadInfo, this.priority, this.canRetry, this.earlyRejectionError, this.cacheInfo);
                    case "post":
                        return c("GraphAPICore").promisePost(this.name, this.path, a, this.batch, this.source, this.preloadInfo, this.priority, this.canRetry, this.earlyRejectionError);
                    case "delete":
                        return c("GraphAPICore").promiseDelete(this.name, this.path, a, this.batch, this.source, this.preloadInfo, this.priority, this.earlyRejectionError)
                }
                h(0, 3977)
            };
            return a
        }(b);
    g["default"] = e
}), 98);
__d("GraphAPIRequestSpecPotentialEdge", ["GraphAPIRequestSpec"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.edge = function(a) {
            return new(c("GraphAPIRequestSpec"))(this.name + "/" + a, this.path + "/" + a, this.params, this.source, this.preloadInfo, this.priority, this.earlyRejectionError)
        };
        return b
    }(c("GraphAPIRequestSpec"));
    g["default"] = a
}), 98);
__d("isValidID", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a != null && !!/^(\d+|pfbid[0123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+l)(_(\d+|pfbid[0123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+l))?$/.test(a)
    }
    f["default"] = a
}), 66);
__d("isValidVanityURI", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return !!/^[\dA-Z\._\-]+$/i.test(a)
    }
    f["default"] = a
}), 66);
__d("NamedJSONPathExpression", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a) {
            this.$1 = a, this.$2 = new g()
        }
        var b = a.prototype;
        b.prop = function(a) {
            this.$2.prop(a);
            return this
        };
        b.toString = function() {
            return "{result=" + this.$1 + ":" + String(this.$2) + "}"
        };
        b.valueOf = function() {
            return this.toString()
        };
        return a
    }();
    var g = function() {
        function a() {
            this.$1 = "$"
        }
        var b = a.prototype;
        b.prop = function(a) {
            this.$1 += "." + a;
            return this
        };
        b.toString = function() {
            return this.$1
        };
        b.valueOf = function() {
            return this.toString()
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("runGraphAPIBatch_EXPERIMENTAL", ["invariant", "GraphAPICore", "NamedJSONPathExpression", "guid"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b) {
        var d = new Map(),
            e = new Map();
        b.forEach(function(a) {
            if (!a.request) {
                var b = a;
                d.get(b) == null || h(0, 3426);
                d.set(b, c("guid")());
                e.set(b, b)
            } else {
                var f = a;
                Array.isArray(f.dependencies) || h(0, 3427);
                f.request.length === f.dependencies.length || h(0, 3428);
                d.set(f.request, c("guid")());
                b = f.dependencies.map(function(a) {
                    a = d.get(a);
                    a || h(0, 3429, f);
                    return new(c("NamedJSONPathExpression"))(a)
                });
                e.set(f.request, f.request.apply(f, b))
            }
        });
        return c("GraphAPICore").promiseBatch(a, b.map(function(b) {
            b.request && (b = b.request);
            var a = d.get(b);
            b = e.get(b);
            a && b || h(0, 3430);
            return {
                name: a,
                request: b
            }
        })).then(function(a) {
            return a.map(function(a) {
                return !a || !a.body ? {
                    success: !1,
                    noBatchDataReturned: !0
                } : JSON.parse(a.body)
            })
        })
    }
    g["default"] = a
}), 98);
__d("GraphAPI", ["errorCode", "FBLogger", "GraphAPICore", "GraphAPIRequestSpec", "GraphAPIRequestSpecPotentialEdge", "fb-error", "isValidID", "isValidVanityURI", "runGraphAPIBatch_EXPERIMENTAL", "sdk.URI", "sdk.safelyParseResponse"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "act_",
        j = function() {
            function a(a, b) {
                this.version = a, this.source = b
            }
            var b = a.prototype;
            b.me = function() {
                return new(c("GraphAPIRequestSpecPotentialEdge"))("me", this.$1("/me"), null, this.source)
            };
            b.object = function(a, b, d) {
                d === void 0 && (d = !1);
                d = this.$2(b, d);
                return new(c("GraphAPIRequestSpecPotentialEdge"))("object:" + a, this.$1("/" + b), null, this.source, void 0, void 0, d)
            };
            b.objects = function(a, b, d) {
                d === void 0 && (d = !1);
                d = this.$3(b, d);
                return new(c("GraphAPIRequestSpec"))("objects:" + a, this.$1("/"), {
                    ids: b.join(",")
                }, this.source, void 0, void 0, d)
            };
            b.urls = function(a) {
                a.forEach(function(a) {
                    return c("sdk.URI").isValidURI(a)
                });
                return new(c("GraphAPIRequestSpec"))("urls", this.$1("/"), {
                    ids: a.join(",")
                }, this.source)
            };
            b.objectByName = function(a, b) {
                this.$4(b);
                return new(c("GraphAPIRequestSpecPotentialEdge"))("objectByName:" + a, this.$1("/" + b), null, this.source)
            };
            b.objectsByName = function(a, b) {
                var d = this;
                b.forEach(function(a) {
                    return d.$4(a)
                });
                return new(c("GraphAPIRequestSpec"))("objectsByName:" + a, this.$1("/"), {
                    ids: b.join(",")
                }, this.source)
            };
            b.adaccount = function(a, b) {
                b === void 0 && (b = !1);
                b = this.$2(a, b);
                return new(c("GraphAPIRequestSpecPotentialEdge"))("adaccount", this.$1("/" + i + a), null, this.source, void 0, void 0, b)
            };
            b.adaccounts = function(a, b) {
                b === void 0 && (b = !1);
                b = this.$3(a, b);
                return new(c("GraphAPIRequestSpecPotentialEdge"))("adaccounts", this.$1("/"), {
                    ids: i + a.join("," + i)
                }, this.source, void 0, void 0, b)
            };
            b.search = function(a) {
                return new(c("GraphAPIRequestSpec"))("search:" + a, this.$1("/search"), {
                    type: a
                }, this.source)
            };
            b.path_DO_NOT_USE = function(a) {
                return new(c("GraphAPIRequestSpec"))("path:" + a, this.$1(a), null, this.source)
            };
            b.root = function(a) {
                return this.objectByName(a, a)
            };
            b.$1 = function(a) {
                return "/v" + this.version + a
            };
            b.$2 = function(a, b) {
                if (c("isValidID")(a)) return null;
                var d = c("fb-error").TAAL.blameToPreviousFile(new Error(a + " is not a valid FBID"));
                if (b) {
                    c("FBLogger")("graph_api").catching(d).mustfix("Attempted to make an API request for an invalid ID %s", a);
                    Object.assign(d, {
                        code: 100,
                        error_subcode: 1357052
                    });
                    return d
                } else throw d
            };
            b.$3 = function(a, b) {
                for (var c = 0; c < a.length; c++) {
                    var d = this.$2(a[c], b);
                    if (d != null) return d
                }
            };
            b.$4 = function(a) {
                if (!c("isValidVanityURI")(a)) throw c("fb-error").TAAL.blameToPreviousFile(new Error(a + " is not a valid vanity URI"))
            };
            return a
        }();

    function a(a, b) {
        (b == null || b === "") && c("FBLogger")("graph_api").warn("Expected a valid request source to be passed, but none was given!");
        return new j(a, b)
    }
    a.blocklist = c("GraphAPICore").blocklist;
    a.disableBatching = c("GraphAPICore").disableBatching;
    a.enableBatching = c("GraphAPICore").enableBatching;
    a.registerProcessor = c("GraphAPICore").registerProcessor;
    a.runBatchExperimental = c("runGraphAPIBatch_EXPERIMENTAL");
    a.setMaxAPIRequestAttempts = c("GraphAPICore").setMaxAPIRequestAttempts;
    a.addErrorHandler = function(a) {
        return c("GraphAPICore").addListener("error", a)
    };
    a.addRetryLogHandler = function(a) {
        return c("GraphAPICore").addListener("retry", a)
    };
    a.addSuccessLogHandler = function(a) {
        return c("GraphAPICore").addListener("success", a)
    };
    a.hasCustomErrorHandler = function() {
        return c("GraphAPICore").listeners("error").length > 1
    };
    c("sdk.safelyParseResponse").setErrorHandler(function(a, b, d, e) {
        var f = "unknown URL";
        if (d && d !== null)
            if (c("sdk.URI").isValidURI(d)) {
                var g = new(c("sdk.URI"))(d);
                if (Object.prototype.hasOwnProperty.call(g.getQueryData(), "access_token")) {
                    var h = g.getQueryData();
                    h.access_token = "ACCESS_TOKEN";
                    g.setQueryData(h)
                }
                f = g.toString()
            } else f = "invalid URL (" + d + ")";
        c("FBLogger")("graph_api").catching(a).mustfix("Received Invalid JSON reply [HTTP %s] from %s: %s", e, f, JSON.stringify(b));
        return c("sdk.safelyParseResponse").ERROR
    });
    g["default"] = a
}), 98);
__d("AdsGraphAPI", ["FBLogger", "GraphAPI", "GraphAPIConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = h();
        b !== d("GraphAPIConfig").adsApiVersion.replace("v", "") && c("FBLogger")("graph_api").warn("%s is not using the correct Graph API version, using %s. It needs to use %s", a, b, d("GraphAPIConfig").adsApiVersion);
        return c("GraphAPI")(b, a)
    }

    function h() {
        switch (d("GraphAPIConfig").adsApiVersion) {
            case "v2.10":
                return "2.10";
            case "v2.11":
                return "2.11";
            case "v2.12":
                return "2.12";
            case "v3.0":
                return "3.0";
            case "v3.1":
                return "3.1";
            case "v3.2":
                return "3.2";
            case "v3.3":
                return "3.3";
            case "v4.0":
                return "4.0";
            case "v5.0":
                return "5.0";
            case "v6.0":
                return "6.0";
            case "v7.0":
                return "7.0";
            case "v8.0":
                return "8.0";
            case "v9.0":
                return "9.0";
            case "v10.0":
                return "10.0";
            case "v11.0":
                return "11.0";
            case "v12.0":
                return "12.0";
            case "v13.0":
                return "13.0";
            case "v14.0":
                return "14.0";
            case "v15.0":
                return "15.0";
            case "v16.0":
                return "16.0";
            default:
                return d("GraphAPIConfig").adsApiVersion.replace("v", "")
        }
    }
    g.get = a;
    g.getVersion = h
}), 98);
__d("AdsInterfacesLogEvents", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        Event: {
            SHOW_CROPPER_DIALOG: "show_cropper_dialog",
            ACCOUNT_DATA_PREFETCHED: "account_data_prefetched",
            ACCOUNT_SELECTED: "account_selected",
            ACCOUNT_SELECTOR_SCROLL: "account_selector_scroll",
            AD_TEMPLATED_RENAME: "ad_template_rename",
            AD_CHANGE_LINK_POST_DESTINATION: "ad_change_link_post_destination",
            AD_CHANGE_LINK_POST_FORMAT: "ad_change_link_post_format",
            AD_CHANGE_MEDIA_FORMAT: "ad_change_media_format",
            AD_CHANGE_MULTI_END_CARD: "ad_change_multi_end_card",
            AD_CHANGE_CHILD_MEDIA_FORMAT: "ad_change_child_media_format",
            AD_CHANGE_MULTI_PRODUCT_OPTIMIZED: "ad_change_multi_product_optimized",
            AD_CHANGE_POST_EDIT_MODE: "ad_change_post_edit_mode",
            AD_SET_PAGE_ACTOR_OVERRIDE: "ad_set_page_actor_override",
            AD_UNSET_PAGE_ACTOR_OVERRIDE: "ad_unset_page_actor_override",
            AM_INLINE_ERROR_SHOWN: "am_inline_error_shown",
            AM_SUMMARY_ERROR_SHOWN: "am_summary_error_shown",
            AD_SET_LINK_TYPE: "ad_set_link_type",
            ADGROUP_URL_BUILDER_MODAL_OPEN: "adgroup_url_builder_modal_open",
            ADGROUP_URL_BUILDER_MODAL_CLOSE: "adgroup_url_builder_modal_close",
            CLOSE_WITHOUT_SAVING_UNMODIFIED: "close_without_saving_unmodified",
            CLOSE_WITHOUT_SAVING_MODIFIED: "close_without_saving_modified",
            CLOSE_AND_APPLY_CHANGES: "close_and_apply_changes",
            ADGROUP_URL_BUILDER_CUSTOM_PARAMETER_CHANGE: "adgroup_url_builder_custom_parameter_change",
            ADD_CUSTOM_PARAMETER: "add_custom_parameter",
            REMOVE_CUSTOM_PARAMETER: "remove_custom_parameter",
            ADS_TIP_XOUT: "ads_tip_xout",
            ADS_TIP_CLICK_FEEDBACK: "ads_tip_click_feedback",
            ADVANTAGE_TOOLTIP_IMPRESSION: "advantage_tooltip_impression",
            ADVANTAGE_ICON_IMPRESSION: "advantage_icon_impression",
            API_CALL_RETRY: "api_call_retry",
            ADS_LOOKALIKE_OFFLINE_EVENT_SET_LOAD_ERROR: "ads_lookalike_offline_event_set_load_error",
            AD_AUDIENCE_SEARCH_SOURCE_LOAD_ERROR: "ad_audience_search_source_load_error",
            ADS_LOOKALIKE_APP_EVENT_SEARCH_SOURCE_SELECT_ERROR: "ads_lookalike_app_event_search_source_select_error",
            ADS_LOOKALIKE_APP_NON_VALUE_BASED_EVENT_SEARCH_SOURCE_SELECT_ERROR: "ads_lookalike_app_non_value_based_event_search_source_select_error",
            ADS_LOOKALIKE_PIXEL_EVENT_SEARCH_SOURCE_SELECT_ERROR: "ads_lookalike_pixel_event_search_source_select_error",
            CAMPAIGN_TEMPLATED_RENAME: "campaign_template_rename",
            CAMPAIGN_GROUP_TEMPLATED_RENAME: "campaign_group_template_rename",
            CF_PE_DIRECT_PUBLISH_MISSING_CFLOGGER: "cf_pe_direct_publish_missing_cflogger",
            EDIT_SOURCE: "edit_source",
            EDITOR_OPEN_IN_ADS_MANAGER_LINK_CLICKED: "editor_open_in_ads_manager_link_clicked",
            DRAFT_FRAGMENT_VALUE_INVALID_JSON: "draft_fragment_value_invalid_json",
            DRAFT_FRAGMENT_VALUE_PHP_CLOWNTOWN: "draft_fragment_value_php_clowntown",
            INVALID_TOPLINE_PRODUCT_TYPE: "invalid_topline_product_type",
            CONNECTION_STATUS_GRAPH_ERROR: "connection_status_graph_error",
            ADS_VALIDATION_WORKER_ERROR: "ads_validation_worker_error",
            INVALID_FIELD_LABEL: "invalid_field_label",
            BUDGET_CHANGE_BY_UNIFORM_VALUE: "budget_change_by_uniform_value",
            BULK_BUDGET_EDIT_APPLY: "bulk_budget_edit_apply",
            BULK_BUDGET_EDIT_CANCEL: "bulk_budget_edit_cancel",
            BULK_BUDGET_EDIT_OPEN_PREVIEW: "bulk_budget_edit_open_preview",
            OPEN_BUDGET_EDIT_DIALOG: "open_budget_edit_dialog",
            OPEN_NAME_EDIT_DIALOG: "open_name_edit_dialog",
            CLICK_CREATE_SLIDESHOW: "click_create_slideshow",
            SLIDESHOW_DIALOG_SHOW: "slideshow_dialog_show",
            SLIDESHOW_DIALOG_HIDE: "slideshow_dialog_hide",
            OPEN_CAROUSEL_REUSE_CARD: "open_carousel_reuse_card",
            CLOSE_CAROUSEL_REUSE_CARD: "close_carousel_reuse_card",
            CONFIRM_CAROUSEL_REUSE_CARD: "confirm_carousel_reuse_card",
            AUTO_CAROUSEL_ENABLE: "auto_carousel_enable",
            AUTO_CAROUSEL_START_SCRAPE: "auto_carousel_start_scrape",
            AUTO_CAROUSEL_END_SCRAPE: "auto_carousel_end_scrape",
            ERROR_FEEDBACK_RESPOND_NO: "ERROR_FEEDBACK.RESPOND_NO",
            INSTAGRAM_ENABLE_POLLING_STICKER: "instagram_enable_polling_sticker",
            INSTAGRAM_DISABLE_POLLING_STICKER: "instagram_disable_polling_sticker",
            INSTAGRAM_ACCOUNT_SELECTOR_SELECT_ACCOUNT: "instagram_account_selector_select_account",
            INSTAGRAM_ACCOUNT_SELECTOR_SELECT_PBIA: "instagram_account_selector_select_PBIA",
            INSTAGRAM_ACCOUNT_SELECTOR_OAUTH_CONNECTION_SUCCESS: "instagram_account_selector_oauth_connection_success",
            INSTAGRAM_ACCOUNT_SELECTOR_OAUTH_CONNECT_ERROR: "instagram_account_selector_oauth_connect_error",
            INSTAGRAM_ACCOUNT_SELECTOR_OAUTH_NONCE_ERROR: "instagram_account_selector_oauth_nonce_error",
            INSTAGRAM_ACCOUNT_SELECTOR_OAUTH_OPEN_ERROR: "instagram_account_selector_oauth_open_error",
            INSTAGRAM_ACCOUNT_SELECTOR_OPEN_LINK_TO_PAGE_MODAL: "instagram_account_selector_open_link_to_page_modal",
            INSTAGRAM_ACCOUNT_SELECTOR_OPEN_OAUTH: "instagram_account_selector_open_oauth",
            INSTAGRAM_ACCOUNT_SELECTOR_REMOVE_IG_PLACEMENT: "instagram_account_selector_remove_ig_placement",
            INSTAGRAM_ACCOUNT_SELECTOR_RENDER: "instagram_account_selector_render",
            INSTAGRAM_COMMENT_MODERATION_EDIT_COMMENT: "instagram_comment_moderation_edit_comment",
            INSTAGRAM_COMMENT_MODERATION_OPEN_DIALOG: "instagram_comment_moderation_open_dialog",
            INSTAGRAM_COMMENT_MODERATION_CLOSE_DIALOG: "instagram_comment_moderation_close_dialog",
            INSTAGRAM_COMMENT_MODERATION_CLICK_VIEW_ON_IG_WEB: "instagram_comment_moderation_click_view_on_ig_web",
            INSTAGRAM_COMMENT_MODERATION_SWITCH_TAB: "instagram_comment_moderation_switch_tab",
            INSTAGRAM_COMMENT_MODERATION_PBIA_VIEW: "instagram_comment_moderation_pbia_view",
            INSTAGRAM_ACCOUNT_SELECTOR_SELECT_BUSINESS_PARTNER: "instagram_account_selector_select_business_partner",
            FACEBOOK_PAGE_SELECTOR_SELECT_BUSINESS_PARTNER: "facebook_page_selector_select_business_partner",
            INSTAGRAM_INELIGIBLE_PAGE_POST_SELECTED: "instagram_ineligible_page_post_selected",
            INSTAGRAM_NUX_BLUR: "instagram_nux_blur",
            INSTAGRAM_NUX_CREATE_CAMPAIGN: "instagram_nux_create_campaign",
            INSTAGRAM_NUX_DO_NOT_SHOW_AGAIN: "instagram_nux_do_not_show_again",
            INSTAGRAM_NUX_NOT_NOW: "instagram_nux_not_now",
            INSTAGRAM_NUX_X_OUT: "instagram_nux_x_out",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_CANVAS_UNSUPPORTED: "instagram_placement_cancel_opt_out_canvas_unsupported",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_CAROUSEL_IMAGE_MISSING: "instagram_placement_cancel_opt_out_carousel_image_missing",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_CAROUSEL_VIDEO_UNSUPPORTED: "instagram_placement_cancel_opt_out_carousel_video_unsupported",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_IMAGE_CROP_TOO_SMALL: "instagram_placement_cancel_opt_out_image_crop_too_small",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_IMAGE_TOO_SMALL: "instagram_placement_cancel_opt_out_image_too_small",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_INSTAGRAM_ACCOUNT_IS_PRIVATE: "instagram_placement_cancel_opt_out_instagram_account_is_private",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_INSTAGRAM_ACCOUNT_LOAD_ERROR: "instagram_placement_cancel_opt_out_instagram_account_load_error",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_INVALID_VIDEO: "instagram_placement_cancel_opt_out_invalid_video",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_INVALID_VIDEO_FROM_BUTTON: "instagram_placement_cancel_opt_out_invalid_video_from_button",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_INVALID_VIDEO_THUMBNAIL: "instagram_placement_cancel_opt_out_invalid_video_thumbnail",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_NO_INSTAGRAM_ACCOUNT_FOR_BUSINESS: "instagram_placement_cancel_opt_out_no_instagram_account_for_business",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_PBIA_ERROR: "instagram_placement_cancel_opt_out_pbia_error",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_PROMOTABLE_POST_INELIGIBLE: "instagram_placement_cancel_opt_out_promotable_post_ineligible",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_PROMOTABLE_POST_INELIGIBLE_FROM_BUTTON: "instagram_placement_cancel_opt_out_promotable_post_ineligible_from_button",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_UNSUPPORTED_CTA: "instagram_placement_cancel_opt_out_unsupported_cta",
            INSTAGRAM_PLACEMENT_CANCEL_OPT_OUT_WRONG_IMAGE_RATIO: "instagram_placement_cancel_opt_out_wrong_image_ratio",
            INSTAGRAM_PLACEMENT_OPT_IN_EXPLICIT_AT_L2: "instagram_placement_opt_in_explicit_at_l2",
            INSTAGRAM_PLACEMENT_OPT_IN_ADD_PLACEMENT_L1_UPSELL: "instagram_placement_opt_in_add_placement_l1_upsell",
            INSTAGRAM_PLACEMENT_OPT_OUT_CAROUSEL_IMAGE_MISSING: "instagram_placement_opt_out_carousel_image_missing",
            INSTAGRAM_PLACEMENT_OPT_OUT_CAROUSEL_VIDEO_UNSUPPORTED: "instagram_placement_opt_out_carousel_video_unsupported",
            INSTAGRAM_PLACEMENT_OPT_OUT_EXPLICIT_AT_L2: "instagram_placement_opt_out_explicit_at_l2",
            INSTAGRAM_PLACEMENT_OPT_OUT_IMAGE_CROP_TOO_SMALL: "instagram_placement_opt_out_image_crop_too_small",
            INSTAGRAM_PLACEMENT_OPT_OUT_IMAGE_TOO_SMALL: "instagram_placement_opt_out_image_too_small",
            INSTAGRAM_PLACEMENT_OPT_OUT_INSTAGRAM_ACCOUNT_IS_PRIVATE: "instagram_placement_opt_out_instagram_account_is_private",
            INSTAGRAM_PLACEMENT_OPT_OUT_INSTAGRAM_ACCOUNT_LOAD_ERROR: "instagram_placement_opt_out_instagram_account_load_error",
            INSTAGRAM_PLACEMENT_OPT_OUT_INVALID_VIDEO: "instagram_placement_opt_out_invalid_video",
            INSTAGRAM_PLACEMENT_OPT_OUT_INVALID_VIDEO_FROM_BUTTON: "instagram_placement_opt_out_invalid_video_from_button",
            INSTAGRAM_PLACEMENT_OPT_OUT_INVALID_VIDEO_THUMBNAIL: "instagram_placement_opt_out_invalid_video_thumbnail",
            INSTAGRAM_PLACEMENT_OPT_OUT_NO_INSTAGRAM_ACCOUNT_FOR_BUSINESS: "instagram_placement_opt_out_no_instagram_account_for_business",
            INSTAGRAM_PLACEMENT_OPT_OUT_PROMOTABLE_POST_INELIGIBLE: "instagram_placement_opt_out_promotable_post_ineligible",
            INSTAGRAM_PLACEMENT_OPT_OUT_PROMOTABLE_POST_INELIGIBLE_FROM_BUTTON: "instagram_placement_opt_out_promotable_post_ineligible_from_button",
            INSTAGRAM_PLACEMENT_OPT_OUT_PBIA_ERROR: "instagram_placement_opt_out_pbia_error",
            INSTAGRAM_PLACEMENT_OPT_OUT_UNSUPPORTED_CTA: "instagram_placement_opt_out_unsupported_cta",
            INSTAGRAM_PLACEMENT_OPT_OUT_WRONG_IMAGE_RATIO: "instagram_placement_opt_out_wrong_image_ratio",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_AUTOMATIC_EXPLICIT: "instagram_placement_optimization_automatic_explicit",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_MANUAL_EXPLICIT: "instagram_placement_optimization_manual_explicit",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_REMOVED_DESKTOP_FEED: "instagram_placement_optimization_removed_desktop_feed",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_REMOVED_INSTAGRAM_STREAM: "instagram_placement_optimization_removed_instagram_stream",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_REMOVED_MOBILE_EXTERNAL: "instagram_placement_optimization_removed_mobile_external",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_REMOVED_MOBILE_FEED: "instagram_placement_optimization_removed_mobile_feed",
            INSTAGRAM_PLACEMENT_OPTIMIZATION_REMOVED_RIGHT_COLUMN: "instagram_placement_optimization_removed_right_column",
            CLICK_LEAD_GEN_LEARN_MORE: "click_lead_gen_learn_more",
            OPT_OUT_LEAD_GEN_TIP: "opt_out_lead_gen_tip",
            AD_MESSAGE_SHOW_MENTIONS: "ad_message_show_mentions",
            AD_MESSAGE_ADD_MENTION: "ad_message_add_mention",
            NUX_TOUR_STARTED: "nux_tour_started",
            CONVERSION_TOUR_NUX_CLOSED: "conversion_tour_nux_closed",
            CONVERSION_TOUR_NUX_VIEWED: "conversion_tour_nux_viewed",
            CONVERSION_ITEM_LIST_NUX_CLOSED: "conversion_item_list_nux_closed",
            CONVERSION_ITEM_LIST_NUX_VIEWED: "conversion_item_list_nux_viewed",
            TARGETING_INLINE_LOOKALIKE_AUDIENCE_CREATED: "targeting_inline_lookalike_audience_created",
            TARGETING_INLINE_LOOKALIKE_DIALOG_OPEN: "targeting_inline_lookalike_dialog_open",
            TARGETING_INLINE_LOOKALIKE_TIP_RENDER: "targeting_inline_lookalike_tip_render",
            TARGETING_UI_CUSTOM_AUDIENCE_ERROR: "targeting_ui_custom_audience_error",
            TARGETING_UI_CUSTOM_AUDIENCE_RENDER_UNAVAILABLE: "targeting_ui_custom_audience_render_unavailable",
            TARGETING_MTC_CUSTOM_AUDIENCE_CREATED: "targeting_mtc_custom_audience_created",
            TARGETING_MTC_SELECT_CUSTOM_AUDIENCE: "targeting_mtc_select_custom_audience",
            TARGETING_PAGE_LOCATION_CHECKBOX: "targeting_page_location_checkbox",
            DELIVERY_ESTIMATE_LOADED_WITHOUT_PREDICTION: "delivery_estimate_loaded_without_prediction",
            DELIVERY_ESTIMATE_NO_TARGETING_SPEC: "delivery_estimate_no_targeting_spec",
            REACH_ESTIMATE_LOADED_WITHOUT_PREDICTION: "reach_estimate_loaded_without_prediction",
            OUTCOME_PREDICTION_SURVEY_RESPONSE_YES: "outcome_prediction_survey_response_yes",
            OUTCOME_PREDICTION_SURVEY_RESPONSE_NO: "outcome_prediction_survey_response_no",
            OUTCOME_PREDICTION_SURVEY_RESPONSE_SOMEWHAT: "outcome_prediction_survey_response_somewhat",
            OUTCOME_PREDICTION_SURVEY_ERROR: "outcome_prediction_survey_error",
            PLACEMENT_ACTION: "placement_action",
            PLACEMENT_ADD: "placement_add",
            PLACEMENT_ADD_BLOCK_LIST: "placement_add_block_list",
            PLACEMENT_ADD_DEVICE: "placement_add_device",
            PLACEMENT_ADD_EXCLUDED_CATEGORIES: "placement_add_excluded_categories",
            PLACEMENT_AN_LINK_CLICK: "placement_an_link_click",
            PLACEMENT_BULK_EDIT_ADD_POSITION: "placement_bulk_edit_add_position",
            PLACEMENT_BULK_EDIT_REMOVE_POSITION: "placement_bulk_edit_remove_position",
            PLACEMENT_BULK_EDIT_SET_AUTO: "placement_bulk_edit_set_auto",
            PLACEMENT_COLLAPSE_PLATFORM: "placement_collapse_platform",
            PLACEMENT_EXPAND_PLATFORM: "placement_expand_platform",
            PLACEMENT_EXPAND_ADVANCED_OPTION_BLOCK_LIST: "placement_expand_advanced_option_block_list",
            PLACEMENT_EXPAND_ADVANCED_OPTION_DEVICE: "placement_expand_advanced_option_device",
            PLACEMENT_EXPAND_ADVANCED_OPTION_CONTENT_FILTER: "placement_expand_advanced_option_content_filter",
            PLACEMENT_REMOVE: "placement_remove",
            PLACEMENT_REMOVE_BLOCK_LIST: "placement_remove_block_list",
            PLACEMENT_REMOVE_DEVICE: "placement_remove_device",
            PLACEMENT_RESET: "placement_reset",
            PLACEMENT_SET_DEVICE_PLATFORM: "placement_set_device_platform",
            PLACEMENT_SET_DEVICE_TYPE: "placement_set_device_type",
            PLACEMENT_SET_MAX_OS_VERSION: "placement_set_max_os_version",
            PLACEMENT_SET_MIN_OS_VERSION: "placement_set_min_os_version",
            PLACEMENT_SET_WIRELESS_CARRIER: "placement_set_wireless_carrier",
            PLACEMENT_SWITCH_TO_MANUAL: "placement_switch_to_manual",
            PLACEMENT_CONTENT_FILTER_OPEN_SUBSECTION: "placement_content_filter_open_subsection",
            PLACEMENT_CONTENT_FILTER_SELECT: "placement_content_filter_select",
            PLACEMENT_CONTENT_FILTER_OPEN_MODAL: "placement_content_filter_open_modal",
            PLACEMENT_ADD_EXCLUDED_BRAND_SAFETY_CONTENT_TYPES: "placement_add_excluded_brand_safety_content_types",
            PLACEMENT_REMOVE_EXCLUDED_BRAND_SAFETY_CONTENT_TYPES: "placement_remove_excluded_brand_safety_content_types",
            PLACEMENT_BLOCK_LISTS_LOAD_ERROR: "placement_block_lists_load_error",
            PLACEMENT_DCS_LOAD_ERROR: "placement_dcs_load_error",
            PLACEMENT_ALLOWED_BLOCK_LISTS_LOAD_ERROR: "placement_allowed_block_lists_load_error",
            PLACEMENT_NEGATIVE_KEYWORD_LISTS_LOAD_ERROR: "placement_negative_keyword_lists_load_error",
            MESSENGER_UPSELL_DIALOG: "messenger_upsell_dialog",
            MULTI_PRODUCT_SELECT_INDEX: "multi_product_select_index",
            RF_INIT_FLOW: "rf_init",
            RF_CHANGE_REACH: "rf_change_reach",
            RF_CHANGE_BUDGET: "rf_change_budget",
            RF_CHANGE_FREQUENCY: "rf_change_frequency",
            RF_CHANGE_DATE: "rf_change_date",
            RF_CHANGE_DATE_START: "rf_change_date_start",
            RF_CHANGE_DATE_STOP: "rf_change_date_stop",
            RF_CHANGE_DAY_PARTING_SCHEDULE: "rf_change_day_parting_schedule",
            RF_CHANGE_DESTINATION: "rf_change_destination",
            RF_CHANGE_Y_AXIS: "rf_change_y_axis",
            RF_CHANGE_TARGETING: "rf_change_targeting",
            RF_RESET_PLACEMENT_TO_AUTO: "rf_reset_placement_to_auto",
            RF_RESET_PLACEMENT_TO_MANUAL: "rf_reset_placement_to_manual",
            RF_CHANGE_PLACEMENT: "rf_change_placement",
            RF_CONFIRM_SEQUENCE: "rf_confirm_sequence",
            RF_PREDICTION_SUCCESS: "rf_prediction_success",
            RF_PREDICTION_START: "rf_prediction_start",
            RF_ERRORS: "rf_errors",
            RF_ERRORS_ON_CLOSE_CF: "rf_errors_on_close_cf",
            RF_EXPORT_CURVE: "rf_export_curve",
            RF_USE_FREQUENCY_CURVE: "rf_use_frequency_curve",
            RF_USE_PLACEMENT_CURVE: "rf_use_placement_curve",
            RF_USE_SPEND_CURVE: "rf_use_spend_curve",
            RF_START_EDIT_TARGET: "rf_start_edit_target",
            RF_DONE_EDIT_TARGET: "rf_done_edit_target",
            RF_REFRESH_TARGET: "rf_refresh_target",
            RF_CHANGE_EDIT_MODE: "rf_change_edit_mode",
            RF_ADD_INSTAGRAM_PLACEMENT: "rf_add_instagram_placement",
            RF_REMOVE_INSTAGRAM_PLACEMENT: "rf_remove_instagram_placement",
            RF_CHANGE_STORY_EVENT_TYPE: "rf_change_story_event_type",
            RF_CHANGE_INSTAGRAM_DESTINATION: "rf_change_ig_destination",
            RF_CHANGE_RESET_PERIOD: "rf_change_reset_period",
            RF_CHANGE_IS_BONUS_MEDIA: "rf_change_is_bonus_media",
            RF_CHANGE_IS_EDITING_PLACEMENT: "rf_change_is_editing_placement",
            RF_CHANGE_IS_FULL_VIEW: "rf_change_is_full_view",
            RF_RESET_PERIOD_ERROR_SHOWN: "rf_reset_period_error_shown",
            RF_CHANGE_OBJECTIVE_TYPE: "rf_change_objective_type",
            RF_CHANGE_SAVED_AUDIENCE: "rf_change_saved_audience",
            RF_CLICK_L2_PREDICTABLE_RESULTS_LINK: "rf_click_l2_predictable_results_link",
            RF_CLICK_L2_TAB_NUX_LINK: "rf_click_l2_tab_nux_link",
            RF_CREATE_NEW_SAVED_AUDIENCE: "rf_create_new_saved_audience",
            RF_SET_PAUSE_PERIOD_ESTIMATE: "rf_set_pause_period_estimate",
            RF_UPDATE_EXPORT_SELECTION: "rf_update_export_selection",
            RF_UPDATE_REACH_CURVE_SELECTION: "rf_update_reach_curve_selection",
            RF_CLICK_UNDER_DELIVERY_LINK: "rf_click_under_delivery_link",
            RF_SELECT_BALANCED_OPTION_FOR_RF_BALANCE: "rf_select_balanced_option_for_rf_balance",
            RF_SELECT_CUMULATIVE_FREQUENCY_CURVE_FREQUENCIES: "rf_select_cumulative_frequency_curve_frequencies",
            RF_SELECT_VIDEO_VIEW_PREDICTABLE_RESULT: "rf_select_video_view_predictable_result",
            RF_UPLOAD_CREATIVE_ASSETS_CREATION_FLOW: "rf_upload_creative_assets_creation_flow",
            RF_GO_BACK_TO_AD_FORMAT_PLAN_CREATION_FLOW: "rf_go_back_to_ad_format_plan_creation_flow",
            RF_GO_BACK_TO_AD_FORMAT_PLAN_EDITING_FLOW: "rf_go_back_to_ad_format_plan_editing_flow",
            RF_INIT_NEW: "rf_init_new",
            RF_SELECT_CUSTOM_OPTION_FOR_RF_BALANCE: "rf_select_custom_option_for_rf_balance",
            RF_CHANGE_FREQUENCY_CAP_IN_CUSTOM_OPTION: "rf_change_frequency_cap_in_custom_option",
            RF_CHANGE_RESET_PERIOD_IN_CUSTOM_OPTION: "rf_change_reset_period_in_custom_option",
            RF_TOGGLE_ON_HIGHER_AVERAGE_FREQUENCY: "rf_toggle_on_higher_average_frequency",
            RF_TOGGLE_OFF_HIGHER_AVERAGE_FREQUENCY: "rf_toggle_off_higher_average_frequency",
            RF_CLICK_ADSET_CONTINUE_BUTTON: "rf_click_adset_continue_button",
            FREQUENCY_CONTROL_RESET: "frequency_control_reset",
            FREQUENCY_CONTROL_SELECT_BALANCED_OPTION: "frequency_control_select_balanced_option",
            FREQUENCY_CONTROL_SELECT_HIGHER_REACH_OPTION: "frequency_control_select_higher_reach_option",
            FREQUENCY_CONTROL_SELECT_HIGHER_FREQUENCY_OPTION: "frequency_control_select_higher_frequency_option",
            FREQUENCY_CONTROL_SELECT_CUSTOM_OPTION: "frequency_control_select_custom_option",
            FREQUENCY_CONTROL_SELECT_CUSTOM_OPTION_AND_EDIT: "frequency_control_select_custom_option_and_edit",
            FREQUENCY_CONTROL_SELECT_AUTOMATIC_OPTION: "frequency_control_select_automatic_option",
            FREQUENCY_CONTROL_PUBLICH_WITH_BALANCED_OPTION: "frequency_control_publish_with_balanced_option",
            FREQUENCY_CONTROL_PUBLISH_WITH_HIGHER_REACH_OPTION: "frequency_control_publish_with_higher_reach_option",
            FREQUENCY_CONTROL_PUBLISH_WITH_HIGHER_FREQUENCY_OPTION: "frequency_control_publish_with_higher_frequency_option",
            FREQUENCY_CONTROL_PUBLISH_WITH_CUSTOM_OPTION: "frequency_control_publish_with_custom_option",
            FREQUENCY_CONTROL_PUBLISH_WITH_AUTOMATIC_OPTION: "frequency_control_publish_with_automatic_option",
            RF_PLANNER_FB_BULK_SELECTED: "rf_planner_fb_bulk_selected",
            RF_PLANNER_INSTAGRAM_BULK_SELECTED: "rf_planner_instagram_bulk_selected",
            RF_PLANNER_CREATION_AUDIENCE_SELECTED: "rf_planner_creation_audience_selected",
            RF_PLANNER_CREATION_AUDIENCE_SAVED: "rf_planner_creation_audience_saved",
            DELIVERY_SELECT_AUCTION_OPTION: "select_auction_delivery_option_tab",
            DELIVERY_SELECT_RF_OPTION: "select_predictable_rf_delivery_option_tab",
            PLANNER_CHANGE_LOCAL_START_DATE: "planner_change_local_start_date",
            PLANNER_CHANGE_LOCAL_END_DATE: "planner_change_local_end_date",
            PLANNER_CHANGE_NONTEXT_FILTER: "planner_change_nontext_filter",
            PLANNER_CHANGE_TEXT_FILTER: "planner_change_text_filter",
            PLANNER_CREATE_PLAN: "planner_create_plan",
            PLANNER_DELETE_TEXT_FILTER: "planner_delete_text_filter",
            PLANNER_DELETE_PLAN_SUCCESS: "planner_delete_plan_success",
            PLANNER_DELETE_VERSION_SUCCESS: "planner_delete_version_success",
            PLANNER_FILTER_BAR_EXPANDED: "planner_filter_bar_expanded",
            PLANNER_GET_PACKAGE_VIDEOS_METADATA_FAILURE: "planner_get_package_videos_metadata_failure",
            PLANNER_GET_PACKAGE_VIDEOS_METADATA_SUCCESS: "planner_get_package_videos_metadata_success",
            PLANNER_HEADER_PURCHASE_CLICK: "planner_header_purchase_click",
            PLANNER_PURCHASE_TABLE_NEXT_CLICK: "planner_table_next_click",
            PLANNER_PLAN_CREATION_COMPLETED: "planner_plan_creation_completed",
            PLANNER_TOGGLE_IS_EXPANDED: "planner_toggle_is_expanded",
            PLANNER_TOGGLE_RIGHT_COLUMN_GRPAH_EXPAND_STATE: "planner_toggle_right_column_graph_expand_state",
            PLANNER_DOWNLOAD_FACEBOOK_INSTREAM_VIDEO_PUBLISHERS_LIST: "planner_download_facebook_instream_video_publishers_list",
            PLANNER_RESERVE_TRP_VERSION_SUCCESS: "planner_reserve_trp_version_success",
            PLANNER_PURCHASE_TRP_PLAN: "planner_purchase_trp_plan",
            PLANNER_PURCHASE_TRP_PLAN_SUCCESS: "planner_purchase_trp_plan_success",
            PLANNER_PURCHASE_TRP_PLAN_ERROR: "planner_purchase_trp_plan_error",
            PLANNER_SAVE_CONTENT_PACKAGE: "planner_save_content_package",
            PLANNER_SAVE_SHARED_PLAN: "planner_save_shared_plan",
            PLANNER_SELECT_CURRENCY_IN_PLAN_CREATION: "planner_select_currency_in_plan_creation",
            PLANNER_SELECT_BUDGET_IN_PLAN_CREATION: "planner_select_budget_in_plan_creation",
            PLANNER_SELECT_REACH_IN_PLAN_CREATION: "planner_select_reach_in_plan_creation",
            PLANNER_SELECT_TRP_IN_PLAN_CREATION: "planner_select_trp_in_plan_creation",
            PLANNER_START_CAMPAIGN_CREATION: "planner_start_campaign_creation",
            PLANNER_SYNC_PLANS_ERROR: "planner_sync_plans_error",
            PLANNER_SYNC_PLANS_START: "planner_sync_plans_start",
            PLANNER_SYNC_PLANS_SUCCESS: "planner_sync_plans_success",
            PLANNER_SYNC_PLAN_VERSIONS_ERROR: "planner_sync_plan_versions_error",
            PLANNER_SYNC_PLAN_VERSIONS_START: "planner_sync_plan_versions_start",
            PLANNER_SYNC_PLAN_VERSIONS_SUCCESS: "planner_sync_plan_versions_success",
            PLANNER_UPDATE_REACH_CURVE_SELECTION: "planner_update_reach_curve_selection",
            PLANNER_VERSION_TABLE_PURCHASE_CLICK: "planner_version_table_purchase_click",
            PLANNER_UNKNOWN: "planner_unknown",
            CRST_AD_FROM_MOCKUP_CREATED: "crst_ad_from_mockup_created",
            IMAGE_LIB_UPLOAD_SUCCESS: "image_lib_upload_success",
            IMAGE_LIB_UPLOAD_ERROR: "image_lib_upload_error",
            VIDEO_LIB_CLOSE_SELECTOR: "video_lib_close_selector",
            VIDEO_LIB_OPEN_SELECTOR: "video_lib_open_selector",
            VIDEO_LIB_START_UPLOAD: "video_lib_start_upload",
            VIDEO_LIB_CANCEL_UPLOAD: "video_lib_cancel_upload",
            VIDEO_LIB_TAB_SWITCH: "video_lib_tab_switch",
            VIDEO_LIB_UPLOAD_SUCCESS: "video_lib_upload_success",
            VIDEO_LIB_UPLOAD_ERROR: "video_lib_upload_error",
            VIDEO_LIB_ENCODING_SUCCESS: "video_lib_encoding_success",
            VIDEO_LIB_VIDEO_USED_IN_POST: "video_lib_video_used_in_post",
            VIDEO_LIB_VIDEO_CAPTION_EDITOR_OPENED: "video_lib_video_caption_editor_opened",
            VIDEO_LIB_VIDEO_CAPTION_PUBLISHED: "video_lib_video_caption_published",
            VIDEO_LIB_INSTAGRAM_VIDEO_START_UPLOAD: "video_lib_instagram_video_start_upload",
            PERF_SCENARIO_START: "perf_scenario_start",
            PERF_SCENARIO_SUCCEED: "perf_scenario_succeed",
            PERF_SCENARIO_ABANDON: "perf_scenario_abandon",
            PERF_SCENARIO_FAIL: "perf_scenario_fail",
            PERF_SCENARIO_TIMEOUT: "perf_scenario_timeout",
            PERF_SCENARIO_INVALID: "perf_scenario_invalid",
            COLUMN_SET_EDITOR_CHANGE_ATTRIBUTION_WINDOWS: "column_set_editor_change_attribution_windows",
            COLUMN_SET_EDITOR_TOGGLE_ALL_COLUMNS: "column_set_editor_toggle_all_columns",
            COLUMN_SET_EDITOR_TOGGLE_ATTRIBUTION_WINDOW_SELECTOR: "column_set_editor_toggle_attribution_window_selector",
            INSIGHTS_SELECT_CATEGORY: "insights_select_category",
            INSIGHTS_TABLE_TOGGLE_COLUMN_SELECTOR: "insights_table_toggle_column_selector",
            INSIGHTS_TABLE_TOGGLE_COLUMN_SET_EDITOR: "insights_table_toggle_column_set_editor",
            INSIGHTS_SEARCH_METRIC: "insights_search_metric",
            ADS_COLUMN_SET_EDITOR_READY: "ads_column_set_editor_ready",
            CHANGE_CUSTOM_EVENT_TYPE: "change_custom_event_type",
            CHANGE_OPTIMIZATION_GOAL: "change_optimization_goal",
            FEATURE_PREFERENCE_CHANGE: "feature_preference_change",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_MOUNTED: "instream_only_contextual_targeting.mounted",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_CHANGE_TOPICS: "instream_only_contextual_targeting.change_topics",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_RENDER_ERROR: "instream_only_contextual_targeting.render_error",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_SECTION_SHOWN: "instream_only_contextual_targeting.section_shown",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_LOW_REACH_WARNING: "instream_only_contextual_targeting.low_reach_warning",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_CHANGE_PLACEMENT: "instream_only_contextual_targeting.change_placement",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_INELIGIBLE_ACCOUNT: "instream_only_contextual_targeting.ineligible_account",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_INELIGIBLE_GK: "instream_only_contextual_targeting.ineligible_gk",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_INELIGIBLE_OBJECTIVE: "instream_only_contextual_targeting.ineligible_objective",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_INELIGIBLE_PLACEMENT: "instream_only_contextual_targeting.ineligible_placement",
            INSTREAM_ONLY_CONTEXTUAL_TARGETING_SECTION_INELIGIBLE_TARGETING_COUNTRIES: "instream_only_contextual_targeting.ineligible_targeting_countries",
            INSTREAM_RESERVE_SELF_SERVE_INELIGIBLE_GK: "instream_reserve_self_serve.ineligible_gk",
            INSTREAM_RESERVE_SELF_SERVE_INELIGIBLE_OBJECTIVE: "instream_reserve_self_serve.ineligible_objective",
            INSTREAM_RESERVE_SELF_SERVE_INELIGIBLE_PLACEMENTS: "instream_reserve_self_serve.ineligible_placements",
            INSTREAM_RESERVE_SELF_SERVE_INELIGIBLE_FORMATS: "instream_reserve_self_serve.ineligible_formats",
            INSTREAM_RESERVE_SELF_SERVE_INELIGIBLE_PACKAGES: "instream_reserve_self_serve.ineligible_packages",
            INSTREAM_RESERVE_SELF_SERVE_INELIGIBLE_TARGET_COUNTRIES: "instream_reserve_self_serve.ineligible_target_countries",
            INSTREAM_RESERVE_SELF_SERVE_SELECTOR_SHOWN: "instream_reserve_self_serve.selector_shown",
            INSTREAM_RESERVE_SELF_SERVE_CHANGE_PACKAGE: "instream_reserve_self_serve.change_package",
            INSTREAM_RESERVE_SELF_SERVE_RENDER_ERROR: "instream_reserve_self_serve.render_error",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_APPLIED: "instream_videos.default_opt_in_applied",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_DIALOG_XOUT: "instream_videos.default_opt_in.dialog_xout",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_CAMPAIGN_DUPLICATED: "instream_videos.default_opt_in.campaign_duplicated",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_BULK_CAMPAIGN_DUPLICATED: "instream_videos.default_opt_in.bulk_campaign_duplicated",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_CAMPAIGN_GROUP_DUPLICATED: "instream_videos.default_opt_in.campaign_group_duplicated",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_ELIGIBLE_BUT_CANCELLED: "instream_videos.default_opt_in.eligible_but_cancelled",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_EXCLUDE_BUTTON_CLICKED: "instream_videos.default_opt_in.exclude_button_clicked",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_EXCLUDE_LINK_CLICKED: "instream_videos.default_opt_in.exclude_link_clicked",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_KEEP_BUTTON_CLICKED: "instream_videos.default_opt_in.keep_button_clicked",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_LEARN_MORE_LINK_CLICKED: "instream_videos.default_opt_in.learn_more_link_clicked",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_PLACEMENT_MANUALLY_REMOVED: "instream_videos.default_opt_in.placement_manually_removed",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_TIP_SHOWN: "instream_videos.default_opt_in.tip_shown",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_TIP_XOUT: "instream_videos.default_opt_in.tip_xout",
            INSTREAM_VIDEOS_DEFAULT_OPT_IN_CELL_TYPE_LOAD_ERROR: "instream_videos.default_opt_in.cell_type_load_error",
            INSTREAM_VIDEOS_CATEGORY_SELECTOR_SELECT_CATEGORY: "instream_videos_category_selector_select_category",
            BETA_OPT_IN: "beta_opt_in",
            BETA_OPT_OUT: "beta_opt_out",
            VIEW_ALL_RELEASE_NOTES: "view_all_release_notes",
            AHG_LINK_CLICK: "ahg_link_click",
            ADGROUP_PREVIEW_COMPONENT_DISABLED: "adgroup_preview_component_disabled",
            ADGROUP_PREVIEW_COMPONENT_ENABLED: "adgroup_preview_component_enabled",
            ADGROUP_PREVIEW_COMPONENT_ADGROUP_INDEX_CHANGE: "adgroup_preview_component_adgroup_index_change",
            ADGROUP_PREVIEW_DISPLAY_TYPE_CHANGE_AD: "adgroup_preview_display_type_change_ad",
            ADGROUP_PREVIEW_DISPLAY_TYPE_CHANGE_MESSAGING: "adgroup_preview_display_type_change_messaging",
            ADGROUP_PREVIEW_OPTIONS_SELECT_ITEM: "preview_options_select_item",
            ADGROUP_PREVIEW_OPTIONS_DROPDOWN_OPENED: "preview_options_dropdown_opened",
            ADGROUP_PREVIEW_REFRESH_CLICK: "adgroup_preview_refresh_click",
            ADGROUP_PREVIEW_FORMAT_DROPDOWN_OPENED: "preview_format_dropdown_opened",
            ADGROUP_PREVIEW_RENDER_TYPE_CHANGE: "preview_render_type_change",
            ADGROUP_PREVIEW_BUG_REPORT_OPENED: "adgroup_preview_bug_report_opened",
            ADGROUP_PREVIEW_BUG_REPORT_CLOSED: "adgroup_preview_bug_report_closed",
            ADGROUP_PREVIEW_BUG_REPORT_SUBMIT_SUCCESS: "adgroup_preview_bug_report_submit_success",
            ADGROUP_PREVIEW_BUG_REPORT_SUBMIT_ERROR: "adgroup_preview_bug_report_submit_error",
            ADGROUP_PREVIEW_BUG_REPORT_INTERNAL_ATTACHMENT_UPLOAD_ERROR: "agroup_preview_bug_report_internal_attachment_upload_error",
            REASON_VIDEO_TABLE_VIEW_MOUNTED: "reason_video_table_view_mounted",
            HEC_CERTIFICATION_LOADING_DIALOG_SHOWN: "hec_certification_loading_dialog_shown",
            REGULATED_CATEGORY_CHECKBOX_SHOWN: "regulated_category_checkbox_shown",
            REGULATED_CATEGORY_LEARN_MORE_SHOWN: "regulated_category_learn_more_shown",
            REGULATED_CATEGORY_SELECTOR_SELECTED: "regulated_category_selector_selected",
            REGULATED_CATEGORY_AD_REJECTED: "regulated_category_ad_rejected",
            REGULATED_CATEGORY_COUNTRY_SELECTOR_SHOWN: "regulated_category_country_selector_shown",
            REGULATED_CATEGORY_COUNTRY_SELECTOR_SELECTED: "regulated_category_country_selector_selected",
            AM_MEGAPHONE_CHANNEL_MESSAGES_RENDERED: "am_megaphone_channel_messages_rendered",
            BULK_CAMPAIGN_GROUP_BUDGET_ELIGIBILITY: "bulk_campaign_group_budget_eligibility",
            TOGGLE_ON_CAMPAIGN_GROUP_BUDGET_BULK_ADOPTION_DIALOG: "toggle_on_campaign_group_budget_bulk_adoption_dialog",
            TOGGLE_OFF_CAMPAIGN_GROUP_BUDGET_BULK_ADOPTION_DIALOG: "toggle_off_campaign_group_budget_bulk_adoption_dialog",
            BUDGET_LIQUIDITY_FOLLOW_UP_CARD_SHOWN: "budget_liquidity_follow_up_card_shown",
            OPEN_ADS_MANAGER_FROM_CBO_UPSELL_EMAIL: "open_ads_manager_from_cbo_upsell_email",
            OPEN_CAMPAIGN_GROUP_EDITING_FROM_CBO_UPSELL_EMAIL: "open_campaign_group_editing_from_cbo_upsell_email",
            TOGGLE_ON_CAMPAIGN_GROUP_BUDGET_IN_MID_FLIGHT_UPSELLED_FROM_EMAIL: "toggle_on_campaign_group_budget_in_mid_flight_upselled_from_email",
            OPT_OUT_CAMPAIGN_GROUP_BUDGET_DEFAULT_ON: "opt_out_campaign_group_budget_default_on",
            ADS_MANAGER_BANNER_MESSAGES_RENDERED: "ads_manager_banner_messages_rendered",
            ADS_MANAGER_BANNER_MESSAGE_RENDER: "ads_manager_banner_message_render",
            ADS_MANAGER_BANNER_MESSAGES_SHOW_MORE: "ads_manager_banner_messages_show_more",
            ADS_MANAGER_BANNER_MESSAGES_SHOW_LESS: "ads_manager_banner_messages_show_less",
            ADS_MANAGER_BANNER_MESSAGES_DISMISS: "ads_manager_banner_messages_dismiss",
            ADS_MANAGER_BANNER_MESSAGES_PRIMARY_CTA_CLICK: "ads_manager_banner_messages_primary_cta_click",
            ADS_MANAGER_BANNER_MESSAGES_SECONDARY_CTA_CLICK: "ads_manager_banner_messages_secondary_cta_click",
            ADS_PE_TOP_ERROR_IMPRESSION: "ads_pe_top_error_impression",
            AD_DISCLAIMER_FIELD_SHOWN: "ad_disclaimer_field_shown",
            AD_DISCLAIMER_FIELD_CHECKBOX_CLICK: "ad_disclaimer_field_checkbox_click",
            AD_DISCLAIMER_FIELD_SELECT_TITLE: "ad_disclaimer_field_select_title",
            AD_DISCLAIMER_FIELD_SELECT_CONTENT_TYPE: "ad_disclaimer_field_select_content_type",
            AD_DISCLAIMER_FIELD_IMPORT_FROM_CREATIVE_HUB: "ad_disclaimer_field_import_from_creative_hub",
            SYD_MARKETING_EXPERT_REQUEST_LIVE_CALL: "syd_marketing_expert_request_live_call",
            SYD_MARKETING_EXPERT_REQUEST_LIVE_CALL_CONFIRM: "syd_marketing_expert_request_live_call_confirm",
            SYD_MARKETING_EXPERT_REQUEST_LIVE_CALL_SUCCESS: "syd_marketing_expert_confirm_request_live_call_success",
            SYD_MARKETING_EXPERT_EDIT_SCHEDULE_CALL_NATIVE_BOOKING: "syd_marketing_expert_edit_schedule_call_native_booking",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING: "syd_marketing_expert_schedule_call_native_booking",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_CONTACT_INFO_CONFIRM: "syd_marketing_expert_schedule_call_native_booking_contact_info_confirm",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_CONTACT_INFO_CANCEL: "syd_marketing_expert_schedule_call_native_booking_contact_info_cancel",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_TIME_SELECT_CONFIRM: "syd_marketing_expert_schedule_call_native_booking_time_select_confirm",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_TIME_SELECT_CONFIRM_SUCCESS: "syd_marketing_expert_schedule_call_native_booking_time_select_confirm_success",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_TIME_SELECT_CONFIRM_FORESEEN_ERROR: "syd_marketing_expert_schedule_call_native_booking_time_select_confirm_foreseen_error",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_TIME_SELECT_CONFIRM_UNFORESEEN_ERROR: "syd_marketing_expert_schedule_call_native_booking_time_select_confirm_unforeseen_error",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_CANCEL_CALL_SUCCESS: "syd_marketing_expert_native_booking_cancel_call_success",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_CANCEL_CALL_FORESEEN_ERROR: "syd_marketing_expert_native_booking_cancel_call_foreseen_error",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_CANCEL_CALL_UNFORESEEN_ERROR: "syd_marketing_expert_native_booking_cancel_call_unforeseen_error",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_OPEN_CALL_CANCELLATION_MODAL: "syd_marketing_expert_native_booking_open_call_cancellation_modal",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_CANCELLATION_MODAL_CANCEL: "syd_marketing_expert_native_booking_cancellation_modal_cancel",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_CANCELLATION_MODAL_CONFIRM: "syd_marketing_expert_native_booking_cancellation_modal_confirm",
            SYD_MARKETING_EXPERT_SCHEDULE_CALL_NATIVE_BOOKING_TIME_SELECT_CANCEL: "syd_marketing_expert_schedule_call_native_booking_time_select_cancel",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_UNABLE_PULL_TIMESLOTS: "syd_marketing_expert_native_booking_unable_pull_timeslots",
            SYD_MARKETING_EXPERT_NATIVE_BOOKING_UNABLE_PULL_MEETING_LENGTH: "syd_marketing_expert_native_booking_unable_pull_meeting_length",
            SYD_MARKETING_EXPERT_WIDGET_LOADED: "syd_marketing_expert_widget_loaded",
            SYD_MARKETING_EXPERT_WIDGET_NOT_LOADED: "syd_marketing_expert_widget_not_loaded",
            SYD_MARKETING_EXPERT_VIEW_MARKETING_PLAN_STORY: "syd_marketing_expert_view_marketing_plan_story",
            SYD_MARKETING_EXPERT_WIDGET_ERROR: "syd_marketing_expert_widget_error",
            SYD_MARKETING_EXPERT_WIDGET_BODY_TEXT_IS_SHOWN: "syd_marketing_expert_widget_body_text_is_shown",
            SEGMENTATION_ROUTING_MODAL_IMPRESSION: "routing.modal_impression",
            SEGMENTATION_ROUTING_MODAL_CLICK: "routing.modal_click",
            SEGMENTATION_ROUTING_SIDEBAR_POPOVER: "routing.sidebar_popover",
            SEGMENTATION_ROUTING_SIDEBAR_CLICK: "routing.sidebar_click",
            SEGMENTATION_ROUTING_TOAST_IMPRESSION: "routing.toast_impression",
            SEGMENTATION_ROUTING_TOAST_CLICK: "routing.toast_click",
            SBG_CONTACTABILITY_FORM_IMPRESSION: "sbg_contactability_form_impression",
            SBG_CONTACTABILITY_FORM_SUBMISSION_SUCCESSFUL: "sbg_contactability_form_submission_successful",
            SBG_CONTACTABILITY_FORM_SUBMISSION_ERROR: "sbg_contactability_form_submission_error",
            ADS_SUPPORT_FORM_LINK_CLICK: "ads_support_form_link_click",
            YOUTH_ADS_ENFORCEMENT_NOTICE_RENDER: "youth_ads_enforcement_notice_render",
            YOUTH_ADS_ENFORCEMENT_LEARN_MORE_CLICK: "youth_ads_enforcement_learn_more_click",
            YOUTH_ADS_ENFORCEMENT_INLINE_ERROR_RENDER: "youth_ads_enforcement_inline_error_render",
            YOUTH_ADS_ENFORCEMENT_DISABLED_OPTION_POPOVER_RENDER: "youth_ads_enforcement_disabled_option_popover_render",
            ADS_RCM_ANNOUNCEMENT_BANNER_RENDER: "ads_rcm_announcement_banner_render",
            ADS_RCM_ANNOUNCEMENT_BANNER_CTA_CLICK: "ads_rcm_announcement_banner_cta_click",
            ADS_L2_RIGHT_RAIL_IOS15_IMPACT_NOTICE_RENDERED: "ads_l2_right_rail_ios15_impact_notice_rendered"
        },
        EventCategory: {
            AD_EDIT: "ad_edit",
            CAMPAIGN_EDIT: "campaign_edit",
            CAMPAIGN_GROUP_EDIT: "campaign_group_edit",
            ERROR: "errors",
            INSTAGRAM_PLACEMENT_ADOPTION: "instagram_placement_adoption",
            INSTREAM_VIDEOS_PLACEMENT_ADOPTION: "instream_videos_placement_adoption",
            PERFORMANCE: "performance",
            PERFORMANCE_PREVIEW_CS: "performance_preview_cs",
            PERFORMANCE_CLIENT_SIDE_MINI_PREVIEW: "performance_client_side_mini_preview",
            PLANNER: "planner",
            PRELOADING: "preloading",
            REACH_FREQUENCY_SHEET: "reach_frequency_sheet",
            USER_ACTION: "user_action"
        }
    })
}), null);
__d("AdsMgmtPreloadingUtils", ["AdsInterfacesLoggerUtils", "Promise", "cr:1612590", "gkx", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = !1,
        i = !1,
        j = !1,
        k = !1,
        l = null,
        m, n = new(b("Promise"))(function(a) {
            m = a
        });

    function a() {
        return l
    }

    function e() {
        return k
    }

    function f() {
        return n
    }

    function o(a) {
        h = a
    }

    function p() {
        i = !0, h && m()
    }

    function q(a) {
        var d;
        l = (d = l) != null ? d : c("performanceAbsoluteNow")();
        j = !0;
        b("cr:1612590") != null && b("cr:1612590").setStopPreloadingTimestamp(l);
        a && (k = !0);
        h || m()
    }

    function r() {
        var a = h ? !i : !j && c("gkx")("677981");
        return b("cr:1612590") != null ? b("cr:1612590").isScenarioOngoingTestVersion() || a : a
    }
    d = {
        isScenarioOngoing: r,
        log: d("AdsInterfacesLoggerUtils").logPreloading
    };
    g.getStopPreloadingTime = a;
    g.hasFinishedSuccessfully = e;
    g.onPreloadingDone = f;
    g.setScenarioDefinedByVC = o;
    g.onVisualCompletion = p;
    g.stopPreloading = q;
    g.isScenarioOngoing = r;
    g.defaultConfig = d
}), 98);
__d("XAdsAccountExperimentsController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/adsmanager/{account_id}/gks/", {
        account_id: {
            type: "Int",
            required: !0
        },
        business_id: {
            type: "FBID"
        }
    })
}), null);
__d("objectToMap", ["forEachObject"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = new Map();
        c("forEachObject")(a, function(a, c) {
            b.set(c, a)
        });
        return b
    }
    g["default"] = a
}), 98);
__d("preloadedAsyncRequest", ["Promise", "URI", "clearTimeout", "regeneratorRuntime", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d = !1;
    var h = function(a) {};

    function i(a) {
        return a.getMethod() !== "GET" ? a.getURI() : new(c("URI"))(a.getURI()).addQueryData(a.getData()).toString()
    }

    function j(a, d, e) {
        var g, j, k, l, m, n, o, p, q, r;
        return b("regeneratorRuntime").async(function(f) {
            while (1) switch (f.prev = f.next) {
                case 0:
                    k = a.preloader;
                    l = i(d);
                    h("Request URI = " + l);
                    h("Preload URI = " + ((g = a.uri) != null ? g : "<NULL>"));
                    if (!(k == null || l !== a.uri)) {
                        f.next = 7;
                        break
                    }
                    h(l + ": Preloaded data NOT available (preload URI doesn't match)");
                    return f.abrupt("return", d.promisePayload().then(function(a) {
                        h(l + ": AsyncRequest completed");
                        return a
                    }));
                case 7:
                    h(l + ": Preload URL matches request URL, preloading can be used!");
                    m = (j = k.peek()) == null ? void 0 : j.data;
                    if (!(m != null)) {
                        f.next = 12;
                        break
                    }
                    h(l + ": Preloaded data was available");
                    return f.abrupt("return", e(m));
                case 12:
                    h(l + ": Preloaded data not available yet");
                    n = null;
                    o = !1;
                    p = function(a) {
                        o = !0, d.promisePayload().then(function(b) {
                            h(l + ": AsyncRequest completed"), a(b)
                        })
                    };
                    q = new(b("Promise"))(function(a, b) {
                        k.onLoaded(function(d) {
                            d = d.data;
                            d != null ? (c("clearTimeout")(n), h(l + ": Preload completed"), a(e(d))) : (h(l + ": Preload completed but it had no data :/"), b(new Error("Preloaded data was empty")))
                        }), k.onError(function(b) {
                            h(l + ": Preload had error, making AsyncRequest"), o || (c("clearTimeout")(n), h(l + ": Making AsyncRequest due to preloader error"), p(a))
                        })
                    });
                    r = new(b("Promise"))(function(a) {
                        var b = 5e3;
                        h(l + ": Waiting " + b + "ms for preloader to finish");
                        n = c("setTimeoutAcrossTransitions")(function() {
                            h(l + ": Making AsyncRequest to race preloader"), p(a)
                        }, b)
                    });
                    f.next = 20;
                    return b("regeneratorRuntime").awrap(b("Promise").race([q, r]));
                case 20:
                    return f.abrupt("return", f.sent);
                case 21:
                case "end":
                    return f.stop()
            }
        }, null, this)
    }

    function a(a, b) {
        return j(a, b, function(a) {
            return a
        })
    }
    a.withDataProcessor = function(a, b, c) {
        return j(a, b, c)
    };
    g["default"] = a
}), 98);
__d("AdsAccountDataLoader", ["AdsAccountAdBuilderDataLoaderFields", "AdsAccountAdsReportingDataLoaderFields", "AdsAccountDataLoaderFields", "AdsAccountDataLoaderPreloader", "AdsAccountExperimentsPreloader", "AdsApplicationUtils", "AdsGraphAPI", "AdsInterfacesLogEvents", "AdsInterfacesLogger", "AdsInterfacesLoggerUtils", "AdsMgmtPreloadingUtils", "AdsTALAccountDataLoaderPreloader", "AsyncTypedRequest", "BizSiteIdentifier.brands", "Deferred", "Promise", "XAdsAccountExperimentsController", "cr:1621989", "mapObject", "memoize", "objectToMap", "preloadedAsyncRequest", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new(c("Deferred"))(),
        i = b("cr:1621989") ? new(b("cr:1621989"))() : null;

    function a(a) {
        h.resolve(a), j()
    }
    var j = c("memoize")(function() {
        return h.getPromise().then(function(a) {
            c("AdsInterfacesLogger").log({
                eventCategory: c("AdsInterfacesLogEvents").EventCategory.USER_ACTION,
                eventName: c("AdsInterfacesLogEvents").Event.ACCOUNT_DATA_PREFETCHED
            }, c("AdsInterfacesLogger").LOG_TYPE_PRIMARY_APP);
            return a
        }, function(a) {
            d("AdsInterfacesLoggerUtils").logFatal(a);
            throw a
        })
    });

    function k(a) {
        a = d("AdsGraphAPI").get(f.id).adaccount(a).batched();
        d("AdsApplicationUtils").isPowerEditor() ? a = a.preloadedBy(c("AdsAccountDataLoaderPreloader").preloader, d("AdsMgmtPreloadingUtils").defaultConfig) : i != null && (a = a.preloadedBy(c("AdsTALAccountDataLoaderPreloader").preloader, i.defaultConfig));
        return a.get({
            fields: d("AdsApplicationUtils").isAdBuilder() ? c("AdsAccountAdBuilderDataLoaderFields").fields : d("AdsApplicationUtils").isAdsReporting() ? c("AdsAccountAdsReportingDataLoaderFields").fields : c("AdsAccountDataLoaderFields").fields
        })
    }

    function e(a, b) {
        return d("AdsGraphAPI").get(f.id).adaccount(a).batched().get({
            fields: b
        })
    }

    function l(a) {
        return d("AdsGraphAPI").get(f.id).adaccount(a).get({
            fields: ["prepay_account_balance"]
        }).then(function(a) {
            return a.prepay_account_balance
        })
    }

    function m(a) {
        return d("AdsGraphAPI").get(f.id).adaccount(a).get({
            fields: ["current_unbilled_spend"]
        }).then(function(a) {
            return a.current_unbilled_spend
        })
    }

    function n(a, b) {
        return d("AdsGraphAPI").get(f.id).adaccount(a).edge("user_settings").post(b)
    }

    function o(a, b) {
        return d("AdsGraphAPI").get(f.id).adaccount(a).post(b)
    }

    function p(a) {
        return d("AdsGraphAPI").get(f.id).adaccount(a).get({
            fields: ["pages_in_authorizations"]
        }).then(function(a) {
            return a.pages_in_authorizations
        })
    }

    function q(a) {
        if (d("AdsApplicationUtils").isFAME()) return new(b("Promise"))(function(a) {
            a({
                gks2: {},
                qes2: {}
            })
        });
        a = c("XAdsAccountExperimentsController").getURIBuilder().setInt("account_id", a).getURI();
        a = new(c("AsyncTypedRequest"))(a).setData({
            business_id: d("BizSiteIdentifier.brands").getBusinessID()
        }).setMethod("GET").setReadOnly(!0);
        return c("preloadedAsyncRequest").withDataProcessor(c("AdsAccountExperimentsPreloader"), a, function(a) {
            return {
                gks2: c("mapObject")(a.gks2, function(a) {
                    return {
                        gks: new Set(a.gks),
                        id: a.id,
                        mac: a.mac,
                        gkablog: a.gkablog == null ? null : c("objectToMap")(a.gkablog)
                    }
                }),
                qes2: c("mapObject")(a.qes2, function(a) {
                    return {
                        id: a.id,
                        log: new Set(a.log),
                        mac: a.mac,
                        qes: c("objectToMap")(a.qes)
                    }
                })
            }
        })
    }

    function r(a) {
        var c, d, e;
        return b("regeneratorRuntime").async(function(f) {
            while (1) switch (f.prev = f.next) {
                case 0:
                    f.next = 2;
                    return b("regeneratorRuntime").awrap(b("Promise").all([k(a), q(a)]));
                case 2:
                    c = f.sent;
                    d = c[0];
                    e = c[1];
                    return f.abrupt("return", babelHelpers["extends"]({}, d, {
                        __gk_DO_NOT_USE: e
                    }));
                case 6:
                case "end":
                    return f.stop()
            }
        }, null, this)
    }
    g.bootstrap = a;
    g.getBootstrapData = j;
    g.fetchAccountData = k;
    g.fetchAccountDataByFields = e;
    g.fetchPrepayAccountBalance = l;
    g.fetchCurrentUnbilledSpend = m;
    g.postUserSettings = n;
    g.updateAccount = o;
    g.fetchPagesInAuthorizations = p;
    g.fetchGKs = q;
    g.fetchAccountAndGKs = r
}), 98);
__d("AdsAccountLastThirtyDaysSpendLoadErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.LAST_THIRTY_DAYS_SPEND_LOAD_ERROR");
    e.exports = a
}), null);
__d("AdsAccountLastThirtyDaysSpendLoadedDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.LAST_THIRTY_DAYS_SPEND_LOADED");
    e.exports = a
}), null);
__d("AdsAccountSettingsUpdateErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.SETTINGS_UPDATE_ERROR");
    e.exports = a
}), null);
__d("AdsAccountSettingsUpdateSuccessDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.SETTINGS_UPDATE_SUCCESS");
    e.exports = a
}), null);
__d("AdsAccountTodaySpendLoadErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.TODAY_SPEND_LOAD_ERROR");
    e.exports = a
}), null);
__d("AdsAccountTodaySpendLoadedDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.TODAY_SPEND_LOADED");
    e.exports = a
}), null);
__d("AdsAccountViewerPermissionsLoadErrorDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.VIEWER_PERMISSIONS_LOAD_ERROR");
    e.exports = a
}), null);
__d("AdsAccountViewerPermissionsLoadedDataAction", ["Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return []
    }, function() {
        return []
    }, "ACCOUNT.VIEWER_PERMISSIONS_LOADED");
    e.exports = a
}), null);
__d("AdsInsightsField", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        ACCOUNT_ID: "account_id",
        ACCOUNT_NAME: "account_name",
        ACTION_BRAND: "action_brand",
        ACTION_BRAND_NAME: "action_brand_name",
        ACTION_CATEGORY: "action_category",
        ACTION_CATEGORY_NAME: "action_category_name",
        ACTION_CONVERTED_PRODUCT_ID: "action_converted_product_id",
        ACTION_DEVICE: "action_device",
        ACTIVITY_RECENCY: "activity_recency",
        AD_FORMAT_ASSET: "ad_format_asset",
        AD_IMPRESSION_VALUE: "ad_impression_value",
        ADGROUP_BID_TYPE: "adgroup_bid_type",
        ADGROUP_BID_VALUE: "adgroup_bid_value",
        ADGROUP_DELIVERY: "adgroup_delivery",
        ADGROUP_ID: "adgroup_id",
        ADGROUP_NAME: "adgroup_name",
        AGE: "age",
        AMOUNT_IN_CATALOG_CURRENCY: "amount_in_catalog_currency",
        APP_ID: "app_id",
        AR_EFFECT_SHARE: "ar_effect_share",
        ATTENTION_EVENTS_PER_IMPRESSION: "attention_events_per_impression",
        ATTRIBUTION_SETTING: "attribution_setting",
        BODY_ASSET: "body_asset",
        BODY_ASSET_VALUE: "body_asset_value",
        BUSINESS_CONTACT_OPTION_CLICKS: "business_contact_option_clicks",
        BUSINESS_IMAGE_CLICKS: "business_image_clicks",
        BUYING_TYPE: "buying_type",
        CALL_TO_ACTION_ASSET: "call_to_action_asset",
        CALL_TO_ACTION_ASSET_VALUE: "call_to_action_asset_value",
        CAMPAIGN_BID_TYPE: "campaign_bid_type",
        CAMPAIGN_BID_VALUE: "campaign_bid_value",
        CAMPAIGN_BUDGET_TYPE: "campaign_budget_type",
        CAMPAIGN_BUDGET_VALUE: "campaign_budget_value",
        CAMPAIGN_DELIVERY: "campaign_delivery",
        CAMPAIGN_END: "campaign_end",
        CAMPAIGN_GROUP_BUDGET_TYPE: "campaign_group_budget_type",
        CAMPAIGN_GROUP_BUDGET_VALUE: "campaign_group_budget_value",
        CAMPAIGN_GROUP_DELIVERY: "campaign_group_delivery",
        CAMPAIGN_GROUP_END: "campaign_group_end",
        CAMPAIGN_GROUP_ID: "campaign_group_id",
        CAMPAIGN_GROUP_NAME: "campaign_group_name",
        CAMPAIGN_GROUP_START: "campaign_group_start",
        CAMPAIGN_ID: "campaign_id",
        CAMPAIGN_NAME: "campaign_name",
        CAMPAIGN_INSIGHTS: "campaign_insights",
        CAMPAIGN_START: "campaign_start",
        CANCEL_SUBSCRIPTION_ACTIONS: "cancel_subscription_actions",
        CANCEL_SUBSCRIPTION_VALUE: "cancel_subscription_value",
        CANVAS_AVG_VIEW_PERCENT: "canvas_avg_view_percent",
        CANVAS_AVG_VIEW_TIME: "canvas_avg_view_time",
        CATALOG_SEGMENT_ACTIONS: "catalog_segment_actions",
        CATALOG_SEGMENT_VALUE_IN_CATALOG_CURRENCY: "catalog_segment_value_in_catalog_currency",
        CATALOG_SEGMENT_VALUE_MOBILE_PURCHASE_ROAS: "catalog_segment_value_mobile_purchase_roas",
        CATALOG_SEGMENT_VALUE_WEBSITE_PURCHASE_ROAS: "catalog_segment_value_website_purchase_roas",
        CONTACT_ACTIONS: "contact_actions",
        CONTACT_VALUE: "contact_value",
        CONVERSION_VALUES: "conversion_values",
        CONVERSIONS: "conversions",
        CONVERTED_PRODUCT_COUNT: "converted_product_count",
        CONVERTED_PRODUCT_QUANTITY: "converted_product_quantity",
        CONVERTED_PRODUCT_VALUE: "converted_product_value",
        COST_PER_10_SEC_VIDEO_VIEW: "cost_per_10_sec_video_view",
        COST_PER_15_SEC_VIDEO_VIEW: "cost_per_15_sec_video_view",
        COST_PER_2_SEC_CONTINUOUS_VIDEO_VIEW: "cost_per_2_sec_continuous_video_view",
        COST_PER_AD_CLICK: "cost_per_ad_click",
        COST_PER_COMPLETED_VIDEO_VIEW: "cost_per_completed_video_view",
        COST_PER_CONTACT: "cost_per_contact",
        COST_PER_CUSTOMIZE_PRODUCT: "cost_per_customize_product",
        COST_PER_DDA_COUNTBY_CONVS: "cost_per_dda_countby_convs",
        COST_PER_DONATE: "cost_per_donate",
        COST_PER_FIND_LOCATION: "cost_per_find_location",
        COST_PER_ONE_THOUSAND_AD_IMPRESSION: "cost_per_one_thousand_ad_impression",
        COST_PER_OUTBOUND_CLICK: "cost_per_outbound_click",
        COST_PER_POST_CONVERSION_SIGNAL: "cost_per_post_conversion_signal",
        COST_PER_SCHEDULE: "cost_per_schedule",
        COST_PER_START_TRIAL: "cost_per_start_trial",
        COST_PER_STORE_VISIT: "cost_per_store_visit",
        COST_PER_STORE_VISIT_ACTION: "cost_per_store_visit_action",
        COST_PER_SUBMIT_APPLICATION: "cost_per_submit_application",
        COST_PER_SUBSCRIBE: "cost_per_subscribe",
        COST_PER_THRUPLAY: "cost_per_thruplay",
        COST_PER_THRUPLAY_WATCHED_ACTION: "cost_per_thruplay_watched_action",
        COST_PER_UNIQUE_CLICK: "cost_per_unique_click",
        COST_PER_UNIQUE_OUTBOUND_CLICK: "cost_per_unique_outbound_click",
        COUNTRY: "country",
        CPC: "cpc",
        CPM: "cpm",
        CPP: "cpp",
        CREATIVE_AD_IDS: "creative_ad_ids",
        CREATIVE_DELIVERY_INFO: "creative_delivery_info",
        CREATIVE_FINGERPRINT: "creative_fingerprint",
        CREATIVE_NAME: "creative_name",
        CTR: "ctr",
        CUSTOMIZE_PRODUCT_ACTIONS: "customize_product_actions",
        CUSTOMIZE_PRODUCT_VALUE: "customize_product_value",
        DATE_CREATED: "created_time",
        DATE_START: "date_start",
        DATE_STOP: "date_stop",
        DATE_UPDATED: "updated_time",
        DDA_COUNTBY_CONVS: "dda_countby_convs",
        DDA_RESULTS: "dda_results",
        DESCRIPTION_ASSET: "description_asset",
        DESCRIPTION_ASSET_VALUE: "description_asset_value",
        DONATE_ACTIONS: "donate_actions",
        DONATE_VALUE: "donate_value",
        EARNED_IMPRESSION: "earned_impression",
        ESTIMATED_MARGIN_AMOUNT: "estimated_margin_amount",
        ESTIMATED_MARGIN_AMOUNT_USD: "estimated_margin_amount_usd",
        FIND_LOCATION_ACTIONS: "find_location_actions",
        FIND_LOCATION_VALUE: "find_location_value",
        GENDER: "gender",
        IMAGE_ASSET: "image_asset",
        IMAGE_ASSET_VALUE: "image_asset_value",
        IMPRESSION_DEVICE: "impression_device",
        INSTANT_EXPERIENCE_CLICKS_TO_OPEN: "instant_experience_clicks_to_open",
        INSTANT_EXPERIENCE_CLICKS_TO_START: "instant_experience_clicks_to_start",
        INSTANT_EXPERIENCE_ELEMENT_IMPRESSIONS: "instant_experience_element_impressions",
        INSTANT_EXPERIENCE_ELEMENT_REACH: "instant_experience_element_reach",
        INSTANT_EXPERIENCE_OUTBOUND_CLICKS: "instant_experience_outbound_clicks",
        INTERACTIVE_COMPONENT_STICKER_ID: "interactive_component_sticker_id",
        INTERACTIVE_COMPONENT_STICKER_RESPONSE: "interactive_component_sticker_response",
        INTERACTIVE_COMPONENT_TAP: "interactive_component_tap",
        IS_CONVERSION_ID_MODELED: "is_conversion_id_modeled",
        IS_VIDEO: "is_video",
        LAST_SIGNIFICANT_EDIT: "last_significant_edit",
        LINK_URL_ASSET: "link_url_asset",
        LINK_URL_ASSET_VALUE: "link_url_asset_value",
        MEDIA_ASSET: "media_asset",
        MOBILE_APP_PURCHASE_ROAS: "mobile_app_purchase_roas",
        NUM_ACTIVE_CAMPAIGN_GROUPS: "num_active_campaign_groups",
        NUM_CAMPAIGN_GROUPS: "num_campaign_groups",
        NUM_CAMPAIGNS: "num_campaigns",
        NUM_CREATIVE_AD_IDS: "num_creative_ad_ids",
        OBJECTIVE: "objective",
        OPTIMIZATION_GOAL: "optimization_goal",
        OUTBOUND_CLICKS: "outbound_clicks",
        OUTBOUND_CLICKS_CTR: "outbound_clicks_ctr",
        PERFORMANCE_INDICATOR: "performance_indicator",
        POST_CONVERSION_SIGNAL_RESULT: "post_conversion_signal_result",
        PRIVATE_ATTRIBUTION_CONVERSIONS: "private_attribution_conversions",
        PRIVATE_ATTRIBUTION_SALES: "private_attribution_sales",
        PRODUCT_ID: "product_id",
        PROMOTED_PRODUCT_SET_VALUE: "promoted_product_set_value",
        QUALIFYING_QUESTION_ANSWER: "qualifying_question_answer",
        QUALIFYING_QUESTION_ANSWER_WITH_QUALIFIED_OPTION: "qualifying_question_answer_with_qualified_option",
        QUALIFYING_QUESTION_QUALIFY_ANSWER_RATE: "qualifying_question_qualify_answer_rate",
        RECURRING_SUBSCRIPTION_PAYMENT_ACTIONS: "recurring_subscription_payment_actions",
        RECURRING_SUBSCRIPTION_PAYMENT_VALUE: "recurring_subscription_payment_value",
        REGION: "region",
        REGION_ID: "region_id",
        RULE_ASSET_VALUE: "rule_asset_value",
        SCHEDULE_ACTIONS: "schedule_actions",
        SCHEDULE_VALUE: "schedule_value",
        SKAN_CAMPAIGN_ID: "skan_campaign_id",
        SKAN_CONVERSION_ID: "skan_conversion_id",
        START_TRIAL_ACTIONS: "start_trial_actions",
        START_TRIAL_VALUE: "start_trial_value",
        STORE_VISIT_ACTIONS: "store_visit_actions",
        SUBMIT_APPLICATION_ACTIONS: "submit_application_actions",
        SUBMIT_APPLICATION_VALUE: "submit_application_value",
        SUBSCRIBE_ACTIONS: "subscribe_actions",
        SUBSCRIBE_VALUE: "subscribe_value",
        THRUPLAY_WATCHED_ACTIONS: "thruplay_watched_actions",
        TITLE_ASSET: "title_asset",
        TITLE_ASSET_VALUE: "title_asset_value",
        TODAY_SPEND: "today_spend",
        TOTAL_POSTBACKS: "total_postbacks",
        TOTAL_POSTBACKS_DETAILED: "total_postbacks_detailed",
        UNIQUE_CONVERTED_PRODUCT_COUNT: "unique_converted_product_count",
        UNIQUE_CTR: "unique_ctr",
        UNIQUE_LINK_CLICKS_CTR: "unique_link_clicks_ctr",
        UNIQUE_OUTBOUND_CLICKS: "unique_outbound_clicks",
        UNIQUE_OUTBOUND_CLICKS_CTR: "unique_outbound_clicks_ctr",
        UNIQUE_VIDEO_CONTINUOUS_2_SEC_WATCHED_ACTIONS: "unique_video_continuous_2_sec_watched_actions",
        UNIQUE_VIDEO_VIEW_10_SEC: "unique_video_view_10_sec",
        UNIQUE_VIDEO_VIEW_15_SEC: "unique_video_view_15_sec",
        USER_SEGMENT_KEY: "user_segment_key",
        VIDEO_10_SEC_WATCHED_ACTIONS: "video_10_sec_watched_actions",
        VIDEO_15_SEC_WATCHED_ACTIONS: "video_15_sec_watched_actions",
        VIDEO_30_SEC_WATCHED_ACTIONS: "video_30_sec_watched_actions",
        VIDEO_ASSET: "video_asset",
        VIDEO_ASSET_VALUE: "video_asset_value",
        VIDEO_AVG_TIME_WATCHED_ACTIONS: "video_avg_time_watched_actions",
        VIDEO_CONTINUOUS_2_SEC_WATCHED_ACTIONS: "video_continuous_2_sec_watched_actions",
        VIDEO_P100_WATCHED_ACTIONS: "video_p100_watched_actions",
        VIDEO_P25_WATCHED_ACTIONS: "video_p25_watched_actions",
        VIDEO_P50_WATCHED_ACTIONS: "video_p50_watched_actions",
        VIDEO_P75_WATCHED_ACTIONS: "video_p75_watched_actions",
        VIDEO_P95_WATCHED_ACTIONS: "video_p95_watched_actions",
        VIDEO_PLAY_ACTIONS: "video_play_actions",
        VIDEO_PLAY_RETENTION_CURVE_ACTIONS: "video_play_retention_curve_actions",
        WEBSITE_CTR: "website_ctr",
        WEBSITE_PURCHASE_ROAS: "website_purchase_roas",
        ACCOUNT_CURRENCY: "account_currency",
        ACCOUNT_DEFAULT_ATTRIBUTION_WINDOWS: "account_default_attribution_windows",
        ACCOUNT_TIMEZONE: "account_timezone",
        ACTION_CANVAS_COMPONENT_ID: "action_canvas_component_id",
        ACTION_CANVAS_COMPONENT_NAME: "action_canvas_component_name",
        ACTION_EVENT_CHANNEL: "action_event_channel",
        ACTION_LINK_CLICK_DESTINATION: "action_link_click_destination",
        ACTION_LOCATION_CODE: "action_location_code",
        ACTION_REACTION: "action_reaction",
        ACTION_RESULTS: "actions_results",
        ACTION_VIDEO_ASSET_ID: "action_video_asset_id",
        ACTIONS_PER_IMPRESSION: "actions_per_impression",
        AD_BID_TYPE: "ad_bid_type",
        AD_BID_VALUE: "ad_bid_value",
        AD_DELIVERY: "ad_delivery",
        AD_ID: "ad_id",
        AD_NAME: "ad_name",
        ADSET_BID_TYPE: "adset_bid_type",
        ADSET_BID_VALUE: "adset_bid_value",
        ADSET_BUDGET_TYPE: "adset_budget_type",
        ADSET_BUDGET_VALUE: "adset_budget_value",
        ADSET_DELIVERY: "adset_delivery",
        ADSET_END: "adset_end",
        ADSET_ID: "adset_id",
        ADSET_NAME: "adset_name",
        ADSET_START: "adset_start",
        APP_STORE_CLICKS: "app_store_clicks",
        ATTENTION_EVENTS_UNQ_PER_REACH: "attention_events_unq_per_reach",
        AUCTION_BID: "auction_bid",
        AUCTION_MAX_COMPETITOR_BID: "auction_max_competitor_bid",
        WISH_BID: "wish_bid",
        AUCTION_COMPETITIVENESS: "auction_competitiveness",
        BUDGET_GOAL: "budget_goal",
        CALL_TO_ACTION_CLICKS: "call_to_action_clicks",
        CANVAS_AVG_VIEW_PERCENT_PER_COMPONENT: "canvas_avg_view_percentage_per_component",
        CANVAS_COMPONENT_AVG_PCT_VIEW: "canvas_component_avg_pct_view",
        CARD_VIEWS: "card_views",
        CAROUSEL_CARD_ID: "action_carousel_card_id",
        CAROUSEL_CARD_NAME: "action_carousel_card_name",
        CLICKS: "clicks",
        CONVERSION_WINDOW: "conversion_window",
        COST_PER_DWELL_3_SEC: "cost_per_dwell_3_sec",
        COST_PER_DWELL_5_SEC: "cost_per_dwell_5_sec",
        COST_PER_DWELL_7_SEC: "cost_per_dwell_7_sec",
        COST_PER_DWELL_P50: "cost_per_dwell",
        COST_PER_ESTIMATED_AD_RECALLERS: "cost_per_estimated_ad_recallers",
        COST_PER_INLINE_POST_ENGAGEMENT: "cost_per_inline_post_engagement",
        COST_PER_INLINE_LINK_CLICK: "cost_per_inline_link_click",
        COST_PER_OBJECTIVE_RESULT: "cost_per_objective_result",
        COST_PER_OPTIMIZATION_RESULT: "cost_per_optimization_result",
        COST_PER_UNIQUE_INLINE_LINK_CLICK: "cost_per_unique_inline_link_click",
        COST_PER_RESULT: "cost_per_result",
        COST_PER_ACTION_RESULT: "cost_per_action_result",
        COST_PER_TOTAL_ACTIONS: "cost_per_total_action",
        AD_CREATIVE_LINK_URL: "ad_creative_link_url",
        CUMULATIVE_REACH: "cumulative_reach",
        LIFETIME_FREQUENCY: "lifetime_frequency",
        WEIGHTED_AD_LIFETIME_FREQUENCY: "weighted_ad_lifetime_frequency",
        NEW_REACH: "new_reach",
        DEAL_END: "deal_end",
        DEAL_START: "deal_start",
        DEDUPING_RATIO: "deduping_ratio",
        DEDUPING_1ST_SOURCE_AD: "deduping_1st_source_ad",
        DEDUPING_1ST_SOURCE_RATIO: "deduping_1st_source_ratio",
        DEDUPING_2ND_SOURCE_AD: "deduping_2nd_source_ad",
        DEDUPING_2ND_SOURCE_RATIO: "deduping_2nd_source_ratio",
        DEDUPING_3RD_SOURCE_AD: "deduping_3rd_source_ad",
        DEDUPING_3RD_SOURCE_RATIO: "deduping_3rd_source_ratio",
        DMA: "dma",
        DMA_CODE: "dma_code",
        DWELL_3_SEC: "dwell_3_sec",
        DWELL_5_SEC: "dwell_5_sec",
        DWELL_7_SEC: "dwell_7_sec",
        DWELL_P50_RATE: "dwell_rate",
        DEEPLINK_CLICKS: "deeplink_clicks",
        DESTINATION: "action_destination",
        ESTIMATED_AD_RECALLERS: "estimated_ad_recallers",
        ESTIMATED_AD_RECALLERS_LOWER_BOUND: "estimated_ad_recallers_lower_bound",
        ESTIMATED_AD_RECALLERS_UPPER_BOUND: "estimated_ad_recallers_upper_bound",
        ESTIMATED_AD_RECALL_RATE: "estimated_ad_recall_rate",
        ESTIMATED_AD_RECALL_RATE_LOWER_BOUND: "estimated_ad_recall_rate_lower_bound",
        ESTIMATED_AD_RECALL_RATE_UPPER_BOUND: "estimated_ad_recall_rate_upper_bound",
        FREQUENCY: "frequency",
        FREQUENCY_VALUE: "frequency_value",
        FULL_VIEW_REACH: "full_view_reach",
        FULL_VIEW_IMPRESSIONS: "full_view_impressions",
        HOURLY_STATS_AGGREGATED_BY_ADVERTISER_TIME_ZONE: "hourly_stats_aggregated_by_advertiser_time_zone",
        HOURLY_STATS_AGGREGATED_BY_AUDIENCE_TIME_ZONE: "hourly_stats_aggregated_by_audience_time_zone",
        IMPRESSIONS: "impressions",
        IMPRESSIONS_AUTO_REFRESH: "impressions_auto_refresh",
        IMPRESSIONS_GOAL: "impressions_goal",
        CATALOG_SEGMENT_VALUE: "catalog_segment_value",
        IMPRESSIONS_DUMMY: "impressions_dummy",
        IMPRESSIONS_GROSS: "impressions_gross",
        INLINE_LINK_CLICKS: "inline_link_clicks",
        UNIQUE_INLINE_LINK_CLICKS: "unique_inline_link_clicks",
        INLINE_POST_ENGAGEMENT: "inline_post_engagement",
        OBJECTIVE_RESULTS: "objective_results",
        OBJECTIVE_RESULT_RATE: "objective_result_rate",
        OPTIMIZATION_RESULTS: "optimization_results",
        PAGE_ID: "page_id",
        PAGE_NAME: "page_name",
        PERCENTAGE_AUDIENCE_REACHED: "percentage_audience_reached",
        PERCENTAGE_FIRST_TIME_IMPRESSIONS: "percentage_first_time_impressions",
        PLACE_PAGE_ID: "place_page_id",
        PLACE_PAGE_NAME: "place_page_name",
        PLACEMENT: "placement",
        PUBLISHER_PLATFORM: "publisher_platform",
        PLATFORM_POSITION: "platform_position",
        DEVICE_PLATFORM: "device_platform",
        PRODUCT_ITEM_ID: "product_item_id",
        PRODUCT_SET_ID: "product_set_id",
        QUALITY_SCORE_ECTR: "quality_score_ectr",
        QUALITY_SCORE_ECVR: "quality_score_ecvr",
        QUALITY_SCORE_ORGANIC: "quality_score_organic",
        QUALITY_RANKING: "quality_ranking",
        ENGAGEMENT_RATE_RANKING: "engagement_rate_ranking",
        CONVERSION_RATE_RANKING: "conversion_rate_ranking",
        REACH: "reach",
        RELEVANCE_SCORE: "relevance_score",
        RELEVANCE_SCORE_VALUE: "relevance_score:score",
        RELEVANCE_SCORE_POSITIVE_FEEDBACK: "relevance_score:positive_feedback",
        RELEVANCE_SCORE_NEGATIVE_FEEDBACK: "relevance_score:negative_feedback",
        RELEVANCE_SCORE_ORGANIC_RANK: "relevance_score:organic_rank",
        RESULT_RATE: "result_rate",
        RESULTS: "results",
        RESULTS_SHARE: "results_share",
        KPI_RESULTS: "kpi_results",
        SOCIAL_CLICKS: "social_clicks",
        SOCIAL_IMPRESSIONS: "social_impressions",
        SOCIAL_REACH: "social_reach",
        SPEND: "spend",
        STORE_VISITS: "store_visits",
        THUMB_STOPS: "thumb_stops",
        TOTAL_ACTION_VALUE: "total_action_value",
        TOTAL_ACTIONS: "total_actions",
        TOTAL_UNIQUE_ACTIONS: "total_unique_actions",
        UNIQUE_CLICKS: "unique_clicks",
        INLINE_LINK_CLICK_CTR: "inline_link_click_ctr",
        UNIQUE_INLINE_LINK_CLICK_CTR: "unique_inline_link_click_ctr",
        UNIQUE_IMPRESSIONS: "unique_impressions",
        UNIQUE_SOCIAL_CLICKS: "unique_social_clicks",
        UNIQUE_SOCIAL_IMPRESSIONS: "unique_social_impressions",
        VIDEO_AVG_PCT_WATCHED_ACTIONS: "video_avg_pct_watched_actions",
        VIDEO_AVG_PERCENT_WATCHED_ACTIONS: "video_avg_percent_watched_actions",
        VIDEO_AVG_SEC_WATCHED_ACTIONS: "video_avg_sec_watched_actions",
        VIDEO_TIME_WATCHED_ACTIONS: "video_time_watched_actions",
        VIDEO_COMPLETE_WATCHED_ACTIONS: "video_complete_watched_actions",
        VIDEO_SOUND: "action_video_sound",
        VIDEO_VIEW_TYPE: "action_video_type",
        VIDEO_THRUPLAY_WATCHED_ACTIONS: "video_thruplay_watched_actions",
        VIDEO_COMPLETED_VIEW_OR_15S_PASSED_ACTIONS: "video_completed_view_or_15s_passed_actions",
        CONDITIONAL_TIME_SPENT_MS_OVER_2S_ACTIONS: "conditional_time_spent_ms_over_2s_actions",
        CONDITIONAL_TIME_SPENT_MS_OVER_3S_ACTIONS: "conditional_time_spent_ms_over_3s_actions",
        CONDITIONAL_TIME_SPENT_MS_OVER_6S_ACTIONS: "conditional_time_spent_ms_over_6s_actions",
        CONDITIONAL_TIME_SPENT_MS_OVER_10S_ACTIONS: "conditional_time_spent_ms_over_10s_actions",
        CONDITIONAL_TIME_SPENT_MS_OVER_15S_ACTIONS: "conditional_time_spent_ms_over_15s_actions",
        VIDEO_PLAY_RETENTION_0_TO_15S_ACTIONS: "video_play_retention_0_to_15s_actions",
        VIDEO_PLAY_RETENTION_20_TO_60S_ACTIONS: "video_play_retention_20_to_60s_actions",
        VIDEO_PLAY_RETENTION_GRAPH_ACTIONS: "video_play_retention_graph_actions",
        WEBSITE_CLICKS: "website_clicks",
        PURCHASE_ROAS: "purchase_roas",
        CATALOG_SEGMENT_VALUE_OMNI_PURCHASE_ROAS: "catalog_segment_value_omni_purchase_roas",
        RULE_ASSET: "rule_asset",
        DEBUG_STAGE_TRACE: "stage_trace",
        GENDER_TARGETING: "gender_targeting",
        AGE_TARGETING: "age_targeting",
        LOCATION: "location",
        LABELS: "labels",
        HEADLINE: "headline",
        DESCRIPTION: "description",
        WEBSITE_URL: "website_url",
        IMAGE_NAME: "image_name",
        VIDEO_NAME: "video_name",
        IMAGE_HASH: "image_hash",
        VIDEO_ID: "video_id",
        URL_TAGS: "url_tags",
        CALL_TO_ACTION_TYPE: "call_to_action_type",
        CUSTOM_AUDIENCES: "custom_audiences",
        EXCLUDED_CUSTOM_AUDIENCES: "excluded_custom_audiences",
        HIGH_CPA_SPEND_ALERT: "high_cpa_spend_alert",
        AD_CLICK_ACTION: "ad_click_actions",
        AD_IMPRESSION_ACTION: "ad_impression_actions",
        CUSTOM_DERIVED_METRICS: "custom_derived_metrics",
        CUSTOM_DERIVED_METRIC_ID: "custom_derived_metric_id",
        CUSTOM_BREAKDOWN: "custom_breakdown",
        TOTAL_LEARNING_PHASE_SPEND_RATIO: "total_learning_phase_spend_ratio",
        IN_LEARNING_SPEND: "in_learning_spend",
        LEARNING_LIMITED_SPEND: "learning_limited_spend",
        TOTAL_RUNNING_ADS: "total_running_ads",
        RUNNING_ADS_COUNT_IN_LEARNING: "running_ads_count_in_learning",
        RUNNING_ADS_COUNT_IN_LEARNING_LIMITED: "running_ads_count_in_learning_limited",
        TOTAL_RUNNING_ADSETS: "total_running_adsets",
        RUNNING_ADSETS_COUNT_IN_LEARNING: "running_adsets_count_in_learning",
        RUNNING_ADSETS_COUNT_IN_LEARNING_LIMITED: "running_adsets_count_in_learning_limited",
        TOTAL_LEARNING_PHASE_SPEND_RATIO_LEGACY: "total_learning_phase_spend_ratio_legacy",
        IN_LEARNING_SPEND_LEGACY: "in_learning_spend_legacy",
        LEARNING_LIMITED_SPEND_LEGACY: "learning_limited_spend_legacy",
        RUNNING_ADS_COUNT_IN_LEARNING_LEGACY: "running_ads_count_in_learning_legacy",
        RUNNING_ADS_COUNT_IN_LEARNING_LIMITED_LEGACY: "running_ads_count_in_learning_limited_legacy",
        RUNNING_ADSETS_COUNT_IN_LEARNING_LEGACY: "running_adsets_count_in_learning_legacy",
        RUNNING_ADSETS_COUNT_IN_LEARNING_LIMITED_LEGACY: "running_adsets_count_in_learning_limited_legacy",
        ONSITE_APP_ADD_TO_CART: "onsite_app_add_to_cart",
        ONSITE_APP_PURCHASE: "onsite_app_purchase",
        ONSITE_APP_VIEW_CONTENT: "onsite_app_view_content",
        ONSITE_WEB_ADD_TO_CART: "onsite_web_add_to_cart",
        ONSITE_WEB_APP_ADD_TO_CART: "onsite_web_app_add_to_cart",
        ONSITE_WEB_APP_PURCHASE: "onsite_web_app_purchase",
        ONSITE_WEB_APP_VIEW_CONTENT: "onsite_web_app_view_content",
        ONSITE_WEB_LEAD: "onsite_web_lead",
        ONSITE_WEB_PURCHASE: "onsite_web_purchase",
        ONSITE_WEB_VIEW_CONTENT: "onsite_web_view_content",
        VIEW_CONTENT: "view_content",
        CATALOG_MATCH: "catalog_match",
        CREATIVE_MEDIA_TYPE: "creative_media_type"
    })
}), null);
__d("XAdsAccountViewerPermissionsGetController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ads/viewer_permissions/", {
        ad_account_id: {
            type: "Int",
            required: !0
        }
    })
}), null);
__d("XMAIAAcceptDeeplinkTOSController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ads/manage/mobile_app_install/tos_dialog/", {
        act: {
            type: "Int",
            required: !0
        },
        agree: {
            type: "Bool",
            defaultValue: !1
        }
    })
}), null);
__d("AdsAccountDataDispatcher", ["AdsAccountAddCapabilitiesDataAction", "AdsAccountAttributionSpecLoadErrorDataAction", "AdsAccountAttributionSpecLoadSuccessDataAction", "AdsAccountAttributionSpecUpdateErrorDataAction", "AdsAccountAttributionSpecUpdateSuccessDataAction", "AdsAccountBatchLoadErrorDataAction", "AdsAccountBatchLoadedDataAction", "AdsAccountDataLoader", "AdsAccountDefaultUnifiedAttrSpecLoadErrorDataAction", "AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataAction", "AdsAccountDefaultUnifiedAttrSpecUpdateErrorDataAction", "AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataAction", "AdsAccountGKsErrorAction", "AdsAccountGKsLoadedAction", "AdsAccountLastThirtyDaysSpendLoadErrorDataAction", "AdsAccountLastThirtyDaysSpendLoadedDataAction", "AdsAccountSettingsUpdateErrorDataAction", "AdsAccountSettingsUpdateSuccessDataAction", "AdsAccountTodaySpendLoadErrorDataAction", "AdsAccountTodaySpendLoadedDataAction", "AdsAccountViewerPermissionsLoadErrorDataAction", "AdsAccountViewerPermissionsLoadedDataAction", "AdsApplicationUtils", "AdsGraphAPI", "AdsInsightsField", "AsyncRequest", "FBLogger", "Promise", "XAdsAccountViewerPermissionsGetController", "XMAIAAcceptDeeplinkTOSController", "promiseDone", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.loadAccountDataByFields = function(a, b) {
                c("promiseDone")(d("AdsAccountDataLoader").fetchAccountDataByFields(a, b), function(b) {
                    c("AdsAccountBatchLoadedDataAction").dispatch({
                        accountID: a,
                        account: b
                    }, {
                        line: "86",
                        module: "AdsAccountDataDispatcher.js"
                    })
                }, function(b) {
                    c("AdsAccountBatchLoadErrorDataAction").dispatch({
                        accountID: a,
                        error: b
                    }, {
                        line: "89",
                        module: "AdsAccountDataDispatcher.js"
                    })
                })
            }
        }
        var e = a.prototype;
        e.updateAccount = function(a, b) {
            d("AdsAccountDataLoader").updateAccount(a, b).then(function() {
                c("AdsAccountSettingsUpdateSuccessDataAction").dispatch({}, {
                    line: "54",
                    module: "AdsAccountDataDispatcher.js"
                })
            })["catch"](function(a) {
                c("AdsAccountSettingsUpdateErrorDataAction").dispatch({
                    error: a,
                    data: a
                }, {
                    line: "57",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.loadAccountData = function(a) {
            c("promiseDone")(d("AdsAccountDataLoader").fetchAccountAndGKs(a), function(b) {
                b.business_country_code === "" && c("FBLogger")("ads").warn("BUSINESS_COUNTRY_CODE is an empty string"), c("AdsAccountBatchLoadedDataAction").dispatch({
                    accountID: a,
                    account: b
                }, {
                    line: "68",
                    module: "AdsAccountDataDispatcher.js"
                })
            }, function(b) {
                c("AdsAccountBatchLoadErrorDataAction").dispatch({
                    accountID: a,
                    error: b
                }, {
                    line: "74",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.loadTodaySpend = function(a, b) {
            if (d("AdsApplicationUtils").isAdBuilder()) return;
            b = d("AdsGraphAPI").get(f.id).adaccount(a).edge("insights");
            c("promiseDone")(b.get({
                date_preset: "today",
                fields: [c("AdsInsightsField").SPEND]
            })["catch"](function() {
                return {}
            }), function(a) {
                c("AdsAccountTodaySpendLoadedDataAction").dispatch({
                    data: a
                }, {
                    line: "110",
                    module: "AdsAccountDataDispatcher.js"
                })
            }, function(a) {
                c("AdsAccountTodaySpendLoadErrorDataAction").dispatch({
                    data: a
                }, {
                    line: "113",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.loadLastThirtyDaysSpend = function(a, b) {
            if (d("AdsApplicationUtils").isAdBuilder()) return;
            b = d("AdsGraphAPI").get(f.id).adaccount(a).edge("insights");
            c("promiseDone")(b.get({
                date_preset: "last_30d",
                fields: [c("AdsInsightsField").SPEND]
            })["catch"](function() {
                return {}
            }), function(a) {
                c("AdsAccountLastThirtyDaysSpendLoadedDataAction").dispatch({
                    data: a
                }, {
                    line: "134",
                    module: "AdsAccountDataDispatcher.js"
                })
            }, function(a) {
                c("AdsAccountLastThirtyDaysSpendLoadErrorDataAction").dispatch({
                    data: a
                }, {
                    line: "137",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.loadViewerPermissions = function(a) {
            c("promiseDone")(new(b("Promise"))(function(b, d) {
                var e = c("XAdsAccountViewerPermissionsGetController").getURIBuilder().setInt("ad_account_id", a).getURI();
                new(c("AsyncRequest"))().setURI(e).setHandler(b).setErrorHandler(d).setAllowCrossPageTransition(!0).send()
            }), function(b) {
                c("AdsAccountViewerPermissionsLoadedDataAction").dispatch({
                    data: b.payload,
                    accountID: a
                }, {
                    line: "159",
                    module: "AdsAccountDataDispatcher.js"
                })
            }, function(b) {
                c("AdsAccountViewerPermissionsLoadErrorDataAction").dispatch({
                    data: b,
                    accountID: a
                }, {
                    line: "165",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.updateAccountAttributionSpec = function(a, b) {
            d("AdsAccountDataLoader").updateAccount(a, b).then(function() {
                return c("AdsAccountAttributionSpecUpdateSuccessDataAction").dispatch({}, {
                    line: "178",
                    module: "AdsAccountDataDispatcher.js"
                })
            })["catch"](function(a) {
                return c("AdsAccountAttributionSpecUpdateErrorDataAction").dispatch({
                    data: a
                }, {
                    line: "180",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.loadAccountAttributionSpec = function(a) {
            d("AdsGraphAPI").get(f.id).adaccount(a).batched().get({
                fields: ["attribution_spec", "is_attribution_spec_system_default"]
            }).then(function(a) {
                c("AdsAccountAttributionSpecLoadSuccessDataAction").dispatch({
                    data: a
                }, {
                    line: "195",
                    module: "AdsAccountDataDispatcher.js"
                })
            })["catch"](function(a) {
                c("AdsAccountAttributionSpecLoadErrorDataAction").dispatch({
                    data: a
                }, {
                    line: "198",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.updateAccountDefaultUnifiedAttrSpec = function(a, b) {
            d("AdsAccountDataLoader").updateAccount(a, b).then(function() {
                return c("AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataAction").dispatch({}, {
                    line: "211",
                    module: "AdsAccountDataDispatcher.js"
                })
            })["catch"](function(a) {
                return c("AdsAccountDefaultUnifiedAttrSpecUpdateErrorDataAction").dispatch({
                    data: a
                }, {
                    line: "214",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.loadAccountDefaultUnifiedAttrSpec = function(a) {
            d("AdsGraphAPI").get(f.id).adaccount(a).batched().get({
                fields: ["default_unified_attribution_spec"]
            }).then(function(a) {
                c("AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataAction").dispatch({
                    data: a
                }, {
                    line: "228",
                    module: "AdsAccountDataDispatcher.js"
                })
            })["catch"](function(a) {
                c("AdsAccountDefaultUnifiedAttrSpecLoadErrorDataAction").dispatch({
                    data: a
                }, {
                    line: "233",
                    module: "AdsAccountDataDispatcher.js"
                })
            })
        };
        e.handleAcceptMAIDeeplinkTOS = function(a) {
            if (a != null) {
                a = c("XMAIAAcceptDeeplinkTOSController").getURIBuilder().setInt("act", a).setBool("agree", !0).getURI();
                new(c("AsyncRequest"))(a).setHandler(function(a) {
                    a = ["HAS_ACCEPTED_MAI_DEEPLINK_TOS"];
                    c("AdsAccountAddCapabilitiesDataAction").dispatch({
                        capabilities: a
                    }, {
                        line: "250",
                        module: "AdsAccountDataDispatcher.js"
                    })
                }).setErrorHandler(function() {}).setMethod("POST").send()
            }
        };
        e.loadGKs = function(a) {
            var e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        f.prev = 0;
                        f.next = 3;
                        return b("regeneratorRuntime").awrap(d("AdsAccountDataLoader").fetchGKs(a));
                    case 3:
                        e = f.sent;
                        c("AdsAccountGKsLoadedAction").dispatch({
                            accountID: a,
                            data: {
                                __gk_DO_NOT_USE: e
                            }
                        }, {
                            line: "263",
                            module: "AdsAccountDataDispatcher.js"
                        });
                        f.next = 10;
                        break;
                    case 7:
                        f.prev = 7, f.t0 = f["catch"](0), c("AdsAccountGKsErrorAction").dispatch({
                            accountID: a,
                            error: f.t0
                        }, {
                            line: "268",
                            module: "AdsAccountDataDispatcher.js"
                        });
                    case 10:
                    case "end":
                        return f.stop()
                }
            }, null, this, [
                [0, 7]
            ])
        };
        return a
    }();
    e = new a();
    a = e;
    g["default"] = a
}), 98);
__d("LoadObjectMapBatchingQueueNames", ["keyMirror"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        MAIN: null,
        POST_FETCH: null,
        DEFAULT: null,
        DYNAMIC: null,
        CHEAP: null
    });
    b = a;
    g["default"] = b
}), 98);
__d("LoadObjectMap", ["invariant", "LoadObject", "LoadObjectMapBatchingQueueNames", "immutable", "regeneratorRuntime"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "long_secret_string_do_not_use",
        j = function(a, b) {
            return a.isEmpty()
        },
        k = Number.POSITIVE_INFINITY;
    a = function() {
        a.create = function(b, c, d, e) {
            c === void 0 && (c = j);
            d === void 0 && (d = k);
            e === void 0 && (e = !1);
            return new a(i, b, function(a) {
                return a
            }, c, d, e)
        };
        a.createKeyed = function(b, c, d, e, f) {
            d === void 0 && (d = j);
            e === void 0 && (e = k);
            f === void 0 && (f = !1);
            return new a(i, b, c, d, e, f)
        };

        function a(a, b, d, e, f, g) {
            this.$1 = c("immutable").Map(), this.$4 = e, this.$5 = d, this.$3 = b, this.$8 = c("immutable").OrderedSet().asMutable(), this.$9 = null, this.$6 = f, this.$10 = g, this.$11 = c("immutable").Set(), this.$7 = new Map()
        }
        var d = a.prototype;
        d.get = function(a, b) {
            var d = this;
            b === void 0 && (b = c("LoadObjectMapBatchingQueueNames").DEFAULT);
            var e = this.getCached(a),
                f = this.$5(a);
            if (!this.$8.has(f) && (this.$4(e, a) || this.$11.has(f))) {
                this.$7.has(b) || this.$7.set(b, c("immutable").OrderedSet().asMutable());
                b = this.$7.get(b);
                b != null || h(0, 21818);
                b.add(a);
                this.$8.add(f);
                if (this.$10) {
                    b = this.$7.get(c("LoadObjectMapBatchingQueueNames").MAIN);
                    if (b != null) {
                        a = this.__getChunkSize(b, c("LoadObjectMapBatchingQueueNames").MAIN);
                        if (b.size >= a) {
                            this.$12(b, c("LoadObjectMapBatchingQueueNames").MAIN);
                            return e
                        }
                    } else this.$7.forEach(function(a, b) {
                        var c = d.__getChunkSize(a, b);
                        if (a.size >= c) {
                            d.$12(a, b);
                            return e
                        }
                    })
                }
                this.$9 === null && (this.$9 = window.setTimeout(function() {
                    d.$7.forEach(function(a, b) {
                        a.size > 0 && d.$12(a, b)
                    }), d.$10 || d.$8.clear(), d.$9 = null
                }, 0));
                this.$11 = this.$11["delete"](f)
            }
            return e
        };
        d.getCached = function(a) {
            a = this.$5(a);
            return this.$1.has(a) ? this.$1.get(a) : c("LoadObject").empty()
        };
        d.getAll = function(a) {
            var b = this,
                d = c("immutable").Map().withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        c.set(g, b.get(g))
                    }
                });
            return d
        };
        d.setKeyStale = function(b) {
            b = this.$5(b);
            var c = new a(i, this.$3, this.$5, this.$4, this.$6, this.$10);
            c.$1 = this.$1;
            c.$11 = this.$11.add(b);
            return c
        };
        d.setAllExistingKeysStale = function() {
            var b = new a(i, this.$3, this.$5, this.$4, this.$6, this.$10);
            b.$1 = this.$1;
            b.$11 = this.$11.union(Array.from(this.$1.keys()));
            return b
        };
        d.setAllKeysStale = function(b) {
            var d = this;
            b = c("immutable").Set(b).map(function(a) {
                return d.$5(a)
            });
            var e = new a(i, this.$3, this.$5, this.$4, this.$6, this.$10);
            e.$1 = this.$1;
            e.$11 = this.$11.union(b);
            return e
        };
        d.__clearFrame = function(a) {
            (a = this.$7.get(a)) == null ? void 0 : a.clear()
        };
        d.$13 = function(a, b) {
            var c = [],
                d = new Set();
            b = this.__getChunkSize(a, b);
            for (var a = a, e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                d.add(g);
                d.size >= b && (c.push(d), d = new Set())
            }
            d.size > 0 && c.push(d);
            return c
        };
        d.$12 = function(a, b) {
            for (var a = this.$13(a, b), c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= a.length) break;
                    e = a[d++]
                } else {
                    d = a.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                this.__doLoadChunk(e)
            }
            this.__clearFrame(b)
        };
        d.__doLoadChunk = function(a) {
            this.$3(a)
        };
        d.__getChunkSize = function(a, b) {
            return this.$6
        };
        d.getData = function() {
            return this.$1
        };
        d.__setData = function(a) {
            this.$1 = a
        };
        d.getLoadedMap = function() {
            if (!this.$2) {
                var a = [];
                for (var b = this.$1, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= b.length) break;
                        f = b[e++]
                    } else {
                        e = b.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    var g = f[0];
                    f = f[1];
                    f.hasValue() && a.push([g, f.getValueEnforcing()])
                }
                this.$2 = c("immutable").Map(a)
            }
            return this.$2
        };
        d.getLoadedValue = function(a) {
            return this.getLoadedMap().get(this.$5(a))
        };
        d.setDeleting = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        var h = b.$5(g);
                        g = b.getCached(g);
                        c.set(h, g.deleting())
                    }
                })
            })
        };
        d.setLoading = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        var h = b.$5(g);
                        g = b.getCached(g);
                        c.set(h, g.loading())
                    }
                })
            })
        };
        d.setUpdating = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        var h = b.$5(g);
                        g = b.getCached(g);
                        c.set(h, g.updating())
                    }
                })
            })
        };
        d.setSingleValueOrError = function(a, b) {
            var c = this.getCached(a);
            if (b instanceof Error) return this.set(a, c.setError(b).done());
            else return this.set(a, c.setValue(b).done())
        };
        d.setMultipleValueOrError = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        var h = g[0];
                        g = g[1];
                        var i = b.$5(h);
                        h = b.getCached(h);
                        g instanceof Error ? c.set(i, h.setError(g).done()) : c.set(i, h.setValue(g).done())
                    }
                })
            })
        };
        d.setMultipleErrors = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        var h = g[0];
                        g = g[1];
                        var i = b.$5(h);
                        h = b.getCached(h);
                        c.set(i, h.setError(g).done())
                    }
                })
            })
        };
        d.deleteMultipleValueOrError = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        g = b.$5(g);
                        c["delete"](g)
                    }
                })
            })
        };
        d.deleteMultipleErrors = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(function(c) {
                    for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var g;
                        if (e) {
                            if (f >= d.length) break;
                            g = d[f++]
                        } else {
                            f = d.next();
                            if (f.done) break;
                            g = f.value
                        }
                        g = g;
                        g = b.$5(g);
                        var h = b.$1.get(g);
                        h.hasError() && c["delete"](g)
                    }
                })
            })
        };
        d.deleteAllErrors = function() {
            var a = this;
            return this.__mutate(function() {
                return a.$1.withMutations(function(a) {
                    a.forEach(function(b, c) {
                        b.hasError() && a["delete"](c)
                    })
                })
            })
        };
        d.has = function(a) {
            return this.$1.has(this.$5(a))
        };
        d.set = function(a, b) {
            var c = this;
            return this.__mutate(function() {
                return c.$1.set(c.$5(a), b)
            })
        };
        d.update = function(a, b) {
            return this.set(a, b(this.get(a)))
        };
        d["delete"] = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1["delete"](b.$5(a))
            })
        };
        d.merge = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.merge(b.$14(a))
            })
        };
        d.withMutations = function(a) {
            var b = this;
            return this.__mutate(function() {
                return b.$1.withMutations(a)
            })
        };
        d.clear = function() {
            var a = this;
            return this.__mutate(function() {
                return a.$1.clear()
            })
        };
        d.$14 = b("regeneratorRuntime").mark(function a(c) {
            var d, e, f, g, h;
            return b("regeneratorRuntime").wrap(function(a) {
                while (1) switch (a.prev = a.next) {
                    case 0:
                        d = c, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();
                    case 1:
                        if (!e) {
                            a.next = 7;
                            break
                        }
                        if (!(f >= d.length)) {
                            a.next = 4;
                            break
                        }
                        return a.abrupt("break", 16);
                    case 4:
                        g = d[f++];
                        a.next = 11;
                        break;
                    case 7:
                        f = d.next();
                        if (!f.done) {
                            a.next = 10;
                            break
                        }
                        return a.abrupt("break", 16);
                    case 10:
                        g = f.value;
                    case 11:
                        h = g;
                        a.next = 14;
                        return [this.$5(h[0]), h[1]];
                    case 14:
                        a.next = 1;
                        break;
                    case 16:
                    case "end":
                        return a.stop()
                }
            }, a, this)
        });
        d.__mutate = function(b) {
            b = b();
            if (b === this.$1) return this;
            var c = new a(i, this.$3, this.$5, this.$4, this.$6, this.$10);
            c.$1 = b;
            c.$11 = this.$11;
            return c
        };
        d.__getPreventLoadsForThisFrame = function(a) {
            a === void 0 && (a = c("LoadObjectMapBatchingQueueNames").DEFAULT);
            return (a = this.$7.get(a)) != null ? a : c("immutable").OrderedSet()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("AdsAccountGKsProviderPlugin", ["AdsAccountDataDispatcher", "LoadObjectMap"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        initialState: function(a) {
            return c("LoadObjectMap").create(function(b) {
                a(function(a) {
                    return a.setLoading(b)
                }), b.forEach(function(a) {
                    return c("AdsAccountDataDispatcher").loadGKs(a)
                })
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsAccountGKsErrorActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "AdsAccountGKsErrorActionPlugin"
    }
}), null);
__d("AdsAccountGKsLoadedActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "AdsAccountGKsLoadedActionPlugin"
    }
}), null);
__d("AdsAccountInitDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.INIT"
    }
}), null);
__d("AdsAccountInvalidateDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.INVALIDATE"
    }
}), null);
__d("AdsAccountListInvalidateDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.LIST_INVALIDATE"
    }
}), null);
__d("AdsAccountSelectDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.SELECT"
    }
}), null);
__d("AdsAccountSettingsCreateFinishedDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.SETTINGS_CREATE_FINISHED"
    }
}), null);
__d("AdsAccountSettingsUpdateStartDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.SETTINGS_UPDATE_START"
    }
}), null);
__d("AdsAccountViewerPermissionsLoadErrorDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.VIEWER_PERMISSIONS_LOAD_ERROR"
    }
}), null);
__d("AdsAccountViewerPermissionsLoadedDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT.VIEWER_PERMISSIONS_LOADED"
    }
}), null);
__d("AdsAdgroupAcceptMAIDeeplinkTOSDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ADGROUP.ACCEPT_MAI_DEEPLINK_TOS"
    }
}), null);
__d("AdsAMAccountAcceptedTosAddActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT_ACCEPTED_TOS_ADD"
    }
}), null);
__d("AdsAMAccountInitActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ACCOUNT_INIT"
    }
}), null);
__d("AdsHelpTrayConstants", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["ADS_HELP_TRAY_CHROME"]);
    c = b("$InternalEnum").Mirrored(["TOP", "MIDDLE", "BOTTOM", "NONE"]);
    d = 3;
    e = 12;
    b = "/business/m/meta-marketing-pros?lead_source=accel_unified_support_helptray";
    var g = {
        padding: "8px 12px 12px 12px",
        overflowX: "hidden"
    };
    f.ID = a;
    f.CaseTrackingPosition = c;
    f.SEE_MORE_DEFAULT_LIMIT = d;
    f.SEE_MORE_FBS_LIMIT = e;
    f.META_PRO_LANDING_PAGE = b;
    f.homeContentStyles = g
}), 66);
__d("AdsHelpTrayNavigationHelper", ["AdsHelpTrayConstants", "DOM", "Scroll", "first", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        contentType: "HOME"
    };

    function i(a) {
        return a.navigationStack.length === 0 ? h : a.navigationStack[a.navigationStack.length - 1]
    }

    function a(a) {
        a = i(a);
        return a.contentType === "ARTICLE" ? c("nullthrows")(a.id) : null
    }

    function b(a) {
        a = i(a);
        return a.contentType === "EMBEDDED_CONTACT_FORM" ? c("nullthrows")(a.id) : null
    }

    function j() {
        var a = document.getElementById(d("AdsHelpTrayConstants").ID.ADS_HELP_TRAY_CHROME),
            b = 0;
        if (a != null) {
            a = c("first")(c("DOM").scry(a, "div.uiScrollableAreaWrap"));
            b = d("Scroll").getTop(a)
        }
        return b
    }

    function e(a) {
        var b = document.getElementById(d("AdsHelpTrayConstants").ID.ADS_HELP_TRAY_CHROME);
        if (b != null) {
            b = c("first")(c("DOM").scry(b, "div.uiScrollableAreaWrap"));
            d("Scroll").setTop(b, a)
        }
    }

    function f(a, b) {
        var c = babelHelpers["extends"]({}, b, {
            scrollPosition: null
        });
        if (a.length === 0) return [c];
        var d = a[a.length - 1];
        return [].concat(a.slice(0, -1), [babelHelpers["extends"]({}, d, {
            scrollPosition: (a = b.scrollPosition) != null ? a : j()
        }), c])
    }
    g.getCurrentNavigationState = i;
    g.getCurrentContentCMSID = a;
    g.getCurrentEmbeddedFormID = b;
    g.setScrollPositionUsingCSS = e;
    g.concatToNavigationStack = f
}), 98);
__d("AdsHelpTrayOpenCaseDetailsActionReducerPlugin", ["AdsHelpTrayNavigationHelper", "CSS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            var c = a.navigationStack;
            b = b.data.caseID;
            c = [];
            c = d("AdsHelpTrayNavigationHelper").concatToNavigationStack(c, {
                contentType: "SUPPORT_CASE",
                id: b
            });
            document.body && d("CSS").conditionClass(document.body, "has-helptray", !0);
            return babelHelpers["extends"]({}, a, {
                isTrayOpen: !0,
                navigationStack: c
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("XBizResourcesPageController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/business/resources/", {})
}), null);
__d("AdsHelpTrayUtils", ["cssVar", "WebStorage", "XBizResourcesPageController"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "help_tray_state";
    e = "help_tray_job_state";
    f = parseInt("324px", 10);
    h = parseInt("400px", 10);
    var j = parseInt("200", 10);

    function a(a) {
        return c("XBizResourcesPageController").getURIBuilder().getURI().toString()
    }

    function b() {
        if (window.location.pathname.startsWith("/intern/asp")) {
            var a = new URL(window.location.href);
            a = a.searchParams.get("pathname");
            if (a !== null) return a
        }
        return window.location.pathname.replace(/[0-9]/g, "")
    }

    function d(a) {
        var b = c("WebStorage").getSessionStorage();
        c("WebStorage").setItemGuarded(b, i, JSON.stringify(babelHelpers["extends"]({}, a)))
    }
    g.HELP_TRAY_STATE_LOCAL_STORAGE_KEY = i;
    g.HELP_TRAY_JOB_STATE_LOCAL_STORAGE_KEY = e;
    g.HELP_TRAY_WIDTH = f;
    g.HELP_TRAY_WIDTH_MBS_ADS = h;
    g.HELP_TRAY_Z_INDEX = j;
    g.getSupportLink = a;
    g.getReleventArticlesProcessedURL = b;
    g.storeHelpTrayStateToSessionStorage = d
}), 98);
__d("AdsHelpTrayUIProviderPlugin", ["AdsHelpTrayUtils", "CSS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        openModalType: null,
        isTrayOpen: !1,
        currentQuery: "",
        recentlyViewed: [],
        nuxType: null,
        source: "other",
        searchIssueID: "",
        bizSitePageTypeFromButton: null,
        showToast: !1,
        startedQuickCreation: !1,
        navigationStack: [],
        alertLoaded: !1,
        articleLoaded: !1
    };
    b = {
        nuxType: null,
        alertLoaded: !1,
        articleLoaded: !1
    };
    c = window.sessionStorage && window.sessionStorage.getItem(d("AdsHelpTrayUtils").HELP_TRAY_STATE_LOCAL_STORAGE_KEY) || null;
    e = null;
    c != null && (e = JSON.parse(c));
    if (document.body) {
        d("CSS").conditionClass(document.body, "has-helptray", ((f = e) == null ? void 0 : f.isTrayOpen) === !0)
    }
    e != null && (a = babelHelpers["extends"]({}, a, e, b));
    c = {
        initialState: a
    };
    d = c;
    g["default"] = d
}), 98);
__d("AdsHelpTrayUIProvider", ["AdsHelpTrayUIProviderPlugin", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("Laminar").__createProvider(b("AdsHelpTrayUIProviderPlugin"), "AdsHelpTrayUIProviderPlugin")
}), null);
__d("AdsHelpTrayOpenCaseDetailsAction", ["AdsHelpTrayOpenCaseDetailsActionReducerPlugin", "AdsHelpTrayUIProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsHelpTrayOpenCaseDetailsActionReducerPlugin"), b("AdsHelpTrayUIProvider"), {}, "")]
    }, function() {
        return []
    }, "ADS_HELP_TRAY_OPEN_CASE_DETAILS");
    e.exports = a
}), null);
__d("AdsHelpTrayModalTypes", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = Object.freeze({
        CONFIRMATION_REQUEST_UPDATE: "CONFIRMATION_REQUEST_UPDATE",
        CONFIRMATION_REOPEN_CASE: "CONFIRMATION_REOPEN_CASE"
    });
    b = Object.freeze(babelHelpers["extends"]({}, a, {
        CLOSE_CASE: "CLOSE_CASE",
        REQUEST_UPDATE: "REQUEST_UPDATE",
        REOPEN_CASE: "REOPEN_CASE"
    }));
    f.ConfirmationModal = a;
    f.Modal = b
}), 66);
__d("AccountQualityBaseUrl", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c, d) {
        a = a.split("/");
        a.splice(a.length - 1, 1, b);
        c != null ? a.splice(a.length - 2, 1, c) : d != null && a.splice(a.length - 2, 1, d);
        return a.join("/")
    }
    f.getBaseUrl = a
}), 66);
__d("AdmanagerAccountStatuses", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        ACTIVE: 1,
        DISABLED: 2,
        UNSETTLED: 3,
        PENDING_RISK_REVIEW: 7,
        PENDING_SETTLEMENT: 8,
        IN_GRACE_PERIOD: 9,
        PENDING_CLOSURE: 100,
        CLOSED: 101,
        ANY_ACTIVE: 201,
        ANY_CLOSED: 202
    });
    f["default"] = a
}), 66);
__d("AdsBuyingTypes", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        AUCTION: "AUCTION",
        FIXED_PRICE: "FIXED_PRICE",
        RESERVED: "RESERVED",
        MIXED: "MIXED"
    })
}), null);
__d("AdsPEPublishDisableReasons", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    a = {
        PUBLISH: h._("This ad account has a balance that needs to be paid before you can publish. Please verify your billing information is up to date."),
        EDIT: h._("This ad account has a balance that needs to be paid before you can take this action. Please verify your billing information is up to date.")
    };
    b = h._("Your account is closed and can't be used to run ads. You can create a new ad account or make this one active again.");
    c = h._("Your account is currently pending closure and is unabled to run ads. You can cancel closing your account to run ads again.");
    d = h._("You do not have permission to create ads on this account.");
    e = {
        EDIT: h._("Direct deals cannot be modified through Ads Manager. Please use the direct deals tool.")
    };
    f = (f = {}, f.campaign = h._("This campaign can't be edited in Ads Manager because it\u2019s part of an ad strategy."), f.ad_set = h._("This ad set can't be edited in Ads Manager because it\u2019s part of an ad strategy."), f.ad = h._("This ad can't be edited in Ads Manager because it\u2019s part of an ad strategy."), f);
    h = (i = {}, i.campaign = h._("This campaign was created using a recommended campaign setup. Go to the campaign setup to make edits."), i.ad_set = h._("Ad set can't be edited - Ad sets of this type can't be edited."), i.ad = h._("This ad was created using a recommended campaign setup. Go to the campaign setup to make edits."), i);
    g.ACCOUNT_UNSETTLED = a;
    g.ACCOUNT_CLOSED = b;
    g.ACCOUNT_PENDING_CLOSURE = c;
    g.NO_PERMISSION = d;
    g.IS_DIRECT_DEALS_AD_ACCOUNT = e;
    g.PART_OF_AD_STRATEGY = f;
    g.PART_OF_AD_STRATEGY_CREATION_PACKAGE = h
}), 98);
__d("AdsGkExposureFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1827916");
    c = b("FalcoLoggerInternal").create("ads_gk_exposure", a);
    e.exports = c
}), null);
__d("AdsLoadState_LEGACY", ["keyMirror"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        DELETING: null,
        ERROR: null,
        LOADED: null,
        LOADING: null,
        UPDATING: null,
        NOT_LOADED: null,
        PENDING_WRITE: null
    });
    b = a;
    g["default"] = b
}), 98);
__d("AdsGKInternal", ["invariant", "AdsGkExposureFalcoEvent", "AdsLoadState_LEGACY", "FBLogger", "requestIdleCallback"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        function b(a, b) {
            h(0, 17718)
        }
        b.withoutLog = function(a, b) {
            h(0, 17718)
        };
        b.logExposure = function(a, b) {
            h(0, 17718)
        };
        b._ = function(b, c, d) {
            d === void 0 && (d = !0);
            return j(b, a, c, d)
        };
        b._log = function(b, c) {
            k(b, a, c)
        };
        b._clearExposures_FOR_TEST = r;
        return b
    }

    function i(a, b, d) {
        if (a == null) return null;
        if (a.loadState === c("AdsLoadState_LEGACY").LOADING) return null;
        var e = a.__gk_DO_NOT_USE;
        if (e == null) {
            c("FBLogger")("adsAccountGK").warn("Checking GK %s for account %s, but account has no GK data!", d, a.account_id);
            return null
        }
        return e.gks2[b]
    }

    function j(a, b, c, d) {
        d === void 0 && (d = !0);
        a = i(a, b, c);
        if (a == null) return !1;
        d && o(a, c);
        if (a.gks.has(c)) return !0;
        return c.includes(":") ? a.gks.has(c.split(":")[0]) : !1
    }

    function k(a, b, c) {
        a = i(a, b, c);
        a != null && o(a, c)
    }
    var l = new Set(),
        m = !1,
        n = [];

    function o(a, b) {
        var c, d = a.id + ":" + b;
        if (l.has(d)) return;
        c = {
            gko: b,
            gki: (c = a.gkablog) == null ? void 0 : c.get(b),
            id: a.id,
            mac: a.mac
        };
        n.push(c);
        p();
        l.add(d)
    }

    function p() {
        if (m) return;
        m = !0;
        c("requestIdleCallback")(function() {
            return q()
        }, {
            timeout: 5e3
        })
    }

    function q() {
        m = !1;
        var a = function() {
            var a = n.pop();
            c("AdsGkExposureFalcoEvent").log(function() {
                return a
            })
        };
        while (n.length > 0) a()
    }

    function r() {
        l = new Set()
    }
    g.createChecker = a;
    g.checkGKInternal = j;
    g.clearExposures_FOR_TEST = r
}), 98);
__d("adsAccountGK", ["AdsGKInternal"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("AdsGKInternal").createChecker("ad_account");
    b = a;
    g["default"] = b
}), 98);
__d("AdsAccountUtils", ["errorDesc", "fbt", "AdmanagerAccountStatuses", "AdsAudienceDirectConfig", "AdsBuyingTypes", "AdsPEPublishDisableReasons", "adsAccountGK", "isNumberLike"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = [c("AdmanagerAccountStatuses").CLOSED, c("AdmanagerAccountStatuses").DISABLED, c("AdmanagerAccountStatuses").PENDING_CLOSURE, c("AdmanagerAccountStatuses").UNSETTLED];

    function k(a) {
        return !m(a) && !j.includes(a.account_status)
    }

    function a(a) {
        return k(a) && a.is_business_allowed_to_advertise === !0 && a.is_user_allowed_to_advertise === !0
    }

    function b(a) {
        if (c("adsAccountGK")._(a, "1bpA8s90r")) return d("AdsPEPublishDisableReasons").IS_DIRECT_DEALS_AD_ACCOUNT.EDIT;
        return a && a.account_status === c("AdmanagerAccountStatuses").UNSETTLED ? d("AdsPEPublishDisableReasons").ACCOUNT_UNSETTLED.EDIT : null
    }

    function e(a) {
        if (c("adsAccountGK")._(a, "1bpA8s90r")) return d("AdsPEPublishDisableReasons").IS_DIRECT_DEALS_AD_ACCOUNT.EDIT;
        return a && a.account_status === c("AdmanagerAccountStatuses").UNSETTLED ? d("AdsPEPublishDisableReasons").ACCOUNT_UNSETTLED.EDIT : l(a)
    }

    function l(a) {
        if (a && !k(a)) {
            a = a.account_status;
            switch (a) {
                case c("AdmanagerAccountStatuses").UNSETTLED:
                    return d("AdsPEPublishDisableReasons").ACCOUNT_UNSETTLED.EDIT;
                case c("AdmanagerAccountStatuses").CLOSED:
                case c("AdmanagerAccountStatuses").DISABLED:
                case c("AdmanagerAccountStatuses").PENDING_CLOSURE:
                    return h._(function(a, b) {
                        return a._("Only active accounts can create or edit ads.")
                    }, {});
                default:
                    return d("AdsPEPublishDisableReasons").NO_PERMISSION
            }
        }
        return null
    }

    function f(a, b) {
        var c = a.name,
            d = a.account_id;
        a = a.io_number;
        a != null ? c ? c = i._("{account name} (IO {IO Number})", [i._param("account name", c), i._param("IO Number", a)]) : c = i._("IO {IO number}", [i._param("IO number", a)]) : c || (c = d);
        b === !0 && c !== d && (c = i._("{account name} ({account ID})", [i._param("account name", c), i._param("account ID", d)]));
        return c
    }

    function m(a) {
        a = (a = a == null ? void 0 : (a = a.userpermissions) == null ? void 0 : a.data) != null ? a : [];
        return a.length > 0 && a.every(function(a) {
            return a.role === "REPORTS_ONLY"
        })
    }

    function n(a) {
        return a != null && a.length >= 5 && c("isNumberLike")(a)
    }

    function o(a) {
        return (a.funding_source == null || a.funding_source === "") && !q(a, "HAS_VALID_PAYMENT_METHODS") && !q(a, "DIRECT_SALES") && a.can_bypass_fs_check !== !0
    }

    function p(a) {
        return a != null && q(a, "DIRECT_SALES") && a.io_number != null && parseInt(a.io_number, 10) > 0
    }

    function q(a, b) {
        return r(a == null ? void 0 : a.capabilities, b)
    }

    function r(a, b) {
        return a != null && a.includes(b)
    }

    function s(a) {
        return c("AdsAudienceDirectConfig").isDirectDealsUser ? c("AdsBuyingTypes").FIXED_PRICE : q(a, "CAN_ONLY_USE_RF_IO_BUYING_TYPE") ? c("AdsBuyingTypes").RESERVED : c("AdsBuyingTypes").AUCTION
    }

    function t(a) {
        a = a == null ? void 0 : a.business;
        return a != null ? {
            businessID: a.id,
            businessName: a.name || a.id
        } : {
            businessID: null,
            businessName: ""
        }
    }
    a = {
        canCreateAds: a,
        getEditDisabledReason: b,
        getPublishDisabledReason: e,
        getAccountHasNoPublishPermissionDisabledReason: l,
        getUIName: f,
        isAnalystAccount: m,
        isPotentialAccountID: n,
        isPaymentInfoRequired: o,
        hasContract: p,
        hasCapability: q,
        hasCapabilityFromList: r,
        getDefaultBuyingType: s,
        getBusinessInfo: t
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsCachedLoadState_LEGACY", ["AdsLoadState_LEGACY", "ImmutableObject", "mapObject"], (function(a, b, c, d, e, f, g) {
    a = c("mapObject")(c("AdsLoadState_LEGACY"), function(a) {
        return new(c("ImmutableObject"))({
            loadState: a
        })
    });
    b = a;
    g["default"] = b
}), 98);
__d("AdsDMLQueryHandler_DerivedDataBase", ["invariant", "FBLogger", "LoadObject", "nullthrows", "promiseDone"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = function a() {
        ++a.$1 > 1 && c("FBLogger")("dml").mustfix("TDerivedBase & TDerived in DML must be a singleton")
    };
    i.$1 = 0;
    var j = {};

    function k(a) {
        if (a.hasError()) throw a.getError();
        if (a.isLoadingOrEmpty()) throw j;
        return a.getValueEnforcing()
    }

    function l(a, b, d, e) {
        a == null ? void 0 : a.addStores(d);
        if (e instanceof c("LoadObject")) {
            a = k(e);
            d = a
        } else d = e;
        return b ? b(d) : d
    }

    function m(a, b) {
        return function(c, d) {
            var e = a(c);
            c = b(c, d);
            return l(this.handler, d, e, c)
        }
    }
    var n = function() {
            function a() {
                this.$1 = null
            }
            var b = a.prototype;
            b.push = function(a) {
                this.$1 == null || h(0, 54994), this.$1 = a
            };
            b.pop = function(a) {
                this.top() === a || h(0, 54993), this.$1 = null
            };
            b.top = function() {
                var a = this.$1;
                return c("nullthrows")(a, "This code should be used inside of DML.Derived")
            };
            return a
        }(),
        o = new n();

    function a(a, b) {
        return function(c, d) {
            var e = a(c);
            c = b(c, d);
            return l(o.top(), d, e, c)
        }
    }

    function b(a, b) {
        return function(c) {
            var d = a(),
                e = b(c);
            return l(o.top(), c, d, e)
        }
    }

    function p(a, b) {
        return function(c) {
            var d = a(),
                e = b(c);
            return l(this.handler, c, d, e)
        }
    }

    function q(a) {
        return m(function(b) {
            return a.getStores(b)
        }, a)
    }

    function d(a) {
        return p(function() {
            return a.getStores()
        }, a)
    }

    function r(a) {
        var b = null,
            d = null;
        return function(e, f) {
            if (d != null) return d.call(this, e, f);
            b || (b = a(), c("promiseDone")(b, function(a) {
                d = q(a)
            }));
            throw j
        }
    }

    function e(a) {
        return r(function() {
            return a.load()
        })
    }

    function s(a) {
        var b = {},
            d = new Proxy(b, {
                get: function(a, b, c) {
                    return a[b] = null
                }
            });
        try {
            a(d)
        } catch (a) {
            c("FBLogger")("dml").warn("[DML] error %s when getting fragment", a.message)
        }
        return b
    }

    function f(a) {
        return function(b, c) {
            var d;
            if (b == null) return null;
            (d = this.handler) == null ? void 0 : d.addStores([a]);
            d = s(c);
            b = a.getByFields(b, Object.keys(d).length === 0 ? null : d);
            d = k(b);
            return c(d)
        }
    }

    function t(a) {
        return function(b, c) {
            var d;
            if (b == null) return null;
            (d = this.handler) == null ? void 0 : d.addStores([a]);
            d = s(c);
            d = a.getAllByFields(b, d);
            var e = Object.create(null);
            for (var f = 0; f < b.length; f++) {
                var g = b[f],
                    h = d.get(g);
                e[g] = c(k(h))
            }
            return e
        }
    }
    g.TDerivedBase = i;
    g.DATA_IS_STILL_LOADING_EXCEPTION = j;
    g.loader = m;
    g.currentStoreHandlers = o;
    g.modularLoader = a;
    g.modularLoaderWithoutArgs = b;
    g.loaderWithoutArgs = p;
    g.selectorLoader = q;
    g.selectorLoaderWithoutArgs = d;
    g.deferredSelectorLoader = r;
    g.deferredDefaultSelectorLoader = e;
    g.storeByIdLoader = f;
    g.storeByAllIdsLoader = t
}), 98);
__d("EngagementAudienceUITypedLogger", ["Banzai", "GeneratedLoggerUtils", "nullthrows"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {}
        }
        var c = a.prototype;
        c.log = function(a) {
            b("GeneratedLoggerUtils").log("logger:EngagementAudienceUILoggerConfig", this.$1, b("Banzai").BASIC, a)
        };
        c.logVital = function(a) {
            b("GeneratedLoggerUtils").log("logger:EngagementAudienceUILoggerConfig", this.$1, b("Banzai").VITAL, a)
        };
        c.logImmediately = function(a) {
            b("GeneratedLoggerUtils").log("logger:EngagementAudienceUILoggerConfig", this.$1, {
                signal: !0
            }, a)
        };
        c.clear = function() {
            this.$1 = {};
            return this
        };
        c.getData = function() {
            return babelHelpers["extends"]({}, this.$1)
        };
        c.updateData = function(a) {
            this.$1 = babelHelpers["extends"]({}, this.$1, a);
            return this
        };
        c.setAdAccount = function(a) {
            this.$1.ad_account = a;
            return this
        };
        c.setAppName = function(a) {
            this.$1.app_name = a;
            return this
        };
        c.setEventName = function(a) {
            this.$1.event_name = a;
            return this
        };
        c.updateExtraData = function(a) {
            a = b("nullthrows")(b("GeneratedLoggerUtils").serializeMap(a));
            b("GeneratedLoggerUtils").checkExtraDataFieldNames(a, g);
            this.$1 = babelHelpers["extends"]({}, this.$1, a);
            return this
        };
        c.addToExtraData = function(a, b) {
            var c = {};
            c[a] = b;
            return this.updateExtraData(c)
        };
        return a
    }();
    var g = {
        ad_account: !0,
        app_name: !0,
        event_name: !0
    };
    f["default"] = a
}), 66);
__d("AdsEngagementAudienceUILogger", ["EngagementAudienceUITypedLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "",
        i = "0";

    function a(a) {
        i = a
    }

    function b(a) {
        h = a
    }

    function d(a, b) {
        (!h || !i) && (h = h || "Unknown", i = i || "0");
        a = new(c("EngagementAudienceUITypedLogger"))().setAppName(h).setAdAccount(i).setEventName(a);
        b && a.updateExtraData(b);
        a.log()
    }
    g.setAdAccountID = a;
    g.setAppName = b;
    g.log = d
}), 98);
__d("AdsInterfacesRouteUpdateParamsDataActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "ADS_INTERFACES_ROUTE-UPDATE_PARAMS"
    }
}), null);
__d("AdsLoadStateUtils_LEGACY", ["invariant", "AdsCachedLoadState_LEGACY", "AdsLoadState_LEGACY", "LoadObject", "immutable", "isEmpty"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        return a.loadState === c("AdsLoadState_LEGACY").LOADING
    }

    function b(a) {
        return !!a && a.loadState === c("AdsLoadState_LEGACY").LOADED
    }

    function d(a) {
        return a.loadState === c("AdsLoadState_LEGACY").DELETING
    }

    function i(a) {
        return !!a && a.loadState === c("AdsLoadState_LEGACY").ERROR
    }

    function e(a) {
        return a.loadState === c("AdsLoadState_LEGACY").PENDING_WRITE
    }

    function f(a) {
        a.loadState === c("AdsLoadState_LEGACY").LOADED || h(0, 5733, a.loadState);
        return a
    }

    function j() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        return r(c("AdsLoadState_LEGACY").LOADING, b)
    }

    function k() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        return r(c("AdsLoadState_LEGACY").LOADED, b)
    }

    function l() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        return r(c("AdsLoadState_LEGACY").ERROR, b)
    }

    function m() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        return r(c("AdsLoadState_LEGACY").DELETING, b)
    }

    function n() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        return q(c("AdsLoadState_LEGACY").LOADED, b)
    }

    function o(a) {
        a = a.reduce(function(a, b) {
            return Math.min(a, F(b))
        }, F(c("AdsLoadState_LEGACY").LOADED));
        return E(a)
    }

    function p(a) {
        var b = F(c("AdsLoadState_LEGACY").LOADED);
        a.forEach(function(a) {
            b = Math.min(b, F(a.loadState))
        });
        return E(b)
    }

    function q(a, b) {
        return b.every(function(b) {
            if (!b) return !0;
            b = b.values();
            var c = b.next();
            while (!c.done) {
                if (c.value && c.value.loadState !== a) return !1;
                c = b.next()
            }
            return !0
        })
    }

    function r(a, b) {
        return b.some(function(b) {
            if (!b) return !1;
            b = b.values();
            var c = b.next();
            while (!c.done) {
                if (c.value && c.value.loadState === a) return !0;
                c = b.next()
            }
            return !1
        })
    }

    function s(a) {
        return i(a) ? a.error : null
    }

    function t() {
        for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
        var d = b.map(u);
        return [].concat.apply([], d)
    }

    function u(a) {
        var b = [];
        a && a.forEach(function(a) {
            a = s(a);
            a && b.push(a)
        });
        return b
    }

    function v() {
        for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
        var d = b.map(w);
        return [].concat.apply([], d)
    }

    function w(a) {
        var b = [];
        a && a.forEach(function(a) {
            a && a.loadState === c("AdsLoadState_LEGACY").LOADED && b.push(a)
        });
        return b
    }

    function x(a) {
        var b = a.loadState;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["loadState"]);
        var d = !c("isEmpty")(a);
        switch (b) {
            case c("AdsLoadState_LEGACY").ERROR:
                return c("LoadObject").empty().setError(a.error || new Error());
            case c("AdsLoadState_LEGACY").LOADED:
                return d ? c("LoadObject").withValue(a) : c("LoadObject").empty();
            case c("AdsLoadState_LEGACY").LOADING:
                return d ? c("LoadObject").loading().setValue(a) : c("LoadObject").loading();
            case c("AdsLoadState_LEGACY").NOT_LOADED:
                return c("LoadObject").empty();
            case c("AdsLoadState_LEGACY").PENDING_WRITE:
                return d ? c("LoadObject").updating().setValue(a) : c("LoadObject").updating();
            case c("AdsLoadState_LEGACY").DELETING:
                return d ? c("LoadObject").deleting().setValue(a) : c("LoadObject").deleting();
            default:
                return h(!1, "Invalid load state %s", b)
        }
    }

    function y(a) {
        if (a.isEmpty()) return c("AdsCachedLoadState_LEGACY").NOT_LOADED;
        if (a.isLoading()) return c("AdsCachedLoadState_LEGACY").LOADING;
        if (a.hasError()) return {
            loadState: c("AdsLoadState_LEGACY").ERROR,
            error: a.getError()
        };
        if (a.isUpdating()) return babelHelpers["extends"]({
            loadState: c("AdsLoadState_LEGACY").PENDING_WRITE
        }, a.getValue());
        if (a.isDeleting()) return babelHelpers["extends"]({
            loadState: c("AdsLoadState_LEGACY").DELETING
        }, a.getValue());
        a = a.getValue() || {};
        return babelHelpers["extends"]({
            loadState: c("AdsLoadState_LEGACY").LOADED
        }, a)
    }

    function z(a) {
        a = y(a);
        return a.loadState === c("AdsLoadState_LEGACY").NOT_LOADED ? c("AdsCachedLoadState_LEGACY").LOADING : a
    }

    function A(a) {
        var b = new Map();
        a.forEach(function(a, c) {
            b.set(c, z(a))
        });
        return b
    }

    function B(a) {
        if (a.isEmpty()) return c("AdsCachedLoadState_LEGACY").NOT_LOADED;
        if (a.isLoading()) return c("AdsCachedLoadState_LEGACY").LOADING;
        if (a.hasError()) return {
            loadState: c("AdsLoadState_LEGACY").ERROR,
            list: [],
            error: a.getError()
        };
        var b = a.getValue() || [];
        b = b.slice();
        if (a.isUpdating()) return {
            loadState: c("AdsLoadState_LEGACY").PENDING_WRITE,
            list: b
        };
        return a.isDeleting() ? {
            loadState: c("AdsLoadState_LEGACY").DELETING,
            list: b
        } : {
            loadState: c("AdsLoadState_LEGACY").LOADED,
            list: b
        }
    }

    function C(a) {
        a = B(a);
        return a.loadState === c("AdsLoadState_LEGACY").NOT_LOADED ? c("AdsCachedLoadState_LEGACY").LOADING : a
    }

    function D(a) {
        var b = a.loadState;
        a = a.list;
        a = c("immutable").List(a);
        switch (b) {
            case c("AdsLoadState_LEGACY").ERROR:
                return c("LoadObject").withError(new Error());
            case c("AdsLoadState_LEGACY").LOADED:
                return c("LoadObject").withValue(a);
            case c("AdsLoadState_LEGACY").LOADING:
                return c("LoadObject").withValue(a).loading();
            case c("AdsLoadState_LEGACY").NOT_LOADED:
                return c("LoadObject").empty();
            case c("AdsLoadState_LEGACY").PENDING_WRITE:
                return c("LoadObject").withValue(a).updating();
            default:
                return h(!1, "Invalid load state")
        }
    }

    function E(a) {
        switch (a) {
            case 0:
                return c("AdsLoadState_LEGACY").NOT_LOADED;
            case 1:
                return c("AdsLoadState_LEGACY").LOADING;
            case 2:
                return c("AdsLoadState_LEGACY").PENDING_WRITE;
            case 3:
                return c("AdsLoadState_LEGACY").ERROR;
            case 4:
                return c("AdsLoadState_LEGACY").LOADED;
            default:
                h(0, 5734)
        }
    }

    function F(a) {
        switch (a) {
            case c("AdsLoadState_LEGACY").NOT_LOADED:
                return 0;
            case c("AdsLoadState_LEGACY").LOADING:
                return 1;
            case c("AdsLoadState_LEGACY").PENDING_WRITE:
                return 2;
            case c("AdsLoadState_LEGACY").ERROR:
                return 3;
            case c("AdsLoadState_LEGACY").LOADED:
                return 4;
            default:
                return void 0
        }
    }

    function G(a) {
        if (a.isEmpty()) return c("AdsLoadState_LEGACY").NOT_LOADED;
        if (a.isLoading()) return c("AdsLoadState_LEGACY").LOADING;
        return a.hasError() ? c("AdsLoadState_LEGACY").ERROR : c("AdsLoadState_LEGACY").LOADED
    }

    function H(a) {
        if (a === c("AdsLoadState_LEGACY").NOT_LOADED) return c("LoadObject").empty();
        if (a === c("AdsLoadState_LEGACY").LOADING || a === c("AdsLoadState_LEGACY").DELETING || a === c("AdsLoadState_LEGACY").PENDING_WRITE) return c("LoadObject").loading();
        if (a === c("AdsLoadState_LEGACY").ERROR) return c("LoadObject").withError(new Error());
        h(0, 5735, a)
    }

    function I(a) {
        return a === c("AdsLoadState_LEGACY").LOADED ? c("LoadObject").withValue(null) : H(a)
    }
    g.isLoading = a;
    g.isLoaded = b;
    g.isDeleting = d;
    g.isError = i;
    g.isPendingWrite = e;
    g.enforceLoaded = f;
    g.anyLoading = j;
    g.anyLoaded = k;
    g.anyError = l;
    g.anyDeleting = m;
    g.allLoaded = n;
    g.mergeLoadStates = o;
    g.mergeLoadStatesForMap = p;
    g._allHaveLoadState = q;
    g._anyHasLoadState = r;
    g.getError = s;
    g.getErrorValues = t;
    g._getErrorValuesSingleMap = u;
    g.getLoadedValues = v;
    g.getLoadedValuesSingleMap = w;
    g.toLoadObject = x;
    g.fromLoadObject = y;
    g.fromLoadObjectTreatEmptyAsLoading = z;
    g.fromLoadObjectMapTreatEmptyAsLoading = A;
    g.fromLoadObjectToListObject = B;
    g.fromLoadObjectToListObjectTreatEmptyAsLoading = C;
    g.listObjectToLoadObject = D;
    g.fromIndex = E;
    g.toIndex = F;
    g.getLoadStateForLoadObject = G;
    g.getLoadObjectForNotLoadedState = H;
    g.getLoadObjectForLoadState = I
}), 98);
__d("AdsPERefreshTableViewActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "PowerEditor.REFRESH_TABLE_VIEW"
    }
}), null);
__d("AdsPEUploadShowPreviewActionFlux", [], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = {
        actionType: "PowerEditor.UPLOAD.SHOW_PREVIEW"
    }
}), null);
__d("AdsPixelUIEnvironments", ["keyMirror"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        AM: null,
        CF: null,
        CM: null,
        GC: null,
        LWI: null,
        PE: null
    });
    b = a;
    g["default"] = b
}), 98);
__d("AdsTimezone", ["AdsTimezoneConfig", "AdsTimezoneDisplayNamesStatic", "TimezoneNamesData", "compareString"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Array(c("AdsTimezoneConfig").offsets.length);
    for (var a = 1; a < c("AdsTimezoneConfig").offsets.length; a++) {
        b = c("AdsTimezoneConfig").offsets[a].split(":");
        d = parseInt(b[0], 10);
        e = d >= 0 ? 1 : -1;
        f = e * parseInt(b[1] || "0", 10);
        h[a] = d + f / 60
    }
    e = {};
    for (var b = 1; b < c("AdsTimezoneConfig").offsets.length; b++) {
        e[b] = {
            displayName: ((d = c("AdsTimezoneDisplayNamesStatic")[b]) == null ? void 0 : d.toString()) || c("AdsTimezoneConfig").names[b],
            name: c("AdsTimezoneConfig").names[b],
            offset: c("AdsTimezoneConfig").offsets[b]
        }
    }
    f = [];
    for (var a = 1; a < c("AdsTimezoneConfig").offsets.length; a++) {
        d = e[a];
        f.push({
            id: a,
            displayName: "(GMT" + d.offset + ") " + d.name.replace("_", " "),
            name: d.name,
            offset: d.offset
        })
    }
    f.sort(function(a, b) {
        var d = h[a.id] - h[b.id];
        return d ? d : c("compareString")(a.name, b.name)
    });
    b = [];
    for (var d = 1; d < c("AdsTimezoneConfig").offsets.length; d++) b[d] = c("TimezoneNamesData").zoneNames[d];
    b[0] = "";
    g.timezoneIDToOffsetMap = h;
    g.timezoneDataByID = e;
    g.sortedTimezones = f;
    g.names = b;
    g.countryCodeToTimezoneIDsMap = c("AdsTimezoneConfig").byCountryCode
}), 98);
__d("DateUtil", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        FACEBOOK_EPOCH: 1105776e3
    })
}), null);
__d("XAdsAccountQualityController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/accountquality/{?primary_id}/{?secondary_id}/", {
        business_id: {
            type: "FBID"
        },
        global_scope_id: {
            type: "FBID"
        },
        ad_account_id: {
            type: "FBID"
        },
        appeal_case_id: {
            type: "FBID"
        },
        primary_id: {
            type: "FBID"
        },
        secondary_id: {
            type: "FBID"
        },
        selected_adgroup_ids: {
            type: "FBIDVector"
        },
        tab: {
            type: "Enum",
            defaultValue: "available_for_review",
            enumType: 1
        },
        source: {
            type: "Enum",
            defaultValue: "link",
            enumType: 1
        },
        asset_view_type: {
            type: "Enum",
            defaultValue: "customer_feedback",
            enumType: 1
        },
        landing_page: {
            type: "Enum",
            defaultValue: "unknown",
            enumType: 1
        },
        entity: {
            type: "Enum",
            enumType: 1
        },
        launch_date: {
            type: "Int"
        },
        redirect_to_app: {
            type: "Bool",
            defaultValue: !0
        },
        do_on_load: {
            type: "Enum",
            enumType: 1
        }
    })
}), null);
__d("AdsAccountStore", ["invariant", "AdsAMAccountAcceptedTosAddActionFlux", "AdsAMAccountInitActionFlux", "AdsAccountAddCapabilitiesDataActionFlux", "AdsAccountAttributionSpecLoadSuccessDataActionFlux", "AdsAccountAttributionSpecUpdateStartDataActionFlux", "AdsAccountAttributionSpecUpdateSuccessDataActionFlux", "AdsAccountBatchLoadErrorDataActionFlux", "AdsAccountBatchLoadedDataActionFlux", "AdsAccountChangeAccountCountryDataActionFlux", "AdsAccountChangeAccountCurrencyDataActionFlux", "AdsAccountChangeAccountNameDataActionFlux", "AdsAccountChangeAccountTimezoneIdDataActionFlux", "AdsAccountDataDispatcher", "AdsAccountDataLoader", "AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataActionFlux", "AdsAccountDefaultUnifiedAttrSpecUpdateStartDataActionFlux", "AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataActionFlux", "AdsAccountGKsErrorActionFlux", "AdsAccountGKsLoadedActionFlux", "AdsAccountInitDataActionFlux", "AdsAccountInvalidateDataActionFlux", "AdsAccountListInvalidateDataActionFlux", "AdsAccountSelectDataActionFlux", "AdsAccountSettingsCreateFinishedDataActionFlux", "AdsAccountSettingsUpdateStartDataActionFlux", "AdsAccountUtils", "AdsAccountViewerPermissionsLoadErrorDataActionFlux", "AdsAccountViewerPermissionsLoadedDataActionFlux", "AdsAdgroupAcceptMAIDeeplinkTOSDataActionFlux", "AdsApplicationUtils", "AdsCachedLoadState_LEGACY", "AdsCountries", "AdsDMLQueryHandler_DerivedDataBase", "AdsDataAtom", "AdsEngagementAudienceUILogger", "AdsInterfacesRouteUpdateParamsDataActionFlux", "AdsLoadStateUtils_LEGACY", "AdsLoadState_LEGACY", "AdsPERefreshTableViewActionFlux", "AdsPEUploadShowPreviewActionFlux", "AdsPaymentsCountryToCurrencyLegalReq", "AdsPixelUIEnvironments", "AdsTimezone", "Arbiter", "DateTime", "DateUtil", "FBLogger", "FluxStore", "LoadObject", "URI", "XAdsAccountQualityController", "adsCreateSelector", "adsCreateStoreSelector", "getByPath", "gkx", "goURI", "ifRequired", "immutable", "isFalsey", "performanceNow", "promiseDone"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = "US",
        j = -7,
        k = 1;
    a = 0;
    var l = c("DateTime").fromLegacyArgs(c("DateUtil").FACEBOOK_EPOCH * 1e3, a).toISOString(),
        m = c("gkx")("6426"),
        n = !1;

    function o(a) {
        if (n) return;
        n = !0;
        c("Arbiter").inform("ads_account_store_acc_id", {
            src: a,
            ts: c("performanceNow")()
        }, "state")
    }
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            b = a.call(this, c("AdsDataAtom")) || this;
            b.getSelectedAccountID = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                return d("AdsApplicationUtils").isFAME() ? c("ifRequired")("AdsExcelAccountProvider", function(a) {
                    return a().selectedAccountID
                }) : b.$AdsAccountStoreClass1
            }, {
                name: f.id
            });
            b.getSelectedAccountIDX = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                if (d("AdsApplicationUtils").isFAME()) {
                    var a = c("ifRequired")("AdsExcelAccountProvider", function(a) {
                        return a().selectedAccountID
                    });
                    !a && h(0, 5919, a);
                    return a
                }
                a = b.$AdsAccountStoreClass10();
                !a && h(0, 5919, a);
                return a
            }, {
                name: f.id
            });
            b.getSelectedBusinessID = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                return b.$AdsAccountStoreClass2
            }, {
                name: f.id
            });
            b.getCreatedTime = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                var a = b.__getSelectedAccount().created_time;
                return a ? a : l
            }, {
                name: f.id
            });
            b.getTimezoneID = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                var a = b.__getSelectedAccount().timezone_id;
                return a ? a : k
            }, {
                name: f.id
            });
            b.getTosAccepted = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                return b.__getSelectedAccount().tos_accepted
            }, {
                name: f.id
            });
            b.getSelectedAccount = c("adsCreateStoreSelector")([babelHelpers.assertThisInitialized(b)], function() {
                return d("AdsApplicationUtils").isFAME() ? c("ifRequired")("AdsExcelAccountProvider", function(a) {
                    a = a();
                    var b = a.selectedAccountID;
                    a = a.accounts;
                    a = b != null ? a.get(b) : null;
                    return a || c("LoadObject").empty()
                }) || c("LoadObject").empty() : d("AdsLoadStateUtils_LEGACY").toLoadObject(b.__getSelectedAccount())
            }, {
                name: f.id
            });
            b.dmlGetSelectedAccount = d("AdsDMLQueryHandler_DerivedDataBase").modularLoader(function() {
                return b.getSelectedAccount.getStores()
            }, b.getSelectedAccount);
            b.getSelectedAccountCapabilities = c("adsCreateSelector")([b.getSelectedAccount], function(a) {
                return ((a = a.getValue()) == null ? void 0 : a.capabilities) || []
            }, {
                name: f.id
            });
            b.$AdsAccountStoreClass4 = {};
            b.$AdsAccountStoreClass3 = new Map();
            b.$AdsAccountStoreClass5 = !1;
            b.$AdsAccountStoreClass6 = new Map();
            b.$AdsAccountStoreClass7 = !1;
            return b
        }
        var e = b.prototype;
        e.__getActionTypes = function() {
            return [d("AdsAccountInitDataActionFlux").actionType, d("AdsAccountBatchLoadedDataActionFlux").actionType, d("AdsAccountBatchLoadErrorDataActionFlux").actionType, d("AdsAccountChangeAccountNameDataActionFlux").actionType, d("AdsAccountChangeAccountCountryDataActionFlux").actionType, d("AdsAccountChangeAccountCurrencyDataActionFlux").actionType, d("AdsAccountChangeAccountTimezoneIdDataActionFlux").actionType, d("AdsAccountAddCapabilitiesDataActionFlux").actionType, d("AdsAccountGKsErrorActionFlux").actionType, d("AdsAccountGKsLoadedActionFlux").actionType, d("AdsInterfacesRouteUpdateParamsDataActionFlux").actionType, d("AdsAccountSelectDataActionFlux").actionType, d("AdsAccountSettingsCreateFinishedDataActionFlux").actionType, d("AdsAccountSettingsUpdateStartDataActionFlux").actionType, d("AdsAccountInvalidateDataActionFlux").actionType, d("AdsAccountListInvalidateDataActionFlux").actionType, d("AdsAccountViewerPermissionsLoadedDataActionFlux").actionType, d("AdsAccountViewerPermissionsLoadErrorDataActionFlux").actionType, d("AdsAccountAttributionSpecUpdateStartDataActionFlux").actionType, d("AdsAccountAttributionSpecUpdateSuccessDataActionFlux").actionType, d("AdsAccountAttributionSpecLoadSuccessDataActionFlux").actionType, d("AdsAccountDefaultUnifiedAttrSpecUpdateStartDataActionFlux").actionType, d("AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataActionFlux").actionType, d("AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataActionFlux").actionType, d("AdsAdgroupAcceptMAIDeeplinkTOSDataActionFlux").actionType, d("AdsAMAccountAcceptedTosAddActionFlux").actionType, d("AdsAMAccountInitActionFlux").actionType, d("AdsPERefreshTableViewActionFlux").actionType, d("AdsPEUploadShowPreviewActionFlux").actionType]
        };
        e.canUpdateCurrency = function() {
            if (this.$AdsAccountStoreClass1 == null) return !1;
            var a = this.getCached(this.$AdsAccountStoreClass1).getValue();
            if (c("isFalsey")(a)) return !1;
            var b = c("AdsAccountUtils").hasCapability(a, "CAN_UPDATE_CURRENCY");
            a = c("AdsAccountUtils").isPaymentInfoRequired(a);
            return b && a
        };
        e.get = function(a) {
            if (d("AdsApplicationUtils").isFAME()) return c("ifRequired")("AdsExcelAccountProvider", function(b) {
                b = b();
                b = b.accounts;
                return b.get(a)
            }) || c("LoadObject").empty();
            return a === this.$AdsAccountStoreClass1 ? this.getSelectedAccount() : d("AdsLoadStateUtils_LEGACY").toLoadObject(this.$AdsAccountStoreClass8(a))
        };
        e.$AdsAccountStoreClass8 = function(a) {
            if (d("AdsApplicationUtils").isFAME()) return c("ifRequired")("AdsExcelAccountProvider", function(b) {
                b = b();
                b = b.accounts;
                return d("AdsLoadStateUtils_LEGACY").fromLoadObject(b.get(a))
            }) || c("AdsCachedLoadState_LEGACY").NOT_LOADED;
            var b = this.$AdsAccountStoreClass3.get(a);
            b || (b = c("AdsCachedLoadState_LEGACY").LOADING, this.$AdsAccountStoreClass3.set(a, b), c("AdsAccountDataDispatcher").loadAccountData(a));
            return b
        };
        e.getCached = function(a) {
            if (d("AdsApplicationUtils").isFAME()) return c("ifRequired")("AdsExcelAccountProvider", function(b) {
                b = b();
                b = b.accounts;
                return b.get(a)
            }) || c("LoadObject").empty();
            var b = this.$AdsAccountStoreClass3.get(a);
            b || (b = c("AdsCachedLoadState_LEGACY").NOT_LOADED);
            return d("AdsLoadStateUtils_LEGACY").toLoadObject(b)
        };
        e.isBusinessMigrationEligible = function() {
            return this.__getSelectedAccount().is_biz_migration_eligible || !1
        };
        e.$AdsAccountStoreClass9 = function() {
            var a = this.$AdsAccountStoreClass1;
            if (!a) return;
            c("AdsAccountDataDispatcher").loadAccountData(a);
            return
        };
        e.getAllLoadObjects = function(a) {
            a = this.getAll(a.toArray());
            var b = new Map();
            for (var a = a, e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                var h = g[0];
                g = g[1];
                b.set(h, d("AdsLoadStateUtils_LEGACY").toLoadObject(g))
            }
            return c("immutable").Map(b)
        };
        e.getAll = function(a) {
            var b = this,
                c = new Map();
            a.forEach(function(a) {
                c.set(a, b.$AdsAccountStoreClass8(a))
            });
            return c
        };
        e.getAllCached = function(a) {
            var b = this,
                d = new Map();
            a.forEach(function(a) {
                var e = b.$AdsAccountStoreClass3.get(a);
                e || (e = c("AdsCachedLoadState_LEGACY").NOT_LOADED);
                d.set(a, e)
            });
            return d
        };
        e.getByFields = function(a, b) {
            var d = this.$AdsAccountStoreClass3.get(a);
            if (!d) {
                c("AdsAccountDataDispatcher").loadAccountDataByFields(a, b);
                this.$AdsAccountStoreClass3.set(a, c("AdsCachedLoadState_LEGACY").LOADING);
                return c("AdsCachedLoadState_LEGACY").LOADING
            }
            if (d.loadState === c("AdsLoadState_LEGACY").ERROR) return c("AdsCachedLoadState_LEGACY").ERROR;
            if (d.loadState === c("AdsLoadState_LEGACY").LOADING) return c("AdsCachedLoadState_LEGACY").LOADING;
            var e = b.some(function(a) {
                return d[a] === null || d[a] === void 0
            });
            if (e) {
                c("AdsAccountDataDispatcher").loadAccountDataByFields(a, b);
                this.$AdsAccountStoreClass3.set(a, babelHelpers["extends"]({}, d, {
                    loadState: c("AdsLoadState_LEGACY").LOADING
                }));
                return c("AdsCachedLoadState_LEGACY").LOADING
            }
            var f = {};
            b.forEach(function(a) {
                f[a] = d[a]
            });
            f.loadState = c("AdsLoadState_LEGACY").LOADED;
            return f
        };
        e.getAllByFields = function(a, b) {
            var c = this,
                d = new Map();
            a.forEach(function(a) {
                d.set(a, c.getByFields(a, b))
            });
            return d
        };
        e.$AdsAccountStoreClass10 = function() {
            return this.$AdsAccountStoreClass1
        };
        e.getSelectedBusinessIDEnforcing = function() {
            var a = this.getSelectedBusinessID();
            a || h(0, 5920);
            return a
        };
        e.getMinDailyBudget = function() {
            var a = this.__getSelectedAccount().min_daily_budget;
            return a ? a : 0
        };
        e.getHasSuperRead = function() {
            return !!this.__getSelectedAccount().hasSuperRead
        };
        e.getPromotableObjects = function() {
            var a = this.__getSelectedAccount().ad_account_promotable_objects,
                b = [],
                c = [],
                d = [];
            a && (b = a.promotableAppIDs, c = a.promotablePageIDs, d = a.promotableUrls);
            return {
                promotableAppIDs: b,
                promotablePageIDs: c,
                promotableUrls: d
            }
        };
        e.getTimezoneName = function() {
            var a = this.__getSelectedAccount().timezone_name;
            return a ? a : ""
        };
        e.getTimezoneOffsetHoursUTC = function() {
            var a = this.__getSelectedAccount().timezone_offset_hours_utc;
            return a ? a : j
        };
        e.getViewerPermissions = function() {
            var a = p.$AdsAccountStoreClass10();
            if (a) {
                this.$AdsAccountStoreClass4[a] || (this.$AdsAccountStoreClass4[a] = c("LoadObject").loading(), c("AdsAccountDataDispatcher").loadViewerPermissions(a));
                return this.$AdsAccountStoreClass4[a]
            }
            return c("LoadObject").empty()
        };
        e.getViewerHasPermission = function(a) {
            var b = p.getViewerPermissions();
            return b.hasValueWithoutError() && Array.isArray(b.getValueEnforcing().data) && b.getValueEnforcing().data.includes(a)
        };
        e.__getSelectedAccount = function() {
            if (d("AdsApplicationUtils").isFAME()) return c("ifRequired")("AdsExcelAccountProvider", function(a) {
                a = a();
                var b = a.selectedAccountID;
                a = a.accounts;
                a = b != null ? a.get(b) : null;
                return a != null ? d("AdsLoadStateUtils_LEGACY").fromLoadObject(a) : null
            }) || c("AdsCachedLoadState_LEGACY").NOT_LOADED;
            var a = this.$AdsAccountStoreClass10();
            return !a ? c("AdsCachedLoadState_LEGACY").NOT_LOADED : this.$AdsAccountStoreClass8(a)
        };
        e.hasAcceptedMAIDeeplinkTOS = function() {
            return !this.$AdsAccountStoreClass1 ? !1 : c("AdsAccountUtils").hasCapability(this.$AdsAccountStoreClass3.get(this.$AdsAccountStoreClass1), "HAS_ACCEPTED_MAI_DEEPLINK_TOS")
        };
        e.hasAcceptedOldMAEDeeplinkTOS = function() {
            return !this.$AdsAccountStoreClass1 ? !1 : c("AdsAccountUtils").hasCapability(this.$AdsAccountStoreClass3.get(this.$AdsAccountStoreClass1), "HAS_ACCEPTED_MOBILE_APP_ENGAGEMENT_TOS")
        };
        e.toURLParams = function() {
            return !this.$AdsAccountStoreClass1 ? null : {
                act: this.$AdsAccountStoreClass1
            }
        };
        e.getAccountStatus = function() {
            var a = this.__getSelectedAccount();
            return a === c("AdsCachedLoadState_LEGACY").NOT_LOADED ? null : a.account_status
        };
        e.getAccountInvalidationCount = function(a) {
            return this.$AdsAccountStoreClass6.get(a)
        };
        e.$AdsAccountStoreClass11 = function() {
            var a = this.__getSelectedAccount();
            c("DateTime").setupTimezoneFallback(a.timezone_id, a.timezone_offset_hours_utc)
        };
        e.hasChangedTableParams = function() {
            return this.$AdsAccountStoreClass7
        };
        e.__onDispatch = function(a) {
            var b = a.action;
            a = !1;
            this.$AdsAccountStoreClass7 = !1;
            var e = this.$AdsAccountStoreClass10();
            switch (b.actionType) {
                case d("AdsAccountInitDataActionFlux").actionType:
                    p.$AdsAccountStoreClass12(b.data);
                    a = !0;
                    this.$AdsAccountStoreClass7 = !0;
                    break;
                case d("AdsAccountBatchLoadedDataActionFlux").actionType:
                    p.$AdsAccountStoreClass13(b.accountID, b.account);
                    a = !0;
                    this.$AdsAccountStoreClass7 = !0;
                    break;
                case d("AdsAccountBatchLoadErrorDataActionFlux").actionType:
                    p.$AdsAccountStoreClass14(b.accountID, b.error);
                    a = !0;
                    break;
                case d("AdsAccountChangeAccountNameDataActionFlux").actionType:
                    if (e != null) {
                        var f = this.$AdsAccountStoreClass3.get(e);
                        if (f == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, f, {
                            name: b.name
                        }));
                        a = !0
                    }
                    break;
                case d("AdsAccountChangeAccountCountryDataActionFlux").actionType:
                    if (e != null) {
                        f = b.country;
                        var g = d("AdsTimezone").countryCodeToTimezoneIDsMap[f][0],
                            h = d("AdsTimezone").timezoneIDToOffsetMap[g],
                            i = this.__getSelectedAccount().currency,
                            j = this.$AdsAccountStoreClass3.get(e);
                        if (j == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, j, {
                            business_country_code: f,
                            timezone_id: g,
                            timezone_offset_hours_utc: h
                        }));
                        j = Object.prototype.hasOwnProperty.call(c("AdsPaymentsCountryToCurrencyLegalReq").legal_req, f) || Object.values(c("AdsPaymentsCountryToCurrencyLegalReq").legal_req).some(function(a) {
                            return a === i
                        });
                        if (!this.$AdsAccountStoreClass5 || j) {
                            g = d("AdsCountries").getCurrencyByCountry(f);
                            h = this.$AdsAccountStoreClass3.get(e);
                            if (h == null) break;
                            this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, h, {
                                currency: g
                            }))
                        }
                        this.$AdsAccountStoreClass11();
                        a = !0
                    }
                    break;
                case d("AdsAccountChangeAccountCurrencyDataActionFlux").actionType:
                    if (e != null) {
                        j = this.$AdsAccountStoreClass3.get(e);
                        if (j == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, j, {
                            currency: b.currency
                        }));
                        f = Object.keys(c("AdsPaymentsCountryToCurrencyLegalReq").legal_req).find(function(a) {
                            return c("AdsPaymentsCountryToCurrencyLegalReq").legal_req[a] === b.currency
                        });
                        if (f !== void 0) {
                            h = this.$AdsAccountStoreClass3.get(e);
                            if (h == null) break;
                            this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, h, {
                                business_country_code: f
                            }))
                        }
                        this.$AdsAccountStoreClass5 = !0;
                        a = !0
                    }
                    break;
                case d("AdsAccountChangeAccountTimezoneIdDataActionFlux").actionType:
                    if (e != null) {
                        g = this.$AdsAccountStoreClass3.get(e);
                        if (g == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, g, {
                            timezone_id: b.timezoneID,
                            timezone_offset_hours_utc: d("AdsTimezone").timezoneIDToOffsetMap[b.timezoneID]
                        }));
                        this.$AdsAccountStoreClass11();
                        a = !0
                    }
                    break;
                case d("AdsPEUploadShowPreviewActionFlux").actionType:
                    b.didUpdateAccount && this.$AdsAccountStoreClass9();
                    break;
                case d("AdsAccountAddCapabilitiesDataActionFlux").actionType:
                    if (e != null) {
                        j = this.__getSelectedAccount();
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, j, {
                            capabilities: j.capabilities.concat(b.capabilities)
                        }));
                        a = !0
                    }
                    break;
                case d("AdsPERefreshTableViewActionFlux").actionType:
                    this.__invalidateAllErrors() && (a = !0);
                    break;
                case d("AdsInterfacesRouteUpdateParamsDataActionFlux").actionType:
                    this.__invalidateAllErrors() && (a = !0);
                    h = b.data.changedParamKeys;
                    if (h.act || h.business_id) {
                        f = b.data.params;
                        if (!f.act && f.tool === "REPORTING") this.$AdsAccountStoreClass15(f.business_id, f.act);
                        else if (f.act) this.$AdsAccountStoreClass16(f.act, f.business_id, d("AdsInterfacesRouteUpdateParamsDataActionFlux").actionType);
                        else break;
                        a = !0;
                        this.$AdsAccountStoreClass7 = !0
                    }
                    break;
                case d("AdsAccountSelectDataActionFlux").actionType:
                    if (d("AdsApplicationUtils").isPowerEditor()) break;
                    this.$AdsAccountStoreClass16(b.accountID, b.businessID, d("AdsAccountSelectDataActionFlux").actionType);
                    a = !0;
                    break;
                case d("AdsAccountSettingsCreateFinishedDataActionFlux").actionType:
                    this.$AdsAccountStoreClass17(b.accountID, b.settingsID);
                    break;
                case d("AdsAccountSettingsUpdateStartDataActionFlux").actionType:
                    this.$AdsAccountStoreClass1 != null && c("AdsAccountDataDispatcher").updateAccount(this.$AdsAccountStoreClass1, b.data);
                    break;
                case d("AdsAccountInvalidateDataActionFlux").actionType:
                    this.$AdsAccountStoreClass18(b.id) && (a = !0);
                    break;
                case d("AdsAccountListInvalidateDataActionFlux").actionType:
                    this.$AdsAccountStoreClass19(b.accounts) && (a = !0);
                    break;
                case d("AdsAccountViewerPermissionsLoadedDataActionFlux").actionType:
                    this.$AdsAccountStoreClass4[b.accountID] = c("LoadObject").withValue({
                        data: b.data
                    });
                    a = !0;
                    break;
                case d("AdsAccountViewerPermissionsLoadErrorDataActionFlux").actionType:
                    this.$AdsAccountStoreClass4[b.accountID] = c("LoadObject").withError(new Error(b.data));
                    a = !0;
                    break;
                case d("AdsAccountAttributionSpecUpdateStartDataActionFlux").actionType:
                    e != null && c("AdsAccountDataDispatcher").updateAccountAttributionSpec(e, {
                        attribution_spec: b.attributionSpec
                    });
                    break;
                case d("AdsAccountAttributionSpecUpdateSuccessDataActionFlux").actionType:
                    if (e != null) {
                        c("AdsAccountDataDispatcher").loadAccountAttributionSpec(e);
                        g = this.$AdsAccountStoreClass3.get(e);
                        if (g == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, g, {
                            loadState: c("AdsLoadState_LEGACY").LOADING
                        }))
                    }
                    break;
                case d("AdsAccountAttributionSpecLoadSuccessDataActionFlux").actionType:
                    if (e != null) {
                        j = this.$AdsAccountStoreClass3.get(e);
                        if (j == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, j, {
                            attribution_spec: b.data.attribution_spec,
                            is_attribution_spec_system_default: b.data.is_attribution_spec_system_default,
                            loadState: c("AdsLoadState_LEGACY").LOADED
                        }));
                        a = !0
                    }
                    break;
                case d("AdsAccountDefaultUnifiedAttrSpecUpdateStartDataActionFlux").actionType:
                    e != null && c("AdsAccountDataDispatcher").updateAccountDefaultUnifiedAttrSpec(e, {
                        default_unified_attribution_spec: b.defaultUnifiedAttrSpec
                    });
                    break;
                case d("AdsAccountDefaultUnifiedAttrSpecUpdateSuccessDataActionFlux").actionType:
                    if (e != null) {
                        c("AdsAccountDataDispatcher").loadAccountDefaultUnifiedAttrSpec(e);
                        h = this.$AdsAccountStoreClass3.get(e);
                        if (h == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, h, {
                            loadState: c("AdsLoadState_LEGACY").LOADING
                        }))
                    }
                    break;
                case d("AdsAccountDefaultUnifiedAttrSpecLoadSuccessDataActionFlux").actionType:
                    if (e != null) {
                        f = this.$AdsAccountStoreClass3.get(e);
                        if (f == null) break;
                        this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, f, {
                            default_unified_attribution_spec: b.data.default_unified_attribution_spec,
                            loadState: c("AdsLoadState_LEGACY").LOADED
                        }));
                        a = !0
                    }
                    break;
                case d("AdsAdgroupAcceptMAIDeeplinkTOSDataActionFlux").actionType:
                    c("AdsAccountDataDispatcher").handleAcceptMAIDeeplinkTOS(this.getSelectedAccountID());
                    a = !0;
                    break;
                case d("AdsAMAccountAcceptedTosAddActionFlux").actionType:
                    if (e == null) break;
                    g = this.$AdsAccountStoreClass3.get(e);
                    if (g == null) break;
                    j = g.tos_accepted ? g.tos_accepted : Object();
                    j = babelHelpers["extends"]({}, j, b.addedTOS);
                    this.$AdsAccountStoreClass3.set(e, babelHelpers["extends"]({}, g, {
                        tos_accepted: j
                    }));
                    a = !0;
                    break;
                case d("AdsAMAccountInitActionFlux").actionType:
                    h = b.account.account_id;
                    if (this.$AdsAccountStoreClass20(h)) {
                        this.$AdsAccountStoreClass21(h);
                        break
                    }
                    this.$AdsAccountStoreClass1 = h;
                    p.$AdsAccountStoreClass13(h, b.account);
                    a = !0;
                    this.$AdsAccountStoreClass7 = !0;
                    o("flux");
                    break;
                case d("AdsAccountGKsErrorActionFlux").actionType:
                case d("AdsAccountGKsLoadedActionFlux").actionType:
                    a = !0;
                    break
            }
            a && this.__emitChange()
        };
        e.$AdsAccountStoreClass22 = function(a, b) {
            var d = this.$AdsAccountStoreClass3.get(a);
            !d || d.loadState === c("AdsLoadState_LEGACY").LOADING ? this.$AdsAccountStoreClass3.set(a, b) : this.$AdsAccountStoreClass3.set(a, babelHelpers["extends"]({}, d, b))
        };
        e.$AdsAccountStoreClass13 = function(a, b) {
            var d = this.$AdsAccountStoreClass3.get(a);
            d && this.$AdsAccountStoreClass3.set(a, babelHelpers["extends"]({}, d, {
                loadState: c("AdsLoadState_LEGACY").LOADED
            }));
            this.$AdsAccountStoreClass22(a, babelHelpers["extends"]({}, b, {
                loadState: c("AdsLoadState_LEGACY").LOADED
            }))
        };
        e.$AdsAccountStoreClass14 = function(a, b) {
            this.$AdsAccountStoreClass3.set(a, {
                loadState: c("AdsLoadState_LEGACY").ERROR,
                error: b
            })
        };
        e.$AdsAccountStoreClass12 = function(a) {
            var b = {},
                e = a.accountID;
            this.$AdsAccountStoreClass20(e) ? this.$AdsAccountStoreClass21(e) : (this.$AdsAccountStoreClass1 = e, this.$AdsAccountStoreClass2 = c("getByPath")(a.accountInfo, ["business", "id"]), b = a.accountInfo, b.business_country_code = b.business_country_code || i, b.name = a.accountName, b.hasSuperRead = a.hasSuperRead, c("promiseDone")(d("AdsAccountDataLoader").postUserSettings(e)), c("DateTime").setupTimezoneFallback(b.timezone_id, b.timezone_offset_hours_utc), d("AdsEngagementAudienceUILogger").setAppName(c("AdsPixelUIEnvironments").CM), b.loadState = c("AdsLoadState_LEGACY").LOADED, this.$AdsAccountStoreClass22(a.accountID, b), o("initAccountData"), c("ifRequired")("EventProfiler", function(a) {
                a.setCurrentAdAccountId(e)
            }))
        };
        e.$AdsAccountStoreClass18 = function(a) {
            return this.$AdsAccountStoreClass3.has(a) ? this.$AdsAccountStoreClass3["delete"](a) : !1
        };
        e.__invalidateAllAccounts = function() {
            this.$AdsAccountStoreClass3 = new Map()
        };
        e.__invalidateAllErrors = function() {
            var a = this,
                b = !1;
            this.$AdsAccountStoreClass3.forEach(function(d, e) {
                if (d.loadState === c("AdsLoadState_LEGACY").ERROR) {
                    d = a.$AdsAccountStoreClass18(e);
                    b = d || b
                }
            });
            return b
        };
        e.$AdsAccountStoreClass19 = function(a) {
            var b = this,
                c = !1;
            a.forEach(function(a) {
                c = c || b.$AdsAccountStoreClass18(a);
                var d = b.$AdsAccountStoreClass6.get(a);
                b.$AdsAccountStoreClass6.set(a, d ? d + 1 : 1)
            });
            return c
        };
        e.$AdsAccountStoreClass17 = function(a, b) {
            var d = this.$AdsAccountStoreClass3.get(a);
            d != null && d.loadState === c("AdsLoadState_LEGACY").LOADED && (d = babelHelpers["extends"]({}, d, {
                user_settings: {
                    id: b
                }
            }), this.$AdsAccountStoreClass3.set(a, d))
        };
        e.$AdsAccountStoreClass15 = function(a, b) {
            (b !== this.$AdsAccountStoreClass1 || a !== this.$AdsAccountStoreClass2) && (this.$AdsAccountStoreClass20(b) ? this.$AdsAccountStoreClass21(b) : (this.$AdsAccountStoreClass1 = b, this.$AdsAccountStoreClass2 = a, o("selectBusiness"), c("ifRequired")("EventProfiler", function(a) {
                a.setCurrentAdAccountId(b)
            })))
        };
        e.$AdsAccountStoreClass16 = function(a, b, d) {
            d = b !== this.$AdsAccountStoreClass2;
            (a !== this.$AdsAccountStoreClass1 || d) && (!d && this.$AdsAccountStoreClass20(a) ? this.$AdsAccountStoreClass21(a) : (this.$AdsAccountStoreClass1 = a, this.$AdsAccountStoreClass2 = b, c("FBLogger")("ads_account_switcher", "business__updates").warn("Business id updates within AdsAccountStore._selectAccount"), o("selectAccount"), c("ifRequired")("EventProfiler", function(b) {
                b.setCurrentAdAccountId(a)
            })))
        };
        e.__setStoreState = function(a) {
            var b = a.selectedAccountID,
                c = a.selectedBusinessID;
            a = a.accounts;
            var e = new Map();
            a.forEach(function(a, b) {
                e.set(b, babelHelpers["extends"]({}, a.getValueEnforcing(), {
                    loadState: d("AdsLoadStateUtils_LEGACY").fromLoadObject(a).loadState
                }))
            });
            this.$AdsAccountStoreClass20(b) ? this.$AdsAccountStoreClass21(b) : (this.$AdsAccountStoreClass1 = b, this.$AdsAccountStoreClass2 = c, this.$AdsAccountStoreClass3 = e, o("setStoreState"))
        };
        e.$AdsAccountStoreClass20 = function(a) {
            a = this.$AdsAccountStoreClass1 != null && this.$AdsAccountStoreClass1 !== a;
            return a && m
        };
        e.$AdsAccountStoreClass21 = function(a) {
            var b = new(c("URI"))(window.location.href);
            b.getPath().includes("accountquality") && a != null && (b = c("XAdsAccountQualityController").getURIBuilder().setFBID("primary_id", a).getURI());
            c("FBLogger")("ads_account_switcher", "account_updated_force_reload").warn("Force reload page when updating account id.");
            c("goURI")(b)
        };
        return b
    }(c("FluxStore"));
    b.__moduleID = f.id;
    var p = new b();
    e = p;
    g["default"] = e
}), 98);
__d("AdsHelpTrayFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("2004113");
    c = b("FalcoLoggerInternal").create("ads_help_tray", a);
    e.exports = c
}), null);
__d("getBusinessCurrentToolType", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a() {
        return g
    }
    a.init = function(a) {
        g = a
    };
    f["default"] = a
}), 66);
__d("AdsHelpTrayUILoggerStoreUtils", ["AdsAccountStore", "AdsHelpTrayFalcoEvent", "BusinessUnifiedNavigationLoggingConfig", "URI", "USID", "getBusinessCurrentToolType"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        var e = new(c("URI"))(window.location.href).getQueryData(),
            f = c("AdsAccountStore").getSelectedAccountID() || e.act;
        c("AdsHelpTrayFalcoEvent").log(function() {
            return {
                ad_account_id: f,
                event: a,
                event_data: b,
                session_id: c("BusinessUnifiedNavigationLoggingConfig").sessionID,
                tool: c("getBusinessCurrentToolType")() || d,
                usid_override: c("USID").get().serializeForRequest()
            }
        })
    }
    g.logHelpTrayEvents = a
}), 98);
__d("IdsIssueDetectionFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("3398");
    c = b("FalcoLoggerInternal").create("ids_issue_detection", a);
    e.exports = c
}), null);
__d("adsHelpTrayBizSitePageTypeFromButtonSelector", ["AdsHelpTrayUIProvider", "adsCreateSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        return a.bizSitePageTypeFromButton
    }, {
        name: f.id + ".adsHelpTrayBizSitePageTypeFromButtonSelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("adsHelpTrayCurrentContentCaseIDSelector", ["AdsHelpTrayNavigationHelper", "AdsHelpTrayUIProvider", "adsCreateSelector", "nullthrows"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        a = d("AdsHelpTrayNavigationHelper").getCurrentNavigationState(a);
        return a.contentType === "SUPPORT_CASE" ? c("nullthrows")(a.id) : ""
    }, {
        name: f.id + ".adsHelpTrayCurrentContentCaseIDSelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("adsHelpTrayCurrentContentSelector", ["AdsHelpTrayNavigationHelper", "AdsHelpTrayUIProvider", "adsCreateSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        return d("AdsHelpTrayNavigationHelper").getCurrentContentCMSID(a)
    }, {
        name: f.id + ".adsHelpTrayCurrentContentSelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("adsHelpTrayCurrentQuerySelector", ["AdsHelpTrayUIProvider", "adsCreateSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        return a.currentQuery || ""
    }, {
        name: f.id + ".adsHelpTrayCurrentQuerySelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("adsHelpTrayIsTrayOpenFromHelpButtonSelector", ["AdsHelpTrayUIProvider", "adsCreateSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        return a.source === "help_button" || a.source === "fbs_help_button"
    }, {
        name: f.id + ".adsHelpTrayIsTrayOpenFromHelpButtonSelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("adsHelpTrayIsTrayOpenSelector", ["AdsHelpTrayUIProvider", "adsCreateSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        return a.isTrayOpen
    }, {
        name: f.id + ".adsHelpTrayIsTrayOpenSelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("adsHelpTrayOpenModalTypeSelector", ["AdsHelpTrayUIProvider", "adsCreateSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("adsCreateSelector")([c("AdsHelpTrayUIProvider").toFluxSelector()], function(a) {
        return a.openModalType
    }, {
        name: f.id + ".adsHelpTrayOpenModalTypeSelector"
    });
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayUILogger", ["AdsHelpTrayModalTypes", "AdsHelpTrayUILoggerStoreUtils", "IdsIssueDetectionFalcoEvent", "adsHelpTrayBizSitePageTypeFromButtonSelector", "adsHelpTrayCurrentContentCaseIDSelector", "adsHelpTrayCurrentContentSelector", "adsHelpTrayCurrentQuerySelector", "adsHelpTrayIsTrayOpenFromHelpButtonSelector", "adsHelpTrayIsTrayOpenSelector", "adsHelpTrayOpenModalTypeSelector"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        d("AdsHelpTrayUILoggerStoreUtils").logHelpTrayEvents(a, b, c("adsHelpTrayBizSitePageTypeFromButtonSelector")())
    }

    function a(a) {
        h("support_form_asset_select", {
            assetID: a
        })
    }

    function b(a) {
        h("support_form_issue_select", {
            issueID: a
        })
    }

    function e(a) {
        h("support_form_plan_select", {
            planID: a
        })
    }

    function f(a) {
        h("support_form_channel_select", {
            channelID: a
        })
    }

    function i(a) {
        h("support_form_asset_is_rate_limited", {
            assetID: a
        })
    }

    function j(a, b, c, d, e) {
        h("support_form_case_submission", {
            formFailed: a,
            channelID: b,
            issueID: c,
            message: d,
            jobID: e
        })
    }

    function k(a) {
        h("support_form_article_see_more_click", {
            cmsID: a
        })
    }

    function l(a) {
        h("help_tray_case_details_see_more_click", {
            caseID: a
        })
    }

    function m(a) {
        h("support_form_article_loaded", {
            cmsID: a
        })
    }

    function n(a, b) {
        h("support_form_contact_support_click", {
            cmsID: a,
            issueID: b
        })
    }

    function o(a, b) {
        h("support_form_self_resolution_shown", {
            lbdPlanID: a,
            assetID: b
        })
    }

    function p(a, b) {
        var c = {};
        a != null && b != null && (c = {
            lbdIssueID: a,
            supportedAsset: b
        });
        h("support_form_common_issue_select", c)
    }

    function q(a, b, d) {
        h("support_form_detected_issue_select", {
            lbdIssueID: a,
            assetID: b,
            issueInstanceId: d
        }), c("IdsIssueDetectionFalcoEvent").log(function() {
            return {
                entity_id: b,
                ids_issue_id: d,
                ids_use_case: "HELP_TRAY",
                event_type: "DIAGNOSIS",
                event_name: "DETECTED_ISSUE_CLICK"
            }
        })
    }

    function r(a, b, c) {
        h("support_form_self_resolution_cta_click", {
            lbdPlanID: a,
            assetID: b,
            uri: c
        })
    }

    function s(a) {
        h("support_form_asset_select_change", {
            assetID: a
        })
    }

    function t(a) {
        h("support_form_plan_select_change", {
            lbdPlanID: a
        })
    }

    function u(a, b, c, d) {
        h("help_tray_recommended_article_impression", {
            cms_id: a,
            title: b,
            pathname: c,
            rank: d
        })
    }

    function v(a) {
        h("help_tray_positive_friction_load", {
            caseID: a
        })
    }

    function w(a) {
        h("help_tray_positive_friction_existing_case_click", {
            caseID: a
        })
    }

    function x(a) {
        h("help_tray_positive_friction_new_case_click", {
            caseID: a
        })
    }

    function y(a, b, c, d) {
        h("help_tray_recommended_article_click", {
            cms_id: a,
            title: b,
            pathname: c,
            rank: d
        })
    }

    function z(a, b, d, e) {
        h(a, babelHelpers["extends"]({}, e, {
            current_cms_id: (a = c("adsHelpTrayCurrentContentSelector")()) != null ? a : "",
            href: b,
            link_type: d
        }))
    }

    function A(a, b, c) {
        z("help_tray_help_article_other_link_click", a, b, c)
    }

    function B(a) {
        h(a ? "help_tray_recommended_article_view_more_click" : "help_tray_recommended_article_view_more_collapse")
    }

    function C() {
        h("help_tray_need_help_click")
    }

    function D() {
        h("help_tray_feedback_click")
    }

    function E() {
        h("help_center_click")
    }

    function F() {
        h("cancel_page_request_click")
    }

    function G(a, b) {
        b === void 0 && (b = c("adsHelpTrayCurrentContentCaseIDSelector")());
        var e = null;
        switch (a) {
            case d("AdsHelpTrayModalTypes").Modal.CLOSE_CASE:
                e = "case_tracking_close_case_modal_open";
                break;
            case d("AdsHelpTrayModalTypes").Modal.REQUEST_UPDATE:
                e = "case_tracking_request_update_modal_open";
                break;
            case d("AdsHelpTrayModalTypes").Modal.CONFIRMATION_REOPEN_CASE:
                e = "case_tracking_confirmation_reopen_case_modal_open";
                break;
            case d("AdsHelpTrayModalTypes").Modal.CONFIRMATION_REQUEST_UPDATE:
                e = "case_tracking_confirmation_request_update_modal_open";
                break;
            case d("AdsHelpTrayModalTypes").Modal.REOPEN_CASE:
                e = "case_tracking_reopen_case_modal_open";
                break;
            default:
                e = "case_tracking_confirmation_request_update_modal_open"
        }
        h(e, {
            job_id: b
        })
    }

    function H(a) {
        var b = c("adsHelpTrayOpenModalTypeSelector")(),
            e = c("adsHelpTrayCurrentContentCaseIDSelector")(),
            f = "case_tracking_close_case_modal_submission";
        switch (b) {
            case d("AdsHelpTrayModalTypes").Modal.CLOSE_CASE:
                f = "case_tracking_close_case_modal_submission";
                break;
            case d("AdsHelpTrayModalTypes").Modal.REQUEST_UPDATE:
                f = "case_tracking_request_update_modal_submission";
                break;
            case d("AdsHelpTrayModalTypes").Modal.REOPEN_CASE:
                f = "case_tracking_reopen_case_modal_submission";
                break
        }
        h(f, babelHelpers["extends"]({}, a, {
            job_id: e
        }))
    }

    function I(a) {
        h("help_tray_footer_click", {
            link: a
        })
    }

    function J(a) {
        h("help_tray_back_button_click", {
            content_type: a
        })
    }

    function K(a) {
        h("help_tray_open", {
            open_source: a
        })
    }

    function L(a, b) {
        h("help_tray_open", {
            open_source: (b = b) != null ? b : "cms_article",
            cms_id: a
        })
    }

    function M(a) {
        h("help_tray_close", {
            is_from_button_open: a.toString()
        })
    }

    function N(a) {
        a != null && a !== "" ? h("help_tray_search", {
            search_term: a
        }) : h("help_tray_search_clear")
    }

    function O(a, b, c, d, e) {
        h("help_tray_search_typeahead_item_open", {
            search_term: a || "",
            cms_id: b,
            title: c,
            position: "" + d,
            pathname: e
        })
    }

    function P(a, b, c) {
        h("help_tray_search_query_suggestion_typeahead_item_click", {
            search_term: a,
            suggestion_term: b,
            suggestion_type: c
        })
    }

    function Q(a) {
        h("help_tray_search_input_change", {
            search_term: a || ""
        })
    }

    function R(a, b, d, e) {
        e === void 0 && (e = c("adsHelpTrayCurrentQuerySelector")());
        h("help_tray_search_result_impression", {
            search_term: (e = e) != null ? e : "",
            cms_id: a.cms_id,
            title: a.title,
            content_source: a.content_source ? a.content_source : "",
            href: (e = a.href) != null ? e : "",
            rank: "" + b,
            pathname: d
        })
    }

    function S(a, b, d, e) {
        e === void 0 && (e = c("adsHelpTrayCurrentQuerySelector")());
        h("help_tray_search_result_open", {
            search_term: (e = e) != null ? e : "",
            cms_id: a.cms_id,
            title: a.title,
            content_source: a.content_source ? a.content_source : "",
            href: (e = a.href) != null ? e : "",
            rank: "" + b,
            pathname: d
        })
    }

    function T(a, b) {
        h("ads_policy_learn_more_click", {
            top_policy_url: a,
            sub_policy_url: b
        })
    }

    function U(a, b, d) {
        d === void 0 && (d = c("adsHelpTrayCurrentQuerySelector")()), h(a, {
            search_term: d || "",
            ranked_search_results: b
        })
    }

    function V(a) {
        h("help_tray_search_suggested_query_for_empty_results_clicked", {
            suggested_term: a
        })
    }

    function W(a, b) {
        b = b.toString();
        h("help_tray_search_keyword_pill_click", {
            search_term: a,
            rank: b
        })
    }

    function X(a) {
        h("help_tray_resource_click", {
            resource: a
        })
    }

    function Y(a) {
        h("case_tracking_case_view_open", {
            job_id: a
        })
    }

    function aa() {
        h("case_tracking_history_click")
    }

    function ba() {
        h("help_tray_home_content_rendered", {
            is_help_tray_open: c("adsHelpTrayIsTrayOpenSelector")().toString()
        })
    }

    function ca() {
        h("help_tray_survey_submit")
    }

    function da() {
        h("entry_point_discoverability_retrain_user_nux_shown", {
            is_help_tray_open: c("adsHelpTrayIsTrayOpenSelector")().toString(),
            is_help_tray_open_from_help_button: c("adsHelpTrayIsTrayOpenFromHelpButtonSelector")().toString()
        })
    }

    function ea() {
        h("entry_point_discoverability_retrain_user_nux_closed")
    }

    function fa() {
        h("entry_point_discoverability_new_user_nux_shown")
    }

    function ga() {
        h("entry_point_discoverability_new_user_nux_closed")
    }

    function ha() {
        h("entry_point_discoverability_new_spend_nux_shown")
    }

    function ia() {
        h("entry_point_discoverability_new_spend_nux_see_how_clicked")
    }

    function ja(a) {
        h("entry_point_discoverability_new_spend_nux_tour_hidden", {
            hide_source: a
        })
    }

    function ka() {
        h("help_tray_survey_renderred")
    }

    function la() {
        h("help_tray_survey_expanded")
    }

    function ma() {
        h("help_tray_survey_to_bhc_button_click")
    }
    var Z = function(a) {
        var b = a.index,
            c = a.numberOfLinks;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["index", "numberOfLinks"]);
        return babelHelpers["extends"]({}, a, {
            index: b.toString(),
            numberOfLinks: c.toString()
        })
    };

    function na(a, b) {
        h("help_tray_alert_shown", babelHelpers["extends"]({}, $(b), Z(a)))
    }

    function oa(a, b) {
        h("help_tray_alert_dismiss", babelHelpers["extends"]({
            identifier: a
        }, Z(b)))
    }

    function pa(a, b) {
        h(a ? "help_tray_alerts_expand" : "help_tray_alerts_collapse", {
            hiddenAlertsCount: b.toString()
        })
    }

    function qa(a, b, c) {
        h(a ? "help_tray_alert_cases_expand" : "help_tray_alert_cases_collapse", babelHelpers["extends"]({}, Z(b), {
            casesCount: c.toString()
        }))
    }
    var $ = function(a) {
        var b = a.type;
        a = a.value;
        return {
            resolution_path_type: b != null ? b : "",
            resolution_path_value: (b = a) != null ? b : ""
        }
    };

    function ra(a, b) {
        h("help_tray_alert_resolution_path_clicked", babelHelpers["extends"]({}, $(b), Z(a)))
    }

    function sa(a, b) {
        h("help_tray_alert_body_link_click", babelHelpers["extends"]({}, Z(a), {
            url: b
        }))
    }

    function ta(a, b) {
        b === void 0 && (b = ""), h("help_tray_contact_support_button_click", {
            entry_point: a,
            url: b
        })
    }

    function ua(a) {
        h("help_tray_alert_exceeds_max_ad_accounts", {
            numberOfAdAccounts: a.toString()
        })
    }

    function va(a) {
        h("embedded_contact_form_open", {
            formID: a
        })
    }

    function wa(a) {
        h("embedded_contact_form_submit_click", {
            formID: a
        })
    }

    function xa(a, b, c, d) {
        h("embedded_contact_form_submit_fail", {
            formID: a,
            errorCode: (a = b == null ? void 0 : b.toString()) != null ? a : "",
            errorMessage: (b = c == null ? void 0 : c.toString()) != null ? b : "",
            invalidFields: d.map(function(a) {
                a = a.fieldID;
                return a
            }).join(",")
        })
    }

    function ya(a) {
        h("embedded_contact_form_submit_success", {
            formID: a
        })
    }

    function za(a, b, c) {
        h("embedded_contact_form_loading_fail", {
            formID: a,
            errorCode: (a = b == null ? void 0 : b.toString()) != null ? a : "",
            errorMessage: (b = c == null ? void 0 : c.toString()) != null ? b : ""
        })
    }

    function Aa(a, b) {
        h("embedded_contact_form_fallback_link_clicked", {
            formID: a,
            location: b
        })
    }

    function Ba(a, b) {
        h("embedded_contact_form_change", {
            fieldID: b,
            formID: a
        })
    }

    function Ca(a) {
        h("bizweb_tooltip_article_click", a != null ? {
            entryPoint: a
        } : {})
    }

    function Da(a, b) {
        h("bizweb_search_snippet_impression", {
            query: a,
            isGalaxy: ((a = b) != null ? a : !1).toString()
        })
    }

    function Ea(a) {
        h("bizweb_contextual_tooltip_impression", {
            entryPoint: a
        })
    }

    function Fa(a, b) {
        h("bizweb_search_snippet_read_article_click", {
            cmsID: a,
            isGalaxy: ((a = b) != null ? a : !1).toString()
        })
    }

    function Ga(a, b, c) {
        h("bizweb_search_snippet_toggle_expand", {
            wasCollapsed: a.toString(),
            cmsID: b,
            isGalaxy: ((a = c) != null ? a : !1).toString()
        })
    }

    function Ha(a) {
        h("help_tray_article_load_fail", {
            cmsID: a
        })
    }

    function Ia(a) {
        a = a.isButton;
        h("bizweb_contextual_learn_more_click", {
            isButton: a.toString()
        })
    }

    function Ja(a) {
        a = a.isButton;
        h("bizweb_contextual_learn_more_impression", {
            isButton: a.toString()
        })
    }

    function Ka() {
        h("bizweb_ads_tooltip_geo_component_hovered")
    }

    function La(a, b) {
        h("bizweb_search_snippet_cms_content_load", {
            articleCmsID: a,
            snippetCmsID: b
        })
    }

    function Ma(a, b, c) {
        h("bizweb_search_snippet_cms_content_load_error", {
            articleCmsID: a,
            snippetCmsID: b,
            errorMessage: c
        })
    }
    g.logSupportFormAssetSelect = a;
    g.logSupportFormIssueSelect = b;
    g.logSupportFormPlanSelect = e;
    g.logSupportFormChannelSelect = f;
    g.logAssetIsRateLimited = i;
    g.logSupportFormCaseSubmission = j;
    g.logSupportFormArticleSeeMoreClick = k;
    g.logSupportCaseSeeMoreClick = l;
    g.logSupportFormArticleLoaded = m;
    g.logSupporFormContactSupportClick = n;
    g.logSupportFormSelfResolutionShown = o;
    g.logSupportFormCommonIssueSelect = p;
    g.logSupportFormDetectedIssueSelect = q;
    g.logSupportFormSelfResolutionCTAClick = r;
    g.logSupportFormAssetChangeClick = s;
    g.logSupportFormPlanChangeClick = t;
    g.logHelpArticleImpression = u;
    g.logPositiveFrictionLoad = v;
    g.logPositiveFrictionExistingCaseClick = w;
    g.logPositiveFrictionNewCaseClick = x;
    g.logHelpArticleClick = y;
    g.logHelpArticleOtherLinkClick = A;
    g.logHelpArticleViewMoreToggle = B;
    g.logNeedHelpClick = C;
    g.logFlytrapClick = D;
    g.logHelpCenterClick = E;
    g.logCancelPageRequestClick = F;
    g.logModalOpen = G;
    g.logModalSubmission = H;
    g.logFooterClick = I;
    g.logBackButtonClick = J;
    g.logHelpTrayOpen = K;
    g.logHelpTrayArticleOpen = L;
    g.logHelpTrayClose = M;
    g.logSearch = N;
    g.logSearchTypeaheadItemOpen = O;
    g.logSearchQuerySuggestionTypeaheadItemClick = P;
    g.logSearchInputChange = Q;
    g.logSearchResultImpression = R;
    g.logSearchResultOpen = S;
    g.logAdsPolicyLearnMoreClick = T;
    g.logSearchResults = U;
    g.logSuggestedQueryForEmptyResultsClick = V;
    g.logSuggestedPillQueryClick = W;
    g.logResourceClick = X;
    g.logCaseTrackingViewOpen = Y;
    g.logCaseTrackingHistoryClick = aa;
    g.logHomeContentRender = ba;
    g.logSurveySubmit = ca;
    g.logRetrainUserNuxShown = da;
    g.logRetrainUserNuxClosed = ea;
    g.logNewUserNuxShown = fa;
    g.logNewUserNuxClosed = ga;
    g.logNewSpendNuxShown = ha;
    g.logNewSpendNuxSeeHowClicked = ia;
    g.logNewSpendNuxTourHidden = ja;
    g.logSurverRender = ka;
    g.logSurveyExpanded = la;
    g.logSurveyToBHCButtonClick = ma;
    g.logHelpTrayAlertShown = na;
    g.logHelpTrayAlertDismiss = oa;
    g.logHelpTrayAlertListToggleExpand = pa;
    g.logHelpTrayAlertCaseListToggleExpand = qa;
    g.logHelpTrayResolutionPathClick = ra;
    g.logHelpTrayAlertBodyLinkClick = sa;
    g.logHelpTrayContactSupportButtonClick = ta;
    g.logHelpTrayAlertExceedsMaxAdAccounts = ua;
    g.logEmbeddedContactFormOpen = va;
    g.logEmbeddedContactFormSubmitClick = wa;
    g.logEmbeddedContactFormSubmitFail = xa;
    g.logEmbeddedContactFormSubmitSuccess = ya;
    g.logEmbeddedContactFormLoadingFail = za;
    g.logEmbeddedContactFormFallbackLinkClick = Aa;
    g.logEmbeddedContactFormChange = Ba;
    g.logBizwebTooltipArticleClick = Ca;
    g.logBizwebSearchSnippetImpression = Da;
    g.logBizwebContextualTooltipImpression = Ea;
    g.logBizwebSearchSnippetReadArticleClick = Fa;
    g.logBizwebSearchSnippetToggleExpand = Ga;
    g.logHelpTrayArticleLoadFail = Ha;
    g.logBizwebContextualLearnMoreClick = Ia;
    g.logBizwebContextualLearnMoreImpression = Ja;
    g.logBizwebAdsTooltipGeoComponentHovered = Ka;
    g.logBizwebSearchSnippetCmsContentLoad = La;
    g.logBizwebSearchSnippetCmsContentLoadError = Ma
}), 98);
__d("last", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = null;
        if (Array.isArray(a) || typeof a === "string") a.length && (b = {
            value: a[a.length - 1]
        });
        else
            for (var a = a, c = Array.isArray(a), d = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= a.length) break;
                    e = a[d++]
                } else {
                    d = a.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                b = b || {};
                b.value = e
            }
        return b ? b.value : null
    }
    f["default"] = a
}), 66);
__d("AdsHelpTrayOpenContactFormReducerPlugin", ["AdsHelpTrayNavigationHelper", "AdsHelpTrayUILogger", "CSS", "last"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            var e = a.navigationStack;
            if (!a.isTrayOpen) {
                var f;
                d("AdsHelpTrayUILogger").logHelpTrayOpen((f = b.source) != null ? f : "contact_support")
            }((f = c("last")(e)) == null ? void 0 : f.contentType) !== "SUPPORT_FORM" && (e = d("AdsHelpTrayNavigationHelper").concatToNavigationStack(e, {
                contentType: "SUPPORT_FORM",
                id: b.assetID,
                lbdIssueOrPlanID: b.lbdIssueID,
                showGuidanceCard: b.showGuidanceCard
            }));
            document.body && d("CSS").conditionClass(document.body, "has-helptray", !0);
            return babelHelpers["extends"]({}, a, {
                isTrayOpen: !0,
                navigationStack: e
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayOpenContactFormAction", ["AdsHelpTrayOpenContactFormReducerPlugin", "AdsHelpTrayUIProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsHelpTrayOpenContactFormReducerPlugin"), b("AdsHelpTrayUIProvider"), {}, "")]
    }, function() {
        return []
    }, "ADS_HELP_TRAY_OPEN_CONTACT_FORM_ACTION_PLUGIN");
    e.exports = a
}), null);
__d("AdsHelpTrayOpenEmbeddedContactFormDataActionReducerPlugin", ["AdsHelpTrayNavigationHelper", "CSS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            var c = a.navigationStack;
            b = b.data.formID;
            var e = d("AdsHelpTrayNavigationHelper").getCurrentEmbeddedFormID(a);
            b !== e && (c = d("AdsHelpTrayNavigationHelper").concatToNavigationStack(c, {
                contentType: "EMBEDDED_CONTACT_FORM",
                id: b
            }));
            document.body && d("CSS").conditionClass(document.body, "has-helptray", !0);
            return babelHelpers["extends"]({}, a, {
                isTrayOpen: !0,
                navigationStack: c
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayOpenEmbeddedContactFormDataLoggerPlugin", ["AdsHelpTrayUILogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        log: function(a) {
            d("AdsHelpTrayUILogger").logEmbeddedContactFormOpen(a.data.formID)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayOpenEmbeddedContactFormDataAction", ["AdsHelpTrayOpenEmbeddedContactFormDataActionReducerPlugin", "AdsHelpTrayOpenEmbeddedContactFormDataLoggerPlugin", "AdsHelpTrayUIProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsHelpTrayOpenEmbeddedContactFormDataActionReducerPlugin"), b("AdsHelpTrayUIProvider"), {}, "")]
    }, function() {
        return [b("Laminar").__createLogger("AdsHelpTrayOpenEmbeddedContactFormDataLoggerPlugin", b("AdsHelpTrayOpenEmbeddedContactFormDataLoggerPlugin"), {})]
    }, "ADS_HELP_TRAY_OPEN_EMBEDDED_CONTACT_FORM");
    e.exports = a
}), null);
__d("AdsHelpTrayPushCmsIdDataReducerPlugin", ["AdsHelpTrayNavigationHelper", "AdsHelpTrayUILogger", "CSS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 2;
    a = {
        reduce: function(a, b) {
            var c = a.navigationStack,
                e = a.recentlyViewed,
                f = b.data.cmsID,
                g = d("AdsHelpTrayNavigationHelper").getCurrentContentCMSID(a);
            a.isTrayOpen || d("AdsHelpTrayUILogger").logHelpTrayArticleOpen(f, b.data.source);
            if (f !== g) {
                c = d("AdsHelpTrayNavigationHelper").concatToNavigationStack(c, {
                    contentType: "ARTICLE",
                    id: f
                });
                b = e.indexOf(f);
                b !== -1 && e.splice(b, 1);
                e.unshift(f);
                e.length > h && e.pop()
            }
            document.body && d("CSS").conditionClass(document.body, "has-helptray", !0);
            return babelHelpers["extends"]({}, a, {
                isTrayOpen: !0,
                recentlyViewed: e,
                navigationStack: c
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayPushCmsIdDataAction", ["AdsHelpTrayPushCmsIdDataReducerPlugin", "AdsHelpTrayUIProvider", "Laminar", "ifRequired_FOR_LAMINAR_CODEGEN"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsHelpTrayPushCmsIdDataReducerPlugin"), b("AdsHelpTrayUIProvider"), {}, "")]
    }, function() {
        return [b("ifRequired_FOR_LAMINAR_CODEGEN")("AdsHelpTrayPushCmsIdDataActionFaqLoggerPlugin", function(a) {
            return b("Laminar").__createLogger("AdsHelpTrayPushCmsIdDataActionFaqLoggerPlugin", a, {}, ["AdsMgmtRegistry"])
        })]
    }, "ADS_HELP_TRAY_PUSH_CMS_ID");
    e.exports = a
}), null);
__d("AdsHelpTrayPushToNavigationStackReducerPlugin", ["AdsHelpTrayNavigationHelper"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            b = b.contentType === "HOME" ? [] : d("AdsHelpTrayNavigationHelper").concatToNavigationStack(a.navigationStack, b);
            return babelHelpers["extends"]({}, a, {
                navigationStack: b
            })
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayPushToNavigationStackAction", ["AdsHelpTrayPushToNavigationStackReducerPlugin", "AdsHelpTrayUIProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsHelpTrayPushToNavigationStackReducerPlugin"), b("AdsHelpTrayUIProvider"), {}, "")]
    }, function() {
        return []
    }, "ADS_HELP_TRAY_PUSH_TO_NAVIGATION_STACK");
    e.exports = a
}), null);
__d("XAdsHelpTrayLogIssuesAsyncController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ads/help_tray/ajax/log_issues/", {
        ad_account_id: {
            type: "FBID"
        },
        business_id: {
            type: "FBID"
        },
        event: {
            type: "Enum",
            required: !0,
            enumType: 1
        },
        session_id: {
            type: "String",
            required: !0
        },
        usid_override: {
            type: "String"
        }
    })
}), null);
__d("AdsHelpTrayLaminarHelper", ["AdsAccountStore", "AsyncRequest", "BizSiteIdentifier.brands", "BusinessUnifiedNavigationLoggingConfig", "USID", "XAdsHelpTrayLogIssuesAsyncController"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = c("XAdsHelpTrayLogIssuesAsyncController").getURIBuilder().setFBID("ad_account_id", c("AdsAccountStore").getSelectedAccountID()).setFBID("business_id", d("BizSiteIdentifier.brands").getBusinessID()).setEnum("event", a).setString("session_id", c("BusinessUnifiedNavigationLoggingConfig").sessionID).setString("usid_override", c("USID").get().serializeForRequest()).getURI();
        new(c("AsyncRequest"))().setURI(a).send()
    }
    g.logIssues = a
}), 98);
__d("AdsHelpTrayToggleDataReducerPlugin", ["AdsHelpTrayLaminarHelper", "AdsHelpTrayUILogger", "AdsHelpTrayUtils", "CSS"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        reduce: function(a, b) {
            var c = b.data.isTrayOpen,
                e = b.data.source,
                f = a.currentQuery,
                g = a.navigationStack,
                h = a.isTrayOpen;
            if (!c) {
                var i = a.source === "help_button" || a.source === "fbs_help_button";
                d("AdsHelpTrayUILogger").logHelpTrayClose(i);
                f = "";
                g = [];
                d("AdsHelpTrayLaminarHelper").logIssues("help_tray_close_issues")
            }!h && c && (d("AdsHelpTrayUILogger").logHelpTrayOpen(e), d("AdsHelpTrayLaminarHelper").logIssues("help_tray_open_issues"));
            h = c;
            e !== "help_button" && e !== "fbs_help_button" && (b.data.contentType !== "HOME" && (g = [{
                contentType: b.data.contentType
            }]));
            document.body && d("CSS").conditionClass(document.body, "has-helptray", h);
            i = babelHelpers["extends"]({}, a, {
                bizSitePageTypeFromButton: b.data.pageType,
                source: e,
                currentQuery: f,
                navigationStack: g,
                isTrayOpen: h
            });
            d("AdsHelpTrayUtils").storeHelpTrayStateToSessionStorage(i);
            return babelHelpers["extends"]({}, i)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("AdsHelpTrayToggleDataAction", ["AdsHelpTrayToggleDataReducerPlugin", "AdsHelpTrayUIProvider", "Laminar"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("Laminar").__createAction(function() {
        return [b("Laminar").__createReducer(b("AdsHelpTrayToggleDataReducerPlugin"), b("AdsHelpTrayUIProvider"), {}, "")]
    }, function() {
        return []
    }, "ADS_HELP_TRAY_TOGGLE");
    e.exports = a
}), null);
__d("AdsHelpTrayUIActions", ["AdsHelpTrayOpenCaseDetailsAction", "AdsHelpTrayOpenContactFormAction", "AdsHelpTrayOpenEmbeddedContactFormDataAction", "AdsHelpTrayPushCmsIdDataAction", "AdsHelpTrayPushToNavigationStackAction", "AdsHelpTrayToggleDataAction", "QuickPerformanceLogger", "gkx", "nullthrows", "qex", "qpl"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d, e) {
        d === void 0 && (d = "HOME"), e === void 0 && (e = "other"), c("AdsHelpTrayToggleDataAction").dispatch({
            data: {
                isTrayOpen: a,
                contentType: d,
                pageType: b,
                source: e
            }
        }, {
            line: "40",
            module: "AdsHelpTrayUIActions.js"
        })
    }

    function b() {
        var a;
        return ((a = c("qex")._("1824")) != null ? a : !1) || c("gkx")("6943")
    }

    function h(a, b) {
        b === void 0 && (b = null), c("QuickPerformanceLogger").markerStart(c("qpl")._(593303848, "618")), c("AdsHelpTrayPushCmsIdDataAction").dispatch({
            data: {
                cmsID: a,
                source: b
            }
        }, {
            line: "60",
            module: "AdsHelpTrayUIActions.js"
        })
    }

    function i(a) {
        c("AdsHelpTrayOpenEmbeddedContactFormDataAction").dispatch({
            data: {
                formID: a
            }
        }, {
            line: "66",
            module: "AdsHelpTrayUIActions.js"
        })
    }

    function d(a) {
        c("AdsHelpTrayOpenCaseDetailsAction").dispatch({
            data: {
                caseID: a
            }
        }, {
            line: "72",
            module: "AdsHelpTrayUIActions.js"
        })
    }

    function e(a, b, d, e) {
        b === void 0 && (b = null);
        d === void 0 && (d = null);
        e === void 0 && (e = !0);
        c("AdsHelpTrayOpenContactFormAction").dispatch({
            source: a,
            assetID: (a = b) != null ? a : void 0,
            lbdIssueID: (b = d) != null ? b : void 0,
            showGuidanceCard: e
        }, {
            line: "83",
            module: "AdsHelpTrayUIActions.js"
        })
    }

    function f(a) {
        switch (a.contentType) {
            case "ARTICLE":
                h(c("nullthrows")(a.id));
                break;
            case "EMBEDDED_CONTACT_FORM":
                i(c("nullthrows")(a.id));
                break;
            default:
                c("AdsHelpTrayPushToNavigationStackAction").dispatch(a, {
                    line: "100",
                    module: "AdsHelpTrayUIActions.js"
                });
                break
        }
    }
    g.toggleHelpTray = a;
    g.isContextualArticlePreviewEnabled = b;
    g.pushCMSIDToHistory = h;
    g.openEmbeddedContactForm = i;
    g.openCaseDetails = d;
    g.openContactSupportForm = e;
    g.pushToNavigationStack = f
}), 98);
__d("AdsLearnMoreStrings", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = h._("Learn more");
    b = h._("Learn more");
    g.INLINE_LEARN_MORE = a;
    g.STANDALONE_LEARN_MORE = b
}), 98);
__d("GeoInvertedThemeProvider", ["GeoPrivateInvertThemeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children;
        a = a.isEnabled;
        a = a === void 0 ? !1 : a;
        return h.jsx(c("GeoPrivateInvertThemeContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.GeoInvertedThemeProvider = a
}), 98);
__d("GeoLinkRouterType", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum").Mirrored(["Native", "Comet", "AIR"]);
    c = a;
    f["default"] = c
}), 66);
__d("GeoPrivateDefaultRouterLink.react", ["Link.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a["aria-describedby"],
            d = a["aria-expanded"],
            e = a["aria-label"],
            f = a["aria-labelledby"],
            g = a["data-testid"];
        g = a.children;
        var i = a.className_DEPRECATED,
            j = a.href,
            k = a.linkRef,
            l = a.onBlur,
            m = a.onClick,
            n = a.onFocus,
            o = a.onMouseEnter,
            p = a.onMouseLeave,
            q = a.rel,
            r = a.role,
            s = a.style,
            t = a.suppressHydrationWarning,
            u = a.tabIndex,
            v = a.target,
            w = a.truncate;
        w = w === void 0 ? !1 : w;
        a = a.xstyle;
        return h.jsx(c("Link.react"), {
            "aria-describedby": b,
            "aria-expanded": d,
            "aria-label": e,
            "aria-labelledby": f,
            className: (b = i) != null ? b : c("stylex")(a),
            "data-hover": w ? "tooltip" : void 0,
            "data-testid": void 0,
            "data-tooltip-display": w ? "overflow" : void 0,
            href: j,
            linkRef: k,
            onBlur: l,
            onClick: m,
            onFocus: n,
            onMouseEnter: o,
            onMouseLeave: p,
            rel: q,
            role: r,
            style: s,
            suppressHydrationWarning: t,
            tabIndex: u,
            target: v,
            children: g
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GeoPrivateRouterLinkContext", ["GeoLinkRouterType", "GeoPrivateDefaultRouterLink.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        RouterLink: c("GeoPrivateDefaultRouterLink.react"),
        type: c("GeoLinkRouterType").Native
    });
    g["default"] = b
}), 98);
__d("GeoBaseLink.react", ["GeoPrivateMakeComponent", "GeoPrivateRouterLinkContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        var b = i(c("GeoPrivateRouterLinkContext"));
        b = b.RouterLink;
        return h.jsx(b, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoBaseLink", a);
    g["default"] = b
}), 98);
__d("useGeoPrivateLinkStyles", ["useGeoPrivateTextStyle"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        root: {
            display: "xt0psk2",
            textDecoration: "x1hl2dhg",
            ":hover": {
                textDecoration: "xt0b8zv"
            }
        },
        noUnderline: {
            textDecoration: "x1hl2dhg",
            ":hover": {
                textDecoration: "x1lku1pv"
            }
        },
        alwaysUnderline: {
            textDecoration: "x1bvjpef",
            ":hover": {
                textDecoration: "xt0b8zv"
            }
        },
        block: {
            display: "x1lliihq"
        },
        inlineBlock: {
            display: "x1rg5ohu",
            verticalAlign: "x3ajldb"
        },
        inherit: {
            fontSize: "x1qlqyl8",
            fontWeight: "x1pd3egz"
        }
    };

    function a(a) {
        var b = a.display,
            d = a.isInverted,
            e = a.isWithinGeoBaseText;
        a = a.showUnderline;
        var f = ["truncateInlineBlock", "inlineBlock"].includes(b),
            g = ["truncateBlock", "block"].includes(b);
        b = ["truncateInlineBlock", "truncateInline", "truncateBlock", "truncate"].includes(b);
        return [h.root, a === "never" && h.noUnderline, a === "always" && h.alwaysUnderline, c("useGeoPrivateTextStyle")({
            size: "value",
            color: d ? "inverted" : "link",
            display: b ? "truncate" : "inline",
            isDisabled: !1,
            overflowWrap: "normal",
            textAlign: "start",
            weight: "normal",
            whiteSpace: "inherit"
        }), e && h.inherit, f && h.inlineBlock, g && h.block]
    }
    g["default"] = a
}), 98);
__d("GeoLink.react", ["GeoBaseLink.react", "GeoPrivateBaseTextContext", "GeoPrivateInvertThemeContext", "GeoPrivateLoggingAction", "GeoPrivateLoggingClassification", "GeoPrivateMakeComponent", "react", "useGeoPrivateLinkStyles", "useGeoPrivateWithLogging"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        var b = a["aria-label"],
            d = a.children,
            e = a["data-testid"];
        e = a.display;
        e = e === void 0 ? "inline" : e;
        var f = a.href,
            g = a.onClick,
            j = a.onMouseEnter,
            k = a.onMouseLeave,
            l = a.rel,
            m = a.showUnderline;
        m = m === void 0 ? "hover" : m;
        var n = a.target,
            o = a.width,
            p = a.xstyle;
        a = a.linkRef;
        g = c("useGeoPrivateWithLogging")(g, {
            name: "GeoLink",
            action: c("GeoPrivateLoggingAction").CLICK,
            classification: c("GeoPrivateLoggingClassification").USER_ACTION
        });
        var q = ["truncateInlineBlock", "truncateInline", "truncateBlock", "truncate"].includes(e),
            r = i(c("GeoPrivateInvertThemeContext")),
            s = i(c("GeoPrivateBaseTextContext"));
        e = c("useGeoPrivateLinkStyles")({
            display: e,
            isInverted: r,
            isWithinGeoBaseText: s,
            showUnderline: m
        });
        return h.jsx(c("GeoBaseLink.react"), {
            "aria-label": b,
            "data-testid": void 0,
            href: f,
            linkRef: a,
            onClick: g,
            onMouseEnter: j,
            onMouseLeave: k,
            rel: l,
            style: {
                width: o
            },
            target: n,
            truncate: q,
            xstyle: [e, p],
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoLink", a);
    g["default"] = b
}), 98);
__d("AHGHelpTrayLink2.react", ["cssVar", "ix", "AHGUtils", "AdsHelpTrayUIActions", "AdsLearnMoreStrings", "GeoButton.react", "GeoInvertedThemeProvider", "GeoLink.react", "Link.react", "fbicon", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.label;
        b = b === void 0 ? d("AdsLearnMoreStrings").INLINE_LEARN_MORE : b;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["label"]);
        var e = a.children,
            f = a.helpCenterID,
            g = a.dialogWidth,
            h = a.forceNewWindow,
            k = h === void 0 ? !1 : h;
        h = a.isInverseColor;
        var l = a.isModern,
            m = a.isButton,
            n = a.source,
            o = a.onClick,
            p = a.xstyle,
            q = a.queryParams;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "helpCenterID", "dialogWidth", "forceNewWindow", "isInverseColor", "isModern", "isButton", "source", "onClick", "xstyle", "queryParams"]);
        var r = function(a) {
            var b = k;
            if (g != null) {
                var c = parseInt("324px", 10);
                c = g + c * 2;
                window.innerWidth < c && (b = !0)
            }
            b || (a.preventDefault(), a.stopPropagation(), d("AdsHelpTrayUIActions").pushCMSIDToHistory(f, n));
            o && o(a)
        };
        return m === !0 ? j.jsx(c("GeoButton.react"), babelHelpers["extends"]({
            label: b
        }, a, {
            onClick: r
        })) : l === !0 ? j.jsx(c("GeoButton.react"), babelHelpers["extends"]({
            label: b
        }, a, {
            icon: d("fbicon")._(i("496957"), 16),
            onClick: r
        })) : j.jsx("span", {
            children: j.jsx(d("GeoInvertedThemeProvider").GeoInvertedThemeProvider, {
                isEnabled: h,
                children: p == null ? j.jsx(c("GeoLink.react"), {
                    href: d("AHGUtils").getHelpCenterURI(f, q).toString(),
                    target: "_blank",
                    onClick: r,
                    children: (m = e) != null ? m : b
                }) : j.jsx(c("Link.react"), {
                    className: c("stylex")(p),
                    href: d("AHGUtils").getHelpCenterURI(f, q).toString(),
                    target: "_blank",
                    onClick: r,
                    children: (l = e) != null ? l : b
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("AdsUtils", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useRef;

    function i(a) {
        return a === Object(a)
    }

    function a(a) {
        return Array.isArray(a) || typeof a === "string" ? a.length : i(a) ? Object.keys(a).length : 0
    }

    function b(a, b, c) {
        var d = {};
        for (var e = 0; e < a.length; ++e) d[a[e][b]] = c === void 0 ? a[e] : a[e][c];
        return d
    }

    function j(a) {
        var b = a;
        Array.isArray(a) ? b = a.map(j) : i(a) && (b = {}, Object.keys(a).forEach(function(c) {
            return b[c] = j(a[c])
        }));
        return b
    }

    function k(a) {
        return a.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase()
    }

    function l(a) {
        return a.replace(/_[a-z]/g, function(a) {
            return a.charAt(1).toUpperCase()
        })
    }

    function m(a, b, c) {
        var d = {},
            e = Object.keys(babelHelpers["extends"]({}, a, b));
        for (var f = 0; f < e.length; f++) {
            var g = e[f],
                h = c(Object.prototype.hasOwnProperty.call(a, g), Object.prototype.hasOwnProperty.call(b, g));
            h < 0 ? d[g] = a[g] : h > 0 && (d[g] = b[g])
        }
        return d
    }

    function c(a, b) {
        return m(a, b, function(a, b) {
            return a && b ? -1 : 0
        })
    }

    function n(a, b) {
        if (Array.isArray(a) && Array.isArray(b)) {
            if (a.length !== b.length) return !1;
            for (var c = 0; c < a.length; ++c)
                if (!n(a[c], b[c])) return !1;
            return !0
        }
        if (i(a) && i(b)) {
            c = Object.keys(a);
            for (var d = 0; d < c.length; d++) {
                var e = c[d];
                if (!Object.prototype.hasOwnProperty.call(b, e)) return !1;
                if (!n(a[e], b[e])) return !1
            }
            return !0
        }
        return a == b
    }

    function e(a) {
        var b = {};
        Object.keys(a).forEach(function(c) {
            var d = l(c);
            b[d] = a[c]
        });
        return b
    }

    function f(a) {
        var b = {};
        Object.keys(a).forEach(function(c) {
            var d = k(c);
            b[d] = a[c]
        });
        return b
    }

    function o(a) {
        var b = h(!1);
        if (b.current) return;
        a();
        b.current = !0
    }
    g.isObject = i;
    g.count = a;
    g.indexedMap = b;
    g.clone = j;
    g.underscoreKey = k;
    g.camelCaseKey = l;
    g.mapIntersectKey = c;
    g.isEqualWeak = n;
    g.underscoreToCamelCaseKeys = e;
    g.camelCaseToUnderscoreKeys = f;
    g.useExecuteOnceBeforeRender = o
}), 98);
__d("GeoPrivatePreventDefaultOverrideContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useGeoPrivateIneractiveRowPreventDefault", ["GeoPrivatePreventDefaultOverrideContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a(a) {
        var b = h(c("GeoPrivatePreventDefaultOverrideContext"));
        return (b = b) != null ? b : !["label", "link"].includes(a)
    }
    g["default"] = a
}), 98);
__d("GeoPrivateTooltipOrDisabledMessage.react", ["GeoPrivateTooltipTriggerContext", "GeoTooltip.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = a["data-testid"],
            d = a.isDisabled,
            e = d === void 0 ? !1 : d,
            f = a.disabledMessage,
            g = a.disabledHeading;
        d = a.triggerRef;
        var j = a.tooltip;
        a = i(function() {
            return e === !0 && f != null ? h.jsx(c("GeoTooltip.react"), {
                content: f,
                "data-testid": void 0,
                heading: g
            }) : j
        }, [b, g, f, e, j]);
        return h.jsx(c("GeoPrivateTooltipTriggerContext").Provider, {
            value: d,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GeoPrivateIconCheckmarkFilled16", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.jsx("svg", {
        height: "16",
        viewBox: "0 0 16 16",
        width: "16",
        children: a.jsx("path", {
            d: "M13.305 3.28L5.993 10.6l-3.31-3.306a1 1 0 00-1.415 1.414l4.013 4.012a.997.997 0 001.414 0l8.024-8.024a1 1 0 00-1.414-1.416z"
        })
    });
    c = b;
    g["default"] = c
}), 98);
__d("GeoPrivateIconMinusFilled16", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.jsx("svg", {
        height: "16",
        viewBox: "0 0 16 16",
        width: "16",
        children: a.jsx("path", {
            d: "M13.333 7H3a1 1 0 000 2h10.333a1 1 0 100-2z"
        })
    });
    c = b;
    g["default"] = c
}), 98);
__d("GeoPrivateMediaItemSurfaceContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("GeoPrivateBadgeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        id: null,
        isLive: !0
    });
    g["default"] = b
}), 98);
__d("GeoBaseListRowContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        isNested: !1
    });
    g["default"] = b
}), 98);
__d("GeoBaseListLayoutContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        density: "dense",
        direction: "vertical",
        isWithinList: !1,
        shouldAlignRows: !1
    });
    g["default"] = b
}), 98);
__d("GeoWrappedListItemContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("GeoBaseRowLayout.react", ["GeoBaseListLayoutContext", "GeoBaseSpacingLayout.react", "GeoPrivateMakeComponent", "GeoWrappedListItemContext", "react", "stylex", "useGeoTheme"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            wrappedRow: {
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r"
            },
            wrapper: {
                display: "x78zum5",
                flexGrow: "x1iyjqo2"
            }
        };

    function a(a) {
        var b = a.children,
            d = a.containerRef,
            e = a.density,
            f = a.grow,
            g = a.accessibilityRole;
        g = g === void 0 ? "listitem" : g;
        var l = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "containerRef", "density", "grow", "accessibilityRole", "xstyle"]);
        var m = i(c("GeoBaseListLayoutContext")),
            n = m.density,
            o = m.direction,
            p = m.isWithinList;
        m = m.shouldAlignRows;
        var q = i(c("GeoWrappedListItemContext"));
        f = ((f = f) != null ? f : o === "vertical") ? "fill" : "auto";
        n = (o = n) != null ? o : e;
        o = c("useGeoTheme")();
        e = o.selectBorderRadius;
        o = k({
            shouldAlignRows: m,
            density: n
        });
        return h.jsx("div", {
            className: c("stylex")(j.wrapper),
            ref: d,
            role: g,
            children: h.jsx(c("GeoBaseSpacingLayout.react"), babelHelpers["extends"]({
                grow: f,
                xstyle: [e({
                    context: "content"
                }), p && o, q && j.wrappedRow, l]
            }, a, {
                children: b
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function k(a) {
        var b = a.shouldAlignRows;
        a = a.density;
        var d = c("useGeoTheme")();
        d = d.selectSpacing;
        return [d({
            context: "component",
            bounds: "internal",
            positions: ["vertical"],
            target: a === "sparse" ? "normal" : "fine"
        }), d({
            context: "component",
            bounds: "internal",
            positions: ["horizontal"],
            offsets: b ? ["horizontal"] : void 0
        })]
    }
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoBaseRowLayout", a);
    g["default"] = b
}), 98);
__d("GeoHStack.react", ["GeoFlexbox.react", "GeoPrivateMakeComponent", "react", "useGeoTheme"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.alignItems;
        b = b === void 0 ? "start" : b;
        var d = a.context;
        d = d === void 0 ? "component" : d;
        var e = a.containerRef,
            f = a.direction;
        f = f === void 0 ? "row" : f;
        var g = a.display;
        g = g === void 0 ? "flex" : g;
        var i = a.grow;
        i = i === void 0 ? 1 : i;
        var j = a.relation;
        j = j === void 0 ? "unrelated" : j;
        var k = a.shrink;
        k = k === void 0 ? 1 : k;
        var l = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["alignItems", "context", "containerRef", "direction", "display", "grow", "relation", "shrink", "xstyle"]);
        var m = c("useGeoTheme")();
        m = m.selectLayoutSpacing;
        m = m({
            context: d,
            relation: j,
            direction: f === "row" ? "horizontal" : "horizontal-reverse"
        });
        return h.jsx(c("GeoFlexbox.react"), babelHelpers["extends"]({
            alignItems: b,
            containerRef: e,
            direction: f,
            display: g,
            grow: i,
            shrink: k,
            wrap: "nowrap",
            xstyle: [m, l]
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoHStack", a);
    g["default"] = b
}), 98);
__d("GeoBaseInteractiveListContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        registerItem: c("emptyFunction"),
        deregisterItem: c("emptyFunction"),
        FocusItem: function(a) {
            a = a.children;
            return a
        }
    });
    g["default"] = b
}), 98);
__d("GeoPrivateClearInteractiveStylesContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = !1;
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("GeoPrivateSidebarNavigationContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        canExpand: !1,
        isCollapsed: !1,
        isUniquelyExpandable: !1,
        onGroupExpand: c("emptyFunction"),
        setIsCollapsed: c("emptyFunction"),
        variant: "light",
        xstyle: void 0
    });
    g["default"] = b
}), 98);
__d("GeoBaseInteractiveRow.react", ["GeoBaseInteractiveListContext", "GeoBaseRowLayout.react", "GeoPrivateAnimationPressableOverlay.react", "GeoPrivateClearInteractiveStylesContext", "GeoPrivateLoggingAction", "GeoPrivateLoggingClassification", "GeoPrivateMakeComponent", "GeoPrivatePressable.react", "GeoPrivateSidebarNavigationContext", "GeoPrivateTooltipOrDisabledMessage.react", "GeoPrivateTruncationContext", "react", "useGeoPrivateIneractiveRowPreventDefault", "useGeoPrivateIsDisabled", "useGeoPrivateWithLogging", "useGeoTheme", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useRef,
        l = b.useState;

    function a(a) {
        var b = a.accessibilityRole,
            d = a.accessibilityState,
            e = a.children,
            f = a.containerRef,
            g = a["data-testid"],
            p = a.describedBy,
            q = a.disabledHeading,
            r = a.disabledMessage,
            s = a.grow,
            t = a.hasAnimation;
        t = t === void 0 ? !1 : t;
        var u = a.id,
            v = a.isDisabled;
        v = v === void 0 ? !1 : v;
        var w = a.isExpanded;
        w = w === void 0 ? !1 : w;
        var x = a.isFocusable;
        x = x === void 0 ? !1 : x;
        var y = a.isHighlighted;
        y = y === void 0 ? !1 : y;
        var z = a.isHoverable,
            A = a.isVisuallyFocused,
            B = a.labelledBy,
            C = a.link,
            D = a.loggingName;
        D = D === void 0 ? "GeoBaseInteractiveRow" : D;
        var E = a.onFocusChange,
            F = a.onHoverChange,
            G = a.onPress,
            H = a.tooltip,
            I = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["accessibilityRole", "accessibilityState", "children", "containerRef", "data-testid", "describedBy", "disabledHeading", "disabledMessage", "grow", "hasAnimation", "id", "isDisabled", "isExpanded", "isFocusable", "isHighlighted", "isHoverable", "isVisuallyFocused", "labelledBy", "link", "loggingName", "onFocusChange", "onHoverChange", "onPress", "tooltip", "xstyle"]);
        var J = k(null);
        f = c("useMergeRefs")(J, f);
        var K = l(!1),
            L = K[0],
            M = K[1];
        K = l(!1);
        var N = K[0];
        K = K[1];
        var O = l(!1),
            P = O[0];
        O = O[1];
        v = c("useGeoPrivateIsDisabled")(v);
        var Q = z === !0 || x;
        A = (z = A) != null ? z : N || Q && L;
        z = i(c("GeoBaseInteractiveListContext"));
        var R = z.registerItem,
            S = z.deregisterItem;
        N = z.FocusItem;
        L = c("useGeoPrivateIneractiveRowPreventDefault")(b);
        j(function() {
            var a = J.current;
            R(a);
            return function() {
                return S(a)
            }
        }, [J, R, S]);
        z = p != null || B != null ? {
            describedby: p,
            labelledby: B
        } : void 0;
        p = c("useGeoPrivateWithLogging")(G, {
            name: D,
            action: c("GeoPrivateLoggingAction").CLICK,
            classification: c("GeoPrivateLoggingClassification").USER_ACTION
        });
        B = i(c("GeoPrivateSidebarNavigationContext"));
        G = B.variant;
        return h.jsxs(N, {
            disabled: v || !x,
            children: [h.jsx(c("GeoPrivateTruncationContext").Provider, {
                value: H != null ? !1 : void 0,
                children: h.jsx(c("GeoPrivatePressable.react"), {
                    accessibilityRelationship: z,
                    accessibilityRole: b,
                    accessibilityState: d,
                    disabled: v,
                    forwardedRef: f,
                    link: C,
                    nativeID: u,
                    onFocusChange: E,
                    onFocusVisibleChange: K,
                    onHoverChange: function(a) {
                        Q && M(a), F == null ? void 0 : F(a)
                    },
                    onPress: p,
                    onPressChange: O,
                    preventDefault: L,
                    tabbable: x,
                    testID: g,
                    xstyle: [s === "fill" && m.fill, s === "auto" && m.fit, b === "link" && m.noUnderline, I],
                    children: h.jsxs(c("GeoBaseRowLayout.react"), babelHelpers["extends"]({
                        accessibilityRole: null,
                        xstyle: n({
                            accessibilityRole: b,
                            hasAnimation: t,
                            isSelected: y,
                            isExpanded: w,
                            isFocused: A,
                            isActive: P
                        })
                    }, a, {
                        children: [t && h.jsx(c("GeoPrivateAnimationPressableOverlay.react"), {
                            color: o({
                                accessibilityRole: b,
                                isSelected: y,
                                variant: G
                            }),
                            isActive: P,
                            isFocused: A
                        }), e]
                    }))
                })
            }), h.jsx(c("GeoPrivateTooltipOrDisabledMessage.react"), {
                disabledHeading: q,
                disabledMessage: r,
                isDisabled: v,
                tooltip: H,
                triggerRef: J
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var m = {
        expanded: {
            borderBottomStartRadius: "xo71vjh",
            borderBottomEndRadius: "x5pf9jr"
        },
        fit: {
            display: "x3nfvp2"
        },
        fill: {
            flexGrow: "x1iyjqo2"
        },
        noUnderline: {
            textDecoration: "x1hl2dhg",
            ":hover": {
                textDecoration: "x1lku1pv"
            }
        },
        row: {
            position: "x1n2onr6"
        }
    };

    function n(a) {
        var b = a.accessibilityRole,
            d = a.hasAnimation,
            e = a.isSelected,
            f = a.isExpanded,
            g = a.isFocused;
        a = a.isActive;
        var h = c("useGeoTheme")();
        h = h.selectInteractiveColorPalette;
        var j = i(c("GeoPrivateClearInteractiveStylesContext")),
            k = i(c("GeoPrivateSidebarNavigationContext"));
        k = k.variant;
        return [d && m.row, !j && h({
            color: o({
                accessibilityRole: b,
                isSelected: e,
                variant: k
            }),
            isFocused: !d && g,
            isActive: !d && a
        }), f && m.expanded]
    }

    function o(a) {
        var b = a.accessibilityRole,
            c = a.isSelected;
        a = a.variant;
        var d = "flat";
        c && (a === "flat" ? d = "flatNavigation" : d = b === "link" ? "navigation" : "selected");
        return d
    }
    e = d("GeoPrivateMakeComponent").makeGeoComponent("GeoBaseInteractiveRow", a);
    g["default"] = e
}), 98);
__d("GeoPrivateBaseListRowLayout.react", ["ix", "BUIPrivateBoldItemLabelContext", "GeoBaseAccessibleElement.react", "GeoBaseListLayoutContext", "GeoBaseListRowContext", "GeoBaseSpacingLayout.react", "GeoBaseText.react", "GeoFlexbox.react", "GeoHStack.react", "GeoPrivateFBIconOrImageish.react", "GeoPrivateMakeComponent", "GeoPrivateMediaItemSurfaceContext", "Image.react", "geoMargin", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = d("react").useContext,
        k = {
            isNested: !0
        },
        l = "none";

    function a(a) {
        var b = a.align,
            d = a.badge,
            e = a.control,
            f = a.description,
            g = a.descriptionID,
            h = a.endContent,
            p = a.isDisabled;
        p = p === void 0 ? !1 : p;
        var q = a.isLabelHidden;
        q = q === void 0 ? !1 : q;
        var r = a.label,
            s = a.labelID,
            t = a.media,
            u = a.showHandle;
        u = u === void 0 ? !1 : u;
        var v = a.statusIndicator,
            w = a.trailingContent,
            x = a.truncate;
        a = a.isTruncationTooltipHidden;
        a = a === void 0 ? !1 : a;
        var y = j(c("GeoBaseListLayoutContext"));
        y = y.direction;
        var z = j(c("BUIPrivateBoldItemLabelContext"));
        z = z && f != null ? "bold" : null;
        y = y === "vertical" ? "fill" : "auto";
        var A = d != null || h != null,
            B = x === "label" || x === "both",
            C = x === "description" || x === "both";
        return i.jsxs(c("GeoBaseListRowContext").Provider, {
            value: k,
            children: [u && i.jsx(n, {}), (e != null || t != null || v != null) && i.jsx(c("GeoPrivateMediaItemSurfaceContext").Provider, {
                value: l,
                children: i.jsxs(m, {
                    align: b,
                    children: [e, t != null ? i.jsx(c("GeoPrivateFBIconOrImageish.react"), {
                        icon: t,
                        xstyle: o.media
                    }) : null, v]
                })
            }), i.jsxs(c("GeoBaseAccessibleElement.react"), {
                isHidden: q,
                xstyle: [o.accessibleEl, A && o.shrinkForEndContent, x != null && o.truncate, y === "auto" && o.fit, f != null && e != null && t == null ? o.descriptionCompensation : null, t !== null && o.alignSelfCenter],
                children: [i.jsxs(c("GeoHStack.react"), {
                    alignItems: "center",
                    context: "component",
                    relation: "related",
                    xstyle: o.headingWrapper,
                    children: [i.jsx(c("GeoBaseText.react"), {
                        color: "value",
                        display: B ? "truncate" : "block",
                        id: s,
                        isDisabled: p,
                        overflowWrap: "break-word",
                        showTruncationTooltip: !a,
                        size: "value",
                        weight: z,
                        xstyle: w == null ? o.heading : void 0,
                        children: r
                    }), w != null && i.jsx(c("GeoFlexbox.react"), {
                        xstyle: [o.trailingContent, c("geoMargin").end4],
                        children: w
                    })]
                }), f != null && i.jsx(c("GeoBaseText.react"), {
                    color: "heading",
                    display: C ? "truncate" : "block",
                    id: g,
                    isDisabled: p,
                    overflowWrap: "break-word",
                    size: "valueDescription",
                    children: f
                })]
            }), d != null && i.jsx("div", {
                className: c("stylex")(o.media),
                children: d
            }), h != null && i.jsx(c("GeoBaseSpacingLayout.react"), {
                grow: "auto",
                children: h
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function m(a) {
        var b = a.align,
            d = a.children;
        a = a.xstyle;
        return i.jsx(c("GeoBaseSpacingLayout.react"), {
            grow: "auto",
            xstyle: [o.addOnContainer, b === "center" && o.alignSelfCenter, a],
            children: d
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function n() {
        return i.jsx(c("GeoBaseSpacingLayout.react"), {
            grow: "auto",
            children: i.jsx(c("Image.react"), {
                src: h("1213581")
            })
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";
    var o = {
        addOnContainer: {
            alignSelf: "xqcrz7y",
            flexShrink: "x2lah0s"
        },
        alignSelfCenter: {
            alignSelf: "xamitd3"
        },
        media: {
            flexShrink: "x2lah0s"
        },
        descriptionCompensation: {
            marginTop: "xr9ek0c"
        },
        fit: {
            flexGrow: "x1c4vz4f"
        },
        accessibleEl: {
            flexGrow: "x1iyjqo2"
        },
        headingWrapper: {
            display: "x78zum5",
            minWidth: "xeuugli"
        },
        heading: {
            flexGrow: "x1iyjqo2"
        },
        trailingContent: {
            flexGrow: "x1iyjqo2",
            flexShrink: "x2lah0s"
        },
        shrinkForEndContent: {
            flexBasis: "x1r8uery"
        },
        truncate: {
            overflowX: "x6ikm8r",
            overflowY: "x10wlt62"
        }
    };
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoPrivateBaseListRowLayout", a);
    g["default"] = b
}), 98);
__d("GeoBaseListRow.react", ["GeoBaseInteractiveRow.react", "GeoBaseListRowContext", "GeoPrivateBadgeContext", "GeoPrivateBaseListRowLayout.react", "GeoPrivateMakeComponent", "joinDomIDs", "react", "stylex", "useUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            "default": {
                listStyle: "xe8uvvx"
            }
        };

    function a(a) {
        var b = a.accessibilityRole,
            d = a.accessibilityState,
            e = a.badge,
            f = a.containerRef,
            g = a["data-testid"];
        g = a.describedBy;
        var n = a.description,
            o = a.descriptionID,
            p = a.disabledHeading,
            q = a.disabledMessage,
            r = a.hasAnimation;
        r = r === void 0 ? !1 : r;
        var s = a.id,
            t = a.isFocusable;
        t = t === void 0 ? !1 : t;
        var u = a.isDisabled;
        u = u === void 0 ? !1 : u;
        var v = a.isHighlighted;
        v = v === void 0 ? !1 : v;
        var w = a.isHoverable,
            x = a.isReadOnly;
        x = x === void 0 ? !1 : x;
        var y = a.isVisuallyFocused,
            z = a.labelID,
            A = a.link,
            B = a.loggingName,
            C = a.onFocusChange,
            D = a.onHoverChange,
            E = a.onPress,
            F = a.tooltip,
            G = a.trailingContent,
            H = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["accessibilityRole", "accessibilityState", "badge", "containerRef", "data-testid", "describedBy", "description", "descriptionID", "disabledHeading", "disabledMessage", "hasAnimation", "id", "isFocusable", "isDisabled", "isHighlighted", "isHoverable", "isReadOnly", "isVisuallyFocused", "labelID", "link", "loggingName", "onFocusChange", "onHoverChange", "onPress", "tooltip", "trailingContent", "xstyle"]);
        var I = i(c("GeoBaseListRowContext"));
        I = I.isNested;
        I = !I && m(b);
        var J = l(b),
            K = c("useUniqueID")();
        K = J ? K : void 0;
        z = (z = z) != null ? z : K;
        K = c("useUniqueID")();
        o = J && n != null ? (o = o) != null ? o : K : void 0;
        var L = c("useUniqueID")();
        K = j(function() {
            return {
                id: L,
                isLive: !1
            }
        }, [L]);
        b = h.jsx(c("GeoBaseInteractiveRow.react"), {
            accessibilityRole: b,
            accessibilityState: d,
            containerRef: f,
            "data-testid": void 0,
            describedBy: c("joinDomIDs")(g, o, e != null ? L : null),
            disabledHeading: p,
            disabledMessage: q,
            hasAnimation: r,
            id: s,
            isDisabled: u || x,
            isFocusable: t,
            isHighlighted: v,
            isHoverable: w,
            isVisuallyFocused: y,
            labelledBy: J ? z : null,
            link: A,
            loggingName: B,
            onFocusChange: C,
            onHoverChange: D,
            onPress: E,
            tooltip: F,
            xstyle: I ? null : H,
            children: h.jsx(c("GeoPrivateBadgeContext").Provider, {
                value: K,
                children: h.jsx(c("GeoPrivateBaseListRowLayout.react"), babelHelpers["extends"]({
                    badge: e,
                    description: n,
                    descriptionID: o,
                    isDisabled: u,
                    labelID: z,
                    trailingContent: G
                }, a))
            })
        });
        return I ? h.jsx("div", {
            className: c("stylex")(k["default"], H),
            role: "listitem",
            children: b
        }) : b
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function l(a) {
        return ["label"].includes(a) === !1
    }

    function m(a) {
        return ["listitem", "option", "label"].includes(a) === !1
    }
    e = d("GeoPrivateMakeComponent").makeGeoComponent("GeoBaseListRow", a);
    g["default"] = e
}), 98);
__d("GeoBinaryInputConstants", [], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = 24;
    b = a;
    c = {
        size: {
            height: "xxk0z11",
            width: "xvy4d1p"
        }
    };
    g.BINARY_INPUT_SIZE = b;
    g.binaryInputStyle = c
}), 98);
__d("GeoPrivateAccessibleInput.react", ["GeoDomID", "GeoPrivateMakeComponent", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.disabled;
        b = b === void 0 ? !1 : b;
        var e = a.xstyle,
            f = a["aria-labelledby"],
            g = a.id,
            j = a.inputRef,
            k = a["aria-describedby"];
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["disabled", "xstyle", "aria-labelledby", "id", "inputRef", "aria-describedby"]);
        g = d("GeoDomID").useApplyGeoDomIDsDirectly({
            id: (g = g) != null ? g : void 0,
            "aria-describedby": (g = k) != null ? g : void 0,
            "aria-labelledby": (k = f) != null ? k : void 0
        });
        f = g.ref;
        k = g.id;
        var l = g["aria-activedescendant"],
            m = g["aria-controls"],
            n = g["aria-owns"],
            o = g["aria-describedby"],
            p = g["aria-details"],
            q = g["aria-errormessage"],
            r = g["aria-flowto"];
        g = g["aria-labelledby"];
        j = c("useMergeRefs")(j, f);
        return h.jsx("input", babelHelpers["extends"]({}, a, {
            "aria-activedescendant": l,
            "aria-controls": m,
            "aria-describedby": o,
            "aria-details": p,
            "aria-errormessage": q,
            "aria-flowto": r,
            "aria-labelledby": g,
            "aria-owns": n,
            className: c("stylex")([i.input, b && i.inputDisabled, e]),
            disabled: b,
            id: k,
            ref: j
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var i = {
        input: {
            appearance: "xjyslct",
            cursor: "x1ypdohk",
            height: "x5yr21d",
            start: "x17qophe",
            marginTop: "xdj266r",
            marginEnd: "x11i5rnm",
            marginBottom: "xat24cr",
            marginStart: "x1mh8g0r",
            opacity: "x1w3u9th",
            outlineStyle: "x1t137rt",
            position: "x10l6tqk",
            top: "x13vifvy",
            width: "xh8yej3",
            zIndex: "x1vjfegm"
        },
        inputDisabled: {
            pointerEvents: "x47corl"
        }
    };
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoPrivateAccessibleInput", a);
    g["default"] = b
}), 98);
__d("GeoPrivateMultiElementLayoutContextReset.react", ["BUIMultiElementLayoutContext", "GeoPrivateInputGroupLayoutContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = function() {
        return null
    };
    var i = {
        getLayout: b
    };

    function a(a) {
        a = a.children;
        return h.jsx(c("GeoPrivateInputGroupLayoutContext").Resetter, {
            children: h.jsx(c("BUIMultiElementLayoutContext").Provider, {
                value: i,
                children: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GeoPrivateBinaryInput.react", ["FDSPrivateDisabledFocusContext", "GeoPrivateAccessibleInput.react", "GeoPrivateMakeComponent", "GeoPrivateMultiElementLayoutContextReset.react", "react", "useBoolean"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext;

    function a(a) {
        var b = a["aria-label"],
            d = a.checked,
            e = a.children,
            f = a["data-testid"];
        f = a.describedBy;
        var g = a.id,
            k = a.inputRef,
            l = a.isDisabled;
        l = l === void 0 ? !1 : l;
        var m = a.labelledBy,
            n = a.name,
            o = a.onChange,
            p = a.type;
        a = a.value;
        var q = c("useBoolean")(!1),
            r = q.value,
            s = q.setTrue;
        q = q.setFalse;
        var t = j(c("FDSPrivateDisabledFocusContext")),
            u = i(function(a) {
                return o == null ? void 0 : o(a.target.checked, a)
            }, [o]);
        f = h.jsx(c("GeoPrivateAccessibleInput.react"), {
            "aria-checked": d,
            "aria-describedby": f,
            "aria-disabled": l,
            "aria-label": b,
            "aria-labelledby": m,
            checked: d,
            "data-testid": void 0,
            disabled: l,
            id: g,
            inputRef: k,
            name: n,
            onChange: u,
            onMouseDown: s,
            onMouseLeave: q,
            onMouseUp: q,
            tabIndex: t ? -1 : void 0,
            type: p,
            value: a
        });
        return h.jsx("div", {
            className: "x3oybdh x1n2onr6 x1rg5ohu",
            children: h.jsx(c("GeoPrivateMultiElementLayoutContextReset.react"), {
                children: e({
                    checked: d,
                    input: f,
                    isActive: r,
                    isDisabled: l
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = d("GeoPrivateMakeComponent").makeGeoComponent("GeoPrivateBinaryInput", a);
    g["default"] = e
}), 98);
__d("GeoPrivateBinaryInputLayout.react", ["GeoBinaryInputConstants", "GeoPrivateInteractiveFrame.react", "GeoPrivateMakeComponent", "react", "stylex", "useGeoTheme"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.checked;
        b = b === void 0 ? !1 : b;
        var d = a.children,
            e = a.context,
            f = a.input,
            g = a.isActive;
        g = g === void 0 ? !1 : g;
        a = a.isDisabled;
        a = a === void 0 ? !1 : a;
        return h.jsxs(c("GeoPrivateInteractiveFrame.react"), {
            context: e,
            grow: "auto",
            isDisabled: a,
            xstyle: j({
                isDisabled: a,
                isActive: g
            }),
            children: [f, h.jsx("div", {
                className: c("stylex")(l({
                    isVisible: b
                })),
                children: d
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var i = {
        root: {
            boxSizing: "x9f619",
            paddingTop: "xexx8yu",
            paddingEnd: "x4uap5",
            paddingBottom: "x18d9i69",
            paddingStart: "xkhd6sd",
            justifyContent: "xl56j7k"
        }
    };

    function j(a) {
        var b = a.isDisabled;
        a = a.isActive;
        var e = c("useGeoTheme")();
        e = e.selectInteractiveColorPalette;
        return [i.root, d("GeoBinaryInputConstants").binaryInputStyle.size, !b && a && e({
            color: "flat",
            isFocused: a
        })]
    }
    var k = {
        root: {
            display: "x78zum5",
            opacity: "xg01cxk",
            transform: "x1f85oc2",
            transitionProperty: "x6o7n8i"
        },
        iconVisible: {
            opacity: "x1hc1fzr",
            transform: "x3oybdh"
        }
    };

    function l(a) {
        a = a.isVisible;
        var b = c("useGeoTheme")();
        b = b.selectTransition;
        return [b({
            duration: "fast",
            timing: "strong"
        }), k.root, a && k.iconVisible]
    }
    b = d("GeoPrivateMakeComponent").makeGeoComponent("GeoPrivateBinaryInputLayout", a);
    g["default"] = b
}), 98);
__d("GeoPrivateCheckboxInputLayout.react", ["GeoPrivateBinaryInputLayout.react", "GeoPrivateIcon.react", "GeoPrivateIconCheckmarkFilled16", "GeoPrivateIconMinusFilled16", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.input,
            d = a.isActive;
        d = d === void 0 ? !1 : d;
        var e = a.isDisabled;
        e = e === void 0 ? !1 : e;
        a = a.value;
        a = a === void 0 ? !1 : a;
        var f = a === "indeterminate";
        f = f ? c("GeoPrivateIconMinusFilled16") : c("GeoPrivateIconCheckmarkFilled16");
        return h.jsx(c("GeoPrivateBinaryInputLayout.react"), {
            checked: a !== !1,
            context: "control",
            input: b,
            isActive: d,
            isDisabled: e,
            children: h.jsx(c("GeoPrivateIcon.react"), {
                color: e ? "inherit" : "info",
                icon: f
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GeoBaseCheckboxInput.react", ["GeoPrivateBinaryInput.react", "GeoPrivateCheckboxInputLayout.react", "GeoPrivateLoggingAction", "GeoPrivateLoggingClassification", "GeoPrivateMakeComponent", "react", "useGeoPrivateWithLogging", "useLayoutEffect_SAFE_FOR_SSR", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useMemo,
        j = b.useRef;

    function a(a) {
        var b = a.htmlForTargetId,
            d = a.inputRef,
            e = a.isDisabled;
        e = e === void 0 ? !1 : e;
        var f = a.loggingName;
        f = f === void 0 ? "GeoBaseCheckboxInput" : f;
        var g = a.onChange,
            k = a.value,
            l = a.htmlValue,
            m = a.name;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["htmlForTargetId", "inputRef", "isDisabled", "loggingName", "onChange", "value", "htmlValue", "name"]);
        var n = j(null),
            o = k === "indeterminate",
            p = i(function() {
                return function(b, a) {
                    return g == null ? void 0 : g(a, b)
                }
            }, [g]),
            q = c("useGeoPrivateWithLogging")(p, {
                name: f,
                action: c("GeoPrivateLoggingAction").CLICK,
                classification: c("GeoPrivateLoggingClassification").USER_ACTION
            });
        p = i(function() {
            return function(a, b) {
                return q == null ? void 0 : q(b, a)
            }
        }, [q]);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            n.current != null && (n.current.indeterminate = o)
        }, [o]);
        f = c("useMergeRefs")(d, n);
        return h.jsx(c("GeoPrivateBinaryInput.react"), babelHelpers["extends"]({}, a, {
            checked: k === !0,
            id: b,
            inputRef: f,
            isDisabled: e,
            isIconVisible: k !== !1,
            name: m,
            onChange: p,
            type: "checkbox",
            value: l,
            children: function(a) {
                return h.jsx(c("GeoPrivateCheckboxInputLayout.react"), babelHelpers["extends"]({}, a, {
                    value: k
                }))
            }
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = d("GeoPrivateMakeComponent").makeGeoComponent("GeoBaseCheckboxInput", a);
    g["default"] = e
}), 98);
__d("GeoCheckboxInput.react", ["GeoBaseCheckboxInput.react", "GeoBaseListLayoutContext", "GeoBaseListRow.react", "GeoBaseListRowContext", "GeoPrivateClearInteractiveStylesContext", "GeoPrivateDisabledContext", "GeoPrivateMakeComponent", "joinDomIDs", "react", "useUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.containerRef,
            d = a["data-testid"];
        d = a.describedBy;
        var e = a.description,
            f = a.disabledMessage,
            g = a.isDisabled;
        g = g === void 0 ? !1 : g;
        var k = a.isReadOnly;
        k = k === void 0 ? !1 : k;
        var l = a.label,
            m = a.isLabelHidden,
            n = a.media,
            o = a.onChange,
            p = a.value,
            q = a.htmlValue,
            r = a.name,
            s = a.tooltip;
        a = a.xstyle;
        var t = c("useUniqueID")(),
            u = c("useUniqueID")(),
            v = c("useUniqueID")();
        d = c("joinDomIDs")(d, u);
        var w = i(c("GeoBaseListRowContext")),
            x = w.isNested;
        w = i(c("GeoBaseListLayoutContext"));
        var y = w.isWithinList;
        w = j(function() {
            return {
                isNested: x || !y
            }
        }, [x, y]);
        var z = g || k;
        return !y && m === !0 && n == null && f == null ? h.jsx(c("GeoBaseCheckboxInput.react"), {
            "aria-label": l,
            "data-testid": void 0,
            describedBy: d,
            htmlForTargetId: t,
            htmlValue: q,
            isDisabled: z,
            labelledBy: v,
            name: r,
            onChange: o,
            value: p
        }) : h.jsx(c("GeoPrivateDisabledContext").Provider, {
            value: null,
            children: h.jsx(c("GeoPrivateClearInteractiveStylesContext").Provider, {
                value: !0,
                children: h.jsx(c("GeoBaseListRowContext").Provider, {
                    value: w,
                    children: h.jsx(c("GeoBaseListRow.react"), {
                        accessibilityRole: "label",
                        containerRef: b,
                        control: h.jsx(c("GeoBaseCheckboxInput.react"), {
                            "data-testid": void 0,
                            describedBy: d,
                            htmlForTargetId: t,
                            htmlValue: q,
                            isDisabled: z,
                            labelledBy: v,
                            name: r,
                            onChange: o,
                            value: p
                        }),
                        description: e,
                        descriptionID: u,
                        disabledMessage: f,
                        isDisabled: g,
                        isFocusable: !1,
                        isLabelHidden: m,
                        isReadOnly: k,
                        label: l,
                        labelID: v,
                        media: n,
                        tooltip: s,
                        xstyle: a
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = d("GeoPrivateMakeComponent").makeGeoComponent("GeoCheckboxInput", a);
    g["default"] = e
}), 98);
__d("nearlyEqualNumbers", [], (function(a, b, c, d, e, f) {
    function a(a, b) {
        if (a === b) return !0;
        var c = Math.abs(a - b);
        if (c < Number.EPSILON) return !0;
        a = Math.abs(a);
        b = Math.abs(b);
        return c / (a + b) < Number.EPSILON
    }
    f["default"] = a
}), 66);
__d("mapMap", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        var c = new Map();
        a.forEach(function(a, d) {
            c.set(d, b(a, d))
        });
        return c
    }
    f["default"] = a
}), 66);
__d("AdsAPIPublisherPlatform", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        FACEBOOK: "facebook",
        INSTAGRAM: "instagram",
        AUDIENCE_NETWORK: "audience_network",
        MESSENGER: "messenger",
        WHATSAPP: "whatsapp",
        OCULUS: "oculus"
    });
    f["default"] = a
}), 66);