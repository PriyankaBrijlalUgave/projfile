if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("SecuredActionChallengePasswordDialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5198270610286156"
}), null);
__d("SecuredActionChallengePasswordDialogQuery$Parameters", ["SecuredActionChallengePasswordDialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionChallengePasswordDialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionChallengePasswordDialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("SecuredActionChallengeSSODialogQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7638652966208904"
}), null);
__d("SecuredActionChallengeSSODialogQuery$Parameters", ["SecuredActionChallengeSSODialogQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("SecuredActionChallengeSSODialogQuery_facebookRelayOperation"),
            metadata: {},
            name: "SecuredActionChallengeSSODialogQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("useAccessibilityAlerts", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useRef,
        k = b.useState;

    function a() {
        var a = j(null),
            b = j(new Map()),
            c = j(0),
            d = k([]),
            e = d[0],
            f = d[1];
        i(function() {
            return function() {
                a.current != null && a.current()
            }
        }, []);
        var g = h(function(a, d) {
            var e = c.current++;
            a = {
                key: e,
                message: a,
                options: d
            };
            b.current.set(e, a);
            f(Array.from(b.current.values()));
            return function() {
                b.current["delete"](e), f(Array.from(b.current.values()))
            }
        }, []);
        d = h(function(b, c) {
            a.current != null && a.current();
            b = g(b, c);
            a.current = b;
            return b
        }, [g]);
        return [e, d]
    }
    g["default"] = a
}), 98);
__d("HostnameRewriter", ["ConstUriUtils", "Env", "URI", "isFacebookURI", "lowerFacebookDomain"], (function(a, b, c, d, e, f, g) {
    var h = function(a) {
            return String(a).replace(/([.*+?^=!:${}()|[\]\/\\])/g, "\\$1")
        },
        i = null,
        j = null,
        k = new RegExp("facebook\\.com$"),
        l = new RegExp("^www\\.(|.*\\.)facebook\\.com$"),
        m = null,
        n = "facebook.com",
        o = null,
        p = new RegExp("fbcdn\\.net$"),
        q = new RegExp("^www\\."),
        r = new RegExp("(^|\\.)(facebook\\.com|workplace\\.com)$", "i");

    function s() {
        i = null;
        var a = "(^|\\.)";
        m = a + h(n) + "$";
        j = null
    }

    function t() {
        if (m == null) return null;
        if (i) return i;
        i = new RegExp(m, "i");
        return i
    }

    function u() {
        if (j) return j;
        j = new RegExp("(^|\\.)(" + h(n) + "|facebook\\.com)$", "i");
        return j
    }

    function v(a) {
        if (u().test(a) && n != null) return a.replace(k, n);
        else if (o != null && a !== null) return a.replace(p, o);
        return a
    }

    function w(a) {
        return l.test(a) ? a.replace(q, "web.") : a
    }

    function x(a) {
        return function(b) {
            b = new(c("URI"))(b);
            b.setDomain(a(b.getDomain()));
            return b
        }
    }

    function y(a, b) {
        n = a, o = b, s(), c("isFacebookURI").setRegex(t()), c("URI").registerFilter(x(v)), d("ConstUriUtils").registerDomainFilter(v), c("lowerFacebookDomain").setDomain(n)
    }

    function a(a, b) {
        n = a, c("URI").registerFilter(x(w))
    }

    function b() {
        var a = c("Env").hostnameRewriterConfig;
        if (a == null) return;
        switch (a.site) {
            case "onion":
                y(a.inboundName, a.cdnDomainName);
                break
        }
    }

    function e() {
        c("isFacebookURI").setRegex(r)
    }
    g.registerFacebookOverTorFilters = y;
    g.registerInternetDotOrgFilters = a;
    g.maybeRegisterFilters = b;
    g.treatWorkplaceAsFacebookURI = e
}), 98);
__d("getGeoAndCometModalCompatible", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("gkx")("6578")
    }
    g["default"] = a
}), 98);
__d("useCometAccessibilityAlerts", ["CometAccessibilityAnnouncement.react", "react", "useAccessibilityAlerts"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function i(a) {
        return h.jsx(h.Fragment, {
            children: a.alerts.map(function(a) {
                var b = a.key,
                    d = a.message;
                a = a.options;
                return h.createElement(c("CometAccessibilityAnnouncement.react"), babelHelpers["extends"]({}, a, {
                    key: b
                }), d)
            })
        })
    }
    i.displayName = i.name + " [from " + f.id + "]";

    function a() {
        var a = c("useAccessibilityAlerts")(),
            b = a[0];
        a = a[1];
        return [h.jsx(i, {
            alerts: b
        }), a]
    }
    g["default"] = a
}), 98);
__d("BaseToasterStateManagerProvider.react", ["BaseToasterStateManager", "BaseToasterStateManagerContext.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = c("BaseToasterStateManager").getInstance();

    function a(a) {
        a = a.children;
        return h.jsx(c("BaseToasterStateManagerContext.react").Provider, {
            value: i,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometCalloutReducer", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        switch (b.type) {
            case "addCallout":
                return a.calloutID == null ? babelHelpers["extends"]({}, a, b.payload) : a;
            case "removeCallout":
                return a.calloutID != null && a.calloutID === b.payload ? babelHelpers["extends"]({}, a, {
                    calloutID: void 0,
                    calloutProps: void 0,
                    contextRef: void 0
                }) : a;
            default:
                throw c("unrecoverableViolation")(b.type + " is not a supported action type", "comet_ui")
        }
    }
    g.CometCalloutReducer = a
}), 98);
__d("CometCalloutManager.react", ["BaseView.react", "CometCalloutContext", "CometCalloutReducer", "CometErrorBoundary.react", "CometPlaceholder.react", "ExecutionEnvironment", "deferredLoadComponent", "react", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo,
        k = b.useReducer,
        l = b.useRef,
        m = c("deferredLoadComponent")(c("requireDeferredForDisplay")("CometCalloutImpl.react").__setRef("CometCalloutManager.react")),
        n = {
            anchorRootRefContext: {
                current: c("ExecutionEnvironment").canUseDOM ? document.body : null
            },
            animationContext: null,
            calloutID: null,
            calloutProps: null,
            contextRef: null,
            scrollableAreaContext: []
        };

    function a(a) {
        var b = a.children;
        a = a.initialState;
        a = a === void 0 ? n : a;
        a = k(d("CometCalloutReducer").CometCalloutReducer, a);
        var e = a[0],
            f = a[1],
            g = l(null),
            o = i(function(a) {
                f({
                    payload: a,
                    type: "addCallout"
                })
            }, []),
            p = i(function(a) {
                f({
                    payload: a,
                    type: "removeCallout"
                })
            }, []),
            q = i(function() {
                var a;
                (a = g.current) == null ? void 0 : a.reposition()
            }, []);
        a = j(function() {
            return {
                addCallout: o,
                removeCallout: p,
                repositionCallout: q
            }
        }, [o, p, q]);
        return h.jsxs(c("CometCalloutContext").Provider, {
            value: a,
            children: [h.jsx(c("BaseView.react"), {
                children: b
            }), h.jsx(c("CometErrorBoundary.react"), {
                children: h.jsx(c("CometPlaceholder.react"), {
                    fallback: null,
                    children: h.jsx(m, babelHelpers["extends"]({}, e, {
                        imperativeRef: g
                    }))
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXManager.react", ["CometNUXManagerContext", "emptyFunction", "react", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo,
        k = b.useRef;

    function a(a) {
        var b = a.children,
            d = a.disableAuction,
            e = k(null),
            f = c("useStable")(function() {
                return new Set()
            }),
            g = c("useStable")(function() {
                return new Map()
            }),
            l = i(function(a, b, h) {
                var i;
                h === void 0 && (h = !1);
                if (!h && g.has(a) || f.has(a)) return c("emptyFunction");
                g.has(a) || g.set(a, []);
                (i = g.get(a)) == null ? void 0 : i.push(b);
                (d === !0 || e.current == null || h && a === e.current) && (e.current = a, b(!0));
                return function() {
                    var c;
                    e.current === a && (e.current = null);
                    g.set(a, (c = (c = g.get(a)) == null ? void 0 : c.filter(function(a) {
                        return a !== b
                    })) != null ? c : []);
                    ((c = g.get(a)) == null ? void 0 : c.length) === 0 && g["delete"](a)
                }
            }, [g, f, d]),
            m = i(function(a) {
                f.add(a);
                var b = g.get(a);
                b != null && b.forEach(function(a) {
                    return a(!1)
                });
                e.current === a && (e.current = null)
            }, [f, g]);
        a = j(function() {
            return {
                registerNUX: l,
                removeNUX: m
            }
        }, [m, l]);
        return h.jsx(c("CometNUXManagerContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXTourContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometNUXTourInProgressConsumerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometProgressStepper.react", ["fbt", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.color,
            d = b === void 0 ? "primary" : b;
        b = a.label;
        var e = a.roundCorners,
            f = e === void 0 ? !0 : e,
            g = a.step;
        e = a.testid;
        var j = a.totalSteps;
        a = a.type;
        var k = a === void 0 ? "default" : a;
        b != null ? a = h._("{name of the progress stepper}, step {current step} of {total number of steps}", [h._param("name of the progress stepper", b), h._param("current step", g), h._param("total number of steps", j)]) : a = h._("Progress, step {current step} of {total number of steps}", [h._param("current step", g), h._param("total number of steps", j)]);
        return i.jsx("div", babelHelpers["extends"]({}, c("testID")(e), {
            "aria-label": a,
            className: "xh8yej3 x1szn6h9 xozqiw3 x1q0g3np x1ja2u2z x1n2onr6 xkhd6sd x18d9i69 x4uap5 xexx8yu xeuugli x2lwn1j x1mh8g0r xat24cr x11i5rnm xdj266r xs83m0k x1iyjqo2 x78zum5 x9f619 x1qhh985 xcfux6l xm0m39n x972fbf x1q0q8m5 xu3j5b3 x26u7qi x13fuv20 x1qjc9v5",
            role: "img",
            children: Array(j).fill().map(function(a, b) {
                a = b < g;
                return i.jsx("div", {
                    className: c("stylex")({
                        "box-sizing-1": "x9f619"
                    }, k === "spaced-out" ? {
                        "padding-end-1": "xg83lxy",
                        "padding-start-1": "x1h0ha7o"
                    } : null, k === "spaced-out" && b === 0 ? {
                        "padding-start-1": "xkhd6sd"
                    } : null, k === "spaced-out" && b === j - 1 ? {
                        "padding-end-1": "x4uap5"
                    } : null),
                    style: {
                        width: "calc(100% / " + j + ")"
                    },
                    children: i.jsx("div", {
                        className: c("stylex")({
                            "background-color-1": "xmjcpbm",
                            "height-1": "xdk7pt"
                        }, b === 0 && f ? {
                            "border-bottom-start-radius-1": "x10y3i5r",
                            "border-top-start-radius-1": "x1lcm9me"
                        } : null, b === j - 1 && f ? {
                            "border-bottom-end-radius-1": "xrt01vj",
                            "border-top-end-radius-1": "x1yr5g0i"
                        } : null, k === "spaced-out" && f ? {
                            "border-bottom-end-radius-1": "xrt01vj",
                            "border-bottom-start-radius-1": "x10y3i5r",
                            "border-top-end-radius-1": "x1yr5g0i",
                            "border-top-start-radius-1": "x1lcm9me"
                        } : null, a && d === "primary" ? {
                            "background-color-1": "xtvsq51"
                        } : null, a && d === "secondary" ? {
                            "background-color-1": "x1qhmfi1"
                        } : null)
                    })
                }, b)
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXTourCardFooter.react", ["CometProgressStepper.react", "CometRow.react", "CometRowItem.react", "TetraButtonGroup.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = "center";

    function a(a) {
        var b = a.primaryButton,
            d = a.secondaryButton,
            e = a.tourIndex;
        a = a.tourLength;
        return h.jsxs(c("CometRow.react"), {
            align: "center",
            columns: 2,
            paddingHorizontal: 0,
            paddingTop: 0,
            spacingHorizontal: 32,
            verticalAlign: i,
            children: [h.jsx(c("CometRowItem.react"), {
                expanding: !0,
                verticalAlign: i,
                children: a > 1 ? h.jsx(c("CometProgressStepper.react"), {
                    step: e + 1,
                    totalSteps: a,
                    type: "spaced-out"
                }) : null
            }), h.jsx(c("CometRowItem.react"), {
                verticalAlign: i,
                children: h.jsx(c("TetraButtonGroup.react"), {
                    align: "end",
                    direction: "backward",
                    paddingHorizontal: 0,
                    paddingTop: 0,
                    primary: b,
                    secondary: d,
                    size: "medium",
                    verticalAlign: i
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXTourInlineSurvey.react", ["CometNUXInlineSurvey.react", "CometNUXTourContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.target;
        a = b.storageRef.current.hasAnsweredSurvey;
        var d = i(c("CometNUXTourContext")),
            e = j(function() {
                function a() {
                    b.storageRef.current.hasAnsweredSurvey = !0
                }
                return {
                    onHelpful: function() {
                        a(), d == null ? void 0 : d.onHelpful == null ? void 0 : d.onHelpful(b.key)
                    },
                    onNotHelpful: function() {
                        a(), d == null ? void 0 : d.onNotHelpful == null ? void 0 : d.onNotHelpful(b.key)
                    }
                }
            }, [b, d]),
            f = e.onHelpful;
        e = e.onNotHelpful;
        return h.jsx(c("CometNUXInlineSurvey.react"), {
            initialHasAnsweredSurvey: a,
            onHelpful: f,
            onNotHelpful: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXTourCard.react", ["fbt", "ix", "CometBackgroundImage.react", "CometColumn.react", "CometColumnItem.react", "CometNUXTourCardFooter.react", "CometNUXTourContext", "CometNUXTourInlineSurvey.react", "CometPopover.react", "Random", "TetraIcon.react", "TetraTextPairing.react", "fbicon", "react", "stylex", "unrecoverableViolation"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");
    b = d("react");
    var k = b.useContext,
        l = b.useRef,
        m = 16,
        n = {
            container: {
                maxWidth: "x1j9u4d2",
                minWidth: "x13o0s5z",
                position: "x1n2onr6"
            },
            headerStyle: {
                marginTop: "xcxhlts"
            }
        },
        o = {
            above: {
                marginBottom: "x1e56ztr"
            },
            below: {
                marginTop: "x1xmf6yo"
            },
            end: {
                marginStart: "x1i64zmx"
            },
            start: {
                marginEnd: "x1emribx"
            }
        };

    function a(a) {
        var b = a.inlineSurveySampleRate,
            e = a.primaryButton,
            f = a.secondaryButton,
            g = a.target,
            p = a.tour,
            q = a.tourIndex,
            r = a.tourLength;
        a = a.withArrow;
        var s = l(function() {
                var a;
                if (((a = p.callbacks) == null ? void 0 : a.onHelpful) == null || ((a = p.callbacks) == null ? void 0 : a.onNotHelpful) == null) return !1;
                if (g == null || g.storageRef.current.hasAnsweredSurvey === !0) return !1;
                if (g.storageRef.current.inlineSurveyCoinflipResult == null) {
                    a = d("Random").coinflip(b);
                    g.storageRef.current.inlineSurveyCoinflipResult = a
                }
                return g.storageRef.current.inlineSurveyCoinflipResult
            }()).current,
            t = k(c("CometNUXTourContext")),
            u = g.contextualLayerOptions,
            v = g.description,
            w = g.title;
        if (t == null) throw c("unrecoverableViolation")("No provider in nux tour card", "comet_ui");
        u = (u = u.position) != null ? u : "below";
        u = o[u];
        return j.jsx("div", {
            className: c("stylex")(n.container, !a && u),
            children: j.jsxs(c("CometPopover.react"), {
                withArrow: a,
                children: [g.image != null ? j.jsx(c("CometBackgroundImage.react"), babelHelpers["extends"]({}, g.image)) : null, j.jsxs(c("CometColumn.react"), {
                    paddingHorizontal: 16,
                    paddingTop: m,
                    paddingVertical: 12,
                    spacing: 20,
                    children: [j.jsx(c("CometColumnItem.react"), {
                        xstyle: n.headerStyle,
                        children: j.jsx(c("TetraTextPairing.react"), {
                            body: v,
                            headline: w,
                            headlineAddOn: j.jsx(c("TetraIcon.react"), {
                                "aria-label": h._("Close"),
                                icon: d("fbicon")._(i("478232"), 16),
                                onPress: function() {
                                    t.endTour()
                                },
                                size: 16,
                                testid: void 0
                            }),
                            level: 2
                        })
                    }), s !== !0 ? null : j.jsx(c("CometColumnItem.react"), {
                        paddingTop: 12,
                        children: j.jsx(c("CometNUXTourInlineSurvey.react"), {
                            target: g
                        })
                    }), j.jsx(c("CometColumnItem.react"), {
                        verticalAlign: "center",
                        children: j.jsx(c("CometNUXTourCardFooter.react"), {
                            primaryButton: e,
                            secondaryButton: f,
                            tourIndex: q,
                            tourLength: r
                        })
                    })]
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNuxTourHighlight.react", ["CometPulseEffectBase.react", "CometVisualCompletionAttributes", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useMemo,
        j = b.useRef;

    function k(a) {
        var b = a.outerElementRef;
        a = a.target;
        var d = a.contextRef,
            e = a.isTargetFixed,
            f = d == null ? void 0 : d.current,
            g = b.current;
        a = i(function() {
            return e ? o(f) : p(f, g)
        }, [f, e, g]);
        var j = i(function() {
            return l(f)
        }, [f]);
        d = i(function() {
            return m(j)
        }, [j]);
        return h.jsx("div", {
            style: (b = a) != null ? b : {
                display: "none"
            },
            children: h.jsx(c("CometPulseEffectBase.react"), {
                height: j.height,
                radii: j.radii,
                width: j.width,
                children: h.jsx("div", {
                    style: d
                })
            })
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a(a) {
        var b = j(null);
        return h.jsx("div", babelHelpers["extends"]({
            className: "xoegz02 x1n2onr6",
            ref: b
        }, c("CometVisualCompletionAttributes").IGNORE_DYNAMIC, {
            children: h.jsx(k, babelHelpers["extends"]({}, a, {
                outerElementRef: b
            }))
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function l(a) {
        if (a == null) return {
            height: null,
            radii: null,
            width: null
        };
        var b = window.getComputedStyle(a),
            c = b.borderBottomLeftRadius,
            d = b.borderBottomRightRadius,
            e = b.borderTopLeftRadius;
        b = b.borderTopRightRadius;
        return {
            height: a.offsetHeight,
            radii: {
                borderBottomLeftRadius: c,
                borderBottomRightRadius: d,
                borderTopLeftRadius: e,
                borderTopRightRadius: b
            },
            width: a.offsetWidth
        }
    }

    function m(a) {
        var b = a.height,
            c = a.radii;
        a = a.width;
        if (b == null || c == null || a == null) return {
            borderBottomLeftRadius: "",
            borderBottomRightRadius: "",
            borderTopLeftRadius: "",
            borderTopRightRadius: "",
            height: "",
            width: ""
        };
        var d = {
            borderBottomLeftRadius: "",
            borderBottomRightRadius: "",
            borderTopLeftRadius: "",
            borderTopRightRadius: "",
            height: b + "px",
            width: a + "px"
        };
        Object.keys(c).forEach(function(a) {
            var b = c[a];
            b != null && (d[a] = b + "px")
        });
        return d
    }

    function n(a, b) {
        return Number.isNaN(b) || Number.isNaN(a) || !Number.isFinite(b) || !Number.isFinite(a)
    }

    function o(a) {
        if (a == null) return null;
        a = a.getBoundingClientRect();
        var b = a.top;
        a = a.left;
        return n(a, b) ? null : {
            left: a + "px",
            position: "fixed",
            top: b + "px"
        }
    }

    function p(a, b) {
        if (a == null || b == null) return null;
        var c = a.offsetParent;
        if (c == null) return null;
        c = c.getBoundingClientRect();
        b = b.getBoundingClientRect();
        var d = b.top - c.top;
        b = b.left - c.left;
        c = a.offsetTop - d;
        d = a.offsetLeft - b;
        return n(d, c) ? null : {
            left: d + "px",
            position: "absolute",
            top: c + "px"
        }
    }
    g["default"] = a
}), 98);
__d("CometNUXTourOverlay.react", ["fbt", "BaseContextualLayer.react", "BaseContextualLayerAnchorRootContext", "CometLayerKeyCommandWrapper.react", "CometNUXTourCard.react", "CometNuxTourHighlight.react", "CometVisualCompletionAttributes", "FocusRegion.react", "focusScopeQueries", "getComputedStyle", "react", "scrollIntoView", "useCometUniqueID", "useSetAttributeRef"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    e = d("react");
    var j = e.useCallback,
        k = e.useEffect,
        l = e.useLayoutEffect,
        m = e.useState;

    function n(a, b) {
        if (a.endsWith("px")) return parseInt(a, 10);
        return a.endsWith("%") ? parseInt(a, 10) * b / 100 : 0
    }

    function b(b) {
        var e, f = b.inlineSurveySampleRate,
            g = b.onNext,
            o = b.onPrev,
            p = b.target,
            q = b.tour;
        b = b.tourIndex;
        var r = c("useCometUniqueID")(),
            s = c("useSetAttributeRef")("id", r),
            t = "url(#" + r + ")",
            u = c("useSetAttributeRef")("mask", t),
            v = m(function() {
                if (a.innerWidth != null && a.innerHeight != null) return [a.innerWidth, a.innerHeight];
                else return [100, 100]
            }),
            w = v[0],
            x = v[1];
        v = m(null);
        var y = v[0],
            z = v[1],
            A = j(function() {
                x([a.innerWidth, a.innerHeight]);
                var b = p ? p.contextRef.current : null;
                if (b != null) {
                    var d = b.getBoundingClientRect(),
                        e = d.height,
                        f = d.left,
                        g = d.top;
                    d = d.width;
                    b = (b = c("getComputedStyle")(b)) != null ? b : {};
                    var h = b.borderBottomLeftRadius,
                        i = b.borderBottomRightRadius,
                        j = b.borderRadius,
                        k = b.borderTopLeftRadius;
                    b = b.borderTopRightRadius;
                    z({
                        borderRadius: {
                            bottomLeft: (h = (h = h) != null ? h : j) != null ? h : "0px",
                            bottomRight: (i = (h = i) != null ? h : j) != null ? i : "0px",
                            topLeft: (i = (h = k) != null ? h : j) != null ? i : "0px",
                            topRight: (h = (k = b) != null ? k : j) != null ? h : "0px"
                        },
                        height: e,
                        left: f,
                        top: g,
                        width: d
                    })
                }
            }, [p]);
        k(function() {
            var a = {
                capture: !0,
                passive: !0
            };
            window.addEventListener("scroll", A, a);
            window.addEventListener("resize", A, a);
            return function() {
                window.removeEventListener("scroll", A, a), window.removeEventListener("resize", A, a)
            }
        }, [A]);
        l(function() {
            if ((p == null ? void 0 : p.contextRef.current) == null) return;
            c("scrollIntoView")(p.contextRef.current, {
                behavior: "smooth",
                verticalAlign: "center"
            });
            A()
        }, [A, p]);
        v = b === 0;
        var B = b >= q.targets.length - 1,
            C = y != null && y.borderRadius.topLeft === y.borderRadius.topRight && y.borderRadius.topLeft === y.borderRadius.bottomLeft && y.borderRadius.topLeft === y.borderRadius.bottomRight;
        e = p != null ? i.jsx(c("BaseContextualLayer.react"), babelHelpers["extends"]({
            contextRef: p.contextRef
        }, (e = p.contextualLayerOptions) != null ? e : {}, {
            children: p && i.jsx(c("CometNUXTourCard.react"), {
                inlineSurveySampleRate: f,
                primaryButton: {
                    label: B ? h._("Done") : h._("Next"),
                    onPress: g,
                    padding: "wide",
                    testid: "nux-tour-primary-button"
                },
                secondaryButton: v ? null : {
                    label: h._("Back"),
                    onPress: o,
                    reduceEmphasis: !0,
                    testid: "nux-tour-secondary-button"
                },
                target: p,
                tour: q,
                tourIndex: b,
                tourLength: q.targets.length,
                withArrow: p.withArrow
            }, p.key)
        })) : null;
        q.DISABLE_ANCHOR_ROOT_DO_NOT_USE !== !0 && p != null && (e = i.jsx(c("BaseContextualLayerAnchorRootContext").Provider, {
            value: p.anchorRootRef,
            children: e
        }));
        return i.jsxs("div", {
            className: "xhtitgo xn9wirt x13vifvy x17qophe xixxii4 x1dr59a3",
            children: [i.jsxs("svg", babelHelpers["extends"]({
                viewBox: [0, 0].concat(w).join(" ")
            }, c("CometVisualCompletionAttributes").IGNORE, {
                children: [i.jsx("defs", {
                    children: i.jsxs("mask", {
                        id: r,
                        ref: s,
                        suppressHydrationWarning: !0,
                        children: [i.jsx("rect", {
                            fill: "white",
                            height: "100%",
                            width: "100%",
                            x: "0",
                            y: "0"
                        }), y != null && C && i.jsx("rect", {
                            fill: "black",
                            height: y.height,
                            rx: n(y.borderRadius.topLeft, y.width),
                            ry: n(y.borderRadius.topLeft, y.height),
                            width: y.width,
                            x: y.left,
                            y: y.top
                        }), y != null && !C && i.jsxs(i.Fragment, {
                            children: [i.jsx("rect", {
                                fill: "black",
                                height: y.height * .75,
                                rx: n(y.borderRadius.topLeft, y.width),
                                ry: n(y.borderRadius.topLeft, y.height),
                                width: y.width * .75,
                                x: y.left,
                                y: y.top
                            }), i.jsx("rect", {
                                fill: "black",
                                height: y.height * .75,
                                rx: n(y.borderRadius.topRight, y.width),
                                ry: n(y.borderRadius.topRight, y.height),
                                width: y.width * .75,
                                x: y.left + y.width * .25,
                                y: y.top
                            }), i.jsx("rect", {
                                fill: "black",
                                height: y.height * .75,
                                rx: n(y.borderRadius.bottomLeft, y.width),
                                ry: n(y.borderRadius.bottomLeft, y.height),
                                width: y.width * .75,
                                x: y.left,
                                y: y.top + y.height * .25
                            }), i.jsx("rect", {
                                fill: "black",
                                height: y.height * .75,
                                rx: n(y.borderRadius.bottomRight, y.width),
                                ry: n(y.borderRadius.bottomRight, y.height),
                                width: y.width * .75,
                                x: y.left + y.width * .25,
                                y: y.top + y.height * .25
                            })]
                        })]
                    })
                }), i.jsx("rect", {
                    className: "x4xt3t0",
                    height: "100%",
                    mask: t,
                    ref: u,
                    suppressHydrationWarning: !0,
                    width: "100%",
                    x: "0",
                    y: "0"
                })]
            })), p && i.jsx(c("CometNuxTourHighlight.react"), {
                target: p
            }), i.jsx(d("FocusRegion.react").FocusRegion, {
                autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
                autoRestoreFocus: !0,
                containFocusQuery: d("focusScopeQueries").tabbableScopeQuery,
                recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
                children: i.jsx(c("CometLayerKeyCommandWrapper.react"), {
                    debugName: "nux tour layer",
                    children: e
                })
            })]
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g["default"] = b
}), 98);
__d("useCometNUXTourManagerReducer", ["react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useReducer,
        i = function(a, b) {
            switch (b.type) {
                case "next":
                    if (a.tourIndex == null || a.tour == null) {
                        c("recoverableViolation")("Active Target or Tour is null which should not be possible when advancing in a NUXTour", "comet_ui");
                        return a
                    }
                    return a.tourIndex >= a.tour.targets.length - 1 ? {
                        tour: null,
                        tourIndex: null
                    } : babelHelpers["extends"]({}, a, {
                        tourIndex: a.tourIndex + 1
                    });
                case "prev":
                    if (a.tourIndex == null || a.tour == null) {
                        c("recoverableViolation")("Active Target or Tour is null which should not be possible when going to the previous step in a NUXTour", "comet_ui");
                        return a
                    }
                    if (a.tourIndex <= 0) {
                        c("recoverableViolation")("Cannot go to the previous step when the tourIndex is 0", "comet_ui");
                        return a
                    }
                    return babelHelpers["extends"]({}, a, {
                        tourIndex: a.tourIndex - 1
                    });
                case "start_tour":
                    return a.tour != null ? a : {
                        tour: b.tour,
                        tourIndex: 0
                    };
                case "end_tour":
                    return {
                        tour: null,
                        tourIndex: null
                    }
            }
        },
        j = {
            tour: null,
            tourIndex: null
        };

    function a() {
        return h(i, j)
    }
    g["default"] = a
}), 98);
__d("CometNUXTourManager.react", ["CometNUXTourConsumerContext", "CometNUXTourContext", "CometNUXTourInProgressConsumerContext", "CometNUXTourOverlay.react", "react", "useCometNUXTourManagerReducer", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState,
        n = 100;

    function a(a) {
        var b = a.children;
        a = a.inlineSurveySampleRate;
        a = a === void 0 ? n : a;
        var d = l(new Map()),
            e = c("useCometNUXTourManagerReducer")(),
            f = e[0],
            g = f.tour,
            o = f.tourIndex,
            p = e[1],
            q = i(function() {
                return g != null && o != null ? d.current.get(g.targets[o]) : null
            }, [g, o]);
        f = m(q());
        var r = f[0],
            s = f[1],
            t = l(null);
        t.current !== (g == null ? void 0 : g.callbacks) && (t.current = g == null ? void 0 : g.callbacks);
        var u = l(function() {
            var a;
            a = (a = t.current) == null ? void 0 : a.onClose;
            a == null ? void 0 : a();
            t.current = null
        });
        e = k(function() {
            return {
                endTour: function() {
                    p({
                        type: "end_tour"
                    }), u.current()
                },
                registerTarget: function(a, b) {
                    d.current.set(a, b), s(q())
                },
                startTour: function(a) {
                    p({
                        tour: a,
                        type: "start_tour"
                    })
                },
                unregisterTarget: function(a) {
                    d.current["delete"](a), s(q())
                }
            }
        }, [p, q, d]);
        f = k(function() {
            return {
                endTour: function() {
                    p({
                        type: "end_tour"
                    }), u.current()
                },
                onHelpful: function() {
                    var a;
                    for (var b = arguments.length, c = new Array(b), d = 0; d < b; d++) c[d] = arguments[d];
                    (a = t.current) == null ? void 0 : a.onHelpful == null ? void 0 : a.onHelpful.apply(a, c)
                },
                onNotHelpful: function() {
                    var a;
                    for (var b = arguments.length, c = new Array(b), d = 0; d < b; d++) c[d] = arguments[d];
                    (a = t.current) == null ? void 0 : a.onNotHelpful == null ? void 0 : a.onNotHelpful.apply(a, c)
                }
            }
        }, [p]);
        var v = c("usePrevious")(o);
        j(function() {
            r === void 0 && u.current()
        });
        j(function() {
            var a = q();
            if (o != null && o !== v && (a == null ? void 0 : a.key) != null) {
                var b;
                (b = t.current) == null ? void 0 : b.onStepVisible == null ? void 0 : b.onStepVisible(a == null ? void 0 : a.key, o)
            }
        }, [q, v, o]);
        var w = i(function() {
                p({
                    type: "next"
                })
            }, [p]),
            x = i(function() {
                p({
                    type: "prev"
                })
            }, [p]);
        a = g != null && o != null && r !== void 0 ? h.jsx(c("CometNUXTourOverlay.react"), {
            inlineSurveySampleRate: a,
            onNext: w,
            onPrev: x,
            target: r,
            tour: g,
            tourIndex: o
        }) : null;
        var y = a != null,
            z = c("usePrevious")(y);
        j(function() {
            if (y === !0 && z !== !0) {
                var a;
                a = (a = t.current) == null ? void 0 : a.onOpen;
                a == null ? void 0 : a()
            } else y === !1 && z !== !1 && u.current()
        }, [z, y]);
        return h.jsxs(h.Fragment, {
            children: [h.jsx(c("CometNUXTourConsumerContext").Provider, {
                value: e,
                children: h.jsx(c("CometNUXTourInProgressConsumerContext").Provider, {
                    value: y,
                    children: b
                })
            }), a == null ? null : h.jsx(c("CometNUXTourContext").Provider, {
                value: f,
                children: a
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAudioLocalScopeProvider.react", ["CometAudioManagerContexts", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = a.customAudioSettingFunc,
            c = a.muted,
            e = a.setMuted,
            f = a.setVolume,
            g = a.volume,
            j = i(function() {
                return {
                    customAudioSettingFunc: b,
                    muted: c,
                    setMuted: e,
                    setVolume: f,
                    volume: g
                }
            }, [b, c, e, f, g]);
        return h.jsx(d("CometAudioManagerContexts").CometAudioLocalScopeContext.Provider, {
            value: j,
            children: a.children
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAudioManagerUtils", ["gkx", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
            a.type === "setMuted" && a.newMuted !== void 0 ? a.controller.setMuted(a.newMuted, a.reason) : a.type === "setVolume" && a.newVolume !== void 0 && a.controller.setVolume(a.newVolume)
        },
        i = function(a, b, c) {
            c = c.get(a);
            c && c.forEach(function(a) {
                a = b.get(a);
                a && a.controller.setMuted(!0, "audio_manager_initiated")
            })
        };
    a = {
        consumeAndExecuteAudioActions: function(a, b) {
            var c = function(b, c) {
                b = a.get(b.reason) || 0;
                c = a.get(c.reason) || 0;
                return b - c
            };
            b.sort(c);
            c = new Set();
            for (var d = 0; d < b.length; d++) {
                var e = b[d];
                c.has(e.audioSymbol) || (h(e), c.add(e.audioSymbol))
            }
            c.clear();
            b.length = 0
        },
        persistMutedAndVolumeStateForLocalAudioScope: function(a, b) {
            var c = a.audioLocalScope,
                d = a.controller,
                e = a.lastMuteReason,
                f = a.muted,
                g = a.paused,
                h = a.volume;
            c && (e || (h !== c.volume && d.setVolume(c.volume), f !== c.muted && e !== "user_initiated" && g && d.setMuted(c.muted, "audio_manager_initiated")));
            b.forEach(function(b) {
                var d = b.symbol;
                d !== a.symbol && (b.audioLocalScope && ((!b.audioLocalScope.muted && b.paused || b.audioLocalScope.muted) && b.controller.setMuted(b.audioLocalScope.muted, "audio_manager_initiated"), b.controller.setVolume(c.volume)))
            })
        },
        persistMutedStateForLocalAudioScope: function(a, b) {
            var c = a.audioLocalScope,
                d = a.controller,
                e = a.lastMuteReason,
                f = a.muted,
                g = a.paused;
            c && (f !== c.muted && e !== "user_initiated" && g && d.setMuted(c.muted, "audio_manager_initiated"));
            b.forEach(function(b) {
                var c = b.symbol;
                c !== a.symbol && (b.audioLocalScope && ((!b.audioLocalScope.muted && b.paused || b.audioLocalScope.muted) && b.controller.setMuted(b.audioLocalScope.muted, "audio_manager_initiated")))
            })
        },
        persistVolumeStateForLocalAudioScope: function(a, b, c) {
            var d = a.audioLocalScope,
                e = a.controller,
                f = a.lastMuteReason,
                g = a.volume;
            d && (f || g !== d.volume && e.setVolume(d.volume));
            b.forEach(function(b) {
                var e = b.symbol;
                if (e !== a.symbol && (b.audioLocalScope && b.volume !== d.volume)) {
                    e = {
                        audioSymbol: e,
                        controller: b.controller,
                        newVolume: d.volume,
                        reason: "audio_manager_initiated",
                        type: "setVolume"
                    };
                    c.push(e)
                }
            })
        },
        register: function(a, b, c, d, e) {
            var f = a.groupID,
                g = a.symbol;
            c.set(g, a);
            e.has(f) || e.set(f, b);
            if (d.has(f)) {
                c = d.get(f);
                c && !c.has(g) && c.add(g)
            } else {
                a = new Set();
                a.add(g);
                d.set(f, a)
            }
        },
        unmuteAudiosMutedByAudioManager: function(a) {
            var b = a.controller,
                c = a.lastMuteReason,
                d = a.muted;
            a = a.paused;
            a && d && c === "audio_manager_initiated" && b.setMuted(!1, "audio_manager_initiated")
        },
        unregister: function(a, b, c, d, e, f, g) {
            if (e.has(a)) {
                var h = e.get(a);
                h && e["delete"](a)
            }
            b.has(a) && b["delete"](a);
            if (d.has(c)) {
                h = d.get(c);
                h && h.has(a) && (h["delete"](a), h.size === 0 && (d["delete"](c), g.has(c) && g["delete"](c), f.has(c) && f["delete"](c)))
            }
        },
        updateAudioContext: function(a, b) {
            var d = a.audioLocalScope,
                e = a.lastMuteReason,
                f = a.muted,
                g = a.previousVolume;
            a = a.volume;
            d && (!c("gkx")("1842356") || d.customAudioSettingFunc) && (e === "user_initiated" && (f && b.size === 0 && !d.muted ? d.setMuted(!0) : !f && d.muted && d.setMuted(!1)), g !== null && g !== a && d.setVolume(a))
        },
        updateAudioContextWithGroup: function(a, b) {
            var c = a.audioLocalScope,
                d = a.lastMuteReason,
                e = a.muted,
                f = a.previousVolume;
            a = a.volume;
            c && (d === "user_initiated" && (e && b.size === 0 && !c.muted ? c.setMuted(!0) : !e && c.muted && c.setMuted(!1)), f !== null && f !== a && c.setVolume(a))
        },
        updateCurrentPlayingAudio: function(a, b, c) {
            var d = a.lastMuteReason,
                e = a.lastPlayReason,
                f = a.muted,
                g = a.paused,
                h = a.symbol;
            !f && !g && !c.has(h) ? c.size > 0 ? d === "user_initiated" || e === "user_initiated" || d === "costreaming_switch_stream_initiated" || d === "tahoe_transition_phase_initiated" ? (c.forEach(function(d) {
                var e = b.get(d);
                if (e) {
                    e = e.controller;
                    e !== a.controller && e.setMuted(!0, "audio_manager_initiated")
                }
                c["delete"](d)
            }), c.add(h)) : a.controller.setMuted(!0, "audio_manager_initiated") : c.add(h) : c.has(h) && (f || g) && c["delete"](h)
        },
        updateCurrentPlayingAudioGroup: function(a, b, c, d, e) {
            var f = a.groupID,
                g = a.lastMuteReason,
                h = a.lastPlayReason,
                j = a.muted;
            a = a.paused;
            var k = d.get(f);
            !j && !a && !e.has(f) ? e.size > 0 ? g === "user_initiated" || h === "user_initiated" ? (e.forEach(function(a) {
                var f = d.get(a);
                f && (f.setAllowSound(!1), i(a, b, c));
                e["delete"](a)
            }), e.add(f), k == null ? void 0 : k.setAllowSound(!0)) : k && (k.setAllowSound(!1), i(f, b, c)) : (k == null ? void 0 : k.setAllowSound(!0), e.add(f)) : e.has(f) && (j || a) && e["delete"](f)
        },
        updateCurrentPlayingAudioIgnoreLastReason: function(a, b, c) {
            var d = a.muted,
                e = a.paused;
            a = a.symbol;
            !d && !e && !c.has(a) ? (c.size > 0 && c.forEach(function(a) {
                var d = b.get(a);
                if (d) {
                    d = d.controller;
                    d.setMuted(!0, "audio_manager_initiated")
                }
                c["delete"](a)
            }), c.add(a)) : c.has(a) && (d || e) && c["delete"](a)
        },
        updateRegisteredAudio: function(a, b) {
            var d = a.symbol,
                e = b.get(d);
            e ? b.set(d, a) : c("recoverableViolation")("Received an update for an unregisterd video unit: " + d, "comet_video_player")
        }
    };
    g.CometAudioManagerUtils = a
}), 98);
__d("CometAudioManager.react", ["CometAudioLocalScopeProvider.react", "CometAudioManagerContexts", "CometAudioManagerUtils", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useMemo,
        k = b.useRef,
        l = b.useState,
        m = new Map([
            ["user_initiated", 0],
            ["tahoe_transition_phase_initiated", 1],
            ["watch_and_scroll_transition_phase_initiated", 2],
            ["audio_manager_initiated", 3],
            ["warning_screen_cover", 4],
            ["autoplay_initiated", 5],
            ["raid_initiated", 6],
            ["loop_initiated", 7],
            ["product_initiated", 8],
            ["commercial_break", 9],
            ["other_user_initiated", 10],
            ["costreaming_switch_stream_initiated", 11],
            ["huddle_speaker_experience_initiated", 12],
            ["fblivewith_joiner_experience_initiated", 13]
        ]);

    function a(a) {
        var b = k(new Map()),
            e = k(new Map()),
            f = k(new Map()),
            g = k(new Set()),
            n = k(new Set()),
            o = k([]),
            p = k([]),
            q = i(function(a, c) {
                d("CometAudioManagerUtils").CometAudioManagerUtils.register(a, c, b.current, e.current, f.current)
            }, []),
            r = i(function(a, c) {
                d("CometAudioManagerUtils").CometAudioManagerUtils.unregister(a, g.current, c, e.current, b.current, f.current, n.current)
            }, []),
            s = i(function(a) {
                d("CometAudioManagerUtils").CometAudioManagerUtils.updateRegisteredAudio(a, b.current);
                c("gkx")("1626006") && d("CometAudioManagerUtils").CometAudioManagerUtils.updateCurrentPlayingAudio(a, b.current, g.current);
                d("CometAudioManagerUtils").CometAudioManagerUtils.updateAudioContext(a, g.current);
                var e = a.audioLocalScope.customAudioSettingFunc;
                e && c("gkx")("1657807") ? e(a, b.current, o.current, p.current) : c("gkx")("1613919") && d("CometAudioManagerUtils").CometAudioManagerUtils.persistVolumeStateForLocalAudioScope(a, b.current, p.current);
                d("CometAudioManagerUtils").CometAudioManagerUtils.consumeAndExecuteAudioActions(m, o.current);
                d("CometAudioManagerUtils").CometAudioManagerUtils.consumeAndExecuteAudioActions(m, p.current)
            }, []),
            t = j(function() {
                return {
                    register: q,
                    unregister: r,
                    update: s
                }
            }, [q, r, s]),
            u = l(!0),
            v = u[0];
        u = u[1];
        var w = l(1),
            x = w[0];
        w = w[1];
        return h.jsx(c("CometAudioLocalScopeProvider.react"), {
            muted: v,
            setMuted: u,
            setVolume: w,
            volume: x,
            children: h.jsx(d("CometAudioManagerContexts").AudioApiContext.Provider, {
                value: t,
                children: a.children
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("GlobalVideoPorts.react", ["CometErrorBoundary.react", "FBLogger", "GlobalVideoPortsContexts", "Promise", "emptyFunction", "gkx", "react", "requireDeferredForDisplay", "requireWeak", "useInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useEffect,
        k = e.useRef,
        l = e.useState,
        m = c("requireDeferredForDisplay")("GlobalVideoPortsImpl.react").__setRef("GlobalVideoPorts.react");
    e = c("emptyFunction");

    function n(a) {
        var c = a.debugLoadDelayMs,
            d = a.onError,
            e = a.onLoaded,
            f = null;
        return function() {
            if (f != null) return f;
            var a = m.getModuleIfRequireable();
            f = (a ? b("Promise").resolve(a) : m.load()).then(function(a) {
                return a
            }).then(function(a) {
                e(a)
            })["catch"](function(a) {
                d(a)
            });
            return f
        }
    }
    var o = c("emptyFunction"),
        p = 3e4;

    function a(a) {
        var b = a.children,
            e = a.debugLoadDelayMs;
        a = a.debugLoadImmediately;
        var f = l(function() {
                return {
                    places: new Map(),
                    placesSequenceNumberNext: 0,
                    videos: new Map()
                }
            }),
            g = f[0],
            m = f[1];
        f = l(null);
        var q = f[0],
            r = f[1];
        f = l(null);
        var s = f[0],
            t = f[1],
            u = k(m),
            v = k(r);
        j(function() {
            u.current === null && (u.current = m);
            v.current === null && (v.current = r);
            return function() {
                u.current = null, v.current = null
            }
        }, []);
        c("useInterval")(q != null ? function() {
            q.collectGarbage()
        } : null, p, [q]);
        f = l(function() {
            return n({
                debugLoadDelayMs: e,
                onError: function(a) {
                    c("FBLogger")("video").catching(a).warn("GlobalVideoPortsImpl failed to load")
                },
                onLoaded: function(a) {
                    t(function() {
                        return a
                    })
                }
            })
        });
        f = f[0];
        o(a, t);
        a = i(function(a) {
            var b = v.current;
            if (b) {
                a = a(function(a) {
                    var b = u.current;
                    b && b(a)
                });
                b(a)
            }
        }, []);
        return h.jsx(d("GlobalVideoPortsContexts").GlobalVideoPortsLoaderContextProvider, {
            value: f,
            children: h.jsx(d("GlobalVideoPortsContexts").GlobalVideoPortsManagerContextProvider, {
                value: q,
                children: h.jsxs(d("GlobalVideoPortsContexts").GlobalVideoPortsStateContextProvider, {
                    value: g,
                    children: [s ? h.jsx(c("CometErrorBoundary.react"), {
                        children: h.jsx(s, {
                            setGlobalVideoPortsManager: a
                        })
                    }) : null, b]
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometThrottledDebounce", ["clearTimeout", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        var e, f = 0,
            g = null,
            h, i, j = function() {
                g != null && (c("clearTimeout")(g), g = null)
            },
            k = function() {
                var k = Array.from(arguments),
                    l = Date.now();
                h = this;
                i = k;
                e = l;
                var m = function() {
                    i != null && a.apply(h, i), h = i = null, f = Date.now(), g = null
                };
                f + d < l ? (j(), m()) : e + b > l && (j(), g = c("setTimeout")(m, b))
            };
        k.cancel = function() {
            i = h = null, j()
        };
        return k
    }
    g["default"] = a
}), 98);
__d("VideoAutoplayManagerUtils", ["DOMRectIsEqual"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        var e = a ? a.symbol : null;
        return a != null && e !== b && a.previousAutoplayDecision === a.currentAutoplayDecision && c("DOMRectIsEqual")((e = a.previousVideoPlayerViewabilityInfo) == null ? void 0 : e.positionToViewport, a.videoPlayerViewabilityInfo.positionToViewport) && !(b == null && d === 1 && ((e = a.previousVideoPlayerViewabilityInfo) == null ? void 0 : e.visiblePercentage) !== a.videoPlayerViewabilityInfo.visiblePercentage)
    }

    function h(a, b) {
        a = a.videoPlayerViewabilityInfo.positionToViewport;
        if (a) {
            var c = a.height;
            a = a.y;
            a = a + c / 2;
            return Math.abs(a - b)
        }
        return Number.POSITIVE_INFINITY
    }

    function b(a, b) {
        return function(c, d) {
            var e = Math.floor(h(c, a)),
                f = Math.floor(h(d, a)),
                g = c.videoPlayerViewabilityInfo.positionToViewport,
                i = d.videoPlayerViewabilityInfo.positionToViewport,
                j = 1.05,
                k = Math.abs(e - f),
                l = !1;
            if (g && i) {
                g = Math.max(g.height, i.height);
                l = k <= g / 2 * j
            }
            if (!l)
                if (e < f) return -1;
                else if (e > f) return 1;
            i = c.videoPlayerViewabilityInfo.visiblePercentage;
            k = d.videoPlayerViewabilityInfo.visiblePercentage;
            g = .01;
            if (Math.abs(i - k) > g)
                if (i > k) return -1;
                else if (i < k) return 1;
            e = (l = (j = c.videoPlayerViewabilityInfo.positionToViewport) == null ? void 0 : j.x) != null ? l : 0;
            i = (g = (f = d.videoPlayerViewabilityInfo.positionToViewport) == null ? void 0 : f.x) != null ? g : 0;
            return b ? i - e : e - i
        }
    }

    function d(a, b, c) {
        var d = b.keys(),
            e = d.next(),
            f = [];
        while (e.value != null) {
            var g = b.get(e.value);
            if (g) {
                var h = g.autoplayLocalScope,
                    i = g.shouldAutoplayManageVideo;
                g = g.symbol;
                if (i && h.autoplayScopeID === a) {
                    i = c.get(g);
                    if (i) {
                        h = i.currentAutoplayDecision;
                        var j = i.videoPlayerViewabilityInfo;
                        c.set(g, babelHelpers["extends"]({}, i, {
                            previousAutoplayDecision: h,
                            previousVideoPlayerViewabilityInfo: j
                        }));
                        h === "ALLOW" && f.push(i)
                    }
                }
            }
            e.done || (e = d.next())
        }
        return f
    }
    g.shouldSkipBestAutoplayVideo = a;
    g.createAutoplayVideosSorter = b;
    g.createPlayableArrayFromRegisteredVideosAndUpdateVideoState = d
}), 98);
__d("useCometPassiveWindowSize", ["ExecutionEnvironment", "react", "removeFromArray"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = b.useState;

    function k() {
        if (c("ExecutionEnvironment").canUseDOM) try {
            return {
                innerHeight: window.innerHeight,
                innerWidth: window.innerWidth,
                outerHeight: window.outerHeight,
                outerWidth: window.outerWidth
            }
        } catch (a) {
            return {
                innerHeight: 0,
                innerWidth: 0,
                outerHeight: 0,
                outerWidth: 0
            }
        }
        return {
            innerHeight: 0,
            innerWidth: 0,
            outerHeight: 0,
            outerWidth: 0
        }
    }

    function a() {
        var a = i([]),
            b = j(function() {
                return {
                    getCurrent: function() {
                        return k()
                    },
                    subscribe: function(b) {
                        a.current.push(b);
                        return {
                            remove: function() {
                                c("removeFromArray")(a.current, b)
                            }
                        }
                    }
                }
            }),
            d = b[0];
        b[1];
        h(function() {
            var b = function() {
                var b = Array.from(a.current);
                b.forEach(function(a) {
                    return a()
                })
            };
            window.addEventListener("resize", b);
            return function() {
                window.removeEventListener("resize", b)
            }
        }, []);
        return d
    }
    g["default"] = a
}), 98);
__d("VideoAutoplayManagerX.react", ["CometThrottle", "CometThrottledDebounce", "CoreVideoPlayerAutoplayClientUtils", "Locale", "VideoAutoplayLocalScopeProvider.react", "VideoAutoplayManagerUtils", "VideoPlayerAutoplayContexts", "VideoPlayerAutoplayRulesProvider", "WwwCometVideoAutoplayFalcoEvent", "clearTimeout", "gkx", "qex", "react", "recoverableViolation", "setTimeout", "useCometPassiveWindowSize", "useCometUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useRef,
        m = (e = c("qex")._("1637")) != null ? e : 0,
        n = (b = c("qex")._("1638")) != null ? b : 100,
        o = (e = c("qex")._("1639")) != null ? e : 100,
        p = (b = c("qex")._("1640")) != null ? b : !1,
        q = (e = c("qex")._("1641")) != null ? e : !0,
        r = (b = c("qex")._("1642")) != null ? b : 15,
        s = (e = c("qex")._("1643")) != null ? e : 9e3,
        t = (b = c("qex")._("1644")) != null ? b : 750,
        u = 200;

    function a(a) {
        var b = c("useCometUniqueID")(),
            e = k(function() {
                return "MX::" + b
            }, [b]),
            f = l(e);
        j(function() {
            f.current = e
        }, [e]);
        var g = l(new Map()),
            v = l(new Map()),
            w = l(new Map()),
            x = l(new Map()),
            y = l(null),
            z = l(!1),
            A = c("useCometPassiveWindowSize")(),
            B = l(A),
            C = l(0);
        j(function() {
            B.current = A
        }, [A]);
        j(function() {
            var a = z,
                b = y,
                d = g;
            a.current = !1;
            return function() {
                a.current = !0;
                c("clearTimeout")(b.current);
                var e = d.current.values(),
                    f = e.next();
                while (f.value != null) {
                    var g = f.value,
                        h = g.longThrottle,
                        i = g.throttle;
                    g = g.throttledDebounce;
                    i.cancel();
                    h.cancel();
                    g.cancel();
                    f.done || (f = e.next())
                }
            }
        }, []);
        var D = i(function(a) {
                var b;
                if (z.current) return;
                var e = a.autoplayScopeID,
                    g = (b = x.current.get(e)) != null ? b : null;
                b = d("VideoAutoplayManagerUtils").createPlayableArrayFromRegisteredVideosAndUpdateVideoState(e, v.current, w.current);
                var h = B.current.getCurrent();
                h = h.innerHeight / 2;
                b.sort(d("VideoAutoplayManagerUtils").createAutoplayVideosSorter(h, d("Locale").isRTL()));
                h = 0;
                var i = b[h],
                    j, k = i == null;
                while (!k) d("VideoAutoplayManagerUtils").shouldSkipBestAutoplayVideo(i, g, b.length) ? (i = b[++h], k = i == null) : k = !0;
                j = i ? i.symbol : null;
                c("clearTimeout")(y.current);
                y.current = null;
                a.customAutoplaySelectionFunc && (j = a.customAutoplaySelectionFunc(b, j, g));
                if (j !== g) {
                    if (g) {
                        k = g ? v.current.get(g) : null;
                        if (k) {
                            var l = k.controller;
                            h = l.getCurrentState();
                            i = h.paused;
                            b = g ? w.current.get(g) : null;
                            k = function(a) {
                                var b;
                                d("CoreVideoPlayerAutoplayClientUtils").log(f.current, "[PAUSE] previously selected autoplay video: " + ((b = g) != null ? b : "null"));
                                c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                                    return {
                                        autoplay_event_name: "pause",
                                        autoplay_scope_id: e,
                                        event_creation_time: Date.now(),
                                        initiator: f.current,
                                        initiator_type: "autoplay_manager",
                                        selected_autoplay_video_symbol: j,
                                        target: g,
                                        target_current_autoplay_decision: a == null ? void 0 : a.currentAutoplayDecision
                                    }
                                });
                                l.pause("autoplay_initiated")
                            };
                            if (b) {
                                h = b.currentAutoplayDecision;
                                h === "ALLOW" && !i && k(b)
                            } else k()
                        }
                    }
                    if (j) {
                        h = v.current.get(j);
                        if (h) {
                            i = h.controller;
                            b = Date.now() - C.current;
                            if (m > 0 && b < n && i.getCurrentState().bufferEnd < m) {
                                c("clearTimeout")(y.current);
                                y.current = c("setTimeout")(function() {
                                    D(a)
                                }, o);
                                d("CoreVideoPlayerAutoplayClientUtils").log(f.current, "[SKIP] defer autoplay for low buffer video during scroll: " + j);
                                return
                            }
                            d("CoreVideoPlayerAutoplayClientUtils").log(f.current, "[PLAY] newly selected autoplay video: " + j);
                            var p = w.current.get(j) || null;
                            c("WwwCometVideoAutoplayFalcoEvent").log(function() {
                                return {
                                    autoplay_event_name: "play",
                                    autoplay_scope_id: e,
                                    event_creation_time: Date.now(),
                                    initiator: f.current,
                                    initiator_type: "autoplay_manager",
                                    selected_autoplay_video_symbol: j,
                                    target: g,
                                    target_current_autoplay_decision: p == null ? void 0 : p.currentAutoplayDecision
                                }
                            });
                            i.play("autoplay_initiated")
                        }
                    }
                    x.current.set(e, j)
                }
            }, []),
            E = i(function(a) {
                a = a.autoplayScopeID;
                return {
                    selectedAutoplayVideoSymbol: x.current.get(a)
                }
            }, []),
            F = i(function(a, b, e, h, i, j) {
                d("CoreVideoPlayerAutoplayClientUtils").log(f.current, "[Register] " + a);
                v.current.set(a, {
                    autoplayLocalScope: e,
                    controller: h,
                    hiddenSubtreePassive: i,
                    instanceKey: b,
                    shouldAutoplayManageVideo: j,
                    symbol: a
                });
                h = e.autoplayScopeID;
                g.current.has(h) || g.current.set(h, {
                    longThrottle: c("CometThrottle")(D, t),
                    throttle: c("CometThrottle")(D, u),
                    throttledDebounce: c("CometThrottledDebounce")(D, r, s)
                })
            }, []),
            G = i(function(a, b, d) {
                var e = v.current.get(a);
                if (e) {
                    e = e.autoplayLocalScope;
                    var f = e.autoplayScopeID,
                        h = w.current.get(a),
                        i = h ? h.previousAutoplayDecision : null,
                        j = h ? h.previousVideoPlayerViewabilityInfo : null;
                    w.current.set(a, {
                        currentAutoplayDecision: b,
                        previousAutoplayDecision: i,
                        previousVideoPlayerViewabilityInfo: j,
                        symbol: a,
                        videoPlayerViewabilityInfo: d
                    });
                    i = !0;
                    (b === "IGNORE" || h && (c("gkx")("1583620") ? h.previousAutoplayDecision : h.currentAutoplayDecision) === "IGNORE") && (i = !1);
                    j = x.current.get(f) || null;
                    j === a && b !== "ALLOW" && x.current.set(f, null);
                    if (i) {
                        d = g.current.get(f);
                        d && (p && j == null ? d.longThrottle(e) : q ? d.throttledDebounce(e) : d.throttle(e))
                    }
                } else c("recoverableViolation")("Received an update for an unregisterd video unit: " + a, "comet_video_player");
                C.current = Date.now()
            }, []),
            H = i(function(a) {
                d("CoreVideoPlayerAutoplayClientUtils").log(f.current, "[Unregister] " + a);
                if (v.current.has(a)) {
                    var b = v.current.get(a);
                    if (b) {
                        var e;
                        b = b.autoplayLocalScope;
                        var h = b.autoplayScopeID;
                        w.current["delete"](a);
                        e = (e = x.current.get(h)) != null ? e : null;
                        if (e === a) {
                            x.current.set(h, null);
                            e = g.current.get(h);
                            e ? p ? e.longThrottle(b) : q ? e.throttledDebounce(b) : e.throttle(b) : c("recoverableViolation")("No throttles exist for the current scope: " + h + ", this is probably an error.", "comet_video_player")
                        }
                        v.current["delete"](a)
                    }
                }
            }, []),
            I = k(function() {
                return {
                    getAutoplayManagerDebugInfo: E,
                    register: F,
                    unregister: H,
                    update: G
                }
            }, [E, F, H, G]),
            J = d("VideoPlayerAutoplayRulesProvider").provideAutoplayRules("basic");
        return h.jsx(d("VideoPlayerAutoplayContexts").AutoplayApiContext.Provider, {
            value: I,
            children: h.jsx(c("VideoAutoplayLocalScopeProvider.react"), {
                autoplayLocalRules: J,
                children: a.children
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerGlobalComponents.react", ["CometAudioManager.react", "GlobalVideoPorts.react", "VideoAutoplayManagerX.react", "cr:1969469", "cr:992073", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react").Fragment;
    var i = (d = b("cr:1969469")) != null ? d : e,
        j = (d = b("cr:992073")) != null ? d : e;

    function a(a) {
        a = a.children;
        return h.jsx(c("GlobalVideoPorts.react"), {
            children: h.jsx(c("CometAudioManager.react"), {
                children: h.jsx(c("VideoAutoplayManagerX.react"), {
                    children: h.jsx(j, {
                        children: h.jsx(i, {
                            children: a
                        })
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAppShell.react", ["BaseToasterStateManagerProvider.react", "CometCalloutManager.react", "CometNUXManager.react", "CometNUXTourManager.react", "VideoPlayerGlobalComponents.react", "cr:10726", "cr:2099", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    d = (e = b("cr:2099")) != null ? e : {
        DocumentTranslationStatusProvider: h.Fragment
    };
    var i = d.DocumentTranslationStatusProvider;

    function a(a) {
        var d = a.children;
        a = a.toaster;
        return h.jsx(i, {
            children: h.jsxs(c("BaseToasterStateManagerProvider.react"), {
                children: [h.jsx(c("CometCalloutManager.react"), {
                    children: h.jsx(c("CometNUXTourManager.react"), {
                        children: h.jsx(c("CometNUXManager.react"), {
                            children: h.jsx(c("VideoPlayerGlobalComponents.react"), {
                                children: b("cr:10726") != null ? h.jsx(b("cr:10726"), {
                                    children: d
                                }) : d
                            })
                        })
                    })
                }), a]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseDocumentScrollView.react", ["BaseView.react", "DocumentScrollViewPageOffsetsContext", "HiddenSubtreeContext", "HiddenSubtreeContextProvider.react", "react", "useLayoutEffect_SAFE_FOR_SSR", "usePrevious", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useContext,
        k = e.useRef,
        l = e.useState,
        m = {
            detached: {
                MsOverflowStyle: "x1pq812k",
                height: "x5yr21d",
                overflowX: "xw2csxc",
                overflowY: "x1odjw0f",
                position: "xixxii4",
                scrollbarWidth: "x1rohswg",
                start: "x17qophe",
                top: "x13vifvy",
                width: "xh8yej3",
                "::-webkit-scrollbar": {
                    display: "xfk6m8",
                    height: "x1yqm8si",
                    width: "xjx87ck"
                }
            }
        },
        n = new Map(),
        o = new Set(),
        p = null;

    function q(a, b) {
        return !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING)
    }

    function r() {
        var a = null;
        n.forEach(function(b, c) {
            a == null ? a = c : a != null && c != null && q(a, c) && !o.has(c) && (a = c)
        });
        return a
    }

    function s(a) {
        return p == null || q(p, a)
    }

    function b(b) {
        var d = b.contextKey,
            e = d === void 0 ? null : d;
        d = b.detached;
        d = d === void 0 ? !1 : d;
        b.detachedPageOffsets;
        var f = b.disableNavigationScrollReset,
            g = f === void 0 ? !1 : f;
        f = b.hiddenWhenDetached;
        f = f === void 0 ? !1 : f;
        var q = b.maintainScrollForContext,
            t = q === void 0 ? !1 : q,
            u = b.onInitialScroll;
        q = b.resetScrollOnMount;
        var v = q === void 0 ? !0 : q;
        q = babelHelpers.objectWithoutPropertiesLoose(b, ["contextKey", "detached", "detachedPageOffsets", "disableNavigationScrollReset", "hiddenWhenDetached", "maintainScrollForContext", "onInitialScroll", "resetScrollOnMount"]);
        var w = k(),
            x = k({
                x: 0,
                y: 0
            }),
            y = c("useStable")(function() {
                return {}
            }),
            z = c("usePrevious")(e);
        b = l(!1);
        var A = b[0],
            B = b[1];
        b = l({
            x: 0,
            y: 0
        });
        var C = b[0],
            D = b[1],
            E = c("usePrevious")(A);
        b = j(c("HiddenSubtreeContext"));
        var F = b.hidden;
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            var a = w.current;
            if (a != null) {
                if (s(a)) {
                    if (p != null) {
                        var b = n.get(p);
                        b && b(!1)
                    }
                    p = a
                } else B(!0);
                n.set(a, function(a) {
                    a || D(babelHelpers["extends"]({}, x.current)), B(!a)
                });
                return function() {
                    n["delete"](a);
                    if (p === a) {
                        p = r();
                        if (p != null) {
                            var b = n.get(p);
                            b && b(!0)
                        }
                    }
                }
            }
        }, []);
        var G = i(function(b, c) {
            a.scrollTo && a.scrollTo(b, c), typeof u === "function" && u(b, c)
        }, [u]);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            (v || E != null) && !A && A !== E && G(C.x, C.y)
        }, [A, C, E, G, v]);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            if ((v || z != null) && e !== z) {
                var a = t && e != null && e in y ? y[e] : {
                    x: 0,
                    y: 0
                };
                A ? D(a) : g !== !0 && G(a.x, a.y)
            }
        }, [e, y, A, t, z, G, v, g]);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            if (!A) {
                var b = function() {
                    var b = a.pageXOffset,
                        c = a.pageYOffset;
                    x.current = {
                        x: b,
                        y: c
                    };
                    e != null && (y[e] = {
                        x: b,
                        y: c
                    })
                };
                window.addEventListener("scroll", b, {
                    passive: !0
                });
                return function() {
                    return window.removeEventListener("scroll", b, {
                        passive: !0
                    })
                }
            }
        }, [A, e, y]);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            var a = w.current;
            if (a != null)
                if (F) {
                    o.add(a);
                    if (!A) {
                        B(!0);
                        p = r();
                        if (p != null) {
                            var b = n.get(p);
                            b && b(!0)
                        }
                    }
                    return function() {
                        o["delete"](a)
                    }
                } else if (A && a !== p && a === r()) {
                if (p != null) {
                    b = n.get(p);
                    b && b(!1)
                }
                p = a;
                b = n.get(p);
                b && b(!0)
            }
        }, [A, F]);
        b = d || A;
        d = f;
        var H = A && !f,
            I = (f = C) != null ? f : C;
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            var a = w.current;
            H && a != null && (a.scrollTop = I.y)
        }, [I.y, H]);
        return h.jsx(c("DocumentScrollViewPageOffsetsContext").Provider, {
            value: x,
            children: h.jsx(c("HiddenSubtreeContextProvider.react"), {
                ignoreParent: !0,
                isBackgrounded: b,
                isHidden: d,
                children: h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, q, {
                    hidden: d
                }, H && {
                    "aria-hidden": !0,
                    id: "scrollview",
                    style: {
                        left: -I.x
                    },
                    xstyle: m.detached
                }, {
                    ref: w
                }))
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g["default"] = b
}), 98);
__d("CometContentWrapperContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        contentWrapperComponent: void 0,
        mainRoutesWrapper: void 0
    });
    g["default"] = b
}), 98);
__d("CometGlobalPanelAnimationStub.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.backgroundColorXStyle,
            d = a.children,
            e = a.testid;
        a = a.xstyle;
        return a != null || b != null || e != null ? h.jsx("div", {
            className: c("stylex")(a, b),
            "data-testid": void 0,
            children: d
        }) : d
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometRootContainer.react", ["cr:1119068", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    c = d("react");
    var i = c.useEffect,
        j = c.useRef;

    function a(a) {
        a = a.children;
        var c = j(null);
        i(function() {
            b("cr:1119068") != null && c.current != null && b("cr:1119068").init(c.current);
            return function() {
                b("cr:1119068") != null && b("cr:1119068").clear()
            }
        }, []);
        return h.jsx("div", {
            className: "x1ja2u2z x1n2onr6 xdt5ytf x78zum5",
            ref: c,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometMainContentWrapper.react", ["BaseDocumentScrollView.react", "BaseViewportMarginsContext", "CometAppNavigationConstants", "CometContentWrapperContext", "CometContextualLayerAnchorRoot.react", "CometGlobalPanelAnimationStub.react", "CometGlobalPanelExpandedContext", "CometGlobalPanelExpandedState", "CometGlobalPanelLayoutContext", "CometPlaceholder.react", "CometRootContainer.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            base: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                position: "x1n2onr6"
            },
            innerHiddenTopNav: {
                minHeight: "xg6iff7",
                top: "x13vifvy"
            },
            innerHiddenTopNavDvh: {
                "@supports (min-height: 100dvh)": {
                    minHeight: "xippug5"
                }
            },
            innerWithTopNav: {
                minHeight: "xat3117",
                top: "xxzkxad"
            },
            innerWithTopNavDvh: {
                "@supports (min-height: 100dvh)": {
                    minHeight: "x4m6w61"
                }
            },
            outerWithExpandedOnLargeScreensGlobalPanel: {
                start: "x90ctcv",
                width: "x1qk6erq",
                "@media (max-width: 1159px)": {
                    start: "xv0u79y",
                    width: "x1yghddv"
                }
            },
            outerWithGlobalPanel: {
                start: "x1uvyrtv",
                width: "x1614rti"
            }
        };

    function a(a) {
        var b = a.children,
            e = a.shouldRenderTopNav,
            f = e === void 0 ? !0 : e;
        e = a.shouldUseDvhMinHeight;
        e = e === void 0 ? !1 : e;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "shouldRenderTopNav", "shouldUseDvhMinHeight"]);
        var g = i(c("CometGlobalPanelLayoutContext")),
            l = i(c("CometGlobalPanelExpandedContext")),
            m = l === d("CometGlobalPanelExpandedState").ExpandedState.Expanding || l === d("CometGlobalPanelExpandedState").ExpandedState.Expanded;
        l = i(c("CometContentWrapperContext"));
        l = l.contentWrapperComponent;
        l = (l = l) != null ? l : c("CometGlobalPanelAnimationStub.react");
        var n = j(function() {
            return {
                bottom: 0,
                left: g ? m ? d("CometAppNavigationConstants").GLOBAL_PANEL_WIDTH_EXPANDED : d("CometAppNavigationConstants").GLOBAL_PANEL_WIDTH : 0,
                right: 0,
                top: f ? d("CometAppNavigationConstants").HEADER_HEIGHT : 0
            }
        }, [g, m, f]);
        return h.jsx(c("BaseDocumentScrollView.react"), babelHelpers["extends"]({}, a, {
            children: h.jsx(c("CometRootContainer.react"), {
                children: h.jsx(c("BaseViewportMarginsContext").Provider, {
                    value: n,
                    children: h.jsx(l, {
                        showOverflow: !0,
                        springConfig: d("CometAppNavigationConstants").GLOBAL_PANEL_EXPAND_SPRING_CONFIG,
                        xstyle: [k.base, g && k.outerWithGlobalPanel, m && k.outerWithExpandedOnLargeScreensGlobalPanel],
                        children: h.jsx("div", {
                            className: c("stylex")(k.base, f ? k.innerWithTopNav : k.innerHiddenTopNav, e ? f ? k.innerWithTopNavDvh : k.innerHiddenTopNavDvh : void 0),
                            children: h.jsx(c("CometContextualLayerAnchorRoot.react"), {
                                children: h.jsx(c("CometPlaceholder.react"), {
                                    fallback: h.jsx("div", {}),
                                    children: b
                                })
                            })
                        })
                    })
                })
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("ContentVisibility", ["ConstUriUtils", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("gkx")("1249968");
    b = c("gkx")("1806005");
    e = null;
    if (a) {
        f = d("ConstUriUtils").getUri(window.location.href);
        c = f == null ? void 0 : f.getQueryParam("force_content_visibility");
        e = c != null ? c === "1" : null
    }
    f = null;
    if (b) {
        c = d("ConstUriUtils").getUri(window.location.href);
        d = c == null ? void 0 : c.getQueryParam("force_tab_content_visibility");
        f = d != null ? d === "1" : null
    }
    d = (c = e) != null ? c : a;
    c = (e = f) != null ? e : b;
    g.CONTENT_VISIBILITY_ENABLED = d;
    g.CONTENT_VISIBILITY_ENABLED_FOR_TABS = c
}), 98);
__d("CometBackupPlaceholder.react", ["react", "useCometPlaceholderImpl"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function a(a) {
        return c("useCometPlaceholderImpl")(babelHelpers["extends"]({}, a, {
            unstable_avoidThisFallback: !0
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAccessibilityAlertProvider.react", ["CometTriggerAccessibilityAlertContext", "react", "useCometAccessibilityAlerts"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.children;
        var b = c("useCometAccessibilityAlerts")(),
            d = b[0];
        b = b[1];
        return h.jsxs(c("CometTriggerAccessibilityAlertContext").Provider, {
            value: b,
            children: [a, d]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSSRMultipassBoundaryUtils", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = "<!--$-->",
        j = "<!--$?-->",
        k = "<!--$!-->",
        l = "<!--/$-->",
        m = new Map(),
        n = new Set();
    a = function(a) {
        n = new Set(a)
    };
    b = function(a) {
        return n.has(a)
    };
    c = function(a) {
        return "ssrb_" + a + "_content"
    };
    var o = function(a) {
            return "ssrb_" + a + "_start"
        },
        p = function(a) {
            return "ssrb_" + a + "_end"
        },
        q = function(a) {
            return '<span id="' + o(a) + '" style="display:none"></span>'
        },
        r = function(a) {
            return '<span id="' + p(a) + '" style="display:none"></span>'
        };
    e = function(a, b) {
        a = q(a);
        var c = a.length;
        a = b.indexOf(a);
        if (a !== -1) {
            if (b.startsWith(i, a + c)) return [a, c + i.length, "hydrate"];
            if (b.startsWith(k, a + c)) return [a, c + k.length, "fallback"];
            if (b.startsWith(j, a + c)) return [a, c + j.length, "fallback"]
        }
        return null
    };
    f = function(a, b) {
        a = l + r(a);
        b = b.indexOf(a);
        return b !== -1 ? [b, a.length] : null
    };
    d = function(a, b) {
        return q(a) + ("" + j + b + l) + r(a)
    };
    var s = function(a) {
            return h.jsx("span", {
                id: o(a),
                style: {
                    display: "none"
                }
            })
        },
        t = function(a) {
            return h.jsx("span", {
                id: p(a),
                style: {
                    display: "none"
                }
            })
        },
        u = function(a) {
            a.forEach(function(a) {
                var b = m.get(a) || null;
                b && b.resolveFunc && typeof b.resolveFunc === "function" && (b.resolveFunc(a), m["delete"](a))
            })
        },
        v = function(a) {
            a = m.get(a);
            return a ? a.promise : null
        },
        w = function(a, b) {
            m.set(a, b)
        };
    g.setEnabledBoundaries = a;
    g.isEnabledBoundary = b;
    g.getBoundarySSRContentID = c;
    g.getBoundaryStartID = o;
    g.getBoundaryEndID = p;
    g.getBoundaryStartOffset = e;
    g.getBoundaryEndOffset = f;
    g.getBoundaryString = d;
    g.getBoundaryStartComponent = s;
    g.getBoundaryEndComponent = t;
    g.tryResolveDisabledBoundaries = u;
    g.tryGetBoundaryPromise = v;
    g.updateDisabledBoundariesMap = w
}), 98);
__d("CometSSRMultipassBoundary.react", ["CometBackupPlaceholder.react", "CometPlaceholder.react", "CometSSRMultipassBoundaryUtils", "CometSSRReactFizzEnvironment", "ExecutionEnvironment", "FBLogger", "Promise", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function j(a) {
        var e = this,
            f = a.children;
        a = a.id;
        if (c("ExecutionEnvironment").canUseDOM) return f;
        if (!d("CometSSRMultipassBoundaryUtils").isEnabledBoundary(a)) {
            if (!d("CometSSRReactFizzEnvironment").isReactFizzEnvironment()) throw new(b("Promise"))(function() {});
            var g = d("CometSSRMultipassBoundaryUtils").tryGetBoundaryPromise(a);
            if (g) throw g;
            g = function() {};
            var h = new(b("Promise"))(function(a) {
                g = a.bind(e)
            });
            d("CometSSRMultipassBoundaryUtils").updateDisabledBoundariesMap(a, {
                promise: h,
                resolveFunc: g
            });
            throw h
        }
        return f
    }
    j.displayName = j.name + " [from " + f.id + "]";

    function k(a) {
        var b = a.children;
        a = a.id;
        d("CometSSRMultipassBoundaryUtils").isEnabledBoundary(a) && c("FBLogger")("comet_ssr").mustfix("SSR boundary suspended unexpectedly: " + a);
        return b
    }
    var l = h.createContext();

    function m(a) {
        var b = a.boundaryId;
        a = a.children;
        var d = i(l);
        if (c("ExecutionEnvironment").canUseDOM) return a;
        if (d && d !== "root") throw c("unrecoverableViolation")("Nested SSR boundaries are unsupported. " + ("Found boundary '" + b + "' nested underneath ") + ("boundary '" + d + "'."), "comet_ssr");
        return h.jsx(l.Provider, {
            value: b,
            children: a
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.children,
            e = a.fallback;
        e = e === void 0 ? null : e;
        var f = a.id;
        a = a.useCometPlaceholder;
        a = a === !0 ? c("CometPlaceholder.react") : c("CometBackupPlaceholder.react");
        return h.jsxs(m, {
            boundaryId: f,
            children: [d("CometSSRMultipassBoundaryUtils").getBoundaryStartComponent(f), h.jsx(a, {
                fallback: h.jsx(k, {
                    id: f,
                    children: e
                }),
                children: h.jsx(j, {
                    id: f,
                    children: h.jsx(h.Fragment, {
                        children: b
                    })
                })
            }), d("CometSSRMultipassBoundaryUtils").getBoundaryEndComponent(f)]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSetKeyCommandWrapperDialogs.react", ["CometKeyCommandContext", "CometKeyCommandSettingsContext", "JSResourceForInteraction", "emptyFunction", "react", "useCometLazyDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useEffect,
        j = c("JSResourceForInteraction")("CometModifiedKeyCommandWrapperDialog.react").__setRef("CometSetKeyCommandWrapperDialogs.react"),
        k = c("JSResourceForInteraction")("CometKeyCommandWrapperDialog.react").__setRef("CometSetKeyCommandWrapperDialogs.react");

    function a() {
        var a, b = h(c("CometKeyCommandSettingsContext"));
        a = (a = h(c("CometKeyCommandContext"))) != null ? a : {};
        var d = a.setShowModifiedKeyCommandWrapperDialogRef,
            e = a.setShowSingleCharacterKeyCommandWrapperDialogRef;
        a = c("useCometLazyDialog")(j);
        var f = a[0];
        a = c("useCometLazyDialog")(k);
        var g = a[0];
        i(function() {
            var a = c("emptyFunction");
            d && (a = d(function(a, d) {
                f({
                    command: a,
                    setModifiedKeyboardShortcutsPreference: b.setModifiedKeyboardShortcutsPreference,
                    singleCharDescription: d
                }, c("emptyFunction"))
            }));
            return a
        }, [d, f, b.setModifiedKeyboardShortcutsPreference]);
        i(function() {
            var a = c("emptyFunction");
            e && (a = e(function(a, d) {
                g({
                    command: a,
                    setAreSingleKeysDisabled: b.setAreSingleKeysDisabled,
                    singleCharDescription: d
                }, c("emptyFunction"))
            }));
            return a
        }, [e, g, b.setAreSingleKeysDisabled]);
        return null
    }
    g["default"] = a
}), 98);
__d("CometTimeSpentEventListener.react", ["CometThrottle", "CometTimeSpentBitArrayLogger", "useGlobalEventListener"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null;

    function j() {
        d("CometTimeSpentBitArrayLogger").updateTimeSpentArray(Date.now())
    }
    var k = c("CometThrottle")(function(a) {
            if (a instanceof MouseEvent) {
                if (/^mouse(enter|leave|move|out|over)$/.test(a.type) && a.pageX === h && a.pageY === i) return;
                h = a.pageX;
                i = a.pageY
            }
            j()
        }, 500, {
            leading: !0,
            trailing: !1
        }),
        l = {
            capture: !0,
            passive: !0
        };

    function a() {
        c("useGlobalEventListener")("click", j, l);
        c("useGlobalEventListener")("focus", j, l);
        c("useGlobalEventListener")("keydown", j, l);
        c("useGlobalEventListener")("mousemove", k, l);
        c("useGlobalEventListener")("scroll", k, l);
        return null
    }
    g["default"] = a
}), 98);
__d("TopLevelKeyCommandListener.react", ["BaseKeyCommandListener.react", "CometGlobalKeyCommandWidget", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("CometGlobalKeyCommandWidget").Wrapper, {
            debugName: "global",
            children: h.jsx(c("BaseKeyCommandListener.react"), {
                observersEnabled: !0,
                children: a.children
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometPlatformAppWrapper.react", ["CometAccessibilityAlertProvider.react", "CometErrorBoundary.react", "CometErrorProjectContext", "CometPlaceholder.react", "CometSSRMultipassBoundary.react", "CometSetKeyCommandWrapperDialogs.react", "CometTimeSpentEventListener.react", "CometTransientDialogProvider.react", "TopLevelKeyCommandListener.react", "cr:1330", "deferredLoadComponent", "hero-tracing-placeholder", "react", "recoverableViolation", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = c("deferredLoadComponent")(c("requireDeferred")("CometUncaughtError.react").__setRef("CometPlatformAppWrapper.react")),
        j = function() {
            return h.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                children: h.jsx(i, {})
            })
        };

    function k(a) {
        a = (a = d("hero-tracing-placeholder").HeroPlaceholderUtils.createThenableDescription(a)) != null ? a : "";
        c("recoverableViolation")("Top level suspense boundary triggered, a component suspended outside of a CometPlaceholder, description: " + a, "comet_infra")
    }

    function a(a) {
        var d = a.KeyboardSettingsStateProvider,
            e = a.children;
        a = a.disableTimeSpentLogging;
        a = a === void 0 ? !1 : a;
        d = (d = (d = d) != null ? d : b("cr:1330")) != null ? d : h.Fragment;
        return h.jsx(c("CometErrorProjectContext").Provider, {
            value: "comet_root",
            children: h.jsx(h.Suspense, {
                fallback: null,
                suspenseCallback: k,
                children: h.jsx(c("CometErrorBoundary.react"), {
                    context: {
                        project: "comet_platform_root_boundary"
                    },
                    fallback: j,
                    children: h.jsxs(c("CometSSRMultipassBoundary.react"), {
                        fallback: null,
                        id: "root",
                        children: [h.jsx(d, {
                            children: h.jsx(c("TopLevelKeyCommandListener.react"), {
                                children: h.jsxs(c("CometTransientDialogProvider.react"), {
                                    children: [h.jsx(c("CometAccessibilityAlertProvider.react"), {
                                        children: e
                                    }), h.jsx(c("CometSetKeyCommandWrapperDialogs.react"), {})]
                                })
                            })
                        }), a !== !0 && h.jsx(c("CometTimeSpentEventListener.react"), {})]
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometPreloaderInit", ["RelayAPIConfig", "RelayPrefetchedStreamCache"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a && a.length)
            for (var a = a, b = Array.isArray(a), e = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (b) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                d("RelayPrefetchedStreamCache").registerPreloader(f.preloaderID, f.queryID, f.variables, (f = f.actorID) != null ? f : c("RelayAPIConfig").actorID)
            }
    }
    g.initPreloaders = a
}), 98);
__d("CometResourceScheduler", ["Bootloader", "ErrorGuard"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Set(),
        i = new Set(),
        j = [];

    function a(a) {
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            i.has(d) || (i.add(d), b.push(d))
        }
        b.length && k(b)
    }

    function b(a) {
        j.push(a), h.size === 0 && l()
    }

    function k(a) {
        a.forEach(function(a) {
            return h.add(a)
        }), c("Bootloader").loadResources(a, {
            onAll: function() {
                a.forEach(function(a) {
                    return h["delete"](a)
                });
                if (h.size) return;
                l()
            }
        })
    }

    function l() {
        var a = j;
        j = [];
        a.forEach(function(a) {
            return c("ErrorGuard").applyWithGuard(a, null, [])
        })
    }
    g.registerHighPriHashes = a;
    g.onHighPriComplete = b
}), 98);
__d("cometFBBaseCSS", ["cx", "cr:2011", "cr:4165"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    b("cr:2011"), b("cr:4165")
}), 34);
__d("CometClientConsistency", ["fbt", "ix", "BaseToasterStateManager", "ClientConsistency", "ClientConsistencyEventEmitter", "CometErrorOverlay", "CometExceptionDialog.react", "CometTimeSpentNavigation", "OutsideExceptionKeyCommandListener.react", "TetraIcon.react", "cometPushToast", "fbicon", "gkx", "react", "requireDeferred"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");
    a = d("react");
    var k = a.useEffect,
        l = a.useRef,
        m = c("requireDeferred")("ClientConsistencyFalcoEvent").__setRef("CometClientConsistency"),
        n = c("BaseToasterStateManager").getInstance(),
        o = !1,
        p = null,
        q = null,
        r = function(a) {
            m.onReady(function(b) {
                b.log(function() {
                    var b;
                    return babelHelpers["extends"]({
                        revs: Array.from(c("ClientConsistency").getAdditionalRevisions()).map(function(a) {
                            return a.toString()
                        }),
                        trace_policy: (b = c("CometTimeSpentNavigation").getPathInfo()) == null ? void 0 : b.name
                    }, a)
                })
            })
        },
        s = function(a) {
            return (a != null ? Date.now() - a : -1).toString()
        },
        t = function() {
            k(function() {
                q = Date.now(), r({
                    action: 2,
                    event: "impression"
                })
            }, []);
            return j.jsx(c("TetraIcon.react"), {
                color: "warning",
                icon: d("fbicon")._(i("502062"), 20)
            })
        },
        u = function() {
            var a = l(null);
            k(function() {
                a.current = Date.now(), r({
                    action: 3,
                    event: "impression"
                })
            }, []);
            return j.jsx(c("OutsideExceptionKeyCommandListener.react"), {
                children: j.jsx(c("CometExceptionDialog.react"), {
                    closeButtonText: h._("Refresh"),
                    errorDescription: h._("The page you're on is out of date. To continue using Facebook, refresh your browser."),
                    errorSummary: h._("Refresh Your Browser"),
                    onClose: function() {
                        r({
                            action: 3,
                            duration: s(a.current),
                            event: "click"
                        }), o = !1, a.current = null, window.location.reload(!0)
                    },
                    withCloseButton: !1
                })
            })
        },
        v = function() {
            if (o) return;
            if (p != null) return;
            p = d("cometPushToast").cometPushToast({
                action: {
                    label: h._("Refresh"),
                    onPress: function() {
                        r({
                            action: 2,
                            duration: s(q),
                            event: "click"
                        }), p = null, q = null, window.location.reload(!0)
                    }
                },
                icon: j.jsx(t, {}),
                message: h._("The page you're on is out of date. Please refresh your browser."),
                supressCloseButton: !0
            }, Infinity);
            n.stopTimer(p)
        },
        w = function() {
            if (o) return;
            p && n["delete"](p);
            o = !0;
            d("CometErrorOverlay").injectComponent(function(a) {
                return j.jsx(u, {})
            })
        },
        x = !1;
    b = {
        init: function() {
            if (x) return;
            if (!c("gkx")("1661552")) return;
            c("ClientConsistency").init();
            c("ClientConsistencyEventEmitter").addListener("softRefresh", v);
            c("ClientConsistencyEventEmitter").addListener("hardRefresh", w);
            x = !0
        },
        logRefreshOnNav: function() {
            r({
                action: 1,
                event: "impression"
            })
        }
    };
    e = b;
    g["default"] = e
}), 98);
__d("QuickMarkersSrcFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1836368");
    c = b("FalcoLoggerInternal").create("quick_markers_src", a);
    e.exports = c
}), null);
__d("QuickMarkersComet", ["QuickMarkersConfig", "QuickMarkersSrcFalcoEvent", "performanceNow"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        h("ClientInit")
    }

    function h(a) {
        if (c("QuickMarkersConfig").pageLoadEventId == null || c("QuickMarkersConfig").sampleWeight == null) return;
        var b = {
            event_id: c("QuickMarkersConfig").pageLoadEventId,
            marker_id: a,
            marker_page_time: c("performanceNow")(),
            script_path: c("QuickMarkersConfig").pageLoadScriptPath,
            weight: c("QuickMarkersConfig").sampleWeight
        };
        c("QuickMarkersSrcFalcoEvent").logImmediately(function() {
            return b
        })
    }
    g.init = a;
    g.mark = h
}), 98);
__d("CometErrorSystem", ["QuickMarkersComet", "cr:1267207", "cr:4345", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("CometErrorLogging").__setRef("CometErrorSystem");

    function a(a) {
        h.onReady(function(b) {
            return b.init(a)
        }), b("cr:4345") && b("cr:4345").init(), b("cr:1267207") && b("cr:1267207")(), d("QuickMarkersComet").init()
    }
    g.init = a
}), 98);
__d("CometPixelRatioDetector", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("CometPixelRatioUpdater").__setRef("CometPixelRatioDetector");

    function a() {
        h.onReady(function(a) {
            return a.startDetecting()
        })
    }
    g.initDetecting = a
}), 98);
__d("WebTimeSpentNavigationFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1829321");
    c = b("FalcoLoggerInternal").create("web_time_spent_navigation", a);
    e.exports = c
}), null);
__d("CometTimeSpentNavigationLogger", ["Banzai", "CometTimeSpentNavigation", "ConstUriUtils", "Env", "WebSession", "WebTimeSpentNavigationFalcoEvent", "isInIframe"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = !1;

    function i(a) {
        c("WebTimeSpentNavigationFalcoEvent").logImmediately(function() {
            return {
                cause: a.cause,
                custom_data_json: JSON.stringify(a.extra_data),
                dest_path: a.dest_path,
                sid_raw: a.sid_raw,
                source_path: a.source_path
            }
        })
    }

    function j(a, b, e) {
        d("WebSession").extend();
        if (!h || c("isInIframe")()) return;
        var f = {
            cause: e,
            extra_data: {},
            sid_raw: d("WebSession").getId()
        };
        a && (f.source_path = a.name, Object.entries(a.extraData).forEach(function(a) {
            var b = a[0];
            a = a[1];
            return f.extra_data["source_" + b] = a
        }));
        b && (f.dest_path = b.name, Object.entries(b.extraData).forEach(function(a) {
            var b = a[0];
            a = a[1];
            return f.extra_data["dest_" + b] = a
        }));
        c("Env").isCometOnMobile === !0 && (f.extra_data.comet_on_mobile = "1");
        i(f)
    }

    function k() {
        var a = c("CometTimeSpentNavigation").getPathInfo();
        if (!a) return;
        a = babelHelpers["extends"]({}, a, {
            extraData: babelHelpers["extends"]({}, a.extraData, {
                referrer: document.referrer,
                subdomain: (a = d("ConstUriUtils").getUri(document.location.href)) == null ? void 0 : a.subdomain
            })
        });
        j(c("CometTimeSpentNavigation").getSourcePathInfo(), a, "load")
    }

    function l() {
        j(c("CometTimeSpentNavigation").getPathInfo(), null, "unload"), h = !1
    }

    function m(a, b) {
        j(a, b, "transition")
    }

    function n(a) {
        var b = a.sourcePathInfo;
        a = a.destPathInfo;
        if (!h || !b || !a) return;
        m(b, a)
    }

    function a(a, b, d) {
        b === void 0 && (b = null), h = !0, c("CometTimeSpentNavigation").changePath(a, d, b), k(), c("CometTimeSpentNavigation").listenToPathChange(n), c("Banzai").subscribe(c("Banzai").SHUTDOWN, l)
    }
    g.init = a
}), 98);
__d("initCometPlatformWebPage", ["CometClientConsistency", "CometErrorSystem", "CometPixelRatioDetector", "CometTimeSpentBitArrayLogger", "CometTimeSpentNavigationLogger", "CometVisitationManager", "HostnameRewriter", "WebPerformanceDeviceInfo", "cr:11192", "cr:1132918", "cr:2654", "cr:866", "cr:869493", "cr:9876", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("CometBrowserDimensionsLogger").__setRef("initCometPlatformWebPage"),
        i = c("requireDeferred")("FalcoLoggerTransports").__setRef("initCometPlatformWebPage");

    function a(a, e, f) {
        var g = e.disableTimeSpentLogging,
            j = e.productAttribution,
            k = e.timeSpentMetadata;
        e = e.timeSpentRoute;
        d("CometErrorSystem").init(a);
        if (!((a = f == null ? void 0 : f.disableDevTools) != null ? a : !1)) {
            b("cr:2654") && b("cr:2654").init({
                connectFromIFrame: (a = f == null ? void 0 : f.connectFromIFrame) != null ? a : !1
            })
        }
        b("cr:9876") && b("cr:9876")();
        b("cr:869493") && b("cr:869493").init();
        d("WebPerformanceDeviceInfo").initWebDevicePerfLoggingPassive();
        h.onReady(function(a) {
            return a.init()
        });
        c("CometClientConsistency").init();
        d("CometPixelRatioDetector").initDetecting();
        g !== !0 && (d("CometVisitationManager").init(e.tracePolicy), d("CometTimeSpentNavigationLogger").init(e, k, j), d("CometTimeSpentBitArrayLogger").init(e.tracePolicy));
        b("cr:866") && b("cr:866")();
        b("cr:1132918") && b("cr:1132918").handleServerErrors();
        i.onReady(function(a) {
            return a.attach()
        });
        b("cr:11192") && b("cr:11192").init();
        d("HostnameRewriter").maybeRegisterFilters()
    }
    g["default"] = a
}), 98);
__d("CometLoggedInTargetedTabsListWithIcons", ["CometIconControllerGaming.react", "CometIconControllerGamingFilled.react", "CometIconEvents.react", "CometIconEventsFilled.react", "CometIconFeed.react", "CometIconFeedFilled.react", "CometIconFriends.react", "CometIconFriendsFilled.react", "CometIconGaming.react", "CometIconGamingFilled.react", "CometIconGroups.react", "CometIconGroupsFilled.react", "CometIconMarketplace.react", "CometIconMarketplaceFilled.react", "CometIconMegaphone.react", "CometIconMegaphoneFilled.react", "CometIconMoreFilled.react", "CometIconNews.react", "CometIconNewsClock.react", "CometIconNewsClockFilled.react", "CometIconNewsFilled.react", "CometIconPages.react", "CometIconPagesFilled.react", "CometIconProfessionalDashboard.react", "CometIconProfessionalDashboardFilled.react", "CometIconWatch.react", "CometIconWatchFilled.react", "CometLoggedInTargetedTabsList", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    a = "4748854339";
    b = "1606854132932955";
    d = "2392950137";
    e = "2361831622";
    f = "2356318349";
    var i = "250100865708545",
        j = "192618159033122",
        k = "513746992167374",
        l = "2344061033",
        m = "2166827706737654",
        n = "608920319153834",
        o = "1146105192114219",
        p = (h = {}, h[o] = {
            activeIcon: c("CometIconMegaphoneFilled.react"),
            icon: c("CometIconMegaphone.react")
        }, h[m] = {
            activeIcon: c("CometIconNewsFilled.react"),
            icon: c("CometIconNews.react")
        }, h[l] = {
            activeIcon: c("CometIconEventsFilled.react"),
            icon: c("CometIconEvents.react")
        }, h[f] = {
            activeIcon: c("CometIconFriendsFilled.react"),
            icon: c("CometIconFriends.react")
        }, h[k] = {
            activeIcon: c("qex")._("1811") === !0 ? c("CometIconControllerGamingFilled.react") : c("CometIconGamingFilled.react"),
            icon: c("qex")._("1811") === !0 ? c("CometIconControllerGaming.react") : c("CometIconGaming.react")
        }, h[e] = {
            activeIcon: c("CometIconGroupsFilled.react"),
            icon: c("CometIconGroups.react")
        }, h[b] = {
            activeIcon: c("CometIconMarketplaceFilled.react"),
            icon: c("CometIconMarketplace.react")
        }, h.More = {
            activeIcon: c("CometIconMoreFilled.react"),
            icon: c("CometIconMoreFilled.react")
        }, h[n] = {
            activeIcon: c("CometIconNewsClockFilled.react"),
            icon: c("CometIconNewsClock.react")
        }, h[a] = {
            activeIcon: c("CometIconFeedFilled.react"),
            icon: c("CometIconFeed.react")
        }, h[i] = {
            activeIcon: c("CometIconPagesFilled.react"),
            icon: c("CometIconPages.react")
        }, h[j] = {
            activeIcon: c("CometIconProfessionalDashboardFilled.react"),
            icon: c("CometIconProfessionalDashboard.react")
        }, h[d] = {
            activeIcon: c("CometIconWatchFilled.react"),
            icon: c("CometIconWatch.react")
        }, h),
        q = new Map([]);
    c("CometLoggedInTargetedTabsList").forEach(function(a, b) {
        q.set(b, a);
        if (p[b] != null) {
            a = babelHelpers["extends"]({}, q.get(b), p[b]);
            q.set(b, a)
        }
    });
    o = q;
    g["default"] = o
}), 98);
__d("CometLazyToasterView_DO_NOT_USE.react", ["CometPlaceholder.react", "deferredLoadComponent", "react", "requireDeferred", "useToasterStateManager"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useState;
    e = c("requireDeferred")("CometToasterView_DO_NOT_USE.react").__setRef("CometLazyToasterView_DO_NOT_USE.react");
    var k = c("deferredLoadComponent")(e);

    function l(a) {
        a = a.getState();
        return Object.keys(a).length > 0
    }

    function a(a) {
        var b = c("useToasterStateManager")(),
            d = j(function() {
                return l(b)
            }),
            e = d[0],
            f = d[1];
        i(function() {
            if (e) return;
            var a = l(b);
            if (a) {
                f(!0);
                return
            }
            var c = b.addListener(function() {
                c.remove(), f(!0)
            });
            return c.remove
        }, [b, e]);
        return e ? h.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            children: h.jsx(k, babelHelpers["extends"]({
                loadImmediately: !0
            }, a))
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometToasterRoot.react", ["CometErrorBoundary.react", "CometLazyToasterView_DO_NOT_USE.react", "react", "recoverableViolation", "useHideNotificationsToasts"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo,
        j = new Set(["CometToastNotification"]);

    function k(a) {
        c("recoverableViolation")("The toaster is broken", "CometAppShell", {
            error: a
        })
    }

    function a(a) {
        var b = a.align,
            d = a.maxWidth,
            e = c("useHideNotificationsToasts")();
        return i(function() {
            return h.jsx(c("CometErrorBoundary.react"), {
                onError: k,
                children: h.jsx(c("CometLazyToasterView_DO_NOT_USE.react"), {
                    align: b,
                    filterToasts: e === !0 ? j : null,
                    maxWidth: d
                })
            })
        }, [b, e, d])
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometCalloutNUX", ["react", "useCometCallout", "useCometNUXInlineSurvey", "useMergeRefs", "useNUX", "useRefEffect"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useMemo,
        j = {
            arrowStyle: "inset",
            hasCloseButton: !0,
            type: "accent"
        };

    function a(a, b, d) {
        d === void 0 && (d = !0);
        var e = b.onClose,
            f = b.onHelpful,
            g = b.onHide,
            k = b.onNotHelpful,
            l = b.onShow;
        a = c("useNUX")(a, d);
        d = a[0];
        var m = a[1],
            n = h(function() {
                m.onDismiss(), e && e()
            }, [m, e]),
            o = h(function() {
                m.onRemoved(), m.onHidden(), g && g()
            }, [m, g]),
            p = h(function() {
                m.onVisible(), l && l()
            }, [m, l]),
            q = h(function() {
                m.onHelpful(), f && f()
            }, [m, f]),
            r = h(function() {
                m.onNotHelpful(), k && k()
            }, [m, k]),
            s = c("useCometNUXInlineSurvey")();
        a = c("useRefEffect")(function(a) {
            var b = function() {
                m.onDismiss()
            };
            a.addEventListener("click", b, {
                passive: !0
            });
            return function() {
                return a.removeEventListener("click", b, {
                    passive: !0
                })
            }
        }, [m]);
        d = c("useCometCallout")(i(function() {
            return babelHelpers["extends"]({}, j, b, {
                inlineSurvey: s,
                onClose: n,
                onHelpful: q,
                onHide: o,
                onNotHelpful: r,
                onShow: p
            })
        }, [b, s, n, q, o, r, p]), d);
        return c("useMergeRefs")(d, a)
    }
    g["default"] = a
}), 98);
__d("NullState404FailedLoadingFB", ["IconSource", "bx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        dark: new(c("IconSource"))("nullStateGlyphs", c("bx").getURL(c("bx")("1160057")), 112),
        "default": new(c("IconSource"))("nullStateGlyphs", c("bx").getURL(c("bx")("1160058")), 112)
    };
    g["default"] = a
}), 98);
__d("NullStateGeneralFB", ["IconSource", "bx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        dark: new(c("IconSource"))("nullStateGlyphs", c("bx").getURL(c("bx")("1160060")), 112),
        "default": new(c("IconSource"))("nullStateGlyphs", c("bx").getURL(c("bx")("1160061")), 112)
    };
    g["default"] = a
}), 98);
__d("NullStatePermissionsFB", ["IconSource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        dark: new(c("IconSource"))("nullStateGlyphs", "/images/comet/empty_states_icons/permissions/permissions_dark_mode.svg", 112),
        "default": new(c("IconSource"))("nullStateGlyphs", "/images/comet/empty_states_icons/permissions/permissions_gray_wash.svg", 112)
    };
    g["default"] = a
}), 98);
__d("CometScrollAnchorContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("BaseCometModal.react", ["BaseContextualLayerAnchorRoot.react", "BaseDocumentScrollView.react", "BaseHeadingContext", "BasePortal.react", "CometHeroInteractionContextPassthrough.react", "CometHeroInteractionWithDiv.react", "CometLayerKeyCommandWrapper.react", "FocusRegion.react", "HiddenSubtreeContext", "cr:1024", "cr:1829844", "focusScopeQueries", "getGeoAndCometModalCompatible", "react", "stylex", "useCometVisualChangeTracker", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            content: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                minHeight: "xg6iff7",
                position: "x1n2onr6"
            },
            contentDvh: {
                "@supports (min-height: 100dvh)": {
                    minHeight: "xippug5"
                }
            },
            hidden: {
                visibility: "xlshs6z"
            },
            mask: {
                bottom: "x1ey2m1c",
                end: "xds687c",
                position: "xixxii4",
                start: "x17qophe",
                top: "x13vifvy"
            },
            maskOverlay: {
                backgroundColor: "x1h0vfkc"
            },
            root: {
                position: "x1n2onr6"
            },
            rootStatic: {
                position: "x1uhb9sk"
            }
        },
        k = {
            "above-everything": {
                zIndex: "x1vjfegm"
            },
            "above-nav": {
                zIndex: "xzkaem6"
            },
            normal: {
                zIndex: "x1ja2u2z"
            }
        };

    function a(a) {
        var e = a.blockKeyCommands;
        e = e === void 0 ? !1 : e;
        var f = a.children,
            g = a.contextKey,
            l = a.hidden;
        l = l === void 0 ? !1 : l;
        var m = a.interactionDesc,
            n = a.interactionUUID,
            o = a.isOverlayTransparent;
        o = o === void 0 ? !1 : o;
        var p = a.shouldUseDvhMinHeight;
        p = p === void 0 ? !1 : p;
        a = a.stackingBehavior;
        a = a === void 0 ? "auto" : a;
        var q = i(c("HiddenSubtreeContext"));
        q = q.hidden;
        var r = c("useStable")(function() {
                return n !== void 0
            }),
            s = c("useCometVisualChangeTracker")();
        o = h.jsxs(h.Fragment, {
            children: [h.jsx("div", {
                className: c("stylex")(j.mask, !o && j.maskOverlay)
            }), h.jsx(c("BaseContextualLayerAnchorRoot.react"), {
                children: h.jsx(d("FocusRegion.react").FocusRegion, {
                    autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
                    autoRestoreFocus: !0,
                    containFocusQuery: d("focusScopeQueries").tabbableScopeQuery,
                    recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
                    children: e ? f : h.jsx(c("CometLayerKeyCommandWrapper.react"), {
                        debugName: "modal layer",
                        children: f
                    })
                })
            })]
        });
        b("cr:1829844") != null && (o = h.jsx(b("cr:1829844"), {
            name: "modal",
            children: o
        }));
        e = q ? "normal" : a;
        return h.jsx(c("BasePortal.react"), {
            hidden: q,
            xstyle: [e === "auto" ? j.rootStatic : j.root, l && j.hidden, e !== "auto" && (b("cr:1024") != null && c("getGeoAndCometModalCompatible")() ? b("cr:1024")[e] : k[e])],
            children: h.jsx(c("BaseDocumentScrollView.react"), {
                contextKey: g,
                hiddenWhenDetached: l,
                children: h.jsx(c("BaseHeadingContext").Provider, {
                    value: 1,
                    children: r ? h.jsx(c("CometHeroInteractionContextPassthrough.react"), {
                        clear: !0,
                        children: h.jsx(c("CometHeroInteractionWithDiv.react"), {
                            interactionDesc: m,
                            interactionUUID: n,
                            ref: s,
                            xstyle: [j.content, p && j.contentDvh],
                            children: o
                        })
                    }) : h.jsx("div", {
                        className: c("stylex")(j.content, p && j.contentDvh),
                        ref: s,
                        children: o
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometScrollAnchor", ["BaseDOMContainer.react", "BaseViewportMarginsContext", "CometScrollAnchorContext", "ExecutionEnvironment", "HiddenSubtreePassiveContext", "react", "recoverableViolation", "scrollTo"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    d = e.createContext;
    var i = e.useContext,
        j = e.useEffect,
        k = e.useMemo,
        l = e.useRef,
        m = e.useState,
        n = 16,
        o = d(null);

    function a(a, b, d) {
        d = (d = d) != null ? d : {};
        var e = d.verticalAlign,
            f = e === void 0 ? "top" : e,
            g = babelHelpers.objectWithoutPropertiesLoose(d, ["verticalAlign"]),
            h = l(null),
            p = i(c("CometScrollAnchorContext")),
            q = k(function() {
                return b !== null && a === (p == null ? void 0 : p.key) && b === (p == null ? void 0 : p.value)
            }, [a, p == null ? void 0 : p.key, p == null ? void 0 : p.value, b]),
            r = i(c("HiddenSubtreePassiveContext"));
        e = m(!r.getCurrentState().hiddenOrBackgrounded);
        var s = e[0],
            t = e[1],
            u = i(c("BaseViewportMarginsContext")),
            v = l(null),
            w = i(o),
            x = function() {
                var a = h.current;
                if (a != null) {
                    var b = document.documentElement;
                    if (b == null) {
                        c("recoverableViolation")("There is no documentElement accessible on document", "comet_ui");
                        return
                    }
                    b = b.clientHeight;
                    a = a.getBoundingClientRect();
                    var d = 0;
                    switch (f) {
                        case "top":
                            d = a.top - n - u.top;
                            break;
                        case "center":
                            d = a.top - u.top - (b - u.top - u.bottom) / 2 + a.height / 2;
                            break;
                        case "bottom":
                            d = a.bottom - b + n + u.bottom;
                            break
                    }
                    a = window.pageYOffset + d;
                    b = document.body;
                    d = (d = w) != null ? d : b;
                    if ((p == null ? void 0 : p.disableScrollFixer) !== !0 && b != null && d != null && b.scrollHeight < a + window.innerHeight) {
                        var e = v.current = document.createElement("div");
                        e.className = "x8knxv4 x1i1rx1s x1n2onr6";
                        e.style.marginTop = "-" + (b.scrollHeight - a) + "px";
                        e.style.height = window.innerHeight + "px";
                        d.appendChild(e)
                    }
                    c("scrollTo")(babelHelpers["extends"]({}, g, {
                        top: a
                    }))
                }
            },
            y = l(x);
        j(function() {
            y.current = x
        });
        j(function() {
            if (q)
                if (s) {
                    y.current();
                    return function() {
                        var a = v.current;
                        a != null && a.parentNode != null && (a.parentNode.removeChild(a), v.current = null)
                    }
                } else {
                    var a = r.subscribeToChanges(function(a) {
                        a = a.hiddenOrBackgrounded;
                        return t(!a)
                    });
                    return function() {
                        return a.remove()
                    }
                }
        }, [r, q, s]);
        return h
    }

    function b(a) {
        a = a.children;
        var b = k(function() {
            return c("ExecutionEnvironment").canUseDOM ? document.createElement("div") : null
        }, []);
        return h.jsxs(h.Fragment, {
            children: [h.jsx(o.Provider, {
                value: b,
                children: a
            }), h.jsx(c("BaseDOMContainer.react"), {
                node: b
            })]
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g.useCometScrollAnchor = a;
    g.CometScrollFixerRoot = b
}), 98);
__d("useCometAriaID", ["react", "useCometUniqueID", "useSetAttributeRef"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;

    function a(a) {
        var b = c("useCometUniqueID")(),
            d = c("useSetAttributeRef")("id", b),
            e = c("useSetAttributeRef")(a, b);
        return h(function() {
            var c;
            return [
                [{
                    id: b,
                    suppressHydrationWarning: !0
                }, d],
                [(c = {}, c[a] = b, c.suppressHydrationWarning = !0, c), e]
            ]
        }, [a, b, d, e])
    }
    g["default"] = a
}), 98);
__d("CometRelayEnvironmentProvider", ["CometRelay", "CometRelayEnvironment", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(d("CometRelay").RelayEnvironmentProvider, {
            environment: a.environment || c("CometRelayEnvironment"),
            children: a.children
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("SecuredActionChallengePasswordDialog.entrypoint", ["JSResourceForInteraction", "SecuredActionChallengePasswordDialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function() {
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionChallengePasswordDialogQuery$Parameters"),
                        variables: {
                            height: 60,
                            scale: 1,
                            width: 60
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionChallengePasswordDialog.react").__setRef("SecuredActionChallengePasswordDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionChallengeSSODialog.entrypoint", ["JSResourceForInteraction", "SecuredActionChallengeSSODialogQuery$Parameters"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            a = a.return_uri;
            return {
                queries: {
                    query: {
                        options: {
                            fetchPolicy: "store-and-network"
                        },
                        parameters: c("SecuredActionChallengeSSODialogQuery$Parameters"),
                        variables: {
                            height: 60,
                            return_uri: a,
                            scale: 1,
                            width: 60
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("SecuredActionChallengeSSODialog.react").__setRef("SecuredActionChallengeSSODialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("SecuredActionUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "Re-authentication canceled.";

    function a(a) {
        return (a == null ? void 0 : a.message) === g
    }
    f.SECURED_ACTION_REAUTH_CANCELED_ERROR = g;
    f.isSecuredActionError = a
}), 66);
__d("handleCometReauthenticationSideEffects", ["errorCode", "CometErrorOverlay", "CometRelayEnvironmentProvider", "CometRouteURL", "CometTransientDialogProvider.react", "JSResourceForInteraction", "OutsideExceptionKeyCommandListener.react", "SecuredActionChallengePasswordDialog.entrypoint", "SecuredActionChallengeSSODialog.entrypoint", "SecuredActionUtils", "err", "gkx", "react", "useCometEntryPointDialog", "useCometLazyDialog"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = d("react").useEffect,
        k = new Set(),
        l = new Set(),
        m = c("JSResourceForInteraction")("WorkSSOReauthDialog.react").__setRef("handleCometReauthenticationSideEffects");

    function a(a, b, d) {
        var e;
        a = a == null ? void 0 : a.source;
        e = (e = (e = a == null ? void 0 : a.errorCode) != null ? e : a == null ? void 0 : a.code) != null ? e : a == null ? void 0 : a.error;
        if (c("gkx")("5606") && e === 1357001) {
            k.has(e) || (k.add(e), n(e));
            return !0
        }
        if (e === 2136001) {
            l.add({
                onError: d,
                onSuccess: b
            });
            k.has(e) || (k.add(e), o(e, a == null ? void 0 : a.description));
            return !0
        }
        return !1
    }

    function n(a) {
        d("CometErrorOverlay").injectComponent(function(b) {
            function d() {
                var d = c("useCometLazyDialog")(m),
                    e = d[0],
                    f = function() {
                        k["delete"](a), b()
                    };
                j(function() {
                    e({
                        onSuccess: function() {
                            f()
                        }
                    })
                }, [e]);
                return null
            }
            return i.jsx(c("CometRelayEnvironmentProvider"), {
                children: i.jsx(c("OutsideExceptionKeyCommandListener.react"), {
                    children: i.jsx(c("CometTransientDialogProvider.react"), {
                        children: i.jsx(d, {})
                    })
                })
            })
        })
    }

    function o(a, b) {
        d("CometErrorOverlay").injectComponent(function(e) {
            function f() {
                var f = null;
                switch (b) {
                    case "work_sso":
                        f = c("SecuredActionChallengeSSODialog.entrypoint");
                        break;
                    case "password":
                    default:
                        f = c("SecuredActionChallengePasswordDialog.entrypoint");
                        break
                }
                var g = d("CometRouteURL").useRouteURL();
                f = c("useCometEntryPointDialog")(f, {
                    return_uri: g
                });
                var h = f[0],
                    i = function() {
                        k["delete"](a), l.clear(), e()
                    };
                j(function() {
                    h({
                        onExit: function() {
                            for (var a = l, b = Array.isArray(a), e = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                var f;
                                if (b) {
                                    if (e >= a.length) break;
                                    f = a[e++]
                                } else {
                                    e = a.next();
                                    if (e.done) break;
                                    f = e.value
                                }
                                f = f;
                                f = f.onError;
                                var g = c("err")(d("SecuredActionUtils").SECURED_ACTION_REAUTH_CANCELED_ERROR);
                                g.type = "info";
                                f(g)
                            }
                            i()
                        },
                        onSuccess: function() {
                            for (var a = l, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                var d;
                                if (b) {
                                    if (c >= a.length) break;
                                    d = a[c++]
                                } else {
                                    c = a.next();
                                    if (c.done) break;
                                    d = c.value
                                }
                                d = d;
                                d = d.onSuccess;
                                d()
                            }
                            i()
                        }
                    })
                });
                return null
            }
            return i.jsx(c("CometRelayEnvironmentProvider"), {
                children: i.jsx(c("OutsideExceptionKeyCommandListener.react"), {
                    children: i.jsx(c("CometTransientDialogProvider.react"), {
                        children: i.jsx(f, {})
                    })
                })
            })
        })
    }
    g["default"] = a
}), 98);
__d("InlineFbtResultImplComet", ["FbtHooks", "FbtReactUtil", "FbtResultBase", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function i(a) {
        var b = a.content,
            d = a.hash,
            e = a.inlineMode;
        a = a.translation;
        d == null && c("recoverableViolation")('Fbt string hash should not be null for translated string "' + a + '" ' + ("[inlineMode=" + e + "]"), "internationalization");
        return h.jsx("span", {
            "data-intl-hash": d,
            "data-intl-translation": a,
            "data-intl-trid": "",
            children: b
        })
    }
    i.displayName = i.name + " [from " + f.id + "]";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, e, f, g) {
            var h;
            h = a.call(this, b, c("FbtHooks").getErrorListener({
                hash: g,
                translation: f
            })) || this;
            h.$$typeof = d("FbtReactUtil").REACT_ELEMENT_TYPE;
            h.key = null;
            h.ref = null;
            h.type = i;
            h.props = {
                content: b,
                hash: g,
                inlineMode: e,
                translation: f
            };
            return h
        }
        return b
    }(c("FbtResultBase"));
    g["default"] = a
}), 98);
__d("BanzaiAdapterComet", ["BanzaiConfig", "BanzaiConsts", "BanzaiStorage", "BaseEventEmitter", "FBLogger", "JSScheduler", "NetworkStatus", "QueryString", "ReactDOMComet", "Run", "SiteData", "StaticSiteData", "URI", "UserAgent", "ZeroRewrites", "getAsyncParams", "gkx", "isInIframe", "justknobx", "lowerFacebookDomain", "once", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = [],
        i = new(c("BaseEventEmitter"))(),
        j = c("isInIframe")(),
        k = "/ajax/bz",
        l = "POST",
        m = {
            cleanup: function() {
                var a = h;
                h = [];
                a.forEach(function(a) {
                    a.readyState < 4 && a.abort()
                })
            },
            config: c("BanzaiConfig"),
            getEndPointUrl: function(a) {
                a = c("getAsyncParams")(l);
                delete a[c("StaticSiteData").csr_key];
                delete a[c("StaticSiteData").jsmod_key];
                a.ph = c("SiteData").push_phase;
                var b = c("justknobx")._("55") && c("gkx")("517") ? "/a/bz" : c("gkx")("1703425") ? "/ajax/bnzai" : k;
                b = c("QueryString").appendToUrl(b, a);
                if (b.length > 2e3) throw c("unrecoverableViolation")("url is too long: ${url}", "comet_infra");
                return b
            },
            getStorage: function() {
                return c("BanzaiStorage")
            },
            getTopLevel: function() {
                return j && c("lowerFacebookDomain").isValidDocumentDomain() ? window.top : null
            },
            inform: function(a) {
                Array.isArray(a) ? a.forEach(function(a) {
                    return i.emit(a)
                }) : i.emit(a)
            },
            isOkToSendViaBeacon: function() {
                return !1
            },
            onUnload: function(a) {
                d("Run").onAfterUnload(a)
            },
            preferredCompressionMethod: c("once")(function() {
                return "deflate"
            }),
            readyToSend: function() {
                return c("UserAgent").isBrowser("IE <= 8") || navigator.onLine
            },
            send: function(a, b, e, f) {
                var g, i = m.getEndPointUrl(!1);
                i = c("ZeroRewrites").rewriteURI(new(c("URI"))(i));
                var j = c("ZeroRewrites").getTransportBuilderForURI(i)();
                j.open(l, i.toString(), !0);
                f === !0 ? j.onreadystatechange = function() {
                    d("ReactDOMComet").flushSync(function() {
                        if (j.readyState >= 4) {
                            var a = h.indexOf(j);
                            a >= 0 && h.splice(a, 1);
                            try {
                                a = j.status
                            } catch (b) {
                                a = 0
                            }
                            a === 200 ? (b && b(), c("NetworkStatus").reportSuccess()) : (e && e(a), c("NetworkStatus").reportError())
                        }
                    })
                } : j.onreadystatechange = function() {
                    c("JSScheduler").scheduleNormalPriCallback(function() {
                        if (j.readyState >= 4) {
                            var a = h.indexOf(j);
                            a >= 0 && h.splice(a, 1);
                            try {
                                a = j.status
                            } catch (b) {
                                a = 0
                            }
                            a === 200 ? (b && b(), c("NetworkStatus").reportSuccess(), m.inform(c("BanzaiConsts").OK)) : (e && e(a), c("NetworkStatus").reportError(), m.inform(c("BanzaiConsts").ERROR))
                        }
                    })
                };
                h.push(j);
                c("NetworkStatus").isOnline() ? j.send(a) : g = c("NetworkStatus").onChange(function(b) {
                    b = b.online;
                    b && (j.send(a), g.remove())
                })
            },
            setHooks: function() {},
            setUnloadHook: function(a) {
                d("Run").onAfterUnload(a._unload)
            },
            subscribe: function(a, b) {
                if (Array.isArray(a)) {
                    var c = [];
                    a.forEach(function(a) {
                        return c.push(i.addListener(a, b))
                    });
                    return {
                        remove: function() {
                            c.forEach(function(a) {
                                return a.remove()
                            })
                        }
                    }
                } else return i.addListener(a, b)
            },
            useBeacon: !1,
            wrapInTimeSlice: function(a, b) {
                c("FBLogger")("banzai").mustfix("wrapInTimeSlice is not implemented");
                return function() {}
            }
        };
    a = m;
    g["default"] = a
}), 98);
__d("setTimeoutCometLoggingPriWithFallback", ["cr:1268629"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1268629")
}), 98);
__d("setTimeoutCometSpeculativeWithFallback", ["cr:1268630"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1268630")
}), 98);
__d("BanzaiComet", ["BanzaiAdapterComet", "BanzaiCompressionUtils", "BanzaiConsts", "BanzaiLazyQueue", "BanzaiUtils", "CurrentUser", "ErrorGuard", "ExecutionEnvironment", "FBLogger", "Promise", "Run", "Visibility", "WebSession", "clearTimeout", "performanceAbsoluteNow", "recoverableViolation", "setTimeout", "setTimeoutCometLoggingPriWithFallback", "setTimeoutCometSpeculativeWithFallback"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            basic: [],
            vital: []
        },
        i = [],
        j = {
            basic: null,
            vital: null
        },
        k = {
            basic: null,
            vital: null
        },
        l = new Map(),
        m, n = null,
        o = {
            _expiredBatchMap: function() {
                var a = c("performanceAbsoluteNow")();
                for (var b = l.entries(), d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= b.length) break;
                        f = b[e++]
                    } else {
                        e = b.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    var g = f[1];
                    if (g.expiryTime <= a) {
                        var h = g.posts[0];
                        h = (h = h.__meta.priority) != null ? h : c("BanzaiConsts").BASIC;
                        (h = o._getPostBuffer(h)).push.apply(h, g.posts);
                        l["delete"](f[0])
                    }
                }
                l.size > 0 && (m = c("setTimeout")(o._expiredBatchMap, c("BanzaiConsts").BATCH_TIMEOUT))
            },
            _flushBatchMap: function() {
                c("clearTimeout")(m);
                m = null;
                for (var a = l.values(), b = Array.isArray(a), d = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var e;
                    if (b) {
                        if (d >= a.length) break;
                        e = a[d++]
                    } else {
                        d = a.next();
                        if (d.done) break;
                        e = d.value
                    }
                    e = e;
                    var f = e.posts[0];
                    f = (f = f.__meta.priority) != null ? f : c("BanzaiConsts").BASIC;
                    (f = o._getPostBuffer(f)).push.apply(f, e.posts)
                }
                l.clear()
            },
            _flushLazyQueue: function() {
                c("BanzaiLazyQueue").flushQueue().forEach(function(a) {
                    return o.post.apply(o, a)
                })
            },
            _gatherWadsAndPostsFromBuffer: function(a, b, d, e, f, g) {
                var h = {
                    currentSize: 0,
                    keepRetryable: d,
                    overlimit: !1,
                    sendMinimumOnePost: g,
                    wadMap: new Map()
                };
                d = f[e].filter(function(d) {
                    return c("BanzaiUtils").filterPost(d, a, b, h)
                });
                !h.overlimit && e === "vital" && (f.basic = f.basic.filter(function(d) {
                    return c("BanzaiUtils").filterPost(d, a, b, h)
                }));
                return d
            },
            _getPostBuffer: function(a) {
                return a == null ? h.basic : h[a] || []
            },
            _handleBatchPost: function(a, b, d) {
                if (d == null) return !1;
                var e = a[2],
                    f = a[0],
                    g = l.get(f);
                if (g != null && g.expiryTime <= e) {
                    (b = o._getPostBuffer(b)).push.apply(b, g.posts);
                    l["delete"](f);
                    return !1
                }
                if (g != null && g.expiryTime > e) {
                    g.posts.push(a);
                    return !0
                }
                b = {
                    expiryTime: e + d,
                    posts: [a]
                };
                l.set(f, b);
                m || (m = c("setTimeout")(o._expiredBatchMap, c("BanzaiConsts").BATCH_TIMEOUT));
                return !0
            },
            _handlePostPreflightChecks: function(a, b, d) {
                if (o.adapter.config.disabled === !0) return !0;
                if (!c("ExecutionEnvironment").canUseDOM) return !0;
                var e = c("BanzaiAdapterComet").getTopLevel();
                if (e) {
                    var f;
                    try {
                        f = e.require("Banzai")
                    } catch (a) {
                        f = null
                    }
                    if (f) {
                        f.post.apply(f, arguments);
                        return !0
                    }
                }
                if (c("BanzaiAdapterComet").config.disabled === !0) return !0;
                var g = c("BanzaiAdapterComet").config.blacklist;
                return g != null && typeof g.indexOf === "function" && g.indexOf(a) !== -1 ? !0 : !1
            },
            _handleSignalPost: function(a, b, e) {
                if (!e) return !1;
                var f = a;
                f.__meta.status = c("BanzaiConsts").POST_INFLIGHT;
                e = [{
                    app_id: c("CurrentUser").getAppID(),
                    posts: [a],
                    trigger: a[0],
                    user: c("CurrentUser").getPossiblyNonFacebookUserID(),
                    webSessionId: d("WebSession").getId()
                }];
                c("BanzaiAdapterComet").send(o._prepForTransit(e), function() {
                    f.__meta.status = c("BanzaiConsts").POST_SENT, f.__meta.callback != null && f.__meta.callback()
                }, function(d) {
                    c("BanzaiUtils").retryPost(a, d, h[b])
                }, !0);
                return !f.__meta.retry
            },
            _initialize: function() {
                var a = [c("BanzaiConsts").VITAL, c("BanzaiConsts").BASIC];
                c("ExecutionEnvironment").canUseDOM && (c("Visibility").isSupported() ? (c("Visibility").addListener(c("Visibility").HIDDEN, function() {
                    o._flushLazyQueue(), a.forEach(function(a) {
                        o._getPostBuffer(a).length > 0 && o._tryToSendViaBeacon(a)
                    }), o._store()
                }), c("Visibility").addListener(c("Visibility").VISIBLE, function() {
                    o._flushLazyQueue(), a.forEach(function(a) {
                        o._tryToSendViaBeacon(a)
                    }), o._restore()
                })) : o.adapter.setHooks(o), d("Run").onBeforeUnload(function() {
                    o._flushLazyQueue(), o._flushBatchMap(), o._sendBeacon(c("BanzaiConsts").VITAL), o._sendBeacon(c("BanzaiConsts").BASIC)
                }, !1), o.adapter.setUnloadHook(o), d("Run").onAfterLoad(function() {
                    o._restore()
                }))
            },
            _isShutdown: !1,
            _prepForTransit: function(a) {
                var b = new FormData();
                b.append("ts", String(Date.now()));
                var d = c("BanzaiCompressionUtils").outOfBandsPosts(a);
                Object.keys(d).forEach(function(a) {
                    b.append(a, d[a])
                });
                b.append("q", JSON.stringify(a));
                return b
            },
            _prepWadForTransit: function(a) {
                c("BanzaiCompressionUtils").compressWad(a, c("BanzaiAdapterComet").preferredCompressionMethod())
            },
            _prepWadForTransitAsync: function(a) {
                return c("BanzaiCompressionUtils").compressWadAsync(a, c("BanzaiAdapterComet").preferredCompressionMethod())
            },
            _restore: function() {
                var a = function(a) {
                        var b = a.__meta;
                        b = b.priority === c("BanzaiConsts").VITAL ? c("BanzaiConsts").VITAL : c("BanzaiConsts").BASIC;
                        o._getPostBuffer(b).push(a)
                    },
                    b = c("BanzaiAdapterComet").getStorage();
                c("ErrorGuard").applyWithGuard(b.restore, b, [a]);
                o._schedule(c("BanzaiConsts").VITAL_WAIT, c("BanzaiConsts").VITAL)
            },
            _schedule: function(a, b) {
                if (b == null) return !1;
                var d = function() {
                        k[b] = null, j[b] = null, o._sendWithCallbacks(b, null, null)
                    },
                    e = c("performanceAbsoluteNow")() + a;
                if (j[b] == null || e < j[b]) {
                    j[b] = e;
                    k[b] !== null && c("clearTimeout")(k[b]);
                    b === c("BanzaiConsts").VITAL ? k.vital = c("setTimeoutCometLoggingPriWithFallback")(d, a) : k.basic = c("setTimeoutCometSpeculativeWithFallback")(d, a);
                    return !0
                }
                return !1
            },
            _sendBeacon: function(a) {
                o._getPostBuffer(a).length > 0 && o._tryToSendViaBeacon(a)
            },
            _sendWithCallbacks: function(a, d, e) {
                h[a].length > 0 && o._schedule(a === "vital" ? c("BanzaiConsts").VITAL_WAIT : c("BanzaiConsts").BASIC_WAIT_COMET, a);
                if (!c("BanzaiAdapterComet").readyToSend()) {
                    e && e();
                    return
                }
                var f = c("BanzaiAdapterComet").getStorage();
                c("ErrorGuard").applyWithGuard(f.flush, f, [o._restore]);
                c("BanzaiAdapterComet").inform(c("BanzaiConsts").SEND);
                var g = [],
                    j = [];
                h[a] = o._gatherWadsAndPostsFromBuffer(g, j, !0, a, h, !0);
                if (g.length <= 0) {
                    c("BanzaiAdapterComet").inform(c("BanzaiConsts").OK);
                    d && d();
                    return
                }
                g[0].trigger = n;
                n = null;
                g.forEach(function(a) {
                    return a.send_method = "ajax"
                });
                i.push.apply(i, j);
                b("Promise").all(g.map(o._prepWadForTransitAsync))["finally"](function() {
                    if (o._isShutdown) return;
                    j.forEach(function(a) {
                        a = i.indexOf(a);
                        if (a === -1) {
                            c("recoverableViolation")("inflight post not found in inPreparationPosts", "comet_infra");
                            return
                        }
                        i.splice(a, 1)
                    });
                    c("BanzaiAdapterComet").send(o._prepForTransit(g), function() {
                        j.forEach(function(a) {
                            a = a;
                            a.__meta.status = c("BanzaiConsts").POST_SENT;
                            typeof a.__meta.callback === "function" && a.__meta.callback()
                        }), d && d()
                    }, function(b) {
                        j.forEach(function(d) {
                            c("BanzaiUtils").retryPost(d, b, h[a])
                        }), o._store(), e && e()
                    })
                })
            },
            _store: function() {
                var a = c("BanzaiAdapterComet").getStorage();
                c("ErrorGuard").applyWithGuard(a.store, a, [h[c("BanzaiConsts").VITAL]]);
                c("ErrorGuard").applyWithGuard(a.store, a, [h[c("BanzaiConsts").BASIC]])
            },
            _testState: function() {
                return {
                    postBuffer: h.basic,
                    triggerRoute: n
                }
            },
            _tryToSendViaBeacon: function(b) {
                if (!(navigator && navigator.sendBeacon)) return !1;
                var d = !0,
                    e = [],
                    f = [];
                h[b] = o._gatherWadsAndPostsFromBuffer(e, f, !1, b, h, !1);
                if (e.length <= 0) return !1;
                e.forEach(function(a) {
                    return a.send_method = "beacon"
                });
                e.map(o._prepWadForTransit);
                e = o._prepForTransit(e);
                var g = o.adapter.getEndPointUrl(!0);
                g = a.navigator.sendBeacon(g, e);
                g || (d = !1, f.forEach(function(a) {
                    c("BanzaiUtils").resetPostStatus(a), o._getPostBuffer(b).push(a)
                }));
                return d
            },
            _unload: function() {
                o._flushLazyQueue(), o._flushBatchMap(), c("BanzaiAdapterComet").cleanup(), c("BanzaiAdapterComet").inform(c("BanzaiConsts").SHUTDOWN), o._isShutdown = !0, i.forEach(function(a) {
                    var b = a;
                    b = b.__meta.priority;
                    c("BanzaiUtils").retryPost(a, 444, o._getPostBuffer((a = b) != null ? a : c("BanzaiConsts").VITAL))
                }), o._sendBeacon(c("BanzaiConsts").VITAL), o._sendBeacon(c("BanzaiConsts").BASIC), o._store()
            },
            _validateRouteAndSize: function(a, b) {
                a || c("FBLogger")("banzai").blameToPreviousFrame().blameToPreviousFrame().mustfix("BanzaiComet.post called without specifying a route");
                return ((a = JSON.stringify(b)) != null ? a : "").length
            },
            BASIC: {
                delay: c("BanzaiConsts").BASIC_WAIT
            },
            BASIC_WAIT: c("BanzaiConsts").BASIC_WAIT,
            ERROR: c("BanzaiConsts").ERROR,
            EXPIRY: void 0,
            OK: c("BanzaiConsts").OK,
            SEND: c("BanzaiConsts").SEND,
            SHUTDOWN: c("BanzaiConsts").SHUTDOWN,
            VITAL: {
                delay: c("BanzaiConsts").VITAL_WAIT
            },
            VITAL_WAIT: c("BanzaiConsts").VITAL_WAIT,
            adapter: c("BanzaiAdapterComet"),
            canUseNavigatorBeacon: function() {
                return !!(navigator && navigator.sendBeacon && c("BanzaiAdapterComet").isOkToSendViaBeacon())
            },
            flush: function(a, b) {
                o.flushHelper(c("BanzaiConsts").VITAL, a, b), o.flushHelper(c("BanzaiConsts").BASIC, a, b)
            },
            flushHelper: function(a, b, d) {
                j[a] = null, k[a] !== null && (c("clearTimeout")(k[a]), k[a] = null), o._sendWithCallbacks(a, b, d)
            },
            isEnabled: function(a) {
                return !!(c("BanzaiAdapterComet").config.gks && c("BanzaiAdapterComet").config.gks[a])
            },
            post: function(a, b, d) {
                var e;
                o._flushLazyQueue();
                if (o._handlePostPreflightChecks(a, b, d)) return;
                var f = a.split(":");
                if ((c("BanzaiAdapterComet").config.known_routes || []).indexOf(f[0]) === -1) {
                    c("BanzaiAdapterComet").config.should_log_unknown_routes === !0 && c("FBLogger")("banzai").blameToPreviousFrame().mustfix("Attempted to post to invalid Banzai route '" + a + "'. This call site should be cleaned up.");
                    if (c("BanzaiAdapterComet").config.should_drop_unknown_routes === !0) return
                }
                f = o._validateRouteAndSize(a, b);
                d = d || {};
                b = c("BanzaiUtils").wrapData(a, b, c("performanceAbsoluteNow")(), d.retry, f);
                f = b;
                d.callback && (f.__meta.callback = d.callback);
                d.compress != null && (f.__meta.compress = d.compress);
                e = (e = d.delay) != null ? e : c("BanzaiConsts").BASIC_WAIT_COMET;
                var g = e > c("BanzaiConsts").VITAL_WAIT ? c("BanzaiConsts").BASIC : c("BanzaiConsts").VITAL;
                f.__meta.priority = g;
                if (o._handleSignalPost(b, g, (f = d.signal) != null ? f : !1)) return;
                if (o._handleBatchPost(b, g, d.batch)) return;
                o._getPostBuffer(g).push(b);
                (o._schedule(e, g) || n == null) && (n = a)
            },
            postsCount: new Map(),
            subscribe: c("BanzaiAdapterComet").subscribe
        };
    o._initialize();
    e = o;
    g["default"] = e
}), 98);
__d("CometProfiler.react", ["hero-tracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("hero-tracing").HeroReactProfiler
}), 98);
__d("IasUtsClientDebuggingFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743690");
    c = b("FalcoLoggerInternal").create("ias_uts_client_debugging", a);
    e.exports = c
}), null);
__d("WebImmediateActiveSecondsFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1843988");
    c = b("FalcoLoggerInternal").create("web_immediate_active_seconds", a);
    e.exports = c
}), null);
__d("TimeSpentImmediateActiveSecondsLoggerComet", ["CometTimeSpentNavigation", "CurrentUser", "IasUtsClientDebuggingFalcoEvent", "WebImmediateActiveSecondsFalcoEvent", "crc32", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("CurrentUser").getID(),
        i = h !== "" || h !== "0" ? 2003 : 0,
        j = (c("crc32")(h) >>> 0) % i,
        k = 0;

    function l(a) {
        if (i <= 0) return !1;
        a = Math.floor(a / 1e3) % i;
        return a === j
    }

    function a(a) {
        if (a >= k && a - k < 1e3) return;
        var b = l(a);
        if (b) {
            var d = c("CometTimeSpentNavigation").getPathInfo();
            c("WebImmediateActiveSecondsFalcoEvent").logImmediately(function() {
                return {
                    activity_time_ms: a,
                    last_activity_time_ms: k,
                    script_path: d ? d.name : ""
                }
            })
        }
        c("gkx")("1427308") && c("IasUtsClientDebuggingFalcoEvent").log(function() {
            return {
                activity_time: a,
                calculated_sampling_rate: i,
                client_user_id: h,
                ias_bucket: j,
                last_activity_time: k,
                should_report_ias: b,
                source: "ias"
            }
        });
        k = Math.floor(a / 1e3) * 1e3
    }
    g.maybeReportActiveSecond = a
}), 98);
__d("CometInteractionVC", ["CometVCTracker", "InteractionTracing", "InteractionTracingMetrics", "JSScheduler", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        defer_expensive_calculation: function(a) {
            d("JSScheduler").scheduleLoggingPriCallback(a)
        },
        observeTextMutation: !1,
        retain_element_reference: c("gkx")("950768") || c("gkx")("1293035") || c("gkx")("1537962"),
        use_image_download_tracker: c("gkx")("6017"),
        vc_deep_cleanup: c("gkx")("2654")
    };

    function a(a, b, d) {
        a = c("InteractionTracingMetrics").get(a);
        a = a && a.vcTracker;
        a && a.addMountPointMetadata(b, d)
    }

    function b(a, b) {
        a = c("InteractionTracingMetrics").get(a);
        a = a && a.vcTracker;
        a && a.addMutationRoot(b)
    }

    function e(a, b) {
        c("InteractionTracing").getPendingInteractions().forEach(function(c) {
            c = c.getTrace();
            c && c.vcTracker && c.type === b && c.vcTracker.addMutationRoot(a)
        })
    }

    function f(a, b) {
        a = c("InteractionTracingMetrics").get(a);
        a && a.vcTracker && a.vcTracker.observeMutation(b)
    }

    function i(a, b, d) {
        return new(c("CometVCTracker").VisualCompletionTraceForInteraction)(b, 0, a, d, h)
    }

    function j(a) {
        var b = [];
        c("InteractionTracing").getPendingInteractions().forEach(function(c) {
            c = c.getTrace();
            c && c.vcTracker && b.push(c.vcTracker.waitLoadingState(a))
        });
        return b
    }
    g.addMountPointMetaData = a;
    g.addMutationRootForTraceId = b;
    g.addMutationRootForTraceType = e;
    g.observeMutation = f;
    g.startVisualCompletionTrace = i;
    g.trackLoadingState = j
}), 98);
__d("cancelIdleCallbackComet", ["IdleCallbackImplementation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        d("IdleCallbackImplementation").cancelIdleCallback(a)
    }
    g["default"] = a
}), 98);
__d("clearIntervalComet", ["setTimeoutCometInternals"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("setTimeoutCometInternals").clearInterval_DO_NOT_USE
}), 98);
__d("clearTimeoutComet", ["setTimeoutCometInternals"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("setTimeoutCometInternals").clearTimeout_DO_NOT_USE
}), 98);
__d("lowerDomainComet", ["ErrorGuard", "FBLogger", "LowerDomainRegex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("ErrorGuard").guard(function() {
        var a;
        if (window.self !== window.top) return;
        if (((a = document.domain) != null ? a : "").toLowerCase().match(d("LowerDomainRegex").domainRegex)) {
            a = window.location.hostname.match(d("LowerDomainRegex").hostnameRegex);
            a = a ? a[1] : "facebook.com";
            try {
                document.domain = a
            } catch (a) {
                c("FBLogger")("lowerDomainComet").catching(a).warn("Error trying to lower the domain")
            }
        }
    });
    b = a;
    g["default"] = b
}), 98);
__d("setIntervalComet", ["JSScheduler", "setTimeoutCometInternals"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = d("JSScheduler").getCurrentPriorityLevel() === d("JSScheduler").priorities.unstable_Idle ? d("JSScheduler").priorities.unstable_Idle : d("JSScheduler").priorities.unstable_Low;
        for (var e = arguments.length, f = new Array(e > 2 ? e - 2 : 0), g = 2; g < e; g++) f[g - 2] = arguments[g];
        return d("setTimeoutCometInternals").setIntervalAtPriority_DO_NOT_USE.apply(d("setTimeoutCometInternals"), [c, a, b].concat(f))
    }
    g["default"] = a
}), 98);
__d("CometChromeDome", ["JSScheduler", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("Chromedome").__setRef("CometChromeDome");

    function a() {
        h.onReady(function(a) {
            d("JSScheduler").scheduleLoggingPriCallback(function() {
                a.start({})
            })
        })
    }
    g.init = a
}), 98);
__d("CometRelayScheduler", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").startTransition;
    a = {
        cancel: function() {},
        schedule: function(a) {
            h(a);
            return ""
        }
    };
    g["default"] = a
}), 98);
__d("CometSSRLogger", ["VisualCompletionUtil"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return {
            logPayloadReceivedFromInlineInjector: function() {},
            logSSRInjection: function() {},
            logSSRShown: function() {}
        }
    }

    function b(a) {
        return {
            logPayloadReceivedFromInlineInjector: function(b) {
                var c = b.clickEvents,
                    d = b.msg,
                    e = b.processedPayloads;
                b = b.status;
                a.addMetadata("ssr_inline_status", b + " " + (d || ""));
                a.addMetadata("ssr_inline_click_events", c.total);
                e && e.forEach(function(b) {
                    var c;
                    c = (c = b.id) != null ? c : "global_failure";
                    a.addMetadata("ssr_status_" + c, b.status)
                })
            },
            logSSRInjection: function(b) {
                a.addMetadata("ssr_injected", b ? 1 : 0), b && (a.addMarkerPoint("ssr_shown", "AppTiming"), d("VisualCompletionUtil").foregroundRequestAnimationFrame(function() {
                    a.addMarkerPoint("ssr_paint", "AppTiming")
                }))
            },
            logSSRShown: function(b) {
                a.addMarkerPoint("ssr_shown_" + b, "AppTiming")
            }
        }
    }
    g.initNoopLogger = a;
    g.initLogger = b
}), 98);
__d("jestOnlyViolation", ["FBLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        d = d === void 0 ? {} : d;
        d = d.error;
        b = c("FBLogger")(b);
        d && (b = b.catching(d));
        b.blameToPreviousFrame().fatal("Jest-Only Fatal: " + a);
        return null
    }
    g["default"] = a
}), 98);
__d("CometSSRContentInjector", ["CometSSRHydrationMarkerUtils", "CometSSRLogger", "cr:2010754", "gkx", "jestOnlyViolation", "performanceNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("CometSSRLogger").initNoopLogger(),
        i = {
            onAllPayloadsInjected: function() {},
            onContentInjected: function(a) {}
        },
        j = !1,
        k = null,
        l = {};

    function m(a) {
        switch (a) {
            case "fail_js_error":
                return "server_js_error";
            case "fail_infra_error":
                return "server_infra_error";
            case "fail_ssr_disabled":
                return "ssr_disabled";
            case "fail_feed_module_not_supported":
                return "feed_module_not_supported";
            case "fail_bad_preloaders":
                return "bad_preloaders";
            case "fail_unknown_boundaries":
                return "unknown_boundaries";
            case "fail_timed_out":
                return "timed_out";
            default:
                return "unknown"
        }
    }
    var n = {
            root: "pending"
        },
        o = 0,
        p = new Map();

    function q() {
        return {
            boundaryErrorStatuses: babelHelpers["extends"]({}, l),
            boundaryStatuses: babelHelpers["extends"]({}, n),
            globalBoundaryErrorStatus: k
        }
    }

    function r() {
        if (p.size === 0) return;
        var a = q();
        p.forEach(function(b) {
            return b(a)
        })
    }

    function a() {
        return q()
    }
    var s = null;

    function e(a) {
        s = a
    }

    function t(a) {
        if (b("cr:2010754")) {
            var d = c("performanceNow")(),
                e = a.querySelectorAll("img");
            Array.from(e).forEach(function(a) {
                b("cr:2010754").trackImagePerf(a, d, a.currentSrc || a.src, {
                    mutationType: "ssrUnhide"
                })
            });
            e = a.querySelectorAll("image");
            Array.from(e).forEach(function(a) {
                b("cr:2010754").trackImagePerf(a, d, (a = a.getAttribute("xlink:href")) != null ? a : "", {
                    mutationType: "ssrUnhide"
                })
            })
        }
    }

    function u(a) {
        if (c("gkx")("6830")) return;
        if (!j) {
            var b = document.getElementById("splash-screen");
            b !== null && (b.remove(), j = !0)
        }
        a.style.visibility = "";
        a.style.display = "";
        c("gkx")("1426") && ((b = window.CSS) == null ? void 0 : b.supports) && window.CSS.supports("content-visibility", "hidden") && (typeof window.__SSRForceLayoutCallbackID === "number" && typeof window.cancelIdleCallback === "function" && window.cancelIdleCallback(window.__SSRForceLayoutCallbackID), a.style["content-visibility"] = "");
        t(a)
    }

    function f(a) {
        var b = o++;
        p.set(b, a);
        return {
            release: function() {
                p["delete"](b)
            }
        }
    }

    function v(a, b, c) {
        b && (h = d("CometSSRLogger").initLogger(b));
        var e = c.onAllPayloadsInjected,
            f = c.onFirstPayloadInjected;
        window.__SSREventEmitter.on("FIRSTPAYLOADINJECTED", function() {
            f == null ? void 0 : f()
        });
        window.__SSREventEmitter.on("ALLPAYLOADSINJECTED", function(b) {
            u(a);
            e == null ? void 0 : e();
            if (!b) return;
            h.logPayloadReceivedFromInlineInjector(b);
            h.logSSRInjection(b.status === "INJECTED");
            b.status === "INJECTED" ? b.processedPayloads && b.processedPayloads.forEach(function(a) {
                a = a.id;
                a && (h.logSSRShown(a), n[a] = "content_injected")
            }) : (s == null ? void 0 : s(), x(b));
            r()
        })
    }

    function w(a, b, c) {
        a;
        b && (h = d("CometSSRLogger").initLogger(b));
        var e = c == null ? void 0 : c.onContentInjected;
        e && (i.onContentInjected = e);
        d("CometSSRHydrationMarkerUtils").injectStyles != null && d("CometSSRHydrationMarkerUtils").injectStyles();
        window.__onSSRCompleted(function(b) {
            h.logPayloadReceivedFromInlineInjector(b);
            b.unbindListeners && b.unbindListeners();
            u(a);
            h.logSSRInjection(b.status === "INJECTED");
            if (b.status === "INJECTED") {
                var c = e || function(a) {};
                b.processedPayloads.forEach(function(a) {
                    a = a.id;
                    a && (h.logSSRShown(a), n[a] = "content_injected", c(a))
                })
            } else x(b);
            r()
        })
    }

    function x(a) {
        a.processedPayloads && a.processedPayloads.forEach(function(a) {
            var b = a.id;
            a = a.status;
            if (a !== "success") {
                var c = m(a);
                b && (l[b] = c, n[b] = "client_rendered");
                k = k === null || k === "unknown" ? c : k;
                a !== "fail_ssr_disabled" && y(c)
            }
        })
    }

    function y(a) {
        c("gkx")("1501502") && c("jestOnlyViolation")("Encountered error during server rendering: " + a + "! See slog for error details. (client rendering prevented since comet_ssr_fatal_on_error is enabled)", "comet_infra")
    }
    window.__SSRFailJestOnError = y;
    g.__getDebugState = a;
    g.onForceHydration = e;
    g.__onDebugStateChange = f;
    g.initFizz = v;
    g.init = w
}), 98);
__d("CometUserActivity", ["BaseEventEmitter", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 5e3,
        i = 500,
        j = -5,
        k = Date.now(),
        l = k,
        m = !1,
        n = Date.now(),
        o = document.hasFocus ? document.hasFocus() : !0,
        p = 0,
        q = Date.now(),
        r = -1,
        s = -1,
        t = !1,
        u = !1,
        v = new(c("BaseEventEmitter"))();

    function b(a) {
        var b = w(function(c, d) {
            b.unsubscribe(), a(d)
        });
        return b
    }

    function w(a) {
        var b = v.addListener("user_activity", function(b) {
            return a("user_activity", b)
        });
        return {
            unsubscribe: function() {
                return b.remove()
            }
        }
    }

    function d(a) {
        return new Date() - k < (a != null ? a : h)
    }

    function e() {
        return o
    }

    function f() {
        return m
    }

    function x() {
        o = !0, m = !1
    }

    function y() {
        return n
    }

    function z() {
        return k
    }

    function A(a) {
        p = a
    }

    function B() {
        return q
    }

    function C() {
        return t
    }

    function D() {
        return u
    }

    function E() {
        return l
    }

    function F() {
        k = Date.now(), l = k, m = !1, n = Date.now(), o = document.hasFocus ? document.hasFocus() : !0, p = 0, q = Date.now(), r = -1, s = -1, t = !1, u = !1
    }

    function G(a) {
        a.unsubscribe()
    }

    function H(a) {
        J(a, i)
    }

    function I(a) {
        J(a, 0)
    }

    function J(b, c) {
        c === void 0 && (c = 0);
        var d = a.MouseEvent,
            e = a.KeyboardEvent;
        if (d && b instanceof d) {
            if (/^mouse(enter|leave|move|out|over)$/.test(b.type) && b.pageX == r && b.pageY == s) return;
            r = b.pageX;
            s = b.pageY
        } else e && b instanceof e && (u = !0);
        (b.type === "click" || b.type === "dblclick" || b.type === "contextmenu") && (t = !0);
        k = Date.now();
        d = k - l;
        d >= c ? (l = k, o || (q = k), d >= (p || h) && (m = !0, n = k), v.emit("user_activity", {
            event: b,
            idleness: d,
            last_inform: l
        })) : d < j && (l = k)
    }

    function K(a) {
        o = !0, n = Date.now(), I(a)
    }

    function L() {
        o = !1, m = !0, q = Date.now()
    }
    window.addEventListener("scroll", H, {
        capture: !0,
        passive: !0
    });
    window.addEventListener("focus", K, {
        capture: !c("gkx")("1352"),
        passive: !0
    });
    window.addEventListener("blur", L, {
        capture: !c("gkx")("1352"),
        passive: !0
    });
    (function() {
        var a = document.documentElement;
        if (a == null) return;
        ["keydown", "mouseover", "mousemove", "click"].forEach(function(b) {
            a.addEventListener(b, H, {
                capture: !0,
                passive: !0
            })
        })
    })();
    g.EVENT_INTERVAL_MS = i;
    g.subscribeOnce = b;
    g.subscribe = w;
    g.isActive = d;
    g.isOnTab = e;
    g.hasBeenInactive = f;
    g.resetActiveStatus = x;
    g.getLastInActiveEnds = y;
    g.getLastActive = z;
    g.setIdleTime = A;
    g.getLastLeaveTime = B;
    g.hasClicked = C;
    g.hasInteractedWithKeyboard = D;
    g.getLastInformTime = E;
    g.reset = F;
    g.unsubscribe = G
}), 98);
__d("NavigationTracing", ["InteractionTracing", "InteractionTracingMetrics", "WebSession"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
        var b = d("WebSession").getSessionId();
        b != null && c("InteractionTracingMetrics").addMetadata(a, "websession_id", b)
    };

    function a(a, b) {
        a = c("InteractionTracing").navigation.traceInitialLoad(c("InteractionTracing").transformStartMetadata(a), b);
        h(a);
        return a
    }

    function b(a, b) {
        a = c("InteractionTracing").navigation.traceNavigation(c("InteractionTracing").transformStartMetadata(a), b);
        h(a);
        return a
    }
    g.traceInitialLoad = a;
    g.traceNavigation = b
}), 98);
__d("EventProfilerSham", [], (function(a, b, c, d, e, f) {
    a = {
        __wrapEventListenHandler: function(a) {
            return a
        },
        tagCurrentActiveInteractionsAs: function(a) {},
        setCurrentAdAccountId: function(a) {},
        setAdsConfig: function(a) {}
    };
    b = a;
    f["default"] = b
}), 66);
__d("QPLAddCometRequestHeaders", ["QuickPerformanceLogger", "cometAsyncRequestHeaders"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        d("cometAsyncRequestHeaders").registerHeaderProvider(function() {
            var a = c("QuickPerformanceLogger").getActiveMarkerIds({
                type: 2
            });
            if (a.length > 0) {
                var b = {};
                b["X-FB-QPL-Active-Flows"] = a.sort().join(",");
                return b
            }
            return {}
        })
    }
    g["default"] = a
}), 98);
__d("ScheduledApplyEach", ["JSScheduler"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c) {
        return a.map(function(a) {
            d("JSScheduler").deferUserBlockingRunAtCurrentPri_DO_NOT_USE(function() {
                b.apply(c, a)
            })
        })
    }
    g["default"] = a
}), 98);