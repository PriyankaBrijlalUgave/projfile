if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("MessengerEmojiConfig", [], (function(a, b, c, d, e, f) {
    e.exports = {
        emoji_colors: [0, 127995, 127996, 127997, 127998, 127999]
    }
}), null);
__d("MessengerScrollableArea.react", ["cx", "ScrollableArea.react", "Style", "UserAgent", "clearImmediate", "gkx", "joinClasses", "react", "setImmediate", "throttle"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = 20,
        k = c("gkx")("1094116");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            var d;
            d = a.call(this, b) || this;
            d.$1 = !1;
            d.$2 = null;
            d.$5 = function() {
                if (d.$1) {
                    var a;
                    d.props.onScroll && (a = d.props).onScroll.apply(a, arguments)
                }
            };
            d.$6 = function() {
                if (!c("UserAgent").isBrowser("IE")) return;
                if (k) return;
                if (!d.refs || !d.$4.current) return;
                var a = d.$4.current.refs.wrap,
                    b = d.$4.current.refs.body;
                if (!b || !a) return;
                a = a.offsetWidth - a.clientWidth;
                a > 0 && c("Style").set(b, "margin-right", -a + "px")
            };
            d.$3 = c("throttle")(d.$5, 50);
            d.$4 = i.createRef();
            return d
        }
        var d = b.prototype;
        d.componentDidMount = function() {
            this.$2 = c("setImmediate")(this.$6), this.$1 = !0
        };
        d.componentWillUnmount = function() {
            c("clearImmediate")(this.$2), this.$1 = !1
        };
        d.render = function() {
            var a = this.props.needsFastScrollHandler ? this.$5 : this.$3;
            return i.jsx(c("ScrollableArea.react"), {
                className: c("joinClasses")("_5f0v", this.props.className),
                height: this.props.height,
                onClick: this.props.onClick,
                onScroll: a,
                persistent: !0,
                ref: this.$4,
                shadow: !1,
                tabIndex: this.props.tabIndex,
                width: this.props.width,
                children: this.props.children
            })
        };
        d.getArea = function() {
            if (this.$4.current) return this.$4.current.getArea()
        };
        d.scrollToBottom = function(a) {
            var b = this.getArea();
            b && this.scrollToPosition(b.getScrollHeight(), !!a)
        };
        d.scrollToTop = function(a) {
            var b = this.getArea();
            b && b.scrollToTop(!!a)
        };
        d.scrollToPosition = function(a, b, c) {
            b === void 0 && (b = !1);
            c === void 0 && (c = {});
            var d = this.getArea();
            if (!d) return;
            d.setScrollTop(a, b, c)
        };
        d.isScrolledToBottom = function() {
            return this.isScrolledToBottomWithHeight(0)
        };
        d.isScrolledToBottomWithHeight = function(a) {
            var b = this.getArea();
            return !b ? !1 : b.getScrollTop() + b.getClientHeight() + a >= b.getScrollHeight() - j
        };
        d.isScrolledToTop = function() {
            var a = this.getArea();
            return !a ? !0 : a.getScrollTop() <= j
        };
        d.getScrollTop = function() {
            var a = this.getArea();
            return !a ? 0 : a.getScrollTop()
        };
        return b
    }(i.Component);
    g["default"] = a
}), 98);
__d("SkinToneEmoji.bs", ["EmojiFormat.bs", "MessengerEmojiConfig", "bs_caml_array"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        switch (a) {
            case "1f385":
            case "1f3c3":
            case "1f3c4":
            case "1f3ca":
            case "1f3cb":
            case "1f442":
            case "1f443":
            case "1f446":
            case "1f447":
            case "1f448":
            case "1f449":
            case "1f44a":
            case "1f44b":
            case "1f44c":
            case "1f44d":
            case "1f44e":
            case "1f44f":
            case "1f450":
            case "1f466":
            case "1f467":
            case "1f468":
            case "1f469":
            case "1f46e":
            case "1f470":
            case "1f471":
            case "1f472":
            case "1f473":
            case "1f474":
            case "1f475":
            case "1f476":
            case "1f477":
            case "1f478":
            case "1f47c":
            case "1f481":
            case "1f482":
            case "1f483":
            case "1f485":
            case "1f486":
            case "1f487":
            case "1f4aa":
            case "1f575":
            case "1f590":
            case "1f595":
            case "1f596":
            case "1f645":
            case "1f646":
            case "1f647":
            case "1f64b":
            case "1f64c":
            case "1f64d":
            case "1f64e":
            case "1f64f":
            case "1f6a3":
            case "1f6b4":
            case "1f6b5":
            case "1f6b6":
            case "1f6c0":
            case "1f918":
            case "261d":
            case "26f9":
            case "270a":
            case "270b":
            case "270c":
            case "270d":
                return !0;
            default:
                return !1
        }
    }

    function h(a) {
        if (b("bs_caml_array").get(a, a.length - 1 | 0) === 65039) return b("bs_caml_array").get(a, a.length - 1 | 0);
        else return 0
    }

    function i(a) {
        if (b("bs_caml_array").get(a, a.length - 1 | 0) === 65039) return a;
        a = a.slice(0);
        return a.concat([65039])
    }

    function j(a) {
        if (h(a) === 0) return a;
        else return a.slice(0, a.length - 1 | 0)
    }

    function k(a) {
        var c = b("MessengerEmojiConfig").emoji_colors;
        c = c.filter(function(b) {
            return b === a
        });
        return c.length !== 0
    }

    function l(a) {
        a = j(a);
        if (a.length <= 1 || !k(b("bs_caml_array").get(a, a.length - 1 | 0))) return 0;
        else return b("bs_caml_array").get(a, a.length - 1 | 0)
    }

    function m(a) {
        var b = h(a),
            c = b === 0 ? l(a) : l(a.slice(0, a.length - 1 | 0));
        if (c !== 0)
            if (b === 0) return a.slice(0, a.length - 1 | 0);
            else return i(a.slice(0, a.length - 2 | 0));
        else return a
    }

    function a(a, b) {
        if (b === 0) return a;
        var c = h(a),
            d = c === 0 ? a.slice(0) : a.slice(0, a.length - 1 | 0),
            e = l(d);
        if (e !== 0) return a;
        e = d.concat([b]);
        if (c === 0) return e;
        else return e.concat([c])
    }

    function c(a) {
        return m(j(a))
    }

    function d(a) {
        return g(b("EmojiFormat.bs").codeArrayToCodeString(m(j(a))))
    }
    e = 65039;
    f.emoji_modifier_code = e;
    f.emoji = g;
    f.getEmojiModifier = h;
    f.addEmojiModifier = i;
    f.removeEmojiModifier = j;
    f.isToneModifier = k;
    f.getTone = l;
    f.removeTone = m;
    f.applyTone = a;
    f.removeAllModifiers = c;
    f.hasVariations = d
}), null);
__d("MessengerEmojiTransitionMapping.bs", ["EmojiFormat.bs", "SkinToneEmoji.bs", "bs_caml_array"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        switch (a) {
            case "1f3c3":
            case "1f3c4":
            case "1f3ca":
            case "1f3cb":
            case "1f3cc":
            case "1f46e":
            case "1f46f":
            case "1f471":
            case "1f473":
            case "1f477":
            case "1f481":
            case "1f482":
            case "1f486":
            case "1f487":
            case "1f575":
            case "1f645":
            case "1f646":
            case "1f647":
            case "1f64b":
            case "1f64d":
            case "1f64e":
            case "1f6a3":
            case "1f6b4":
            case "1f6b5":
            case "1f6b6":
            case "26f9":
                return !0;
            default:
                return !1
        }
    }

    function h(a) {
        if (b("bs_caml_array").get(a, a.length - 1 | 0) === 65039) return b("bs_caml_array").get(a, a.length - 1 | 0);
        else return 0
    }

    function i(a) {
        if (b("bs_caml_array").get(a, a.length - 1 | 0) === 65039) return a;
        a = a.slice(0);
        return a.concat([65039])
    }

    function j(a) {
        if (h(a) === 0) return a;
        else return a.slice(0, a.length - 1 | 0)
    }

    function k(a) {
        if (a === 9792) return !0;
        else return a === 9794
    }

    function l(a) {
        a = j(a);
        if (a.length <= 1 || !k(b("bs_caml_array").get(a, a.length - 1 | 0))) return 0;
        else return b("bs_caml_array").get(a, a.length - 1 | 0)
    }

    function m(a) {
        var b = h(a),
            c = b === 0 ? l(a) : l(a.slice(0, a.length - 1 | 0));
        if (c !== 0)
            if (b === 0) return a.slice(0, a.length - 2 | 0);
            else return i(a.slice(0, a.length - 3 | 0));
        else return a
    }

    function n(a, b) {
        if (b === 0) return a;
        var c = h(a),
            d = c === 0 ? a.slice(0) : a.slice(0, a.length - 1 | 0),
            e = l(d);
        if (e !== 0) return a;
        e = d.concat([8205, b]);
        if (c === 0) return e;
        else return e.concat([c])
    }

    function a(a) {
        return n(a, 9792)
    }

    function c(a) {
        return m(b("SkinToneEmoji.bs").removeTone(a))
    }

    function d(a) {
        return g(b("EmojiFormat.bs").codeArrayToCodeString(m(b("SkinToneEmoji.bs").removeTone(a))))
    }

    function e(a) {
        a = b("EmojiFormat.bs").codeArrayToCodeString(m(b("SkinToneEmoji.bs").removeTone(a)));
        switch (a) {
            case "1f46a":
            case "1f48f":
            case "1f491":
                return !0;
            default:
                return !1
        }
    }
    var o = 65039,
        p = 9792,
        q = 9794,
        r = 8205;
    f.emoji_modifier_code = o;
    f.gender_female = p;
    f.gender_male = q;
    f.zero_join = r;
    f.emoji = g;
    f.getEmojiModifier = h;
    f.addEmojiModifier = i;
    f.removeEmojiModifier = j;
    f.isGenderModifier = k;
    f.getGender = l;
    f.removeGender = m;
    f.applyGender = n;
    f.makeFemale = a;
    f.removeAllModifiers = c;
    f.hasGender = d;
    f.isBlacklisted = e
}), null);
__d("MessengerHotlikeEmoji.bs", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "f0000";

    function a(a) {
        return a === g
    }
    f.hotlike_key = g;
    f.isMessengerHotlike = a
}), null);
__d("MessengerHotlikeEmoji.re", ["MessengerHotlikeEmoji.bs"], (function(a, b, c, d, e, f) {
    a = b("MessengerHotlikeEmoji.bs").isMessengerHotlike;
    f.isMessengerHotlike = a
}), null);
__d("Utf16", [], (function(a, b, c, d, e, f) {
    function a(a) {
        switch (a.length) {
            case 1:
                return a.charCodeAt(0);
            case 2:
                return 65536 | (a.charCodeAt(0) - 55296) * 1024 | a.charCodeAt(1) - 56320;
            default:
                return null
        }
    }

    function b(a) {
        if (a < 65536) return String.fromCharCode(a);
        else return String.fromCharCode(55296 + (a - 65536 >> 10)) + String.fromCharCode(56320 + a % 1024)
    }
    f.decode = a;
    f.encode = b
}), 66);
__d("messengerIterateEmoji", ["MessengerSupportedEmoji", "ifRequired"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f) {
        var g = String(a);
        while (g) {
            a = c("ifRequired")("MessengerSupportedEmojiUtils", function(a) {
                return a.getEmojiMatchObj(g)
            }, function() {
                return d("MessengerSupportedEmoji").getEmojiMatchObj(g)
            });
            if (a) {
                var h = a.offset + a.length,
                    i = g.substr(0, a.is_supported ? a.offset : h);
                e(i);
                a.is_supported && b(a.emoji_str, a.emoji_key, f);
                i = g.substr(h);
                g = i
            } else break
        }
        e(g)
    }
    g["default"] = a
}), 98);
__d("messengerIterateEmoticons", ["EmoticonEmojiList"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, c, e) {
        var f, g, h;
        a = String(a);
        while (a) {
            g = d("EmoticonEmojiList").regexp.exec(a);
            if (g) f = g.index + g[1].length, h = a.substr(0, f), g = g[2], f = a.substr(f + g.length), c(h), b(g, d("EmoticonEmojiList").names[g], e), a = f;
            else break
        }
        c(a)
    }
    g["default"] = a
}), 98);
__d("MessengerTextWithEmoticons.react", ["cx", "fbt", "BaseTextWithDecoration.react", "EmojiImageURL", "EmoticonEmojiList", "FBEmojiResource", "Image.react", "MessengerHotlikeEmoji.re", "messengerIterateEmoji", "messengerIterateEmoticons", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function k(a, b, e, f, g) {
        var h = f === !0 ? 128 : 16;
        g = g != null ? g : !a && !d("MessengerHotlikeEmoji.re").isMessengerHotlike(e) ? new(c("FBEmojiResource"))(e).getImageURL(h) : d("EmojiImageURL").getMessengerURL(e, h);
        a = f === !0 ? "_1ift _5m3a" : "_1ift _2560";
        return j.jsx(c("Image.react"), {
            alt: b,
            className: a,
            src: g
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function l(a, b, e) {
        var f = e === !0 ? 128 : 16,
            g = d("EmoticonEmojiList").emote2emojis[b],
            h = g ? d("MessengerHotlikeEmoji.re").isMessengerHotlike(g) ? d("EmojiImageURL").getMessengerURL(g, f) : new(c("FBEmojiResource"))(g).getImageURL(f) : null;
        if (h != null && h !== "") {
            g = String.fromCodePoint(parseInt(g, f));
            f = e === !0 ? "_1ift _5m3a" : "_1ift _2560";
            return j.jsx(c("Image.react"), {
                alt: g,
                className: f,
                src: h
            })
        }
        e = i._("{emoticonName} emoticon", [i._param("emoticonName", b)]);
        return j.jsx("span", {
            "aria-label": e,
            children: a
        })
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function m(a, b, c) {
        return function(d, e, f) {
            var g = function(c, d, a) {
                e(b(c, d, a))
            };
            a(String(d), g, f, c)
        }
    }
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.shouldComponentUpdate = function(a) {
            return a.text !== this.props.text
        };
        d.render = function() {
            var a = [m(c("messengerIterateEmoji"), k.bind(null, !!this.props.forceMessengerEmoji), this.props.customSize), m(c("messengerIterateEmoticons"), l, this.props.customSize)];
            return j.jsx(c("BaseTextWithDecoration.react"), babelHelpers["extends"]({}, this.props, {
                text: this.props.text,
                decorators: a
            }))
        };
        return b
    }(j.Component);
    a.renderEmoji = k;
    g["default"] = a
}), 98);