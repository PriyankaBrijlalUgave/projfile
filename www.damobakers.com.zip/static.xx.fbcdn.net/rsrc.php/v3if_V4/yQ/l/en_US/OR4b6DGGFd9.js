if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometDismissFBNuxMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "4969387046444111"
}), null);
__d("CometDismissFBNuxMutation.graphql", ["CometDismissFBNuxMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "nux_id_input"
            }],
            c = [{
                kind: "Variable",
                name: "nux_id",
                variableName: "nux_id_input"
            }],
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "should_show",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "CometDismissFBNuxMutation",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nux_dismiss",
                    plural: !1,
                    selections: [d],
                    storageKey: null
                }],
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "CometDismissFBNuxMutation",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nux_dismiss",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "__typename",
                        storageKey: null
                    }, d, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "id",
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("CometDismissFBNuxMutation_facebookRelayOperation"),
                metadata: {},
                name: "CometDismissFBNuxMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("CometLogImpressionFBNuxMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5712935945399791"
}), null);
__d("CometLogImpressionFBNuxMutation.graphql", ["CometLogImpressionFBNuxMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "nux_id"
            }],
            c = [{
                kind: "Variable",
                name: "nux_id",
                variableName: "nux_id"
            }],
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "nux_id",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "CometLogImpressionFBNuxMutation",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "log_nux_view",
                    plural: !1,
                    selections: [d],
                    storageKey: null
                }],
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "CometLogImpressionFBNuxMutation",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "log_nux_view",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "__typename",
                        storageKey: null
                    }, d, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "id",
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("CometLogImpressionFBNuxMutation_facebookRelayOperation"),
                metadata: {},
                name: "CometLogImpressionFBNuxMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8041112739247711"
}), null);
__d("CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation.graphql", ["CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "nux_id"
            }],
            c = [{
                kind: "Variable",
                name: "nux_id",
                variableName: "nux_id"
            }],
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "nux_id",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "log_nux_view_and_increment_view_count",
                    plural: !1,
                    selections: [d],
                    storageKey: null
                }],
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "log_nux_view_and_increment_view_count",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "__typename",
                        storageKey: null
                    }, d, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "id",
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation_facebookRelayOperation"),
                metadata: {},
                name: "CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useLiveCostreamerTagSubscription_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5422329641195523"
}), null);
__d("useLiveCostreamerTagSubscription.graphql", ["useLiveCostreamerTagSubscription_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                kind: "Variable",
                name: "data",
                variableName: "input"
            }],
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            e = [d],
            f = {
                alias: null,
                args: null,
                concreteType: "Page",
                kind: "LinkedField",
                name: "tagged_page",
                plural: !1,
                selections: [d, {
                    alias: null,
                    args: null,
                    concreteType: "Video",
                    kind: "LinkedField",
                    name: "currently_live_video",
                    plural: !1,
                    selections: e,
                    storageKey: null
                }],
                storageKey: null
            },
            g = {
                args: null,
                documentName: "useLiveCostreamerTagSubscription",
                fragmentName: "VideoPlayerCostreamingControl_video",
                fragmentPropName: "video",
                kind: "ModuleImport"
            };
        e = {
            alias: null,
            args: null,
            concreteType: "Video",
            kind: "LinkedField",
            name: "video",
            plural: !1,
            selections: [d, {
                alias: null,
                args: null,
                concreteType: "VideoLiveCostreamingStreamersConnection",
                kind: "LinkedField",
                name: "live_costreaming_streamers",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "Page",
                    kind: "LinkedField",
                    name: "nodes",
                    plural: !0,
                    selections: e,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "count",
                    storageKey: null
                }],
                storageKey: null
            }],
            storageKey: null
        };
        var h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            i = [h, d],
            j = [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "uri",
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "useLiveCostreamerTagSubscription",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: "LiveVideoTagSubscribeResponsePayload",
                    kind: "LinkedField",
                    name: "live_video_tag_subscribe",
                    plural: !1,
                    selections: [f, {
                        alias: null,
                        args: null,
                        concreteType: "Video",
                        kind: "LinkedField",
                        name: "tagged_video",
                        plural: !1,
                        selections: [d, {
                            alias: null,
                            args: null,
                            concreteType: "Video",
                            kind: "LinkedField",
                            name: "if_viewer_can_see_costreaming_tools",
                            plural: !1,
                            selections: [g],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "VideoLiveCostreamingStreamersConnection",
                            kind: "LinkedField",
                            name: "live_costreaming_streamers",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "Page",
                                kind: "LinkedField",
                                name: "nodes",
                                plural: !0,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    concreteType: "Video",
                                    kind: "LinkedField",
                                    name: "currently_live_video",
                                    plural: !1,
                                    selections: [{
                                        args: null,
                                        kind: "FragmentSpread",
                                        name: "CometVideoPlayerCostreamingThumbnailRowInner_video"
                                    }],
                                    storageKey: null
                                }],
                                storageKey: null
                            }],
                            storageKey: null
                        }],
                        storageKey: null
                    }, e],
                    storageKey: null
                }],
                type: "Subscription",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "useLiveCostreamerTagSubscription",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: "LiveVideoTagSubscribeResponsePayload",
                    kind: "LinkedField",
                    name: "live_video_tag_subscribe",
                    plural: !1,
                    selections: [f, {
                        alias: null,
                        args: null,
                        concreteType: "Video",
                        kind: "LinkedField",
                        name: "tagged_video",
                        plural: !1,
                        selections: [d, {
                            alias: null,
                            args: null,
                            concreteType: "Video",
                            kind: "LinkedField",
                            name: "if_viewer_can_see_costreaming_tools",
                            plural: !1,
                            selections: [g, d],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "VideoLiveCostreamingStreamersConnection",
                            kind: "LinkedField",
                            name: "live_costreaming_streamers",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "Page",
                                kind: "LinkedField",
                                name: "nodes",
                                plural: !0,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    concreteType: "Video",
                                    kind: "LinkedField",
                                    name: "currently_live_video",
                                    plural: !1,
                                    selections: [d, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "url",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: null,
                                        kind: "LinkedField",
                                        name: "video_channel",
                                        plural: !1,
                                        selections: i,
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: null,
                                        kind: "LinkedField",
                                        name: "owner",
                                        plural: !1,
                                        selections: [h, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "name",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "Image",
                                            kind: "LinkedField",
                                            name: "profile_picture",
                                            plural: !1,
                                            selections: j,
                                            storageKey: null
                                        }, d],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "animated_image_caption",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "original_width",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "original_height",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "broadcaster_origin",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "broadcast_id",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "broadcast_status",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "dash_manifest",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_live_streaming",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_live_trace_enabled",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_looping",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_video_broadcast",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_podcast_video",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "loop_count",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_spherical",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_spherical_enabled",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "unsupported_browser_message",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "MusicVideoMetadata",
                                        kind: "LinkedField",
                                        name: "pmv_metadata",
                                        plural: !1,
                                        selections: i,
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "LatencySensitiveConfig",
                                        kind: "LinkedField",
                                        name: "latency_sensitive_config",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "broadcast_latency_sensitivity",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "LivePlaybackInstrumentationConfigParams",
                                        kind: "LinkedField",
                                        name: "live_playback_instrumentation_configs",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "is_client_triggered_trace_enabled",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_ncsr",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "permalink_url",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "captions_url",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "dash_prefetch_experimental",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoCaptionLocale",
                                        kind: "LinkedField",
                                        name: "video_available_captions_locales",
                                        plural: !0,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "localized_creation_method",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "can_use_oz",
                                        storageKey: null
                                    }, {
                                        alias: "playable_url_dash",
                                        args: [{
                                            kind: "Literal",
                                            name: "scrubbing_preference",
                                            value: "MPEG_DASH"
                                        }],
                                        kind: "ScalarField",
                                        name: "playable_url",
                                        storageKey: 'playable_url(scrubbing_preference:"MPEG_DASH")'
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "min_quality_preference",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_rss_podcast_video",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoPlayerShakaLiveP2PInit",
                                        kind: "LinkedField",
                                        name: "video_player_shaka_live_p2p_init",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "json_encoded_video_data",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "playable_url",
                                        storageKey: null
                                    }, {
                                        alias: "playable_url_quality_hd",
                                        args: [{
                                            kind: "Literal",
                                            name: "quality",
                                            value: "HD"
                                        }],
                                        kind: "ScalarField",
                                        name: "playable_url",
                                        storageKey: 'playable_url(quality:"HD")'
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "SphericalVideoFallbackUrls",
                                        kind: "LinkedField",
                                        name: "spherical_video_fallback_urls",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "hd",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "sd",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_gaming_video",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_latency_menu_enabled",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "fbls_tier",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "is_latency_sensitive_broadcast",
                                        storageKey: null
                                    }, {
                                        kind: "ClientExtension",
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "selected_latency_setting",
                                            storageKey: null
                                        }]
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "comet_video_player_static_config",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "comet_video_player_context_sensitive_config",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoPlayerShakaPerformanceLoggerInit",
                                        kind: "LinkedField",
                                        name: "video_player_shaka_performance_logger_init",
                                        plural: !1,
                                        selections: [{
                                            args: null,
                                            documentName: "useVideoPlayerShakaPerformanceLoggerRelayImpl_video",
                                            fragmentName: "useVideoPlayerShakaPerformanceLoggerRelayImpl_init",
                                            fragmentPropName: "init",
                                            kind: "ModuleImport"
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "video_player_shaka_performance_logger_should_sample",
                                        storageKey: null
                                    }, {
                                        alias: "video_player_shaka_performance_logger_init2",
                                        args: null,
                                        concreteType: "VideoPlayerShakaPerformanceLoggerInit",
                                        kind: "LinkedField",
                                        name: "video_player_shaka_performance_logger_init",
                                        plural: !1,
                                        selections: [{
                                            args: null,
                                            documentName: "useVideoPlayerShakaPerformanceLoggerBuilder_video",
                                            fragmentName: "useVideoPlayerShakaPerformanceLoggerBuilder_init",
                                            fragmentPropName: "init",
                                            kind: "ModuleImport"
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "per_session_sampling_rate",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "autoplay_gating_result",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "viewer_autoplay_setting",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "can_autoplay",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "drm_info",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoP2PSettings",
                                        kind: "LinkedField",
                                        name: "p2p_settings",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "ticket",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "VideoP2PSettingsConfig",
                                            kind: "LinkedField",
                                            name: "config",
                                            plural: !1,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "delay_p2p_until_play",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "disable_hivejava_for_livevc",
                                                storageKey: null
                                            }],
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "VideoHiveCommunityInfo",
                                            kind: "LinkedField",
                                            name: "community_info",
                                            plural: !1,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "community_id",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "community_name",
                                                storageKey: null
                                            }],
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "VideoHiveInitializationOptions",
                                            kind: "LinkedField",
                                            name: "hive_initialization_options",
                                            plural: !1,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                concreteType: "VideoHiveInitializationOptionHiveJava",
                                                kind: "LinkedField",
                                                name: "hive_java",
                                                plural: !1,
                                                selections: [{
                                                    alias: null,
                                                    args: null,
                                                    kind: "ScalarField",
                                                    name: "min_version",
                                                    storageKey: null
                                                }],
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "hive_tech_order",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "debug_level",
                                                storageKey: null
                                            }],
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "AudioSettings",
                                        kind: "LinkedField",
                                        name: "audio_settings",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "video_volume_setting",
                                            storageKey: null
                                        }, d],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "CaptionsSettings",
                                        kind: "LinkedField",
                                        name: "captions_settings",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "always_show_captions",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "captions_background_color",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "captions_background_opacity",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "captions_text_color",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "captions_text_size",
                                            storageKey: null
                                        }, d],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoBroadcastLowLatencyConfig",
                                        kind: "LinkedField",
                                        name: "broadcast_low_latency_config",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "ll_desired_latency_ms",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "ll_latency_tolerance_ms",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "audio_availability",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoMutedSegment",
                                        kind: "LinkedField",
                                        name: "muted_segments",
                                        plural: !0,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "mute_start_time_in_sec",
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "mute_end_time_in_sec",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "SphericalVideoRenderer",
                                        kind: "LinkedField",
                                        name: "spherical_video_renderer",
                                        plural: !1,
                                        selections: [{
                                            args: null,
                                            documentName: "VideoPlayerRelay_video_spherical_video_renderer",
                                            fragmentName: "VideoPlayerSphericalRelay_sphericalVideoRenderer",
                                            fragmentPropName: "sphericalVideoRenderer",
                                            kind: "ModuleImport"
                                        }],
                                        storageKey: null
                                    }, {
                                        "if": null,
                                        kind: "Defer",
                                        label: "VideoPlayerRelay_video$defer$InstreamVideoAdBreaksPlayer_video",
                                        selections: [d, {
                                            alias: null,
                                            args: null,
                                            concreteType: "InstreamExtraConfig",
                                            kind: "LinkedField",
                                            name: "instream_extra_config",
                                            plural: !1,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "instream_halo_delay_time_seconds",
                                                storageKey: null
                                            }],
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "InstreamVideoAdBreaks",
                                            kind: "LinkedField",
                                            name: "instream_video_ad_breaks_comet",
                                            plural: !1,
                                            selections: [{
                                                args: null,
                                                documentName: "InstreamVideoAdBreaksPlayer_video_instream_video_ad_breaks_comet",
                                                fragmentName: "InstreamVideoAdBreaksPlayerImpl_adBreaks",
                                                fragmentPropName: "adBreaks",
                                                kind: "ModuleImport"
                                            }],
                                            storageKey: null
                                        }]
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoThumbnail",
                                        kind: "LinkedField",
                                        name: "preferred_thumbnail",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            concreteType: "Image",
                                            kind: "LinkedField",
                                            name: "image",
                                            plural: !1,
                                            selections: j,
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "image_preview_payload",
                                            storageKey: null
                                        }, d],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "VideoIMFData",
                                        kind: "LinkedField",
                                        name: "video_imf_data",
                                        plural: !1,
                                        selections: [{
                                            args: null,
                                            documentName: "useVideoPlayerIMFFromVideoMetadataRelay_video",
                                            fragmentName: "useVideoPlayerIMFFromVideoMetadataRelay_video_imf_data",
                                            fragmentPropName: "video_imf_data",
                                            kind: "ModuleImport"
                                        }],
                                        storageKey: null
                                    }],
                                    storageKey: null
                                }, d],
                                storageKey: null
                            }],
                            storageKey: null
                        }],
                        storageKey: null
                    }, e],
                    storageKey: null
                }]
            },
            params: {
                id: b("useLiveCostreamerTagSubscription_facebookRelayOperation"),
                metadata: {
                    subscriptionName: "live_video_tag_subscribe"
                },
                name: "useLiveCostreamerTagSubscription",
                operationKind: "subscription",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("LiveVideoCometNuxForCVCQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5349533685085225"
}), null);
__d("LiveVideoCometNuxForCVCQuery.graphql", ["LiveVideoCometNuxForCVCQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "nuxID"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "videoID"
            }],
            c = [{
                kind: "Variable",
                name: "nux_id",
                variableName: "nuxID"
            }],
            d = {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "LiveVideoCometNuxForCVCQuery",
                    fragmentName: "LiveVideoCometNuxForCVCInternal_nux",
                    fragmentPropName: "nux",
                    kind: "ModuleImport"
                }],
                type: "DefaultNUX",
                abstractKey: null
            },
            e = [{
                kind: "Variable",
                name: "id",
                variableName: "videoID"
            }],
            f = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "LiveVideoCometNuxForCVCQuery",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nux",
                    plural: !1,
                    selections: [d],
                    storageKey: null
                }, {
                    alias: null,
                    args: e,
                    concreteType: "Video",
                    kind: "LinkedField",
                    name: "video",
                    plural: !1,
                    selections: [{
                        args: null,
                        kind: "FragmentSpread",
                        name: "LiveVideoCometNuxForCVCInternal_video"
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "LiveVideoCometNuxForCVCQuery",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nux",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "__typename",
                        storageKey: null
                    }, d, f],
                    storageKey: null
                }, {
                    alias: null,
                    args: e,
                    concreteType: "Video",
                    kind: "LinkedField",
                    name: "video",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_premiere",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_live_audio_room_v2_broadcast",
                        storageKey: null
                    }, f],
                    storageKey: null
                }]
            },
            params: {
                id: b("LiveVideoCometNuxForCVCQuery_facebookRelayOperation"),
                metadata: {},
                name: "LiveVideoCometNuxForCVCQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("usePOESurveyDialog_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        };
        return {
            argumentDefinitions: [],
            kind: "Fragment",
            metadata: null,
            name: "usePOESurveyDialog_video",
            selections: [{
                alias: null,
                args: null,
                concreteType: "Event",
                kind: "LinkedField",
                name: "associated_paid_online_event",
                plural: !1,
                selections: [a],
                storageKey: null
            }, a, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_live_streaming",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_paid_virtual_event_premium_content",
                storageKey: null
            }],
            type: "Video",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("useRainbowNativeSurveyDialogPlatformIntegrationPointQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5174302059348459"
}), null);
__d("useRainbowNativeSurveyDialogPlatformIntegrationPointQuery.graphql", ["useRainbowNativeSurveyDialogPlatformIntegrationPointQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "integration_point_id"
            },
            c = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            },
            d = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "session_id"
            },
            e = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "survey_context_data"
            },
            f = [{
                kind: "Variable",
                name: "integration_point_id",
                variableName: "integration_point_id"
            }],
            g = [{
                kind: "Variable",
                name: "session_id",
                variableName: "session_id"
            }, {
                kind: "Variable",
                name: "survey_context_data",
                variableName: "survey_context_data"
            }],
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "session_blob",
                storageKey: null
            },
            i = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "branch_default_page_index",
                storageKey: null
            },
            j = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "branch_question_id",
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "branch_subquestion_index_int",
                storageKey: null
            },
            l = {
                alias: null,
                args: null,
                concreteType: "StructuredSurveyBranchNodeResponseMapEntry",
                kind: "LinkedField",
                name: "branch_response_maps",
                plural: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "page_index",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "response_option_numeric_value",
                    storageKey: null
                }],
                storageKey: null
            },
            m = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "qwa_min",
                storageKey: null
            },
            n = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "qwa_page_index",
                storageKey: null
            },
            o = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "qwa_question_id",
                storageKey: null
            },
            p = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "qwa_default_page_index",
                storageKey: null
            },
            q = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "direct_next_page_index_int",
                storageKey: null
            },
            r = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "random_fallback_threshold",
                storageKey: null
            },
            s = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "random_next_page_indices",
                storageKey: null
            },
            t = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "random_next_page_weights",
                storageKey: null
            },
            u = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "fallback_page",
                storageKey: null
            },
            v = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "qe_next_page_index",
                storageKey: null
            },
            w = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "node_type",
                storageKey: null
            };
        i = [i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, {
            alias: null,
            args: null,
            concreteType: "StructuredSurveyControlNodeFlat",
            kind: "LinkedField",
            name: "composite_control_node_flat",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "parent_index",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "StructuredSurveyControlNode",
                kind: "LinkedField",
                name: "control_node",
                plural: !1,
                selections: [i, j, k, l, m, n, o, p, q, r, s, t, u, v, w],
                storageKey: null
            }],
            storageKey: null
        }];
        j = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "__typename",
            storageKey: null
        };
        k = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "question_id",
            storageKey: null
        };
        l = [k, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "amount",
            storageKey: null
        }];
        m = [{
            alias: null,
            args: null,
            concreteType: "XFBSurveyFlowDSLNodeDirective",
            kind: "LinkedField",
            name: "directives",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "target_page",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "conditions",
                plural: !0,
                selections: [j, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [k, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "subquestion",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "answer_num",
                        storageKey: null
                    }],
                    type: "XFBSurveyFlowDSLNodeAnswerEqCondition",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: l,
                    type: "XFBSurveyFlowDSLNodeAnswerCountGTECondition",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: l,
                    type: "XFBSurveyFlowDSLNodeSeenCountGTECondition",
                    abstractKey: null
                }],
                storageKey: null
            }],
            storageKey: null
        }];
        n = [{
            kind: "Literal",
            name: "is_comet_environment",
            value: !0
        }];
        o = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "text",
            storageKey: null
        };
        p = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "length",
            storageKey: null
        };
        q = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "offset",
            storageKey: null
        };
        r = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        };
        s = [o, {
            alias: null,
            args: null,
            concreteType: "InlineStyleAtRange",
            kind: "LinkedField",
            name: "inline_style_ranges",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "inline_style",
                storageKey: null
            }, p, q],
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "EntityAtRange",
            kind: "LinkedField",
            name: "ranges",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "entity",
                plural: !1,
                selections: [j, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "url",
                    storageKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [r],
                    type: "Node",
                    abstractKey: "__isNode"
                }],
                storageKey: null
            }, q, p],
            storageKey: null
        }];
        t = [o];
        u = [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "option_numeric_value",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "TextWithEntities",
            kind: "LinkedField",
            name: "option_text",
            plural: !1,
            selections: t,
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "option_value",
            storageKey: null
        }];
        return {
            fragment: {
                argumentDefinitions: [a, c, d, e],
                kind: "Fragment",
                metadata: null,
                name: "useRainbowNativeSurveyDialogPlatformIntegrationPointQuery",
                selections: [{
                    alias: null,
                    args: f,
                    concreteType: "SurveyIntegrationPoint",
                    kind: "LinkedField",
                    name: "survey_integration_point",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: g,
                        concreteType: "StructuredSurveySession",
                        kind: "LinkedField",
                        name: "survey_session",
                        plural: !1,
                        selections: [{
                            args: null,
                            kind: "FragmentSpread",
                            name: "CometRainbowNativeSurveyDialog_surveySession"
                        }, h],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [a, e, c, d],
                kind: "Operation",
                name: "useRainbowNativeSurveyDialogPlatformIntegrationPointQuery",
                selections: [{
                    alias: null,
                    args: f,
                    concreteType: "SurveyIntegrationPoint",
                    kind: "LinkedField",
                    name: "survey_integration_point",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: g,
                        concreteType: "StructuredSurveySession",
                        kind: "LinkedField",
                        name: "survey_session",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "StructuredSurvey",
                            kind: "LinkedField",
                            name: "survey",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "StructuredSurveyFlow",
                                kind: "LinkedField",
                                name: "survey_flow",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    concreteType: "StructuredSurveyControlNode",
                                    kind: "LinkedField",
                                    name: "initial_control_node",
                                    plural: !1,
                                    selections: i,
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    concreteType: "XFBSurveyFlowDSLNode",
                                    kind: "LinkedField",
                                    name: "initial_dsl",
                                    plural: !1,
                                    selections: m,
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    concreteType: "StructuredSurveyFlowPage",
                                    kind: "LinkedField",
                                    name: "structured_survey_flow_pages",
                                    plural: !0,
                                    selections: [{
                                        alias: null,
                                        args: null,
                                        concreteType: "StructuredSurveyFlowBucket",
                                        kind: "LinkedField",
                                        name: "buckets",
                                        plural: !0,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            concreteType: "StructuredSurveyConfiguredQuestion",
                                            kind: "LinkedField",
                                            name: "configured_questions",
                                            plural: !0,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "question_class",
                                                storageKey: null
                                            }, k, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "is_required",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "custom_question_params",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "custom_question_controller",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "allow_write_in_response",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "question_images",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                concreteType: null,
                                                kind: "LinkedField",
                                                name: "full_text_tokens",
                                                plural: !0,
                                                selections: [j, {
                                                    alias: null,
                                                    args: null,
                                                    kind: "ScalarField",
                                                    name: "param_name",
                                                    storageKey: null
                                                }, {
                                                    alias: null,
                                                    args: null,
                                                    kind: "ScalarField",
                                                    name: "param_type",
                                                    storageKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [k, {
                                                        alias: null,
                                                        args: null,
                                                        kind: "ScalarField",
                                                        name: "subquestion_index",
                                                        storageKey: null
                                                    }],
                                                    type: "StructuredSurveyTextTokenParamAnswerReference",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [k],
                                                    type: "StructuredSurveyTextTokenParamPreviousValue",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        alias: null,
                                                        args: null,
                                                        kind: "ScalarField",
                                                        name: "custom_hack_class",
                                                        storageKey: null
                                                    }],
                                                    type: "StructuredSurveyTextTokenParamCustomHackValue",
                                                    abstractKey: null
                                                }],
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "content_gallery_question_content_fbid",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "content_gallery_question_content_type",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: [{
                                                    kind: "Literal",
                                                    name: "supported",
                                                    value: ["QuestionCheckboxRenderer", "QuestionDropdownRenderer", "QuestionRankOrderRenderer", "QuestionContentGalleryRenderer", "QuestionCustomRenderer", "QuestionMessageRenderer", "QuestionRadioRenderer", "QuestionStarsRenderer", "QuestionTextRenderer", "QuestionRatingMatrixRenderer", "QuestionMaxDiffRenderer", "QuestionLikertRenderer", "QuestionConsentIntroRenderer", "QuestionNumericFieldRenderer"]
                                                }],
                                                concreteType: null,
                                                kind: "LinkedField",
                                                name: "question_type_renderer",
                                                plural: !1,
                                                selections: [j, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionCheckbox_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionCheckboxRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionDropdown_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionDropdownRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionRankOrder_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionRankOrderRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionContentGallery_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionContentGalleryRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionCustom_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionCustomRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyMessage_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionMessageRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionRadio_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionRadioRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionStars_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionStarsRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyText_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionTextRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionRatingMatrix_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionRatingMatrixRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionMaxDiff_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionMaxDiffRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionLikert_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionLikertRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionConsentIntro_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionConsentIntroRenderer",
                                                    abstractKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        args: null,
                                                        documentName: "QuestionRenderer_renderer",
                                                        fragmentName: "RainbowSurveyQuestionNumericField_question",
                                                        fragmentPropName: "question",
                                                        kind: "ModuleImport"
                                                    }],
                                                    type: "QuestionNumericFieldRenderer",
                                                    abstractKey: null
                                                }],
                                                storageKey: 'question_type_renderer(supported:["QuestionCheckboxRenderer","QuestionDropdownRenderer","QuestionRankOrderRenderer","QuestionContentGalleryRenderer","QuestionCustomRenderer","QuestionMessageRenderer","QuestionRadioRenderer","QuestionStarsRenderer","QuestionTextRenderer","QuestionRatingMatrixRenderer","QuestionMaxDiffRenderer","QuestionLikertRenderer","QuestionConsentIntroRenderer","QuestionNumericFieldRenderer"])'
                                            }, {
                                                alias: null,
                                                args: n,
                                                concreteType: "TextWithEntities",
                                                kind: "LinkedField",
                                                name: "body",
                                                plural: !1,
                                                selections: s,
                                                storageKey: "body(is_comet_environment:true)"
                                            }, {
                                                alias: null,
                                                args: n,
                                                concreteType: "TextWithEntities",
                                                kind: "LinkedField",
                                                name: "message",
                                                plural: !1,
                                                selections: s,
                                                storageKey: "message(is_comet_environment:true)"
                                            }, {
                                                alias: null,
                                                args: null,
                                                concreteType: "StructuredSurveyResponseOption",
                                                kind: "LinkedField",
                                                name: "response_options",
                                                plural: !0,
                                                selections: u,
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                kind: "ScalarField",
                                                name: "pipe_options_from_question_id",
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                concreteType: "StructuredSurveyResponseOption",
                                                kind: "LinkedField",
                                                name: "responses_options_from_pipe_question",
                                                plural: !0,
                                                selections: u,
                                                storageKey: null
                                            }, {
                                                alias: null,
                                                args: null,
                                                concreteType: "TextWithEntities",
                                                kind: "LinkedField",
                                                name: "subquestion_labels",
                                                plural: !0,
                                                selections: t,
                                                storageKey: null
                                            }],
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "XFBSurveyFlowDSLPage",
                                        kind: "LinkedField",
                                        name: "page_dsl",
                                        plural: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            concreteType: "XFBSurveyFlowDSLNode",
                                            kind: "LinkedField",
                                            name: "entry",
                                            plural: !1,
                                            selections: m,
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "XFBSurveyFlowDSLNode",
                                            kind: "LinkedField",
                                            name: "exit",
                                            plural: !1,
                                            selections: m,
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "StructuredSurveyControlNode",
                                        kind: "LinkedField",
                                        name: "control_node",
                                        plural: !1,
                                        selections: i,
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        concreteType: "StructuredSurveyControlNode",
                                        kind: "LinkedField",
                                        name: "before_visit_control_node",
                                        plural: !1,
                                        selections: i,
                                        storageKey: null
                                    }],
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "allow_repeats",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "flow_type",
                                    storageKey: null
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "is_last_sub_survey",
                                storageKey: null
                            }, r, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "survey_flow_type",
                                storageKey: null
                            }],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "end_of_survey_redirect_uri",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "response_id",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "SurveyConfig",
                            kind: "LinkedField",
                            name: "config",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "dialog_x_out_enabled",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "survey_header",
                                storageKey: null
                            }, r],
                            storageKey: null
                        }, h],
                        storageKey: null
                    }, r],
                    storageKey: null
                }]
            },
            params: {
                id: b("useRainbowNativeSurveyDialogPlatformIntegrationPointQuery_facebookRelayOperation"),
                metadata: {},
                name: "useRainbowNativeSurveyDialogPlatformIntegrationPointQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useVideoOriginalDimensionsRelay_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "useVideoOriginalDimensionsRelay_video",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "original_width",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "original_height",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "original_rotation",
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("LiveVideoLatencyMenuContextProvider_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "LiveVideoLatencyMenuContextProvider_video",
        selections: [{
            kind: "RequiredField",
            field: {
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "if_viewer_can_use_latency_menu",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "LiveVideoLatencyMenuContextProvider_video_if_viewer_can_use_latency_menu",
                    fragmentName: "VideoPlayerSettingsMenuLatencyPane_video",
                    fragmentPropName: "video",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            action: "NONE",
            path: "if_viewer_can_use_latency_menu"
        }, {
            kind: "RequiredField",
            field: {
                alias: "if_viewer_can_use_latency_menu_toggle",
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "if_viewer_can_use_latency_menu",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "LiveVideoLatencyMenuContextProvider_video_if_viewer_can_use_latency_menu_toggle",
                    fragmentName: "VideoPlayerSettingsMenuLatencyPaneToggle_video",
                    fragmentPropName: "video",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            action: "NONE",
            path: "if_viewer_can_use_latency_menu_toggle"
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerCaptionsControl_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "captions_url",
            storageKey: null
        };
        return {
            argumentDefinitions: [],
            kind: "Fragment",
            metadata: null,
            name: "VideoPlayerCaptionsControl_video",
            selections: [a, {
                alias: null,
                args: null,
                concreteType: "VideoCaptionLocale",
                kind: "LinkedField",
                name: "video_available_captions_locales",
                plural: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "localized_creation_method",
                    storageKey: null
                }, a, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "locale",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "localized_language",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "localized_country",
                    storageKey: null
                }],
                storageKey: null
            }],
            type: "Video",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("VideoPlayerCaptionsSettingMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "4806273429427493"
}), null);
__d("VideoPlayerCaptionsSettingMutation.graphql", ["VideoPlayerCaptionsSettingMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "data",
                    variableName: "input"
                }],
                concreteType: "VideoPlayerCaptionsSettingResponsePayload",
                kind: "LinkedField",
                name: "video_player_captions_setting",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "success",
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "VideoPlayerCaptionsSettingMutation",
                selections: c,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "VideoPlayerCaptionsSettingMutation",
                selections: c
            },
            params: {
                id: b("VideoPlayerCaptionsSettingMutation_facebookRelayOperation"),
                metadata: {},
                name: "VideoPlayerCaptionsSettingMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("VideoPlayerDefaultControlsImplLive_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerDefaultControlsImplLive_video",
        selections: [{
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerLiveVideoControls_video"
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerDefaultControlsImplNotLive_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerDefaultControlsImplNotLive_video",
        selections: [{
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerScrubberPreview_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerWatchAndScrollControl_video"
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "VideoPlayerCaptionsControl_video"
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "Video",
            kind: "LinkedField",
            name: "if_viewer_can_use_clipping",
            plural: !1,
            selections: [{
                args: null,
                documentName: "VideoPlayerDefaultControlsImplNotLive_video_if_viewer_can_use_clipping",
                fragmentName: "VideoPlayerClipVideoControl_video",
                fragmentPropName: "video",
                kind: "ModuleImport"
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerLiveVideoControls_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        };
        return {
            argumentDefinitions: [],
            kind: "Fragment",
            metadata: null,
            name: "VideoPlayerLiveVideoControls_video",
            selections: [a, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_clipping_enabled",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "live_rewind_enabled",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "owner",
                plural: !1,
                selections: [a],
                storageKey: null
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "VideoPlayerWatchAndScrollControl_video"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "LiveVideoLatencyMenuContextProvider_video"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "VideoPlayerCaptionsControl_video"
            }, {
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "if_viewer_can_see_community_moderation_tools",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "VideoPlayerLiveVideoControls_video",
                    fragmentName: "VideoPlayerModeratorControl_video",
                    fragmentPropName: "video",
                    kind: "ModuleImport"
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "if_viewer_can_use_live_rewind",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "VideoPlayerLiveVideoControls_video_if_viewer_can_use_live_rewind",
                    fragmentName: "VideoPlayerLiveRewindControlsGroup_video",
                    fragmentPropName: "video",
                    kind: "ModuleImport"
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "if_viewer_can_use_clipping",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "VideoPlayerLiveVideoControls_video_if_viewer_can_use_clipping",
                    fragmentName: "VideoPlayerClipVideoControl_video",
                    fragmentPropName: "video",
                    kind: "ModuleImport"
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "if_viewer_can_see_costreaming_tools",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "VideoPlayerLiveVideoControls_video_if_viewer_can_see_costreaming_tools",
                    fragmentName: "VideoPlayerCostreamingControl_video",
                    fragmentPropName: "video",
                    kind: "ModuleImport"
                }],
                storageKey: null
            }],
            type: "Video",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("VideoPlayerScrubberPreview_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerScrubberPreview_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "ScrubberPreview",
            kind: "LinkedField",
            name: "scrubber_preview_thumbnail_information",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "sprite_uris",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "thumbnail_width",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "thumbnail_height",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_preview_thumbnails",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "num_images_per_row",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "max_number_of_images_per_sprite",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "time_interval_between_image",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerWatchAndScrollControl_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        };
        return {
            argumentDefinitions: [],
            kind: "Fragment",
            metadata: null,
            name: "VideoPlayerWatchAndScrollControl_video",
            selections: [a, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "playable_duration_in_ms",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "owner",
                plural: !1,
                selections: [{
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "has_professional_features_for_watch",
                        storageKey: null
                    }],
                    type: "VideoOwner",
                    abstractKey: "__isVideoOwner"
                }, a],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_huddle",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "url",
                storageKey: null
            }],
            type: "Video",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("useVideoPlayerWatchAndScrollControlNUXQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "4901851916588521"
}), null);
__d("useVideoPlayerWatchAndScrollControlNUXQuery.graphql", ["useVideoPlayerWatchAndScrollControlNUXQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                kind: "Literal",
                name: "nux_id",
                value: 9347
            }],
            c = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "should_show",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: [],
                kind: "Fragment",
                metadata: null,
                name: "useVideoPlayerWatchAndScrollControlNUXQuery",
                selections: [{
                    alias: null,
                    args: a,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nux",
                    plural: !1,
                    selections: [c],
                    storageKey: "nux(nux_id:9347)"
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [],
                kind: "Operation",
                name: "useVideoPlayerWatchAndScrollControlNUXQuery",
                selections: [{
                    alias: null,
                    args: a,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nux",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "__typename",
                        storageKey: null
                    }, c, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "id",
                        storageKey: null
                    }],
                    storageKey: "nux(nux_id:9347)"
                }]
            },
            params: {
                id: b("useVideoPlayerWatchAndScrollControlNUXQuery_facebookRelayOperation"),
                metadata: {},
                name: "useVideoPlayerWatchAndScrollControlNUXQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("VideoPlayerWithAudioBackground_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerWithAudioBackground_video",
        selections: [{
            alias: null,
            args: [{
                kind: "Literal",
                name: "supported",
                value: ["CometVideoPlayerWithHuddleBackgroundRenderer", "CometVideoPlayerWithPodcastBackgroundRenderer", "CometVideoPlayerWithSoundbiteBackgroundRenderer"]
            }],
            concreteType: null,
            kind: "LinkedField",
            name: "comet_video_player_audio_background_renderer",
            plural: !1,
            selections: [{
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioBackground_video",
                    fragmentName: "CometVideoPlayerWithHuddleBackgroundRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithHuddleBackgroundRenderer",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioBackground_video",
                    fragmentName: "CometVideoPlayerWithPodcastBackgroundRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithPodcastBackgroundRenderer",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioBackground_video",
                    fragmentName: "CometVideoPlayerWithSoundbiteBackgroundRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithSoundbiteBackgroundRenderer",
                abstractKey: null
            }],
            storageKey: 'comet_video_player_audio_background_renderer(supported:["CometVideoPlayerWithHuddleBackgroundRenderer","CometVideoPlayerWithPodcastBackgroundRenderer","CometVideoPlayerWithSoundbiteBackgroundRenderer"])'
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerWithAudioOverlay_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerWithAudioOverlay_video",
        selections: [{
            alias: null,
            args: [{
                kind: "Literal",
                name: "supported",
                value: ["CometVideoPlayerWithLiveAudioRoomV2OverlayRenderer", "CometVideoPlayerWithHuddleOverlayRenderer", "CometVideoPlayerWithPodcastOverlayRenderer", "VideoPlayerWithMusicSproutOverlayRenderer", "CometVideoPlayerWithSoundbiteOverlayRenderer"]
            }],
            concreteType: null,
            kind: "LinkedField",
            name: "comet_video_player_audio_overlay_renderer",
            plural: !1,
            selections: [{
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioOverlay_video",
                    fragmentName: "CometVideoPlayerWithLiveAudioRoomV2OverlayRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithLiveAudioRoomV2OverlayRenderer",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioOverlay_video",
                    fragmentName: "CometVideoPlayerWithHuddleOverlayRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithHuddleOverlayRenderer",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioOverlay_video",
                    fragmentName: "CometVideoPlayerWithPodcastOverlayRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithPodcastOverlayRenderer",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioOverlay_video",
                    fragmentName: "VideoPlayerWithMusicSproutOverlayRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "VideoPlayerWithMusicSproutOverlayRenderer",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "VideoPlayerWithAudioOverlay_video",
                    fragmentName: "CometVideoPlayerWithSoundbiteOverlayRenderer_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                type: "CometVideoPlayerWithSoundbiteOverlayRenderer",
                abstractKey: null
            }],
            storageKey: 'comet_video_player_audio_overlay_renderer(supported:["CometVideoPlayerWithLiveAudioRoomV2OverlayRenderer","CometVideoPlayerWithHuddleOverlayRenderer","CometVideoPlayerWithPodcastOverlayRenderer","VideoPlayerWithMusicSproutOverlayRenderer","CometVideoPlayerWithSoundbiteOverlayRenderer"])'
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerWithLiveVideoEndscreen_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerWithLiveVideoEndscreen_video",
        selections: [{
            alias: null,
            args: null,
            concreteType: "TextWithEntities",
            kind: "LinkedField",
            name: "live_end_text",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "text",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_huddle",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_live_audio_room_v2_broadcast",
            storageKey: null
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "usePOESurveyDialog_video"
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("VideoPlayerWithLiveVideoIndicator_video.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "VideoPlayerWithLiveVideoIndicator_video",
        selections: [{
            alias: "breakingStatus",
            args: null,
            kind: "ScalarField",
            name: "breaking_status",
            storageKey: null
        }, {
            alias: "videoId",
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: "isPremiere",
            args: null,
            kind: "ScalarField",
            name: "is_premiere",
            storageKey: null
        }, {
            alias: "liveViewerCount",
            args: null,
            kind: "ScalarField",
            name: "live_viewer_count_read_only",
            storageKey: null
        }, {
            alias: "rehearsalInfo",
            args: null,
            concreteType: "LiveVideoRehearsalInfo",
            kind: "LinkedField",
            name: "rehearsal_info",
            plural: !1,
            selections: [{
                alias: "typeName",
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_gaming_video",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_huddle",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_live_audio_room_v2_broadcast",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "publish_time",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "Video",
            kind: "LinkedField",
            name: "live_speaker_count_indicator",
            plural: !1,
            selections: [{
                args: null,
                documentName: "VideoPlayerWithLiveVideoIndicator_video",
                fragmentName: "HuddlesSpeakerCountIndicatorContainer_video",
                fragmentPropName: "video",
                kind: "ModuleImport"
            }],
            storageKey: null
        }],
        type: "Video",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("useCometRelayExpiredVideoUrlRefreshHandlerQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "4651571778286726"
}), null);
__d("useCometRelayExpiredVideoUrlRefreshHandlerQuery.graphql", ["useCometRelayExpiredVideoUrlRefreshHandlerQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "expiredURL"
            },
            c = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "videoID"
            },
            d = [{
                kind: "Variable",
                name: "id",
                variableName: "videoID"
            }],
            e = {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "expired_url",
                    variableName: "expiredURL"
                }],
                concreteType: "RMDRefreshedUrl",
                kind: "LinkedField",
                name: "rmd_refreshed_url",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "new_url",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "reason",
                    storageKey: null
                }],
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: [a, c],
                kind: "Fragment",
                metadata: null,
                name: "useCometRelayExpiredVideoUrlRefreshHandlerQuery",
                selections: [{
                    alias: null,
                    args: d,
                    concreteType: "Video",
                    kind: "LinkedField",
                    name: "video",
                    plural: !1,
                    selections: [e],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [c, a],
                kind: "Operation",
                name: "useCometRelayExpiredVideoUrlRefreshHandlerQuery",
                selections: [{
                    alias: null,
                    args: d,
                    concreteType: "Video",
                    kind: "LinkedField",
                    name: "video",
                    plural: !1,
                    selections: [e, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "id",
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("useCometRelayExpiredVideoUrlRefreshHandlerQuery_facebookRelayOperation"),
                metadata: {},
                name: "useCometRelayExpiredVideoUrlRefreshHandlerQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("encodeNUXIDForRelay", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = "NUX_ID:";

    function a(a) {
        return typeof a === "string" && a.startsWith(g) ? {
            nuxID: Number(a.replace(g, "")),
            relayID: a
        } : {
            nuxID: Number(a),
            relayID: g + a
        }
    }
    f["default"] = a
}), 66);
__d("CometDismissFBNuxMutation", ["CometDismissFBNuxMutation.graphql", "CometRelay", "encodeNUXIDForRelay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("CometDismissFBNuxMutation.graphql");

    function a(a, b, e, f) {
        b = c("encodeNUXIDForRelay")(b);
        var g = b.nuxID;
        b = b.relayID;
        return d("CometRelay").commitMutation(a, {
            mutation: i,
            onCompleted: e,
            onError: f,
            optimisticResponse: {
                nux_dismiss: {
                    __typename: "NUX",
                    id: b,
                    should_show: !1
                }
            },
            variables: {
                nux_id_input: g
            }
        })
    }
    g.commit = a
}), 98);
__d("CometLogImpressionFBNuxMutation", ["CometLogImpressionFBNuxMutation.graphql", "CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation.graphql", "CometRelay", "encodeNUXIDForRelay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = h !== void 0 ? h : h = b("CometLogImpressionFBNuxMutation.graphql");

    function a(a, b, e, f) {
        b = c("encodeNUXIDForRelay")(b);
        b = b.nuxID;
        return d("CometRelay").commitMutation(a, {
            mutation: j,
            onCompleted: e,
            onError: f,
            variables: {
                nux_id: b
            }
        })
    }
    var k = i !== void 0 ? i : i = b("CometLogImpressionFBNuxMutationWithNoImpressionLimitMutation.graphql");

    function e(a, b, e, f) {
        b = c("encodeNUXIDForRelay")(b);
        b = b.nuxID;
        return d("CometRelay").commitMutation(a, {
            mutation: k,
            onCompleted: e,
            onError: f,
            variables: {
                nux_id: b
            }
        })
    }
    g.commit = a;
    g.commitNuxWithNoImpressionLimit = e
}), 98);
__d("isRecentProfileSwitchSessionStorage", ["WebStorage"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getAndRemove: function() {
            var a, b;
            a = (a = c("WebStorage").getSessionStorage()) == null ? void 0 : a.getItem("comet_is_recent_profile_switch");
            if (a == null) return null;
            (b = c("WebStorage").getSessionStorage()) == null ? void 0 : b.removeItem("comet_is_recent_profile_switch");
            try {
                b = JSON.parse(a);
                return {
                    didSwitchToMainProfile: (b == null ? void 0 : b.didSwitchToMainProfile) === !0
                }
            } catch (a) {
                return null
            }
        },
        set: function(a) {
            c("WebStorage").setItemGuarded(c("WebStorage").getSessionStorage(), "comet_is_recent_profile_switch", JSON.stringify(a))
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("profileCometSwitcherCleanup", ["Banzai", "UserMismatchExpected", "WebStorage", "isRecentProfileSwitchSessionStorage", "previousProfileIdForToastSessionStorage", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("Cookie").__setRef("profileCometSwitcherCleanup"),
        i = c("requireDeferred")("ServiceWorkerLoginAndLogout").__setRef("profileCometSwitcherCleanup"),
        j = c("requireDeferred")("WebStorageMonster").__setRef("profileCometSwitcherCleanup");

    function a(a, b, e) {
        var f = e.fromCDSSwitcher,
            g = f === void 0 ? !1 : f,
            k = e.isSwitchingToMainProfile,
            l = e.withPostSwitchLogging;
        j.onReady(function(d) {
            d.cleanOnLogout(b), c("previousProfileIdForToastSessionStorage").set(a), g && c("WebStorage").setItemGuarded(c("WebStorage").getSessionStorage(), "did_profile_switch_come_from_switcher", "1"), l && c("isRecentProfileSwitchSessionStorage").set({
                didSwitchToMainProfile: k
            })
        });
        h.onReady(function(a) {
            a.clear("presence", "/")
        });
        i.onReady(function(a) {
            a.logout()
        });
        c("Banzai").flush();
        d("UserMismatchExpected").setIsUserMismatchExpected(!0);
        window.setTimeout(function() {
            return d("UserMismatchExpected").setIsUserMismatchExpected(!1)
        }, 6e4)
    }
    g["default"] = a
}), 98);
__d("CometProductTagFunnelIDContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometMenuBase.react", ["fbt", "ix", "BaseScrollableArea.react", "CometErrorBoundary.react", "CometFocusGroupFirstLetterNavigation", "CometListCellStrict.react", "CometMenuFocusGroup", "CometMenuItemBaseRoleContext", "CometSeparatorMenuItem.react", "FocusRegion.react", "TetraTextPairing.react", "fbicon", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = 145,
        l = {
            listItem: {
                borderTopStartRadius: "x1lcm9me",
                borderTopEndRadius: "x1yr5g0i",
                borderBottomEndRadius: "xrt01vj",
                borderBottomStartRadius: "x10y3i5r",
                display: "x78zum5",
                flexDirection: "x1q0g3np",
                marginTop: "xdj266r",
                marginEnd: "x1emribx",
                marginBottom: "xat24cr",
                marginStart: "x1i64zmx",
                paddingTop: "xz9dl7a",
                paddingEnd: "x1sxyh0",
                paddingBottom: "xsag5q8",
                paddingStart: "xurb0ha"
            },
            root: {
                alignItems: "x1qjc9v5",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                paddingEnd: "x4uap5",
                paddingStart: "xkhd6sd",
                paddingTop: "x1ten1a2",
                paddingBottom: "xz7cn9q"
            },
            sizeFull: {
                marginEnd: "xzy4u6w",
                width: "xh8yej3"
            },
            sizeNormal: {
                width: "x168biu4"
            },
            sizeSmall: {
                width: "xi55695"
            }
        },
        m = "menu",
        n = {
            listbox: "option",
            menu: "menuitem"
        };

    function a(a) {
        var b = a.children,
            e = a.footer,
            f = a.header,
            g = a.maxHeight,
            o = a.role;
        o = o === void 0 ? m : o;
        a = a.size;
        a = a === void 0 ? "normal" : a;
        var p = 0,
            q = j.Children.toArray(b).map(function(a) {
                if (a == null) return null;
                var b = p++;
                return a.type === c("CometSeparatorMenuItem.react") ? a : j.jsx(c("CometErrorBoundary.react"), {
                    children: a
                }, b)
            });
        o = n[o];
        return j.Children.count(b) > 0 ? j.jsx(c("BaseScrollableArea.react"), {
            horizontal: !1,
            style: g != null ? {
                maxHeight: Math.max(g, k)
            } : void 0,
            vertical: !0,
            xstyle: [l.root, a === "full" && l.sizeFull, a === "normal" && l.sizeNormal, a === "small" && l.sizeSmall],
            children: j.jsxs(c("CometMenuItemBaseRoleContext").Provider, {
                value: o,
                children: [f != null ? j.jsxs(j.Fragment, {
                    children: [f.onPressBack != null ? j.jsx(c("CometListCellStrict.react"), {
                        addOnStart: {
                            "aria-label": h._("Back"),
                            icon: d("fbicon")._(i("512665"), 24),
                            onPress: f.onPressBack,
                            type: "icon"
                        },
                        addOnStartVerticalAlign: "center",
                        emphasized: !1,
                        headline: f.title,
                        level: 3,
                        meta: f.meta,
                        paddingHorizontal: 8
                    }) : j.jsx("div", {
                        className: c("stylex")([l.listItem]),
                        children: j.jsx(c("TetraTextPairing.react"), {
                            body: f.body,
                            headline: f.title,
                            level: 3,
                            meta: f.meta,
                            reduceEmphasis: !0
                        })
                    }), j.jsx(c("CometSeparatorMenuItem.react"), {})]
                }) : null, j.jsx(d("FocusRegion.react").FocusRegion, {
                    autoFocusQuery: (f == null ? void 0 : f.onPressBack) ? d("focusScopeQueries").tabbableScopeQuery : null,
                    children: j.jsx(c("CometMenuFocusGroup").FocusGroup, {
                        onNavigate: d("CometFocusGroupFirstLetterNavigation").handleFirstLetterNavigation,
                        orientation: "vertical",
                        preventScrollOnFocus: !1,
                        tabScopeQuery: d("focusScopeQueries").tabbableScopeQuery,
                        wrap: !0,
                        children: q
                    })
                }), e != null ? j.jsxs(j.Fragment, {
                    children: [j.jsx(c("CometSeparatorMenuItem.react"), {}), j.jsx("div", {
                        className: c("stylex")(l.listItem),
                        children: j.jsx(c("TetraTextPairing.react"), {
                            level: 3,
                            meta: e.text
                        })
                    })]
                }) : null]
            })
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometMenuBaseWithPopover.react", ["BaseContextualLayerAvailableHeightContext", "BaseMultiPageView.react", "CometMenuBase.react", "CometPopover.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = 15,
        k = "menu";

    function a(a, b) {
        var d = a.children,
            e = a.id,
            f = a.label,
            g = a.role;
        g = g === void 0 ? k : g;
        var l = a.arrowAlignment,
            m = a.withArrow;
        m = m === void 0 ? !1 : m;
        var n = a.testid;
        n = n === void 0 ? "comet-menu" : n;
        n = a.truncate;
        n = n === void 0 ? !1 : n;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "id", "label", "role", "arrowAlignment", "withArrow", "testid", "truncate"]);
        var o = i(c("BaseContextualLayerAvailableHeightContext"));
        m && o != null && (o -= j);
        return h.Children.count(d) > 0 ? h.jsx(c("CometPopover.react"), {
            arrowAlignment: l,
            id: e,
            label: f,
            ref: b,
            role: g,
            testid: void 0,
            withArrow: m,
            children: h.jsx(c("BaseMultiPageView.react"), {
                disableAutoFocus: !0,
                disableFocusContainment: !0,
                children: h.jsx(c("CometMenuBase.react"), babelHelpers["extends"]({}, a, {
                    children: d,
                    maxHeight: n ? (l = o) != null ? l : 0 : void 0,
                    role: g
                }))
            })
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.memo(h.forwardRef(a));
    g["default"] = b
}), 98);
__d("CometMenu.react", ["CometMenuBaseWithPopover.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        return h.jsx(c("CometMenuBaseWithPopover.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseAccessibleElement_DEPRECATED.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children;
        a = a.id;
        return h.jsx("span", {
            className: "x1i1rx1s x10l6tqk x10wlt62 x6ikm8r xjm9jq1 x1hyvwdk xzpqnlu",
            "data-html2canvas-ignore": "true",
            id: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogStartAlignedTextHeader.react", ["fbt", "CometCircleButton.react", "CometDialogHeaderContainer.react", "CrossFilled24.svg.react", "TetraText.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.closeTestID;
        b = b === void 0 ? "close-button" : b;
        b = a.disabled;
        b = b === void 0 ? !1 : b;
        var d = a.withCloseButton;
        d = d === void 0 ? !0 : d;
        var e = a.onClose;
        e = e === void 0 ? c("emptyFunction") : e;
        var f = a.text;
        a = a.id;
        return i.jsxs(c("CometDialogHeaderContainer.react"), {
            children: [f != null && i.jsx("div", {
                className: "x1yztbdb xw7yly9 x1d52u69",
                children: i.jsx(c("TetraText.react"), {
                    align: "start",
                    id: a,
                    isSemanticHeading: !0,
                    type: "headlineEmphasized2",
                    children: f
                })
            }), i.jsx("div", {
                className: "xod5an3 x14vqqas x1d52u69 xktsk01 xqcrz7y",
                children: d ? i.jsx(c("CometCircleButton.react"), {
                    disabled: b,
                    icon: c("CrossFilled24.svg.react"),
                    label: h._("Close"),
                    onPress: e,
                    size: 36,
                    testid: void 0
                }) : i.jsx("div", {
                    className: "x14qfxbe x1yztbdb xw7yly9 xc9qbxq"
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometAlertDialogImpl.react", ["fbt", "CometDialog.react", "CometDialogFooter.react", "CometDialogStartAlignedTextHeader.react", "TetraText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.body,
            d = a.close,
            e = a.onClose;
        a = a.title;
        return i.jsx(c("CometDialog.react"), {
            footer: i.jsx(c("CometDialogFooter.react"), {
                expanding: !1,
                primary: {
                    label: (d = d) != null ? d : h._("Close"),
                    onPress: e,
                    testid: "CometAlertDialogImpl-closeButton"
                }
            }),
            header: i.jsx(c("CometDialogStartAlignedTextHeader.react"), {
                onClose: e,
                text: a
            }),
            label: a,
            children: i.jsx("div", {
                className: "x1n2onr6 x1swvt13 x1pi30zi",
                children: i.jsx(c("TetraText.react"), {
                    type: "body3",
                    children: b
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTwoButtonDialogImpl.react", ["fbt", "CometDialog.react", "CometDialogConfirmationFooter.react", "CometDialogHeader.react", "CometTrackingNodeProvider.react", "TetraText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = {
            dialog: "comet-two-button-dialog",
            primary: "comet-two-button-dialog-primary",
            secondary: "comet-two-button-dialog-secondary"
        };

    function a(a) {
        var b = a.body,
            d = a.disabled;
        d = d === void 0 ? !1 : d;
        var e = a.onClose,
            f = a.primary,
            g = a.secondary,
            k = a.testids;
        k = k === void 0 ? j : k;
        a = a.title;
        return i.jsx(c("CometTrackingNodeProvider.react"), {
            trackingNode: 163,
            children: i.jsx(c("CometDialog.react"), {
                footer: i.jsx(c("CometDialogConfirmationFooter.react"), {
                    primary: {
                        disabled: d,
                        label: (f = f) != null ? f : h._("Confirm"),
                        onPress: function() {
                            return e("PRIMARY")
                        },
                        testid: k.primary
                    },
                    secondary: {
                        disabled: d,
                        label: (f = g) != null ? f : h._("Cancel"),
                        onPress: function() {
                            return e("SECONDARY")
                        },
                        testid: k.secondary
                    }
                }),
                header: i.jsx(c("CometDialogHeader.react"), {
                    onClose: function() {
                        return e("EXIT")
                    },
                    text: a,
                    withCloseButton: !0
                }),
                label: a,
                onClose: function() {
                    return e("EXIT")
                },
                testid: void 0,
                children: i.jsx("div", {
                    className: "x1n2onr6 x1swvt13 xsag5q8 x1pi30zi xz9dl7a",
                    children: i.jsx(c("TetraText.react"), {
                        type: "body3",
                        children: b
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometConfirmationDialogImpl.react", ["CometTwoButtonDialogImpl.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.body,
            d = a.cancel,
            e = a.confirm,
            f = a.disabled;
        f = f === void 0 ? !1 : f;
        var g = a.onClose;
        a = a.title;
        return h.jsx(c("CometTwoButtonDialogImpl.react"), {
            body: b,
            disabled: f,
            onClose: function(a) {
                return g(a === "PRIMARY")
            },
            primary: e,
            secondary: d,
            testids: {
                dialog: "CometConfirmationDialogImpl",
                primary: "CometConfirmationDialogConfirmButton",
                secondary: "CometConfirmationDialogCancelButton"
            },
            title: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometEmojiWithContextualSize.react", ["CometTextContext", "CometTextTypography", "cr:244", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = new Map([
            [16, 16],
            [20, 16],
            [24, 20],
            [28, 24],
            [32, 30],
            [38, 32]
        ]);

    function k() {
        var a = i(c("CometTextContext"));
        a = (a = a == null ? void 0 : a.type) != null ? a : "body4";
        var b = 16;
        a != null && (a in c("CometTextTypography") && (b = c("CometTextTypography")[a].lineHeight));
        return (a = j.get(b)) != null ? a : 16
    }

    function a(a) {
        var c = k();
        c = a.size != null ? a.size : c;
        return a.renderCustomEmoji ? a.renderCustomEmoji(c) : h.jsx(b("cr:244"), babelHelpers["extends"]({}, a, {
            size: c
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometToastCard.react", ["fbt", "ix", "CometAccessibilityAnnouncement.react", "CometCard.react", "CometIcon.react", "CometPressable.react", "TetraTextPairing.react", "fbicon", "react", "useCometUniqueID"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.accessibilityAnnouncement,
            e = a.content,
            f = a.headline,
            g = a.onCloseClick;
        a = a.onMouseEnter;
        var k = c("useCometUniqueID")();
        return j.jsx(c("CometCard.react"), {
            background: "white",
            dropShadow: 2,
            children: j.jsxs("div", {
                "aria-labelledby": k,
                className: "xi55695 x6prxxf xdt5ytf x78zum5 x9f619 xh5kl08 x9jhf4c x30kzoy xgqcy7u x1lq5wgf",
                onMouseEnter: a,
                role: "complementary",
                children: [j.jsx("div", {
                    className: "x14vqqas",
                    children: j.jsxs("div", {
                        className: "x1swvt13 x18d9i69 x1pi30zi xexx8yu x1qughib x78zum5 x6s0dn4",
                        children: [j.jsx("div", {
                            id: k,
                            children: j.jsx(c("TetraTextPairing.react"), {
                                headline: f,
                                level: 4
                            })
                        }), j.jsx(c("CometPressable.react"), {
                            display: "inline",
                            label: h._("Close"),
                            onPress: g,
                            overlayDisabled: !0,
                            children: j.jsx("span", {
                                className: "xvy4d1p xl56j7k xxk0z11 x78zum5 x15gyhx8 x1s7lred x40j3uw xnwf7zb x1qhmfi1 x6s0dn4",
                                children: j.jsx(c("CometIcon.react"), {
                                    color: "primary",
                                    icon: d("fbicon")._(i("478231"), 12),
                                    size: 12
                                })
                            })
                        })]
                    })
                }), j.jsx("div", {
                    className: "x1iorvi4 xwib8y2 x1sqdly8",
                    children: e
                }), b != null && j.jsx(c("CometAccessibilityAnnouncement.react"), {
                    children: b.text
                }, b.id)]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useLiveCostreamerTagSubscription.react", ["CometRelay", "react", "useLiveCostreamerTagSubscription.graphql", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useMemo;

    function a(a, e, f) {
        var g = h !== void 0 ? h : h = b("useLiveCostreamerTagSubscription.graphql"),
            j = i(function() {
                return {
                    onNext: f,
                    subscription: g,
                    updater: function(a) {
                        var b;
                        a = a.getRootField("live_video_tag_subscribe");
                        b = a == null ? void 0 : (b = a.getLinkedRecord("tagged_page")) == null ? void 0 : b.getLinkedRecord("currently_live_video");
                        a = a == null ? void 0 : a.getLinkedRecord("tagged_video");
                        b == null && a != null && a.setValue(null, "if_viewer_can_see_costreaming_tools")
                    },
                    variables: {
                        input: {
                            client_subscription_id: c("uuid")(),
                            tagged_page_id: a,
                            tagged_video_id: e
                        }
                    }
                }
            }, [f, a, g, e]);
        d("CometRelay").useSubscription(j)
    }
    g["default"] = a
}), 98);
__d("LiveCostreamerTagSubscription.react", ["useLiveCostreamerTagSubscription.react"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        c("useLiveCostreamerTagSubscription.react")(a.pageID, a.videoID, a.onNext);
        return null
    }
    g["default"] = a
}), 98);
__d("LiveVideoCometNuxForCVC.react", ["CometPlaceholder.react", "CometRelay", "LiveVideoCometNuxForCVCQuery.graphql", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react"),
        j = h !== void 0 ? h : h = b("LiveVideoCometNuxForCVCQuery.graphql");

    function a(a) {
        a = a.videoID;
        a = d("CometRelay").useLazyLoadQuery(j, {
            nuxID: 8030,
            videoID: a
        });
        return i.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            children: i.jsx(d("CometRelay").MatchContainer, {
                match: a.nux,
                props: {
                    video: a.video
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTrackingCodeProvider.react", ["CometTrackingCodeContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function k(a, b) {
        return a && a !== "" ? b.concat(a) : b
    }

    function a(a) {
        var b = a.children;
        a = a.trackingCode;
        var d = a.click_tracking_linkshim_cb,
            e = a.encrypted_click_tracking,
            f = a.encrypted_tracking,
            g = i(c("CometTrackingCodeContext"));
        a = j(function() {
            return {
                click_tracking_linkshim_cb: k(d, g.click_tracking_linkshim_cb),
                encrypted_click_tracking: k(e, g.encrypted_click_tracking),
                encrypted_tracking: k(f, g.encrypted_tracking)
            }
        }, [g, d, e, f]);
        return h.jsx(c("CometTrackingCodeContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.memo(a);
    g["default"] = e
}), 98);
__d("getAggregatedStoryTrackingNodeIndex", ["TrackingNodes"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = c("TrackingNodes").parseTrackingNodeString(a.join(""));
        var b = 0;
        for (var d = 0; d < a.length; d++)
            if (a[d][0] === 340 && a[d].length > 1) {
                b = a[d][1];
                return b
            }
        return b
    }
    g["default"] = a
}), 98);
__d("CometPageVerificationIcon.react", ["fbt", "ix", "CometImage.react", "TetraIcon.react", "fbicon", "react", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.isInverted,
            e = a.size;
        a = a.verificationBadge;
        var f = c("useCurrentDisplayMode")();
        f = f === "dark";
        var g = null,
            k = d("fbicon")._(i("498144"), 12),
            l = 12;
        e === "large" && (l = 16, k = d("fbicon")._(i("498145"), 16));
        if (b === !0) g = j.jsx(c("TetraIcon.react"), {
            alt: h._("Verified account"),
            color: "white",
            icon: k,
            size: l
        });
        else switch (a) {
            case "BLUE_VERIFIED":
                e === "large" ? b = f ? i("1510597") : i("1510599") : b = f ? i("1510593") : i("1510595");
                g = j.jsx(c("CometImage.react"), {
                    alt: h._("Verified account"),
                    height: l,
                    src: b,
                    width: l
                });
                break;
            case "GRAY_VERIFIED":
                g = j.jsx(c("TetraIcon.react"), {
                    alt: h._("Verified account"),
                    color: "secondary",
                    icon: k,
                    size: l
                });
                break
        }
        return g != null ? j.jsx("span", {
            className: "x11njtxf x3nfvp2",
            children: g
        }) : null
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useRainbowNativeSurveyDialog", ["CometRelay", "JSResourceForInteraction", "WebPixelRatio", "emptyFunction", "promiseDone", "react", "useCometLazyDialog", "useRainbowNativeSurveyDialogPlatformIntegrationPointQuery.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useCallback,
        j = c("JSResourceForInteraction")("CometRainbowNativeSurveyDialog.react").__setRef("useRainbowNativeSurveyDialog"),
        k = h !== void 0 ? h : h = b("useRainbowNativeSurveyDialogPlatformIntegrationPointQuery.graphql");

    function a(a, b, e, f) {
        var g = d("CometRelay").useRelayEnvironment(),
            h = c("useCometLazyDialog")(j),
            l = h[0];
        return i(function(h, i, j, m) {
            var n;
            j = ((n = b) != null ? n : []).concat((n = j) != null ? n : []);
            c("promiseDone")(d("CometRelay").fetchQuery(g, k, {
                integration_point_id: a,
                scale: d("WebPixelRatio").get(),
                session_id: e,
                survey_context_data: (n = j) != null ? n : []
            }, {
                fetchPolicy: "network-only"
            }).toPromise().then(function(a) {
                a = a == null ? void 0 : (a = a.survey_integration_point) == null ? void 0 : a.survey_session;
                (a == null ? void 0 : a.session_blob) ? l({
                    hideThankYou: f,
                    onOpenCallback: i,
                    surveySession: a
                }, h ? h : c("emptyFunction")()): m != null && m()
            }))
        }, [b, f, g, a, e, l])
    }
    g["default"] = a
}), 98);
__d("usePOESurveyDialog", ["CometRelay", "emptyFunction", "usePOESurveyDialog_video.graphql", "useRainbowNativeSurveyDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = "2683796868609644";

    function a(a) {
        var e;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("usePOESurveyDialog_video.graphql"), a);
        var f = c("useRainbowNativeSurveyDialog")(i, [{
            context_key: "event_id",
            context_value: (e = a == null ? void 0 : (e = a.associated_paid_online_event) == null ? void 0 : e.id) != null ? e : ""
        }, {
            context_key: "video_id",
            context_value: (e = a == null ? void 0 : a.id) != null ? e : ""
        }]);
        return (a == null ? void 0 : a.is_live_streaming) === !0 && (a == null ? void 0 : a.is_paid_virtual_event_premium_content) === !0 ? function() {
            f()
        } : c("emptyFunction")
    }
    g["default"] = a
}), 98);
__d("CometSeeMoreExpandingUtils", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        var c = b;
        while (c >= 0) {
            if (a.charAt(c) === " " || a.charAt(c) === "\n") break;
            c -= 1
        }
        a.charAt(b) !== "\n" ? c += 1 : c = b + 1;
        b = a.substring(c);
        a = /\s/;
        b = b.search(a) + c - 1;
        return {
            truncatedEntityEndIndex: b,
            truncatedEntityOffset: c
        }
    }

    function i(a, b, c) {
        var d = [];
        b = h(b, c);
        c = b.truncatedEntityEndIndex;
        b = b.truncatedEntityOffset;
        b = b;
        var e = !1;
        for (var a = a, f = Array.isArray(a), g = 0, a = f ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var i;
            if (f) {
                if (g >= a.length) break;
                i = a[g++]
            } else {
                g = a.next();
                if (g.done) break;
                i = g.value
            }
            i = i;
            var j = i.entity,
                k = i.entity_type,
                l = i.length;
            i = i.offset;
            i != null && l != null && j != null && j.__typename != null && (d.push({
                entity: j,
                entity_type: k,
                length: l,
                offset: i
            }), !e && i + l >= c && b >= i && (b = i, e = !0))
        }
        e || d.push({
            entity: {
                __typename: "SeeMoreTruncation"
            },
            entity_type: "SEE_MORE_ANCHOR",
            length: 0,
            offset: b
        });
        return {
            newEntityRanges: d,
            newTruncatedEntityOffset: b
        }
    }

    function j(a, b) {
        var c = [],
            d = [];
        if (b != null)
            for (var a = a, e = Array.isArray(a), f = 0, a = e ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var g;
                if (e) {
                    if (f >= a.length) break;
                    g = a[f++]
                } else {
                    f = a.next();
                    if (f.done) break;
                    g = f.value
                }
                g = g;
                var h = g.entity,
                    i = g.entity_type,
                    j = g.length;
                g = g.offset;
                g != null && j != null && h != null && h.__typename != null && (g < b ? c.push({
                    entity: h,
                    entity_type: i,
                    length: j,
                    offset: g
                }) : d.push({
                    entity: h,
                    entity_type: i,
                    length: j,
                    offset: g - b
                }))
            }
        return {
            entitiesBeforeTruncatedOffset: c,
            entitiesFromTruncatedOffset: d
        }
    }

    function k(a, b, c) {
        a = i(a, b, c);
        b = a.newEntityRanges;
        c = a.newTruncatedEntityOffset;
        a = j(b, c);
        b = a.entitiesBeforeTruncatedOffset;
        a = a.entitiesFromTruncatedOffset;
        return {
            entitiesBeforeTruncatedOffset: b,
            entitiesFromTruncatedOffset: a,
            newTruncatedEntityOffset: c
        }
    }

    function a(a, b, d) {
        var e = [],
            f = [],
            g = -1,
            h = -1,
            i = -1;
        if (!a || !c("gkx")("3236")) return {
            filteredEntitiesBeforeTruncatedPosition: e,
            filteredEntitiesFromTruncatedPosition: f,
            hiddenContentOffset: g,
            truncatedLineIndex: h,
            truncatedParagraphIndex: i
        };
        a = 0;
        var j;
        for (var l = 0; l < b.length; l++) {
            var m = b[l];
            if (Array.isArray(m) && d != null && d.current != null) {
                var n = d.current;
                for (var o = 0; o < m.length; o++) {
                    var p = m[o].ranges,
                        q = m[o].text,
                        r = q.length;
                    j = n - a;
                    a += r;
                    if (i < 0 && j >= 0 && a >= n) {
                        i = l;
                        h = o;
                        j = k(p, q, n - a + r);
                        p = j.entitiesBeforeTruncatedOffset;
                        q = j.entitiesFromTruncatedOffset;
                        r = j.newTruncatedEntityOffset;
                        e = p;
                        f = q;
                        g = r;
                        break
                    }
                }
            }
            if (i >= 0 && h >= 0) break
        }
        return {
            filteredEntitiesBeforeTruncatedPosition: e,
            filteredEntitiesFromTruncatedPosition: f,
            hiddenContentOffset: g,
            truncatedLineIndex: h,
            truncatedParagraphIndex: i
        }
    }

    function b(a, b, c, d) {
        var e = [],
            f = !1,
            g = 0,
            h = -1,
            j = 0;
        for (var k = 0; k < a.length; k++) {
            var l = b - g,
                m = a[k],
                n = m.text;
            if (typeof n === "string") {
                var o = n.length,
                    p = c && k === d,
                    q = h === -1 && (l <= 0 || l > 0 && o > l && n.trim().length > l || p);
                if (q) {
                    q = p || l <= 0 ? 0 : l;
                    p = i(m.entity_ranges, n, q);
                    l = p.newEntityRanges;
                    q = p.newTruncatedEntityOffset;
                    e.push(babelHelpers["extends"]({}, m, {
                        entity_ranges: l,
                        text: n
                    }));
                    h = k;
                    j = q;
                    g += o;
                    continue
                }
                g += o
            }
            e.push(m)
        }
        return {
            composedText: e,
            hiddenContentOffset: j,
            splitWithinBlock: f,
            truncatedBlockIndex: h
        }
    }
    g.getTruncatedEntityRangesAfterExpandingSeeMore = i;
    g.splitEntityRangesIntoRegularAndHiddenParts = j;
    g.getEntityRangesWithTruncatedEntityAndSplitIntoTwoParts = k;
    g.filterParagraphsGetTruncatedLinesEntityRangesAndIndex = a;
    g.getBlockComposedTextWithWrapper = b
}), 98);
__d("CometTextWithEntitiesBase.react", ["UnicodeUtils", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = h.Fragment;

    function j(a) {
        return Array.from(a).sort(function(a, b) {
            return a.offset - b.offset || b.length - a.length
        })
    }

    function k(a, b) {
        return b != null ? b.reduce(function(a, b) {
            return b(a)
        }, a) : a
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function l(a, b, c, d, e, f, g, j, k) {
        var l = a.__typename;
        j = Object.prototype.hasOwnProperty.call(j, l) ? j[l].concat(k) : k;
        return h.jsx(i, {
            children: j && j.length > 0 ? j.reduce(function(d, f) {
                return f(d, a, c, e, b)
            }, f) : d
        }, g)
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function m(a, b, c, e, f, g, j, m, n, o, p, q) {
        a = d("UnicodeUtils").substr(a, b, c - b);
        c = n.length;
        a.length > 0 && m.push(h.jsx(i, {
            children: k(a, o)
        }, "c" + b + "_" + c + "_" + q));
        o = n.pop();
        n[n.length - 1].subElements.push(l(e, f, g, m, a, m, b + "_" + c + "_" + q, j, p));
        return o
    }

    function a(a) {
        var b = a.ranges;
        b = b === void 0 ? [] : b;
        var e = a.renderers,
            f = a.transforms,
            g = f === void 0 ? [] : f,
            n = a.text;
        f = a.disableRangeSort;
        a = f === void 0 ? !1 : f;
        var o = (f = e) != null ? f : {},
            p = 0,
            q = (e = Object.prototype.hasOwnProperty.call(o, "*") ? o["*"] : []) != null ? e : [];
        f = a ? b : j(b);
        var r = [{
            entity: {
                __typename: ""
            },
            entity_is_weak_reference: !1,
            entityType: "",
            length: n.length,
            offset: 0,
            subElements: []
        }];
        if (!c("gkx")("1779648"))
            for (var e = 0; e < f.length; ++e) {
                a = f[e];
                b = a.entity;
                var s = a.entity_is_weak_reference,
                    t = a.entity_type,
                    u = a.length;
                a = a.offset;
                if (p >= n.length || a > n.length) break;
                var v = r[r.length - 1],
                    w = v.entity,
                    x = v.entity_is_weak_reference,
                    y = v.entityType,
                    z = v.length,
                    A = v.offset;
                v = v.subElements;
                var B = A + z;
                while (B <= a && r.length > 1) {
                    m(n, p, B, w, x, y, o, v, r, g, q, e);
                    p = B;
                    var C = r[r.length - 1];
                    w = C.entity;
                    x = C.entity_is_weak_reference;
                    y = C.entityType;
                    z = C.length;
                    A = C.offset;
                    v = C.subElements;
                    B = A + z
                }
                p < a && (r[r.length - 1].subElements.push(h.jsx(i, {
                    children: k(d("UnicodeUtils").substr(n, p, a - p), g)
                }, "c" + p + "_" + r.length)), p = a);
                if (A <= a && B >= a + u) {
                    r.push({
                        entity: b,
                        entity_is_weak_reference: (C = s) != null ? C : null,
                        entityType: (B = t) != null ? B : null,
                        length: u,
                        offset: a,
                        subElements: []
                    })
                } else {
                    var D;
                    C = d("UnicodeUtils").substr(n, a, u);
                    B = k(C, g);
                    r[r.length - 1].subElements.push(l(b, (D = s) != null ? D : null, (D = t) != null ? D : null, C, C, B, p + "_" + r.length, o, q));
                    p = a + u
                }
            } else {
                var E = [];
                f.forEach(function(a) {
                    E.push({
                        index: a.offset,
                        range: a,
                        type: "start"
                    }), E.push({
                        index: a.offset + a.length,
                        range: a,
                        type: "end"
                    })
                });
                E.sort(function(a, b) {
                    if (a.index !== b.index) return a.index - b.index;
                    return a.type !== b.type ? a.range === b.range ? b.type === "start" ? 1 : -1 : b.type === "end" ? 1 : -1 : 0
                });
                var F = 0;
                while (F < E.length) {
                    var G = E[F];
                    if (p >= n.length || G.index > n.length) break;
                    if (G.type === "start") {
                        if (G.index > p) {
                            D = d("UnicodeUtils").substr(n, p, G.index - p);
                            r[r.length - 1].subElements.push(h.jsx(i, {
                                children: k(D, g)
                            }, "c" + p + "_" + r.length))
                        }
                        C = G.range;
                        b = C.entity;
                        var s = C.entity_is_weak_reference,
                            t = C.entity_type,
                            u = C.length;
                        a = C.offset;
                        r.push({
                            entity: b,
                            entity_is_weak_reference: (B = s) != null ? B : null,
                            entityType: (e = t) != null ? e : null,
                            length: u,
                            offset: a,
                            subElements: []
                        });
                        F++;
                        p = G.index
                    } else {
                        var H = new Set();
                        f = E[F];
                        D = function() {
                            var d = E[F];
                            F++;
                            var e = null;
                            H.forEach(function(a) {
                                a.entity === d.range.entity && (e = a)
                            });
                            if (e != null) H["delete"](e);
                            else if (r.length > 1) {
                                var h = r[r.length - 1],
                                    a = h.entity,
                                    b = h.entity_is_weak_reference,
                                    c = h.entityType;
                                h = h.subElements;
                                var i = m(n, p, G.index, a, b, c, o, h, r, g, q, E.length - F);
                                p = G.index;
                                while (r.length > 1 && i.entity !== d.range.entity) {
                                    H.add(i);
                                    var j = r[r.length - 1];
                                    a = j.entity;
                                    b = j.entity_is_weak_reference;
                                    c = j.entityType;
                                    h = j.subElements;
                                    i = m(n, p, p, a, b, c, o, h, r, g, q, E.length - F)
                                }
                            }
                            f = E[F]
                        };
                        while (f && f.index === G.index && f.type === "end") D();
                        p = G.index;
                        C = Array.from(H);
                        for (var b = C.length - 1; b >= 0; b--) {
                            s = C[b];
                            r.push({
                                entity: s.entity,
                                entity_is_weak_reference: s.entity_is_weak_reference,
                                entityType: s.entityType,
                                length: s.offset + s.length - p,
                                offset: p,
                                subElements: []
                            })
                        }
                    }
                }
            }
        while (r.length > 1) {
            B = r[r.length - 1];
            var w = B.entity,
                x = B.entity_is_weak_reference,
                y = B.entityType,
                z = B.length,
                A = B.offset;
            v = B.subElements;
            t = A + z;
            m(n, p, t, w, x, y, o, v, r, g, q, r.length);
            p = t
        }
        if (p < n.length) {
            e = r[r.length - 1].subElements;
            e.push(h.jsx(i, {
                children: k(d("UnicodeUtils").substr(n, p), g)
            }, "c" + p))
        }
        return r[r.length - 1].subElements
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTextWithEntities.react", ["fbt", "CometLink.react", "CometSeeMoreExpandingUtils", "CometTextWithEntitiesBase.react", "CometTrackingNodeProvider.react", "EmojiRendererData", "FocusRegion.react", "UnicodeUtils", "focusScopeQueries", "getTextDirectionAttribute", "gkx", "killswitch", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useCallback,
        k = b.useRef,
        l = b.useState,
        m = .6,
        n = 20,
        o = {
            auto: {
                textAlign: "start"
            },
            center: {
                textAlign: "center"
            },
            ltr: {
                textAlign: "left"
            },
            rtl: {
                textAlign: "right"
            }
        };

    function p(a) {
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            if (d != null && d.offset != null && d.length != null && d.entity != null && d.entity.__typename != null) {
                var e;
                b.push({
                    entity: d.entity,
                    entity_is_weak_reference: (e = d.entity_is_weak_reference) != null ? e : null,
                    length: d.length,
                    offset: d.offset
                })
            }
        }
        return b
    }

    function q(a, b, c) {
        return a.map(function(a) {
            return babelHelpers["extends"]({}, a, {
                offset: a.offset - b
            })
        }).filter(function(a) {
            return a.offset >= 0 && a.offset < c
        })
    }

    function r(a) {
        var b = a.ranges;
        a = a.text;
        var c = 0;
        return a.split("\n").map(function(a) {
            var e = q(b, c, d("UnicodeUtils").strlen(a));
            c += d("UnicodeUtils").strlen(a) + 1;
            return {
                ranges: e,
                text: a
            }
        }).filter(function(a) {
            return a.text.trim() !== ""
        })
    }

    function s(a, b) {
        var c = a.ranges;
        a = a.text;
        var e = 0;
        return a.split(/(?=\n\s*\n)/).map(function(a) {
            var f, g;
            f = (f = a.match(/(^\n\s*\n)?([^]*$)/)) != null ? f : [];
            g = (g = f[1]) != null ? g : "";
            f = (f = f[2]) != null ? f : a;
            g = q(c, e + g.length, d("UnicodeUtils").strlen(f));
            e += d("UnicodeUtils").strlen(a);
            return b ? r({
                ranges: g,
                text: f
            }) : {
                ranges: g,
                text: f
            }
        })
    }

    function t(a, b, e, f) {
        var g = null,
            h = a.split("\n"),
            i = d("UnicodeUtils").strlen(a);
        i > b && i - b > f && (g = b);
        if (h.length > e) {
            f = h.slice(0, e).join("\n").length;
            g !== null ? g = Math.min(f, g) : g = f
        }
        if (c("killswitch")("COMET_EMOJI_SEQUENCE_TRUNCATION_FIX")) return g;
        else if (g == null) return g;
        else {
            b = g + u(a, g);
            return b < i ? b : null
        }
    }

    function u(a, b) {
        var e = b > 0 && c("EmojiRendererData").isZWJ(d("UnicodeUtils").charAt(a, b - 1).codePointAt(0));
        return v(a, e ? b - 1 : b)
    }

    function v(a, b) {
        var e = d("UnicodeUtils").charAt(a, b);
        if (e !== "") {
            e = e.codePointAt(0);
            if (c("EmojiRendererData").isEmojiModifier(e) || c("EmojiRendererData").isEmojiVariationSelector(e) || c("EmojiRendererData").isTextVariationSelector(e)) return 1 + v(a, b + 1);
            else if (c("EmojiRendererData").isZWJ(e)) {
                e = d("UnicodeUtils").charAt(a, b + 1);
                if (c("EmojiRendererData").isEmojiModifierBase(e.codePointAt(0))) return 2 + v(a, b + 2)
            }
        }
        return 0
    }

    function a(a) {
        var b = a.maxLength;
        b = b === void 0 ? 800 : b;
        var e = a.maxLines;
        e = e === void 0 ? 8 : e;
        var f = a.ranges;
        f = f === void 0 ? [] : f;
        var g = a.text,
            r = a.truncationFactor_DEPRECATED;
        r = r === void 0 ? m : r;
        var u = a.truncationStyle;
        u = u === void 0 ? "none" : u;
        var v = a.truncationThreshold;
        v = v === void 0 ? n : v;
        var w = a.withLineBreaks;
        w = w === void 0 ? !1 : w;
        var x = a.withParagraphs;
        x = x === void 0 ? !1 : x;
        var y = a.onToggleExpanded,
            z = a.seeLessLinkProps,
            A = a.seeMoreLinkProps,
            B = a.expanded,
            C = a.preserveWhiteSpace,
            D = C === void 0 ? !1 : C;
        C = a.suffix;
        var E = babelHelpers.objectWithoutPropertiesLoose(a, ["maxLength", "maxLines", "ranges", "text", "truncationFactor_DEPRECATED", "truncationStyle", "truncationThreshold", "withLineBreaks", "withParagraphs", "onToggleExpanded", "seeLessLinkProps", "seeMoreLinkProps", "expanded", "preserveWhiteSpace", "suffix"]);
        a = l((a = B) != null ? a : !1);
        var F = a[0],
            G = a[1],
            H = B != null ? B : F;
        a = k(-1);
        B = j(function() {
            G(function(a) {
                return !a
            }), y != null && y()
        }, [y]);
        F = p(f);
        f = g;
        var I = null;
        if (u !== "none" && !H) {
            b = t(g, b * r, e, v);
            if (b != null) {
                f = d("UnicodeUtils").substring(g, 0, b);
                F = q(F, 0, d("UnicodeUtils").strlen(f));
                a.current = b;
                switch (u) {
                    case "ellipsis-only":
                        I = i.jsx(i.Fragment, {
                            children: h._("\u2026")
                        }, "seemore");
                        break;
                    case "see-more":
                    case "see-more-and-less":
                        I = i.jsxs(i.Fragment, {
                            children: [h._("\u2026"), " ", i.jsx(c("CometLink.react"), babelHelpers["extends"]({
                                onClick: B,
                                testid: void 0
                            }, A, {
                                children: h._("See more")
                            }))]
                        }, "seemore")
                }
            }
        } else u === "see-more-and-less" && H && (I = i.jsxs(i.Fragment, {
            children: [" ", i.jsx(c("CometLink.react"), babelHelpers["extends"]({
                onClick: B
            }, z, {
                role: "button",
                children: h._("See less")
            }))]
        }, "seemore"));
        I = i.jsx(c("CometTrackingNodeProvider.react"), {
            trackingNode: 44,
            children: I
        });
        if (!x) {
            if (c("gkx")("5118") && H && a != null && a.current != null) {
                r = d("CometSeeMoreExpandingUtils").getEntityRangesWithTruncatedEntityAndSplitIntoTwoParts(F, f, a.current);
                e = r.entitiesBeforeTruncatedOffset;
                v = r.entitiesFromTruncatedOffset;
                g = r.newTruncatedEntityOffset;
                return i.jsxs(i.Fragment, {
                    children: [i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                        ranges: e,
                        text: f.substring(0, g)
                    }, E)), i.jsx(d("FocusRegion.react").FocusRegion, {
                        autoFocusQuery: d("focusScopeQueries").focusableScopeQuery,
                        children: i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                            ranges: v,
                            text: f.substring(g)
                        }, E))
                    })]
                })
            }
            return i.jsxs(i.Fragment, {
                children: [i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                    ranges: F,
                    text: f
                }, E)), I]
            })
        }
        var J = s({
            ranges: F,
            text: f
        }, w);
        c("killswitch")("COMET_MESSAGE_EMPTY_PARAGRAPH_FILTERING") || (J = J.filter(function(a) {
            return !Array.isArray(a) || a.length > 0
        }));
        b = d("CometSeeMoreExpandingUtils").filterParagraphsGetTruncatedLinesEntityRangesAndIndex(H, J, a);
        var K = b.filteredEntitiesBeforeTruncatedPosition,
            L = b.filteredEntitiesFromTruncatedPosition,
            M = b.hiddenContentOffset,
            N = b.truncatedLineIndex,
            O = b.truncatedParagraphIndex,
            P = C != null ? i.jsxs(i.Fragment, {
                children: [" ", C]
            }) : null;
        return i.jsx(i.Fragment, {
            children: J.map(function(a, b) {
                return i.jsx("div", {
                    className: c("stylex")({
                        "margin-top-1": "xdj266r",
                        "margin-end-1": "x11i5rnm",
                        "margin-bottom-1": "xat24cr",
                        "margin-start-1": "x1mh8g0r",
                        "word-wrap-1": "x1vvkbs"
                    }, b !== 0 ? {
                        "margin-top-1": "xtlvy1s"
                    } : null, D ? {
                        "white-space-1": "x126k92a"
                    } : null),
                    children: Array.isArray(a) ? a.map(function(e, f) {
                        var g = e.ranges;
                        e = e.text;
                        var h = c("getTextDirectionAttribute")(e);
                        return i.jsxs("div", {
                            dir: h,
                            style: o[h],
                            children: [H && O === b && N === f ? i.jsxs(i.Fragment, {
                                children: [i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                                    ranges: K,
                                    text: e.substring(0, M)
                                }, E)), i.jsx(d("FocusRegion.react").FocusRegion, {
                                    autoFocusQuery: d("focusScopeQueries").focusableScopeQuery,
                                    children: i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                                        ranges: L,
                                        text: e.substring(M)
                                    }, E))
                                })]
                            }) : i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                                ranges: g,
                                text: e
                            }, E)), b === J.length - 1 && f === a.length - 1 ? i.jsxs(i.Fragment, {
                                children: [I, P]
                            }) : null]
                        }, f)
                    }) : i.jsxs(i.Fragment, {
                        children: [i.jsx(c("CometTextWithEntitiesBase.react"), babelHelpers["extends"]({
                            ranges: a.ranges,
                            text: a.text
                        }, E)), b === J.length - 1 ? i.jsxs(i.Fragment, {
                            children: [I, P]
                        }) : null]
                    })
                }, b)
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("baseTextTransformAllStrings", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function i(a) {
        return (a == null ? void 0 : a.type) === h.Fragment && typeof(a == null ? void 0 : (a = a.props) == null ? void 0 : a.children) === "string"
    }

    function j(a, b, c, d) {
        c === void 0 && (c = 3);
        d === void 0 && (d = 0);
        var e = 0;
        if (typeof a === "string") {
            var f = a;
            return b(f, d + "-" + e++)
        } else if (Array.isArray(a)) return a.map(function(a, f) {
            if (i(a)) return h.cloneElement(a, {
                children: b(a.props.children, d + "-" + e++)
            });
            return d < c ? j(a, b, c, d + 1) : a
        });
        else if (a != null && typeof a === "object") {
            f = h.Children.only(a);
            if (i(f)) return h.cloneElement(f, {
                children: b(f.props.children, d + "-" + e++)
            })
        }
        return a
    }
    j.displayName = j.name + " [from " + f.id + "]";
    g["default"] = j
}), 98);
__d("CometEmojiTransform", ["CometEmojiWithContextualSize.react", "EmojiRenderer", "baseTextTransformAllStrings", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.size;
        return function(a) {
            var e = 0;
            return c("baseTextTransformAllStrings")(a, function(a, f) {
                return d("EmojiRenderer").render(a, function(a) {
                    return h.jsx(c("CometEmojiWithContextualSize.react"), {
                        emoji: a,
                        size: b
                    }, f + "-" + e++)
                })
            })
        }
    }
    g["default"] = a
}), 98);
__d("EmoticonRenderer", ["EmoticonsList"], (function(a, b, c, d, e, f, g) {
    var h = ["LIKE", "PACMAN", "FACE_WITH_COLON_THREE"];

    function i(a) {
        var b = [],
            c = new RegExp(d("EmoticonsList").regexp),
            e = 0,
            f = a.match(c);
        while (f !== null) {
            var g = f[1],
                i = f[2].split(""),
                j = d("EmoticonsList").emotes[f[2]];
            j = d("EmoticonsList").emoji[j];
            b.push({
                chars: i,
                key: j,
                isCustom: h.includes(j),
                offset: e + f.index + g.length
            });
            e += f.index + f[0].length;
            f = a.slice(e).match(c)
        }
        return b
    }

    function a(a, b, c) {
        var d = i(a),
            e = [],
            f = 0;
        d.forEach(function(d) {
            var g = d.offset;
            g > f && e.push(a.substr(f, g - f));
            d.isCustom ? e.push(c(d.key, d.chars)) : e.push(b(d.key));
            f = g + d.chars.length
        });
        e.push(a.substr(f, a.length - f));
        return e
    }
    g.parse = i;
    g.render = a
}), 98);
__d("CometEmoticonTransform", ["CometEmojiWithContextualSize.react", "EmoticonRenderer", "FBEmojiResource", "FBEmojiUtils", "baseTextTransformAllStrings", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a === void 0 ? {} : a;
        var b = a.size;
        return function(a) {
            var e = 0;
            return c("baseTextTransformAllStrings")(a, function(a, f) {
                return d("EmoticonRenderer").render(a, function(a) {
                    return h.jsx(c("CometEmojiWithContextualSize.react"), {
                        emoji: [d("FBEmojiUtils").codepointsToString(a.split("_").map(function(a) {
                            return Number("0x" + a)
                        }))],
                        resource: new(c("FBEmojiResource"))(a),
                        size: b
                    }, f + "-" + e++)
                }, function(a, d) {
                    return h.jsx(c("CometEmojiWithContextualSize.react"), {
                        emoji: d,
                        resource: new(c("FBEmojiResource"))(a),
                        size: b
                    }, f + "-" + e++)
                })
            })
        }
    }
    g["default"] = a
}), 98);
__d("CometUFIVideoPlayerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react").createContext;
    b = a([null, function() {}]);
    g["default"] = b
}), 98);
__d("CometUFIVideoPlayerPortableIDContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react").createContext;
    b = a(null);
    g["default"] = b
}), 98);
__d("useCometUFIVideoPlayerStateAndController", ["CometUFIVideoPlayerContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = h(c("CometUFIVideoPlayerContext")),
            b = a[0];
        a[1];
        return b
    }
    g["default"] = a
}), 98);
__d("CometUFIVideoPlayerUtils", ["CometUFIVideoPlayerContext", "CometUFIVideoPlayerPortableIDContext", "VideoPlayerHooks", "react", "useCometUFIVideoPlayerStateAndController", "useVideoPlayerPortalingPassthroughProps"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react"),
        j = i.useCallback,
        k = i.useContext,
        l = i.useEffect,
        m = i.useState;

    function a(a) {
        a = a.children;
        var b = m(null),
            d = b[0];
        return h.jsx(c("CometUFIVideoPlayerContext").Provider, {
            value: b,
            children: h.jsx(c("CometUFIVideoPlayerPortableIDContext").Provider, {
                value: d == null ? void 0 : (b = d.data) == null ? void 0 : b.portableVideoID,
                children: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = a.data,
            e = d("VideoPlayerHooks").useController(),
            f = c("useVideoPlayerPortalingPassthroughProps")();
        a = k(c("CometUFIVideoPlayerContext"));
        a[0];
        var g = a[1];
        l(function() {
            g({
                controller: e,
                data: babelHelpers["extends"]({}, b, f)
            });
            return function() {
                g(null)
            }
        }, [e, b, f, g]);
        return null
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function e() {
        var a = c("useCometUFIVideoPlayerStateAndController")();
        return j(function() {
            return a == null ? null : Math.floor(a.controller.getPlayheadPosition())
        }, [a])
    }
    g.CometUFIVideoPlayerStateAndControllerContextProvider = a;
    g.CometUFIVideoPlayerStateAndControllerExtractor = b;
    g.useGetCometUFIVideoPlayerTimestampInteger = e
}), 98);
__d("UnifiedEditorExpandedImageDialog.react", ["fbt", "ix", "BaseDialog.react", "CometImage.react", "TetraCircleButton.react", "fbicon", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = {
            anchor: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha",
                paddingTop: "xn2ks54",
                paddingBottom: "x161sli9"
            },
            buttonContainer: {
                position: "xixxii4",
                start: "xoie2o3",
                top: "x1tk7jg1"
            },
            image: {
                maxHeight: "xv0t3ls",
                maxWidth: "x12mqc9s",
                objectFit: "x19kjcj4"
            }
        };

    function a(a) {
        var b = a.imageUri;
        a = a.onClose;
        return j.jsxs(c("BaseDialog.react"), {
            anchorXStyle: k.anchor,
            onClose: a,
            children: [j.jsx("div", {
                className: c("stylex")(k.buttonContainer),
                children: j.jsx(c("TetraCircleButton.react"), {
                    icon: d("fbicon")._(i("478233"), 20),
                    label: h._("Close"),
                    onPress: a,
                    size: 36
                })
            }), j.jsx(c("CometImage.react"), {
                src: b,
                xstyle: k.image
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getFormattedTimestamp", ["DateConsts"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = "";
        a = a;
        isNaN(a) ? a = 0 : a < 0 && (a *= -1, b = "-");
        var c = Math.floor(a / d("DateConsts").SEC_PER_HOUR),
            e = Math.floor((a - c * d("DateConsts").SEC_PER_HOUR) / d("DateConsts").SEC_PER_MIN);
        a = Math.round(a - c * d("DateConsts").SEC_PER_HOUR - e * d("DateConsts").SEC_PER_MIN);
        a === d("DateConsts").SEC_PER_MIN && (a = 0, e++);
        e === d("DateConsts").MIN_PER_HOUR && (e = 0, c++);
        a = ("0" + a).slice(-2);
        if (c === 0) return "" + b + e + ":" + a;
        else {
            e = ("0" + e).slice(-2);
            return "" + b + c + ":" + e + ":" + a
        }
    }
    g["default"] = a
}), 98);
__d("useVideoOriginalDimensionsRelay", ["CometRelay", "computeAspectRatio", "useVideoOriginalDimensionsRelay_video.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;

    function a(a) {
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("useVideoOriginalDimensionsRelay_video.graphql"), a);
        var e = a == null ? void 0 : a.original_rotation;
        e = e === "ROTATE_LEFT" || e === "ROTATE_RIGHT";
        var f = e ? a == null ? void 0 : a.original_height : a == null ? void 0 : a.original_width;
        e = e ? a == null ? void 0 : a.original_width : a == null ? void 0 : a.original_height;
        a = c("computeAspectRatio")(f, e);
        return {
            originalAspectRatio: a,
            originalHeight: e,
            originalWidth: f
        }
    }
    g["default"] = a
}), 98);
__d("GamingVideoBackLink.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "XCometGamingControllerRouteBuilder", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = i("370949"),
        l = c("XCometGamingControllerRouteBuilder").buildURL({});

    function a() {
        var a = h._("Go to Facebook Gaming");
        return j.jsx(c("CometPressable.react"), {
            linkProps: {
                url: l
            },
            children: function(b) {
                b = b.hovered;
                return j.jsxs("div", {
                    className: "x1q0g3np x78zum5",
                    children: [j.jsx("span", {
                        className: b ? "xl405pv x19991ni x1d8287x x1hc1fzr x3nfvp2" : "xl405pv x19991ni x1d8287x xbyyjgo x1qo4wvw x3nfvp2",
                        children: j.jsx(c("CometImage.react"), {
                            alt: h._("Close"),
                            src: k
                        })
                    }), j.jsx("div", {
                        className: c("stylex")(b ? {
                            "color-1": "xe2km65",
                            "display-1": "x1lliihq",
                            "padding-end-1": "x1sxyh0",
                            "position-1": "x1n2onr6",
                            "text-decoration-0.1": "x1bvjpef",
                            "top-1": "xndqk7f"
                        } : {
                            "display-1": "x1s85apg"
                        }),
                        children: a
                    })]
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSettingsMenuQualityPaneToggle.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "VideoPlayerSettingsMenu.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = {
            chevronRight: {
                display: "x3nfvp2",
                marginBottom: "xmgb6t1",
                marginStart: "x12mruv9"
            },
            label: {
                cursor: "x1ypdohk",
                fontWeight: "x1s688f"
            },
            option: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x78zum5",
                flexGrow: "x1bhwmg6",
                justifyContent: "x13a6bvl",
                marginStart: "x1i64zmx",
                minWidth: "x450l9j"
            },
            pressableOption: {
                width: "xh8yej3"
            }
        };

    function a(a) {
        var b = a.selectedVideoQuality,
            e = a.setPane;
        a = a.targetVideoQuality;
        return j.jsxs(c("CometPressable.react"), {
            onPress: function() {
                e(d("VideoPlayerSettingsMenu.react").VideoPlayerSettingsMenuPaneType.QUALITY)
            },
            testid: void 0,
            xstyle: k.pressableOption,
            children: [j.jsx("div", {
                className: c("stylex")(k.label),
                children: h._("Quality")
            }), j.jsxs("div", {
                className: c("stylex")(k.option),
                children: [b === "notselected" ? j.jsx("span", {
                    "data-testid": void 0,
                    children: "\xa0"
                }) : b === "auto" ? j.jsxs(j.Fragment, {
                    children: [j.jsx("span", {
                        "data-testid": void 0,
                        children: h._("Auto")
                    }), a != null ? j.jsxs(j.Fragment, {
                        children: [j.jsx("span", {
                            children: "\xa0"
                        }), j.jsx("span", {
                            "data-testid": void 0,
                            children: a
                        })]
                    }) : null]
                }) : j.jsx("span", {
                    "data-testid": void 0,
                    children: b
                }), j.jsx("span", {
                    className: c("stylex")(k.chevronRight),
                    children: j.jsx(c("CometImage.react"), {
                        src: i("480587")
                    })
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("LiveVideoLatencyMenu.react", ["fbt", "CometRelay", "LiveVideoLatencyMenuContextProvider_video.graphql", "VideoPlayerHooks", "gkx", "react", "recoverableViolation", "useSelectedLatencySetting"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = d("react"),
        k = d("react").useMemo,
        l = h._("Latency"),
        m = c("gkx")("3681") ? [o("ultra-low"), o("low"), o("normal")] : [o("low"), o("normal")],
        n = j.createContext({
            liveVideoLatencyMenuPaneMatchPointer: null,
            liveVideoLatencyMenuPaneToggleMatchPointer: null
        });

    function o(a) {
        switch (a) {
            case "low":
                return {
                    description: h._("A near-realtime experience."),
                    title: h._("Low Latency"),
                    value: a
                };
            case "normal":
                return {
                    description: h._("Best for performance and slower connections."),
                    title: h._("Normal"),
                    value: a
                };
            case "ultra-low":
                return {
                    description: h._("Best for interactive broadcasts."),
                    title: h._("Ultra-low"),
                    value: a
                };
            default:
                a;
                c("recoverableViolation")("Setting " + a + " is not valid", "gaming_video");
                return {
                    description: h._("Error"),
                    title: h._("Error"),
                    value: a
                }
        }
    }

    function a(a, b) {
        var e = d("VideoPlayerHooks").useController(),
            f = d("VideoPlayerHooks").useLatencyLevel();
        a = c("useSelectedLatencySetting")(a, b);
        a[0];
        var g = a[1];
        b = o(f);
        a = b.title;
        b = function(a) {
            f !== a && (g(a), e.setLatencyLevel(a))
        };
        return {
            selectedLatencySetting: f,
            selectedLatencySettingTitle: a,
            setSelectedLatencySetting: b
        }
    }
    var p = i !== void 0 ? i : i = b("LiveVideoLatencyMenuContextProvider_video.graphql");

    function e(a) {
        var b = a.children;
        a = a.video;
        var c = d("CometRelay").useFragment(p, a);
        a = k(function() {
            return c == null ? {
                liveVideoLatencyMenuPaneMatchPointer: null,
                liveVideoLatencyMenuPaneToggleMatchPointer: null
            } : {
                liveVideoLatencyMenuPaneMatchPointer: c.if_viewer_can_use_latency_menu,
                liveVideoLatencyMenuPaneToggleMatchPointer: c.if_viewer_can_use_latency_menu_toggle
            }
        }, [c]);
        return j.jsx(n.Provider, {
            value: a,
            children: b
        })
    }
    e.displayName = e.name + " [from " + f.id + "]";
    g.LATENCY_MENU_TITLE = l;
    g.LATENCY_SETTING_OPTIONS = m;
    g.LiveVideoLatencyMenuContext = n;
    g.getLiveVideoLatencySettingToInfoMapping = o;
    g.useLatencySettingState = a;
    g.LiveVideoLatencyMenuContextProvider = e
}), 98);
__d("VideoPlayerSettingsMenu.react", ["fbt", "$InternalEnum", "CometErrorBoundary.react", "CometKeys", "CometPlaceholder.react", "CometRelay", "LiveVideoLatencyMenu.react", "PlaybackSpeedExperiments", "VideoPlayerHooks", "VideoPlayerSettingsMenuMainPane.react", "VideoPlayerSettingsMenuPlaybackSpeedPane.react", "VideoPlayerSettingsMenuQualityPane.react", "cr:564", "react", "recoverableViolation", "useLayerKeyCommands"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    e = d("react");
    var j = e.useCallback,
        k = e.useContext,
        l = e.useEffect,
        m = e.useMemo,
        n = e.useRef,
        o = e.useState,
        p = b("$InternalEnum")({
            LATENCY: "latency",
            MAIN: "main",
            PLAYBACK_SPEED: "playbackSpeed",
            QUALITY: "quality",
            SEARCH_CAPTIONS: "searchCaptions"
        });

    function a(a) {
        var e = a.children;
        e = e === void 0 ? null : e;
        var f = a.onClose;
        a = d("VideoPlayerHooks").useCaptionsLoaded();
        var g = d("VideoPlayerHooks").useCaptionsVisible(),
            q = d("VideoPlayerHooks").useSelectedVideoQuality(),
            r = d("VideoPlayerHooks").useInbandCaptionsAutogenerated(),
            s = d("VideoPlayerHooks").useTargetVideoQuality(),
            t = o(p.MAIN),
            u = t[0],
            v = t[1];
        t = o(g);
        g = t[0];
        t = t[1];
        var w = d("VideoPlayerHooks").usePlaybackRate(),
            x = d("VideoPlayerHooks").useIsLive(),
            y = d("VideoPlayerHooks").useIsLiveRewindActive(),
            z = k(d("LiveVideoLatencyMenu.react").LiveVideoLatencyMenuContext);
        z = z.liveVideoLatencyMenuPaneMatchPointer;
        var A = d("VideoPlayerHooks").useShouldShowPlaybackRateControl();
        A = !!d("PlaybackSpeedExperiments").enableCometPlaybackSpeedControlPublicTest() && A;
        l(function() {
            x && !y && u === p.PLAYBACK_SPEED && v(p.MAIN)
        }, [y, v, x, u]);
        var B = n(null),
            C = n(null),
            D = j(function(a) {
                B.current && C.current && a.target instanceof HTMLElement && document.contains(a.target) && !B.current.contains(a.target) && C.current.contains(a.target) && f()
            }, [f]);
        l(function() {
            document.addEventListener("click", D);
            return function() {
                document.removeEventListener("click", D)
            }
        }, [D]);
        var E = m(function() {
            return [{
                command: {
                    key: c("CometKeys").ESCAPE
                },
                description: h._("Close video settings menu"),
                handler: function() {
                    f()
                }
            }]
        }, [f]);
        c("useLayerKeyCommands")(E);
        E = i.jsx(c("VideoPlayerSettingsMenuMainPane.react"), {
            captionsLoaded: a,
            captionsVisibleOptimistic: g,
            inbandCaptionsAutogenerated: r,
            playbackRate: w,
            selectedVideoQuality: q,
            setIsCaptionsVisible: t,
            setPane: v,
            shouldEnablePlaybackRateSupport: A,
            targetVideoQuality: s,
            children: e
        });
        switch (u) {
            case p.LATENCY:
                if (z == null) {
                    c("recoverableViolation")("Latency components should not be null", "gaming_video");
                    break
                }
                E = i.jsx(c("CometErrorBoundary.react"), {
                    children: i.jsx(c("CometPlaceholder.react"), {
                        fallback: null,
                        children: i.jsx(d("CometRelay").MatchContainer, {
                            match: z,
                            props: {
                                setPane: v
                            }
                        })
                    })
                });
                break;
            case p.MAIN:
                break;
            case p.PLAYBACK_SPEED:
                E = i.jsx(c("VideoPlayerSettingsMenuPlaybackSpeedPane.react"), {
                    playbackRate: w,
                    setPane: v
                });
                break;
            case p.QUALITY:
                E = i.jsx(c("VideoPlayerSettingsMenuQualityPane.react"), {
                    selectedVideoQuality: q,
                    setPane: v
                });
                break;
            case p.SEARCH_CAPTIONS:
                b("cr:564") != null && (E = i.jsx(b("cr:564"), {
                    setPane: v,
                    children: e
                }));
                break
        }
        return i.jsxs(i.Fragment, {
            children: [i.jsx("div", {
                ref: B,
                children: E
            }), i.jsx("div", {
                className: "x8knxv4 xh8yej3 x13vifvy x17qophe xixxii4 x1g81zrj xg6iff7 x5yr21d xjbqb8w",
                "data-testid": void 0,
                ref: C
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.VideoPlayerSettingsMenuPaneType = p;
    g.VideoPlayerSettingsMenu = a
}), 98);
__d("VideoPlayerSettingsMenuMainPane.react", ["CometErrorBoundary.react", "CometPlaceholder.react", "CometRelay", "FocusRegion.react", "LiveVideoLatencyMenu.react", "VideoPlayerSettingsMenuPlaybackPaneToggle.react", "VideoPlayerSettingsMenuQualityPaneToggle.react", "cr:565", "focusScopeQueries", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        var e = a.children,
            f = a.playbackRate,
            g = a.selectedVideoQuality,
            j = a.setPane,
            k = a.shouldEnablePlaybackRateSupport;
        a = a.targetVideoQuality;
        var l = i(d("LiveVideoLatencyMenu.react").LiveVideoLatencyMenuContext);
        l = l.liveVideoLatencyMenuPaneToggleMatchPointer;
        return h.jsx(d("FocusRegion.react").FocusRegion, {
            autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            children: h.jsxs("div", {
                "data-testid": void 0,
                children: [h.jsx("div", {
                    className: "x1lku1pv x1hoihq8 x78zum5 x14ctfv",
                    children: b("cr:565") && h.jsx(b("cr:565"), {
                        setPane: j
                    })
                }), h.jsx("div", {
                    className: "x1lku1pv x1hoihq8 x78zum5 x14ctfv",
                    children: h.jsx(c("VideoPlayerSettingsMenuQualityPaneToggle.react"), {
                        selectedVideoQuality: g,
                        setPane: j,
                        targetVideoQuality: a
                    })
                }), h.jsx("div", {
                    className: "x1lku1pv x1hoihq8 x78zum5 x14ctfv",
                    children: h.jsx(c("VideoPlayerSettingsMenuPlaybackPaneToggle.react"), {
                        playbackRate: f,
                        setPane: j,
                        shouldEnablePlaybackRateSupport: k
                    })
                }), l != null && h.jsx("div", {
                    className: "x1lku1pv x1hoihq8 x78zum5 x14ctfv",
                    children: h.jsx(c("CometErrorBoundary.react"), {
                        children: h.jsx(c("CometPlaceholder.react"), {
                            fallback: null,
                            children: h.jsx(d("CometRelay").MatchContainer, {
                                match: l,
                                props: {
                                    setPane: j
                                }
                            })
                        })
                    })
                }), e]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSettingsMenuPlaybackPaneToggle.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "VideoPlayerSettingsMenu.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = {
            chevronRight: {
                display: "x3nfvp2",
                marginBottom: "xmgb6t1",
                marginStart: "x12mruv9"
            },
            label: {
                cursor: "x1ypdohk",
                fontWeight: "x1s688f"
            },
            option: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x78zum5",
                flexGrow: "x1bhwmg6",
                justifyContent: "x13a6bvl",
                marginStart: "x1i64zmx",
                minWidth: "x450l9j"
            },
            pressableOption: {
                width: "xh8yej3"
            }
        };

    function a(a) {
        var b = a.playbackRate,
            e = a.setPane;
        a = a.shouldEnablePlaybackRateSupport;
        return !a ? null : j.jsxs(c("CometPressable.react"), {
            onPress: function() {
                e(d("VideoPlayerSettingsMenu.react").VideoPlayerSettingsMenuPaneType.PLAYBACK_SPEED)
            },
            testid: void 0,
            xstyle: k.pressableOption,
            children: [j.jsx("div", {
                className: c("stylex")(k.label),
                children: h._("Playback Speed")
            }), j.jsxs("div", {
                className: c("stylex")(k.option),
                children: [j.jsx("span", {
                    "data-testid": void 0,
                    children: b
                }), j.jsx("span", {
                    className: c("stylex")(k.chevronRight),
                    children: j.jsx(c("CometImage.react"), {
                        src: i("480587")
                    })
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSettingsMenuPlaybackSpeedPane.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "FocusRegion.react", "VideoPlayerHooks", "VideoPlayerSettingsMenu.react", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = {
            chevronLeft: {
                display: "x3nfvp2",
                marginBottom: "xmgb6t1",
                marginStart: "x139jcc6"
            },
            menuHeading: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x78zum5",
                fontWeight: "x1s688f",
                ":hover": {
                    textDecoration: "x1lku1pv"
                }
            },
            menuLabel: {
                cursor: "x1ypdohk",
                display: "x1rg5ohu"
            },
            menuOption: {
                marginStart: "x17adc0v",
                marginTop: "x1anpbxc"
            },
            menuOptionRow: {
                color: "x14ctfv",
                display: "x1lliihq",
                minWidth: "xfvyar9",
                outline: "x1a2a7pz",
                paddingTop: "xyqdw3p",
                paddingEnd: "x4uap5",
                paddingBottom: "xg8j3zb",
                paddingStart: "xkhd6sd",
                textAlign: "x1yc453h"
            },
            pressableOption: {
                width: "xh8yej3"
            },
            radio: {
                backgroundColor: "x17j41np",
                borderTopStartRadius: "x1ykpwxx",
                borderTopEndRadius: "x118zf8b",
                borderBottomEndRadius: "xnwxkdh",
                borderBottomStartRadius: "xfocsrx",
                display: "x1rg5ohu",
                marginBottom: "xmgb6t1",
                marginEnd: "xmo9yow",
                paddingTop: "x1yrsyyn",
                paddingEnd: "xsyo7zv",
                paddingBottom: "x10b6aqq",
                paddingStart: "x16hj40l"
            },
            radioDot: {
                backgroundColor: "x14hiurz",
                borderTopStartRadius: "x8u2fvd",
                borderTopEndRadius: "x1ht7hnu",
                borderBottomEndRadius: "x1quq95r",
                borderBottomStartRadius: "x5yzy4c",
                display: "x1rg5ohu",
                height: "xqu0tyb",
                marginStart: "x8182xy",
                marginTop: "x1kgmq87",
                position: "x10l6tqk",
                width: "x51ohtg"
            },
            selectedOption: {
                fontWeight: "x1s688f"
            }
        };

    function a(a) {
        var b = a.playbackRate,
            e = a.setPane,
            f = d("VideoPlayerHooks").useController();
        return j.jsx(d("FocusRegion.react").FocusRegion, {
            autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            children: j.jsxs("div", {
                "data-testid": void 0,
                children: [j.jsx("div", {
                    className: c("stylex")(k.menuHeading),
                    children: j.jsxs(c("CometPressable.react"), {
                        onPress: function() {
                            return e(d("VideoPlayerSettingsMenu.react").VideoPlayerSettingsMenuPaneType.MAIN)
                        },
                        testid: void 0,
                        xstyle: k.pressableOption,
                        children: [" ", j.jsx("span", {
                            className: c("stylex")(k.chevronLeft),
                            children: j.jsx(c("CometImage.react"), {
                                src: i("480579")
                            })
                        }), h._("Playback Speed")]
                    })
                }), j.jsx("div", {
                    className: c("stylex")(k.menuOption),
                    "data-testid": void 0,
                    children: [.5, .75, 1, 1.25, 1.5, 1.75, 2].map(function(a) {
                        var d = b === a;
                        return j.jsx("div", {
                            children: j.jsxs(c("CometPressable.react"), {
                                onPress: function() {
                                    f.setPlaybackRate(a)
                                },
                                testid: void 0,
                                xstyle: k.menuOptionRow,
                                children: [j.jsx("div", {
                                    className: c("stylex")(k.radio),
                                    children: d && j.jsx("div", {
                                        className: c("stylex")(k.radioDot),
                                        "data-testid": void 0
                                    })
                                }), j.jsx("div", {
                                    className: c("stylex")(k.menuLabel, d && k.selectedOption),
                                    "data-testid": void 0,
                                    children: a
                                })]
                            })
                        }, a)
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSettingsMenuQualityPane.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "FocusRegion.react", "VideoPlayerHooks", "VideoPlayerSettingsMenu.react", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = {
            chevronLeft: {
                alignItems: "x6s0dn4",
                display: "x3nfvp2",
                marginBottom: "xmgb6t1",
                marginStart: "x139jcc6"
            },
            menuHeading: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x78zum5",
                fontWeight: "x1s688f",
                ":hover": {
                    textDecoration: "x1lku1pv"
                }
            },
            menuLabel: {
                cursor: "x1ypdohk",
                display: "x1rg5ohu"
            },
            menuOption: {
                marginStart: "x17adc0v",
                marginTop: "x1anpbxc"
            },
            menuOptionRow: {
                color: "x14ctfv",
                display: "x1lliihq",
                minWidth: "xfvyar9",
                outline: "x1a2a7pz",
                paddingTop: "xyqdw3p",
                paddingEnd: "x4uap5",
                paddingBottom: "xg8j3zb",
                paddingStart: "xkhd6sd",
                textAlign: "x1yc453h"
            },
            pressableOption: {
                width: "xh8yej3"
            },
            radio: {
                backgroundColor: "xiakxrv",
                borderTopStartRadius: "x1ykpwxx",
                borderTopEndRadius: "x118zf8b",
                borderBottomEndRadius: "xnwxkdh",
                borderBottomStartRadius: "xfocsrx",
                display: "x1rg5ohu",
                marginBottom: "xmgb6t1",
                marginEnd: "xmo9yow",
                paddingTop: "x1yrsyyn",
                paddingEnd: "xsyo7zv",
                paddingBottom: "x10b6aqq",
                paddingStart: "x16hj40l"
            },
            radioDot: {
                backgroundColor: "x14hiurz",
                borderTopStartRadius: "x8u2fvd",
                borderTopEndRadius: "x1ht7hnu",
                borderBottomEndRadius: "x1quq95r",
                borderBottomStartRadius: "x5yzy4c",
                display: "x1rg5ohu",
                height: "xqu0tyb",
                marginStart: "x8182xy",
                marginTop: "x1kgmq87",
                position: "x10l6tqk",
                width: "x51ohtg"
            },
            selectedOption: {
                fontWeight: "x1s688f"
            }
        };

    function a(a) {
        var b = a.selectedVideoQuality,
            e = a.setPane;
        a = d("VideoPlayerHooks").useAvailableVideoQualities();
        var f = d("VideoPlayerHooks").useIsAbrEnabled(),
            g = d("VideoPlayerHooks").useController();
        return j.jsx(d("FocusRegion.react").FocusRegion, {
            autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            children: j.jsxs("div", {
                "data-testid": void 0,
                children: [j.jsx("div", {
                    className: c("stylex")(k.menuHeading),
                    children: j.jsxs(c("CometPressable.react"), {
                        onPress: function() {
                            return e(d("VideoPlayerSettingsMenu.react").VideoPlayerSettingsMenuPaneType.MAIN)
                        },
                        testid: void 0,
                        xstyle: k.pressableOption,
                        children: [j.jsx("span", {
                            className: c("stylex")(k.chevronLeft),
                            children: j.jsx(c("CometImage.react"), {
                                src: i("480579")
                            })
                        }), h._("Quality")]
                    })
                }), j.jsxs("div", {
                    className: c("stylex")(k.menuOption),
                    "data-testid": void 0,
                    children: [f ? j.jsx("div", {
                        children: j.jsxs(c("CometPressable.react"), {
                            onPress: function() {
                                g.selectVideoQuality("auto")
                            },
                            testid: void 0,
                            xstyle: k.menuOptionRow,
                            children: [j.jsx("div", {
                                className: c("stylex")(k.radio),
                                children: b === "auto" && j.jsx("div", {
                                    className: c("stylex")(k.radioDot),
                                    "data-testid": void 0
                                })
                            }), j.jsx("div", {
                                className: c("stylex")(k.menuLabel, b === "auto" && k.selectedOption),
                                "data-testid": void 0,
                                children: h._("Auto")
                            })]
                        })
                    }, "auto") : null, a.map(function(a) {
                        var d = b === a;
                        return j.jsx("div", {
                            children: j.jsxs(c("CometPressable.react"), {
                                onPress: function() {
                                    g.selectVideoQuality(a)
                                },
                                testid: void 0,
                                xstyle: k.menuOptionRow,
                                children: [j.jsx("div", {
                                    className: c("stylex")(k.radio),
                                    children: d && j.jsx("div", {
                                        className: c("stylex")(k.radioDot),
                                        "data-testid": void 0
                                    })
                                }), j.jsx("div", {
                                    className: c("stylex")(k.menuLabel, d && k.selectedOption),
                                    "data-testid": void 0,
                                    children: a
                                })]
                            })
                        }, a)
                    }).reverse()]
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoControlsContainerFocusedContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("VideoPlayerCaptionsMenu.react", ["fbt", "$InternalEnum", "CometKeys", "VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react", "VideoPlayerCaptionsMenuCaptionsDisplayPane.react", "VideoPlayerCaptionsMenuMainPane.react", "VideoPlayerHooks", "react", "useLayerKeyCommands"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    e = d("react");
    var j = e.useCallback,
        k = e.useEffect,
        l = e.useMemo,
        m = e.useRef,
        n = e.useState,
        o = b("$InternalEnum")({
            CAPTIONS_BG_COLOR: "captionsBackgroundColor",
            CAPTIONS_BG_OPACITY: "captionsBackgroundOpacity",
            CAPTIONS_DISPLAY_MAIN: "captionsDisplayMain",
            CAPTIONS_TEXT_COLOR: "captionsTextColor",
            CAPTIONS_TEXT_SIZE: "captionsTextSize",
            CAPTIONS_MAIN: "captionsMain"
        });

    function a(a) {
        var b = a.availableCaptionsLocales,
            e = a.captionsListExpanded,
            f = a.children;
        f = f === void 0 ? null : f;
        var g = a.onClose,
            p = a.onPressLog,
            q = a.selectedCaptionsLocale,
            r = a.setCaptionsListExpanded;
        a = a.setSelectedCaptionsLocale;
        var s = d("VideoPlayerHooks").useCaptionDisplayStyle(),
            t = n(o.CAPTIONS_MAIN),
            u = t[0];
        t = t[1];
        var v = m(null),
            w = m(null),
            x = j(function(a) {
                v.current && w.current && a.target instanceof HTMLElement && document.contains(a.target) && !v.current.contains(a.target) && w.current.contains(a.target) && g()
            }, [g]);
        k(function() {
            document.addEventListener("click", x);
            return function() {
                document.removeEventListener("click", x)
            }
        }, [x]);
        var y = l(function() {
            return [{
                command: {
                    key: c("CometKeys").ESCAPE
                },
                description: h._("Close captions menu"),
                handler: function() {
                    g()
                }
            }]
        }, [g]);
        c("useLayerKeyCommands")(y);
        y = i.jsx(d("VideoPlayerCaptionsMenuMainPane.react").VideoPlayerCaptionsMenuMainPane, {
            availableCaptionsLocales: b,
            captionsListExpanded: e,
            onPressLog: p,
            selectedCaptionsLocale: q,
            setCaptionsListExpanded: r,
            setPane: t,
            setSelectedCaptionsLocale: a,
            children: f
        });
        switch (u) {
            case o.CAPTIONS_MAIN:
                break;
            case o.CAPTIONS_DISPLAY_MAIN:
                y = i.jsx(d("VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react").VideoPlayerCaptionsMenuCaptionsDisplayMainPane, {
                    currentCaptionsDisplay: s,
                    onPressLog: p,
                    setPane: t
                });
                break;
            case o.CAPTIONS_BG_COLOR:
                y = i.jsx(d("VideoPlayerCaptionsMenuCaptionsDisplayPane.react").VideoPlayerCaptionsMenuCaptionsDisplayPane, {
                    captionsDisplayOption: "captionsBackgroundColor",
                    currentCaptionsDisplay: s,
                    onPressLog: p,
                    setPane: t
                });
                break;
            case o.CAPTIONS_BG_OPACITY:
                y = i.jsx(d("VideoPlayerCaptionsMenuCaptionsDisplayPane.react").VideoPlayerCaptionsMenuCaptionsDisplayPane, {
                    captionsDisplayOption: "captionsBackgroundOpacity",
                    currentCaptionsDisplay: s,
                    onPressLog: p,
                    setPane: t
                });
                break;
            case o.CAPTIONS_TEXT_SIZE:
                y = i.jsx(d("VideoPlayerCaptionsMenuCaptionsDisplayPane.react").VideoPlayerCaptionsMenuCaptionsDisplayPane, {
                    captionsDisplayOption: "captionsTextSize",
                    currentCaptionsDisplay: s,
                    setPane: t
                });
                break;
            case o.CAPTIONS_TEXT_COLOR:
                y = i.jsx(d("VideoPlayerCaptionsMenuCaptionsDisplayPane.react").VideoPlayerCaptionsMenuCaptionsDisplayPane, {
                    captionsDisplayOption: "captionsTextColor",
                    currentCaptionsDisplay: s,
                    onPressLog: p,
                    setPane: t
                });
                break
        }
        return i.jsxs(i.Fragment, {
            children: [i.jsx("div", {
                ref: v,
                children: y
            }), i.jsx("div", {
                className: "x8knxv4 xh8yej3 x13vifvy x17qophe xixxii4 x5yr21d",
                "data-testid": void 0,
                ref: w
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.VideoPlayerCaptionsMenuPaneType = o;
    g.VideoPlayerCaptionsMenu = a
}), 98);
__d("VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "FocusRegion.react", "VideoPlayerCaptionsMenu.react", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useCallback,
        l = {
            captionsDisplayLabel: {
                fontSize: "x1nxh6w3",
                fontWeight: "x1s688f",
                marginStart: "x16n37ib"
            },
            chevronLeft: {
                alignItems: "x6s0dn4",
                display: "x3nfvp2"
            },
            chevronRight: {
                display: "x1lliihq"
            },
            icon: {
                display: "x1rg5ohu"
            },
            menuHeading: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x78zum5",
                fontWeight: "x1s688f",
                ":hover": {
                    textDecoration: "x1lku1pv"
                }
            },
            menuOptionLabel: {
                cursor: "x1ypdohk",
                display: "x1rg5ohu",
                fontSize: "x1nxh6w3",
                fontWeight: "x1s688f",
                width: "x1uncgzr"
            },
            menuOptionRow: {
                color: "x14ctfv",
                display: "x1lliihq",
                outline: "x1a2a7pz",
                paddingTop: "x1y1aw1k",
                paddingEnd: "x4uap5",
                paddingBottom: "xwib8y2",
                paddingStart: "xkhd6sd",
                textAlign: "x1yc453h",
                width: "xafpxmx"
            },
            menuOptions: {
                marginTop: "x1anpbxc"
            },
            menuOptionValue: {
                fontSize: "x1nxh6w3",
                fontWeight: "xo1l8bm"
            },
            pressableOption: {
                width: "xh8yej3"
            }
        },
        m = {
            captionsBackgroundColor: {
                Black: "BLACK",
                Blue: "BLUE",
                Cyan: "CYAN",
                Green: "GREEN",
                Magenta: "MAGENTA",
                Red: "RED",
                White: "WHITE",
                Yellow: "YELLOW"
            },
            captionsBackgroundOpacity: {
                "0%": "TRANSPARENT",
                "25%": "LIGHT",
                "45%": "DEFAULT",
                "75%": "DARK",
                "100%": "OPAQUE"
            },
            captionsTextColor: {
                Black: "BLACK",
                Blue: "BLUE",
                Cyan: "CYAN",
                Green: "GREEN",
                Magenta: "MAGENTA",
                Red: "RED",
                White: "WHITE",
                Yellow: "YELLOW"
            },
            captionsTextSize: {
                "(50%)": "SMALLEST",
                "(75%)": "SMALL",
                "(100%)": "DEFAULT",
                "(125%)": "MEDIUM",
                "(150%)": "BIG",
                "(175%)": "BIGGER",
                "(200%)": "BIGGEST"
            }
        },
        n = {
            "Background Color": {
                ftbLabel: h._("Background Color"),
                name: "captionsBackgroundColor"
            },
            "Background Opacity": {
                ftbLabel: h._("Background Opacity"),
                name: "captionsBackgroundOpacity"
            },
            "Text Color": {
                ftbLabel: h._("Text Color"),
                name: "captionsTextColor"
            },
            "Text Size": {
                ftbLabel: h._("Text Size"),
                name: "captionsTextSize"
            }
        },
        o = {
            Black: h._("Black"),
            Blue: h._("Blue"),
            Cyan: h._("Cyan"),
            Green: h._("Green"),
            Magenta: h._("Magenta"),
            Red: h._("Red"),
            White: h._("White"),
            Yellow: h._("Yellow")
        };

    function p(a) {
        var b = null,
            c = null;
        switch (a) {
            case "(50%)":
                b = h._("Small");
                c = "X-";
                break;
            case "(75%)":
                b = h._("Small");
                break;
            case "(125%)":
                b = h._("Large");
                break;
            case "(150%)":
                b = h._("Large");
                c = "X-";
                break;
            case "(175%)":
                b = h._("Large");
                c = "XX-";
                break;
            case "(200%)":
                b = h._("Large");
                c = "XXX-";
                break;
            case "(100%)":
                b = h._("Medium")
        }
        return j.jsxs("span", {
            children: [c != null && c, b, a]
        })
    }
    p.displayName = p.name + " [from " + f.id + "]";
    var q = {
        captionsBackgroundColor: d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_BG_COLOR,
        captionsBackgroundOpacity: d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_BG_OPACITY,
        captionsTextColor: d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_TEXT_COLOR,
        captionsTextSize: d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_TEXT_SIZE
    };

    function r(a) {
        var b = a.onPressLog,
            d = a.option,
            e = a.optionVal,
            f = a.setPane,
            g = n[d].name;
        a = k(function() {
            f(q[g]), b && b("captions_display_main_menu", d)
        }, [g, f, d, b]);
        var h = null;
        switch (g) {
            case "captionsTextColor":
            case "captionsBackgroundColor":
                h = o[e];
                break;
            default:
                h = e;
                break
        }
        var m = d.replace(" ", "");
        m = "video-player-captions-menu-captions-display-main-" + m;
        return j.jsxs(c("CometPressable.react"), {
            onPress: a,
            xstyle: l.menuOptionRow,
            children: [j.jsxs("div", {
                className: c("stylex")(l.menuOptionLabel),
                children: [n[d].ftbLabel, j.jsx("div", {
                    className: c("stylex")(l.menuOptionValue),
                    "data-testid": void 0,
                    children: g === "captionsTextSize" ? p(e) : h
                })]
            }), j.jsx("div", {
                className: c("stylex")(l.icon),
                children: j.jsx("div", {
                    className: c("stylex")(l.chevronRight),
                    children: j.jsx("div", {
                        style: {
                            display: "table-cell"
                        },
                        children: j.jsx(c("CometImage.react"), {
                            src: i("480588")
                        })
                    })
                })
            })]
        })
    }
    r.displayName = r.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.currentCaptionsDisplay,
            e = a.onPressLog,
            f = a.setPane;
        a = k(function() {
            f(d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_MAIN)
        }, [f]);
        return j.jsxs(d("FocusRegion.react").FocusRegion, {
            autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            children: [j.jsx("div", {
                className: c("stylex")(l.menuHeading),
                children: j.jsxs(c("CometPressable.react"), {
                    onPress: a,
                    xstyle: l.pressableOption,
                    children: [j.jsx("span", {
                        className: c("stylex")(l.chevronLeft),
                        children: j.jsx(c("CometImage.react"), {
                            src: i("480580")
                        })
                    }), j.jsx("span", {
                        className: c("stylex")(l.captionsDisplayLabel),
                        children: h._("Subtitle Options")
                    })]
                })
            }), j.jsx("div", {
                className: c("stylex")(l.menuOptions),
                "data-testid": void 0,
                children: Object.keys(n).map(function(a) {
                    var c = n[a].name,
                        d = m[c];
                    d = Object.fromEntries(Object.entries(d).map(function(a) {
                        var b = a[0];
                        a = a[1];
                        return [a, b]
                    }));
                    d = b != null ? d[b[c]] : "";
                    return j.jsx(r, {
                        onPressLog: e,
                        option: a,
                        optionVal: d,
                        setPane: f
                    }, a)
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.captionsDisplayOptionsMap = m;
    g.colorsFBTMap = o;
    g.getFontSizeDivWithFBTLabel = p;
    g.VideoPlayerCaptionsMenuCaptionsDisplayMainPane = a
}), 98);
__d("VideoPlayerCaptionsSettingMutation", ["CometRelay", "VideoPlayerCaptionsSettingMutation.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("VideoPlayerCaptionsSettingMutation.graphql");

    function a(a, b, c) {
        return d("CometRelay").commitMutation(a, {
            mutation: i,
            onCompleted: c && c.onCompleted,
            onError: c && c.onError,
            optimisticResponse: {
                video_captions_setting: {
                    success: !0
                }
            },
            variables: {
                input: {
                    captions_background_color: b.captions_background_color,
                    captions_background_opacity: b.captions_background_opacity,
                    captions_text_color: b.captions_text_color,
                    captions_text_size: b.captions_text_size,
                    client_mutation_id: "www_captions_settings"
                }
            }
        })
    }
    g.commit = a
}), 98);
__d("VideoPlayerCaptionsMenuCaptionsDisplayPane.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "CometRelay", "FocusRegion.react", "TetraIcon.react", "VideoPlayerCaptionsMenu.react", "VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react", "VideoPlayerCaptionsSettingMutation", "VideoPlayerHooks", "fbicon", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useCallback,
        l = {
            chevronLeft: {
                alignItems: "x6s0dn4",
                display: "x3nfvp2",
                width: "x1849jeq"
            },
            icon: {
                display: "x1rg5ohu",
                width: "x1849jeq"
            },
            menuHeading: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x78zum5",
                fontSize: "x1nxh6w3",
                fontWeight: "x1s688f",
                ":hover": {
                    textDecoration: "x1lku1pv"
                }
            },
            menuLabel: {
                cursor: "x1ypdohk",
                display: "x1rg5ohu"
            },
            menuOptionRow: {
                color: "x14ctfv",
                display: "x1lliihq",
                outline: "x1a2a7pz",
                paddingTop: "x1y1aw1k",
                paddingEnd: "x4uap5",
                paddingBottom: "xwib8y2",
                paddingStart: "xkhd6sd",
                textAlign: "x1yc453h"
            },
            menuOptions: {
                fontSize: "x1nxh6w3",
                fontWeight: "xo1l8bm",
                marginTop: "x1anpbxc"
            },
            pressableOption: {
                width: "xh8yej3"
            }
        },
        m = {
            captionsBackgroundColor: h._("Background Color"),
            captionsBackgroundOpacity: h._("Background Opacity"),
            captionsTextColor: h._("Text Color"),
            captionsTextSize: h._("Text Size")
        },
        n = function(a) {
            return {
                captions_background_color: a.captionsBackgroundColor,
                captions_background_opacity: a.captionsBackgroundOpacity,
                captions_text_color: a.captionsTextColor,
                captions_text_size: a.captionsTextSize
            }
        };

    function o(a) {
        var b = a.captionsDisplayOption,
            e = a.currentCaptionsDisplay,
            f = a.onPressLog,
            g = a.option,
            h = a.selected,
            m = a.setPane,
            o = d("VideoPlayerHooks").useController();
        a = h;
        var p = d("VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react").captionsDisplayOptionsMap[b];
        h = null;
        switch (b) {
            case "captionsTextColor":
            case "captionsBackgroundColor":
                h = d("VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react").colorsFBTMap[g];
                break;
            default:
                h = g
        }
        var q = "video-player-captions-menu-captions-display-pane-" + b + "-" + g;
        q = k(function() {
            a = !0;
            if (e != null) {
                e[b] = p[g];
                o.setCaptionsDisplayStyle(e);
                var c = n(e);
                d("VideoPlayerCaptionsSettingMutation").commit(r, c)
            }
            m(d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_DISPLAY_MAIN);
            f && f(b)
        }, [e, p, b, o, g]);
        var r = d("CometRelay").useRelayEnvironment();
        return j.jsxs(c("CometPressable.react"), {
            onPress: q,
            testid: void 0,
            xstyle: l.menuOptionRow,
            children: [j.jsx("div", {
                className: c("stylex")(l.icon),
                children: a && j.jsx("div", {
                    "data-testid": void 0,
                    children: j.jsx(c("TetraIcon.react"), {
                        color: "white",
                        icon: d("fbicon")._(i("477813"), 16)
                    })
                })
            }), b === "captionsTextSize" ? d("VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react").getFontSizeDivWithFBTLabel(g) : j.jsx("div", {
                className: c("stylex")(l.menuLabel),
                children: h
            })]
        })
    }
    o.displayName = o.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.captionsDisplayOption,
            e = a.currentCaptionsDisplay,
            f = a.onPressLog,
            g = a.setPane;
        a = m[b];
        var h = d("VideoPlayerCaptionsMenuCaptionsDisplayMainPane.react").captionsDisplayOptionsMap[b],
            n = e != null ? e[b] : null,
            p = k(function() {
                g(d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_DISPLAY_MAIN)
            }, [g]),
            q = "video-player-captions-menu-captions-display-pane-" + b;
        return j.jsxs(d("FocusRegion.react").FocusRegion, {
            autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            children: [j.jsx("div", {
                className: c("stylex")(l.menuHeading),
                children: j.jsxs(c("CometPressable.react"), {
                    onPress: p,
                    testid: void 0,
                    xstyle: l.pressableOption,
                    children: [j.jsx("span", {
                        className: c("stylex")(l.chevronLeft),
                        children: j.jsx(c("CometImage.react"), {
                            src: i("480580")
                        })
                    }), a]
                })
            }), j.jsx("div", {
                className: c("stylex")(l.menuOptions),
                "data-testid": void 0,
                children: Object.keys(h).map(function(a) {
                    var c = n === h[a];
                    return j.jsx(o, {
                        captionsDisplayOption: b,
                        currentCaptionsDisplay: e,
                        onPressLog: f,
                        option: a,
                        selected: c,
                        setPane: g
                    }, a)
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.VideoPlayerCaptionsMenuCaptionsDisplayPane = a
}), 98);
__d("VideoPlayerCaptionsMenuMainPane.react", ["fbt", "ix", "CometPressable.react", "CometScrollableArea.react", "FocusRegion.react", "TetraIcon.react", "VideoPlayerCaptionsMenuTopBar.react", "VideoPlayerHooks", "fbicon", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useEffect,
        l = {
            icon: {
                display: "x1rg5ohu",
                width: "xw4jnvo"
            },
            menuLabel: {
                cursor: "x1ypdohk",
                display: "x1rg5ohu",
                marginStart: "x17adc0v",
                width: "xzjbwwf"
            },
            menuOptionRow: {
                color: "x14ctfv",
                display: "x1lliihq",
                fontSize: "x1nxh6w3",
                fontWeight: "xo1l8bm",
                minWidth: "xfvyar9",
                outline: "x1a2a7pz",
                paddingTop: "x1y1aw1k",
                paddingEnd: "x4uap5",
                paddingBottom: "xwib8y2",
                paddingStart: "xkhd6sd",
                textAlign: "x1yc453h",
                ":hover": {
                    backgroundColor: "xx8nu07"
                }
            },
            menuOptions: {
                marginTop: "x1anpbxc",
                maxHeight: "x15eivr9"
            },
            moreOptionsLabel: {
                cursor: "x1ypdohk",
                display: "x1rg5ohu",
                marginStart: "x1iedhe"
            }
        },
        m = 5;

    function n(a) {
        var b, e = a.captions,
            f = a.captionsVisible,
            g = a.controller,
            k = a.focused,
            m = a.onPressLog,
            n = a.setSelectedCaptionsLocale;
        a = d("VideoPlayerHooks").useIsVideoBroadcast();
        a = e.localized_creation_method != null || a;
        b = "video-player-captions-menu-language-list-item-" + ((b = e.localized_language) != null ? b : "");
        return j.jsxs(c("CometPressable.react"), {
            onPress: function() {
                var a;
                e.locale != null && n(e.locale);
                f || g.setCaptionsVisible(!0);
                e.captions_url != null && g.setCaptionsUrl(e.captions_url);
                m && m("captions_language_selector", (a = e.localized_language) != null ? a : "")
            },
            testid: void 0,
            xstyle: l.menuOptionRow,
            children: [j.jsx("div", {
                className: c("stylex")(l.icon),
                children: k && j.jsx("div", {
                    "data-testid": void 0,
                    children: j.jsx(c("TetraIcon.react"), {
                        color: "white",
                        icon: d("fbicon")._(i("477813"), 16)
                    })
                })
            }), j.jsxs("div", {
                className: c("stylex")(l.menuLabel),
                children: [e.localized_language, (b = e.localized_country) != null ? b : null, !a && h._("(Provided by Author)")]
            })]
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        var b = a.availableCaptionsLocales,
            e = a.captionsListExpanded,
            f = a.children,
            g = a.onPressLog,
            o = a.selectedCaptionsLocale,
            p = a.setCaptionsListExpanded,
            q = a.setPane,
            r = a.setSelectedCaptionsLocale,
            s = d("VideoPlayerHooks").useController(),
            t = d("VideoPlayerHooks").useCaptionsVisible();
        a = b != null ? b.length : 0;
        k(function() {
            t || r("")
        }, [t, r]);
        return b == null ? null : j.jsx(d("FocusRegion.react").FocusRegion, {
            autoFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            recoverFocusQuery: d("focusScopeQueries").headerFirstTabbableSecondScopeQuery,
            children: j.jsxs("div", {
                "data-testid": void 0,
                children: [j.jsx(c("VideoPlayerCaptionsMenuTopBar.react"), {
                    availableCaptionsLocales: b,
                    onPressLog: g,
                    setPane: q
                }), f, j.jsx(c("CometScrollableArea.react"), {
                    hideScrollbar: !0,
                    children: j.jsxs("div", {
                        className: c("stylex")(l.menuOptions),
                        "data-testid": void 0,
                        children: [j.jsxs(c("CometPressable.react"), {
                            onPress: function() {
                                r(""), s.setCaptionsVisible(!1)
                            },
                            xstyle: l.menuOptionRow,
                            children: [j.jsx("div", {
                                className: c("stylex")(l.icon),
                                children: o === "" && j.jsx(c("TetraIcon.react"), {
                                    color: "white",
                                    icon: d("fbicon")._(i("477813"), 16)
                                })
                            }), j.jsx("div", {
                                className: c("stylex")(l.menuLabel),
                                children: h._("Off")
                            })]
                        }), b.slice(0, 4).map(function(a) {
                            var b = a.locale === o;
                            return a.localized_language != null ? j.jsx(n, {
                                captions: a,
                                captionsVisible: t,
                                controller: s,
                                focused: b,
                                onPressLog: g,
                                setSelectedCaptionsLocale: r
                            }, a.locale) : null
                        }), a >= m && !e && j.jsx(c("CometPressable.react"), {
                            onPress: function() {
                                p(!0)
                            },
                            xstyle: l.menuOptionRow,
                            children: j.jsx("div", {
                                className: c("stylex")(l.moreOptionsLabel),
                                children: h._("See more")
                            })
                        }), e && b.slice(4).map(function(a) {
                            var b = a.locale === o;
                            return a.localized_language != null ? j.jsx(n, {
                                captions: a,
                                captionsVisible: t,
                                controller: s,
                                focused: b,
                                setSelectedCaptionsLocale: r
                            }, a.locale) : null
                        }), e && j.jsx(c("CometPressable.react"), {
                            onPress: function() {
                                p(!1)
                            },
                            xstyle: l.menuOptionRow,
                            children: j.jsx("div", {
                                className: c("stylex")(l.moreOptionsLabel),
                                children: h._("See less")
                            })
                        })]
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.VideoPlayerCaptionsMenuMainPane = a
}), 98);
__d("VideoPlayerCaptionsMenuTopBar.react", ["fbt", "ix", "CometImage.react", "CometPressable.react", "VideoPlayerCaptionsMenu.react", "VideoPlayerHooks", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useCallback,
        l = {
            "default": {
                color: "x14ctfv",
                display: "x78zum5",
                minWidth: "x1jzhcrs"
            },
            label: {
                fontSize: "x1nxh6w3",
                fontWeight: "x1s688f"
            },
            labelAutoGenerated: {
                fontSize: "x1nxh6w3",
                fontStyle: "x1k4tb9n"
            },
            option: {
                alignItems: "x6s0dn4",
                color: "x14ctfv",
                cursor: "x1ypdohk",
                display: "x3nfvp2",
                flexGrow: "x1bhwmg6",
                justifyContent: "x13a6bvl",
                marginStart: "x8zvzrc"
            },
            optionsLabel: {
                display: "x3nfvp2",
                fontWeight: "xo1l8bm",
                marginStart: "x1mnrxsn"
            },
            pressableOption: {
                width: "xh8yej3"
            },
            settingIconRight: {
                display: "x3nfvp2"
            }
        };

    function a(a) {
        var b = a.availableCaptionsLocales,
            e = a.onPressLog,
            f = a.setPane;
        a = k(function() {
            f(d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenuPaneType.CAPTIONS_DISPLAY_MAIN), e && e("captions_main_menu_top_bar")
        }, [f, e]);
        var g = d("VideoPlayerHooks").useIsVideoBroadcast();
        b = (b == null ? void 0 : b.some(function(a) {
            return a.localized_creation_method != null
        })) || g;
        return j.jsxs("div", {
            children: [j.jsx("div", {
                className: c("stylex")(l["default"]),
                children: j.jsxs(c("CometPressable.react"), {
                    onPress: a,
                    testid: void 0,
                    xstyle: l.pressableOption,
                    children: [j.jsx("div", {
                        className: c("stylex")(l.label),
                        children: h._("Subtitles")
                    }), j.jsxs("div", {
                        className: c("stylex")(l.option),
                        children: [j.jsx("span", {
                            className: c("stylex")(l.settingIconRight),
                            children: j.jsx(c("CometImage.react"), {
                                src: i("492300")
                            })
                        }), j.jsx("div", {
                            className: c("stylex")(l.optionsLabel),
                            children: h._("Options")
                        })]
                    })]
                })
            }), b != null && b && j.jsx("div", {
                className: c("stylex")(l.labelAutoGenerated),
                children: h._("Auto-generated")
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerLoggingSuboriginContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("VideoPlayerCaptionsControl.react", ["fbt", "ix", "CometRelay", "IntlCurrentLocale", "VideoPlayerCaptionsControl_video.graphql", "VideoPlayerCaptionsMenu.react", "VideoPlayerControlIcon.react", "VideoPlayerDefaultControlsProperties", "VideoPlayerHooks", "VideoPlayerLoggingSuboriginContext", "VideoPlayerUserInteractionCounter", "fbicon", "react", "requireDeferred", "stylex", "usePlayerOriginRouteTracePolicy"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = d("react");
    e = d("react");
    var l = e.useCallback,
        m = e.useContext,
        n = e.useEffect,
        o = e.useRef,
        p = e.useState,
        q = c("requireDeferred")("VideoHomeTypedLoggerLite").__setRef("VideoPlayerCaptionsControl.react");

    function a(a) {
        var e = a.alignMenuToIcon;
        e = e === void 0 ? !1 : e;
        var f = a.captionsVisible,
            g = a.children;
        g = g === void 0 ? null : g;
        var r = a.compactMenu,
            s = a.icon,
            t = a.menuOpened,
            u = a.onMenuOpen,
            v = a.onUserInteraction,
            w = a.setMenuOpened;
        a = a.video;
        var x = h._("Captions");
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_captions_menu", t === d("VideoPlayerDefaultControlsProperties").VideoMenuType.VIDEO_CAPTIONS_MENU, v);
        v = d("CometRelay").useFragment(j !== void 0 ? j : j = b("VideoPlayerCaptionsControl_video.graphql"), a);
        var y = d("VideoPlayerHooks").useMuted(),
            z = d("VideoPlayerHooks").useController(),
            A = c("usePlayerOriginRouteTracePolicy")(),
            B = v == null ? void 0 : v.video_available_captions_locales,
            C = v == null ? void 0 : v.captions_url;
        a = p("");
        v = a[0];
        var D = a[1],
            E = o(null),
            F = o(null);
        n(function() {
            B == null ? void 0 : B.map(function(a) {
                a.captions_url === C && a.locale != null && (E.current = a.locale, D(a.locale))
            })
        }, [B, C]);
        a = [];
        var G = c("IntlCurrentLocale").code;
        n(function() {
            E.current !== G && F.current === null ? (z.setCaptionsVisible(!1), F.current = !1) : y && !f && F.current === null ? (F.current = !0, z.setCaptionsVisible(!0)) : !y && F.current === !0 && (z.setCaptionsVisible(!1), F.current = !1)
        }, [f, z, y, G]);
        if (B != null)
            for (var H = B, I = Array.isArray(H), J = 0, H = I ? H : H[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var K;
                if (I) {
                    if (J >= H.length) break;
                    K = H[J++]
                } else {
                    J = H.next();
                    if (J.done) break;
                    K = J.value
                }
                K = K;
                K = {
                    captions_url: K.captions_url,
                    locale: K.locale,
                    localized_country: K.localized_country,
                    localized_creation_method: K.localized_creation_method,
                    localized_language: K.localized_language
                };
                a.push(K)
            }
        a.sort(function(a, b) {
            return ((a = a.localized_language) != null ? a : "") > ((a = b.localized_language) != null ? a : "") ? 1 : -1
        });
        var L = t === d("VideoPlayerDefaultControlsProperties").VideoMenuType.VIDEO_CAPTIONS_MENU;
        K = p(!1);
        J = K[0];
        I = K[1];
        var M = m(c("VideoPlayerLoggingSuboriginContext")),
            N = l(function(a, b) {
                a === void 0 && (a = null), b === void 0 && (b = null), q.onReady(function(c) {
                    c.log({
                        click_point: a,
                        event: "click",
                        event_target_info: A,
                        event_target_sub_type: b,
                        player_suborigin: M
                    })
                })
            }, [A, M]);
        return k.jsxs("div", {
            className: "x1mnrxsn xzueoph x1w0mnb x1k70j0n x1rg5ohu" + (e === !0 ? " xuxw1ft x1n2onr6" : ""),
            "data-testid": void 0,
            children: [L && k.jsx("div", {
                className: c("stylex")({
                    "background-color-1": "x1av4zun",
                    "border-top-start-radius-1": "x1lcm9me",
                    "border-top-end-radius-1": "x1yr5g0i",
                    "border-bottom-end-radius-1": "xrt01vj",
                    "border-bottom-start-radius-1": "x10y3i5r",
                    "bottom-1": "xacj9c0",
                    "color-1": "x14ctfv",
                    "margin-left-1": "x89ytp0",
                    "max-height-1": "x1hdnelj",
                    "max-width-1": "xgmxx4u",
                    "padding-top-1": "xyamay9",
                    "padding-end-1": "x1pi30zi",
                    "padding-bottom-1": "x1l90r2v",
                    "padding-start-1": "x1swvt13",
                    "position-1": "x10l6tqk",
                    "right-1": "xk6ci0l",
                    "width-1": "x1602a87"
                }, r === !0 ? {
                    "right-1": "xwjie4w"
                } : null, e === !0 ? {
                    "right-1": "x1g75g36"
                } : null),
                children: k.jsx(d("VideoPlayerCaptionsMenu.react").VideoPlayerCaptionsMenu, {
                    availableCaptionsLocales: a,
                    captionsListExpanded: J,
                    onClose: function() {
                        w != null && w(null)
                    },
                    onPressLog: N,
                    selectedCaptionsLocale: v,
                    setCaptionsListExpanded: I,
                    setSelectedCaptionsLocale: D,
                    children: g
                })
            }), k.jsx(c("VideoPlayerControlIcon.react"), {
                icon: s == null ? f ? d("fbicon")._(i("662652"), 20) : d("fbicon")._(i("662655"), 20) : s,
                label: x,
                onPress: function() {
                    w != null && w(L ? null : d("VideoPlayerDefaultControlsProperties").VideoMenuType.VIDEO_CAPTIONS_MENU), !L && u != null && u(), N("closed_captions_button")
                },
                tooltip: x
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerControlsGroups.react", ["VideoControlsContainerFocusedContext", "VideoPlayerControlsHiddenContext", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        var b = a.children,
            d = a.isVisible;
        d = d === void 0 ? !0 : d;
        var e = a.noPaddingEnd;
        e = e === void 0 ? !1 : e;
        a = a.noPaddingStart;
        a = a === void 0 ? !1 : a;
        var f = i(c("VideoControlsContainerFocusedContext"));
        d = d || f;
        f = i(c("VideoPlayerControlsHiddenContext"));
        return h.jsx("div", {
            className: c("stylex")({
                "align-items-1": "x6s0dn4",
                "display-1": "x78zum5",
                "flex-direction-1": "x1q0g3np",
                "flex-shrink-1": "x2lah0s",
                "flex-wrap-1": "xozqiw3"
            }, {
                "padding-top-1": "xexx8yu",
                "padding-end-1": "x1mpkggp",
                "padding-bottom-1": "x18d9i69",
                "padding-start-1": "x1t2a60a"
            }, e ? {
                "padding-end-1": "x4uap5"
            } : null, a ? {
                "padding-start-1": "xkhd6sd"
            } : null, d ? {
                "opacity-1": "x1hc1fzr"
            } : {
                "opacity-1": "x1fmh03i",
                "pointer-events-1": "x47corl"
            }),
            children: h.jsx(c("VideoPlayerControlsHiddenContext").Provider, {
                value: f || !d,
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function b(a) {
        var b = a.children;
        a = a.isVisible;
        a = a === void 0 ? !0 : a;
        var d = i(c("VideoControlsContainerFocusedContext"));
        a = a || d;
        d = i(c("VideoPlayerControlsHiddenContext"));
        return h.jsx("div", {
            className: c("stylex")({
                "align-items-1": "x6s0dn4",
                "display-1": "x78zum5",
                "flex-direction-1": "x1q0g3np",
                "flex-shrink-1": "x2lah0s",
                "flex-wrap-1": "xozqiw3"
            }, {
                "flex-grow-1": "x1iyjqo2"
            }, a ? {
                "opacity-1": "x1hc1fzr"
            } : {
                "opacity-1": "x1fmh03i",
                "pointer-events-1": "x47corl"
            }),
            children: h.jsx(c("VideoPlayerControlsHiddenContext").Provider, {
                value: d || !a,
                children: b
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g.Contracted = a;
    g.Expanded = b
}), 98);
__d("VideoPlayerCastControlShim.react", ["CometPlaceholder.react", "VideoPlayerControlsGroups.react", "cr:11811", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var e = a.isVisible;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["isVisible"]);
        return h.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: e,
            noPaddingEnd: !0,
            noPaddingStart: !0,
            children: h.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                children: h.jsx(b("cr:11811"), babelHelpers["extends"]({}, a))
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerCastControlShimImpl.legacy.react", ["JSResourceForInteraction", "lazyLoadComponent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("lazyLoadComponent")(c("JSResourceForInteraction")("VideoPlayerCastControl.react").__setRef("VideoPlayerCastControlShimImpl.legacy.react"));
    g["default"] = a
}), 98);
__d("useNavigateToTahoePassthroughProps", ["CometProductTagFunnelIDContext", "CometTrackingCodeContext", "CometTrackingNodesContext", "CometWarningScreenContext", "VideoPlayerHooks", "getAggregatedStoryTrackingNodeIndex", "react", "useIsVideoHomePlayerOriginFromTracePolicy", "usePlayerOriginRouteTracePolicy", "useVideoPlayerPortalingPassthroughProps"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        var a = c("useVideoPlayerPortalingPassthroughProps")(),
            b = h(c("CometTrackingCodeContext")),
            e = h(c("CometTrackingNodesContext")),
            f = h(c("CometProductTagFunnelIDContext")),
            g = d("CometWarningScreenContext").useIsOverlayShown(),
            i = d("CometWarningScreenContext").useHasOverlay();
        e = c("getAggregatedStoryTrackingNodeIndex")(e);
        var j = d("VideoPlayerHooks").useVideoPlayerInitialTracePolicy(),
            k = c("usePlayerOriginRouteTracePolicy")(),
            l = c("useIsVideoHomePlayerOriginFromTracePolicy")(k);
        return babelHelpers["extends"]({
            bypassAutoplaySettings: !0
        }, a, {
            index: e,
            initialTracePolicy: (a = j) != null ? a : k,
            origOverlayShown: g,
            overlayExists: i,
            productTagFunnelID: f,
            trackingCode: b
        }, l ? {
            caller: "CHANNEL_VIEW_FROM_VIDEO_HOME"
        } : {})
    }
    g["default"] = a
}), 98);
__d("VideoPlayerCometNavigateToTahoeControl.react", ["fbt", "ix", "VideoPlayerControlIcon.react", "fbicon", "react", "useNavigateToTahoePassthroughProps"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.onPress,
            e = a.reactionVideoChannelType,
            f = a.subOrigin;
        a = a.videoTahoeUrl;
        var g = c("useNavigateToTahoePassthroughProps")();
        g = babelHelpers["extends"]({}, g, {
            playerSubOrigin: f,
            reactionVideoChannelType: e
        });
        f = h._("Enlarge");
        return j.jsx(c("VideoPlayerControlIcon.react"), {
            icon: d("fbicon")._(i("517763"), 20),
            label: f,
            linkProps: {
                passthroughProps: g,
                url: a
            },
            onPress: b,
            tooltip: f
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerControlsContainerOverlay.react", ["CometErrorBoundary.react", "FocusWithinHandler.react", "VideoControlsContainerFocusedContext", "VideoPlayerControlsBottomRowAddOnContext", "VideoPlayerControlsHiddenContext", "VideoPlayerHooks", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useEffect,
        j = 44,
        k = {
            backgroundGradient: {
                backgroundImage: "x11v4dcs",
                bottom: "x1ey2m1c",
                height: "xn3w4p2",
                position: "x10l6tqk",
                transitionDuration: "x1d8287x",
                transitionProperty: "x6o7n8i",
                transitionTimingFunction: "xl405pv",
                width: "xh8yej3",
                zIndex: "x8knxv4"
            },
            "default": {
                bottom: "x1ey2m1c",
                flexDirection: "x1q0g3np",
                position: "x10l6tqk",
                transitionDuration: "x1d8287x",
                transitionProperty: "x6o7n8i",
                transitionTimingFunction: "xl405pv",
                width: "xh8yej3",
                zIndex: "x11uqc5h"
            },
            firstRow: {
                alignItems: "x6s0dn4",
                direction: "xzt5al7",
                display: "x78zum5",
                flexDirection: "x1q0g3np"
            },
            hidden: {
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                visibility: "xlshs6z"
            },
            visible: {
                opacity: "x1hc1fzr"
            }
        };

    function a(a) {
        var b = a.children,
            e = a.initialBottomRowAddOn;
        e = e === void 0 ? null : e;
        var f = a.isBackgroundVisible,
            g = a.isVisible,
            l = a.xstyle,
            m = d("VideoPlayerControlsBottomRowAddOnContext").useVideoPlayerControlsBottomRowAddOn(e);
        a = d("VideoPlayerHooks").useVideoPlayerCaptionsReservationActions();
        var n = a.release,
            o = a.reserve;
        i(function() {
            if (Boolean(g) || Boolean(f)) {
                var a = o({
                    location: "bottom",
                    size: j
                });
                return function() {
                    n(a)
                }
            }
        }, [g, f, o, n]);
        var p = f === !1 || g === !1,
            q = f === !0 || g === !0;
        return h.jsx(c("FocusWithinHandler.react"), {
            children: function(a, d) {
                return h.jsx(c("VideoControlsContainerFocusedContext").Provider, {
                    value: d,
                    children: h.jsxs("div", {
                        className: c("stylex")(k["default"], m == null && k.firstRow, g === !1 && k.hidden, g === !0 && k.visible),
                        "data-testid": void 0,
                        children: [h.jsx("div", {
                            className: c("stylex")(k.backgroundGradient, p && k.hidden, q && k.visible, l)
                        }), h.jsx(c("VideoPlayerControlsHiddenContext").Provider, {
                            value: p,
                            children: m == null ? b : h.jsxs(h.Fragment, {
                                children: [h.jsx("div", {
                                    className: c("stylex")(k.firstRow),
                                    children: b
                                }), h.jsx(c("CometErrorBoundary.react"), {
                                    children: m
                                })]
                            })
                        })]
                    })
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTahoeCustomVideoAreaContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useMemo,
        j = b.useState,
        k = h.createContext({
            customVideoAreaHidden: !0,
            setCustomVideoAreaHidden: c("emptyFunction")
        });

    function a(a) {
        a = a.children;
        var b = j(!0),
            c = b[0],
            d = b[1];
        b = i(function() {
            return {
                customVideoAreaHidden: c,
                setCustomVideoAreaHidden: d
            }
        }, [c, d]);
        return h.jsx(k.Provider, {
            value: b,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.CometTahoeCustomVideoAreaContext = k;
    g.CometTahoeCustomVideoAreaContextProvider = a
}), 98);
__d("VideoPlayerJoinOnPortalControl.react", ["cr:1795495", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    a = function(a) {
        a = a.isVisible;
        return !a || b("cr:1795495") == null ? null : h.jsx(b("cr:1795495"), {})
    };
    c = a;
    g["default"] = c
}), 98);
__d("VideoPlayerPlaybackControlBase.react", ["fbt", "ix", "VideoPlayerControlIcon.react", "fbicon", "react", "unrecoverableViolation"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.onPress;
        a = a.playbackIcon;
        var e, f;
        switch (a) {
            case "pause":
                e = h._("Pause");
                f = d("fbicon")._(i("497675"), 20);
                break;
            case "replay":
                e = h._("Replay");
                f = d("fbicon")._(i("534219"), 20);
                break;
            case "play":
                e = h._("Play");
                f = d("fbicon")._(i("484863"), 20);
                break;
            default:
                a;
                throw c("unrecoverableViolation")("The playback icon is unsupported " + a, "comet_video_player")
        }
        return j.jsx(c("VideoPlayerControlIcon.react"), {
            icon: f,
            label: e,
            onPress: b,
            tooltip: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerPlaybackControl.react", ["VideoHomeTypedLoggerLite", "VideoPlayerHooks", "VideoPlayerPlaybackControlBase.react", "react", "useFeedClickEventHandler", "useVideoPlayerControllerSubscription"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useEffect;

    function a(a) {
        var b = a.isNPC,
            e = b === void 0 ? !1 : b;
        b = a.unmuteOnPlay;
        var f = b === void 0 ? !1 : b;
        i(function() {
            e && c("VideoHomeTypedLoggerLite").log({
                event: "npc_control_playback_button_impression"
            })
        }, [e]);
        a = c("useVideoPlayerControllerSubscription")(function(a, b) {
            var c = a.getCurrentState(),
                d = c.ended,
                e = c.paused,
                f = c.playing,
                g = c.stalling;
            a = a.getPlayheadPosition();
            c = c.duration;
            e = !e && (f || g);
            g = !f && d && a >= c;
            return b != null && b.showPauseButton === e && b.showReplayButton === g ? b : {
                showPauseButton: e,
                showReplayButton: g
            }
        });
        var g = a.showPauseButton;
        b = a.showReplayButton;
        var j = d("VideoPlayerHooks").useController();
        a = c("useFeedClickEventHandler")(function() {
            e && c("VideoHomeTypedLoggerLite").log({
                click_point: "npc_control_playback_button",
                event: "click",
                event_target: "video"
            }), g ? j.pause("user_initiated") : (f && j.setMuted(!1, "user_initiated"), j.play("user_initiated"))
        });
        b = g ? "pause" : b ? "replay" : "play";
        return h.jsx(c("VideoPlayerPlaybackControlBase.react"), {
            onPress: a,
            playbackIcon: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTahoeSidePaneContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = {
        rightRailHidden: !1,
        setRightRailHidden: function() {}
    };
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("VideoPlayerQuietModeControl.react", ["fbt", "ix", "CometTahoeSidePaneContext", "VideoPlayerControlIcon.react", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useContext;

    function a() {
        var a = k(c("CometTahoeSidePaneContext")),
            b = a.rightRailHidden,
            e = a.setRightRailHidden;
        a = b ? h._("Show comments and reactions") : h._("Hide comments and reactions");
        return j.jsx("div", {
            className: "x1mnrxsn xzueoph x1w0mnb x1k70j0n x1rg5ohu",
            children: j.jsx(c("VideoPlayerControlIcon.react"), {
                icon: b ? d("fbicon")._(i("942218"), 20) : d("fbicon")._(i("942221"), 20),
                label: a,
                onPress: function() {
                    e(!b)
                },
                tooltip: a
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerSettingsControl.react", ["fbt", "ix", "VideoPlayerControlIcon.react", "VideoPlayerDefaultControlsProperties", "VideoPlayerSettingsMenu.react", "VideoPlayerUserInteractionCounter", "fbicon", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useState;
    a = j.forwardRef(function(a, b) {
        var e = a.alignMenuToIcon;
        e = e === void 0 ? !1 : e;
        var f = a.children;
        f = f === void 0 ? null : f;
        var g = a.compactMenu,
            l = a.icon,
            m = a.menuOpened,
            n = a.onMenuOpen,
            o = a.onUserInteraction,
            p = a.setMenuOpened;
        a = k(!1);
        var q = a[0],
            r = a[1];
        a = h._("Settings");
        var s = p != null;
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_settings_menu", s ? m === d("VideoPlayerDefaultControlsProperties").VideoMenuType.VIDEO_SETTINGS_MENU : q, o);
        var t = s ? m === d("VideoPlayerDefaultControlsProperties").VideoMenuType.VIDEO_SETTINGS_MENU : q;
        return j.jsxs("div", {
            className: "x1mnrxsn xzueoph x1w0mnb x1k70j0n x1rg5ohu" + (e === !0 ? " xuxw1ft x1n2onr6" : ""),
            ref: b,
            children: [t && j.jsx("div", {
                className: c("stylex")({
                    "background-color-1": "xjb1437",
                    "bottom-1": "xacj9c0",
                    "color-1": "x14ctfv",
                    "margin-left-1": "x89ytp0",
                    "padding-top-1": "x889kno",
                    "padding-end-1": "x1ou2tus",
                    "padding-bottom-1": "x1a8lsjc",
                    "padding-start-1": "x1egjynq",
                    "position-1": "x10l6tqk",
                    "right-1": "x1fwd5yv"
                }, g === !0 ? {
                    "right-1": "xwjie4w"
                } : null, e === !0 ? {
                    "right-1": "x3m8u43"
                } : null),
                children: j.jsx(d("VideoPlayerSettingsMenu.react").VideoPlayerSettingsMenu, {
                    onClose: function() {
                        s ? p != null && p(null) : r(!1)
                    },
                    children: f
                })
            }), j.jsx(c("VideoPlayerControlIcon.react"), {
                icon: l == null ? d("fbicon")._(i("497567"), 20) : l,
                label: a,
                onPress: function() {
                    s ? p != null && p(t ? null : d("VideoPlayerDefaultControlsProperties").VideoMenuType.VIDEO_SETTINGS_MENU) : r(!q), !t && n != null && n()
                },
                tooltip: a
            })]
        })
    });
    a.displayName = "VideoPlayerSettingsControl";
    b = a;
    g["default"] = b
}), 98);
__d("VideoPlayerVolumeControlBase.react", ["fbt", "ix", "FocusWithinHandler.react", "VideoPlayerControlIcon.react", "fbicon", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = d("react").useState,
        l = .33,
        m = .66;

    function a(a) {
        var b = a.audioAvailabilityUI,
            e = a.isMuted,
            f = a.onMouseEnter,
            g = a.onMouseLeave,
            n = a.onSetMuted,
            o = a.onUserInteraction,
            p = a.renderVolumeSlider;
        a = a.volume;
        var q = !e && a > 0,
            r;
        b != null && b.shouldShowNullIcon ? r = d("fbicon")._(i("944792"), 20) : q ? a <= l ? r = d("fbicon")._(i("1104387"), 20) : a <= m ? r = d("fbicon")._(i("1104390"), 20) : r = d("fbicon")._(i("564390"), 20) : r = d("fbicon")._(i("564396"), 20);
        q = k(!1);
        var s = q[0],
            t = q[1],
            u = e ? h._("Unmute") : h._("Mute");
        return j.jsx(c("FocusWithinHandler.react"), {
            children: function(a, d) {
                return j.jsxs("div", {
                    className: "x1n2onr6 x16hj40l x10b6aqq xsyo7zv xyamay9 xhsvlbd x1rg5ohu x1ypdohk",
                    onMouseEnter: f,
                    onMouseLeave: g,
                    children: [b != null && b.shouldDisableVolumeControl ? null : j.jsx("div", {
                        className: "xh8yej3 x17qophe x10l6tqk x16hj40l x10b6aqq xsyo7zv x1yrsyyn x9f619 xk7dvq3",
                        children: p({
                            focusVisible: d,
                            onVisibilityChange: t
                        })
                    }), j.jsx(c("VideoPlayerControlIcon.react"), {
                        icon: r,
                        label: u,
                        onPress: function() {
                            b && b.onVolumeControlPress(), b != null && b.shouldDisableVolumeControl || n(!e, "user_initiated"), o && o({
                                name: "video_mute_button",
                                type: "happened"
                            })
                        },
                        tooltip: b != null ? b.tooltipContent : null,
                        tooltipAlign: "end",
                        tooltipImpl: b != null ? b.tooltipImpl : null,
                        tooltipOffsetY: s ? -80 : 0
                    })]
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerPointerDrag", ["react", "useResizeObserver", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    f = d("react");
    var h = f.useEffect,
        i = f.useRef,
        j = f.useState;

    function a() {
        var a = i(null),
            b = i(null),
            d = c("useResizeObserver")(function(c, d) {
                a.current = d.getBoundingClientRect(), b.current = d
            }),
            e = c("useStable")(function() {
                return function() {
                    var c = b.current;
                    c ? a.current = c.getBoundingClientRect() : a.current = null
                }
            });
        return {
            invalidateRootRect: e,
            rootRectRef: a,
            rootSizeRefCallback: d
        }
    }

    function b(a, b) {
        if (b == null) return null;
        var c = Math.max(0, Math.min(b.width, a.clientX - b.left));
        a = Math.max(0, Math.min(b.height, a.clientY - b.top));
        return {
            ratioX: b.width > 0 ? c / b.width : 0,
            ratioY: b.height > 0 ? a / b.height : 0
        }
    }

    function k(a, b) {
        a = a.changedTouches;
        if (b == null || !a) return null;
        for (var c = 0; c < a.length; ++c) {
            var d = a[c];
            if (d.identifier === b) return {
                clientX: d.clientX,
                clientY: d.clientY
            }
        }
        return null
    }

    function l(a, b) {
        var c = a;
        switch (b.type) {
            case "start":
                c = babelHelpers["extends"]({}, a, {
                    clientX: b.clientX,
                    clientY: b.clientY,
                    dragState: "dragging",
                    lastEffect: a.dragState === "idle" ? "start" : a.lastEffect
                });
                break;
            case "move":
                if (a.dragState !== "dragging") break;
                c = {
                    clientX: b.clientX,
                    clientY: b.clientY,
                    dragState: "dragging",
                    lastEffect: a.dragState === "idle" ? "start" : "move"
                };
                break;
            case "end":
                if (a.dragState !== "dragging") break;
                c = {
                    clientX: b.clientX,
                    clientY: b.clientY,
                    dragState: "idle",
                    lastEffect: a.dragState === "idle" ? a.lastEffect : "end"
                };
                break;
            case "cancel":
                if (a.dragState !== "dragging") break;
                c = {
                    clientX: a.clientX,
                    clientY: a.clientY,
                    dragState: "idle",
                    lastEffect: a.dragState === "idle" ? a.lastEffect : "cancel"
                };
                break;
            default:
                break
        }
        return c.dragState !== a.dragState || c.lastEffect !== a.lastEffect || c.clientX !== a.clientX || c.clientY !== a.clientY ? c : a
    }
    var m = {
            clientX: 0,
            clientY: 0,
            dragState: "idle",
            lastEffect: null
        },
        n = function() {
            return window.navigator.userAgent.indexOf("MSIE") >= 0
        };

    function o(a, b, c) {
        var d = m,
            e = null,
            f = null,
            g = function(b) {
                d = l(d, b), a(d)
            },
            h = function(a) {
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "move"
                });
                a = b.current.onDragMoveSync;
                a == null ? void 0 : a(d)
            },
            i = function(a) {
                e && e();
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "end"
                });
                a = b.current.onDragEndSync;
                a == null ? void 0 : a(d)
            },
            j = function() {
                e && e();
                g({
                    type: "cancel"
                });
                var a = b.current.onDragCancelSync;
                a == null ? void 0 : a(d)
            },
            o = function(a) {
                a = k(a, c.current);
                if (a == null) return;
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "move"
                });
                a = b.current.onDragMoveSync;
                a == null ? void 0 : a(d)
            },
            p = function(a) {
                a = k(a, c.current);
                if (a == null) return;
                f && f();
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "end"
                });
                a = b.current.onDragEndSync;
                a == null ? void 0 : a(d)
            },
            q = p;
        return {
            destroy: function() {
                e && e(), f && f()
            },
            onMouseDown: function(a) {
                n() || a.preventDefault();
                g({
                    clientX: a.clientX,
                    clientY: a.clientY,
                    type: "start"
                });
                a = b.current.onDragStartSync;
                a == null ? void 0 : a(d);
                e || (window.addEventListener("mousemove", h), window.addEventListener("mouseup", i), window.addEventListener("blur", j), window.addEventListener("mouseleave", j), e = function() {
                    e = null, window.removeEventListener("mousemove", h), window.removeEventListener("mouseup", i), window.removeEventListener("blur", j), window.removeEventListener("mouseleave", j)
                })
            },
            onTouchStart: function(a) {
                a.preventDefault();
                var e = a.changedTouches[0];
                e != null && (c.current = e.identifier);
                e = k(a, c.current);
                if (e == null) return;
                g({
                    clientX: e.clientX,
                    clientY: e.clientY,
                    type: "start"
                });
                a = b.current.onDragStartSync;
                a == null ? void 0 : a(d);
                f || (window.addEventListener("touchmove", o), window.addEventListener("touchend", p), window.addEventListener("touchcancel", q), window.addEventListener("blur", j), f = function() {
                    f = null, window.removeEventListener("touchmove", o), window.removeEventListener("touchend", p), window.removeEventListener("touchcancel", q), window.removeEventListener("blur", j)
                })
            }
        }
    }

    function p(a, b) {
        h(function() {
            var c = b.current,
                d = c.onDragCancel,
                e = c.onDragEnd,
                f = c.onDragMove;
            c = c.onDragStart;
            switch (a.lastEffect) {
                case "start":
                    c(a);
                    return;
                case "move":
                    f(a);
                    return;
                case "end":
                    e(a);
                    return;
                case "cancel":
                    d(a);
                    return
            }
        }, [a, b])
    }

    function q(a, b, d) {
        var e = j(m),
            f = e[0],
            g = e[1];
        e = c("useStable")(function() {
            return o(g, a, b)
        });
        var i = e.destroy,
            k = e.onMouseDown;
        e = e.onTouchStart;
        h(function() {
            return i
        }, [i]);
        return {
            dragState: f,
            rootProps: {
                onClick: function(a) {
                    a.stopPropagation(), a.preventDefault()
                },
                onMouseDown: k,
                onTouchStart: (d == null ? void 0 : d.hasTouchEvents) === !0 ? e : void 0
            }
        }
    }

    function e(a, b) {
        var c = i(a),
            d = i(null);
        h(function() {
            c.current = a
        }, [a]);
        d = q(c, d, b);
        b = d.dragState;
        d = d.rootProps;
        p(b, c);
        return {
            dragState: b,
            isDragging: b.dragState === "dragging",
            rootProps: d
        }
    }
    g.usePointerDragResizeObserver = a;
    g.computePointerOffsetRatio = b;
    g.usePointerDrag = e
}), 98);
__d("VideoPlayerSliderNub.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.isVisible;
        return h.jsx("div", {
            className: c("stylex")({
                "background-color-1": "x14hiurz",
                "border-top-0.3": "xtucvfd",
                "border-end-0.3": "xj0q7ni",
                "border-bottom-0.3": "x1e4yufr",
                "border-start-0.3": "x1sp3icg",
                "border-top-start-radius-1": "x14yjl9h",
                "border-top-end-radius-1": "xudhj91",
                "border-bottom-end-radius-1": "x18nykt9",
                "border-bottom-start-radius-1": "xww2gxu",
                "box-shadow-1": "x1nqv1ya",
                "display-1": "x1s85apg",
                "height-1": "xdk7pt",
                "margin-right-1": "x1x862rh",
                "margin-top-1": "x1rdy4ex",
                "position-1": "x10l6tqk",
                "right-1": "x3m8u43",
                "width-1": "x1xc55vz",
                "z-index-1": "x1vjfegm"
            }, a ? {
                "display-1": "x1lliihq"
            } : null),
            "data-testid": void 0
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerVolumeSliderBase.react", ["fbt", "CometComponentWithKeyCommands.react", "CometKeys", "VideoPlayerPointerDrag", "VideoPlayerSliderNub.react", "VideoPlayerUserInteractionCounter", "qex", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    e = b.useEffect;
    var j = b.useLayoutEffect,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState,
        n = c("qex")._("109") ? e : j;

    function a(a) {
        var b = a.isHovering,
            e = a.isMuted,
            f = a.onChangeVolumeDown,
            g = a.onChangeVolumeUp,
            j = a.onSetMuted,
            o = a.onSetVolume,
            p = a.onUserInteraction,
            q = a.onVisibilityChange,
            r = a.volume;
        a = d("VideoPlayerPointerDrag").usePointerDragResizeObserver();
        var s = a.invalidateRootRect,
            t = a.rootRectRef;
        a = a.rootSizeRefCallback;
        var u = l(r),
            v = l(e),
            w = e ? 0 : r,
            x = m(w),
            y = x[0],
            z = x[1],
            A = function(a) {
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, t.current);
                if (!a) return;
                a = Math.max(0, Math.min(1, 1 - a.ratioY));
                z(a);
                o(a);
                e && j(!1, "user_initiated")
            };
        x = d("VideoPlayerPointerDrag").usePointerDrag({
            onDragCancel: function(a) {
                z(u.current), o(u.current), j(v.current, "user_initiated")
            },
            onDragEnd: function(a) {
                A(a)
            },
            onDragMove: function(a) {
                A(a)
            },
            onDragStart: function(a) {
                s(), u.current = r, v.current = e, z(w), A(a)
            }
        });
        var B = x.isDragging;
        x = x.rootProps;
        y = B ? y : w;
        var C = b || B,
            D = l(C);
        n(function() {
            D.current !== C && (q && q(C)), D.current = C
        }, [q, C]);
        b = C;
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_volume_slider", b, p);
        B = k(function() {
            return [{
                command: {
                    key: c("CometKeys").UP
                },
                description: h._("Increase volume"),
                handler: function() {
                    g()
                }
            }, {
                command: {
                    key: c("CometKeys").DOWN
                },
                description: h._("Decrease volume"),
                handler: function() {
                    f()
                }
            }]
        }, [g, f]);
        return i.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: B,
            children: i.jsx("div", babelHelpers["extends"]({}, x, {
                "aria-label": h._("Change volume"),
                "aria-orientation": "vertical",
                "aria-valuemax": "1",
                "aria-valuemin": "0",
                "aria-valuenow": r,
                className: c("stylex")({
                    "cursor-1": "x1ypdohk",
                    "height-1": "xng8ra",
                    "opacity-1": "xg01cxk",
                    "pointer-events-1": "x47corl",
                    "position-1": "x1n2onr6",
                    "transition-duration-1": "x1d8287x",
                    "transition-property-1": "x19991ni",
                    "transition-timing-function-1": "xl405pv",
                    "width-1": "x1td3qas",
                    "z-index-1": "x1ja2u2z"
                }, C ? {
                    "opacity-1": "x1hc1fzr",
                    "pointer-events-1": "x67bb7w"
                } : null),
                ref: a,
                role: "slider",
                tabIndex: "0",
                children: i.jsx("div", {
                    className: "x1xc55vz xoyjkpr x10l6tqk xng8ra x1ey2m1c x10y3i5r xrt01vj x1yr5g0i x1lcm9me x18fn2jl",
                    children: i.jsx("div", {
                        className: "xh8yej3 x10l6tqk x1ey2m1c x10y3i5r xrt01vj x1yr5g0i x1lcm9me x1spa7qu",
                        style: {
                            height: y * 100 + "%"
                        },
                        children: i.jsx("div", {
                            className: "x1n2onr6 x1f4buv5 x1c7jfne",
                            children: i.jsx(c("VideoPlayerSliderNub.react"), {
                                isVisible: C
                            })
                        })
                    })
                })
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerVolumeSlider.react", ["VideoPlayerHooks", "VideoPlayerVolumeSliderBase.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect;

    function a(a) {
        var b = a.isHovering,
            e = a.onUserInteraction;
        a = a.onVisibilityChange;
        var f = d("VideoPlayerHooks").useController(),
            g = d("VideoPlayerHooks").useMuted(),
            k = d("VideoPlayerHooks").useVolume(),
            l = d("VideoPlayerHooks").useSetVolume();
        j(function() {
            f.setVolume(k)
        }, [f, k]);
        var m = i(function(a) {
                f.setVolume(a), l(a)
            }, [f, l]),
            n = i(function(a, b) {
                f.setMuted(a, b)
            }, [f]),
            o = i(function(a) {
                var b = f.getCurrentState();
                a = Math.max(0, Math.min(1, b.volume + a));
                l(a);
                f.setVolume(a);
                a === 0 ? f.setMuted(!0, "user_initiated") : b.muted && f.setMuted(!1, "user_initiated")
            }, [f, l]),
            p = i(function() {
                o(.05)
            }, [o]),
            q = i(function() {
                o(-.05)
            }, [o]);
        return h.jsx(c("VideoPlayerVolumeSliderBase.react"), {
            isHovering: b,
            isMuted: g,
            onChangeVolumeDown: q,
            onChangeVolumeUp: p,
            onSetMuted: n,
            onSetVolume: m,
            onUserInteraction: e,
            onVisibilityChange: a,
            volume: k
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerVolumeControl.react", ["VideoPlayerHooks", "VideoPlayerVolumeControlBase.react", "VideoPlayerVolumeSlider.react", "cr:1826284", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useState,
        k = (e = b("cr:1826284")) != null ? e : c("emptyFunction");

    function a(a) {
        var b = a.onUserInteraction;
        a = j(!1);
        var e = a[0],
            f = a[1],
            g = d("VideoPlayerHooks").useController();
        a = d("VideoPlayerHooks").useMuted();
        var l = d("VideoPlayerHooks").useVolume(),
            m = function() {
                f(!0)
            },
            n = function() {
                f(!1)
            },
            o = i(function(a, b) {
                g.setMuted(a, b)
            }, [g]),
            p = !a && l > 0;
        p = k({
            canPlayerProduceSound: p,
            isHovering: e
        }) || null;
        return h.jsx(c("VideoPlayerVolumeControlBase.react"), {
            audioAvailabilityUI: p,
            isMuted: a,
            onMouseEnter: m,
            onMouseLeave: n,
            onSetMuted: o,
            onUserInteraction: b,
            renderVolumeSlider: function(a) {
                var d = a.focusVisible;
                a = a.onVisibilityChange;
                return h.jsx(c("VideoPlayerVolumeSlider.react"), {
                    isHovering: e || d,
                    onUserInteraction: b,
                    onVisibilityChange: a
                })
            },
            volume: l
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometVideoPictureInPictureCanvasRender.react", ["qex", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useRef,
        k = b.useState,
        l = 17,
        m = .3,
        n = "Verdana",
        o = "middle",
        p = "center",
        q = .7,
        r = .3,
        s = "RGBA(20, 22, 26, 0.45)",
        t = "RGBA(255, 255, 255)",
        u = (e = c("qex")._("764")) != null ? e : 30,
        v = 640;

    function a(a) {
        var b = a.controller,
            c = a.onLeavePipPlayerHandler,
            d = a.setRenderedInCanvas,
            e = j(null),
            f = j(null),
            g = j(null),
            w = j(null),
            x = j(null),
            y = j(null),
            z = j(null);
        f.current === null && (f.current = document.createElement("canvas"));
        g.current === null && (g.current = document.createElement("canvas"));
        a = k(null);
        var A = a[0],
            B = a[1],
            C = h(function() {
                if (b != null) {
                    var a = b.getCurrentState(),
                        c = a.availableVideoQualities;
                    c = c.map(function(a) {
                        return Number(a.slice(0, a.length - 1))
                    });
                    c.sort();
                    a = a.currentVideoQuality;
                    a = Number(a.slice(0, a.length - 1));
                    if (a > v) {
                        a = v;
                        if (!c.includes(v))
                            for (var d = c.length - 1; d >= 0; d--)
                                if (c[d] > v) continue;
                                else {
                                    a = c[d];
                                    break
                                }
                        c = a.toString() + "p";
                        b == null ? void 0 : b.selectVideoQuality(c)
                    }
                }
            }, [b]),
            D = h(function() {
                if (b != null) {
                    b.exitPictureInPicture();
                    var a = x.current;
                    d(!0);
                    if (a && typeof a.requestPictureInPicture === "function") return a.requestPictureInPicture().then(function() {
                        var a;
                        b.setPictureInPictureState(!0);
                        C();
                        (a = x.current) == null ? void 0 : a.removeEventListener("playing", D)
                    })
                }
            }, [d, b, C]),
            E = h(function() {
                var a = w.current,
                    b = f.current,
                    c = g.current;
                a != null && b != null && c != null && (b.width = a.videoWidth, b.height = a.videoHeight, c.width = a.videoWidth * q, c.height = a.videoHeight * r)
            }, []),
            F = h(function() {
                e.current != null && (window.cancelAnimationFrame(e.current), e.current = null);
                var a = [z, y];
                a.forEach(function(a) {
                    a.current != null && (a.current.remove(), a.current = null)
                });
                w.current != null && (w.current.removeEventListener("resize", E), w.current = null)
            }, [E]),
            G = h(function() {
                B(null);
                d(!1);
                b != null && b.setPictureInPictureState(!1);
                if (x.current != null) {
                    var a;
                    x.current.removeEventListener("leavepictureinpicture", G);
                    (a = x.current) == null ? void 0 : a.remove();
                    x.current = null
                }
                F();
                a = b == null ? void 0 : (a = b.internal_getVideoElement()) == null ? void 0 : a.currentSrc;
                a === ((a = w.current) == null ? void 0 : a.currentSrc) && c()
            }, [B, F, b, d, c]),
            H = h(function(a, b) {
                var c = g.current;
                if (c) {
                    var d = c.getContext("2d");
                    d.textBaseline = o;
                    d.textAlign = p;
                    var e = null;
                    a != null && a.length > 0 && (e = a.map(function(a) {
                        return a.trim()
                    }).filter(function(a) {
                        return !!a
                    }));
                    if (e != null) {
                        d.clearRect(0, 0, c.width, c.height);
                        d.fillStyle = s;
                        d.fillRect(0, 0, c.width, c.height);
                        d.fillStyle = t;
                        a = Number(b.slice(0, -1));
                        b = Math.max(a / 270 * l, l);
                        d.font = b + "px " + n;
                        for (var a = 0; a < ((b = e) == null ? void 0 : b.length); a++) {
                            d.fillText(e[a], c.width / 2, c.height / 3 + a * c.height * m, c.width)
                        }
                    }
                }
            }, []);
        i(function() {
            b != null && (A == null && f.current != null ? z.current = b.subscribe(function() {
                var a = b.getCurrentState();
                a.captionsLoaded && a.captionsVisible && a.playing && B(!0)
            }) : (z.current && z.current.remove(), z.current = null))
        }, [b, A]);
        i(function() {
            var a, c = b == null ? void 0 : b.internal_getVideoElement(),
                d = f.current,
                h = g.current;
            a = (a = b == null ? void 0 : b.getCurrentState().playing) != null ? a : !1;
            if (b != null && c != null && a && A === !0 && d && h) {
                a = function a() {
                    var b = w.current;
                    if (d != null && h != null && b != null) {
                        var c = Date.now();
                        if (c - j >= k) {
                            j = c;
                            c = d.getContext("2d");
                            c.drawImage(b, 0, 0);
                            c.drawImage(h, (d.width - h.width) / 2, d.height - h.height)
                        }
                        e.current === null ? e.current = window.requestAnimationFrame(a) : window.requestAnimationFrame(a)
                    }
                };
                w.current = c;
                E();
                c.addEventListener("resize", E);
                var i;
                y.current = b.subscribe(function() {
                    var a, c = b.getCurrentState();
                    a = (a = c.activeCaptions) == null ? void 0 : a.rows;
                    c = c.currentVideoQuality;
                    a !== i && (H(a, c), i = a)
                });
                var j = 0,
                    k = 1e3 / u;
                a();
                a = document.createElement("video");
                x.current = a;
                a.width = c.videoWidth;
                a.height = c.videoHeight;
                a.srcObject = d.captureStream();
                a.addEventListener("leavepictureinpicture", G);
                a.addEventListener("playing", D);
                a.play()
            }
        }, [b, G, D, A, E, H]);
        i(function() {
            return function() {
                F();
                var a = [f, g];
                a.forEach(function(a) {
                    a.current != null && (a.current.remove(), a.current = null)
                })
            }
        }, [F])
    }
    g.CometPictureInPictureCanvasRender = a
}), 98);
__d("CometVideoPictureInPictureManager.react", ["CometSetWatchAndScrollVideoContext", "CometVideoPictureInPictureCanvasRender.react", "CometVideoPictureInPictureManagerContext", "CometWatchAndScrollVideoContext", "XCometWatchControllerRouteBuilder", "clearTimeout", "gkx", "qex", "react", "requireDeferred", "setTimeout", "useCometRouterDispatcher"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useEffect,
        l = b.useMemo,
        m = b.useRef,
        n = b.useState,
        o = c("requireDeferred")("VideoHomeTypedLoggerLite").__setRef("CometVideoPictureInPictureManager.react"),
        p = c("gkx")("1443572"),
        q = (e = c("qex")._("44")) != null ? e : 50;
    b = ["286211568997787", "214604021960500", "108677131037"];
    var r = (e = c("qex")._("407")) != null ? e : !1,
        s = (e = c("qex")._("586")) != null ? e : !1,
        t = window.document.pictureInPictureEnabled;

    function a(a) {
        var b = c("useCometRouterDispatcher")(),
            e = a.isPipEnabled,
            f = n(null),
            g = f[0],
            u = f[1];
        f = n(!1);
        var v = f[0],
            w = f[1];
        f = n(!1);
        var x = f[0],
            y = f[1],
            z = m(!1),
            A = i(function(a) {
                z.current = a
            }, []);
        f = l(function() {
            return {
                hasNextChainedVideo: x,
                isPipEnabled: e,
                setHasNextChainedVideo: y,
                setSkippedFromPipPlayer: w,
                skippedFromPipPlayer: v
            }
        }, [v, w, x, y, e]);
        var B = n(null),
            C = B[0],
            D = B[1],
            E = j(c("CometWatchAndScrollVideoContext")),
            F = j(c("CometSetWatchAndScrollVideoContext")),
            G = m(null),
            H = m(null),
            I = i(function(a) {
                a === void 0 && (a = null), o.onReady(function(b) {
                    b.log({
                        click_point: a,
                        event: "click"
                    })
                })
            }, []),
            J = i(function() {
                var a = E == null ? void 0 : E.videoID,
                    d = E == null ? void 0 : E.videoUrl;
                if (a != null && d != null) {
                    var e = E == null ? void 0 : E.routeTracePolicy,
                        f = E == null ? void 0 : E.subOrigin;
                    d = p ? d : c("XCometWatchControllerRouteBuilder").buildURL({
                        v: a
                    });
                    b && (b.go(d, {
                        passthroughProps: {
                            portableVideoID: C,
                            portalingRouteTracePolicy: e,
                            portalingSubOrigin: f
                        }
                    }), F(null))
                }
            }, [b, E, C, F]),
            K = i(function() {
                g != null && (G.current = c("setTimeout")(function() {
                    var a = g.getCurrentState(),
                        b = a.lastPauseReason;
                    a = a.paused;
                    z.current || (e && (a === !1 || a === !0 && b === "product_initiated") ? (J(), I("control_pip_player_return_to_tab")) : window.document.pictureInPictureElement === null && (F(null), I("control_pip_player_close")))
                }, q))
            }, [g, e, J, F, I]),
            L = i(function() {
                g != null && (s || (window.navigator.mediaSession.setActionHandler("nexttrack", null), window.navigator.mediaSession.setActionHandler("nexttrack", function() {
                    g.pause("user_initiated"), w(!0), A(!1), I("control_pip_player_skip")
                })), z.current || (window.navigator.mediaSession.setActionHandler("play", null), window.navigator.mediaSession.setActionHandler("pause", null), window.navigator.mediaSession.setActionHandler("pause", function() {
                    g.pause("product_initiated")
                })), x || window.navigator.mediaSession.setActionHandler("nexttrack", null))
            }, [g, x, I, A]),
            M = i(function(a) {
                a.requestPictureInPicture();
                T(!1);
                a = a.internal_getVideoElement();
                H.current = a == null ? void 0 : a.currentSrc
            }, []),
            N = i(function() {
                if (g != null) {
                    var a = g.getIsDesktopPictureInPicture();
                    if (a) {
                        g.exitPictureInPicture();
                        return
                    }
                    M(g)
                }
            }, [M, g]),
            O = i(function(a) {
                u(a)
            }, [u]),
            P = i(function(a) {
                a != null && D(a)
            }, [D]);
        B = l(function() {
            return {
                openPipPlayer: N,
                setController: O,
                setPipPortableVideoID: P
            }
        }, [N, O, P]);
        var Q = m(!1),
            R = n(!1),
            S = R[0],
            T = R[1];
        k(function() {
            var a = null;
            if (t && g != null && window.document.pictureInPictureElement) {
                var b = g.internal_getVideoElement();
                b = b == null ? void 0 : b.currentSrc;
                var c = !1,
                    d = !1;
                a = g.subscribe(function() {
                    var a = g.getCurrentState(),
                        b = a.playing;
                    a = a.isDesktopPictureInPicture;
                    !c && b && Q.current && !z.current && (Q.current = !1, T(!0));
                    d && !a && K();
                    !d && a && L();
                    c = b;
                    d = a
                });
                b !== H.current ? !S ? (g.play("user_initiated"), Q.current = !0) : M(g) : e && (L(), H.current = b)
            }
            return function() {
                a != null && a.remove()
            }
        }, [M, g, N, x, L, K, e, S]);
        k(function() {
            return function() {
                G.current != null && (c("clearTimeout")(G.current), G.current = null)
            }
        }, []);
        return h.jsx(d("CometVideoPictureInPictureManagerContext").CometVideoPictureInPictureManagerContext.Provider, {
            value: f,
            children: h.jsxs(d("CometVideoPictureInPictureManagerContext").CometVideoPictureInPictureManagerAPIContext.Provider, {
                value: B,
                children: [a.children, r && h.jsx(d("CometVideoPictureInPictureCanvasRender.react").CometPictureInPictureCanvasRender, {
                    controller: g,
                    onLeavePipPlayerHandler: K,
                    setRenderedInCanvas: A
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g.EXCLUDED_PROVIDERS = b;
    g.CometVideoPictureInPictureManager = a
}), 98);
__d("useVideoPlayerWatchAndScrollControlNUX", ["fbt", "CometRelay", "CometWatchAndScrollTriggerContext", "react", "recoverableViolation", "requireDeferred", "useCometCallout", "useVideoPlayerWatchAndScrollControlNUXQuery.graphql"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    e = d("react");
    var j = e.useCallback,
        k = e.useContext,
        l = e.useEffect,
        m = e.useState,
        n = c("requireDeferred")("CometDismissFBNuxMutation").__setRef("useVideoPlayerWatchAndScrollControlNUX"),
        o = c("requireDeferred")("CometLogImpressionFBNuxMutation").__setRef("useVideoPlayerWatchAndScrollControlNUX"),
        p = {
            nux: {
                maxWidth: "xw5ewwj"
            }
        },
        q = 9347,
        r = i !== void 0 ? i : i = b("useVideoPlayerWatchAndScrollControlNUXQuery.graphql");

    function a(a) {
        var b = k(c("CometWatchAndScrollTriggerContext")),
            e = b.setIsTriggerDisabled;
        b = m(null);
        var f = b[0],
            g = b[1],
            i = d("CometRelay").useRelayEnvironment(),
            s = j(function() {
                e != null && e(!0), g(!1), n.onReady(function(a) {
                    a.commit(i, q)
                })
            }, [i, e]);
        l(function() {
            if (a && f === null) {
                var b = d("CometRelay").fetchQuery(i, r, {
                    fetchPolicy: "store-or-network"
                }).subscribe({
                    next: function(b) {
                        b = (b == null ? void 0 : (b = b.nux) == null ? void 0 : b.should_show) || !1;
                        g(b);
                        b && a && o.onReady(function(a) {
                            a.commit(i, q, function() {}, function() {
                                c("recoverableViolation")("logimpression fb nux mutation failed for video player watch and scroll control.", "watch_www_bug_rotation")
                            })
                        })
                    }
                });
                return function() {
                    b.unsubscribe()
                }
            }
        }, [i, a, f]);
        b = {
            align: "end",
            arrowStyle: "inset",
            disableAutoFlip: !0,
            hasCloseButton: !0,
            label: h._("Continue watching while you browse Facebook."),
            onClose: function() {
                s()
            },
            onHide: function() {
                g(!1)
            },
            position: "below",
            type: "accent",
            xstyle: p.nux
        };
        b = c("useCometCallout")(b, f === !0 && a || !1);
        return {
            handleDismissNUX: s,
            nuxRef: b,
            shouldShowNUX: f
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerWatchAndScrollControl.react", ["fbt", "ix", "CastingStateHooks", "CometPictureInPictureExpContext", "CometRelay", "CometRouteRenderType", "CometVideoPictureInPictureManager.react", "CometVideoPictureInPictureManagerContext", "CometWatchAndScrollControlNUXContext", "CometWatchAndScrollTriggerContext", "JSResourceForInteraction", "VideoPlayerControlIcon.react", "VideoPlayerHooks", "VideoPlayerInstreamAdsStateHooks", "VideoPlayerWatchAndScrollControl_video.graphql", "VideoPlayerWithWatchAndScrollTrigger.react", "emptyFunction", "fbicon", "gkx", "react", "requireDeferred", "useCometLazyDialog", "useCometRouterDispatcher", "useCometRouterState", "useIsVideoHomePlayerOriginFromTracePolicy", "usePlayerOriginRouteTracePolicy", "useVideoPlayerWatchAndScrollControlNUX", "useWatchAndScrollTrigger"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = d("react");
    e = d("react");
    var l = e.useCallback,
        m = e.useContext,
        n = e.useEffect,
        o = e.useState,
        p = c("requireDeferred")("VideoHomeTypedLoggerLite").__setRef("VideoPlayerWatchAndScrollControl.react"),
        q = c("JSResourceForInteraction")("CometCastingStopWatchAndScrollDialog.react").__setRef("VideoPlayerWatchAndScrollControl.react"),
        r = 6e4,
        s = window.document.pictureInPictureEnabled;

    function a(a) {
        var e, f = a.subOrigin;
        a = a.video;
        var g = m(c("CometWatchAndScrollTriggerContext")),
            t = g.isControlShown,
            u = g.setIsControlShown;
        g = d("CometRouteRenderType").useIsPushView();
        var v = d("VideoPlayerHooks").useIsFullscreen(),
            w = c("useCometRouterDispatcher")(),
            x = c("useCometRouterState")(),
            y = (x = x == null ? void 0 : x.main.route.tabKey) != null ? x : "undefined";
        x = d("CometRelay").useFragment(j !== void 0 ? j : j = b("VideoPlayerWatchAndScrollControl_video.graphql"), a);
        var z = x == null ? void 0 : x.id;
        a = (a = x == null ? void 0 : x.playable_duration_in_ms) != null ? a : 0;
        var A = x == null ? void 0 : x.is_huddle,
            B = x == null ? void 0 : x.url;
        n(function() {
            u != null && u(!0)
        }, [u]);
        var C = c("usePlayerOriginRouteTracePolicy")(),
            D = c("useIsVideoHomePlayerOriginFromTracePolicy")(C);
        e = (x == null ? void 0 : (e = x.owner) == null ? void 0 : e.has_professional_features_for_watch) === !0 && a >= r && t && !D;
        var E = d("VideoPlayerHooks").usePlaying(),
            F = d("VideoPlayerHooks").useController();
        a = F.getPlayheadPosition();
        var G = a >= 10;
        t = o(!1);
        D = t[0];
        var H = t[1];
        a = o(!1);
        var I = a[0],
            J = a[1];
        t = o(!1);
        a = t[0];
        var K = t[1];
        t = d("VideoPlayerInstreamAdsStateHooks").useInstreamAdsStateValue();
        t = t === "STARTING_INDICATOR" || t === "PLAY_NI_VIDEO" || t === "START_AD" || t === "PLAY_LONGER_AD";
        n(function() {
            E && G && H(!0)
        }, [G, E]);
        var L = d("CastingStateHooks").useIsCastingAnyVideo(),
            M = c("useCometLazyDialog")(q),
            N = M[0];
        M = !t && D && e;
        t = c("useVideoPlayerWatchAndScrollControlNUX")(M);
        var O = t.handleDismissNUX;
        D = t.nuxRef;
        e = t.shouldShowNUX;
        var P = e === !0 && M;
        t = m(c("CometWatchAndScrollControlNUXContext"));
        var Q = t.setIsVideoPlayerWatchAndScrollControlNUXVisible,
            R = m(c("CometPictureInPictureExpContext"));
        n(function() {
            Q && Q(P)
        }, [P, Q]);
        var S = d("useWatchAndScrollTrigger").useWatchAndScrollTrigger(f, d("VideoPlayerWithWatchAndScrollTrigger.react").WatchAndScrollTriggerType.WNS_CONTROL, z, B),
            T = d("VideoPlayerHooks").useIsPremiumMusicVideo(),
            U = x == null ? void 0 : (e = x.owner) == null ? void 0 : e.id;
        M = l(function() {
            var a = d("CometVideoPictureInPictureManagerContext").isInPictureInPictureExp(),
                b = d("CometVideoPictureInPictureManagerContext").isInPictureInPictureExpControlGroup(),
                c = d("CometVideoPictureInPictureManagerContext").isSkipAndChainingDisabledInPictureInPicture();
            R.setPictureInPictureExpConfig({
                isInPictureInPictureExp: a,
                isInPictureInPictureExpControlGroup: b,
                isSkipAndChainingDisabled: c
            });
            s && a && J(!0);
            c = (a || b) && (T || d("CometVideoPictureInPictureManager.react").EXCLUDED_PROVIDERS.includes(U));
            c && K(!0)
        }, [T, U, R]);
        var V = C === "comet.videos.tahoe",
            W = l(function() {
                L && z != null ? N({
                    onClose: c("emptyFunction"),
                    onContinue: S,
                    startingVideoType: "wns"
                }, c("emptyFunction")) : S()
            }, [L, S, N, z]);
        t = l(function() {
            W(), I ? (p.onReady(function(a) {
                a.log({
                    click_point: "control_picture_in_picture",
                    event: "click",
                    event_target_info: C,
                    player_suborigin: f
                })
            }), F.requestPictureInPicture()) : p.onReady(function(a) {
                a.log({
                    click_point: "control_watch_and_scroll",
                    event: "click",
                    event_target_info: y
                })
            }), P === !0 && O(), w && w.popPushView && w.popPushView()
        }, [W, P, w, y, O, C, f, F, I]);
        var X = f === "live_producer";
        B = l(function() {
            W(), I ? (p.onReady(function(a) {
                a.log({
                    click_point: "control_picture_in_picture",
                    event: "click",
                    event_target_info: C,
                    player_suborigin: f
                })
            }), F.requestPictureInPicture()) : p.onReady(function(a) {
                a.log({
                    click_point: "control_watch_and_scroll",
                    event: "click",
                    event_target_info: y
                })
            }), P === !0 && O(), v && F.requestSetIsFullscreen(!1), w != null && (X || V) && w.go("/", {})
        }, [W, P, v, y, O, F, w, X, V, f, C, I]);
        x = g ? t : B;
        c("gkx")("1224637") ? e = h._("Continue watching while you use Workplace") : A === !0 ? e = h._("Continue listening while you browse Facebook.") : e = h._("Continue watching while you browse Facebook.");
        I && (e = h._("Enter Picture in Picture Mode"));
        return a ? null : k.jsx("div", {
            onMouseEnter: M,
            ref: D,
            children: k.jsx(c("VideoPlayerControlIcon.react"), {
                color: "white",
                icon: d("fbicon")._(i("150489"), 20),
                label: e,
                onPress: x,
                tooltip: P ? null : e
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerLiveVideoControls.react", ["CometPlaceholder.react", "CometRelay", "CometTahoeCustomVideoAreaContext", "CometTrackingNodeProvider.react", "LiveCostreamerTagSubscription.react", "LiveVideoLatencyMenu.react", "PlaybackSpeedExperiments", "VideoPlayerCaptionsControl.react", "VideoPlayerCastControlShim.react", "VideoPlayerControlsBottomRowAddOnContext", "VideoPlayerControlsContainerOverlay.react", "VideoPlayerControlsGroups.react", "VideoPlayerHooks", "VideoPlayerJoinOnPortalControl.react", "VideoPlayerLiveVideoControls_video.graphql", "VideoPlayerPlaybackControl.react", "VideoPlayerQuietModeControl.react", "VideoPlayerSettingsControl.react", "VideoPlayerVolumeControl.react", "VideoPlayerWatchAndScrollControl.react", "cr:1809777", "gkx", "qex", "react", "useVideoPlayerBigPlayButtonOverlay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");
    e = d("react");
    var j = e.useContext,
        k = e.useState,
        l = d("PlaybackSpeedExperiments").isInCometHeadroomTest() ? b("cr:1809777") : null,
        m = h !== void 0 ? h : h = b("VideoPlayerLiveVideoControls_video.graphql");

    function n(a) {
        var b, e, f = d("CometRelay").useFragment(m, a.video),
            g = d("VideoPlayerHooks").useEnded(),
            h = d("VideoPlayerHooks").useIsFullscreen(),
            n = j(d("VideoPlayerControlsBottomRowAddOnContext").VideoPlayerControlsBottomRowAddOnContext),
            o = c("useVideoPlayerBigPlayButtonOverlay")();
        o = o.bigPlayButtonIsVisible;
        var p = d("VideoPlayerHooks").useCaptionsLoaded(),
            q = d("VideoPlayerHooks").useCaptionsVisible(),
            r = k(null),
            s = r[0];
        r = r[1];
        var t = j(d("CometTahoeCustomVideoAreaContext").CometTahoeCustomVideoAreaContext);
        t = t.customVideoAreaHidden;
        if (g) return null;
        g = a.disablePlaybackControls;
        var u = a.expandControl,
            v = a.isControlsVisible,
            w = a.isExpandControlVisible;
        w = w === void 0 ? !1 : w;
        var x = a.isVolumeControlVisible,
            y = a.isWatchAndScrollControlVisible;
        y = y === void 0 ? !1 : y;
        var z = a.onUserInteraction,
            A = a.pictureInPictureControl,
            B = a.shouldRenderCaptionsControl;
        B = B === void 0 ? !0 : B;
        var C = a.shouldRenderCostreamControl;
        C = C === void 0 ? !1 : C;
        var D = a.shouldRenderModeratorControl;
        D = D === void 0 ? !1 : D;
        var E = a.subOrigin,
            F = f == null ? void 0 : f.id;
        b = f == null ? void 0 : (b = f.owner) == null ? void 0 : b.id;
        var G = f == null ? void 0 : f.if_viewer_can_see_costreaming_tools,
            H = G != null,
            I = f == null ? void 0 : f.if_viewer_can_use_clipping,
            J = (f == null ? void 0 : f.is_clipping_enabled) === !0,
            K = f == null ? void 0 : f.if_viewer_can_see_community_moderation_tools,
            L = K != null,
            M = f == null ? void 0 : f.if_viewer_can_use_live_rewind;
        e = ((e = f == null ? void 0 : f.live_rewind_enabled) != null ? e : !1) && a.shouldHideRewindControls !== !0;
        w = w || v || g === !0 && !o;
        y = y || v || g === !0 && !o;
        o = i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: w,
            noPaddingEnd: !0,
            noPaddingStart: !0,
            children: u
        });
        w = a.shouldRenderWatchAndScrollControl === !0 && E != null && f != null ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: y,
            children: i.jsx(c("VideoPlayerWatchAndScrollControl.react"), {
                subOrigin: E,
                video: f
            })
        }) : null;
        u = E === "watch_scroll";
        y = null;
        c("qex")._("170") && (y = A != null ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: v,
            children: A
        }) : null);
        A = c("gkx")("8487") ? B === !0 : !u;
        return i.jsxs(c("VideoPlayerControlsContainerOverlay.react"), {
            isBackgroundVisible: v,
            isVisible: t,
            children: [e ? i.jsx(d("CometRelay").MatchContainer, {
                match: M,
                props: {
                    isControlsVisible: v && !g,
                    onUserInteraction: z,
                    video: M
                }
            }) : i.jsxs(i.Fragment, {
                children: [Boolean(a.shouldRenderPauseControl) ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
                    isVisible: v && !g,
                    children: i.jsx(c("VideoPlayerPlaybackControl.react"), {})
                }) : null, i.jsx(d("VideoPlayerControlsGroups.react").Expanded, {
                    children: i.jsx(i.Fragment, {})
                })]
            }), i.jsxs(d("VideoPlayerControlsGroups.react").Contracted, {
                isVisible: v,
                children: [b != null && F != null && i.jsx(c("LiveCostreamerTagSubscription.react"), {
                    pageID: b,
                    videoID: F
                }), H && C && F != null && !h && i.jsx(c("CometPlaceholder.react"), {
                    fallback: null,
                    children: i.jsx(d("CometRelay").MatchContainer, {
                        match: G,
                        props: {
                            video: G
                        }
                    })
                }), a.shouldRenderQuietModeControl === !0 && !h && i.jsx(c("VideoPlayerQuietModeControl.react"), {}), J && F != null && i.jsx(d("CometRelay").MatchContainer, {
                    match: I,
                    props: {
                        video: I,
                        videoID: F
                    }
                }), L && D ? i.jsx(c("CometPlaceholder.react"), {
                    fallback: null,
                    children: i.jsx(d("CometRelay").MatchContainer, {
                        match: K,
                        props: {
                            video: K,
                            videoID: F
                        }
                    })
                }) : null, g === !0 ? null : i.jsx(c("CometTrackingNodeProvider.react"), {
                    trackingNode: 257,
                    children: i.jsx(d("LiveVideoLatencyMenu.react").LiveVideoLatencyMenuContextProvider, {
                        video: f,
                        children: i.jsx(c("VideoPlayerSettingsControl.react"), {
                            alignMenuToIcon: (n == null ? void 0 : n.getBottomRowAddOn()) != null,
                            menuOpened: s,
                            onUserInteraction: z,
                            setMenuOpened: r
                        })
                    })
                }), l != null ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
                    isVisible: v,
                    children: i.jsx(l, {
                        onUserInteraction: z
                    })
                }) : null, p && A ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
                    isVisible: v,
                    children: i.jsx(c("VideoPlayerCaptionsControl.react"), {
                        alignMenuToIcon: (n == null ? void 0 : n.getBottomRowAddOn()) != null,
                        captionsVisible: q,
                        menuOpened: s,
                        onUserInteraction: z,
                        setMenuOpened: r,
                        video: f
                    })
                }) : null, a.shouldRenderCastControl === !0 && E != null && f != null ? i.jsx(c("VideoPlayerCastControlShim.react"), {
                    isVisible: v && !g,
                    subOrigin: E
                }) : null]
            }), o, y, i.jsx(c("VideoPlayerJoinOnPortalControl.react"), {
                isVisible: v
            }), w, i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
                isVisible: x,
                noPaddingStart: !0,
                children: i.jsx(c("CometTrackingNodeProvider.react"), {
                    trackingNode: 114,
                    children: i.jsx(c("VideoPlayerVolumeControl.react"), {
                        onUserInteraction: z
                    })
                })
            })]
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        return i.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            children: i.jsx(n, babelHelpers["extends"]({}, a))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerDefaultControlsImplLive.react", ["CometRelay", "VideoPlayerDefaultControlsImplLive_video.graphql", "VideoPlayerLiveVideoControls.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");

    function a(a) {
        var e = a.expandControl,
            f = a.isControlsVisible,
            g = a.isVolumeControlVisible,
            j = a.onUserInteraction,
            k = a.pictureInPictureControl,
            l = a.shouldHideRewindControls,
            m = a.shouldRenderCaptionsControl,
            n = a.shouldRenderCostreamControl,
            o = a.shouldRenderModeratorControl,
            p = a.shouldRenderPauseControl,
            q = a.shouldRenderQuietModeControl,
            r = a.shouldRenderWatchAndScrollControl,
            s = a.subOrigin,
            t = a.video;
        a = a.videoTahoeUrl;
        t = d("CometRelay").useFragment(h !== void 0 ? h : h = b("VideoPlayerDefaultControlsImplLive_video.graphql"), t);
        return i.jsx(c("VideoPlayerLiveVideoControls.react"), {
            expandControl: e,
            isControlsVisible: f,
            isVolumeControlVisible: g,
            onUserInteraction: j,
            pictureInPictureControl: k,
            shouldHideRewindControls: l,
            shouldRenderCaptionsControl: m,
            shouldRenderCostreamControl: n,
            shouldRenderModeratorControl: o,
            shouldRenderPauseControl: p,
            shouldRenderQuietModeControl: q,
            shouldRenderWatchAndScrollControl: r,
            subOrigin: s,
            video: t,
            videoTahoeUrl: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerLiveRewindControlContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        cachedLiveRewindTimestamp: null,
        onLiveRewindControlEvent: function() {}
    });
    g["default"] = b
}), 98);
__d("VideoPlayerPlaybackTimerBase.react", ["getFormattedTimestamp", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.currentTime;
        a = a.duration;
        return h.jsxs("div", {
            className: "x3ajldb x27saw0 x2b8uid x9hgts1 x8j4wrb x1t4t16n x7h9g57 xss6m8b x1pg5gke x1rg5ohu x14ctfv",
            children: [h.jsx("span", {
                className: "x15hfatp x1s688f",
                children: c("getFormattedTimestamp")(b)
            }), a != null && h.jsxs(h.Fragment, {
                children: [h.jsx("span", {
                    children: " / "
                }), h.jsx("span", {
                    children: c("getFormattedTimestamp")(a)
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useLiveRewindUtils", ["VideoPlayerHooks", "VideoPlayerLiveRewindControlContext", "react", "useVideoPlayerControllerSubscription"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = h.useCallback,
        j = h.useContext,
        k = 10,
        l = 10;

    function a() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            var c = a.getCurrentState().seekableRanges;
            c = c != null ? (c = c.end(c.length() - 1)) != null ? c : 0 : 0;
            var d = Math.min(a.getPlayheadPosition() + k, c);
            d === c ? (a.setIsLiveRewindActive(!1), a.seek(c)) : a.seek(d);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function b() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            var c = a.getCurrentState().seekableRanges;
            c = (c = c == null ? void 0 : c.start(0)) != null ? c : 0;
            c = Math.max(a.getPlayheadPosition() - l, c);
            a.seek(c);
            a.setIsLiveRewindActive(!0);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function e() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            var c = a.getCurrentState().seekableRanges;
            c = c != null ? (c = c.end(c.length() - 1)) != null ? c : 0 : 0;
            a.seek(c);
            a.play("user_initiated");
            a.setIsLiveRewindActive(!1);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function f() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            var c = a.getCurrentState().seekableRanges;
            c = (c = c == null ? void 0 : c.start(0)) != null ? c : 0;
            a.seek(c);
            a.setIsLiveRewindActive(!0);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function m() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            a.play("user_initiated"), b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function n() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            a.pause("user_initiated"), a.setIsLiveRewindActive(!0), b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function o() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function() {
            var c = a.getCurrentState().seekableRanges;
            c = (c = c == null ? void 0 : c.start(0)) != null ? c : 0;
            a.seek(c);
            a.setIsLiveRewindActive(!0);
            a.play("user_initiated");
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function p() {
        var a = d("VideoPlayerHooks").useController(),
            b = j(c("VideoPlayerLiveRewindControlContext"));
        return i(function(c) {
            var d, e = a.getCurrentState().seekableRanges;
            d = (d = e == null ? void 0 : e.start(0)) != null ? d : 0;
            e = e != null ? (e = e.end(e.length() - 1)) != null ? e : 0 : 0;
            d = Math.min(d + c, e);
            a.scrubEnd(d);
            d === e ? a.setIsLiveRewindActive(!1) : a.setIsLiveRewindActive(!0);
            b.onLiveRewindControlEvent()
        }, [b, a])
    }

    function q() {
        return c("useVideoPlayerControllerSubscription")(function(a) {
            return (a = (a = a.getCurrentState().seekableRanges) == null ? void 0 : a.start(0)) != null ? a : 0
        })
    }
    g.useLiveRewindForward = a;
    g.useLiveRewindBack = b;
    g.useLiveRewindLive = e;
    g.useLiveRewindStart = f;
    g.useLiveRewindPlay = m;
    g.useLiveRewindPause = n;
    g.useLiveRewindReplay = o;
    g.useLiveRewindScrub = p;
    g.useLiveRewindSeekableStartTime = q
}), 98);
__d("VideoPlayerPlaybackTimer.react", ["VideoPlayerHooks", "VideoPlayerLiveRewindControlContext", "VideoPlayerPlaybackTimerBase.react", "gkx", "react", "useLiveRewindUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = function() {
            return d("VideoPlayerHooks").useCurrentTimeThrottled(200)
        };

    function a() {
        var a = d("VideoPlayerHooks").useIsLive(),
            b = d("VideoPlayerHooks").useDuration(),
            e = j(),
            f = d("useLiveRewindUtils").useLiveRewindSeekableStartTime(),
            g = i(c("VideoPlayerLiveRewindControlContext"));
        g = g.cachedLiveRewindTimestamp;
        var k = d("VideoPlayerHooks").useIsLiveRewindActive();
        if (a) {
            a = e - f;
            k && g != null && c("gkx")("1657274") && (a = g);
            return h.jsx(c("VideoPlayerPlaybackTimerBase.react"), {
                currentTime: a,
                duration: null
            })
        }
        return h.jsx(c("VideoPlayerPlaybackTimerBase.react"), {
            currentTime: e,
            duration: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerScrubberBase.react", ["fbt", "CometComponentWithKeyCommands.react", "CometKeys", "CometVisualCompletionAttributes", "VideoPlayerPointerDrag", "VideoPlayerSliderNub.react", "VideoPlayerUserInteractionCounter", "react", "stylex", "usePrevious"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useMemo,
        m = b.useState,
        n = {
            liveRewindTimePlayed: {
                backgroundColor: "xh1tjdi"
            },
            liveTimePlayed: {
                backgroundColor: "x1ciooss"
            },
            root: {
                cursor: "x1ypdohk",
                paddingTop: "x1y1aw1k",
                paddingEnd: "x4uap5",
                paddingBottom: "xwib8y2",
                paddingStart: "xkhd6sd",
                position: "x1n2onr6",
                userSelect: "x87ps6o",
                width: "xh8yej3"
            },
            timelineBackground: {
                backgroundColor: "x1rwy58d",
                borderTopStartRadius: "xm3z3ea",
                borderTopEndRadius: "x1x8b98j",
                borderBottomEndRadius: "x131883w",
                borderBottomStartRadius: "x16mih1h",
                boxShadow: "xpdb0fs",
                height: "xuoj239",
                textShadow: "xd9u3wd",
                userSelect: "x87ps6o"
            },
            timelineBuffered: {
                height: "xuoj239",
                position: "x10l6tqk"
            },
            timelineBufferedBackground: {
                backgroundColor: "x17j41np"
            },
            timelinePlayed: {
                backgroundColor: "x1evw4sf",
                borderTopStartRadius: "xm3z3ea",
                borderTopEndRadius: "x1x8b98j",
                borderBottomEndRadius: "x131883w",
                borderBottomStartRadius: "x16mih1h",
                height: "xuoj239",
                position: "x10l6tqk",
                userSelect: "x87ps6o"
            },
            tooltipContainer: {
                bottom: "xfqi8uc",
                position: "x10l6tqk"
            }
        };

    function o(a, b) {
        return Math.min(a > 0 ? b / a : 0, 1)
    }

    function a(a) {
        var b = a.bufferEnd,
            e = a.currentTime,
            f = a.disableKeyCommands,
            g = a.duration,
            p = a.isLive,
            q = a.isLiveRewindActive,
            r = a.keyLeftDescription,
            s = a.keyRightDescription,
            t = a.onScrubCancel,
            u = a.onScrubEnd,
            v = a.onScrubStart,
            w = a.onUserInteraction,
            x = a.playFromBeginningImpl,
            y = a.renderTooltip,
            z = a.skipBackwardImpl,
            A = a.skipForwardImpl,
            B = a.skipToEndImpl,
            C = a.supportsTouch,
            D = a.timelineBackgroundXStyle,
            E = a.timelineBufferedXStyle;
        a = a.timelinePlayedXStyle;
        var F = d("VideoPlayerPointerDrag").usePointerDragResizeObserver(),
            G = F.invalidateRootRect,
            H = F.rootRectRef;
        F = F.rootSizeRefCallback;
        var I = c("usePrevious")(e),
            J = m(!1),
            K = J[0],
            L = J[1];
        J = m(0);
        var M = J[0],
            N = J[1];
        J = m(!1);
        var O = J[0],
            P = J[1];
        J = m(0);
        var Q = J[0],
            R = J[1];
        J = m(null);
        var S = J[0],
            T = J[1];
        k(function() {
            e !== I && P(!1)
        }, [e, I]);
        J = d("VideoPlayerPointerDrag").usePointerDrag({
            onDragCancel: function(a) {
                t()
            },
            onDragEnd: function(a) {
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, H.current);
                if (!a) {
                    t();
                    return
                }
                N(a.ratioX);
                a = a.ratioX * g;
                u(a)
            },
            onDragEndSync: function() {
                P(!0)
            },
            onDragMove: function(a) {
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, H.current);
                if (!a) return;
                N(a.ratioX)
            },
            onDragStart: function(a) {
                G();
                a = d("VideoPlayerPointerDrag").computePointerOffsetRatio(a, H.current);
                if (!a) return;
                N(a.ratioX);
                v()
            }
        }, {
            hasTouchEvents: C === !0
        });
        C = J.isDragging;
        J = J.rootProps;
        var U = j(function() {
                L(!0)
            }, []),
            V = j(function() {
                L(!1)
            }, []),
            W = j(function(a) {
                G();
                if (H.current != null) {
                    var b = H.current.left,
                        c = H.current.width,
                        d = Math.max(0, Math.min(c, a.clientX - b));
                    d = c > 0 ? d / c : 0;
                    c = Number.isFinite(g) && g > 0 ? g * d : null;
                    R(a.clientX - b);
                    T(c)
                }
            }, [g, G, H]),
            X = K || C;
        d("VideoPlayerUserInteractionCounter").useVideoPlayerUserInteraction("video_scrubber", X, w);
        X = K || C || O;
        w = C || O ? M : p && !q ? 1 : o(g, e);
        C = o(g, b);
        O = l(function() {
            return f === !0 ? [] : [{
                command: {
                    key: c("CometKeys").RIGHT
                },
                description: s,
                handler: A
            }, {
                command: {
                    key: c("CometKeys").LEFT
                },
                description: r,
                handler: z
            }, {
                command: {
                    key: c("CometKeys").HOME
                },
                description: h._("Play from beginning"),
                handler: x
            }, {
                command: {
                    key: c("CometKeys").END
                },
                description: h._("Skip to end"),
                handler: B
            }]
        }, [f, s, A, r, z, x, B]);
        return i.jsx(c("CometComponentWithKeyCommands.react"), {
            commandConfigs: O,
            children: i.jsxs("div", babelHelpers["extends"]({}, J, {
                "aria-label": h._("Change Position"),
                "aria-orientation": "horizontal",
                "aria-valuemax": g,
                "aria-valuemin": "0",
                "aria-valuenow": e,
                className: c("stylex")(n.root),
                "data-testid": void 0,
                onMouseEnter: U,
                onMouseLeave: V,
                onMouseMove: W,
                ref: F,
                role: "slider",
                tabIndex: "0",
                children: [i.jsxs("div", {
                    className: c("stylex")(n.timelineBackground, D),
                    children: [i.jsx("div", babelHelpers["extends"]({
                        className: c("stylex")(n.timelineBuffered, !p && n.timelineBufferedBackground, E)
                    }, c("CometVisualCompletionAttributes").IGNORE, {
                        style: {
                            width: (100 * C).toFixed(5) + "%"
                        }
                    })), i.jsx("div", babelHelpers["extends"]({
                        className: c("stylex")(n.timelinePlayed, p && !q && n.liveTimePlayed, p && q && n.liveRewindTimePlayed, a)
                    }, c("CometVisualCompletionAttributes").IGNORE, {
                        style: {
                            width: (100 * w).toFixed(5) + "%"
                        },
                        children: i.jsx(c("VideoPlayerSliderNub.react"), {
                            isVisible: X
                        })
                    }))]
                }), y != null && S != null && K && i.jsx("div", {
                    className: c("stylex")(n.tooltipContainer),
                    style: {
                        left: Q
                    },
                    children: y(S)
                })]
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerScrubber.react", ["fbt", "VideoPlayerHooks", "VideoPlayerScrubberBase.react", "react", "useLiveRewindUtils"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = d("react").useCallback,
        k = function() {
            return d("VideoPlayerHooks").useCurrentTimeThrottled(200)
        };

    function a(a) {
        var b = a.onUserInteraction;
        a = a.renderTooltip;
        var e = k(),
            f = d("VideoPlayerHooks").useDuration(),
            g = d("VideoPlayerHooks").useController(),
            l = d("VideoPlayerHooks").useBufferEnd(),
            m = d("VideoPlayerHooks").useIsLive(),
            n = d("VideoPlayerHooks").useIsLiveRewindActive(),
            o = d("useLiveRewindUtils").useLiveRewindScrub(),
            p = d("useLiveRewindUtils").useLiveRewindForward(),
            q = d("useLiveRewindUtils").useLiveRewindBack(),
            r = d("useLiveRewindUtils").useLiveRewindStart(),
            s = d("useLiveRewindUtils").useLiveRewindLive(),
            t = d("useLiveRewindUtils").useLiveRewindSeekableStartTime();
        m && (f -= t, e -= t);
        t = j(function() {
            if (m) p();
            else {
                var a = g.getPlayheadPosition() + 5;
                a >= f ? g.seek(f - .01) : g.seek(a)
            }
        }, [g, m, p, f]);
        var u = m ? h._("Fast forward 10 seconds") : h._("Fast forward 5 seconds"),
            v = j(function() {
                if (m) q();
                else {
                    var a = g.getPlayheadPosition() - 5;
                    a < 0 ? g.seek(0) : g.seek(a)
                }
            }, [g, m, q]),
            w = m ? h._("Rewind 10 seconds") : h._("Rewind 5 seconds"),
            x = j(function() {
                m ? r() : g.seek(0)
            }, [g, m, r]),
            y = j(function() {
                m ? s() : g.seek(f - .01)
            }, [g, m, s, f]),
            z = j(function() {
                g.scrubEnd(null)
            }, [g]),
            A = j(function() {
                g.scrubBegin()
            }, [g]),
            B = j(function(a) {
                !m ? g.scrubEnd(a) : o(a)
            }, [g, m, o]);
        return i.jsx(c("VideoPlayerScrubberBase.react"), {
            bufferEnd: l,
            currentTime: e,
            duration: f,
            isLive: m,
            isLiveRewindActive: n,
            keyLeftDescription: w,
            keyRightDescription: u,
            onScrubCancel: z,
            onScrubEnd: B,
            onScrubStart: A,
            onUserInteraction: b,
            playFromBeginningImpl: x,
            renderTooltip: a,
            skipBackwardImpl: v,
            skipForwardImpl: t,
            skipToEndImpl: y
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerTimeIndicator.react", ["TetraText.react", "formatDurationSeconds", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.shouldCenterSelf;
        a = a.timestampSec;
        var d = b === !0 ? "var(--always-black)" : "var(--always-dark-overlay)";
        d = h.jsx("div", {
            className: "xuxw1ft x10l6tqk x1t2a60a xs9asl8 x1mpkggp x123j3cw x1wa3icf x10y3i5r xrt01vj x1yr5g0i x1lcm9me x18l40ae",
            style: {
                backgroundColor: d
            },
            children: h.jsx(c("TetraText.react"), {
                color: "primaryOnMedia",
                type: "body4",
                children: c("formatDurationSeconds")(Math.round(a))
            })
        });
        return b === !0 ? h.jsx("div", {
            className: "x1n2onr6 xl56j7k x78zum5",
            children: d
        }) : d
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerScrubberPreview.react", ["CometRelay", "VideoPlayerHooks", "VideoPlayerScrubberPreview_video.graphql", "VideoPlayerTimeIndicator.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react"),
        j = .1,
        k = 60,
        l = 120;

    function m(a, b, c, d, e, f) {
        c = c * b;
        b = Math.floor(a % c / b);
        var g = Math.floor(b / d);
        b = b % d;
        d = b * e;
        b = g * f;
        e = Math.floor(a / c);
        return {
            spriteIndex: e,
            spriteX: d,
            spriteY: b
        }
    }

    function a(a) {
        var e = a.timestampSec;
        a = a.video;
        var f = d("VideoPlayerHooks").useDimensions();
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("VideoPlayerScrubberPreview_video.graphql"), a);
        a = a == null ? void 0 : a.scrubber_preview_thumbnail_information;
        var g = a == null ? void 0 : a.sprite_uris,
            n = a == null ? void 0 : a.thumbnail_width,
            o = a == null ? void 0 : a.thumbnail_height,
            p = a == null ? void 0 : a.has_preview_thumbnails,
            q = a == null ? void 0 : a.num_images_per_row,
            r = a == null ? void 0 : a.max_number_of_images_per_sprite;
        a = a == null ? void 0 : a.time_interval_between_image;
        if (g == null || n == null || o == null || p == null || q == null || r == null || a == null || !p) return i.jsx(c("VideoPlayerTimeIndicator.react"), {
            shouldCenterSelf: !0,
            timestampSec: e
        });
        p = m(e, a, r, q, n, o);
        a = p.spriteIndex;
        r = p.spriteX;
        q = p.spriteY;
        p = n / o;
        n = f == null ? k : Math.max(k, Math.min(l, f.height * j));
        f = n * p;
        p = o / n;
        o = {
            backgroundImage: "url(" + g[a] + ")",
            backgroundPosition: "-" + r / p + "px -" + q / p + "px",
            backgroundSize: "1000% 1000%",
            borderRadius: 4,
            height: n,
            width: f
        };
        g = {
            backgroundColor: "var(--fds-black-alpha-60)",
            borderRadius: 4,
            height: n,
            left: -f / 2,
            padding: 1,
            width: f
        };
        return i.jsxs("div", {
            className: "x1n2onr6 xl56j7k x78zum5",
            style: g,
            children: [i.jsx("div", {
                style: o
            }), i.jsx(c("VideoPlayerTimeIndicator.react"), {
                timestampSec: e
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerScrubberWithPreview.react", ["VideoPlayerScrubber.react", "VideoPlayerScrubberPreview.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.onUserInteraction,
            d = a.video;
        return h.jsx(c("VideoPlayerScrubber.react"), {
            onUserInteraction: b,
            renderTooltip: function(a) {
                return h.jsx(c("VideoPlayerScrubberPreview.react"), {
                    timestampSec: a,
                    video: d
                })
            }
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerDefaultControlsImplNotLive.react", ["CometRelay", "PlaybackSpeedExperiments", "VideoPlayerCaptionsControl.react", "VideoPlayerControlsBottomRowAddOnContext", "VideoPlayerControlsContainerOverlay.react", "VideoPlayerControlsGroups.react", "VideoPlayerDefaultControlsImplNotLive_video.graphql", "VideoPlayerHooks", "VideoPlayerJoinOnPortalControl.react", "VideoPlayerPlaybackControl.react", "VideoPlayerPlaybackTimer.react", "VideoPlayerQuietModeControl.react", "VideoPlayerScrubberWithPreview.react", "VideoPlayerSettingsControl.react", "VideoPlayerVolumeControl.react", "VideoPlayerWatchAndScrollControl.react", "cr:1790881", "cr:1809777", "gkx", "qex", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");
    e = d("react");
    var j = e.useContext,
        k = e.useState,
        l = d("PlaybackSpeedExperiments").isInCometHeadroomTest ? b("cr:1790881") : null,
        m = d("PlaybackSpeedExperiments").isInCometHeadroomTest ? b("cr:1809777") : null,
        n = c("gkx")("3610") || !!c("qex")._("170");

    function a(a) {
        var e = a.expandControl,
            f = a.isControlsVisible,
            g = a.isVolumeControlVisible,
            o = a.onUserInteraction,
            p = a.pictureInPictureControl,
            q = a.shouldRenderCaptionsControl;
        q = q === void 0 ? !0 : q;
        var r = a.shouldRenderQuietModeControl;
        r = r === void 0 ? !1 : r;
        var s = a.shouldRenderWatchAndScrollControl,
            t = a.skipControl,
            u = a.subOrigin;
        a = a.video;
        a = d("CometRelay").useFragment(h !== void 0 ? h : h = b("VideoPlayerDefaultControlsImplNotLive_video.graphql"), a);
        var v = d("VideoPlayerHooks").useIsFullscreen(),
            w = a == null ? void 0 : a.id,
            x = a == null ? void 0 : a.if_viewer_can_use_clipping,
            y = j(d("VideoPlayerControlsBottomRowAddOnContext").VideoPlayerControlsBottomRowAddOnContext);
        r = r === !0 && !v ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            noPaddingEnd: !0,
            children: i.jsx(c("VideoPlayerQuietModeControl.react"), {})
        }) : null;
        v = x != null && w != null && i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            noPaddingEnd: !0,
            noPaddingStart: r != null,
            children: i.jsx(d("CometRelay").MatchContainer, {
                match: x,
                props: {
                    video: x,
                    videoID: w
                }
            })
        });
        x = k(null);
        w = x[0];
        x = x[1];
        y = i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            noPaddingEnd: !0,
            noPaddingStart: r != null || v != null,
            children: i.jsx(c("VideoPlayerSettingsControl.react"), {
                alignMenuToIcon: (y == null ? void 0 : y.getBottomRowAddOn()) != null,
                menuOpened: w,
                onUserInteraction: o,
                setMenuOpened: x
            })
        });
        s = s === !0 && u != null && a != null ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            children: i.jsx(c("VideoPlayerWatchAndScrollControl.react"), {
                subOrigin: u,
                video: a
            })
        }) : null;
        e = i.jsxs(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            noPaddingEnd: !0,
            children: [e, i.jsx(c("VideoPlayerJoinOnPortalControl.react"), {
                isVisible: f
            })]
        });
        var z = m != null ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: !0,
            children: i.jsx(m, {
                enableNUX: d("PlaybackSpeedExperiments").enableCometPlaybackSpeedControlHeadroomTestNUX(),
                onUserInteraction: o
            })
        }) : null;
        g = i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: m ? !0 : g,
            noPaddingStart: !0,
            children: i.jsx(c("VideoPlayerVolumeControl.react"), {
                onUserInteraction: o
            })
        });
        var A = i.jsx(d("VideoPlayerControlsGroups.react").Expanded, {
            isVisible: f,
            children: i.jsx(c("VideoPlayerScrubberWithPreview.react"), {
                onUserInteraction: o,
                video: a
            })
        });
        t = i.jsxs(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            children: [i.jsx(c("VideoPlayerPlaybackControl.react"), {}), t, i.jsx(c("VideoPlayerPlaybackTimer.react"), {}), l != null ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
                isVisible: f,
                children: i.jsx(l, {
                    onUserInteraction: o
                })
            }) : null]
        });
        u = u === "watch_scroll";
        q = c("gkx")("8487") ? q === !0 : !u;
        var B = d("VideoPlayerHooks").useCaptionsLoaded(),
            C = d("VideoPlayerHooks").useCaptionsVisible();
        B = B && !c("gkx")("1745416") && q ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            children: i.jsx(c("VideoPlayerCaptionsControl.react"), {
                captionsVisible: C,
                menuOpened: w,
                onUserInteraction: o,
                setMenuOpened: x,
                video: a
            })
        }) : null;
        q = u && n ? i.jsx(d("VideoPlayerControlsGroups.react").Contracted, {
            isVisible: f,
            children: p
        }) : null;
        return i.jsxs(c("VideoPlayerControlsContainerOverlay.react"), {
            isBackgroundVisible: f,
            children: [t, A, r, v, y, B, s, e, q, z, g]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerNavigateToTahoeOrFullScreenControl.react", ["CometTrackingNodeProvider.react", "VideoPlayerCometNavigateToTahoeControl.react", "VideoPlayerFullscreenControl.react", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.isAdVideo,
            d = a.onPressFullscreenControl,
            e = a.onPressTahoeControl,
            f = a.onUserInteraction,
            g = a.reactionVideoChannelType,
            i = a.shouldUnmute,
            j = a.subOrigin;
        a = a.videoTahoeUrl;
        var k = c("gkx")("1333");
        return h.jsx(c("CometTrackingNodeProvider.react"), {
            trackingNode: 144,
            children: Boolean(b) === !1 && j != null && a != null && a !== "" && !k ? h.jsx(c("VideoPlayerCometNavigateToTahoeControl.react"), {
                onPress: e,
                reactionVideoChannelType: g,
                subOrigin: j,
                videoTahoeUrl: a
            }) : h.jsx(c("VideoPlayerFullscreenControl.react"), {
                onPress: d,
                onUserInteraction: f,
                shouldUnmute: i
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useVideoPlayerVolumeControlAudioAvailabilityUI", ["fbt", "CometTooltipImpl.react", "VideoPlayerControlsHiddenContext", "clearTimeout", "emptyFunction", "qex", "react", "setTimeout", "useAudioAvailabilityAtPlayhead", "useLayoutEffect_SAFE_FOR_SSR", "usePrevious", "useStable"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useContext;
    e = b.useEffect;
    var k = b.useRef,
        l = b.useState,
        m = c("qex")._("109") ? e : c("useLayoutEffect_SAFE_FOR_SSR"),
        n = 3e3;

    function a(a) {
        var b = a.canPlayerProduceSound,
            d = a.isHovering;
        a = c("useAudioAvailabilityAtPlayhead")();
        var e = a.isSilentAtPlayhead;
        a = a.volumeControlState;
        var f = null;
        switch (a) {
            case "VOLUME_SILENT":
                f = h._("Video has no sound");
                break;
            case "VOLUME_COPYRIGHT_FULL":
                f = h._("Muted due to copyright claim");
                break;
            case "VOLUME_COPYRIGHT_PARTIAL_SILENCED":
                f = h._("Partially muted due to copyright claim");
                break;
            case "VOLUME_COPYRIGHT_PARTIAL_NOT_SILENCED":
                break;
            case "VOLUME_DEFAULT":
                break;
            default:
                a
        }
        var g = c("usePrevious")(e),
            o = l(!1),
            p = o[0],
            q = o[1],
            r = k(c("emptyFunction")),
            s = k(!1);
        o = l(!1);
        var t = o[0],
            u = o[1],
            v = c("useStable")(function() {
                return function(a) {
                    s.current = a, u(a), r.current(a), a || q(!1)
                }
            }),
            w = j(c("VideoPlayerControlsHiddenContext"));
        m(function() {
            w ? v(!1) : f == null ? v(!1) : d || p ? v(!0) : e !== g && e && b && v(!0)
        }, [f, b, w, d, p, e, g, v]);
        m(function() {
            if (t) {
                var a = c("setTimeout")(function() {
                    v(!1)
                }, n);
                return function() {
                    c("clearTimeout")(a)
                }
            }
        }, [t, v]);
        o = c("useStable")(function() {
            return function() {
                q(function(a) {
                    return !a
                })
            }
        });
        var x = c("useStable")(function() {
                return function(a) {
                    var b = l(!1),
                        d = b[0],
                        e = b[1];
                    m(function() {
                        r.current = e;
                        return function() {
                            r.current = c("emptyFunction")
                        }
                    }, [e]);
                    m(function() {
                        a.isVisible || v(!1)
                    }, [a.isVisible]);
                    return i.jsx(c("CometTooltipImpl.react"), babelHelpers["extends"]({}, a, {
                        isVisible: d
                    }))
                }
            }),
            y = a === "VOLUME_COPYRIGHT_FULL" || a === "VOLUME_SILENT",
            z = b ? e : y;
        return f == null ? null : {
            onVolumeControlPress: o,
            shouldDisableVolumeControl: y,
            shouldShowNullIcon: z,
            tooltipContent: f,
            tooltipImpl: x,
            volumeControlState: a
        }
    }
    g["default"] = a
}), 98);
__d("VideoPlayerWithAudioBackground.react", ["CometPlaceholder.react", "CometRelay", "VideoPlayerInteractionOverlay.react", "VideoPlayerWithAudioBackground_video.graphql", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");

    function a(a) {
        var e = d("CometRelay").useFragment(h !== void 0 ? h : h = b("VideoPlayerWithAudioBackground_video.graphql"), a.video);
        return e == null || (e == null ? void 0 : e.comet_video_player_audio_background_renderer) == null ? null : i.jsxs(c("CometPlaceholder.react"), {
            fallback: null,
            children: [i.jsx(d("VideoPlayerInteractionOverlay.react").VideoPlayerInteractionOverlay, {
                pressInteraction: a.pressInteraction
            }), i.jsx(d("CometRelay").MatchContainer, {
                match: e == null ? void 0 : e.comet_video_player_audio_background_renderer,
                props: {
                    playerFormat: a.playerFormat,
                    pressInteraction: a.pressInteraction
                }
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerWithAudioOverlay.react", ["CometRelay", "VideoPlayerWithAudioOverlay_video.graphql", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react");

    function a(a) {
        var c = d("CometRelay").useFragment(h !== void 0 ? h : h = b("VideoPlayerWithAudioOverlay_video.graphql"), a.video);
        return c == null ? null : i.jsx("div", {
            className: "xl56j7k x5yr21d x78zum5 x6s0dn4",
            children: i.jsx(d("CometRelay").MatchContainer, {
                match: c == null ? void 0 : c.comet_video_player_audio_overlay_renderer,
                props: {
                    playerFormat: a.playerFormat,
                    pressInteraction: a.pressInteraction
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerWithLiveVideoEndscreen.react", ["fbt", "CometRelay", "TetraTextPairing.react", "VideoPlayerHooks", "VideoPlayerInteractionOverlay.react", "VideoPlayerWithLiveVideoEndscreen_video.graphql", "react", "usePOESurveyDialog"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = d("react");

    function a(a) {
        var e = d("VideoPlayerHooks").useEnded(),
            f = d("VideoPlayerHooks").useIsLive(),
            g = d("CometRelay").useFragment(i !== void 0 ? i : i = b("VideoPlayerWithLiveVideoEndscreen_video.graphql"), a.video),
            k = c("usePOESurveyDialog")(g);
        if (!e || !f) return null;
        else k();
        e = (g == null ? void 0 : g.is_huddle) === !0 || (g == null ? void 0 : g.is_live_audio_room_v2_broadcast) === !0 ? h._("This live audio room has ended.") : h._("This live video has ended.");
        return j.jsx(d("VideoPlayerInteractionOverlay.react").VideoPlayerInteractionOverlay, {
            children: j.jsx("div", {
                className: "x13vifvy x17qophe x10l6tqk xl56j7k xdt5ytf xds687c x78zum5 x9f619 x1ey2m1c xal61yo x6s0dn4",
                children: j.jsxs("div", {
                    className: "xm6i5cn",
                    children: [j.jsx(c("TetraTextPairing.react"), {
                        body: g == null ? void 0 : (f = g.live_end_text) == null ? void 0 : f.text,
                        bodyColor: "white",
                        headline: e,
                        headlineColor: "white",
                        level: 2,
                        textAlign: "center"
                    }), a.children]
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("Duration.react", ["ServerTime", "clearTimeout", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = 500,
        j = 1e3,
        k = 60,
        l = 60;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            b = a.call(this, b) || this;
            b.state = {
                duration: 0
            };
            return b
        }
        var e = b.prototype;
        e.UNSAFE_componentWillMount = function() {
            this.$2()
        };
        e.componentWillUnmount = function() {
            c("clearTimeout")(this.$1)
        };
        e.$2 = function() {
            var a = this,
                b;
            this.props.useLocalTime ? b = Date.now() : b = d("ServerTime").getMillis();
            this.setState({
                duration: Math.max(b - this.props.startTime, 0)
            });
            this.$1 = c("setTimeout")(function() {
                return a.$2()
            }, i)
        };
        e.render = function() {
            var a = Math.floor(this.state.duration / j),
                b = a % k;
            a = Math.floor(a / k);
            var c = a % l;
            a = Math.floor(a / l);
            var d = "";
            a > 0 && (d = a + ":");
            a = c + ":";
            a.length < 3 && d.length > 0 && (a = "0" + a);
            c = "" + b;
            c.length < 2 && (c = "0" + c);
            return h.jsxs("span", {
                children: [d, a, c]
            })
        };
        return b
    }(h.Component);
    a.defaultProps = {
        useLocalTime: !1
    };
    g["default"] = a
}), 98);
__d("VideoPlayerWithLiveVideoIndicator.react", ["fbt", "ix", "CometImage.react", "CometPlaceholder.react", "CometRelay", "CometRouteRenderType", "Duration.react", "GamingVideoBackLink.react", "TetraText.react", "VideoBroadcastStatus", "VideoPlayerHooks", "VideoPlayerWithLiveVideoIndicator_video.graphql", "clearTimeout", "cr:541", "deferredLoadComponent", "gkx", "intlSummarizeNumber", "react", "requireDeferred", "setTimeout", "stylex", "unrecoverableViolation", "useVideoPlayerUnifiedCVCProvider"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k = d("react");
    e = d("react");
    var l = e.useEffect,
        m = e.useRef,
        n = e.useState,
        o = c("deferredLoadComponent")(c("requireDeferred")("LiveVideoCometNuxForCVC.react").__setRef("VideoPlayerWithLiveVideoIndicator.react")),
        p = {
            cvcIndicator: {
                alignItems: "x6s0dn4",
                backgroundColor: "xrmyhay",
                borderTopStartRadius: "x1lcm9me",
                borderTopEndRadius: "x1yr5g0i",
                borderBottomEndRadius: "xrt01vj",
                borderBottomStartRadius: "x10y3i5r",
                boxSizing: "x9f619",
                display: "x3nfvp2",
                height: "x5yr21d",
                marginStart: "x1mnrxsn",
                paddingTop: "xexx8yu",
                paddingEnd: "xsyo7zv",
                paddingBottom: "x18d9i69",
                paddingStart: "x16hj40l"
            },
            cvcIndicatorIcon: {
                display: "x3nfvp2",
                marginEnd: "xw3qccf",
                position: "x1n2onr6"
            },
            liveIndicator: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "x1lcm9me",
                borderTopEndRadius: "x1yr5g0i",
                borderBottomEndRadius: "xrt01vj",
                borderBottomStartRadius: "x10y3i5r",
                boxSizing: "x9f619",
                display: "x3nfvp2",
                height: "x5yr21d",
                paddingTop: "xexx8yu",
                paddingEnd: "xsyo7zv",
                paddingBottom: "x18d9i69",
                paddingStart: "x16hj40l"
            },
            liveIndicatorAnimation: {
                animationDirection: "xpz12be",
                animationDuration: "xof6966",
                animationIterationCount: "xa4qsjk",
                animationName: "x18wbh7p",
                animationTimingFunction: "xkewf8z"
            },
            liveIndicatorBackground: {
                backgroundColor: "x1ciooss"
            },
            liveIndicatorExpanded: {
                display: "x3nfvp2",
                marginStart: "xsgj6o6"
            },
            liveRewindIndicatorBackground: {
                backgroundColor: "x1osi62z"
            },
            positionTop: {
                display: "x78zum5",
                height: "xxk0z11",
                position: "x10l6tqk",
                start: "xoie2o3",
                top: "x1tk7jg1"
            },
            positionTopWithCometNavOverlay: {
                start: "x1i5ckhj",
                top: "xoyzfg9"
            },
            positionTopWithCometNavOverlayWorkplace: {
                start: "x1i5ckhj",
                top: "xoyzfg9"
            },
            privacyNux: {
                position: "x10l6tqk",
                start: "xoie2o3",
                top: "x1w1tb2m"
            },
            rehearsalIndicator: {
                backgroundColor: "x1d2osyd"
            },
            speakerIndicator: {
                marginStart: "x1mnrxsn"
            }
        };

    function a(a) {
        var e, f, g, h = d("VideoPlayerHooks").useIsLive(),
            i = d("VideoPlayerHooks").useIsLiveRewindActive(),
            u = d("VideoPlayerHooks").useIsFullscreen(),
            v = d("CometRouteRenderType").useIsMain(),
            w = d("VideoPlayerHooks").usePlaying(),
            x = m(null),
            y = d("CometRelay").useFragment(j !== void 0 ? j : j = b("VideoPlayerWithLiveVideoIndicator_video.graphql"), a.video),
            z = (e = y == null ? void 0 : y.videoId) != null ? e : "";
        if (y == null || typeof z !== "string" || z === "") throw c("unrecoverableViolation")("Null video or bad videoId", "comet_live_video");
        var A = d("useVideoPlayerUnifiedCVCProvider").useVideoPlayerUnifiedCVCData();
        e = n((e = y.liveViewerCount) != null ? e : 0);
        var B = e[0],
            C = e[1];
        e = n(!1);
        var D = e[0],
            E = e[1];
        e = n(!1);
        var F = e[0],
            G = e[1];
        l(function() {
            h && A != null && (q(A.bs) ? C(A.c) : (C(0), E(!0)))
        }, [A, h]);
        l(function() {
            w ? (G(!0), x.current = c("setTimeout")(function() {
                G(!1)
            }, 3e3)) : x.current && (G(!1), c("clearTimeout")(x.current));
            return function() {
                return c("clearTimeout")(x.current)
            }
        }, [w]);
        l(function() {
            h && z && (b("cr:541") == null ? void 0 : b("cr:541").loadImmediately(function(a) {
                a.LiveProducerLiveActivated(z)
            }))
        }, [h, z]);
        e = ((e = y.rehearsalInfo) == null ? void 0 : e.typeName) === "LiveVideoRehearsalInfo";
        f = (f = y.is_gaming_video) != null ? f : !1;
        g = (g = a.includeGamingBackLink) != null ? g : !1;
        g = g && v && f;
        f = !h || D;
        if (f) return null;
        D = c("gkx")("1443572");
        return k.jsxs(k.Fragment, {
            children: [k.jsxs("div", {
                className: c("stylex")(p.positionTop, D ? a.shouldExpand !== !0 && (a.hasCometNavOverlay || v) && !u && !a.renderedInLiveProducer === !0 && p.positionTopWithCometNavOverlayWorkplace : a.hasCometNavOverlay && !u && p.positionTopWithCometNavOverlay),
                children: [g ? k.jsx(c("GamingVideoBackLink.react"), {}) : null, k.jsx("div", {
                    className: c("stylex")(p.liveIndicator, !i && p.liveIndicatorAnimation, !i && p.liveIndicatorBackground, i && p.liveRewindIndicatorBackground, e && p.rehearsalIndicator),
                    "data-testid": void 0,
                    children: k.jsxs(c("TetraText.react"), {
                        color: e ? "primary" : "white",
                        type: "bodyLink4",
                        children: [r(y), a.shouldExpand === !0 && F && (y == null ? void 0 : y.publish_time) != null && !i && t(y.publish_time)]
                    })
                }), (y == null ? void 0 : y.live_speaker_count_indicator) != null && k.jsx("span", {
                    className: c("stylex")(p.speakerIndicator),
                    children: k.jsx(d("CometRelay").MatchContainer, {
                        match: y == null ? void 0 : y.live_speaker_count_indicator
                    })
                }), s(y, B)]
            }), a.shouldShowPrivacyNux === !0 && k.jsx(c("CometPlaceholder.react"), {
                fallback: null,
                children: k.jsx("div", {
                    className: c("stylex")(p.privacyNux),
                    children: k.jsx(o, {
                        videoID: z
                    })
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function q(a) {
        if (a == null) return !1;
        switch (a) {
            case c("VideoBroadcastStatus").LIVE:
            case c("VideoBroadcastStatus").LIVE_STOPPED:
            case c("VideoBroadcastStatus").SEAL_STARTED:
                return !0;
            default:
                return !1
        }
    }

    function r(a) {
        if ((a == null ? void 0 : a.isPremiere) === !0) return h._("PREMIERE");
        return (a == null ? void 0 : a.breakingStatus) === !0 ? h._("LIVE BREAKING") : h._("LIVE")
    }
    r.displayName = r.name + " [from " + f.id + "]";

    function s(a, b) {
        if (a === null || b == null || b === 0) return null;
        a = k.jsx(c("CometImage.react"), {
            alt: "",
            src: a.is_huddle === !0 || (a == null ? void 0 : a.is_live_audio_room_v2_broadcast) === !0 ? i("1214050") : i("411339")
        });
        a = k.jsx("span", {
            className: c("stylex")(p.cvcIndicatorIcon),
            children: a
        });
        return k.jsxs("div", {
            "aria-label": h._({
                "*": "{number} people currently watching this video.",
                "_1": "1 person currently watching this video."
            }, [h._plural(b, "number", c("intlSummarizeNumber")(b))]),
            className: c("stylex")(p.cvcIndicator),
            "data-testid": void 0,
            role: "img",
            children: [a, k.jsx(c("TetraText.react"), {
                color: "primaryOnMedia",
                type: "body4",
                children: c("intlSummarizeNumber")(b)
            })]
        })
    }
    s.displayName = s.name + " [from " + f.id + "]";

    function t(a) {
        return k.jsx("div", {
            className: c("stylex")(p.liveIndicatorExpanded),
            children: k.jsx(c("Duration.react"), {
                startTime: a * 1e3,
                useLocalTime: !0
            })
        })
    }
    t.displayName = t.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("VideoPlayerWithLiveVideoInterruptedOverlay.react", ["fbt", "CometLoadingAnimation.react", "TetraTextPairing.react", "VideoPlayerHooks", "VideoPlayerInteractionOverlay.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a() {
        var a = d("VideoPlayerHooks").useStreamInterrupted(),
            b = d("VideoPlayerHooks").useIsLiveRewindActive();
        return !a || b ? null : i.jsx(d("VideoPlayerInteractionOverlay.react").VideoPlayerInteractionOverlay, {
            children: i.jsxs("div", {
                className: "x13vifvy x17qophe x10l6tqk xl56j7k xdt5ytf xds687c x78zum5 x9f619 x1ey2m1c x18l40ae x6s0dn4",
                children: [i.jsx("div", {
                    children: i.jsx(c("TetraTextPairing.react"), {
                        body: h._("The broadcast is waiting for a signal. It should resume shortly."),
                        bodyColor: "white",
                        headline: h._("Waiting for Live Video Signal"),
                        headlineColor: "white",
                        level: 2,
                        textAlign: "center"
                    })
                }), i.jsx("div", {
                    className: "x14qfxbe x1n2onr6 x1sy10c2 xc9qbxq",
                    children: i.jsx(c("CometLoadingAnimation.react"), {
                        size: 36
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometRelayExpiredVideoUrlRefreshHandler", ["CometRelay", "cr:2741", "react", "unrecoverableViolation", "useCometRelayExpiredVideoUrlRefreshHandlerQuery.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = d("react").useCallback;

    function a(a) {
        var e = d("CometRelay").useRelayEnvironment();
        if (a == null || a === "") throw c("unrecoverableViolation")("refreshCometRelayVideoPlayerExpiredUrl videoFBID cannot be " + (a === "" ? "an empty string" : a === null ? "null" : "undefined"), "comet_video_player");
        return i(function(c) {
            var f = h !== void 0 ? h : h = b("useCometRelayExpiredVideoUrlRefreshHandlerQuery.graphql");
            return d("CometRelay").fetchQuery(e, f, {
                expiredURL: btoa(c),
                videoID: a
            }).toPromise().then(function(c) {
                var d;
                if (b("cr:2741")) return b("cr:2741")(a, c);
                d = (d = c == null ? void 0 : (d = c.video) == null ? void 0 : (d = d.rmd_refreshed_url) == null ? void 0 : d.new_url) != null ? d : null;
                c = (c = c == null ? void 0 : (c = c.video) == null ? void 0 : (c = c.rmd_refreshed_url) == null ? void 0 : c.reason) != null ? c : null;
                return {
                    reason: c,
                    refreshedUrl: d
                }
            })
        }, [e, a])
    }
    g["default"] = a
}), 98);
__d("VideoPlayerCometWatchInjectionControl.react", ["fbt", "ix", "VideoPlayerControlIcon.react", "fbicon", "react", "useCometRouterState", "useVideoPlayerPortalingPassthroughProps"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");

    function a(a) {
        var b = a.isARLTW,
            e = a.onPress,
            f = a.routeTracePolicy,
            g = a.subOrigin;
        a = a.videoWatchUrl;
        var k = c("useVideoPlayerPortalingPassthroughProps")();
        k = k.portableVideoID;
        var l = c("useCometRouterState")();
        l = l == null ? void 0 : l.main.route.tabKey;
        l = l !== "watch" ? h._("Open in Watch") : h._("Enlarge");
        return j.jsx(c("VideoPlayerControlIcon.react"), {
            icon: d("fbicon")._(i("517763"), 20),
            label: l,
            linkProps: {
                passthroughProps: {
                    isARLTW: b,
                    portableVideoID: k,
                    portalingRouteTracePolicy: f,
                    portalingSubOrigin: g,
                    unmute: !0
                },
                url: a
            },
            onPress: e,
            tooltip: l
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CommerceTabFeedClickFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1878");
    c = b("FalcoLoggerInternal").create("commerce_tab_feed_click", a);
    e.exports = c
}), null);
__d("XCometMeControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/me/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XCometProfileControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/profile.php", Object.freeze({
        show_switched_toast: !1,
        show_switched_tooltip: !1,
        is_tour_dismissed: !1,
        is_tour_completed: !1,
        show_podcast_settings: !1,
        show_community_transition: !1,
        show_community_review_changes: !1,
        should_open_composer: !1,
        badge_type: "NEW_MEMBER",
        show_community_rollback_toast: !1,
        show_community_rollback: !1,
        show_follower_visibility_disclosure: !1
    }), void 0);
    b = a;
    g["default"] = b
}), 98);