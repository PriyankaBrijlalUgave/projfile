if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("MessengerPlatformInterfaceType", [], (function(a, b, c, d, e, f) {
    e.exports = {
        UNKNOWN_INTERFACE: 0,
        MESSENGER_INTERFACE: 1,
        FB_INTERFACE: 2,
        FB_POST_INTERFACE: 3,
        FB_MESSAGING_INTERFACE: 4,
        FB_COMMENT_INTERFACE: 5,
        FB_STORIES_INTERFACE: 6,
        FB_CONVERSATION_GUIDE: 7
    }
}), null);
__d("getWorkplaceUFI2ComposerPluginsDEPRECATED_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        };
        return {
            argumentDefinitions: [{
                kind: "RootArgument",
                name: "useDefaultActor"
            }],
            kind: "Fragment",
            metadata: {
                mask: !1
            },
            name: "getWorkplaceUFI2ComposerPluginsDEPRECATED_feedback",
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_gif",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_file",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_photo",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_video",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_sticker",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_bot_mention",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_marker",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_comment_markdown_eligible",
                storageKey: null
            }, a, {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "use_default_actor",
                    variableName: "useDefaultActor"
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "viewer_actor",
                plural: !1,
                selections: [a, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "Avatar",
                        kind: "LinkedField",
                        name: "user_avatar",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "has_fb_app_avatar",
                            storageKey: null
                        }],
                        storageKey: null
                    }],
                    type: "User",
                    abstractKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "__typename",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "composer_tip",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mentions_datasource_js_constructor_args_json",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "owning_profile",
                plural: !1,
                selections: [a],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "TextWithEntities",
                kind: "LinkedField",
                name: "people_outside_community_in_comment_notice",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "EntityAtRange",
                    kind: "LinkedField",
                    name: "ranges",
                    plural: !0,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "entity",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "url",
                            storageKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "length",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "offset",
                        storageKey: null
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "text",
                    storageKey: null
                }],
                storageKey: null
            }],
            type: "Feedback",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("getWorkplaceUFI2ComposerPluginsDEPRECATED_group.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: {
            mask: !1
        },
        name: "getWorkplaceUFI2ComposerPluginsDEPRECATED_group",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "GroupMentionsSectionsInfo",
            kind: "LinkedField",
            name: "group_mentions_sections_info",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "member_title",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "member_aux",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "nonmember_title",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "nonmember_aux",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "bot_title",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "bot_aux",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Group",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("SnowliftUFIRenderer_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                kind: "Variable",
                name: "use_default_actor",
                variableName: "useDefaultActor"
            },
            b = [a],
            c = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            };
        return {
            argumentDefinitions: [{
                kind: "RootArgument",
                name: "containerIsWorkplace"
            }, {
                kind: "RootArgument",
                name: "feedLocation"
            }, {
                kind: "RootArgument",
                name: "feedbackSource"
            }, {
                kind: "RootArgument",
                name: "useDefaultActor"
            }],
            kind: "Fragment",
            metadata: null,
            name: "SnowliftUFIRenderer_feedback",
            selections: [{
                alias: "comment_count",
                args: null,
                concreteType: "TopLevelCommentsConnection",
                kind: "LinkedField",
                name: "top_level_comments",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "total_count",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_see_ufi",
                storageKey: null
            }, {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "location",
                    variableName: "feedLocation"
                }, a],
                kind: "ScalarField",
                name: "can_viewer_comment",
                storageKey: null
            }, {
                alias: null,
                args: b,
                kind: "ScalarField",
                name: "can_viewer_react",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_see_voice_switcher",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "have_comments_been_disabled",
                storageKey: null
            }, c, {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "feedback_source_integer",
                    variableName: "feedbackSource"
                }],
                kind: "ScalarField",
                name: "is_eligible_for_real_time_updates",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_viewer_muted",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mentions_datasource_js_constructor_args_json",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "num_localized_comment_orderings",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "subscription_target_id",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "supports_disabling_comments",
                storageKey: null
            }, {
                alias: null,
                args: b,
                concreteType: null,
                kind: "LinkedField",
                name: "viewer_actor",
                plural: !1,
                selections: [c, {
                    args: null,
                    kind: "FragmentSpread",
                    name: "UFI2Composer_actor"
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "Avatar",
                        kind: "LinkedField",
                        name: "user_avatar",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "has_fb_app_avatar",
                            storageKey: null
                        }],
                        storageKey: null
                    }],
                    type: "User",
                    abstractKey: null
                }, d],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_gif",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_photo",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_video",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_sticker",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_stars",
                storageKey: null
            }, {
                alias: "flat_threading_config",
                args: [{
                    kind: "Literal",
                    name: "type",
                    value: "FLAT_THREADING"
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "threading_config",
                plural: !1,
                selections: [d],
                storageKey: 'threading_config(type:"FLAT_THREADING")'
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "composer_tip",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "owning_profile",
                plural: !1,
                selections: [c],
                storageKey: null
            }, {
                condition: "containerIsWorkplace",
                kind: "Condition",
                passingValue: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_comment_with_file",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_comment_with_bot_mention",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_comment_with_marker",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_comment_markdown_eligible",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "TextWithEntities",
                    kind: "LinkedField",
                    name: "people_outside_community_in_comment_notice",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "EntityAtRange",
                        kind: "LinkedField",
                        name: "ranges",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "entity",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "url",
                                storageKey: null
                            }],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "length",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "offset",
                            storageKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "text",
                        storageKey: null
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "Group",
                    kind: "LinkedField",
                    name: "associated_group",
                    plural: !1,
                    selections: [c, {
                        alias: null,
                        args: null,
                        concreteType: "GroupMentionsSectionsInfo",
                        kind: "LinkedField",
                        name: "group_mentions_sections_info",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "member_title",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "member_aux",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "nonmember_title",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "nonmember_aux",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "bot_title",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "bot_aux",
                            storageKey: null
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }]
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "SnowliftUFISummary_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2ActorSelector_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2Comment_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2CommentActorLinkBadgesDynamic_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2CommentDisabledNotice_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2CommentsList_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2Composer_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2PrivateReplyActionLink_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2ReactionActionLink_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2ShareActionLink_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2ViewOptionsSelector_feedback"
            }],
            type: "Feedback",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("SnowliftUFIRenderer_shareableConfig.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "SnowliftUFIRenderer_shareableConfig",
        selections: [{
            args: null,
            kind: "FragmentSpread",
            name: "UFI2ShareActionLink_shareableConfig"
        }],
        type: "ShareableConfig",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("SnowliftUFIRootQuery.graphql", ["relay-runtime"], (function(a, aa, ba, ca, da, ea) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "UFI2CommentsProvider_commentsKey"
            },
            aa = {
                defaultValue: !0,
                kind: "LocalArgument",
                name: "containerIsFeedStory"
            },
            ba = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "containerIsLiveStory"
            },
            ca = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "containerIsTahoe"
            },
            da = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "containerIsWorkplace"
            },
            ea = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextEnableComment"
            },
            fa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextIsAdPreview"
            },
            ga = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextIsAggregatedShare"
            },
            ha = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextIsStorySet"
            },
            ia = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsFeedbackContext"
            },
            ja = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "feedLocation"
            },
            ka = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "feedbackSource"
            },
            la = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "feedbackTargetID"
            },
            ma = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "focusCommentID"
            },
            na = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "isComet"
            },
            oa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "mediaID"
            },
            pa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            },
            qa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "useDefaultActor"
            },
            ra = [{
                kind: "Variable",
                name: "id",
                variableName: "feedbackTargetID"
            }],
            sa = [{
                kind: "Variable",
                name: "id",
                variableName: "mediaID"
            }, {
                kind: "Literal",
                name: "shareable_type",
                value: "MEDIA"
            }],
            ta = {
                alias: "comment_count",
                args: null,
                concreteType: "TopLevelCommentsConnection",
                kind: "LinkedField",
                name: "top_level_comments",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "total_count",
                    storageKey: null
                }],
                storageKey: null
            },
            b = {
                kind: "Variable",
                name: "use_default_actor",
                variableName: "useDefaultActor"
            },
            ua = {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "location",
                    variableName: "feedLocation"
                }, b],
                kind: "ScalarField",
                name: "can_viewer_comment",
                storageKey: null
            };
        b = [b];
        var va = {
                alias: null,
                args: b,
                kind: "ScalarField",
                name: "can_viewer_react",
                storageKey: null
            },
            c = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            wa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "subscription_target_id",
                storageKey: null
            },
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            xa = {
                kind: "TypeDiscriminator",
                abstractKey: "__isActor"
            },
            e = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            f = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "url",
                storageKey: null
            },
            g = [f],
            ya = {
                kind: "InlineFragment",
                selections: g,
                type: "Entity",
                abstractKey: "__isEntity"
            },
            h = {
                kind: "Variable",
                name: "scale",
                variableName: "scale"
            },
            i = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "uri",
                storageKey: null
            },
            j = [i],
            za = {
                alias: "profile_picture_depth_0",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 32
                }, h, {
                    kind: "Literal",
                    name: "width",
                    value: 32
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: j,
                storageKey: null
            },
            Aa = [{
                kind: "Literal",
                name: "height",
                value: 20
            }, h, {
                kind: "Literal",
                name: "width",
                value: 20
            }],
            Ba = {
                alias: "profile_picture_depth_1_legacy",
                args: Aa,
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: j,
                storageKey: null
            },
            Ca = [{
                kind: "Literal",
                name: "site",
                value: "www"
            }],
            Da = {
                alias: "www_url",
                args: Ca,
                kind: "ScalarField",
                name: "url",
                storageKey: 'url(site:"www")'
            },
            k = [Da],
            Ea = {
                kind: "InlineFragment",
                selections: k,
                type: "Application",
                abstractKey: null
            },
            Fa = {
                kind: "InlineFragment",
                selections: k,
                type: "Event",
                abstractKey: null
            },
            Ga = {
                kind: "InlineFragment",
                selections: k,
                type: "Group",
                abstractKey: null
            },
            Ha = [d],
            Ia = [d, c],
            Ja = {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "owning_profile",
                plural: !1,
                selections: Ia,
                storageKey: null
            },
            Ka = {
                alias: "i18n_reaction_count",
                args: null,
                kind: "ScalarField",
                name: "reaction_count_reduced",
                storageKey: null
            },
            l = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "count",
                storageKey: null
            },
            m = [l],
            La = [{
                kind: "Literal",
                name: "orderby",
                value: ["COUNT_DESC", "REACTION_TYPE"]
            }],
            Ma = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "reaction_count",
                storageKey: null
            },
            Na = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "key",
                storageKey: null
            },
            Oa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "reaction_type",
                storageKey: null
            },
            Pa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "share_fbid",
                storageKey: null
            },
            Qa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_empty",
                storageKey: null
            },
            Ra = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "status",
                storageKey: null
            },
            Sa = {
                alias: null,
                args: null,
                concreteType: "PageReplyableActivity",
                kind: "LinkedField",
                name: "activity",
                plural: !1,
                selections: [c, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }],
                storageKey: null
            },
            n = [c],
            Ta = {
                alias: null,
                args: null,
                concreteType: "Page",
                kind: "LinkedField",
                name: "page",
                plural: !1,
                selections: n,
                storageKey: null
            },
            Ua = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "permalink",
                storageKey: null
            },
            Va = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_reply_permission",
                storageKey: null
            },
            Wa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "should_show_private_reply_nux",
                storageKey: null
            },
            o = {
                kind: "InlineFragment",
                selections: n,
                type: "Node",
                abstractKey: "__isNode"
            },
            Xa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "length",
                storageKey: null
            },
            Ya = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "offset",
                storageKey: null
            },
            p = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "text",
                storageKey: null
            },
            Za = {
                alias: null,
                args: b,
                kind: "ScalarField",
                name: "comment_composer_placeholder",
                storageKey: null
            },
            $a = {
                alias: "toplevel_comment_count",
                args: [{
                    kind: "Literal",
                    name: "orderby",
                    value: "toplevel"
                }],
                concreteType: "TopLevelCommentsConnection",
                kind: "LinkedField",
                name: "top_level_comments",
                plural: !1,
                selections: m,
                storageKey: 'top_level_comments(orderby:"toplevel")'
            },
            ab = {
                kind: "Variable",
                name: "feed_context_enable_comment",
                variableName: "displayCommentsContextEnableComment"
            },
            q = {
                kind: "Variable",
                name: "feed_context_fb_feed_location",
                variableName: "feedLocation"
            },
            bb = {
                kind: "Variable",
                name: "feed_context_is_ad_preview",
                variableName: "displayCommentsContextIsAdPreview"
            },
            r = {
                kind: "Variable",
                name: "feed_context_is_aggregated_share",
                variableName: "displayCommentsContextIsAggregatedShare"
            },
            cb = {
                kind: "Variable",
                name: "feed_context_is_story_set",
                variableName: "displayCommentsContextIsStorySet"
            },
            s = {
                kind: "Variable",
                name: "feedback_context",
                variableName: "displayCommentsFeedbackContext"
            },
            db = {
                kind: "Variable",
                name: "feedback_source",
                variableName: "feedbackSource"
            },
            eb = {
                kind: "Variable",
                name: "focus_comment_id",
                variableName: "focusCommentID"
            },
            t = {
                kind: "Literal",
                name: "is_initial_fetch",
                value: !0
            },
            fb = [ab, q, bb, r, cb, s, db, eb, t, {
                kind: "Literal",
                name: "is_top_level",
                value: !0
            }],
            gb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "after_count",
                storageKey: null
            },
            hb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "before_count",
                storageKey: null
            },
            ib = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "created_time",
                storageKey: null
            },
            jb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "legacy_fbid",
                storageKey: null
            },
            u = [f, Da];
        u = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "author",
            plural: !1,
            selections: [d, c, e, {
                kind: "InlineFragment",
                selections: u,
                type: "Event",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: u,
                type: "Group",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: u,
                type: "Page",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: u,
                type: "User",
                abstractKey: null
            }, xa, za, Ba, Ea, ya],
            storageKey: null
        };
        var kb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_weak_reference",
                storageKey: null
            },
            lb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "spam_display_mode",
                storageKey: null
            },
            mb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_disable_preview",
                storageKey: null
            },
            nb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_hidden_by_content_owner",
                storageKey: null
            },
            ob = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_banned_by_content_owner",
                storageKey: null
            },
            pb = {
                alias: null,
                args: null,
                concreteType: "StoryAttachment",
                kind: "LinkedField",
                name: "attachments",
                plural: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "style_list",
                    storageKey: null
                }],
                storageKey: null
            },
            qb = {
                alias: null,
                args: null,
                concreteType: "Story",
                kind: "LinkedField",
                name: "attached_story",
                plural: !1,
                selections: Ia,
                storageKey: null
            },
            rb = {
                alias: null,
                args: null,
                concreteType: "ReactorsOfContentConnection",
                kind: "LinkedField",
                name: "reactors",
                plural: !1,
                selections: [l, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "count_reduced",
                    storageKey: null
                }],
                storageKey: null
            },
            sb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "should_show_top_reactions",
                storageKey: null
            },
            v = [Na, c],
            tb = {
                alias: null,
                args: b,
                concreteType: "FeedbackReactionInfo",
                kind: "LinkedField",
                name: "viewer_feedback_reaction_info",
                plural: !1,
                selections: v,
                storageKey: null
            },
            ub = {
                alias: null,
                args: La,
                concreteType: "TopReactionsConnection",
                kind: "LinkedField",
                name: "top_reactions",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "TopReactionsEdge",
                    kind: "LinkedField",
                    name: "edges",
                    plural: !0,
                    selections: [Ma, {
                        alias: null,
                        args: null,
                        concreteType: "FeedbackReactionInfo",
                        kind: "LinkedField",
                        name: "node",
                        plural: !1,
                        selections: [Na, c, Oa],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: 'top_reactions(orderby:["COUNT_DESC","REACTION_TYPE"])'
            },
            vb = {
                alias: "can_see_top_custom_reactions_on_comment",
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "if_viewer_can_render_group_custom_reactions",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFICommentTopReactions_feedback",
                    fragmentName: "CometUFICommentCustomTopReactions_feedback",
                    fragmentPropName: "feedback",
                    kind: "ModuleImport"
                }, c],
                storageKey: null
            },
            wb = {
                alias: "cannot_see_top_custom_reactions_on_comment",
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "if_viewer_cannot_render_group_custom_reactions",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFICommentTopReactions_feedback__cannot_use_group_custom_reactions",
                    fragmentName: "CometUFIClassicCommentTopReactions_feedback",
                    fragmentPropName: "feedback",
                    kind: "ModuleImport"
                }, c],
                storageKey: null
            };
        ab = [ab, q, bb, r, cb, s, db, eb, t, {
            kind: "Literal",
            name: "is_top_level",
            value: !1
        }];
        q = {
            kind: "Variable",
            name: "feed_location",
            variableName: "feedLocation"
        };
        bb = {
            alias: null,
            args: null,
            concreteType: "GroupCommentInfo",
            kind: "LinkedField",
            name: "group_comment_info",
            plural: !1,
            selections: [{
                alias: "is_author_with_member_profile_legacy",
                args: [q, {
                    kind: "Variable",
                    name: "is_comet",
                    variableName: "isComet"
                }],
                kind: "ScalarField",
                name: "is_author_with_member_profile",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "group_id",
                storageKey: null
            }],
            storageKey: null
        };
        r = [{
            kind: "Literal",
            name: "translation_type",
            value: "ORIGINAL"
        }];
        cb = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "value",
            storageKey: null
        };
        s = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "entity_is_weak_reference",
            storageKey: null
        };
        db = {
            alias: null,
            args: r,
            concreteType: null,
            kind: "LinkedField",
            name: "preferred_body",
            plural: !1,
            selections: [d, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "translation_type",
                storageKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "DelightAtRange",
                    kind: "LinkedField",
                    name: "delight_ranges",
                    plural: !0,
                    selections: [d, {
                        alias: null,
                        args: null,
                        concreteType: "TextDelightCampaign",
                        kind: "LinkedField",
                        name: "campaign",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: [{
                                kind: "Literal",
                                name: "delight_surface",
                                value: "COMMENT"
                            }],
                            concreteType: "TextDelightStylePair",
                            kind: "LinkedField",
                            name: "delight_styles",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "style",
                                storageKey: null
                            }, cb],
                            storageKey: 'delight_styles(delight_surface:"COMMENT")'
                        }, c],
                        storageKey: null
                    }, Xa, Ya],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "EntityAtRange",
                    kind: "LinkedField",
                    name: "ranges",
                    plural: !0,
                    selections: [d, {
                        alias: null,
                        args: null,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "entity",
                        plural: !1,
                        selections: [d, {
                            condition: "isComet",
                            kind: "Condition",
                            passingValue: !0,
                            selections: [{
                                alias: null,
                                args: [{
                                    kind: "Literal",
                                    name: "site",
                                    value: "comet"
                                }],
                                kind: "ScalarField",
                                name: "url",
                                storageKey: 'url(site:"comet")'
                            }]
                        }, {
                            condition: "isComet",
                            kind: "Condition",
                            passingValue: !1,
                            selections: k
                        }, o, {
                            kind: "InlineFragment",
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "can_skip_redirect",
                                storageKey: null
                            }],
                            type: "ExternalUrl",
                            abstractKey: null
                        }, {
                            kind: "InlineFragment",
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "time_index",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                concreteType: "Video",
                                kind: "LinkedField",
                                name: "video",
                                plural: !1,
                                selections: n,
                                storageKey: null
                            }],
                            type: "VideoTimeIndex",
                            abstractKey: null
                        }],
                        storageKey: null
                    }, s, Xa, Ya],
                    storageKey: null
                }, p],
                type: "TextWithEntities",
                abstractKey: null
            }],
            storageKey: 'preferred_body(translation_type:"ORIGINAL")'
        };
        eb = {
            alias: "sub_reply_parent_above_comment_author_context",
            args: [{
                kind: "Literal",
                name: "type",
                value: "AUTHOR_CONTEXT_ABOVE_COMMENT"
            }],
            concreteType: null,
            kind: "LinkedField",
            name: "sub_reply_parent_context",
            plural: !1,
            selections: [d, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "UFI2CommentRow_comment",
                    fragmentName: "UFI2SubReplyParentAboveCommentAuthorContext_subReplyParentContext",
                    fragmentPropName: "subReplyParentContext",
                    kind: "ModuleImport"
                }],
                type: "CommentSubReplyParentAboveCommentAuthorContext",
                abstractKey: null
            }],
            storageKey: 'sub_reply_parent_context(type:"AUTHOR_CONTEXT_ABOVE_COMMENT")'
        };
        t = [{
            kind: "Literal",
            name: "type",
            value: "REPLY_PREVIEW_CONTEXT"
        }];
        var xb = {
                alias: "sub_reply_parent_preview_context",
                args: t,
                concreteType: null,
                kind: "LinkedField",
                name: "sub_reply_parent_context",
                plural: !1,
                selections: [d, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentRow_comment__sub_reply_parent_preview_context",
                        fragmentName: "UFI2CommentReplyParentPreview_subReplyParentContext",
                        fragmentPropName: "subReplyParentContext",
                        kind: "ModuleImport"
                    }],
                    type: "CommentSubReplyParentPreviewContext",
                    abstractKey: null
                }],
                storageKey: 'sub_reply_parent_context(type:"REPLY_PREVIEW_CONTEXT")'
            },
            yb = {
                alias: null,
                args: null,
                concreteType: "WorkAMAUFIAnsweredEventCommentModuleRenderer",
                kind: "LinkedField",
                name: "work_answered_event_comment_renderer",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "UFI2Comment_comment_work_answered_event_comment_renderer",
                    fragmentName: "CometUFIAMABroadcastAnswerEventRow_data",
                    fragmentPropName: "data",
                    kind: "ModuleImport"
                }],
                storageKey: null
            };
        s = {
            alias: null,
            args: null,
            concreteType: "TextWithEntities",
            kind: "LinkedField",
            name: "body",
            plural: !1,
            selections: [p, {
                alias: null,
                args: null,
                concreteType: "EntityAtRange",
                kind: "LinkedField",
                name: "ranges",
                plural: !0,
                selections: [d, {
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "entity",
                    plural: !1,
                    selections: [d, o],
                    storageKey: null
                }, s, Xa, Ya],
                storageKey: null
            }],
            storageKey: null
        };
        var zb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_markdown_enabled",
                storageKey: null
            },
            Ab = {
                alias: "can_comment",
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [ua, c],
                storageKey: null
            },
            w = [h],
            x = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "height",
                storageKey: null
            },
            y = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "width",
                storageKey: null
            },
            Bb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "title",
                storageKey: null
            },
            Cb = {
                alias: null,
                args: null,
                concreteType: "InlineSurveyStoryActionLink",
                kind: "LinkedField",
                name: "inline_survey_config",
                plural: !1,
                selections: [{
                    alias: null,
                    args: w,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "favicon",
                    plural: !1,
                    selections: [x, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "scale",
                        storageKey: null
                    }, i, y],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "followup_choices",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "followup_question",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "main_choices",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "main_question",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "privacy_text",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "session_blob",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "thankyou_text",
                    storageKey: null
                }, Bb, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "tessa_survey_config_id",
                    storageKey: null
                }],
                storageKey: null
            },
            Db = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "reply_parent_comment",
                plural: !1,
                selections: n,
                storageKey: null
            },
            Eb = {
                alias: "threading_depth",
                args: null,
                kind: "ScalarField",
                name: "depth",
                storageKey: null
            },
            Fb = {
                kind: "ClientExtension",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_created_from_subscription",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_locally_composed",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "optimistic_action",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "optimistic_error_code",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "client_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "optimistic_error",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "reply_comment_parent_fbid",
                    storageKey: null
                }]
            },
            z = [p],
            Gb = {
                alias: null,
                args: null,
                concreteType: "TextWithEntities",
                kind: "LinkedField",
                name: "source",
                plural: !1,
                selections: z,
                storageKey: null
            },
            A = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "animated_image_attribution",
                storageKey: null
            },
            B = {
                alias: null,
                args: null,
                concreteType: "ObjectionableContentInfo",
                kind: "LinkedField",
                name: "objectionable_content_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "categories",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "ObjectionableContentWarningScreenText",
                    kind: "LinkedField",
                    name: "strings",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "blur_subtitle",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "blur_title",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "cover_media_link",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "learn_more_desc",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "learn_more_uri",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "show_media_desc",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "uncover_media_link",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            },
            C = {
                kind: "Literal",
                name: "height",
                value: 396
            },
            D = {
                kind: "Literal",
                name: "width",
                value: 396
            },
            E = [x, i, y],
            F = {
                kind: "InlineFragment",
                selections: n,
                type: "MontageImage",
                abstractKey: null
            },
            G = {
                kind: "InlineFragment",
                selections: n,
                type: "MontageVideo",
                abstractKey: null
            };
        i = [i, y, x];
        A = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "media",
            plural: !1,
            selections: [d, {
                kind: "InlineFragment",
                selections: [c, A, {
                    condition: "isComet",
                    kind: "Condition",
                    passingValue: !0,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "playable_url",
                        storageKey: null
                    }]
                }, B, y, x, {
                    alias: null,
                    args: null,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: j,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "original_height",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "original_width",
                    storageKey: null
                }],
                type: "Video",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    alias: "media_id",
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }, A, c],
                type: "GenericAttachmentMedia",
                abstractKey: null
            }, {
                alias: "gifAnimatedImage_396",
                args: [C, {
                    kind: "Literal",
                    name: "media_type",
                    value: "image/gif"
                }, h, D],
                concreteType: "Image",
                kind: "LinkedField",
                name: "animated_image",
                plural: !1,
                selections: E,
                storageKey: null
            }, {
                alias: "image_396",
                args: [C, h, {
                    kind: "Literal",
                    name: "sizing",
                    value: "contain-fit"
                }, D],
                concreteType: "Image",
                kind: "LinkedField",
                name: "image",
                plural: !1,
                selections: E,
                storageKey: null
            }, {
                alias: "webPAnimatedImage_396",
                args: [C, {
                    kind: "Literal",
                    name: "media_type",
                    value: "image/webp"
                }, h, D],
                concreteType: "Image",
                kind: "LinkedField",
                name: "animated_image",
                plural: !1,
                selections: E,
                storageKey: null
            }, o, F, G, {
                alias: "fallback_image",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 98
                }, h, {
                    kind: "Literal",
                    name: "width",
                    value: 98
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "image",
                plural: !1,
                selections: E,
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_playable",
                storageKey: null
            }, {
                kind: "InlineFragment",
                selections: [B, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "accessibility_caption",
                    storageKey: null
                }, {
                    alias: "massive_image",
                    args: w,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: [y, x],
                    storageKey: null
                }, {
                    alias: null,
                    args: [{
                        kind: "Literal",
                        name: "height",
                        value: 210
                    }, h, {
                        kind: "Literal",
                        name: "width",
                        value: 260
                    }],
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: i,
                    storageKey: null
                }],
                type: "Photo",
                abstractKey: null
            }],
            storageKey: null
        };
        C = [{
            alias: null,
            args: null,
            concreteType: "StreetAddress",
            kind: "LinkedField",
            name: "address",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "single_line_full_address",
                storageKey: null
            }],
            storageKey: null
        }, c, e, {
            alias: null,
            args: null,
            concreteType: "Location",
            kind: "LinkedField",
            name: "location",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "latitude",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "longitude",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "overall_rating",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "price_range_description",
            storageKey: null
        }, {
            alias: null,
            args: [{
                kind: "Literal",
                name: "size__height",
                value: 60
            }, {
                kind: "Literal",
                name: "size__width",
                value: 60
            }],
            concreteType: "Image",
            kind: "LinkedField",
            name: "profile_picture",
            plural: !1,
            selections: j,
            storageKey: "profile_picture(size__height:60,size__width:60)"
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "top_category_name",
            storageKey: null
        }, f];
        D = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "target",
            plural: !1,
            selections: [d, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_add_to_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_remove_from_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_add_suggested_to_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_remove_suggested_from_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_curate_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "Page",
                    kind: "LinkedField",
                    name: "pending_places_for_attachment",
                    plural: !0,
                    selections: C,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "CommentPlaceInfoToPlaceListItemsConnection",
                    kind: "LinkedField",
                    name: "place_list_items",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "PlaceListItem",
                        kind: "LinkedField",
                        name: "nodes",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "Page",
                            kind: "LinkedField",
                            name: "recommendation_page",
                            plural: !1,
                            selections: C,
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "PageCtaPayload",
                            kind: "LinkedField",
                            name: "page_cta",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "cta_label",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "cta_type",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "cta_icon",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "web_uri",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "web_destination_type",
                                storageKey: null
                            }],
                            storageKey: null
                        }, c],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "CommentPlaceInfo",
                abstractKey: null
            }, c, {
                kind: "InlineFragment",
                selections: g,
                type: "ExternalUrl",
                abstractKey: null
            }],
            storageKey: null
        };
        E = [{
            alias: null,
            args: null,
            concreteType: "EntityAtRange",
            kind: "LinkedField",
            name: "ranges",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "entity",
                plural: !1,
                selections: [d, f, o],
                storageKey: null
            }, Xa, Ya],
            storageKey: null
        }, p];
        B = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "style_infos",
            plural: !0,
            selections: [d, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "TextWithEntities",
                    kind: "LinkedField",
                    name: "donation_comment_text",
                    plural: !1,
                    selections: E,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "use_donation_v2",
                    storageKey: null
                }],
                type: "FundraiserForStoryDonationAttachmentStyleInfo",
                abstractKey: null
            }, o, {
                kind: "InlineFragment",
                selections: n,
                type: "GamesInstantPlayStyleInfo",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: n,
                type: "XFBPluginStyleInfo",
                abstractKey: null
            }],
            storageKey: null
        };
        w = {
            alias: null,
            args: null,
            concreteType: "TextWithEntities",
            kind: "LinkedField",
            name: "title_with_entities",
            plural: !1,
            selections: z,
            storageKey: null
        };
        y = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "action_links",
            plural: !0,
            selections: [d, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "object_id",
                    storageKey: null
                }],
                type: "ArticleContextActionLink",
                abstractKey: null
            }],
            storageKey: null
        };
        x = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "tracking",
            storageKey: null
        };
        C = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "label",
            storageKey: null
        };
        g = [e, c];
        z = [{
            kind: "Literal",
            name: "height",
            value: 80
        }, h, {
            kind: "Literal",
            name: "width",
            value: 80
        }];
        z = {
            alias: "sticker",
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "media",
            plural: !1,
            selections: [d, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frame_count",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frame_rate",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frames_per_column",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frames_per_row",
                    storageKey: null
                }, C, {
                    alias: null,
                    args: null,
                    concreteType: "StickerPack",
                    kind: "LinkedField",
                    name: "pack",
                    plural: !1,
                    selections: g,
                    storageKey: null
                }, {
                    alias: null,
                    args: z,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "sprite_image",
                    plural: !1,
                    selections: j,
                    storageKey: null
                }, {
                    alias: "sticker_image",
                    args: z,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: i,
                    storageKey: null
                }, {
                    alias: "larger_sticker_image",
                    args: [{
                        kind: "Literal",
                        name: "height",
                        value: 120
                    }, h, {
                        kind: "Literal",
                        name: "width",
                        value: 120
                    }],
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: i,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "sticker_type",
                    storageKey: null
                }],
                type: "Sticker",
                abstractKey: null
            }, o, {
                kind: "InlineFragment",
                selections: n,
                type: "GenericAttachmentMedia",
                abstractKey: null
            }, F, G],
            storageKey: null
        };
        h = {
            alias: null,
            args: null,
            concreteType: "StoryAttachment",
            kind: "LinkedField",
            name: "attachments",
            plural: !0,
            selections: [f, Gb, A, D, B, w, y, x, z, {
                alias: "style_type_renderer_blue",
                args: [{
                    kind: "Literal",
                    name: "supported",
                    value: ["StoryAttachmentTipJarPaymentStyleRenderer", "StoryAttachmentChatCommandStyleRenderer", "StoryAttachmentInstantGamesTournamentActivityStyleRenderer"]
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "style_type_renderer",
                plural: !1,
                selections: [d, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentLazyLoadAttachmentContainer_attachment",
                        fragmentName: "UFI2CommentTipJarPaymentAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentTipJarPaymentStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentLazyLoadAttachmentContainer_attachment",
                        fragmentName: "UFI2CommentChatCommandAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentChatCommandStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentLazyLoadAttachmentContainer_attachment",
                        fragmentName: "UFI2CommentInstantGamesTournamentActivityAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentInstantGamesTournamentActivityStyleRenderer",
                    abstractKey: null
                }],
                storageKey: 'style_type_renderer(supported:["StoryAttachmentTipJarPaymentStyleRenderer","StoryAttachmentChatCommandStyleRenderer","StoryAttachmentInstantGamesTournamentActivityStyleRenderer"])'
            }],
            storageKey: null
        };
        i = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_verified",
            storageKey: null
        };
        F = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "author",
            plural: !1,
            selections: [{
                kind: "InlineFragment",
                selections: [i, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "short_name",
                    storageKey: null
                }],
                type: "User",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [i],
                type: "Page",
                abstractKey: null
            }],
            storageKey: null
        };
        G = {
            alias: null,
            args: null,
            concreteType: "Story",
            kind: "LinkedField",
            name: "parent_post_story",
            plural: !1,
            selections: n,
            storageKey: null
        };
        i = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "upvote_downvote_total",
            storageKey: null
        };
        var Hb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "viewer_comment_vote_state",
                storageKey: null
            },
            Ib = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "work_ama_answer_status",
                storageKey: null
            },
            Jb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_share",
                storageKey: null
            },
            Kb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_upvote_downvote",
                storageKey: null
            },
            H = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "chat_to_buy",
                storageKey: null
            },
            Lb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "ban_action",
                storageKey: null
            },
            I = {
                alias: null,
                args: null,
                concreteType: "EditHistoryConnection",
                kind: "LinkedField",
                name: "edit_history",
                plural: !1,
                selections: m,
                storageKey: null
            };
        v = {
            alias: null,
            args: null,
            concreteType: "FeedbackReaction",
            kind: "LinkedField",
            name: "supported_reactions",
            plural: !0,
            selections: v,
            storageKey: null
        };
        var Mb = {
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "associated_video",
                plural: !1,
                selections: n,
                storageKey: null
            },
            Nb = {
                alias: null,
                args: null,
                concreteType: "ReactorsOfContentConnection",
                kind: "LinkedField",
                name: "reactors",
                plural: !1,
                selections: [Qa],
                storageKey: null
            },
            Ob = {
                alias: null,
                args: null,
                concreteType: "PrivateReplyContext",
                kind: "LinkedField",
                name: "page_private_reply",
                plural: !1,
                selections: [Sa, Ra, Ta, Ua, Va, Wa, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "user_can_private_reply",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "prefilled_content",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "post_id",
                    storageKey: null
                }],
                storageKey: null
            },
            Pb = {
                alias: null,
                args: null,
                concreteType: "PublicConversationsExperimentContext",
                kind: "LinkedField",
                name: "public_conversations_context",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "comment_vote_ui_version",
                    storageKey: null
                }],
                storageKey: null
            },
            J = {
                alias: null,
                args: null,
                concreteType: "PageAdminActorInfo",
                kind: "LinkedField",
                name: "page_admin_actor_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "creator_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "creator_name",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "creator_type",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "label_type",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "page_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "profile_uri",
                    storageKey: null
                }],
                storageKey: null
            },
            K = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_ban_user",
                storageKey: null
            },
            L = {
                alias: null,
                args: b,
                concreteType: "Page",
                kind: "LinkedField",
                name: "viewer_acts_as_page",
                plural: !1,
                selections: n,
                storageKey: null
            },
            Qb = {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "parent_feedback",
                plural: !1,
                selections: [K, c, L, Ja],
                storageKey: null
            },
            Rb = {
                alias: null,
                args: null,
                concreteType: "PrivateReplyContext",
                kind: "LinkedField",
                name: "private_reply_context",
                plural: !1,
                selections: [Ta, Ra, Va],
                storageKey: null
            },
            M = {
                alias: null,
                args: null,
                concreteType: "PostTranslatability",
                kind: "LinkedField",
                name: "translatability_for_viewer",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "source_dialect_name",
                    storageKey: null
                }],
                storageKey: null
            },
            N = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "translation_available_for_viewer",
                storageKey: null
            };
        q = [q];
        var O = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "badge_asset",
                storageKey: null
            },
            P = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "badge_color",
                storageKey: null
            },
            Q = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "identity_badge_type",
                storageKey: null
            },
            R = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "multiple_badge_asset",
                storageKey: null
            },
            S = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "multiple_badge_asset_colored",
                storageKey: null
            },
            T = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "serialized",
                storageKey: null
            },
            U = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "badge_color_variant",
                storageKey: null
            },
            Sb = {
                alias: null,
                args: q,
                concreteType: "IdentityBadge",
                kind: "LinkedField",
                name: "identity_badges_web",
                plural: !0,
                selections: [O, P, Q, R, S, p, T, U, {
                    args: null,
                    documentName: "FeedStoryUFICommentBody_comment",
                    fragmentName: "UFI2CommentIdentityBadges_identityBadge",
                    fragmentPropName: "identityBadge",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            V = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_see_constituent_badge_upsell",
                storageKey: null
            },
            W = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "legacy_token",
                storageKey: null
            },
            X = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_constituent_badge",
                storageKey: null
            };
        t = {
            alias: "sub_reply_parent_preview_context",
            args: t,
            concreteType: null,
            kind: "LinkedField",
            name: "sub_reply_parent_context",
            plural: !1,
            selections: Ha,
            storageKey: 'sub_reply_parent_context(type:"REPLY_PREVIEW_CONTEXT")'
        };
        var Y = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_non_coworker",
                storageKey: null
            },
            Z = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_bot",
                storageKey: null
            },
            $ = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_original_poster",
                storageKey: null
            },
            Tb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_the_comment_on_work_knowledge",
                storageKey: null
            };
        g = {
            alias: null,
            args: null,
            concreteType: "InternQASyncedAnswerData",
            kind: "LinkedField",
            name: "synced_intern_qa_answer",
            plural: !1,
            selections: [Ra, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "activity_uri",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "User",
                kind: "LinkedField",
                name: "last_editor",
                plural: !1,
                selections: g,
                storageKey: null
            }],
            storageKey: null
        };
        var Ub = {
                condition: "containerIsWorkplace",
                kind: "Condition",
                passingValue: !0,
                selections: [Y, Z, $, Tb, g]
            },
            Vb = {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "author",
                plural: !1,
                selections: [d, e, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "first_name",
                        storageKey: null
                    }],
                    type: "User",
                    abstractKey: null
                }, c],
                storageKey: null
            },
            Wb = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "comment_parent",
                plural: !1,
                selections: [c, Vb],
                storageKey: null
            },
            Xb = {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [v, Mb, Nb, va, wa],
                storageKey: null
            };
        K = {
            alias: null,
            args: null,
            concreteType: "Feedback",
            kind: "LinkedField",
            name: "parent_feedback",
            plural: !1,
            selections: [K, c, L],
            storageKey: null
        };
        var Yb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "written_while_video_was_live",
                storageKey: null
            },
            Zb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "timestamp_in_video",
                storageKey: null
            },
            $b = {
                alias: null,
                args: q,
                concreteType: "IdentityBadge",
                kind: "LinkedField",
                name: "identity_badges_web",
                plural: !0,
                selections: [O, P, Q, R, S, p, T, U, {
                    args: null,
                    documentName: "LiveFeedStoryUFICommentBody_comment",
                    fragmentName: "UFI2CommentIdentityBadges_identityBadge",
                    fragmentPropName: "identityBadge",
                    kind: "ModuleImport"
                }],
                storageKey: null
            };
        Vb = {
            alias: null,
            args: null,
            concreteType: "Comment",
            kind: "LinkedField",
            name: "comment_parent",
            plural: !1,
            selections: [c, Vb, {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: n,
                storageKey: null
            }],
            storageKey: null
        };
        O = {
            alias: null,
            args: q,
            concreteType: "IdentityBadge",
            kind: "LinkedField",
            name: "identity_badges_web",
            plural: !0,
            selections: [O, P, Q, R, S, p, T, U, {
                args: null,
                documentName: "TahoeUFICommentBody_comment",
                fragmentName: "UFI2CommentIdentityBadges_identityBadge",
                fragmentPropName: "identityBadge",
                kind: "ModuleImport"
            }],
            storageKey: null
        };
        P = {
            alias: null,
            args: null,
            concreteType: "Feedback",
            kind: "LinkedField",
            name: "feedback",
            plural: !1,
            selections: [v, Mb, Nb, va],
            storageKey: null
        };
        Q = {
            condition: "containerIsWorkplace",
            kind: "Condition",
            passingValue: !0,
            selections: [{
                alias: null,
                args: null,
                concreteType: "StoryAttachment",
                kind: "LinkedField",
                name: "attachments",
                plural: !0,
                selections: [f, Gb, A, D, B, w, y, x, z],
                storageKey: null
            }, F, G, i, Hb, Ib, Kb, I, P, {
                alias: null,
                args: r,
                concreteType: null,
                kind: "LinkedField",
                name: "preferred_body",
                plural: !1,
                selections: [{
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "fb_workplace_commonmark_ast_serialized",
                        storageKey: null
                    }],
                    type: "FBMarkdownCommentBody",
                    abstractKey: null
                }],
                storageKey: 'preferred_body(translation_type:"ORIGINAL")'
            }, M, N, f, {
                alias: null,
                args: null,
                concreteType: "WorkApprovalRequestInfoModuleRenderer",
                kind: "LinkedField",
                name: "work_approval_request_info",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "WorkplaceFeedStoryUFICommentActionLinks_comment",
                    fragmentName: "WorkApprovalsUFICommentActions_data",
                    fragmentPropName: "data",
                    kind: "ModuleImport"
                }],
                storageKey: null
            }, V, W, X, {
                alias: null,
                args: null,
                concreteType: "FileMarker",
                kind: "LinkedField",
                name: "file_marker",
                plural: !1,
                selections: [C, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "page_number",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "location_x",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "location_y",
                    storageKey: null
                }],
                storageKey: null
            }, t, Y, Z, $, Tb, g]
        };
        R = {
            alias: null,
            args: q,
            kind: "ScalarField",
            name: "comment_menu_tooltip",
            storageKey: null
        };
        S = {
            condition: "isComet",
            kind: "Condition",
            passingValue: !1,
            selections: [{
                alias: null,
                args: null,
                concreteType: "GroupCommentInfo",
                kind: "LinkedField",
                name: "group_comment_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_author_muted",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_report_comment_to_admin_with_tags",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_block_author",
                    storageKey: null
                }],
                storageKey: null
            }, W, R, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "comment_menu_items",
                plural: !0,
                selections: [d, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "show_remove_content_options",
                        storageKey: null
                    }],
                    type: "CommentMenuItemDeleteAndRemoveMember",
                    abstractKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "parent_feedback",
                plural: !1,
                selections: [c, L],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "create_detailed_report_uri",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "us_structured_reporting_enabled",
                storageKey: null
            }]
        };
        T = {
            condition: "isComet",
            kind: "Condition",
            passingValue: !0,
            selections: [R, {
                alias: null,
                args: q,
                kind: "ScalarField",
                name: "should_show_comment_menu",
                storageKey: null
            }]
        };
        U = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "cursor",
            storageKey: null
        };
        Gb = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_initially_expanded",
            storageKey: null
        };
        A = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "page_size",
            storageKey: null
        };
        D = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "reply_comment_order",
            storageKey: null
        };
        B = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "should_render_composer_preemptively",
            storageKey: null
        };
        w = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "comment_order",
            storageKey: null
        };
        y = {
            alias: null,
            args: null,
            concreteType: "PageInfo",
            kind: "LinkedField",
            name: "page_info",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "end_cursor",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_next_page",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_previous_page",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "start_cursor",
                storageKey: null
            }],
            storageKey: null
        };
        x = {
            kind: "ClientExtension",
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "ufi2_connection_generation",
                storageKey: null
            }]
        };
        z = ["feedback_source", "focus_comment_id", "comment_order"];
        r = {
            kind: "Variable",
            name: "__dynamicKey",
            variableName: "UFI2CommentsProvider_commentsKey"
        };
        C = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "comment_share_context",
            plural: !1,
            selections: [d, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "tooltip_nux_text",
                storageKey: null
            }],
            storageKey: null
        };
        Y = {
            alias: null,
            args: null,
            concreteType: "Group",
            kind: "LinkedField",
            name: "associated_group",
            plural: !1,
            selections: n,
            storageKey: null
        };
        Z = {
            alias: null,
            args: null,
            concreteType: "PoliticalFigureData",
            kind: "LinkedField",
            name: "political_figure_data",
            plural: !1,
            selections: [e, {
                alias: null,
                args: null,
                concreteType: "PoliticalOffice",
                kind: "LinkedField",
                name: "political_office",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "generic_title",
                    storageKey: null
                }, c],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "best_profile",
                plural: !1,
                selections: Ia,
                storageKey: null
            }, c],
            storageKey: null
        };
        $ = [Pa, Z];
        Tb = {
            condition: "containerIsFeedStory",
            kind: "Condition",
            passingValue: !0,
            selections: $
        };
        g = {
            condition: "containerIsLiveStory",
            kind: "Condition",
            passingValue: !0,
            selections: $
        };
        L = {
            condition: "containerIsTahoe",
            kind: "Condition",
            passingValue: !0,
            selections: $
        };
        R = [Mb, Y, Tb, g, L];
        q = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "can_viewer_comment_with_marker",
            storageKey: null
        };
        n = [Z];
        $ = [Y, Z];
        return {
            fragment: {
                argumentDefinitions: [a, aa, ba, ca, da, ea, fa, ga, ha, ia, ja, ka, la, ma, na, oa, pa, qa],
                kind: "Fragment",
                metadata: null,
                name: "SnowliftUFIRootQuery",
                selections: [{
                    alias: null,
                    args: ra,
                    concreteType: "Feedback",
                    kind: "LinkedField",
                    name: "feedback",
                    plural: !1,
                    selections: [{
                        args: null,
                        kind: "FragmentSpread",
                        name: "SnowliftUFIRenderer_feedback"
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: sa,
                    concreteType: "ShareableConfig",
                    kind: "LinkedField",
                    name: "shareable_config",
                    plural: !1,
                    selections: [{
                        args: null,
                        kind: "FragmentSpread",
                        name: "SnowliftUFIRenderer_shareableConfig"
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [ia, ea, fa, ga, ha, ja, ka, la, ma, oa, aa, da, ba, ca, na, pa, qa, a],
                kind: "Operation",
                name: "SnowliftUFIRootQuery",
                selections: [{
                    alias: null,
                    args: ra,
                    concreteType: "Feedback",
                    kind: "LinkedField",
                    name: "feedback",
                    plural: !1,
                    selections: [ta, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_viewer_see_ufi",
                        storageKey: null
                    }, ua, va, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_see_voice_switcher",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "have_comments_been_disabled",
                        storageKey: null
                    }, c, {
                        alias: null,
                        args: [{
                            kind: "Variable",
                            name: "feedback_source_integer",
                            variableName: "feedbackSource"
                        }],
                        kind: "ScalarField",
                        name: "is_eligible_for_real_time_updates",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_viewer_muted",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "mentions_datasource_js_constructor_args_json",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "num_localized_comment_orderings",
                        storageKey: null
                    }, wa, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "supports_disabling_comments",
                        storageKey: null
                    }, {
                        alias: null,
                        args: b,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "viewer_actor",
                        plural: !1,
                        selections: [d, c, xa, e, ya, za, Ba, Ea, Fa, Ga, {
                            kind: "InlineFragment",
                            selections: [Da, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "uri_token",
                                storageKey: null
                            }],
                            type: "Page",
                            abstractKey: null
                        }, {
                            kind: "InlineFragment",
                            selections: [Da, {
                                alias: null,
                                args: null,
                                concreteType: "Avatar",
                                kind: "LinkedField",
                                name: "user_avatar",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "has_fb_app_avatar",
                                    storageKey: null
                                }, c],
                                storageKey: null
                            }],
                            type: "User",
                            abstractKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_viewer_comment_with_gif",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_viewer_comment_with_photo",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_viewer_comment_with_video",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_viewer_comment_with_sticker",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_viewer_comment_with_stars",
                        storageKey: null
                    }, {
                        alias: "flat_threading_config",
                        args: [{
                            kind: "Literal",
                            name: "type",
                            value: "FLAT_THREADING"
                        }],
                        concreteType: null,
                        kind: "LinkedField",
                        name: "threading_config",
                        plural: !1,
                        selections: Ha,
                        storageKey: 'threading_config(type:"FLAT_THREADING")'
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "composer_tip",
                        storageKey: null
                    }, Ja, {
                        alias: "i18n_comment_count",
                        args: null,
                        kind: "ScalarField",
                        name: "comment_count_reduced",
                        storageKey: null
                    }, f, Ka, {
                        alias: null,
                        args: [{
                            kind: "Literal",
                            name: "first",
                            value: 2
                        }],
                        concreteType: "ImportantReactorsConnection",
                        kind: "LinkedField",
                        name: "important_reactors",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "nodes",
                            plural: !0,
                            selections: [d, e, c],
                            storageKey: null
                        }],
                        storageKey: "important_reactors(first:2)"
                    }, {
                        alias: "reaction_count",
                        args: null,
                        concreteType: "ReactorsOfContentConnection",
                        kind: "LinkedField",
                        name: "reactors",
                        plural: !1,
                        selections: m,
                        storageKey: null
                    }, {
                        alias: null,
                        args: La,
                        concreteType: "TopReactionsConnection",
                        kind: "LinkedField",
                        name: "top_reactions",
                        plural: !1,
                        selections: [l, {
                            alias: null,
                            args: null,
                            concreteType: "TopReactionsEdge",
                            kind: "LinkedField",
                            name: "edges",
                            plural: !0,
                            selections: [Ma, {
                                alias: null,
                                args: null,
                                concreteType: "FeedbackReactionInfo",
                                kind: "LinkedField",
                                name: "node",
                                plural: !1,
                                selections: [Na, c, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "localized_name",
                                    storageKey: null
                                }, Oa],
                                storageKey: null
                            }, Ka],
                            storageKey: null
                        }],
                        storageKey: 'top_reactions(orderby:["COUNT_DESC","REACTION_TYPE"])'
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "ReactionDisplayConfig",
                        kind: "LinkedField",
                        name: "reaction_display_config",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "reaction_display_strategy",
                            storageKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: null,
                        args: b,
                        concreteType: "FeedbackReactionInfo",
                        kind: "LinkedField",
                        name: "viewer_feedback_reaction_info",
                        plural: !1,
                        selections: [d, c, Na],
                        storageKey: null
                    }, Pa, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "can_show_seen_by",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "SeenByConnection",
                        kind: "LinkedField",
                        name: "seen_by",
                        plural: !1,
                        selections: [l, {
                            alias: "i18n_seen_by_count",
                            args: null,
                            kind: "ScalarField",
                            name: "seen_by_count_reduced",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "seen_by_everyone",
                            storageKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: "i18n_share_count",
                        args: null,
                        kind: "ScalarField",
                        name: "share_count_reduced",
                        storageKey: null
                    }, {
                        alias: "share_count",
                        args: null,
                        concreteType: "ResharesOfContentConnection",
                        kind: "LinkedField",
                        name: "reshares",
                        plural: !1,
                        selections: m,
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "ReactorsOfContentConnection",
                        kind: "LinkedField",
                        name: "reactors",
                        plural: !1,
                        selections: [l, Qa],
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "Video",
                        kind: "LinkedField",
                        name: "associated_video",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "is_live_streaming",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "is_profile_video",
                            storageKey: null
                        }, c],
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "video_view_count",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "video_view_count_reduced",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "total_video_posts",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "video_post_view_count",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "PrivateReplyContext",
                        kind: "LinkedField",
                        name: "page_private_reply",
                        plural: !1,
                        selections: [Ra, Sa, Ta, Ua, Va, Wa],
                        storageKey: null
                    }, {
                        alias: "seen_by_count",
                        args: null,
                        concreteType: "SeenByConnection",
                        kind: "LinkedField",
                        name: "seen_by",
                        plural: !1,
                        selections: m,
                        storageKey: null
                    }, {
                        alias: "account_actor",
                        args: [{
                            kind: "Literal",
                            name: "use_default_actor",
                            value: !1
                        }],
                        concreteType: null,
                        kind: "LinkedField",
                        name: "viewer_actor",
                        plural: !1,
                        selections: Ia,
                        storageKey: "viewer_actor(use_default_actor:false)"
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "VoiceSwitcherActorsConnection",
                        kind: "LinkedField",
                        name: "voice_switcher_actors",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "nodes",
                            plural: !0,
                            selections: [d, c, e, {
                                alias: null,
                                args: [{
                                    kind: "Literal",
                                    name: "width",
                                    value: 30
                                }],
                                concreteType: "Image",
                                kind: "LinkedField",
                                name: "profile_picture",
                                plural: !1,
                                selections: j,
                                storageKey: "profile_picture(width:30)"
                            }],
                            storageKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: "display_comments_count",
                        args: null,
                        concreteType: "DisplayCommentsConnection",
                        kind: "LinkedField",
                        name: "display_comments",
                        plural: !1,
                        selections: m,
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "TextWithEntities",
                        kind: "LinkedField",
                        name: "comments_disabled_notice",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "EntityAtRange",
                            kind: "LinkedField",
                            name: "ranges",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "entity",
                                plural: !1,
                                selections: [d, {
                                    alias: null,
                                    args: Ca,
                                    kind: "ScalarField",
                                    name: "url",
                                    storageKey: 'url(site:"www")'
                                }, o],
                                storageKey: null
                            }, Xa, Ya],
                            storageKey: null
                        }, p],
                        storageKey: null
                    }, Za, $a, {
                        alias: null,
                        args: fb,
                        concreteType: "DisplayCommentsConnection",
                        kind: "LinkedField",
                        name: "display_comments",
                        plural: !1,
                        selections: [gb, hb, l, {
                            alias: null,
                            args: null,
                            concreteType: "DisplayCommentsEdge",
                            kind: "LinkedField",
                            name: "edges",
                            plural: !0,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "Comment",
                                kind: "LinkedField",
                                name: "node",
                                plural: !1,
                                selections: [ib, c, jb, u, kb, lb, mb, nb, ob, pb, qb, {
                                    alias: null,
                                    args: null,
                                    concreteType: "Feedback",
                                    kind: "LinkedField",
                                    name: "feedback",
                                    plural: !1,
                                    selections: [c, rb, sb, tb, ub, {
                                        alias: null,
                                        args: b,
                                        concreteType: null,
                                        kind: "LinkedField",
                                        name: "viewer_actor",
                                        plural: !1,
                                        selections: [d, c, xa, e, ya, za, Ba, Ea, Fa, Ga, {
                                            kind: "InlineFragment",
                                            selections: k,
                                            type: "Page",
                                            abstractKey: null
                                        }, {
                                            kind: "InlineFragment",
                                            selections: k,
                                            type: "User",
                                            abstractKey: null
                                        }],
                                        storageKey: null
                                    }, vb, wb, Za, ua, ta, $a, wa, {
                                        alias: null,
                                        args: ab,
                                        concreteType: "DisplayCommentsConnection",
                                        kind: "LinkedField",
                                        name: "display_comments",
                                        plural: !1,
                                        selections: [gb, hb, l, {
                                            alias: null,
                                            args: null,
                                            concreteType: "DisplayCommentsEdge",
                                            kind: "LinkedField",
                                            name: "edges",
                                            plural: !0,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                concreteType: "Comment",
                                                kind: "LinkedField",
                                                name: "node",
                                                plural: !1,
                                                selections: [ib, c, jb, u, kb, lb, mb, nb, ob, pb, qb, {
                                                    alias: null,
                                                    args: null,
                                                    concreteType: "Feedback",
                                                    kind: "LinkedField",
                                                    name: "feedback",
                                                    plural: !1,
                                                    selections: [c, rb, sb, tb, ub, {
                                                        alias: null,
                                                        args: b,
                                                        concreteType: null,
                                                        kind: "LinkedField",
                                                        name: "viewer_actor",
                                                        plural: !1,
                                                        selections: Ia,
                                                        storageKey: null
                                                    }, vb, wb, Za],
                                                    storageKey: null
                                                }, bb, db, eb, xb, yb, s, zb, Ab, Cb, Db, Eb, d, Fb, {
                                                    condition: "containerIsFeedStory",
                                                    kind: "Condition",
                                                    passingValue: !0,
                                                    selections: [h, F, G, i, Hb, Ib, Jb, Kb, H, Lb, I, {
                                                        alias: null,
                                                        args: null,
                                                        concreteType: "Feedback",
                                                        kind: "LinkedField",
                                                        name: "feedback",
                                                        plural: !1,
                                                        selections: [v, Mb, Nb, Ob, va, Pb, wa],
                                                        storageKey: null
                                                    }, J, Qb, Rb, M, N, f, Sb, V, W, X, t, Ub]
                                                }, {
                                                    condition: "containerIsLiveStory",
                                                    kind: "Condition",
                                                    passingValue: !0,
                                                    selections: [h, F, G, H, Wb, I, Xb, J, K, M, N, f, Yb, Zb, $b, V, W, X, Ub]
                                                }, {
                                                    condition: "containerIsTahoe",
                                                    kind: "Condition",
                                                    passingValue: !0,
                                                    selections: [h, F, G, H, Vb, I, Xb, J, K, M, N, f, Yb, Zb, O, V, W, X, Ub]
                                                }, Q, S, T],
                                                storageKey: null
                                            }, U],
                                            storageKey: null
                                        }, {
                                            alias: null,
                                            args: null,
                                            concreteType: "Comment",
                                            kind: "LinkedField",
                                            name: "highlighted_comments",
                                            plural: !0,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                concreteType: null,
                                                kind: "LinkedField",
                                                name: "author",
                                                plural: !1,
                                                selections: [d, e, {
                                                    alias: null,
                                                    args: Aa,
                                                    concreteType: "Image",
                                                    kind: "LinkedField",
                                                    name: "profile_picture",
                                                    plural: !1,
                                                    selections: j,
                                                    storageKey: null
                                                }, {
                                                    kind: "InlineFragment",
                                                    selections: [{
                                                        alias: null,
                                                        args: null,
                                                        kind: "ScalarField",
                                                        name: "gender",
                                                        storageKey: null
                                                    }],
                                                    type: "User",
                                                    abstractKey: null
                                                }, c],
                                                storageKey: null
                                            }, ib, c],
                                            storageKey: null
                                        }, Gb, A, D, B, w, y, x],
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: ab,
                                        filters: z,
                                        handle: "ufi2_comments",
                                        key: "UFI2CommentsProvider_feedback_display_comments",
                                        kind: "LinkedHandle",
                                        name: "display_comments",
                                        dynamicKey: r
                                    }, {
                                        condition: "containerIsFeedStory",
                                        kind: "Condition",
                                        passingValue: !0,
                                        selections: [C, Y, Tb, g, L]
                                    }, {
                                        condition: "containerIsLiveStory",
                                        kind: "Condition",
                                        passingValue: !0,
                                        selections: R
                                    }, {
                                        condition: "containerIsWorkplace",
                                        kind: "Condition",
                                        passingValue: !0,
                                        selections: [q, Y, Tb, g, L]
                                    }, {
                                        condition: "containerIsTahoe",
                                        kind: "Condition",
                                        passingValue: !0,
                                        selections: R
                                    }],
                                    storageKey: null
                                }, bb, db, eb, xb, yb, s, zb, Ab, Cb, Db, Eb, d, Fb, {
                                    condition: "containerIsFeedStory",
                                    kind: "Condition",
                                    passingValue: !0,
                                    selections: [h, F, G, i, Hb, Ib, Jb, Kb, H, Lb, I, {
                                        alias: null,
                                        args: null,
                                        concreteType: "Feedback",
                                        kind: "LinkedField",
                                        name: "feedback",
                                        plural: !1,
                                        selections: [v, Mb, Nb, Ob, va, Pb],
                                        storageKey: null
                                    }, J, Qb, Rb, M, N, f, Sb, V, W, X, t, Ub]
                                }, {
                                    condition: "containerIsLiveStory",
                                    kind: "Condition",
                                    passingValue: !0,
                                    selections: [h, F, G, H, Wb, I, P, J, K, M, N, f, Yb, Zb, $b, V, W, X, Ub]
                                }, {
                                    condition: "containerIsTahoe",
                                    kind: "Condition",
                                    passingValue: !0,
                                    selections: [h, F, G, H, Vb, I, P, J, K, M, N, f, Yb, Zb, O, V, W, X, Ub]
                                }, Q, S, T],
                                storageKey: null
                            }, U],
                            storageKey: null
                        }, Gb, A, D, B, w, y, x],
                        storageKey: null
                    }, {
                        alias: null,
                        args: fb,
                        filters: z,
                        handle: "ufi2_comments",
                        key: "UFI2CommentsProvider_feedback_display_comments",
                        kind: "LinkedHandle",
                        name: "display_comments",
                        dynamicKey: r
                    }, v, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "default_comment_ordering",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "CommentOrderOption",
                        kind: "LinkedField",
                        name: "localized_comment_orderings",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "description",
                            storageKey: null
                        }, Bb, cb],
                        storageKey: null
                    }, {
                        condition: "containerIsWorkplace",
                        kind: "Condition",
                        passingValue: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "can_viewer_comment_with_file",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "can_viewer_comment_with_bot_mention",
                            storageKey: null
                        }, q, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "is_comment_markdown_eligible",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "TextWithEntities",
                            kind: "LinkedField",
                            name: "people_outside_community_in_comment_notice",
                            plural: !1,
                            selections: E,
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "Group",
                            kind: "LinkedField",
                            name: "associated_group",
                            plural: !1,
                            selections: [c, {
                                alias: null,
                                args: null,
                                concreteType: "GroupMentionsSectionsInfo",
                                kind: "LinkedField",
                                name: "group_mentions_sections_info",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "member_title",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "member_aux",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "nonmember_title",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "nonmember_aux",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "bot_title",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "bot_aux",
                                    storageKey: null
                                }],
                                storageKey: null
                            }],
                            storageKey: null
                        }, {
                            condition: "containerIsFeedStory",
                            kind: "Condition",
                            passingValue: !0,
                            selections: n
                        }, {
                            condition: "containerIsLiveStory",
                            kind: "Condition",
                            passingValue: !0,
                            selections: n
                        }, {
                            condition: "containerIsTahoe",
                            kind: "Condition",
                            passingValue: !0,
                            selections: n
                        }]
                    }, {
                        kind: "ClientExtension",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "is_unseen",
                            storageKey: null
                        }]
                    }, {
                        condition: "containerIsFeedStory",
                        kind: "Condition",
                        passingValue: !0,
                        selections: [C, Y, Z]
                    }, {
                        condition: "containerIsLiveStory",
                        kind: "Condition",
                        passingValue: !0,
                        selections: $
                    }, {
                        condition: "containerIsTahoe",
                        kind: "Condition",
                        passingValue: !0,
                        selections: $
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: sa,
                    concreteType: "ShareableConfig",
                    kind: "LinkedField",
                    name: "shareable_config",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "intercept_for_page_post",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "misinformation_confirm_dialog_uri",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "reshare_warning_framework_dialog_uri",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "PrimerAttributes",
                        kind: "LinkedField",
                        name: "share_action_link_primer_attributes",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "rel",
                            storageKey: null
                        }],
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "share_action_link_uri",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "share_now_menu_uri",
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: "5592888664077058",
                metadata: {},
                name: "SnowliftUFIRootQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    aa("relay-runtime").PreloadableQueryRegistry.set(a.params.id, a);
    da.exports = a
}), null);
__d("SnowliftUFISummary_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "count",
            storageKey: null
        }];
        return {
            argumentDefinitions: [],
            kind: "Fragment",
            metadata: null,
            name: "SnowliftUFISummary_feedback",
            selections: [{
                args: null,
                kind: "FragmentSpread",
                name: "UFI2CommentsCount_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2ReactionsCount_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2SeenByCount_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2SharesCount_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2TopReactions_feedback"
            }, {
                args: null,
                kind: "FragmentSpread",
                name: "UFI2ViewCount_feedback"
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_show_seen_by",
                storageKey: null
            }, {
                alias: "comment_count",
                args: null,
                concreteType: "TopLevelCommentsConnection",
                kind: "LinkedField",
                name: "top_level_comments",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "total_count",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "PrivateReplyContext",
                kind: "LinkedField",
                name: "page_private_reply",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "status",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: "reaction_count",
                args: null,
                concreteType: "ReactorsOfContentConnection",
                kind: "LinkedField",
                name: "reactors",
                plural: !1,
                selections: a,
                storageKey: null
            }, {
                alias: "seen_by_count",
                args: null,
                concreteType: "SeenByConnection",
                kind: "LinkedField",
                name: "seen_by",
                plural: !1,
                selections: a,
                storageKey: null
            }, {
                alias: "share_count",
                args: null,
                concreteType: "ResharesOfContentConnection",
                kind: "LinkedField",
                name: "reshares",
                plural: !1,
                selections: a,
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "video_view_count",
                storageKey: null
            }, {
                kind: "ClientExtension",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_unseen",
                    storageKey: null
                }]
            }],
            type: "Feedback",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("UFI2ReactionsCount_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            b = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            c = [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "count",
                storageKey: null
            }],
            d = [{
                kind: "Variable",
                name: "use_default_actor",
                variableName: "useDefaultActor"
            }];
        return {
            argumentDefinitions: [{
                kind: "RootArgument",
                name: "useDefaultActor"
            }],
            kind: "Fragment",
            metadata: null,
            name: "UFI2ReactionsCount_feedback",
            selections: [a, {
                alias: "i18n_reaction_count",
                args: null,
                kind: "ScalarField",
                name: "reaction_count_reduced",
                storageKey: null
            }, {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "first",
                    value: 2
                }],
                concreteType: "ImportantReactorsConnection",
                kind: "LinkedField",
                name: "important_reactors",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "nodes",
                    plural: !0,
                    selections: [b],
                    storageKey: null
                }],
                storageKey: "important_reactors(first:2)"
            }, {
                alias: "reaction_count",
                args: null,
                concreteType: "ReactorsOfContentConnection",
                kind: "LinkedField",
                name: "reactors",
                plural: !1,
                selections: c,
                storageKey: null
            }, {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "orderby",
                    value: ["COUNT_DESC", "REACTION_TYPE"]
                }],
                concreteType: "TopReactionsConnection",
                kind: "LinkedField",
                name: "top_reactions",
                plural: !1,
                selections: c,
                storageKey: 'top_reactions(orderby:["COUNT_DESC","REACTION_TYPE"])'
            }, {
                alias: null,
                args: null,
                concreteType: "ReactionDisplayConfig",
                kind: "LinkedField",
                name: "reaction_display_config",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "reaction_display_strategy",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: d,
                concreteType: null,
                kind: "LinkedField",
                name: "viewer_actor",
                plural: !1,
                selections: [a, b],
                storageKey: null
            }, {
                alias: null,
                args: d,
                concreteType: "FeedbackReactionInfo",
                kind: "LinkedField",
                name: "viewer_feedback_reaction_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "__typename",
                    storageKey: null
                }],
                storageKey: null
            }],
            type: "Feedback",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("PhotoEverstoreLogger", ["AsyncRequest", "Event", "ImageUtils"], (function(a, b, c, d, e, f) {
    var g = {
        BATCH_WINDOW_MS: 500,
        storedLog: []
    };

    function h() {}
    Object.assign(h, {
        _log: function(a) {
            g.storedLog.push(a), g.storedLog.length == 1 && setTimeout(i, g.BATCH_WINDOW_MS)
        },
        logImmediately: function(a) {
            h._log(a)
        },
        registerForLogging: function(a) {
            var c = document.getElementById(a);
            c != null && (b("ImageUtils").hasLoaded(c) ? h._log(c.src) : b("Event").listen(c, "load", function(a) {
                h._log(c.src)
            }))
        }
    });

    function i() {
        var a = g.storedLog;
        g.storedLog = [];
        a = JSON.stringify(a);
        new(b("AsyncRequest"))().setURI("/ajax/photos/logging/everstore_logging.php").setData({
            loggedUrls: a
        }).setMethod("POST").setOption("suppressErrorHandlerWarning", !0).setOption("suppressErrorAlerts", !0).send()
    }
    e.exports = h
}), null);
__d("PhotoViewerImage", ["PhotoEverstoreLogger", "URI", "Vector"], (function(a, b, c, d, e, f) {
    var g;
    a = function() {
        "use strict";

        function a(a) {
            this._hiResDimensions = a.hiResDimensions && b("Vector").deserialize(a.hiResDimensions), this._normalDimensions = a.normalDimensions && b("Vector").deserialize(a.normalDimensions), this._info = a.info, this._video = a.video, this._shouldLog = a.everstoreLogThis, this._hiResSrc = a.hiResSrc, this._normalSrc = a.normalSrc, this._thumbSrc = a.thumbSrc, this._isInverted = !1, this._data = a
        }
        var c = a.prototype;
        c.getURIString = function() {
            return new(g || (g = b("URI")))(this._info.permalink).getUnqualifiedURI().toString()
        };
        c.hasHiResDimensions = function() {
            return !!this._hiResDimensions
        };
        c.getHiResDimensions = function() {
            return this._hiResDimensions
        };
        c.getNormalDimensions = function() {
            return this._normalDimensions
        };
        c.getHiResSrc = function() {
            return this._hiResSrc
        };
        c.getNormalSrc = function() {
            return this._normalSrc
        };
        c.getThumbSrc = function() {
            return this._thumbSrc
        };
        c.getInfo = function() {
            return this._info
        };
        c.getPermalink = function() {
            return this._info.permalink
        };
        c.getHighestResSrc = function() {
            return this._hiResSrc || this._normalSrc
        };
        c.preload = function(a) {
            var c;
            this.getHighestResSrc() && (a && !this._resource ? (this._resource = new Image(), this._resource.src = this.getHighestResSrc(), c = this._resource.src, this._shouldLog && b("PhotoEverstoreLogger").logImmediately(this._resource.src)) : !a && !this._small && (this._small = new Image(), this._small.src = this._normalSrc || this._hiResSrc, c = this._small.src, this._shouldLog && b("PhotoEverstoreLogger").logImmediately(this._small.src)));
            return c
        };
        c.setNormalDimensions = function(a, c) {
            this._normalDimensions = new(b("Vector"))(a, c)
        };
        c.setHiResDimensions = function(a, c) {
            this._hiResDimensions = new(b("Vector"))(a, c)
        };
        c.invertDimensions = function() {
            this.hasHiResDimensions() && (this._hiResDimensions = new(b("Vector"))(this._hiResDimensions.y, this._hiResDimensions.x)), this._normalDimensions = new(b("Vector"))(this._normalDimensions.y, this._normalDimensions.x), this._isInverted = !this._isInverted
        };
        c.copy = function() {
            return new a(this._data)
        };
        return a
    }();
    e.exports = a
}), null);
__d("PhotosConst", [], (function(a, b, c, d, e, f) {
    a = {
        VIEWER_PERMALINK: 0,
        VIEWER_SNOWLIFT: 6,
        VIEWER_VAULTBOX: 8,
        VIEWER_SNOWFLAKE: 14,
        VIEWER_COMPOSER: 16,
        VIEWER_CAROUSEL: 19,
        VIEWER_SPHERICAL: 20,
        VIEWER_PERMALINK_STRING: "permalink",
        VIEWER_SNOWLIFT_STRING: "snowlift",
        VIEWER_VAULTBOX_STRING: "vaultbox",
        VIEWER_CAROUSEL_STRING: "carousel",
        BULK_EDITOR: 3,
        BULK_EDITOR_REACT: 15,
        EDITOR_MODAL: 17,
        FLASH_UPLOADER: 4,
        HTML5_UPLOADER: 10,
        SIZE_NORMAL: "n",
        PIC_NORMAL_FBX_SIZE: 180,
        ALBUM_NAME_MAXLEN: 65
    };
    e.exports = a
}), null);
__d("UFI2DOMAttachmentEventEmitter", ["EventEmitter"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        return b
    }(b("EventEmitter"))
}), null);
__d("PhotoStreamCache", ["DOM", "HTML", "PhotoEverstoreLogger", "PhotoViewerImage", "PhotosConst", "ReactDOM", "ReactRenderer", "Rect", "UFI2DOMAttachmentEventEmitter", "UIPagelet", "URI", "Vector", "ge", "react"], (function(a, b, c, d, e, f) {
    var g, h, i = g || b("react");
    a = function() {
        "use strict";

        function a() {}
        var c = a.prototype;
        c.init = function(b, c, d, e, f) {
            this.version = b, this.pageletName = c, this.pageletRootID = d, this.tagSuggestionMode = f, this.bufferSize = a.BUFFER_SIZE, this.fullBucketSize = a.FULL_BUCKET_SIZE, this.initError = !1, this.isActive = !0, this.usesOpaqueCursor = !1, this.usesNonCircularPhotoSet = !1, this.reachedLeftEnd = !1, this.reachedRightEnd = !1, this.leftLock = !1, this.rightLock = !1, this.useAjaxPipe = !0, this.logger = e, this.viewAsUser = null, this.reset()
        };
        c.setViewAs = function(a) {
            this.viewAsUser = a
        };
        c.isInViewAsMode = function() {
            return !!this.viewAsUser
        };
        c.getViewAsUserId = function() {
            return this.viewAsUser
        };
        c.getUsesOpaqueCursor = function() {
            return this.usesOpaqueCursor
        };
        c.isNonCircularPhotoSet = function() {
            return this.usesNonCircularPhotoSet
        };
        c.setReachedLeftEnd = function() {
            this.reachedLeftEnd = !0
        };
        c.setReachedRightEnd = function() {
            this.reachedRightEnd = !0
        };
        c.hasReachedLeftEnd = function() {
            return this.reachedLeftEnd
        };
        c.hasReachedRightEnd = function() {
            return this.reachedRightEnd
        };
        c.nonCircularPhotoSetCanPage = function(a) {
            if (!this.isNonCircularPhotoSet()) return !0;
            if (a < 0) return this.getCursorPos() || !this.hasReachedLeftEnd();
            return a > 0 ? this.getLength() - 1 != this.getCursorPos() || !this.hasReachedRightEnd() : !0
        };
        c.setUseAjaxPipe = function(a) {
            this.useAjaxPipe = a
        };
        c.reset = function() {
            this.cache = {
                image: {},
                extra: {},
                html: {},
                ufi_config: {},
                ufi_dom_attachment_event_emitters: {},
                ufi_roots: {}
            }, this.snowliftUFIModule = null, this.fbidList = [], this.loaded = !1, this.allLoaded = !1, this.permalinkMap = {}, this.position = 0, this.totalCount = null, this.firstCursor = null, this.firstCursorIndex = null, this.firstOpaqueCursor = null
        };
        c.waitForInitData = function() {
            this.fbidList.push(a.INIT_PLACEHOLDER)
        };
        c.unmountUFIRoots = function() {
            Object.entries(this.cache.ufi_roots).forEach(function(a) {
                a[0];
                a = a[1];
                return a.ufiMainRoot && b("ReactDOM").unmountComponentAtNode(a.ufiMainRoot)
            })
        };
        c.destroy = function() {
            this.unmountUFIRoots(), this.reset(), this.isActive = !1
        };
        c.isLoaded = function() {
            return this.loaded
        };
        c.canPage = function() {
            if (!this.isLoaded()) return !1;
            if (this.totalCount !== null) return this.totalCount > 1;
            return this.usesNonCircularPhotoSet ? !0 : this.getLength() > 1
        };
        c.errorInCurrent = function() {
            if (this.initError) return !0;
            else if (!this.isLoaded()) return !1;
            return this.checkErrorAt(this.getCursor())
        };
        c.getLength = function() {
            return this.fbidList.length
        };
        c.getPhotoSet = function() {
            return this.photoSetQuery.set
        };
        c.getPhotoSetQuery = function() {
            return this.photoSetQuery
        };
        c.getCurrentImageData = function() {
            return this.getImageData(this.getCursor())
        };
        c.getNextImageData = function() {
            if (!this.fbidList || !this.fbidList.length) return null;
            var a = (this.position + 1) % this.fbidList.length;
            return this.getImageData(this.getCursorAt(a))
        };
        c.getPreviousImageData = function() {
            if (!this.fbidList || !this.fbidList.length) return null;
            var a = this.fbidList.length;
            a = (this.position + a - 1) % a;
            return this.getImageData(this.getCursorAt(a))
        };
        c.addViewAsToURI = function(a) {
            a = new(h || (h = b("URI")))(a);
            this.isInViewAsMode() && a.addQueryData({
                viewas: this.getViewAsUserId()
            });
            return a
        };
        c.getOpaqueCursor = function(a) {
            if (this.getImageData(a)) return this.version === b("PhotosConst").VIEWER_VAULTBOX ? this.getImageData(a).getInfo().opaquecursor : this.getImageData(a).info.opaquecursor;
            return a == this.firstCursor ? this.firstOpaqueCursor : null
        };
        c.getImageData = function(b) {
            b = this.getCacheContent(b, a.IMAGE_DATA);
            b && (b.info.permalink = this.addViewAsToURI(b.info.permalink));
            return b
        };
        c.getCurrentHtml = function() {
            return this.getCacheContent(this.getCursor(), a.HTML)
        };
        c.getCurrentExtraData = function() {
            return this.getCacheContent(this.getCursor(), a.EXTRA)
        };
        c.getCurrentUFIConfig = function() {
            return this.getCacheContent(this.getCursor(), a.UFI_CONFIG)
        };
        c.getCurrentUFIRoots = function(b) {
            var c = this.getCacheContent(this.getCursor(), a.UFI_ROOTS),
                d = this.getCacheContent(this.getCursor(), a.UFI_DOM_ATTACHMENT_EVENT_EMITTERS);
            if (c) {
                b(c, d);
                return
            }
            this.createUFIRoots(this.getCursor(), function(a, c) {
                b(a, c)
            })
        };
        c.containsUFIConfig = function() {
            return Object.keys(this.cache.ufi_config).length > 0
        };
        c.getCacheContent = function(b, c) {
            return !b || b === a.ERROR_ID || b === a.INIT_PLACEHOLDER ? null : this.cache[c][b]
        };
        c.getCursorPos = function() {
            return this.position
        };
        c.getCursor = function() {
            return this.position >= 0 && this.position < this.getLength() ? this.fbidList[this.position] : null
        };
        c.getCursorAt = function(a) {
            return this.fbidList[a]
        };
        c.getCursorForURI = function(a) {
            return this.permalinkMap[a]
        };
        c.calculatePositionForMovement = function(a) {
            a = this.position + a;
            if (this.allLoaded) {
                var b = this.getLength();
                a = (b + a % b) % b
            }
            return a
        };
        c.isValidMovement = function(a) {
            if (!this.isLoaded() || !this.canPage()) return !1;
            a = this.calculatePositionForMovement(a);
            return this.getCursor() > 0 || a >= 0 && a < this.getLength()
        };
        c.moveCursor = function(a) {
            if (!this.isValidMovement(a)) return;
            this.position = this.calculatePositionForMovement(a);
            a !== 0 && this.loadMoreIfNeccessary(a > 0)
        };
        c.checkErrorAt = function(b) {
            if (!this.isLoaded()) return !1;
            return b === a.ERROR_ID ? !0 : !1
        };
        c.getRelativeMovement = function(a) {
            for (var b = 0; b < this.getLength(); b++)
                if (this.fbidList[b] == a) return b - this.position;
            return null
        };
        c.preloadImages = function(c) {
            var d, e = this.getLength(),
                f = this.cache.image,
                g = a.BUFFER_SIZE;
            e > g * 2 ? (d = (this.position + e - g % e) % e, g = (this.position + g) % e) : (d = 0, g = e - 1);
            while (d != g) {
                var h, i = this.fbidList[d],
                    j = c && c(f[i]);
                this.version === b("PhotosConst").VIEWER_VAULTBOX ? h = f[i] && f[i].preload(j) : f[i] && f[i].url && (j && !f[i].resource ? (f[i].resource = new Image(), f[i].resource.src = f[i].url, h = f[i].url, f[i].everstoreLogThis === !0 && b("PhotoEverstoreLogger").logImmediately(f[i].resource.src)) : !j && !f[i].small && (f[i].small = new Image(), f[i].small.src = f[i].smallurl || f[i].url, h = f[i].small.src, f[i].everstoreLogThis === !0 && b("PhotoEverstoreLogger").logImmediately(f[i].small.src)));
                this.logger && h && this.logger.log(h);
                d = (d + 1) % e
            }
        };
        c.loadMoreIfNeccessary = function(a) {
            if (this.allLoaded || a && this.rightLock || !a && this.leftLock) return;
            a = a ? 1 : -1;
            a = this.position + this.bufferSize * a;
            a < 0 && !this.checkErrorAt(this.getEndCursor(!1)) ? (this.leftLock = !0, this.fetch(this.fullBucketSize, !1)) : a > this.getLength() && !this.checkErrorAt(this.getEndCursor(!0)) && (this.rightLock = !0, this.fetch(this.fullBucketSize, !0))
        };
        c.getEndCursor = function(a) {
            return a ? this.fbidList[this.getLength() - 1] : this.fbidList[0]
        };
        c.calculateRelativeIndex = function(a, b, c) {
            if (!this.totalCount) return null;
            b = this.fbidList.indexOf(b);
            c = this.fbidList.indexOf(c);
            if (b === -1 || c === -1) return null;
            c = c - b;
            return (a + c + this.totalCount) % this.totalCount
        };
        c.calculateDistance = function(a, b) {
            a = this.fbidList.indexOf(a);
            b = this.fbidList.indexOf(b);
            return a === -1 || b === -1 ? null : (b - a + this.getLength()) % this.getLength()
        };
        c.fetch = function(a, c) {
            var d = this.getEndCursor(c);
            c = babelHelpers["extends"]({
                cursor: d,
                version: this.version,
                end: this.getEndCursor(!c),
                fetchSize: c ? a : -1 * a,
                relevant_count: this.relevantCount,
                opaqueCursor: this.getOpaqueCursor(d),
                tagSuggestionMode: this.tagSuggestionMode,
                is_from_groups: this.isFromGroups
            }, this.photoSetQuery);
            this.isInViewAsMode() && (c.viewas = this.getViewAsUserId());
            this.totalCount && this.firstCursorIndex !== null && (c.total = this.totalCount, c.cursorIndex = this.calculateRelativeIndex(this.firstCursorIndex, this.firstCursor, d));
            a = b("ge")(this.pageletRootID);
            a || (a = b("DOM").create("div", {
                id: this.pageletRootID
            }), b("DOM").appendContent(document.body, a));
            b("UIPagelet").loadFromEndpoint(this.pageletName, a, c, {
                usePipe: this.useAjaxPipe,
                automatic: !0,
                jsNonblock: !0,
                crossPage: !0
            });
            this.useAjaxPipe || this.setUseAjaxPipe(!0)
        };
        c.storeToCache = function(a) {
            var b = {};
            if (!this.isActive) return b;
            if ("error" in a) {
                this.processErrorResult(a.error);
                b.error = !0;
                return b
            }
            "init" in a && (this.processInitResult(a.init), b.init = {
                logids: a.init.logids,
                fbid: a.init.fbid,
                loggedin: a.init.loggedin,
                fromad: a.init.fromad,
                withinbusiness: a.init.withinbusiness,
                eid: a.init.eid
            });
            "image" in a && (this.processImageResult(a.image), b.image = !0);
            "data" in a && (this.processDataResult(a.data), b.data = !0);
            return b
        };
        c.processInitResult = function(c) {
            if (this.loaded) return;
            this.usesOpaqueCursor = c.usesopaquecursor;
            this.usesNonCircularPhotoSet = c.isnoncircularphotoset;
            this.setIsFromGroups(c.is_from_groups);
            this.loaded = !0;
            this.photoSetQuery = c.query;
            c.bufferSize && (this.bufferSize = c.bufferSize);
            c.fullBucketSize && (this.fullBucketSize = c.fullBucketSize);
            if (this.fbidList.length === 0) this.fbidList.push(c.fbid), this.rightLock = !0;
            else {
                var d = this.fbidList.indexOf(a.INIT_PLACEHOLDER);
                d != -1 && (this.fbidList[d] = c.fbid)
            }
            this.firstCursor = c.fbid;
            this.firstOpaqueCursor = c.opaquecursor;
            "initIndex" in c && "totalCount" in c && (this.firstCursorIndex = c.initIndex, this.totalCount = c.totalCount);
            if (this.version == b("PhotosConst").VIEWER_PERMALINK) {
                d = c.initialBucketSize ? c.initialBucketSize : a.INIT_BUCKET_SIZE;
                this.fetch(d, !0)
            }
        };
        c.processImageResult = function(a) {
            for (var c in a) {
                c === this.firstCursor && a[c].everstoreLogThis && b("PhotoEverstoreLogger").logImmediately(a[c].url);
                if (this.version === b("PhotosConst").VIEWER_VAULTBOX) {
                    var d = a[c];
                    this.cache.image[c] = new(b("PhotoViewerImage"))(d);
                    this.permalinkMap[this.cache.image[c].getURIString()] = c
                } else this.cache.image[c] = a[c], a[c].dimensions && (this.cache.image[c].dimensions = b("Vector").deserialize(a[c].dimensions)), a[c].originalDimensions && (this.cache.image[c].originalDimensions = b("Vector").deserialize(a[c].originalDimensions)), a[c].smalldims && (this.cache.image[c].smalldims = b("Vector").deserialize(a[c].smalldims)), this.permalinkMap[new(h || (h = b("URI")))(a[c].info.permalink).getUnqualifiedURI().toString()] = c
            }
        };
        c.attachToFbidsList = function(a, b, c) {
            var d = this;
            if (this.allLoaded) return;
            a = a.filter(function(a) {
                return !d.fbidList.includes(a)
            });
            if (b === -1) {
                for (var b = a.length - 1; b >= 0; b--) this.fbidList.unshift(a[b]), this.position++;
                this.leftLock = !1
            } else {
                for (var b = 0; b < a.length; b++) this.fbidList.push(a[b]);
                this.rightLock = !1
            }
            c && this.setAllLoaded()
        };
        c.setAllLoaded = function() {
            this.allLoaded = !0, this.getCursor() === null && (this.position = this.calculatePositionForMovement(0))
        };
        c.processDataResult = function(a) {
            var c = this;
            for (var d in a) {
                this.cache.html[d] || (this.cache.html[d] = {});
                for (var e in a[d].html) {
                    var f = a[d].html[e];
                    typeof f === "string" && (f = b("HTML")(f).getRootNode());
                    f.childNodes ? this.cache.html[d][e] = Array.from(f.childNodes) : this.cache.html[d][e] = []
                }
                if ("ufi_config" in a[d]) {
                    this.cache.ufi_config[d] = a[d].ufi_config;
                    if ("snowlift_ufi_module" in a[d]) {
                        f = a[d].snowlift_ufi_module.module;
                        this.snowliftUFIModule = f
                    }
                }
                if (!("extra" in a[d])) {
                    this.cache.extra[d] = null;
                    continue
                }
                this.cache.extra[d] = {
                    tagRects: {}
                };
                if (!Array.isArray(a[d].extra.tagRects))
                    for (var e in a[d].extra.tagRects) a[d].extra.tagRects[e] && (this.cache.extra[d].tagRects[e] = b("Rect").deserialize(a[d].extra.tagRects[e]));
                Object.keys(a[d].extra).forEach(function(b) {
                    if (b == "tagRects") return;
                    c.cache.extra[d][b] = a[d].extra[b]
                })
            }
        };
        c.processErrorResult = function(b) {
            if (!this.isLoaded()) {
                this.initError = !0;
                return
            }
            b = b.side;
            var c = [a.ERROR_ID];
            this.attachToFbidsList(c, b)
        };
        c.setTotalCount = function(a) {
            this.totalCount = a
        };
        c.setFirstCursorIndex = function(a) {
            this.firstCursorIndex = a
        };
        c.setIsFromGroups = function(a) {
            this.isFromGroups = a
        };
        c.createUFIRoots = function(a, c) {
            var d = {
                    ufiMainRoot: b("DOM").create("div"),
                    ufiComposerRoot: b("DOM").create("div"),
                    ufiStageActionsRoot: b("DOM").create("div")
                },
                e = this.snowliftUFIModule;
            if (!e) {
                this.cache.ufi_roots[a] = d;
                c(d);
                return
            }
            var f = this.getCurrentUFIConfig();
            if (Object.keys(f).length === 0) {
                this.cache.ufi_roots[a] = d;
                c(d);
                return
            }
            var g = f.preloader;
            f = f.props;
            f.composerPortalNode = d.ufiComposerRoot;
            f.stageActionsPortalNode = d.ufiStageActionsRoot;
            var h = f.domAttachmentEventEmitter = new(b("UFI2DOMAttachmentEventEmitter"))();
            this.cache.ufi_dom_attachment_event_emitters[a] = h;
            var j = g ? g.getContextProvider() : null;
            g && j ? b("ReactRenderer").renderComponent(i.jsx(j, {
                value: g,
                children: i.jsx(e, babelHelpers["extends"]({}, f))
            }), d.ufiMainRoot) : (f.usePreloadedQueryRenderer = !1, b("ReactRenderer").renderComponent(i.jsx(e, babelHelpers["extends"]({}, f)), d.ufiMainRoot));
            this.cache.ufi_roots[a] = d;
            c(d, h)
        };
        return a
    }();
    Object.assign(a, {
        ERROR: "error",
        HTML: "html",
        IMAGE_DATA: "image",
        EXTRA: "extra",
        UFI_CONFIG: "ufi_config",
        UFI_DOM_ATTACHMENT_EVENT_EMITTERS: "ufi_dom_attachment_event_emitters",
        UFI_ROOTS: "ufi_roots",
        BUFFER_SIZE: 3,
        INIT_BUCKET_SIZE: 4,
        FULL_BUCKET_SIZE: 12,
        ERROR_ID: -1,
        INIT_PLACEHOLDER: 1
    });
    e.exports = a
}), null);
__d("XPhotosetSearchPivotController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/search-pivot/photoset/", {
        fbid: {
            type: "Int",
            required: !0
        },
        tags: {
            type: "IntToIntMap"
        }
    })
}), null);
__d("PhotosetSearchPivotData", ["AsyncRequest", "PhotoStreamCache", "Promise", "XPhotosetSearchPivotController"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = /^(perm:)?tag:(\d+)/,
        h = {};
    a = {
        fetch: function(a, c) {
            if (!(a in h)) {
                var d = b("XPhotosetSearchPivotController").getURIBuilder().setInt("fbid", a);
                if (c) {
                    var e = {};
                    c.fbidList.forEach(function(a) {
                        a = c.getCacheContent(a, b("PhotoStreamCache").EXTRA);
                        a && Object.keys(a.tagRects).forEach(function(a) {
                            if (g.test(a)) {
                                a = RegExp.$2;
                                a in e ? e[a]++ : e[a] = 1
                            }
                        })
                    });
                    d.setIntToIntMap("tags", e)
                }
                h[a] = new(b("Promise"))(function(a, c) {
                    new(b("AsyncRequest"))().setURI(d.getURI()).setHandler(function(b) {
                        a(b.getPayload())
                    }).setErrorHandler(c).setAllowCrossPageTransition(!0).send()
                })
            }
            return h[a]["catch"](function(b) {
                delete h[a];
                throw b
            })
        }
    };
    e.exports = a
}), null);
__d("ConstituentBadgeEventEmitter", ["EventEmitter"], (function(a, b, c, d, e, f, g) {
    a = new(c("EventEmitter"))();
    g["default"] = a
}), 98);
__d("UFIAsyncWrapper", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.Fragment;
    g["default"] = b
}), 98);
__d("UFIDispatcher", ["ReactDispatcher_DEPRECATED", "UFISharedDispatcher"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.dispatch = function(b) {
            a.prototype.dispatch.call(this, b), c("UFISharedDispatcher").dispatch(b)
        };
        return b
    }(c("ReactDispatcher_DEPRECATED"));
    g["default"] = a
}), 98);
__d("UFIAddCommentAction", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return {
            type: "add_comment_cancel",
            instanceID: a.instanceid,
            ftentidentifier: a.ftentidentifier
        }
    }

    function b(a, b, c) {
        return {
            type: "add_comment_change_content",
            instanceID: a.instanceid,
            ftentidentifier: a.ftentidentifier,
            text: b,
            replyFBID: c
        }
    }

    function c(a, b) {
        return {
            type: "add_comment_retry_submit",
            instanceID: a.instanceid,
            ftentidentifier: a.ftentidentifier,
            comment: b
        }
    }

    function d(a, b, c, d) {
        return {
            type: "add_comment_submit_edit",
            instanceID: a.instanceid,
            ftentidentifier: a.ftentidentifier,
            comment: b,
            commentData: c,
            target: d
        }
    }

    function e(a, b, c, d) {
        return {
            type: "add_comment_submit_new",
            instanceID: a.instanceid,
            ftentidentifier: a.ftentidentifier,
            comment: b,
            target: c,
            replyCommentID: d,
            timestamp: Date.now()
        }
    }
    f.cancel = a;
    f.changeContent = b;
    f.retrySubmit = c;
    f.submitEdit = d;
    f.submitNew = e
}), 66);
__d("UFINewCommentNotifier", ["Arbiter", "UFIFeedbackTargets", "UFIUserActions"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e, f, g, h) {
        c("UFIUserActions").addComment(b.ftentidentifier, e.visibleValue, e.encodedValue, {
            source: b.source,
            ufiinstanceid: b.instanceid,
            target: f,
            replyid: g,
            rootid: b.rootid,
            attachedphoto: e.attachedPhoto,
            attachedvideo: e.attachedVideo,
            attachedfile: e.attachedFile,
            attachedsticker: e.attachedSticker,
            feedcontext: b.feedcontext,
            timestamp: h,
            feedbackReferrer: b.feedbackReferrer,
            isMarkdown: e.isMarkdown,
            fluentContentToken: b.fluentContentToken,
            isActiveLivingRoom: b.isActiveLivingRoom,
            livingRoomID: b.livingRoomID,
            isLiveVOD: b.isLiveVOD,
            islivestreaming: b.islivestreaming,
            liveVideoQuickCommentQuality: e.liveVideoQuickCommentQuality,
            photoTextTagID: b.photoTextTagID,
            isPhotoTag: b.isPhotoTag,
            photoFBID: b.photoFBID,
            photoTagX: b.photoTagX,
            photoTagY: b.photoTagY,
            privacyValue: e.privacy_value,
            section: e.section,
            selectedInsightPoint: e.selectedInsightPoint,
            attachedshareurl: e.attachedShareURL,
            isBroadcasterUFI: b.isBroadcasterUFI,
            enableVODCommentTimestamps: b.enableVODCommentTimestamps,
            trackingID: e.trackingID,
            delightRanges: e.delightRanges
        }), d("UFIFeedbackTargets").getFeedbackTarget(b.ftentidentifier, function(d) {
            a && c("Arbiter").inform("ufi/comment", {
                ft_id: d.entidentifier,
                target: f,
                form: a,
                isinverted: d.isranked || b.islivestreaming || b.isActiveLivingRoom,
                isPhotoTag: b.isPhotoTag,
                photoTextTagID: b.photoTextTagID,
                photoTagX: b.photoTagX,
                photoTagY: b.photoTagY,
                commentString: e.visibleValue
            })
        })
    }
    g.onNewComment = a
}), 98);
__d("ClipboardPhotoUploader", ["ArbiterMixin", "AsyncRequest", "mixin"], (function(a, b, c, d, e, f) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(b, c) {
            var d;
            d = a.call(this) || this;
            d.uploadURIString = b;
            d.data = c;
            return d
        }
        var d = c.prototype;
        d.handlePaste = function(a) {
            var d = this;
            a = c.getImages(a);
            for (var e = 0; e < a.length; ++e) {
                var f = new FormData();
                f.append("pasted_file", a[e]);
                var g = new(b("AsyncRequest"))();
                g.setURI(this.uploadURIString).setData(this.data).setRawData(f).setHandler(function(a) {
                    d.inform("upload_success", a)
                }).setErrorHandler(function(a) {
                    d.inform("upload_error", a)
                }).setAbortHandler(function(a) {
                    d.inform("upload_error", a)
                });
                this.inform("upload_start");
                g.send();
                break
            }
        };
        c.getImages = function(a) {
            if (!a.clipboardData) return [];
            a = a.clipboardData.items;
            if (!a) return [];
            var b, c = [];
            for (var d = 0; d < a.length; ++d) {
                b = a[d];
                if (b.kind === "string") return [];
                b.kind === "file" && b.type.indexOf("image/") !== -1 && c.push(b.getAsFile());
                b.kind === "blob" && c.push(b.blob)
            }
            return c
        };
        return c
    }(b("mixin")(b("ArbiterMixin")));
    e.exports = a
}), null);
__d("MentionsInputUtils", [], (function(a, b, c, d, e, f) {
    a = {
        generateDataFromTextWithEntities: function(a) {
            var b = a.text,
                c = [];
            (a.ranges || []).forEach(function(a) {
                var d = a.entity;
                !d.external && !a.videoTimestamp && !a.sphericalViewport && !a.campaign && !/\D/.test(d.id) && c.push({
                    uid: d.id,
                    text: b.substr(a.offset, a.length),
                    offset: a.offset,
                    length: a.length,
                    weakreference: !!d.weakreference
                })
            });
            a = {
                value: b,
                mentions: c,
                delights: (a.ranges || []).filter(function(a) {
                    return a.campaign
                })
            };
            return a
        }
    };
    e.exports = a
}), null);
__d("UFIAttachMediaSection.react", ["cx", "fbt", "Bootloader", "Focus", "UFICommentFileInputAcceptValues", "XUIError.react", "prop-types", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = d = a.call.apply(a, [this].concat(f)) || this, d.state = {
                bootloaded: !1,
                hasUploadFailure: !1
            }, d.$1 = null, d.$2 = null, d.$3 = function() {
                d.setState({
                    hasUploadFailure: !1
                })
            }, d.$4 = function() {
                d.setState({
                    hasUploadFailure: !1
                })
            }, d.$5 = function() {
                d.setState({
                    hasUploadFailure: !0
                })
            }, d.$6 = function(a) {
                d.props.onClick && d.props.onClick();
                if (d.state.bootloaded) return;
                c("Bootloader").loadModules(["UFIUploader"], function(a) {
                    d.$1 = new a(d.refs.inputContainer, d.refs.inputControl, d.refs.input, d.props.getPhotoUploadData, d.props.getFileUploadData, d.props.prepareForAttachedPhotoPreview, d.props.prepareForAttachedVideoPreview, d.props.prepareForAttachedFilePreview, d.props.onPhotoUploadComplete, d.props.onVideoEncodeUpdate, d.props.onVideoUploadUpdate, d.props.onVideoUploadComplete, d.props.onFileUploadComplete, d.props.setFileInput, d.props.viewerActorID, d.$3, d.$4, d.$5)
                }, "UFIAttachMediaSection.react");
                d.setState({
                    bootloaded: !0
                })
            }, b) || babelHelpers.assertThisInitialized(d)
        }
        var e = b.prototype;
        e.componentDidMount = function() {
            var a = this.refs,
                b = a.input;
            a = a.inputControl;
            b && a && (this.$2 = d("Focus").relocate(b, a))
        };
        e.componentWillUnmount = function() {
            this.$1 && this.$1.destroy(), this.$2 && (this.$2.remove(), this.$2 = null)
        };
        e.render = function() {
            var a = this.props.allowFileAttachments,
                b = a ? i._("Attach a file") : this.props.allowVideoAttachments ? i._("Attach a photo or video") : i._("Attach a Photo"),
                d = a ? i._("There was a problem attaching the file, please try again") : i._("There was a problem attaching the file, please try again"),
                e = this.state.hasUploadFailure;
            a = j.jsx("div", {
                className: "_r1a UFIPhotoAttachLinkWrapper _m" + (this.props.attachment ? " _5t1p" : ""),
                "data-hover": e ? null : "tooltip",
                "data-tooltip-alignh": e ? null : "center",
                "data-tooltip-content": e ? null : b,
                onClick: this.$6,
                ref: "inputContainer",
                role: "presentation",
                children: j.jsx("span", {
                    className: a ? "UFICommentFileIcon" : "UFICommentPhotoIcon",
                    ref: "inputControl",
                    children: j.jsx("input", {
                        accept: a ? c("UFICommentFileInputAcceptValues").files : this.props.allowVideoAttachments ? c("UFICommentFileInputAcceptValues").both : c("UFICommentFileInputAcceptValues").photos,
                        "aria-label": b,
                        className: "_n",
                        name: "file",
                        ref: "input",
                        title: b,
                        type: "file"
                    }, "0")
                })
            });
            return j.jsx(c("XUIError.react"), {
                xuiError: e ? d : null,
                xuiErrorPosition: "above",
                xuiErrorAlignh: "center",
                children: a
            })
        };
        return b
    }(j.Component);
    a.propTypes = {
        getPhotoUploadData: c("prop-types").func.isRequired,
        getFileUploadData: c("prop-types").func,
        prepareForAttachedPhotoPreview: c("prop-types").func.isRequired,
        prepareForAttachedVideoPreview: c("prop-types").func,
        prepareForAttachedFilePreview: c("prop-types").func,
        onPhotoUploadComplete: c("prop-types").func.isRequired,
        onVideoUploadComplete: c("prop-types").func,
        onVideoUploadUpdate: c("prop-types").func,
        onVideoEncodeUpdate: c("prop-types").func,
        onFileUploadComplete: c("prop-types").func,
        onClick: c("prop-types").func,
        setFileInput: c("prop-types").func.isRequired,
        targetId: c("prop-types").string,
        allowVideoAttachments: c("prop-types").bool,
        allowFileAttachments: c("prop-types").bool,
        attachment: c("prop-types").object,
        viewerActorID: c("prop-types").string.isRequired
    };
    g["default"] = a
}), 98);
__d("UFIGifButton.react", ["cx", "fbt", "Arbiter", "Bootloader", "FocusRelocator.react", "LayerTabIsolation", "Link.react", "MessengerPlatformInterfaceType", "SubscriptionsHandler", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = 278;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            b = a.call(this) || this;
            b.$5 = function() {
                b.setState({
                    flyoutShown: !1,
                    query: ""
                })
            };
            b.$8 = function() {
                b.$3 = b.state.flyoutShown
            };
            b.$7 = function(a) {
                a.preventDefault();
                if (b.state.renderFlyout !== null) {
                    b.$3 || (b.props.onGifFlyoutShow && b.props.onGifFlyoutShow(), b.setState({
                        flyoutShown: !0
                    }));
                    return
                }
                a = c("Bootloader").loadModules(["XUIContextualDialog.react", "ChatContentSearchFlyout.react", "ContextualLayerAutoFlip"], function(a, d, e) {
                    b.setState({
                        flyoutShown: !0,
                        renderFlyout: function() {
                            return j.jsx(a, {
                                alignment: "right",
                                behaviors: {
                                    flip: e,
                                    LayerTabIsolation: c("LayerTabIsolation")
                                },
                                className: "_5trk",
                                contextRef: function() {
                                    return b.$1
                                },
                                onBlur: b.$5,
                                onToggle: function(a) {
                                    !a && b.state.flyoutShown && b.$5()
                                },
                                position: "above",
                                shown: b.state.flyoutShown,
                                hasActionableContext: !0,
                                width: k,
                                children: j.jsx("div", {
                                    children: j.jsx(d, {
                                        onEscKeyDown: b.$5,
                                        onSelect: b.$9,
                                        query: b.state.query,
                                        shown: b.state.flyoutShown,
                                        searchInterface: c("MessengerPlatformInterfaceType").FB_INTERFACE,
                                        queryDefault: b.props.defaultGifSelection
                                    })
                                })
                            })
                        }
                    }), b.props.onGifFlyoutShow && b.props.onGifFlyoutShow()
                }, "UFIGifButton.react");
                b.$4.addSubscriptions(a)
            };
            b.$9 = function(a) {
                b.props.onGifSelected(a), b.$5()
            };
            b.$6 = function(a) {
                b.$1 = a
            };
            b.state = {
                renderFlyout: null,
                flyoutShown: !1,
                query: ""
            };
            return b
        }
        var d = b.prototype;
        d.componentDidMount = function() {
            var a = this;
            this.$4 = new(c("SubscriptionsHandler"))();
            this.$2 = c("Arbiter").subscribe("page_transition", function() {
                return a.$5()
            })
        };
        d.componentWillUnmount = function() {
            this.$2 && this.$2.unsubscribe(), this.$4 && this.$4.release(), delete this.$4
        };
        d.render = function() {
            var a = i._("Post a GIF"),
                b = this.state.renderFlyout && this.state.flyoutShown ? this.state.renderFlyout() : null;
            return j.jsx(c("FocusRelocator.react"), {
                from: this.$1,
                to: this.refs.icon,
                children: j.jsxs(c("Link.react"), {
                    "aria-label": a,
                    className: "_r1a UFICommentGifButton",
                    "data-hover": "tooltip",
                    "data-tooltip-alignh": "center",
                    "data-tooltip-content": this.props.showTooltip ? a : null,
                    linkRef: this.$6,
                    onClick: this.$7,
                    onMouseDown: this.$8,
                    role: "button",
                    children: [j.jsx("div", {
                        ref: "icon",
                        className: "UFICommentGifIcon" + (this.state.flyoutShown ? " UFICommentGifIconActive" : "")
                    }), this.props.children, b]
                })
            })
        };
        return b
    }(j.Component);
    a.defaultProps = {
        children: [],
        showTooltip: !0,
        defaultGifSelection: null
    };
    g["default"] = a
}), 98);
__d("UFIGroupedInputTabs", ["CacheStorage"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = Object.freeze({
            EMOJI: "EMOJI",
            STICKER: "STICKER",
            GIF: "GIF"
        }),
        i = "last_used_input_on_composer",
        j = new(c("CacheStorage"))("localstorage");
    a = function() {
        return j.get(i, h.STICKER)
    };
    b = function(a) {
        j.set(i, a)
    };
    g.InputTitleEnum = h;
    g.getLastUsedTab = a;
    g.setLastUsedTab = b
}), 98);
__d("UFIImageBlock.react", ["cx", "ImageBlock.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            return i.jsx(c("ImageBlock.react"), babelHelpers["extends"]({}, this.props, {
                imageClassName: "UFIImageBlockImage",
                contentClassName: "UFIImageBlockContent",
                children: this.props.children
            }))
        };
        return b
    }(i.Component);
    g["default"] = a
}), 98);
__d("UFINavigationCheck", ["SnowflakePermalinkUtils", "URI", "VideoPermalinkURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function b(b) {
        var e = c("URI").getNextURI();
        b = b.getMostRecentURI();
        if (Object.prototype.hasOwnProperty.call(e.getQueryData(), "theater") || Object.prototype.hasOwnProperty.call(b.getQueryData(), "theater") || Object.prototype.hasOwnProperty.call(e.getQueryData(), "sdialog") || d("SnowflakePermalinkUtils").isPermalinkURI(e) || d("SnowflakePermalinkUtils").isPermalinkURI(b) || d("VideoPermalinkURI").isValid(e) && e.getQueryData().ref === "channel" || d("VideoPermalinkURI").isValid(b) && b.getQueryData().ref === "channel") return !1;
        b = a.DialogNavigationStack;
        return b && b.isActiveURI(e) ? !1 : !0
    }
    g.isLeaving = b
}), 98);
__d("UFIStickerButton.react", ["cx", "fbt", "Arbiter", "Bootloader", "FocusRelocator.react", "Link.react", "StickerInterfaces", "createReactClass_DEPRECATED", "getObjectValues", "prop-types", "react", "setImmediate"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react");
    a = c("createReactClass_DEPRECATED")({
        displayName: "UFIStickerButton",
        _clickGuard: !1,
        _updateListener: null,
        _openFlyoutListener: null,
        _linkRef: null,
        propTypes: {
            customStickerOwnerID: c("prop-types").string,
            onStickerFlyoutShow: c("prop-types").func,
            onStickerSelected: c("prop-types").func.isRequired,
            showTooltip: c("prop-types").bool,
            stickerInterface: c("prop-types").oneOf(c("getObjectValues")(c("StickerInterfaces"))),
            tabIndex: c("prop-types").number
        },
        getDefaultProps: function() {
            return {
                customStickerOwnerID: "",
                showTooltip: !0,
                stickerInterface: "comments"
            }
        },
        getInitialState: function() {
            return {
                renderFlyout: null,
                flyoutShown: !1
            }
        },
        componentDidMount: function() {
            var a = this;
            this._updateListener = c("Arbiter").subscribe("page_transition", function() {
                return a._hideFlyout()
            });
            this._openFlyoutListener = c("Arbiter").subscribe("GamingStickers/openFlyout", function(b, c) {
                return a._showFlyout(c)
            })
        },
        componentWillUnmount: function() {
            this._updateListener && this._updateListener.unsubscribe(), this._openFlyoutListener && this._openFlyoutListener.unsubscribe()
        },
        render: function() {
            var a = i._("Post a sticker");
            return j.jsx(c("FocusRelocator.react"), {
                from: this._linkRef,
                to: this.refs.icon,
                children: j.jsxs(c("Link.react"), {
                    "aria-label": a,
                    className: "_r1a UFICommentStickerButton",
                    "data-hover": "tooltip",
                    "data-tooltip-alignh": "center",
                    "data-tooltip-content": this.props.showTooltip ? a : null,
                    linkRef: this._setRef,
                    onClick: this._onLinkClicked,
                    onMouseDown: this._prepareForClick,
                    role: "button",
                    tabIndex: this.props.tabIndex,
                    children: [j.jsx("div", {
                        ref: "icon",
                        className: "UFICommentStickerIcon" + (this.state.flyoutShown ? " UFICommentStickerIconActive" : "")
                    }), this.props.children, this.state.renderFlyout ? this.state.renderFlyout() : null]
                })
            })
        },
        _hideFlyout: function() {
            this.setState({
                flyoutShown: !1
            })
        },
        _showFlyout: function(a) {
            var b = this;
            c("Bootloader").loadModules(["ContextualLayerAutoFlip", "LayerTabIsolation", "StickersFlyout.react", "XUIContextualDialog.react", "StickersActions"], function(d, e, f, g, h) {
                b.setState({
                    flyoutShown: !0,
                    renderFlyout: function() {
                        return j.jsx(g, {
                            alignment: "right",
                            behaviors: {
                                ContextualLayerAutoFlip: d,
                                LayerTabIsolation: e
                            },
                            className: "_5e-r",
                            contextRef: function() {
                                return b._linkRef
                            },
                            onBlur: b._hideFlyout,
                            onToggle: function(a) {
                                !a && b.state.flyoutShown && b._hideFlyout()
                            },
                            position: "above",
                            shown: b.state.flyoutShown,
                            hasActionableContext: !0,
                            width: 278,
                            children: j.jsx("div", {
                                children: j.jsx(f, {
                                    customStickerOwnerID: b.props.customStickerOwnerID,
                                    onEscKeyDown: b._hideFlyout,
                                    onStickerSelect: b._onStickerSelected,
                                    stickerInterface: b.props.stickerInterface,
                                    shown: b.state.flyoutShown
                                })
                            })
                        })
                    }
                }), b.props.onStickerFlyoutShow && b.props.onStickerFlyoutShow(), a && c("setImmediate")(function() {
                    return h.selectTrayPack(a)
                })
            }, "UFIStickerButton.react")
        },
        _prepareForClick: function() {
            this._clickGuard = this.state.flyoutShown
        },
        _onLinkClicked: function(a) {
            a.preventDefault();
            if (this.state.renderFlyout !== null) {
                this._clickGuard || (this.props.onStickerFlyoutShow && this.props.onStickerFlyoutShow(), this.setState({
                    flyoutShown: !0
                }));
                return
            }
            this._showFlyout(null)
        },
        _onStickerSelected: function(a, b, c) {
            this.props.onStickerSelected(a, b, c), this._hideFlyout()
        },
        _setRef: function(a) {
            this._linkRef = a
        }
    });
    b = a;
    g["default"] = b
}), 98);
__d("UFIVideoEncodeStatusMonitor", ["AsyncRequest", "clearInterval", "setInterval"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            this.$1 = a
        }
        var b = a.prototype;
        b.subscribe = function(a, b) {
            var d = this;
            this.$3();
            this.$2 = c("setInterval")(function() {
                new(c("AsyncRequest"))().setURI("/ajax/video/encode/feedback/ping/").setData({
                    video_id: d.$1
                }).setHandler(function(c) {
                    c = c.getPayload();
                    c.is_ready ? (d.$3(), a && a()) : c.error && (d.$3(), b && b())
                }).send()
            }, 1e3);
            return {
                unsubscribe: function() {
                    d.$3()
                }
            }
        };
        b.$3 = function() {
            c("clearInterval")(this.$2)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("XConstituentBadgeV2OptInDialogController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/constituent_badge/v2_opt_in_dialog/", {
        __asyncDialog: {
            type: "Int"
        },
        ft_id: {
            type: "String"
        },
        should_refresh: {
            type: "Bool",
            defaultValue: !1
        }
    })
}), null);
__d("XFeedNUXSaveSeenStateController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/feed/nux/seen/save/", {
        link_id: {
            type: "String"
        },
        key: {
            type: "String",
            required: !0
        },
        seen: {
            type: "Bool",
            defaultValue: !1
        },
        env: {
            type: "Enum",
            enumType: 0
        }
    })
}), null);
__d("XUFICommentGIFPreprocessController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ufi/comment/gif_preprocess/", {})
}), null);
__d("UFIAddComment.react", ["cx", "fbt", "invariant", "ActorURI", "Arbiter", "AsyncRequest", "Badge.react", "BootloadedComponent.react", "Bootloader", "ClipboardPhotoUploader", "ConstituentBadgeEventEmitter", "CurrentUser", "EmojiInputButton.react", "Event", "ExclamationStarsActions.react", "ExclamationStarsDispatcher.react", "ExclamationStarsStore.react", "FluxContainer", "IdentityBadgeUtils", "JSResource", "Keys", "Link.react", "LitestandStoryInsertionStatus", "MentionsInputUtils", "Run", "SubscriptionsHandler", "SutroStoryHeaderUFIGatingConfig", "TextWithEntities.react", "ThisControllerNoLongerExists", "TrackingNodes", "UFIAddCommentAction", "UFIAttachMediaSection.react", "UFICommercialBreakStore", "UFICommonInteractionEvents", "UFICommonInteractionLogger", "UFIComposerIsTypingStore", "UFIConfig", "UFIGifButton.react", "UFIGroupedInputTabs", "UFIImageBlock.react", "UFINavigationCheck", "UFIODSLogger", "UFISharedDispatcher", "UFIStickerButton.react", "UFIThreadedFacecastCommentsStore", "UFIVideoEncodeStatusMonitor", "XBasicFBNuxDismissController", "XBasicFBNuxGenShouldShowController", "XBasicFBNuxViewController", "XConstituentBadgeV2OptInDialogController", "XFeedNUXSaveSeenStateController", "XUFICommentGIFPreprocessController", "XUIText.react", "cr:682211", "getActiveElement", "gkx", "joinClasses", "promiseDone", "prop-types", "react", "throttle"], (function(a, b, c, d, e, f, g, h, i, j) {
    "use strict";
    var k = d("react"),
        l = a.URL || a.webkitURL || {},
        m = i._("Write a comment..."),
        n = i._("Write a reply..."),
        o = "fcg fss UFICommentTip",
        p = 19,
        q = "/ajax/ufi/upload/",
        r = "/ajax/ufi/sticker_preview/",
        s = 1e3,
        t = "comment_content_change",
        u = Object.freeze({
            UPLOAD: "uploading",
            ENCODE: "encoding"
        }),
        v = 5572,
        w = /@\[([0-9;]+):((?:[^\\\]]|\\.)*)\]/g,
        x = !1,
        y = !1;
    e = function(e) {
        babelHelpers.inheritsLoose(f, e);
        f.renderEditCommentBox = function(a, b, c) {
            a = babelHelpers["extends"]({}, a);
            delete a.addcommentautoflip;
            delete a.collapseaddcomment;
            delete a.hideActorPhoto;
            delete a.issnowlift;
            delete a.loggedOutLinkConfig;
            delete a.monitorHeight;
            delete a.sht;
            delete a.viewoptionstypeobjects;
            delete a.viewoptionstypeobjectsorder;
            return k.jsx(f, {
                viewerActorID: c.actorforpost,
                targetID: c.ownerid,
                groupID: c.grouporeventid,
                mentionsDataSource: c.mentionsdatasource,
                contextArgs: a,
                isEditing: !0,
                editingComment: b,
                allowVideoAttachments: c.allowvideoattachments,
                allowPhotoAttachments: c.allowphotoattachments,
                allowFileAttachments: c.allowfileattachments,
                allowStickerAttachments: c.allowstickerattachments,
                allowGifAttachments: c.allowgifattachments,
                allowBotMentions: c.allowbotmentions,
                allowTogglePrivateComments: !1,
                privateCommentTarget: c.actorname,
                showconstituentbadgev2optin: c.showconstituentbadgev2optin,
                constituentBanner: c.constituentbanneruri
            }, "editing_comment" + b.id)
        };

        function f(b) {
            var f;
            f = e.call(this, b) || this;
            f.$11 = function(a) {
                f.props.isEditing && c("Event").getKeyCode(a.nativeEvent) === c("Keys").ESC && f.context.dispatch(d("UFIAddCommentAction").cancel(f.props.contextArgs));
                f.$1 && !f.$2 && (d("Run").onBeforeUnload(f.$12), f.$2 = !0);
                var b = c("getActiveElement")();
                b && c("Event").getKeyCode(a.nativeEvent) === c("Keys").ESC && b.blur()
            };
            f.$13 = function(a) {
                c("UFISharedDispatcher").dispatch(d("UFIAddCommentAction").changeContent(f.props.contextArgs, a, f.$14())), c("Arbiter").inform(t, {
                    fbid: f.$14(),
                    text: a,
                    instanceid: f.props.contextArgs.instanceid,
                    ftentidentifier: f.props.contextArgs.ftentidentifier
                }), f.state.groupedInputNUXShown && f.$15()
            };
            f.$16 = function(a) {
                a = d("ThisControllerNoLongerExists").__DEADURI__("0rnfqc3v");
                new(c("AsyncRequest"))(a).setHandler(f.$17).send()
            };
            f.$17 = function(a) {
                if (!a) return;
                f.setState({
                    commentMarkdownPreviewContent: a.payload ? a.payload.markup : null
                })
            };
            f.$12 = function() {
                if (a.PageTransitions && !d("UFINavigationCheck").isLeaving(a.PageTransitions)) return;
                if (f.refs && f.refs.mentionsinput && f.refs.mentionsinput.hasEnteredText()) return i._("You haven't finished your comment yet. Do you want to leave without finishing?")
            };
            f.$18 = function() {
                f.setState({
                    markdownNUXVisible: !1,
                    gifsInCommentsNUXVisible: !1,
                    groupedInputNUXShown: !1,
                    privateCommentNUXVisible: !1
                });
                window.setTimeout(function() {
                    f.$1 && f.setState({
                        isFocused: !1
                    })
                }, 100);
                if (f.refs.mentionsinput && f.refs.mentionsinput.hasEnteredText()) return;
                f.setState({
                    isCommenting: !1
                })
            };
            f.$19 = function(a) {
                var b = new(c("ClipboardPhotoUploader"))(q, f.$20());
                f.$21();
                f.$3 = [b.subscribe("upload_start", f.$22), b.subscribe("upload_error", f.$23), b.subscribe("upload_success", function(a, b) {
                    f.$24(b)
                })];
                b.handlePaste(a)
            };
            f.$25 = function(a, b) {
                var c = f.props.isEditing || f.state.hasAttachment,
                    d = a.encodedValue && a.encodedValue.trim(),
                    e = f.state.isLoadingPhoto || f.$26() || f.state.isLoadingFile;
                if (e || !c && !d) return !1;
                else return f.$27(a, b)
            };
            f.focus = function() {
                var a = {
                        isCommenting: !0,
                        isFocused: !0
                    },
                    b = f.props.contextArgs.loggedOutLinkConfig;
                b && b.showAddComment && c("Bootloader").loadModules(["AsyncDialog"], function(a) {
                    a.bootstrap(b.addCommentAjaxifyURI, null, "dialog")
                }, "UFIAddComment.react");
                f.refs.groupedInputButton && c("Bootloader").loadModules(["SimpleNUXMessage", "SimpleNUXMessageTypes"], function(a, b) {
                    a.hasUserSeenMessage_LEGACY(b.MERGE_INPUT_COMPOSER_NUX) || (f.setState({
                        groupedInputNUXShown: !0
                    }), a.markMessageSeenByUser(b.MERGE_INPUT_COMPOSER_NUX))
                }, "UFIAddComment.react");
                if (f.props.allowGifAttachments && c("UFIConfig").shouldShowGIFsInCommentsNux && !x) {
                    x = !0;
                    var d = c("XFeedNUXSaveSeenStateController").getURIBuilder().setString("key", "gif_comments").setBool("seen", !0).getURI();
                    new(c("AsyncRequest"))(d).send();
                    a.gifsInCommentsNUXVisible = !0
                }
                if (f.props.allowTogglePrivateComments && !(f.state.gifsInCommentsNUXVisible || a.gifsInCommentsNUXVisible) && !(f.state.markdownNUXVisible || a.markdownNUXVisible) && !y) {
                    y = !0;
                    d = c("XBasicFBNuxGenShouldShowController").getURIBuilder().setInt("nux_id", v).getURI();
                    new(c("AsyncRequest"))().setURI(d).setMethod("GET").setReadOnly(!0).setHandler(function(a) {
                        a = a.getPayload();
                        if (a && a.should_show_nux) {
                            a = c("XBasicFBNuxViewController").getURIBuilder().setInt("nux_id", v).getURI();
                            new(c("AsyncRequest"))().setURI(a).send();
                            f.setState({
                                privateCommentNUXVisible: !0
                            })
                        }
                    }).send()
                }
                if (f.state.showConstituentBadgeV2OptIn) {
                    d = c("XConstituentBadgeV2OptInDialogController").getURIBuilder().setString("ft_id", f.props.commentsTargetID).getURI();
                    new(c("AsyncRequest"))().setURI(d).send()
                }
                f.setState(a);
                f.markViewerHasInteracted();
                f.props.onFocus && f.props.onFocus();
                c("Arbiter").inform("UFIAddComment/focus", {
                    instanceid: f.props.contextArgs.instanceid,
                    ftentidentifier: f.props.contextArgs.ftentidentifier,
                    isTopLevelComposer: f.props.isTopLevelComposer
                })
            };
            f.$39 = function(a, b) {
                f.setState({
                    fileInput: a,
                    fileUploader: b
                })
            };
            f.$40 = function(a) {
                d("UFIGroupedInputTabs").setLastUsedTab(d("UFIGroupedInputTabs").InputTitleEnum.EMOJI), f.refs.mentionsinput.insertEmoji(a)
            };
            f.$43 = function(a, b) {
                d("UFIGroupedInputTabs").setLastUsedTab(d("UFIGroupedInputTabs").InputTitleEnum.STICKER), f.onStickerSelected(a, b), f.$44(!1)
            };
            f.$41 = function(a) {
                d("UFIGroupedInputTabs").setLastUsedTab(d("UFIGroupedInputTabs").InputTitleEnum.GIF), f.onGifSelected(a), f.$44(!1)
            };
            f.$44 = function(a) {
                a !== f.state.flyoutShown && f.setState({
                    flyoutShown: a
                })
            };
            f.$42 = function() {
                f.state.flyoutShown || f.markViewerHasInteracted(), f.state.groupedInputNUXShown && f.$15()
            };
            f.$20 = function() {
                var a = f.props.viewerActorID,
                    b = {
                        profile_id: a,
                        target_id: f.props.targetID,
                        source: p
                    };
                b[d("ActorURI").PARAMETER_ACTOR] = a;
                return b
            };
            f.$24 = function(a) {
                if (!f.state.isLoadingPhoto) return;
                a = a.getPayload();
                a && a.fbid ? f.setState({
                    attachedPhoto: a,
                    isLoadingPhoto: !1
                }) : f.$23(null)
            };
            f.$45 = function() {
                var a = f.props.viewerActorID,
                    b = {
                        profile_id: a,
                        target_id: f.props.targetID
                    };
                b[d("ActorURI").PARAMETER_ACTOR] = a;
                return b
            };
            f.$48 = function(a) {
                if (!f.state.isLoadingFile) return;
                a = a.getPayload();
                a && a.fbid ? f.setState({
                    attachedFile: a,
                    isLoadingFile: !1
                }) : f.$23(null)
            };
            f.$50 = function(a, b) {
                if (!f.state.attachedVideo || f.state.videoStatus !== u.ENCODE) return;
                if (b.obj.progress < f.state.videoProgress) return;
                b.obj.fbid = b.obj.videoID;
                if (f.state.attachedVideo.fbid && f.state.attachedVideo.fbid !== b.obj.fbid) return;
                f.setState({
                    attachedVideo: b.obj,
                    videoProgress: b.obj.progress,
                    videoStatus: u.ENCODE
                });
                f.$61(b.obj.stage) && f.$62()
            };
            f.$51 = function(a) {
                f.setState({
                    videoProgress: a
                })
            };
            f.$49 = function(a) {
                if (f.state.videoStatus !== u.UPLOAD) return;
                a && a.video_id && (f.setState({
                    videoProgress: 0,
                    attachedVideo: a,
                    videoStatus: u.ENCODE
                }), f.$4.addSubscriptions(new(c("UFIVideoEncodeStatusMonitor"))(a.video_id).subscribe(function() {
                    f.setState({
                        videoProgress: 100
                    })
                })))
            };
            f.$23 = function(a) {
                c("Arbiter").inform("video_upload_cancel", {}), f.state.fileInput && f.state.fileInput.clear(), f.setState({
                    attachedPhoto: null,
                    attachedVideo: null,
                    attachedFile: null,
                    attachedGIF: null,
                    attachedStars: null,
                    videoStatus: null,
                    videoFileURL: null,
                    isLoadingPhoto: !1,
                    videoProgress: 0,
                    isVideoFileTranscodedGIF: !1,
                    hasAttachment: !1
                })
            };
            f.$22 = function() {
                f.setState({
                    attachedPhoto: null,
                    isLoadingPhoto: !0
                })
            };
            f.$47 = function() {
                f.setState({
                    attachedFile: null,
                    isLoadingFile: !0
                })
            };
            f.$46 = function() {
                var a, b = f.state.fileInput ? f.state.fileInput.input : null;
                b = b ? b.files[0] : null;
                b && l.createObjectURL && (a = l.createObjectURL(b));
                f.setState({
                    attachedVideo: null,
                    videoStatus: u.UPLOAD,
                    videoFileURL: a,
                    videoProgress: 0,
                    isVideoFileTranscodedGIF: Boolean(b && b.type === "image/gif")
                })
            };
            f.$63 = function(a) {
                if (!f.state.isLoadingPhoto) return;
                a = a.getPayload();
                a && a.fbid ? f.$60({
                    attachedSticker: a,
                    isLoadingPhoto: !1
                }) : (c("Bootloader").loadModules(["Dialog"], function(a) {
                    var b = i._("Sticker Failed"),
                        c = i._("There was a problem attaching the sticker.");
                    new a().setTitle(b).setBody(c).setButtons(a.OK).show()
                }, "UFIAddComment.react"), f.$53(null))
            };
            f.$53 = function(a) {
                f.setState({
                    attachedSticker: null,
                    isLoadingPhoto: !1,
                    hasAttachment: !1
                })
            };
            f.$52 = function(a) {
                c("Bootloader").loadModules(["FunnelLogger"], function(a) {
                    a.appendAction("FLEXIBLE_STARS_WWW_FUNNEL", "dismissed_star_attachment"), a.endFunnel("FLEXIBLE_STARS_WWW_FUNNEL")
                }, "UFIAddComment.react"), d("ExclamationStarsActions.react").flyoutStarsUnselected(), f.$23(a)
            };
            f.onStickerSelected = function(a, b) {
                if (f.props.isEditing || f.refs.mentionsinput.hasEnteredText()) {
                    f.$59(a);
                    return
                }
                f.sendSticker(a, b)
            };
            f.onStarsSelected = function(a, b) {
                d("ExclamationStarsActions.react").flyoutStarsSelected(), f.setState({
                    attachedStars: {
                        gift: b,
                        previewImageSrc: null,
                        metadata: a,
                        userTippedQuantity: a,
                        matchingQuantity: 0,
                        promotionEvent: null,
                        type: "SEND_STARS"
                    }
                })
            };
            f.$34 = function() {
                f.setState({
                    markdownNUXVisible: !1
                })
            };
            f.$15 = function() {
                f.setState({
                    groupedInputNUXShown: !1
                })
            };
            f.$38 = function() {
                var a = c("XBasicFBNuxDismissController").getURIBuilder().setInt("nux_id", v).getURI();
                new(c("AsyncRequest"))().setURI(a).send();
                f.setState({
                    privateCommentNUXVisible: !1
                })
            };
            f.$31 = function() {
                f.setState({
                    colorfulCommentsNUXShown: !1
                })
            };
            f.onGifSelected = function(a) {
                if (f.props.isEditing || f.refs.mentionsinput.hasEnteredText()) {
                    f.$60({
                        attachedGIF: a
                    });
                    f.preprocessGIF(a);
                    return
                }
                f.sendGIF(a)
            };
            f.$54 = function(a, b) {
                f.setState(function(c) {
                    c[a] = b;
                    return {
                        mentionsData: c
                    }
                })
            };
            f.$1 = !1;
            var g = f.props.editingComment,
                h = g.attachment,
                j = h ? h.type : null,
                k = j === "photo" ? h : null;
            f.state = {
                attachedPhoto: g.photo_comment || k,
                attachedVideo: g.video_comment || null,
                attachedFile: g.file_comment || null,
                attachedSticker: j == "sticker" ? h : null,
                attachedGIF: j == "gif" ? h : null,
                attachedStars: j == "SEND_STARS" ? h : null,
                colorfulCommentsNUXShown: !1,
                commentMarkdownPreviewContent: g.body ? g.body.markup || null : null,
                commentMarkdownEnabled: g.body ? g.body.markdown_enabled || !1 : !1,
                currentThreadedFacecastCommentID: c("UFIThreadedFacecastCommentsStore").getCommentID(b.contextArgs.instanceid),
                addCommentNUXShown: f.props.contextArgs.permalinkAddCommentNuxShown || !1,
                commentPrivacy: g.privacy_value || f.props.replyCommentPrivacy || 0,
                showConstituentBadgeV2OptIn: Boolean(f.props.showConstituentBadgeV2OptIn),
                constituentBannerState: String(f.props.constituentBanner),
                exclamationStarsData: null,
                videoStatus: null,
                videoFileURL: null,
                videoProgress: 0,
                isVideoFileTranscodedGIF: !1,
                fileInput: null,
                fileUploader: null,
                flyoutShown: !1,
                isCommenting: !1,
                isLoadingPhoto: !1,
                isLoadingFile: !1,
                showFeaturedProductsButton: f.props.contextArgs.shouldShowFeaturedProductsButton || !1,
                isFocused: Boolean(f.props.isEditing),
                gifsInCommentsNUXVisible: !1,
                groupedInputNUXShown: !1,
                markdownNUXVisible: !1,
                privateCommentNUXVisible: !1,
                inCommercialBreak: !1,
                shouldLoadFlexibleStars: !1,
                isSendingMessage: !1,
                hasAttachment: !1,
                mentionsData: {}
            };
            k = f.state.attachedPhoto || f.state.attachedVideo || f.state.attachedFile || f.state.attachedGIF || f.state.attachedSticker || f.state.attachedStars;
            f.state.hasAttachment = !!k;
            return f
        }
        var g = f.prototype;
        g.$27 = function(a, b) {
            var e;
            a.encodedValue = a.encodedValue ? a.encodedValue.trim() : "";
            this.state.commentMarkdownEnabled && (a.isMarkdown = !0, this.setState({
                commentMarkdownEnabled: !1,
                commentMarkdownPreviewContent: null
            }));
            this.state.commentPrivacy && (a.privacy_value = this.state.commentPrivacy);
            this.state.hasAttachment ? (a.attachedPhoto = this.state.attachedPhoto, a.attachedVideo = this.state.attachedVideo, a.attachedFile = this.state.attachedFile, a.attachedSticker = this.state.attachedSticker, a.attachedStars = this.state.attachedStars, this.state.attachedGIF && (this.state.attachedGIF.source ? a.attachedShareURL = this.state.attachedGIF.source.url : this.state.attachedGIF.originalImageUrl && (a.attachedShareURL = this.state.attachedGIF.originalImageUrl)), this.setState({
                isLoadingPhoto: !1,
                isLoadingFile: !1,
                attachedPhoto: null,
                attachedVideo: null,
                attachedFile: null,
                attachedSticker: null,
                attachedGIF: null,
                attachedStars: null,
                hasAttachment: !1
            })) : (a.attachedPhoto = null, a.attachedVideo = null, a.attachedFile = null, a.attachedSticker = null, a.attachedGIF = null, a.attachedShareURL = null, a.attachedStars = null);
            if (this.props.isEditing) this.context.dispatch(d("UFIAddCommentAction").submitEdit(this.props.contextArgs, this.props.editingComment, a, b.target));
            else if (this.state.attachedStars || !((e = this.state.exclamationStarsData) == null ? void 0 : e.isLoading) && ((e = this.state.exclamationStarsData) == null ? void 0 : e.isDetected) && ((e = this.state.exclamationStarsData) == null ? void 0 : e.errorMessage) == null) this.$28(a);
            else {
                e = d("UFICommonInteractionLogger").makeTrackingID();
                d("UFICommonInteractionLogger").startInteraction(c("UFICommonInteractionEvents").UFI_OPTIMISTIC_COMMENT, e + c("UFICommonInteractionEvents").UFI_OPTIMISTIC_COMMENT);
                d("UFICommonInteractionLogger").startInteraction(c("UFICommonInteractionEvents").UFI_PERSISTED_COMMENT, e + c("UFICommonInteractionEvents").UFI_PERSISTED_COMMENT);
                a.trackingID = e;
                this.context.dispatch(d("UFIAddCommentAction").submitNew(this.props.contextArgs, a, b.target, this.$14()))
            }
            this.$29();
            return !0
        };
        g.$28 = function(a) {
            var b;
            a = (a = this.state.attachedStars) == null ? void 0 : a.userTippedQuantity;
            if (((b = this.state.exclamationStarsData) == null ? void 0 : b.isDetected) && !((b = this.state.exclamationStarsData) == null ? void 0 : b.isFlyoutStarsSelected)) {
                a = (b = this.state.exclamationStarsData) == null ? void 0 : b.spendingUnits
            }
            b = this.props.targetID;
            d("ExclamationStarsActions.react").exclamationStarsUndetected();
            d("ExclamationStarsActions.react").flyoutStarsUnselected();
            a && b && j(0, 54389)
        };
        g.$26 = function() {
            return this.state.videoStatus === u.UPLOAD || this.state.videoStatus === u.ENCODE && this.state.videoProgress !== 100
        };
        g.$21 = function() {
            this.$3 && this.$3.forEach(function(a) {
                a.unsubscribe()
            })
        };
        g.UNSAFE_componentWillMount = function() {
            var a = this;
            this.$2 = !1;
            this.$5 = c("LitestandStoryInsertionStatus").registerBlocker(function() {
                return a.state.isCommenting
            });
            this.$4 && this.$4.release();
            this.$4 = new(c("SubscriptionsHandler"))();
            this.$4.addSubscriptions(c("UFICommercialBreakStore").addListener(function() {
                a.setState({
                    inCommercialBreak: c("UFICommercialBreakStore").getValueFor(a.props.contextArgs.instanceid)
                })
            }), c("ConstituentBadgeEventEmitter").addListener("ConstituentBadgeV2OptInModal", function(b) {
                if (!b) {
                    a.setState({
                        showConstituentBadgeV2OptIn: !1
                    });
                    return
                }
                a.setState({
                    constituentBannerState: b.turn_off ? null : a.props.constituentBanner,
                    showConstituentBadgeV2OptIn: !1
                })
            }));
            this.props.allowLiveVideoCommentReplyMode && (this.props.contextArgs.islivestreaming || this.props.contextArgs.isLiveVOD || this.props.contextArgs.isActiveLivingRoom) && this.$4.addSubscriptions(c("UFIThreadedFacecastCommentsStore").addListener(function() {
                var b = a.state.currentThreadedFacecastCommentID,
                    d = c("UFIThreadedFacecastCommentsStore").getCommentID(a.props.contextArgs.instanceid);
                a.setState({
                    currentThreadedFacecastCommentID: d
                });
                d !== b && a.focus()
            }));
            c("UFIConfig").canPublishLive && this.$4.addSubscriptions(c("UFIComposerIsTypingStore").addListener(function() {
                var b = c("UFIComposerIsTypingStore").getValueFor(a.props.contextArgs.ftentidentifier);
                if (b === null) return
            }))
        };
        g.componentWillUnmount = function() {
            var a = this;
            c("Bootloader").loadModules(["TextDelightInComposerLogger"], function(b) {
                b.endFunnel(a.$14() || a.props.contextArgs.ftentidentifier)
            }, "UFIAddComment.react");
            this.$1 = !1;
            this.$21();
            this.$7 && c("Arbiter").unsubscribe(this.$7);
            this.$6 && c("Arbiter").unsubscribe(this.$6);
            this.$8 && c("Arbiter").unsubscribe(this.$8);
            this.$9 && c("Arbiter").unsubscribe(this.$9);
            this.$10 && c("Arbiter").unsubscribe(this.$10);
            this.$5 && this.$5.unsubscribe();
            this.$5 = null;
            this.$4 && this.$4.release()
        };
        g.$30 = function() {
            var a = this;
            if (!this.state.colorfulCommentsNUXShown) d("IdentityBadgeUtils").isEligibleForColorComments(this.props.feedback, this.props.contextArgs) && c("gkx")("900398") && c("Bootloader").loadModules(["SimpleNUXMessage", "SimpleNUXMessageTypes"], function(b, c) {
                b.hasUserSeenMessage_LEGACY(c.GAMES_COLORFUL_COMMENTS) || (a.setState({
                    colorfulCommentsNUXShown: !0
                }), b.markMessageSeenByUser(c.GAMES_COLORFUL_COMMENTS))
            }, "UFIAddComment.react");
            else return k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("XUIAmbientNUX.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                contextRef: function() {
                    return a.refs.mentionsinput
                },
                shown: this.state.colorfulCommentsNUXShown,
                position: "above",
                width: "auto",
                alignment: "center",
                onCloseButtonClick: this.$31,
                children: i._("Top Fan, Supporter, and Familiar Face badge holders will have their comments highlighted for a few seconds.")
            });
            return null
        };
        g.$32 = function() {
            var a = this;
            return this.state.gifsInCommentsNUXVisible && this.refs.gif_button ? k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("XUIAmbientNUX.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                contextRef: function() {
                    return a.refs.gif_button
                },
                shown: this.state.gifsInCommentsNUXVisible,
                position: "above",
                width: "auto",
                alignment: "right",
                children: i._("You can now add GIFs to comments")
            }) : null
        };
        g.$33 = function() {
            var a = this;
            return this.state.markdownNUXVisible ? k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("XUIAmbientNUX.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                contextRef: function() {
                    return a.refs.markdownButton
                },
                shown: this.state.markdownNUXVisible,
                position: "above",
                width: "auto",
                alignment: "right",
                onCloseButtonClick: this.$34,
                children: i._("[FB-Only] Markdown in Comments! Click to enable.")
            }) : null
        };
        g.$35 = function() {
            var a = this;
            return this.state.groupedInputNUXShown ? k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("XUIAmbientNUX.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                contextRef: function() {
                    return a.refs.groupedInputButton
                },
                shown: this.state.groupedInputNUXShown,
                position: "above",
                width: "auto",
                alignment: "right",
                onCloseButtonClick: this.$15,
                children: i._("Post stickers, emojis and GIFs")
            }) : null
        };
        g.$36 = function() {
            var a = this;
            return this.state.addCommentNUXShown ? k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("FBAmbientPulseNUX.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                contextRef: function() {
                    return a.refs.mentionsinput
                },
                dialogShown: !1,
                position: "left",
                shown: this.state.addCommentNUXShown
            }) : null
        };
        g.$37 = function() {
            var a = this;
            return this.state.privateCommentNUXVisible ? k.jsxs(c("BootloadedComponent.react"), {
                alignment: "right",
                bootloadLoader: c("JSResource")("XUIAmbientNUX.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                contextRef: function() {
                    return a.refs.privacy_icon
                },
                onCloseButtonClick: this.$38,
                position: "above",
                shown: this.state.privateCommentNUXVisible,
                width: "auto",
                children: [k.jsx(c("XUIText.react"), {
                    display: "block",
                    weight: "bold",
                    children: i._("Comment Privately")
                }), k.jsx(c("XUIText.react"), {
                    display: "block",
                    children: i._("Add a comment that only {user} will see", [i._param("user", this.props.privateCommentTarget)])
                })]
            }) : null
        };
        g.render = function() {
            var a = this,
                e = this.props.contextArgs.loggedOutLinkConfig,
                f = !0;
            e && e.showAddComment && (f = !1);
            e = (!this.props.contextArgs.collapseaddcomment || this.state.isCommenting) && f && !this.props.contextArgs.hideActorPhoto;
            var g = null;
            this.props.subtitle ? g = k.jsx("span", {
                className: o,
                children: this.props.subtitle
            }) : !this.state.isFocused && this.props.isEditing ? g = k.jsx("span", {
                className: o,
                children: i._("{cancel}", [i._param("cancel", k.jsx(c("Link.react"), {
                    onClick: function() {
                        return a.context.dispatch(d("UFIAddCommentAction").cancel(a.props.contextArgs))
                    },
                    children: i._("Cancel")
                }))])
            }) : this.props.isEditing ? g = k.jsx("span", {
                className: o,
                children: i._("Press Esc to {cancel}.", [i._param("cancel", k.jsx(c("Link.react"), {
                    onMouseDown: function() {
                        return a.context.dispatch(d("UFIAddCommentAction").cancel(a.props.contextArgs))
                    },
                    children: i._("cancel")
                }))])
            }) : this.props.peopleOutsideCommunityInCommentNotice && this.state.isFocused ? g = k.jsxs("div", {
                className: "fcg fsm _2pid",
                children: [k.jsx(c("Badge.react"), {
                    type: "work_non_coworker"
                }, "noncoworker"), k.jsx("span", {
                    className: "_2pir _4zk5",
                    children: k.jsx(c("TextWithEntities.react"), {
                        ranges: this.props.peopleOutsideCommunityInCommentNotice.ranges,
                        text: this.props.peopleOutsideCommunityInCommentNotice.text
                    })
                })]
            }) : this.props.showSendOnEnterTip && !this.props.contextArgs.isTahoeUFI && !this.props.contextArgs.isActiveLivingRoom && (g = k.jsx("span", {
                className: o,
                children: i._("Press Enter to post.")
            }));
            var h = null,
                j = null,
                l = null,
                p = null,
                q = this.state.attachedPhoto || this.state.attachedSticker || this.state.attachedVideo || this.state.attachedFile || this.state.attachedGIF || this.state.attachedStars,
                r = null,
                s = null,
                t = b("cr:682211") ? k.jsx(b("cr:682211"), {
                    ref: "groupedInputButton",
                    allowGifAttachments: !!this.props.allowGifAttachments,
                    allowStickerAttachments: !!this.props.allowStickerAttachments,
                    customStickerOwnerID: this.props.targetID,
                    flyoutShown: this.state.flyoutShown,
                    onEmojiSelect: this.$40,
                    onGifSelect: this.$41,
                    onLinkClick: this.$42,
                    onStickerSelect: this.$43,
                    toggleFlyout: this.$44
                }) : null,
                v = b("cr:682211") ? null : k.jsx(c("EmojiInputButton.react"), {
                    buttonClassName: "_r1a UFICommentEmojiButton",
                    iconActiveClassName: "UFICommentEmojiIconActive",
                    iconClassName: "UFICommentEmojiIcon",
                    onClick: function() {
                        return a.markViewerHasInteracted()
                    },
                    onSelect: function(b) {
                        a.refs.mentionsinput.insertEmoji(b)
                    }
                });
            !b("cr:682211") && this.props.allowStickerAttachments && !q && (j = k.jsx(c("UFIStickerButton.react"), {
                ref: "sticker_button",
                customStickerOwnerID: this.props.targetID,
                onStickerSelected: this.onStickerSelected,
                onStickerFlyoutShow: function() {
                    c("Arbiter").inform("comment_content_change", {
                        addingAttachment: !0
                    }), a.markViewerHasInteracted()
                }
            }));
            !b("cr:682211") && this.props.allowGifAttachments && !q && (l = k.jsx(c("UFIGifButton.react"), {
                ref: "gif_button",
                onGifSelected: this.onGifSelected,
                onGifFlyoutShow: function() {
                    return a.markViewerHasInteracted()
                },
                defaultGifSelection: this.props.contextArgs.defaultGifQuery
            }));
            (this.props.allowPhotoAttachments || this.props.allowVideoAttachments || this.props.allowFileAttachments) && (r = this.$19, h = k.jsx(c("UFIAttachMediaSection.react"), {
                ref: "media_section",
                getPhotoUploadData: this.$20,
                getFileUploadData: this.$45,
                prepareForAttachedPhotoPreview: this.$22,
                prepareForAttachedVideoPreview: this.$46,
                prepareForAttachedFilePreview: this.$47,
                allowVideoAttachments: this.props.allowVideoAttachments,
                allowFileAttachments: this.props.allowFileAttachments,
                onPhotoUploadComplete: this.$24,
                onFileUploadComplete: this.$48,
                onVideoUploadComplete: this.$49,
                onVideoEncodeUpdate: this.$50,
                onVideoUploadUpdate: this.$51,
                setFileInput: this.$39,
                targetId: this.props.targetID,
                onClick: function() {
                    c("Arbiter").inform("comment_content_change", {
                        addingAttachment: !0
                    }), a.markViewerHasInteracted()
                },
                attachment: q,
                viewerActorID: this.props.viewerActorID
            }));
            q = c("TrackingNodes").getTrackingInfo(c("TrackingNodes").types.ADD_COMMENT_BOX);
            var w = "addComment_" + this.props.contextArgs.ftentidentifier,
                x;
            this.$14() ? x = this.props.contextArgs.replyPlaceholderText || n : this.props.contextArgs.placeholderText ? x = this.props.contextArgs.placeholderText : x = m;
            var y = this.props.contextArgs.viewoptionstypeobjects,
                z = this.props.contextArgs.viewoptionstypeobjectsorder;
            this.props.attachedPhoto && !this.props.subtitle && (g = null);
            var A;
            (this.state.attachedPhoto || this.state.isLoadingPhoto || this.state.attachedVideo || this.state.videoStatus === u.UPLOAD || this.state.attachedFile || this.state.isLoadingFile || this.state.attachedSticker || this.state.attachedGIF || this.state.attachedStars) && (A = k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("UFIAttachedMediaPreview.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("span", {}),
                attachedPhoto: this.state.attachedPhoto,
                attachedVideo: this.state.attachedVideo,
                attachedFile: this.state.attachedFile,
                attachedSticker: this.state.attachedSticker,
                attachedGIF: this.state.attachedGIF,
                attachedStars: this.state.attachedStars,
                monitorHeight: this.props.contextArgs.monitorHeight,
                onRemoveAttachedMediaPreviewClicked: this.$23,
                onRemoveAttachedStarsPreview: this.$52,
                onRemoveAttachedStickerPreview: this.$53,
                subtitle: this.props.subtitle,
                isLoadingPhoto: this.state.isLoadingPhoto,
                isLoadingFile: this.state.isLoadingFile,
                videoFileURL: this.state.videoFileURL,
                videoStatus: this.state.videoStatus,
                videoProgress: this.state.videoProgress,
                isVideoFileTranscodedGIF: this.state.isVideoFileTranscodedGIF
            }));
            var B = this.props.contextArgs.mentionsinput,
                C = null,
                D = null,
                E = null;
            B && (C = B.inputComponent, D = B.viewComponent, E = B.viewProps);
            B = this.props.editingComment.body;
            B = B ? d("MentionsInputUtils").generateDataFromTextWithEntities(B) : null;
            C = C ? k.jsx(C, {
                disableInitTextarea: !f,
                replyCommentID: this.$14(),
                initialData: B,
                placeholder: x,
                datasource: this.props.mentionsDataSource,
                ref: "mentionsinput",
                viewComponent: D,
                viewProps: E,
                viewOptionsTypeObjects: y,
                viewOptionsTypeObjectsOrder: z,
                hashtags: this.props.contextArgs.sht,
                autoflip: this.props.contextArgs.addcommentautoflip,
                monitorHeight: this.props.contextArgs.monitorHeight,
                onEnterSubmit: this.$25,
                onFocus: this.focus,
                onBlur: this.$18,
                onContentChange: this.$13,
                onPaste: r,
                ftEntIdentifier: this.props.contextArgs.ftentidentifier,
                instanceID: this.props.contextArgs.instanceid,
                isBroadcasterUFI: this.props.contextArgs.isBroadcasterUFI,
                isTahoeUFI: this.props.contextArgs.isTahoeUFI,
                isLivingRoom: this.props.contextArgs.isActiveLivingRoom,
                isStreamerHub: this.props.contextArgs.isStreamerHub,
                updateMentionsData: this.$54
            }) : null;
            f = c("SutroStoryHeaderUFIGatingConfig").enabled_for_comment_composer_rounded_borders;
            B = c("SutroStoryHeaderUFIGatingConfig").enabled_for_comment_glyphs;
            x = k.jsxs("div", {
                className: "UFICommentContainer",
                children: [k.jsxs("div", {
                    className: "_fmi" + (f ? " _613v" : "") + " UFIInputContainer",
                    children: [C, k.jsxs("div", {
                        className: "_fmk UFICommentAttachmentButtons _5op2" + (B ? " _15i7" : "") + (B ? " _2kwm" : ""),
                        children: [B ? this.$55() : null, p, v, h, l, j, t, s]
                    })]
                }), A, g]
            });
            ({});
            e && (x = k.jsx(c("UFIImageBlock.react"), {
                className: "UFIMentionsInputWrap" + (this.props.allowStickerAttachments ? " UFIStickersEnabledInput" : "") + "" + (this.props.allowGifAttachments ? " UFIGifEnabledInput" : "") + (this.props.allowNativeTipJar ? " UFITipJarEnabledInput" : "") + (this.props.allowFlexibleTipping ? " UFIFlexibleStarsEnabledInput" : ""),
                children: x
            }));
            D = k.jsxs("div", {
                ref: function(b) {
                    return a.rootNode = b
                },
                id: w,
                className: c("joinClasses")("UFIRow _4oep UFIAddComment" + (this.props.allowPhotoAttachments ? " UFIAddCommentWithPhotoAttacher" : "") + (this.props.withoutSeparator ? " UFIAddCommentWithoutSeparator" : "") + (this.props.isFirstComponent ? " _4204" : "") + (this.props.isLastComponent ? " _2o9m" : "") + (this.state.inCommercialBreak ? " hidden_elem" : ""), this.props.className),
                onKeyDown: this.$11,
                "data-ft": q,
                children: [this.$56(), this.$57(), x, this.$32(), this.$33(), this.$35(), this.$36(), this.$30()]
            });
            return D
        };
        g.componentDidUpdate = function(a, b) {
            if (!b.attachedPhoto && this.state.attachedPhoto || !b.attachedSticker && this.state.attachedSticker || !b.attachedVideo && this.state.attachedVideo || !b.attachedFile && this.state.attachedFile || !b.attachedGIF && this.state.attachedGIF || !b.attachedStars && this.state.attachedStars || !b.isCommenting && this.state.isCommenting) {
                var c = this.state.attachedPhoto || this.state.attachedVideo || this.state.attachedFile || this.state.attachedSticker || this.state.attachedGIF || this.state.attachedStars;
                this.setState({
                    hasAttachment: !!c
                });
                this.refs.mentionsinput.focus()
            }
            a.viewerActorID !== this.props.viewerActorID && (this.state.fileInput && this.state.fileInput.clear(), this.state.fileUploader && this.state.fileUploader.setData(this.$20()), this.$23());
            !b.shouldLoadFlexibleStars && this.state.shouldLoadFlexibleStars && this.$58()
        };
        g.componentDidMount = function() {
            var a = this;
            this.$1 = !0;
            if (this.props.contextArgs.source === 1) {
                var b = this.props.replyCommentID != null;
                b ? d("UFIODSLogger").bump("composer.newsfeed.replies.componentDidMount", "legacy") : d("UFIODSLogger").bump("composer.newsfeed.toplevel.componentDidMount", "legacy")
            }
            this.$16 = c("throttle")(this.$16, s, this);
            this.$8 = c("Arbiter").subscribe("UFIComment/insertComposerPayload/" + this.props.contextArgs.ftentidentifier, function(b, c) {
                if (!c || c.instanceid !== void 0 && c.instanceid !== a.props.contextArgs.instanceid || !a.props.isTopLevelComposer) return;
                a.focus();
                c.mention !== void 0 && a.insertMention(c.mention);
                c.emojitext !== void 0 && a.insertEmojiText(c.emojitext);
                c.stickerid !== void 0 && a.$59(c.stickerid)
            });
            this.$9 = c("Arbiter").subscribe("UFIComment/" + this.props.contextArgs.ftentidentifier + "/selectGif", function(b, c) {
                if (!c || a.$14()) return;
                a.focus();
                a.$60({
                    attachedGIF: c.gif
                });
                a.preprocessGIF(c.gif)
            });
            (this.props.contextArgs.shouldCreateFeaturedProductsButton || !1) && (this.$10 = c("Arbiter").subscribe("LiveVideoInteractiveAlert/liveShoppingFeaturedProductAlertReceived", function(b, c) {
                a.setState({
                    showFeaturedProductsButton: !0
                })
            }));
            c("ExclamationStarsDispatcher.react").explicitlyRegisterStores([c("ExclamationStarsStore.react")]);
            this.state.shouldLoadFlexibleStars && this.$58();
            if (!this.props.allowPhotoAttachments && !this.props.allowVideoAttachments && !this.props.allowFileAttachments) return;
            this.$14() === null && (this.$6 = c("Arbiter").subscribe("focusCommentField" + this.props.contextArgs.ftentidentifier, function(b) {
                a.refs.mentionsinput.focus()
            }), this.props.contextArgs.issnowlift && (this.$7 = c("Arbiter").subscribe("newRemixedImage" + this.props.contextArgs.ftentidentifier, function(b, c) {
                b = {
                    clipboardData: {
                        items: [c]
                    }
                };
                a.$19(b)
            })))
        };
        g.$56 = function() {
            return this.state.constituentBannerState && !this.$14() ? k.jsx(c("BootloadedComponent.react"), {
                bootloadLoader: c("JSResource")("UFICommentingAsConstituentHeader.react").__setRef("UFIAddComment.react"),
                bootloadPlaceholder: k.jsx("div", {}),
                uri: this.props.constituentBanner
            }) : null
        };
        g.$55 = function() {
            var a = this,
                b = this.props.isEditing && this.props.editingComment.privacy_value === 1,
                d = this.$14() && this.props.replyCommentPrivacy === 1,
                e = !b && !d && this.props.allowTogglePrivateComments;
            if (!b && !d && !this.props.allowTogglePrivateComments || e) return null;
            e ? b = i._("Toggle Privacy") : d ? b = i._("Only you and {user} will be able to see your reply", [i._param("user", this.props.privateCommentTarget)]) : b = i._("Only you and {user} can see this", [i._param("user", this.props.privateCommentTarget)]);
            return k.jsxs(c("Link.react"), {
                "aria-label": b,
                className: "_r1a UFICommentPrivacyButton",
                "data-hover": "tooltip",
                "data-tooltip-alignh": "center",
                "data-tooltip-content": b,
                onClick: function() {
                    a.markViewerHasInteracted(), e && a.setState(function(a) {
                        return {
                            commentPrivacy: a.commentPrivacy === 1 ? 0 : 1
                        }
                    })
                },
                role: "button",
                children: [k.jsx("div", {
                    ref: "privacy_icon",
                    className: "UFICommentPrivacyIcon" + (!e || this.state.commentPrivacy === 1 ? " UFICommentPrivacyIconActive" : "")
                }), e ? this.$37() : null]
            })
        };
        g.$57 = function() {
            return this.props.isEditing || this.state.commentPrivacy !== 1 ? null : this.$14() ? k.jsx("div", {
                className: "_2tpi",
                children: i._("Replying privately to {=m1}", [i._implicitParam("=m1", k.jsx("strong", {
                    children: i._("{user}", [i._param("user", this.props.privateCommentTarget)])
                }))])
            }) : k.jsx("div", {
                className: "_2tpi",
                children: i._("Only you and {=m1} can see this", [i._implicitParam("=m1", k.jsx("strong", {
                    children: i._("{user}", [i._param("user", this.props.privateCommentTarget)])
                }))])
            })
        };
        g.insertMention = function(a) {
            var b = this;
            this.refs.mentionsinput && this.refs.mentionsinput.insertMention && (this.refs.mentionsinput.insertMention(a), window.setTimeout(function() {
                return b.refs.mentionsinput.focus()
            }))
        };
        g.insertEmojiText = function(a) {
            this.refs.mentionsinput.getText().trim() === "" ? this.refs.mentionsinput.insertEmoticon(a.trim() + " ") : this.refs.mentionsinput.insertEmoticon(a)
        };
        g.$61 = function(a) {
            return a === "finish"
        };
        g.$62 = function() {
            this.state.fileInput && this.state.fileInput.clear()
        };
        g.$60 = function(a) {
            if (!c("CurrentUser").isWorkUser()) this.setState(a);
            else {
                var b = {
                    attachedPhoto: null,
                    attachedVideo: null,
                    attachedFile: null,
                    attachedGIF: null,
                    attachedSticker: null,
                    attachedStars: null,
                    videoStatus: null,
                    videoFileURL: null,
                    isLoadingPhoto: !1,
                    videoProgress: 0,
                    isVideoFileTranscodedGIF: !1,
                    hasAttachment: !1
                };
                this.setState(babelHelpers["extends"]({}, b, a))
            }
        };
        g.$59 = function(a) {
            this.setState({
                attachedSticker: null,
                isLoadingPhoto: !0
            }), new(c("AsyncRequest"))(r).setData({
                sticker_id: a
            }).setErrorHandler(this.$53).setHandler(this.$63).send()
        };
        g.sendSticker = function(a, b) {
            a = {
                encodedValue: "",
                visibleValue: "",
                attachedPhoto: null,
                attachedSticker: {
                    fbid: a
                },
                privacy_value: this.state.commentPrivacy
            };
            this.context.dispatch(d("UFIAddCommentAction").submitNew(this.props.contextArgs, a, b.target, this.$14()))
        };
        g.isPromotionMatchingEnabled = function(a) {
            return a != null && a.isEnabled && a.type === "SPEND_MATCH"
        };
        g.$29 = function() {
            this.setState({
                addCommentNUXShown: !1
            })
        };
        g.preprocessGIF = function(a) {
            var b = c("XUFICommentGIFPreprocessController").getURIBuilder().getURI();
            new(c("AsyncRequest"))(b).setData({
                gif_url: a.source.url
            }).send()
        };
        g.sendGIF = function(a) {
            a = {
                encodedValue: "",
                visibleValue: "",
                attachedShareURL: a.source.url,
                privacy_value: this.state.commentPrivacy
            };
            this.rootNode && this.context.dispatch(d("UFIAddCommentAction").submitNew(this.props.contextArgs, a, this.rootNode, this.$14()))
        };
        g.parseTextForMentions = function(a) {
            var b = [],
                c;
            while (c = w.exec(a)) {
                c = {
                    uid: c[1],
                    text: c[2],
                    offset: c.index,
                    length: c[2].length,
                    weakreference: !1,
                    entity: {
                        uid: c[1],
                        weakreference: !1
                    }
                };
                b.push(c);
                w.lastIndex = c.offset + c.length
            }
            return b
        };
        g.markViewerHasInteracted = function() {
            this.props.markViewerHasInteracted && this.props.markViewerHasInteracted()
        };
        g.$14 = function() {
            return this.props.replyCommentID || this.state.currentThreadedFacecastCommentID
        };
        f.getStores = function() {
            return [c("ExclamationStarsStore.react")]
        };
        f.calculateState = function(a) {
            a = babelHelpers["extends"]({}, a);
            a.exclamationStarsData = {
                isDetected: c("ExclamationStarsStore.react").isExclamationStarsDetected(),
                isLoading: c("ExclamationStarsStore.react").isLoading(),
                spendingUnits: c("ExclamationStarsStore.react").getSpendingUnits(),
                errorMessage: c("ExclamationStarsStore.react").getErrorMessage(),
                isFlyoutStarsSelected: c("ExclamationStarsStore.react").isFlyoutStarsSelected()
            };
            return a
        };
        g.$64 = function() {
            var a = this;
            d("ExclamationStarsActions.react").startFetchBalance();
            c("Bootloader").loadModules(["VideoStarsWalletQuery", "RelayModern", "RelayFBEnvironment"], function(b, e, f) {
                c("promiseDone")(e.fetchQuery(f, b, {}), function(a) {
                    d("ExclamationStarsActions.react").completeFetchBalance((a = a) != null ? (a = a.viewer) != null ? (a = a.digital_content_wallet) != null ? a.digital_content_wallet_balance : a : a : a)
                }, function(b) {
                    d("ExclamationStarsActions.react").handleTransactionError(a.props.targetID)
                })
            }, "UFIAddComment.react")
        };
        g.$58 = function() {
            var a = this,
                b = this.props.targetID;
            b && this.props.allowShortcutTipping && (d("ExclamationStarsActions.react").enableExclamationStars(), c("Bootloader").loadModules(["GameTippingCustomTipMetaDataQuery", "RelayModern", "nullthrows", "RelayFBEnvironment"], function(e, f, g, h) {
                c("promiseDone")(f.fetchQuery(h, e, {
                    input: {
                        page_id: b
                    }
                }), function(a) {
                    a = (a = a) != null ? a.game_tipping_custom_tip_meta_data : a;
                    if (a) {
                        a = a.map(function(a) {
                            var b;
                            return {
                                min: g((b = a) != null ? b.min : b),
                                max: g((b = a) != null ? b.max : b),
                                color: g((b = a) != null ? b.main_color : b)
                            }
                        });
                        d("ExclamationStarsActions.react").completeFetchExclamationStarsMetadata(a, a[0].min)
                    }
                }, function(b) {
                    d("ExclamationStarsActions.react").handleTransactionError(a.props.targetID)
                }), a.$64()
            }, "UFIAddComment.react"))
        };
        return f
    }(k.Component);
    e.contextTypes = {
        dispatch: c("prop-types").func
    };
    f = c("FluxContainer").create(e);
    g["default"] = f
}), 98);
__d("UFICallbackStore", ["FluxStore"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.__onDispatch = function(a) {
            var b = a.type;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["type"]);
            this.__emitter.emit(b, a)
        };
        c.on = function(a, b) {
            return this.__emitter.addListener(a, b)
        };
        c.remove = function() {
            this.__emitter.removeAllListeners()
        };
        return b
    }(c("FluxStore"));
    a.__moduleID = f.id;
    g["default"] = a
}), 98);
__d("UFIDispatcherContext.react", ["prop-types", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.getChildContext = function() {
            return {
                dispatch: this.props.dispatcher.dispatch.bind(this.props.dispatcher),
                stores: this.props.stores
            }
        };
        c.render = function() {
            return this.props.children
        };
        return b
    }(a.Component);
    b.childContextTypes = {
        dispatch: c("prop-types").func,
        stores: c("prop-types").object
    };
    g["default"] = b
}), 98);
__d("UFIFeedbackContext.react", ["UFICentralUpdates", "UFIFeedbackTargets", "prop-types", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$1 = null, c.state = {
                contextArgs: c.props.contextArgs,
                feedback: null
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var e = b.prototype;
        e.loadFeedbackTarget = function(a) {
            var b = this;
            this.$1 || (this.$1 = d("UFIFeedbackTargets").getFeedbackTarget(a, function(a) {
                b.$1 = null, b.setState({
                    feedback: a
                })
            }))
        };
        e.componentDidMount = function() {
            var a = this;
            this.loadFeedbackTarget(this.state.contextArgs.ftentidentifier);
            this.ufiCentralUpdatesSubscriptions = [c("UFICentralUpdates").subscribe("feedback-updated", function(b, c) {
                b = a.state.contextArgs;
                b.ftentidentifier in c.updates && a.loadFeedbackTarget(b.ftentidentifier)
            })]
        };
        e.componentWillUnmount = function() {
            this.ufiCentralUpdatesSubscriptions.forEach(function(a) {
                return a && c("UFICentralUpdates").unsubscribe(a)
            }), this.$1 && d("UFIFeedbackTargets").unsubscribe(this.$1)
        };
        e.render = function() {
            return this.state.feedback ? this.props.render(this.state.contextArgs, this.state.feedback) : null
        };
        return b
    }(a.Component);
    b.propTypes = {
        contextArgs: c("prop-types").object.isRequired,
        render: c("prop-types").func.isRequired
    };
    b.contextTypes = {
        stores: c("prop-types").object
    };
    g["default"] = b
}), 98);
__d("UFIAddCommentController", ["Parent", "ReactDOM", "UFIAddComment.react", "UFIAsyncWrapper", "UFICallbackStore", "UFICentralUpdates", "UFICommentEditIDStore", "UFIDispatcher", "UFIDispatcherContext.react", "UFIFeedbackContext.react", "UFILivePinnedCommentStore", "UFINewCommentNotifier", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    a = function() {
        a.factory = function(b, c) {
            c.rootid = b.id;
            return new a(b, Object.freeze(c))
        };

        function a(a, b) {
            var e = this;
            this.renderAddComment = function(a, b) {
                if (e.$5 !== null || !b || !b.cancomment || !b.actorforpost) return null;
                var d = e.$6 != null;
                return h.jsx(c("UFIAddComment.react"), {
                    isLivePinnedCommentVisible: d,
                    viewerActorID: b.actorforpost,
                    targetID: b.ownerid,
                    targetName: b.actorname,
                    groupID: b.grouporeventid,
                    initialData: null,
                    ref: null,
                    withoutSeparator: !1,
                    editingComment: {},
                    isEditing: !1,
                    allowLiveVideoCommentReplyMode: !0,
                    mentionsDataSource: b.mentionsdatasource,
                    showSendOnEnterTip: b.showsendonentertip,
                    peopleOutsideCommunityInCommentNotice: b.peopleoutsidecommunityincommentnotice,
                    allowPhotoAttachments: b.allowphotoattachments && !a.islivestreaming && !a.isActiveLivingRoom,
                    allowVideoAttachments: b.allowvideoattachments && !a.islivestreaming && !a.isActiveLivingRoom,
                    allowFileAttachments: b.allowfileattachments && !a.islivestreaming && !a.isActiveLivingRoom,
                    allowStickerAttachments: b.allowstickerattachments && (!a.islivestreaming || b.allowLiveVideoStickerAttachments),
                    allowGifAttachments: b.allowgifattachments && (!a.islivestreaming || b.allowgaminglivestreamgifattachments) && !a.isActiveLivingRoom,
                    allowBotMentions: b.allowbotmentions && !a.islivestreaming && !a.isActiveLivingRoom,
                    allowNativeTipJar: b.isnativetipjarenabled,
                    allowFlexibleTipping: b.isflexibletippingenabled,
                    flexibleStarsModule: b.flexiblestarsmodule,
                    allowShortcutTipping: b.isshortcuttippingenabled,
                    allowTogglePrivateComments: !1,
                    privateCommentTarget: b.actorname,
                    contextArgs: a,
                    feedback: b,
                    subtitle: b.subtitle,
                    commentsTargetID: b.commentstargetfbid
                })
            };
            this.$1 = a;
            this.$2 = b;
            this.$3 = new(c("UFIDispatcher"))();
            this.$4 = {
                UFICallbackStore: new(c("UFICallbackStore"))(this.$3)
            };
            this.$4.UFICallbackStore.on("add_comment_submit_new", function(b) {
                return d("UFINewCommentNotifier").onNewComment(d("Parent").byTag(a, "form"), e.$2, b.comment, b.target, b.replyCommentID, b.timestamp)
            });
            this.$5 = c("UFICommentEditIDStore").getForInstance(this.$2.instanceid);
            c("UFICommentEditIDStore").addListener(function() {
                var a = c("UFICommentEditIDStore").getForInstance(e.$2.instanceid);
                a != e.$5 && (e.$5 = a, e.render())
            });
            c("UFILivePinnedCommentStore").addListener(function() {
                var a = c("UFILivePinnedCommentStore").getPinnedCommentID(e.$2.ftentidentifier);
                a != e.$6 && (e.$6 = a, e.render())
            });
            c("UFICentralUpdates").subscribeOnce("update-comments", function(a, b) {
                e.$6 = c("UFILivePinnedCommentStore").getPinnedCommentID(e.$2.ftentidentifier), e.render()
            });
            this.render()
        }
        var b = a.prototype;
        b.render = function() {
            var a = h.jsx(c("UFIDispatcherContext.react"), {
                dispatcher: this.$3,
                stores: this.$4,
                children: h.jsx(c("UFIFeedbackContext.react"), {
                    contextArgs: this.$2,
                    render: this.renderAddComment
                })
            });
            d("ReactDOM").render(h.jsx(c("UFIAsyncWrapper"), {
                children: a
            }), this.$1)
        };
        b.disable = function() {
            this.$4.UFICallbackStore.remove()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LegacyMentionsInput.react", ["cx", "Bootloader", "Event", "FocusListener", "Keys", "ReactDOM", "TypeaheadMetricsConfig", "prop-types", "react"], (function(a, b, c, d, e, f, g) {
    var h;
    b("FocusListener");
    var i = h || (h = b("react"));
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c() {
            var c, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (c = d = a.call.apply(a, [this].concat(f)) || this, d.hasEnteredText = function() {
                return !!(d.$2 && d.$2.getValue().trim())
            }, d.submitComment = function(a) {
                var c;
                if (a) c = a.target.value && a.target.value.trim();
                else {
                    var e = b("ReactDOM").findDOMNode(d.refs.textarea);
                    e.value && e.value !== e.placeholder && (c = e.value)
                }
                c = c || "";
                e = {
                    visibleValue: c,
                    encodedValue: c
                };
                d.$2 && (e.encodedValue = d.$2.getRawValue().trim());
                e = d.props.onEnterSubmit(e, a);
                e && d.$2 && (d.$2.reset(), a && a.preventDefault())
            }, d.$3 = function(a) {
                var c = a.nativeEvent;
                c = b("Event").getKeyCode(c) == b("Keys").RETURN && !b("Event").$E(c).getModifiers().any;
                var e = d.$2 && d.$2.getTypeahead().getView().getSelection();
                d.props.onEnterSubmit && c && !e && d.submitComment(a)
            }, d.$4 = function() {
                d.props.onFocus && d.props.onFocus(), d.$1(b("ReactDOM").findDOMNode(d.refs.root))
            }, d.$5 = function() {
                d.props.onBlur && d.props.onBlur()
            }, d.$1 = function(a) {
                if (d.props.disableInitTextarea || d.$2 || d.$6) return;
                d.$6 = !0;
                b("Bootloader").loadModules(["CompactTypeaheadRenderer", "ContextualTypeaheadView", "InputSelection", "MentionsInput", "TextAreaControl", "Typeahead", "TypeaheadAreaCore", "TypeaheadBestName", "TypeaheadHoistFriends", "TypeaheadMetrics", "TypeaheadMetricsX", "TypingDetector"], function(c, e, f, g, h, i, j, k, l, m, n, o) {
                    var p = b("ReactDOM").findDOMNode(d.refs.textarea);
                    new h(p);
                    if (d.props.onTypingStateChange) {
                        h = new o(p);
                        h.init();
                        h.subscribe("change", d.props.onTypingStateChange)
                    }
                    o = {
                        autoSelect: !0,
                        renderer: c,
                        causalElement: p,
                        autoflip: d.props.autoflip
                    };
                    d.props.viewOptionsTypeObjects && (o.typeObjects = d.props.viewOptionsTypeObjects);
                    d.props.viewOptionsTypeObjectsOrder && (o.typeObjectsOrder = d.props.viewOptionsTypeObjectsOrder);
                    h = new i(d.props.datasource, {
                        ctor: e,
                        options: o
                    }, {
                        ctor: j
                    }, b("ReactDOM").findDOMNode(d.refs.typeahead));
                    c = [k, l];
                    if (b("TypeaheadMetricsConfig").gkResults) {
                        e = new n({
                            extraData: {
                                event_name: "mention_metric_x"
                            }
                        });
                        e.init(h)
                    }
                    o = new m({
                        extraData: {
                            event_name: "mentions",
                            from_location: "comments"
                        }
                    });
                    i.initNow(h, c, o);
                    d.$2 = new g(a, h, p, {
                        hashtags: d.props.hashtags
                    });
                    d.$2.init({}, d.props.initialData);
                    d.props.initialData && f.set(p, p.value.length);
                    d.props.onPaste && b("Event").listen(p, "paste", d.props.onPaste);
                    d.props.onContentChange && (d.$7 = d.$2.subscribe("valueUpdate", function(a, b) {
                        a = b.value;
                        d.props.onContentChange(a)
                    }));
                    d.$6 = !1
                }, "LegacyMentionsInput.react")
            }, d.focus = function() {
                try {
                    b("ReactDOM").findDOMNode(d.refs.textarea).focus()
                } catch (a) {}
            }, c) || babelHelpers.assertThisInitialized(d)
        }
        var d = c.prototype;
        d.componentDidMount = function() {
            this.props.initialData && this.$1(b("ReactDOM").findDOMNode(this))
        };
        d.getText = function() {
            return this.$2 && this.$2.getRawValue().trim()
        };
        d.componentWillUnmount = function() {
            this.$2 && this.$7 && this.$2.unsubscribe(this.$7)
        };
        d.render = function() {
            var a = "textInput mentionsTextarea uiTextareaAutogrow uiTextareaNoResize UFIAddCommentInput _2xww";
            return i.jsxs("div", {
                ref: "root",
                className: "uiMentionsInput textBoxContainer ReactLegacyMentionsInput _2xwx",
                children: [i.jsx("div", {
                    className: "highlighter",
                    children: i.jsx("div", {
                        children: i.jsx("span", {
                            className: "highlighterContent hidden_elem"
                        })
                    })
                }), i.jsx("div", {
                    ref: "typeahead",
                    className: "uiTypeahead mentionsTypeahead",
                    children: i.jsxs("div", {
                        className: "wrap",
                        children: [i.jsx("input", {
                            type: "hidden",
                            autoComplete: "off",
                            className: "hiddenInput"
                        }), i.jsx("div", {
                            className: "innerWrap",
                            children: i.jsx("textarea", {
                                ref: "textarea",
                                name: "add_comment_text",
                                className: a,
                                title: this.props.placeholder,
                                placeholder: this.props.placeholder,
                                onFocus: this.$4,
                                onBlur: this.$5,
                                onKeyDown: this.$3
                            })
                        })]
                    })
                }), i.jsx("input", {
                    type: "hidden",
                    autoComplete: "off",
                    className: "mentionsHidden",
                    defaultValue: ""
                })]
            })
        };
        return c
    }(i.Component);
    a.propTypes = {
        initialData: b("prop-types").object,
        disableInitTextarea: b("prop-types").bool,
        placeholder: b("prop-types").string,
        datasource: b("prop-types").object,
        ref: b("prop-types").string,
        viewOptionsTypeObjects: b("prop-types").object,
        viewOptionsTypeObjectsOrder: b("prop-types").array,
        hashtags: b("prop-types").bool,
        autoflip: b("prop-types").bool,
        onEnterSubmit: b("prop-types").func,
        onFocus: b("prop-types").func,
        onBlur: b("prop-types").func,
        onContentChange: b("prop-types").func,
        onTypingStateChange: b("prop-types").func,
        onPaste: b("prop-types").func
    };
    e.exports = a
}), null);
__d("createUFI2BotComposerPluginForDraftjs", ["cr:1959427", "createUFI2ComposerPlugin", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return function(d) {
            var e = function(e) {
                babelHelpers.inheritsLoose(c, e);

                function c() {
                    return e.apply(this, arguments) || this
                }
                var f = c.prototype;
                f.render = function() {
                    return b("cr:1959427") == null ? h.jsx(d, babelHelpers["extends"]({}, this.props)) : h.jsx(d, babelHelpers["extends"]({}, this.props, {
                        actions: [].concat(this.props.actions, [h.jsx(b("cr:1959427"), {
                            groupID: a.groupID,
                            onComposerStateChange: this.props.inputProps.onComposerStateChange
                        }, "botComposerAction")])
                    }))
                };
                return c
            }(h.Component);
            return c("createUFI2ComposerPlugin")(e)
        }
    }
    g["default"] = a
}), 98);
__d("createUFI2FileViewerComposerPlugin", ["fbt", "Arbiter", "SubscriptionsHandler", "WorkFilePDFViewEvents", "createUFI2ComposerPlugin", "nullthrows", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a() {
        return function(a) {
            var b = function(d) {
                babelHelpers.inheritsLoose(b, d);

                function b() {
                    var a, b;
                    for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
                    return (a = b = d.call.apply(d, [this].concat(f)) || this, b.$1 = new(c("SubscriptionsHandler"))(), b.state = {
                        pageNumber: null
                    }, b.$2 = function(a, c) {
                        b.props.inputProps.onComposerStateChange(function(a) {
                            b.setState({
                                pageNumber: c.page
                            });
                            return {
                                fileMarker: c
                            }
                        })
                    }, b.$3 = function(a, c) {
                        if (b.props.inputProps.depth !== 0) return;
                        b.props.inputProps.onComposerStateChange(function(a) {
                            return {
                                fileMarker: c
                            }
                        })
                    }, b.$4 = function() {
                        b.props.inputProps.onCommit();
                        var a = b.props.inputProps.composerState.fileMarker,
                            d = {};
                        a == null && (d.isReply = !0);
                        (a == null ? void 0 : a.page) != null && (d.pageIndex = c("nullthrows")(a == null ? void 0 : a.page) - 1);
                        (a == null ? void 0 : a.location) != null && (d.isMarker = !0)
                    }, a) || babelHelpers.assertThisInitialized(b)
                }
                var e = b.prototype;
                e.componentDidMount = function() {
                    if (this.props.inputProps.depth !== 0) return;
                    this.$1.addSubscriptions(c("Arbiter").subscribe(c("WorkFilePDFViewEvents").PAGE_CHANGE, this.$2), c("Arbiter").subscribe(c("WorkFilePDFViewEvents").SELECTED_MARKER, this.$3))
                };
                e.componentWillUnmount = function() {
                    this.$1.release()
                };
                e.render = function() {
                    return i.jsx(a, babelHelpers["extends"]({}, this.props, {
                        inputProps: babelHelpers["extends"]({}, this.props.inputProps, {
                            onCommit: this.$4,
                            placeholder: this.state.pageNumber != null && this.props.inputProps.depth === 0 ? h._("Page {Page number}: write a comment", [h._param("Page number", this.state.pageNumber)]) : this.props.inputProps.placeholder
                        })
                    }))
                };
                return b
            }(i.Component);
            return c("createUFI2ComposerPlugin")(b)
        }
    }
    g["default"] = a
}), 98);
__d("getWorkplaceUFI2ComposerPlugins__DEPRECATED", ["cr:1101374", "cr:1329998", "cr:4373", "createCometUFIMentionsComposerPluginForDraftjs", "createUFI2AssociateReplyWithParentComposerPluginForDraftjs", "createUFI2BotComposerPluginForDraftjs", "createUFI2ComposerTipPluginForDraftjs", "createUFI2EmoticonsComposerPluginForDraftjs", "createUFI2FileViewerComposerPlugin", "createUFI2HashtagComposerPluginForDraftjs", "createUFI2LiveTypingBroadcastComposerPlugin", "createUFI2PrefillMentionComposerPluginForDraftjs", "createUFI2SetReplyClickedComposerPluginForDraftjs", "createUFI2UnifiedInputComposerPluginForDraftjs", "getWorkplaceUFI2ComposerPluginsDEPRECATED_feedback.graphql", "getWorkplaceUFI2ComposerPluginsDEPRECATED_group.graphql", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j = c("requireDeferred")("createUpgradedUFI2GroupMentionsComposerPluginForDraftjs").__setRef("getWorkplaceUFI2ComposerPlugins__DEPRECATED"),
        k = c("requireDeferred")("createUpgradedUFI2MentionsComposerPluginForDraftjs").__setRef("getWorkplaceUFI2ComposerPlugins__DEPRECATED");
    h !== void 0 ? h : h = b("getWorkplaceUFI2ComposerPluginsDEPRECATED_feedback.graphql");
    i !== void 0 ? i : i = b("getWorkplaceUFI2ComposerPluginsDEPRECATED_group.graphql");

    function a(a) {
        var d, e = a.environment,
            f = a.feedback;
        a = a.group;
        d = (f == null ? void 0 : (d = f.viewer_actor) == null ? void 0 : (d = d.user_avatar) == null ? void 0 : d.has_fb_app_avatar) === !0;
        return [f.can_viewer_comment_with_marker === !0 ? c("createUFI2FileViewerComposerPlugin")() : null, f.composer_tip != null ? c("createUFI2ComposerTipPluginForDraftjs")({
            composer_tip: f.composer_tip
        }) : null, b("cr:1329998") ? b("cr:1329998")({
            environment: e
        }) : null, a != null ? c("createCometUFIMentionsComposerPluginForDraftjs")({
            upgradedPluginDeferred_FOR_DRAFTJS_AND_OUTLINE: j
        }) : c("createCometUFIMentionsComposerPluginForDraftjs")({
            upgradedPluginDeferred_FOR_DRAFTJS_AND_OUTLINE: k
        }), c("createUFI2HashtagComposerPluginForDraftjs")(), f.can_viewer_comment_with_bot_mention === !0 && a != null && a.id != null ? c("createUFI2BotComposerPluginForDraftjs")({
            groupID: a.id
        }) : null, c("createUFI2EmoticonsComposerPluginForDraftjs")({
            size: 16
        }), c("createUFI2LiveTypingBroadcastComposerPlugin")({
            feedback: f,
            relayEnvironment: e
        }), c("createUFI2PrefillMentionComposerPluginForDraftjs")(), c("createUFI2AssociateReplyWithParentComposerPluginForDraftjs")(), c("createUFI2SetReplyClickedComposerPluginForDraftjs")()].concat(c("createUFI2UnifiedInputComposerPluginForDraftjs")({
            allowGifAttachments: (a = f.can_viewer_comment_with_gif) != null ? a : !1,
            allowStickerAttachments: (a = f.can_viewer_comment_with_sticker) != null ? a : !1,
            environment: e,
            targetID: (a = f) != null ? (a = a.owning_profile) != null ? a.id : a : a
        }), [b("cr:4373") != null && d ? b("cr:4373")({
            hasAvatar: d,
            postID: null
        }) : null, b("cr:1101374") != null ? b("cr:1101374")({
            environment: e,
            ftentidentifier: f == null ? void 0 : f.id,
            surface: "comment"
        }) : null]).filter(Boolean)
    }
    g["default"] = a
}), 98);
__d("Token", ["fbt", "CSS", "DOM", "DataStore", "Locale", "UnicodeBidi"], (function(a, b, c, d, e, f, g) {
    a = function() {
        "use strict";

        function a(a, b) {
            this.info = a, this.paramName = b
        }
        var c = a.prototype;
        c.getInfo = function() {
            return this.info
        };
        c.getText = function() {
            return this.info.text
        };
        c.getValue = function() {
            return this.info.uid
        };
        c.isFreeform = function() {
            return !!this.info.freeform
        };
        c.setSelected = function(a) {
            b("CSS").conditionClass(this.getElement(), "uiTokenSelected", a);
            return this
        };
        c.getElement = function() {
            this.element || this.setElement(this.createElement());
            return this.element
        };
        c.setElement = function(a) {
            b("DataStore").set(a, "Token", this);
            this.element = a;
            return this
        };
        c.isRemovable = function() {
            return b("CSS").hasClass(this.element, "removable")
        };
        c.getTextDirection = function() {
            var a = b("UnicodeBidi").isDirectionRTL(this.getText()),
                c = b("Locale").isRTL();
            if (a && !c) return "rtl";
            return !a && c ? "ltr" : null
        };
        c.createElement = function(a, c) {
            var d = this.paramName,
                e = this.getValue(),
                f = this.getText(),
                h = b("DOM").create("span", {
                    className: "uiTokenText"
                }, f),
                i = null;
            this.info.removable !== !1 && (i = b("DOM").create("a", {
                href: "#",
                "aria-label": g._("Remove {item}", [g._param("item", f)]),
                className: "remove uiCloseButton uiCloseButtonSmall"
            }));
            a && b("CSS").addClass(i, "uiCloseButtonSmallGray");
            e = b("DOM").create("input", {
                type: "hidden",
                value: e,
                name: d + "[]",
                autocomplete: "off"
            });
            f = b("DOM").create("input", {
                type: "hidden",
                value: f,
                name: "text_" + d + "[]",
                autocomplete: "off"
            });
            d = {
                className: "removable uiToken"
            };
            var j = this.getTextDirection();
            j !== null && (d.dir = j);
            j = b("DOM").create("span", d, [h, e, f, i]);
            a && b("CSS").addClass(j, "uiTokenGray");
            if (c) {
                d = b("DOM").create("i", {
                    className: c
                });
                b("DOM").prependContent(j, d)
            }
            return j
        };
        return a
    }();
    e.exports = a
}), null);
__d("WeakToken", ["CSS", "Token"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.createElement = function() {
            var b = a.prototype.createElement.call(this, !0, "UFIWeakReferenceIcon");
            d("CSS").addClass(b, "uiTokenWeakReference");
            return b
        };
        return b
    }(c("Token"));
    g["default"] = a
}), 98);
__d("Tokenizer", ["Arbiter", "ArbiterMixin", "CSS", "DOM", "DOMQuery", "DataStore", "Event", "Focus", "Input", "Keys", "Parent", "StickyPlaceholderInput", "Style", "TextMetrics", "Token", "UserAgent_DEPRECATED", "WeakToken", "createObjectFrom", "emptyFunction", "mixin"], (function(a, b, c, d, e, f) {
    var g = 20;
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(c, d, e) {
            var f;
            f = a.call(this) || this;
            f.element = c;
            f.typeahead = d;
            f.input = d.getCore().getElement();
            e && f.init(e.tokenarea, e.param_name, e.initial_info, e.options);
            b("DataStore").set(f.element, "Tokenizer", babelHelpers.assertThisInitialized(f));
            return f
        }
        var d = c.prototype;
        d.init = function(a, c, d, e) {
            this._handleEvents = this.handleEvents.bind(this), this.init = b("emptyFunction"), this.setTokenarea(a), this.paramName = c, this.placeholder || (this.placeholder = this.input.getAttribute("data-placeholder") || this.input.getAttribute("placeholder") || ""), Object.assign(this, e), this.initEvents(), this.initTypeahead(), this.reset(d), this.initBehaviors(), setTimeout(this.adjustWidth.bind(this), 0), b("Arbiter").inform("Tokenizer/init", this, "persistent"), this.inform("init", {
                tokens: this.getTokens()
            })
        };
        d.reset = function(a) {
            this.tokens = [], this.unique = {}, a ? this.populate(a) : b("DOM").empty(this.tokenarea), this.updateTokenarea()
        };
        d.populate = function(a) {
            var c = [];
            this.tokens = this.getTokenElements().map(function(b, d) {
                d = a[d];
                c.push(this._tokenKey(d));
                return this.createToken(d, b)
            }, this);
            this.unique = b("createObjectFrom")(c, this.tokens)
        };
        d.setTokenarea = function(a) {
            var c = !this.tokenarea;
            if (a !== this.tokenarea) {
                if (this.tokenarea) {
                    b("DOM").remove(this.tokenarea);
                    for (var d in this._tokenareaListeners) this._tokenareaListeners[d].remove()
                }
                this._tokenareaListeners = b("Event").listen(a, {
                    click: this._handleEvents,
                    keydown: this._handleEvents
                });
                this.tokenarea = a
            }
            c || this.reset()
        };
        d.getElement = function() {
            return this.element
        };
        d.getTypeahead = function() {
            return this.typeahead
        };
        d.getInput = function() {
            return this.input
        };
        d.initBehaviors = function() {
            var a = this;
            this.behaviors = this.behaviors || [];
            if (this.behaviors instanceof Array) this.behaviors.forEach(function(b) {
                b.behavior(a, b.config)
            });
            else
                for (var b in this.behaviors || {}) {
                    var c = window.TokenizerBehaviors && window.TokenizerBehaviors[b];
                    c.call(null, this, this.behaviors[b])
                }
        };
        d.initTypeahead = function() {
            var a = this,
                c = this.typeahead.getCore();
            c.resetOnSelect = !0;
            c.setValueOnSelect = !1;
            c.preventFocusChangeOnTab = !this.typeaheadTabNavigation;
            if (this.inline) {
                c = this.typeahead.getView();
                b("CSS").addClass(c.getElement(), "uiInlineTokenizerView")
            }
            this.typeahead.subscribe("select", function(b, c) {
                return a.handleSelect(c)
            });
            this.typeahead.subscribe("blur", this.handleBlur.bind(this))
        };
        d.handleBlur = function(a) {
            this.inform("blur", {
                event: a
            }), this.updatePlaceholder()
        };
        d.handleSelect = function(a) {
            var b = a.selected;
            a = a.query;
            "uid" in b && (this.updateInput(), this.addToken(this.createToken(b), a))
        };
        d.initEvents = function() {
            var a = b("UserAgent_DEPRECATED").firefox() < 4 ? "keypress" : "keydown";
            b("Event").listen(this.input, "paste", this.paste.bind(this));
            b("Event").listen(this.input, a, this.keydown.bind(this))
        };
        d.handleEvents = function(a) {
            var c = a.getTarget(),
                d = c && this.getTokenElementFromTarget(c);
            if (!d) return;
            (a.type != "keydown" || b("Event").getKeyCode(a) == b("Keys").RETURN) && this.processEvents(a, c, d)
        };
        d.processEvents = function(a, c, d) {
            if (b("Parent").byClass(c, "remove")) {
                var e = d.nextSibling;
                e = e && b("DOMQuery").scry(d.nextSibling, ".remove")[0];
                d = this.getTokenFromElement(d);
                d = this.addTokenData(d, c);
                this.removeToken(d);
                this.focusOnTokenRemoval(a, e);
                a.kill()
            }
        };
        d.focusOnTokenRemoval = function(a, c) {
            b("Focus").set(a.type == "keydown" && c || this.input)
        };
        d.addTokenData = function(a, b) {
            return a
        };
        d.keydown = function(a) {
            this.inform("keydown", {
                event: a
            });
            a = b("Event").getKeyCode(a);
            var c = this.input;
            if (this.inline && a == b("Keys").BACKSPACE && b("Input").isEmpty(c)) {
                a = this.getLastToken();
                a && a.isRemovable() && this.removeToken(a)
            }
            this.updateInput()
        };
        d.paste = function(a) {
            this.inform("paste", {
                event: a
            }), this.updateInput(!0)
        };
        d.focusInput = function() {
            b("Focus").set(this.input)
        };
        d.updateInput = function(a) {
            var c = this;
            if (!this.inline) return;
            setTimeout(function() {
                c.adjustWidth(c.input.value), a && (c.input.value = c.input.value)
            }, 20);
            b("StickyPlaceholderInput").setPlaceholderText(this.input, "");
            this.inform("resize")
        };
        d.setStickyPlaceholder = function(a) {
            this.stickyPlaceholder = !0, this.setPlaceholder(a)
        };
        d.setPlaceholder = function(a) {
            this.placeholder = a, this.stickyPlaceholder && b("StickyPlaceholderInput").setPlaceholderText(this.input, a), this.updatePlaceholder()
        };
        d.updatePlaceholder = function() {
            if (!this.inline || this.input.value) return;
            var a = !this.tokens.length,
                c = "";
            a || this.stickyPlaceholder ? (this.adjustWidth(this.placeholder), c = this.placeholder) : this.adjustWidth(this.input.value);
            b("StickyPlaceholderInput").setPlaceholderText(this.input, c)
        };
        d.adjustWidth = function(a) {
            if (!this.inline || !this._getIsInDOM()) return;
            !a && this.input.value === "" && (a = this.placeholder);
            var c = g;
            if (a !== this.placeholder || !this.getTokens().length || this.stickyPlaceholder) {
                var d = b("Style").getFloat(this.getElement(), "width");
                a = this._getMetrics().measure(a);
                c = a.width + this._getWidthOffset() + 10;
                c = c >= d ? d : c
            }
            b("Style").set(this.input, "width", c + "px");
            this.inform("resize");
            b("Arbiter").inform("reflow")
        };
        d.getToken = function(a) {
            return this.unique[a] || null
        };
        d.getTokens = function() {
            return this.tokens || []
        };
        d.getTokenElements = function() {
            return b("DOMQuery").scry(this.tokenarea, "span.uiToken")
        };
        d.getTokenElementFromTarget = function(a) {
            return b("Parent").byClass(a, "uiToken")
        };
        d.getTokenFromElement = function(a) {
            return b("DataStore").get(a, "Token")
        };
        d.getTokenValues = function() {
            return !this.tokens ? [] : this.tokens.map(function(a) {
                return a.getValue()
            })
        };
        d.getFirstToken = function() {
            return this.tokens[0] || null
        };
        d.getLastToken = function() {
            return this.tokens[this.tokens.length - 1] || null
        };
        d.hasMaxTokens = function() {
            return this.maxTokens && this.maxTokens <= this.tokens.length
        };
        d.createToken = function(a, c) {
            var d = this.getToken(this._tokenKey(a));
            d || (d = a.weak_reference ? new(b("WeakToken"))(a, this.paramName) : new(b("Token"))(a, this.paramName));
            c && d.setElement(c);
            return d
        };
        d.addToken = function(a, c) {
            if (this.hasMaxTokens()) return;
            var d = this._tokenKey(a.getInfo());
            if (d in this.unique) return;
            this.unique[d] = a;
            this.tokens.push(a);
            this.insertToken(a);
            this.updateTokenarea();
            this.inform("addToken", a);
            this.inform("addTokenWithQuery", {
                token: a,
                query: c
            });
            this.inform("changeTokens");
            b("Arbiter").inform("Form/change", {
                node: this.element
            })
        };
        d.insertToken = function(a) {
            b("DOM").appendContent(this.tokenarea, a.getElement())
        };
        d.removeToken = function(a) {
            if (!a) return;
            var c = this.tokens.indexOf(a);
            if (c < 0) return;
            this.tokens.splice(this.tokens.indexOf(a), 1);
            delete this.unique[this._tokenKey(a.getInfo())];
            b("DOM").remove(a.getElement());
            this.updateTokenarea();
            this.inform("removeToken", a);
            this.inform("changeTokens");
            b("Arbiter").inform("Form/change", {
                node: this.element
            })
        };
        d.removeAllTokens = function() {
            this.reset(), this.inform("changeTokens"), this.inform("removeAllTokens")
        };
        d.updateTokenarea = function() {
            var a = this.typeahead.getCore(),
                c = this.getTokenValues();
            this.excludeDuplicates && (this._exclusions || (this._exclusions = a.getExclusions()), a.setExclusions(c.concat(this._exclusions)));
            a.setEnabled(!this.hasMaxTokens());
            this.updateTokenareaVisibility();
            this.updatePlaceholder();
            this.inform("resize");
            b("Arbiter").inform("reflow")
        };
        d.updateTokenareaVisibility = function() {
            b("CSS").conditionShow(this.tokenarea, this.tokens.length !== 0)
        };
        d._tokenKey = function(a) {
            return a.uid + (a.freeform ? ":" : "")
        };
        d._getWidthOffset = function() {
            if (this._widthOffset === null) {
                var a = this.input.clientWidth,
                    c = b("Style").getFloat(this.input, "width");
                a == c ? this._widthOffset = b("Style").getFloat(this.input, "paddingLeft") + b("Style").getFloat(this.input, "paddingRight") : this._widthOffset = 0
            }
            return this._widthOffset
        };
        d._getMetrics = function() {
            this._metrics || (this._metrics = new(b("TextMetrics"))(this.input, this.inline));
            return this._metrics
        };
        d._getIsInDOM = function() {
            return this._isInDOM || (this._isInDOM = b("DOMQuery").contains(document.body, this.input))
        };
        c.getInstance = function(a) {
            a = b("Parent").byClass(a, "uiTokenizer");
            return a ? b("DataStore").get(a, "Tokenizer") : null
        };
        c.init = function(a, b) {
            a.init(b.tokenarea, b.param_name, b.initial_info, b.options)
        };
        return c
    }(b("mixin")(b("ArbiterMixin")));
    Object.assign(a.prototype, {
        inline: !1,
        maxTokens: null,
        excludeDuplicates: !0,
        placeholder: "",
        _widthOffset: null,
        _metrics: null
    });
    e.exports = a
}), null);
__d("PhotoSessionLog", ["AsyncRequest", "Run", "URI", "Vector", "WWWBase"], (function(a, b, c, d, e, f) {
    var g;

    function h() {}
    Object.assign(h, {
        UNKNOWN: 0,
        ESC: 1,
        X: 2,
        OUTSIDE: 3,
        UNLOAD: 4,
        NAVIGATE: 5,
        AGGREGATE: 6,
        LEAVE: 7,
        LOADING: 8,
        PERMALINK: 0,
        SNOWLIFT: 6,
        SNOWDOWN: 13,
        AGGREGATION_COUNT: 20,
        set: null,
        time: null,
        views: 0,
        fbidList: [],
        details: {},
        width: 0,
        height: 0,
        first: !1,
        last: !1,
        logIds: !1,
        version: null,
        source: null,
        lastVisibleStart: 0,
        currentDuration: 0,
        buttonLikes: 0,
        pagingAction: "",
        cycle: !1,
        endOfRelevant: !1,
        relevantCount: 0,
        closingTypeToString: function(a) {
            return {
                0: "UNKNOWN",
                1: "ESC",
                2: "X",
                3: "OUTSIDE",
                4: "UNLOAD",
                5: "NAVIGATE"
            }[a] || "UNKNOWN"
        },
        initLogging: function(a) {
            this.set = null;
            this.time = new Date();
            this.views = 0;
            this.hiResLoads = 0;
            this.fullScreenViews = {};
            this.first = !0;
            this.last = !1;
            this.logIds = !1;
            this.eid = "";
            this.version = a;
            this.buttonLikes = 0;
            this.pagingAction = "";
            this.cycle = !1;
            this.endOfRelevant = !1;
            this.relevantCount = 0;
            this.topLevelPostId = 0;
            this.storyLocation = 0;
            this.storyAttachmentStyle = "";
            this.attachedStoryAttachmentStyle = "";
            this.qid = "";
            this.mfStoryKey = "";
            this.pageInsightsData = null;
            this.lastVisibleStart = Date.now();
            this.currentDuration = 0;
            if (a === h.SNOWLIFT) {
                a = b("Vector").getViewportDimensions();
                this.width = a.x;
                this.height = a.y
            }
        },
        _isSnowlift: function() {
            return this.version === h.SNOWLIFT
        },
        setLogFbids: function(a) {
            this.logIds = a
        },
        setTopLevelPostId: function(a) {
            this.topLevelPostId = a
        },
        setStoryLocation: function(a) {
            this.storyLocation = a
        },
        setStoryAttachmentStyle: function(a) {
            this.storyAttachmentStyle = a
        },
        setAttachedStoryAttachmentStyle: function(a) {
            this.attachedStoryAttachmentStyle = a
        },
        setQid: function(a) {
            this.qid = a
        },
        setMfStoryKey: function(a) {
            this.mfStoryKey = a
        },
        setPageInsightsData: function(a) {
            this.pageInsightsData = a
        },
        setEid: function(a) {
            this.eid = a
        },
        setPhotoSet: function(a) {
            this.set = a
        },
        addButtonLike: function() {
            this.buttonLikes++
        },
        setPagingAction: function(a) {
            this.pagingAction = a
        },
        setCycle: function(a) {
            this.cycle = a
        },
        setEndOfRelevant: function(a) {
            this.endOfRelevant = a
        },
        setRelevantCount: function(a) {
            this.relevantCount = a
        },
        setEndMetrics: function(a) {
            this.endMetrics = a
        },
        setSource: function(a) {
            this.source = a
        },
        addPhotoView: function(a, b, c) {
            this.logIds && this.views >= this.AGGREGATION_COUNT && this.logPhotoViews(this.AGGREGATE), this.updateLastFbidDuration(), this.views++, a && this.fbidList.push([a.fbid, a.owner, Date.now()]), b && this.hiResLoads++, c && (this.fullScreenViews[a.fbid] = !0)
        },
        updateLastFbidDuration: function() {
            this.updateDuration(), this.fbidList.length > 0 && this.fbidList[this.fbidList.length - 1].push(this.currentDuration), this.updateLastVisibleTime(), this.currentDuration = 0
        },
        updateDuration: function() {
            this.currentDuration += Date.now() - this.lastVisibleStart
        },
        updateLastVisibleTime: function() {
            this.lastVisibleStart = Date.now()
        },
        logEnterFullScreen: function(a) {
            this.fullScreenViews[a] = !0
        },
        addDetailData: function(a, b) {
            this.details[a] || (this.details[a] = {
                t: b.num_tags,
                l: b.has_location,
                c: b.has_caption,
                cm: b.comment_count,
                lk: b.like_count,
                w: b.width,
                h: b.height,
                ad: "{}",
                p: this.pagingAction
            })
        },
        updateAdData: function(a, b) {
            this.details[a] && (this.details[a].ad = JSON.stringify(b))
        },
        logPhotoViews: function(a) {
            if (!this.views) return;
            this.updateLastFbidDuration();
            a != this.AGGREGATE && (this.last = !0);
            this.logData(a ? a : this.UNKNOWN);
            this.views = 0;
            this.hiResLoads = 0;
            this.fbidList = [];
            this.details = {};
            this.first = !1;
            this.buttonLikes = 0;
            this.last && (this.set = null, this.logIds = !1, this.fullScreenViews = {})
        },
        logInitialLoad: function() {
            this.logData(h.LOADING)
        },
        logData: function(a) {
            var c = [],
                d = {},
                e = 0;
            a === this.LOADING ? (e = this.topLevelPostId, this.topLevelPostId || (c = this.fbidList, d = this.details)) : (c = this.fbidList, d = this.details);
            c = {
                set: this.set,
                time: new Date() - this.time,
                fbids: c,
                details: d,
                eid: this.eid,
                first: this.first,
                last: this.last,
                close: a,
                button_likes: this.buttonLikes,
                version: this.version,
                endmetric: this.endMetrics,
                cycle: this.cycle,
                end_relev: this.endOfRelevant,
                relev_count: this.relevantCount,
                source: this.source,
                top_level_post_id: e,
                story_location: this.storyLocation,
                story_attachment_style: this.storyAttachmentStyle,
                attached_story_attachment_style: this.attachedStoryAttachmentStyle,
                qid: this.qid,
                mf_story_key: this.mfStoryKey,
                page_insights: this.pageInsightsData
            };
            if (this.version === h.SNOWLIFT) {
                d = b("Vector").getViewportDimensions();
                c.width = d.x || this.width;
                c.height = d.y || this.height;
                this.hiResLoads > 0 && (c.hires_loads = this.hiResLoads);
                if (this.last) {
                    e = Object.keys(this.fullScreenViews).length;
                    e > 0 && (c.fullscreen = e)
                }
            }
            d = new(g || (g = b("URI")))(b("WWWBase").uri).setPath("/ajax/photos/logging/session_logging.php");
            new(b("AsyncRequest"))().setAllowCrossPageTransition(!0).setURI(d).setOption("asynchronous_DEPRECATED", a != h.UNLOAD).setOption("suppressErrorHandlerWarning", !0).setData(c).send()
        }
    });
    b("Run").onUnload(function() {
        h.logPhotoViews(h.UNLOAD)
    });
    b("Run").onLeave(function() {
        h.logPhotoViews(h.LEAVE)
    });
    e.exports = h
}), null);
__d("PhotoTagApproval", ["Arbiter", "CSS", "DOM", "Event", "Parent", "PhotosConst", "ge"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a(a) {
            var c = this;
            this.viewer = a;
            this.units = [];
            this.currentUnit = 0;
            var d = a.getVersionConst();
            d == b("PhotosConst").VIEWER_SNOWLIFT ? this._root = b("ge")("fbPhotoSnowliftTagApproval") : this._root = b("ge")("fbPhotoPageTagApproval");
            b("Arbiter").subscribe(a.getEventString("DATA_CHANGE"), this.restartTagApproval.bind(this));
            b("Arbiter").subscribe("PhotoTagApproval.PENDING_TAG_PHOTO_CLICK", this.pendingTagPhotoClick.bind(this));
            b("Event").listen(this._root, "click", this.handleClick.bind(this));
            b("Event").listen(this._root, "mousemove", function(a) {
                c.hiliteCurrentPendingTag(), b("Event").kill(a)
            });
            this.restartTagApproval()
        }
        var c = a.prototype;
        c.handleClick = function(a) {
            a = a.getTarget();
            if (b("CSS").hasClass(a, "nextPager") && b("CSS").hasClass(a, "enabled")) this.showNextUnit();
            else if (b("CSS").hasClass(a, "prevPager") && b("CSS").hasClass(a, "enabled")) this.showPrevUnit();
            else if (b("Parent").byClass(a, "fbPhotoApprovalPendingButtons")) {
                var c = this.units[this.currentUnit];
                c = this.getTagNameID(c);
                if (c) {
                    a = b("Parent").byClass(a, "approve");
                    b("Arbiter").inform("PhotoTagApproval.UPDATE_TAG_BOX", {
                        id: c,
                        approve: a,
                        version: this.viewer.getVersionConst()
                    })
                }
                setTimeout(this.removeSelectedUnit.bind(this), 0)
            }
            return !0
        };
        c.loadUnits = function(a) {
            this.units = b("DOM").scry(this._root, "div.fbPhotoApprovalUnit"), this.units.length ? (b("CSS").show(this._root), this.showUnit(a), b("CSS").conditionClass(this._root, "hidePagers", this.units.length == 1)) : (b("CSS").hide(this._root), b("Arbiter").inform("PhotoTagApproval.HILITE_TAG", {
                tag: null,
                version: this.viewer.getVersionConst()
            }))
        };
        c.restartTagApproval = function() {
            this.loadUnits(0)
        };
        c.pendingTagPhotoClick = function(a, c) {
            if (c.version !== b("PhotosConst").VIEWER_PERMALINK && c.version !== b("PhotosConst").VIEWER_SNOWLIFT) return !0;
            a = "approve:" + c.id;
            for (var c = 0; c < this.units.length; c++)
                if (this.units[c].id === a) {
                    this.showUnit(c);
                    return !1
                }
            return !0
        };
        c.removeSelectedUnit = function() {
            var a = this.units[this.currentUnit];
            b("DOM").remove(a);
            this.loadUnits(this.currentUnit)
        };
        c.showNextUnit = function() {
            this.showUnit(this.currentUnit + 1)
        };
        c.showPrevUnit = function() {
            this.showUnit(this.currentUnit - 1)
        };
        c.getTagNameID = function(a) {
            var b = a.id.indexOf(":");
            return a.id.slice(b + 1)
        };
        c.showUnit = function(a) {
            var c;
            this.units.forEach((c = b("CSS")).hide);
            this.currentUnit = (a + this.units.length) % this.units.length;
            a = this.units[this.currentUnit];
            c.show(a);
            this.hiliteCurrentPendingTag();
            c.conditionClass(b("DOM").find(this._root, "a.prevPager"), "enabled", this.currentUnit > 0);
            c.conditionClass(b("DOM").find(this._root, "a.nextPager"), "enabled", this.currentUnit < this.units.length - 1)
        };
        c.hiliteCurrentPendingTag = function() {
            var a = this.units[this.currentUnit];
            a = this.getTagNameID(a);
            b("Arbiter").inform("PhotoTagApproval.HILITE_TAG", {
                tag: a,
                version: this.viewer.getVersionConst()
            })
        };
        return a
    }();
    e.exports = a
}), null);
__d("PhotoTagStore", ["ActorURI", "AsyncRequest", "ThisControllerNoLongerExists", "isEmpty"], (function(a, b, c, d, e, f) {
    var g;
    a = function() {
        "use strict";

        function a() {
            this._tagList = {}, this._textTagList = {}, this._originalTagList = {}, this._dirtyPhotosByUid = {}, a.instance = this
        }
        var c = a.prototype;
        c.getPhotoTags = function(a) {
            return this._tagList[a] || {}
        };
        c.photoHasTags = function(a) {
            return !(g || (g = b("isEmpty")))(this.getPhotoTags(a))
        };
        c.clear = function() {
            this._tagList = {}, this._textTagList = {}, this._originalTagList = {}, this._dirtyPhotosByUid = {}
        };
        c.addTag = function(a, b, c, d) {
            a[b] = a[b] || {};
            var e = a[b][c] || [];
            e.push(d);
            a[b][c] = e
        };
        c.revert = function(a) {
            var c = this._tagList,
                d = this._originalTagList;
            for (var e in c)(g || (g = b("isEmpty")))(d[e][a]) ? c[e][a] = [] : c[e][a] = d[e][a];
            this._dirtyPhotosByUid = {}
        };
        c.hasNewTags = function() {
            return !(g || (g = b("isEmpty")))(this._tagList) || !(g || (g = b("isEmpty")))(this._textTagList)
        };
        c.userHasDirtyTags = function(a) {
            return !(g || (g = b("isEmpty")))(this._dirtyPhotosByUid[a])
        };
        c.userDirtyTagsCount = function(a) {
            return Object.keys(this._dirtyPhotosByUid[a]).length
        };
        c.handleTagFetch = function(a) {
            for (var b in a) this.loadTagInfo(b, a[b])
        };
        c.saveAlbumTagsForUser = function(a, c, d, e) {
            e === void 0 && (e = !1);
            var f = {},
                h = [],
                i = this._dirtyPhotosByUid[a] || {};
            for (var j in i) {
                i = this._tagList[j][a];
                if ((g || (g = b("isEmpty")))(i)) {
                    h[h.length] = j;
                    continue
                }
                i.forEach(function(a) {
                    f[j] = {
                        x: a.x,
                        y: a.y
                    }
                })
            }
            i = {
                subject: a,
                action: "save",
                save_tags: f
            };
            h = b("ActorURI").create("/ajax/photos/album/tags.php", c);
            e && (i = {
                subject: a,
                save_tags: JSON.stringify(f)
            }, h = b("ThisControllerNoLongerExists").__DEADURI__("m9fhmxosp"));
            new(b("AsyncRequest"))().setURI(h).setData(i).setHandler(function(a) {
                d(a.payload)
            }).setAllowCrossPageTransition(!0).send();
            delete this._dirtyPhotosByUid[a]
        };
        c.getTagsFromList = function(a) {
            var b = [];
            for (var c in a)
                if (Object.prototype.hasOwnProperty.call(a, c))
                    for (var d in a[c]) Object.prototype.hasOwnProperty.call(a[c], d) && a[c][d].forEach(function(a) {
                        return b.push(a)
                    });
            return b
        };
        c.getAllTags = function() {
            var a = this.getTagsFromList(this._tagList),
                b = this.getTagsFromList(this._textTagList);
            return a.concat(b)
        };
        c.removeTag = function(a, c) {
            var d = this._tagList[a],
                e = this._originalTagList[a] || {};
            e[c] ? (this._dirtyPhotosByUid[c] = this._dirtyPhotosByUid[c] || {}, this._dirtyPhotosByUid[c][a] = !0) : delete this._dirtyPhotosByUid[c][a];
            for (var e in d)
                if (e == c) {
                    d = this._tagList[a][e];
                    delete this._tagList[a][e];
                    (g || (g = b("isEmpty")))(this._tagList[a]) && delete this._tagList[a];
                    return d
                }
        };
        c.removeTextTag = function(a, c) {
            var d = this._textTagList[a];
            if (!(g || (g = b("isEmpty")))(d[c])) {
                d = this._textTagList[a][c];
                this._textTagList[a][c] = [];
                (g || (g = b("isEmpty")))(this._textTagList[a]) && delete this._textTagList[a];
                return d
            }
            return []
        };
        c.removeAllNewTagsOfUser = function(a) {
            var b = [];
            if (!this.userHasDirtyTags(a)) return b;
            var c = this._dirtyPhotosByUid[a];
            for (var c in c) b = b.concat(this.removeTag(c, a));
            return b
        };
        c.removeAllTagsFromPhoto = function(a) {
            var c = [];
            if (!(g || (g = b("isEmpty")))(this._tagList[a]))
                for (var d in this._tagList[a]) {
                    if (!Object.prototype.hasOwnProperty.call(this._tagList[a], d)) continue;
                    c = c.concat(this.removeTag(a, d))
                }
            if (!(g || (g = b("isEmpty")))(this._textTagList[a]))
                for (var d in this._textTagList[a]) {
                    if (!Object.prototype.hasOwnProperty.call(this._textTagList[a], d)) continue;
                    c = c.concat(this.removeTextTag(a, d))
                }
            return c
        };
        c.storeTag = function(a, b, c, d, e) {
            this.storeTagWithOptions(a, b, c, d, {
                can_remove: e
            })
        };
        c.storeTagWithOptions = function(a, b, c, d, e) {
            this._dirtyPhotosByUid[b] = this._dirtyPhotosByUid[b] || {};
            this._dirtyPhotosByUid[b][a] = !0;
            c = {
                x: c,
                y: d
            };
            Object.assign(c, e);
            !b ? this.addTag(this._textTagList, a, c.name, c) : this.addTag(this._tagList, a, b, c)
        };
        c.loadTagInfo = function(a, b) {
            this._tagList[a] = {};
            this._originalTagList[a] = {};
            for (var c = 0; c < b.length; c++) {
                var d = b[c];
                this.addTag(this._tagList, a, d.subject, d);
                this.addTag(this._originalTagList, a, d.subject, d)
            }
        };
        a.getInstance = function() {
            a.instance === null && new a();
            return a.instance
        };
        return a
    }();
    a.instance = null;
    e.exports = a
}), null);
__d("PhotosTaggingWaterfall", ["AsyncSignal"], (function(a, b, c, d, e, f) {
    function g(a) {
        g._queueName = a || g._queueName
    }
    Object.assign(g, {
        BEGIN: "begin",
        TAG_FACE: "tag_face",
        HOVER_TAG_FACE: "hover_tag_face",
        SHOW_SUGGEST: "show_suggest",
        ADD_NAME: "add_name",
        TAG_CONFIRMED: "tag_confirmed",
        FINISH: "finish",
        TYPE_NAME: "type_name",
        SELECT_NAME: "select_name",
        _queueName: null,
        sendSignal: function(a, c) {
            new(b("AsyncSignal"))("/ajax/photos/tag_waterfall.php", {
                data: JSON.stringify(a)
            }).setHandler(c).send()
        }
    });
    e.exports = g
}), null);
__d("PhotosUtils", ["Vector"], (function(a, b, c, d, e, f, g) {
    function a() {}
    Object.assign(a, {
        getNearestBox: function(a, b) {
            var c = Infinity,
                d = null;
            for (var e in a) {
                var f = a[e];
                if (f.contains(b)) {
                    f = b.distanceTo(f.getCenter());
                    f < c && (c = f, d = e)
                }
            }
            return d
        },
        absoluteToNormalizedPosition: function(a, b) {
            var d = c("Vector").getElementPosition(a);
            a = c("Vector").getElementDimensions(a);
            b = b.sub(d).mul(100 / a.x, 100 / a.y);
            b.domain = "pure";
            return b
        },
        normalizedToAbsolutePosition: function(a, b) {
            var d = c("Vector").getElementPosition(a);
            a = c("Vector").getElementDimensions(a);
            b = b.mul(a.x / 100, a.y / 100).add(d);
            b.domain = "document";
            return b
        },
        isFacebox: function(a) {
            return a.match(/^face:/)
        },
        isTag: function(a) {
            return a.match(/^tag:/)
        }
    });
    g["default"] = a
}), 98);
__d("PhotoPermalinkURI", ["FBLogger"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return h(a) !== null
    }

    function h(a) {
        if (i(a)) {
            var b = a.getQueryData();
            if (Boolean(b.fbid)) return {
                photo_id: String(b.fbid),
                set_token: b.set != null ? String(b.set) : null
            };
            if (Boolean(b.id) && Boolean(b.pid)) {
                c("FBLogger")("photos", "PhotoPermalinkURI_js").warn("Legacy PID usage in PhotoPermalinkURI.js");
                return {
                    photo_id: String(b.id) + ":" + String(b.pid),
                    set_token: b.set != null ? String(b.set) : null
                }
            }
            return null
        }
        b = a.getPath();
        b[b.length - 1] === "/" && (b = b.substring(0, b.length - 1));
        a = b.split("/");
        if (a.length >= 3 && a[2] === "photos")
            if (a.length === 4 && /^\d+$/.exec(a[3]) !== null) return {
                photo_id: a[3],
                set_token: null
            };
            else if (a.length === 5 && /^\d+$/.exec(a[4]) !== null) return {
            photo_id: a[4],
            set_token: a[3]
        };
        return null
    }

    function i(a) {
        a = a.getPath();
        a[a.length - 1] === "/" && (a = a.substring(0, a.length - 1));
        return a === "/photo.php" || a === "/force_photo/photo.php" || a === "/photo" || a === "/force_photo/photo/index.php" || a === "/photo/index.php" || a === "/force_photo/photo" || a === "/video.php" || a === "/video/video.php" ? !0 : !1
    }
    g.isValid = a;
    g.parse = h;
    g.isValidLegacy = i
}), 98);
__d("PhotosetSearchPivot.react", ["cx", "fbt", "LeftRight.react", "PhotosetSearchPivotData", "XUISpinner.react", "XUIText.react", "createReactClass_DEPRECATED", "joinClasses", "prop-types", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i || b("react"),
        k = function(c) {
            babelHelpers.inheritsLoose(a, c);

            function a() {
                return c.apply(this, arguments) || this
            }
            var d = a.prototype;
            d.render = function() {
                return j.jsx("div", {
                    className: "_25r",
                    children: j.jsxs("a", {
                        href: this.props.uri,
                        className: "_25t _3-8t",
                        children: [j.jsxs("div", {
                            className: "_25u",
                            children: [j.jsx("div", {
                                className: "_25v _25w",
                                style: {
                                    backgroundImage: "url(" + this.props.images[0].uri + ")"
                                }
                            }), j.jsxs("div", {
                                className: "_25x",
                                children: [j.jsxs("div", {
                                    className: "_25y",
                                    children: [j.jsx("div", {
                                        className: "_25z"
                                    }), j.jsx("div", {
                                        className: "_26r",
                                        children: j.jsx("div", {
                                            className: "_273 _25w",
                                            style: {
                                                backgroundImage: "url(" + this.props.images[1].uri + ")"
                                            }
                                        })
                                    })]
                                }), j.jsxs("div", {
                                    className: "_274",
                                    children: [j.jsx("div", {
                                        className: "_25z"
                                    }), j.jsx("div", {
                                        className: "_26r",
                                        children: j.jsx("div", {
                                            className: "_273 _25w",
                                            style: {
                                                backgroundImage: "url(" + this.props.images[2].uri + ")"
                                            }
                                        })
                                    })]
                                })]
                            })]
                        }), j.jsx(b("XUIText.react"), {
                            display: "block",
                            className: "_27f _2pi4",
                            dangerouslySetInnerHTML: {
                                __html: this.props.title.__html
                            }
                        })]
                    })
                })
            };
            return a
        }(j.Component);
    k.propTypes = {
        normalized: b("prop-types").string,
        title: b("prop-types").object,
        uri: b("prop-types").string,
        images: b("prop-types").array
    };
    a = b("createReactClass_DEPRECATED")({
        displayName: "PhotosetSearchPivot",
        propTypes: {
            fbid: b("prop-types").string,
            endofalbum: b("prop-types").bool,
            withBackground: b("prop-types").bool,
            linesAroundHeader: b("prop-types").bool,
            onclose: b("prop-types").func
        },
        fetchPivots: function(a) {
            var c = this;
            b("PhotosetSearchPivotData").fetch(a).then(function(b) {
                setTimeout(c.onFetchSuccess.bind(c, a, b.pivots), 0)
            }, function(b) {
                setTimeout(c.onFetchError.bind(c, a), 0)
            })
        },
        onFetchSuccess: function(a, b) {
            if (!this.isMounted() || this.props.fbid !== a) return;
            b = b || [];
            a = "show";
            b.length === 0 && (a = "hide");
            this.setState({
                pivots: b,
                action: a
            })
        },
        onFetchError: function(a) {
            if (!this.isMounted() || this.props.fbid !== a) return;
            this.setState({
                pivots: [],
                action: "hide"
            })
        },
        getInitialState: function() {
            this.fetchPivots(this.props.fbid);
            return {
                pivots: [],
                action: "loading"
            }
        },
        UNSAFE_componentWillReceiveProps: function(a) {
            a.fbid ? (this.setState({
                action: "loading"
            }), this.fetchPivots(a.fbid)) : this.setState({
                action: "hide",
                pivots: []
            })
        },
        onExitClicked: function() {
            this.props.onclose()
        },
        render: function() {
            if (this.state.action === "loading") return j.jsx("div", {
                className: b("joinClasses")(this.props.className, "_27h _2ph_"),
                children: j.jsx(b("XUISpinner.react"), {
                    size: "large"
                })
            });
            if (this.state.action === "hide") return j.jsx("span", {});
            var a = this.state.pivots.map(function(a) {
                    return j.jsx(k, {
                        normalized: a.normalized,
                        title: a.title,
                        uri: a.uri,
                        images: a.images
                    })
                }),
                c = this.props.endofalbum ? j.jsx("span", {
                    className: "_2pij",
                    children: h._("End of album")
                }) : null,
                d = "_27m _2pi3 _2pib" + (this.props.linesAroundHeader ? " _3-te" : "");
            c = j.jsxs("span", {
                children: [c, j.jsx("span", {
                    className: "_4ptz",
                    children: h._("Other photos you may like")
                })]
            });
            this.props.onclose ? c = j.jsxs(b("LeftRight.react"), {
                className: d,
                children: [c, j.jsx("a", {
                    href: "#",
                    onClick: this.onExitClicked,
                    className: "_27n"
                })]
            }) : c = j.jsx("div", {
                className: d,
                children: c
            });
            return j.jsx("div", {
                className: b("joinClasses")(this.props.className, (this.state.action === "hide" ? "_27j" : "") + (this.state.action === "show" ? " _27k" : "")),
                children: j.jsxs("div", {
                    className: "_27l" + (this.props.withBackground ? " _3-tf" : ""),
                    children: [c, j.jsx("div", {
                        className: "_27o _2pi8 clearfix",
                        children: a
                    })]
                })
            })
        }
    });
    e.exports = a
}), null);
__d("PhotosetPivotSlide.react", ["cx", "fbt", "ix", "xuiglyph", "Image.react", "Link.react", "PhotosetSearchPivot.react", "XUIText.react", "prop-types", "react"], (function(a, b, c, d, e, f, g, h, i, j, k) {
    var l = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = d = a.call.apply(a, [this].concat(f)) || this, d.$1 = function() {
                if (d.props.albumOwnerName)
                    if (d.props.isAlbum) return i._("End of {user_name}'s album", [i._param("user_name", l.jsx(c("XUIText.react"), {
                        weight: "bold",
                        children: d.props.albumOwnerName
                    }))]);
                    else return i._("End of {user_name}'s photos", [i._param("user_name", l.jsx(c("XUIText.react"), {
                        weight: "bold",
                        children: d.props.albumOwnerName
                    }))]);
                else if (d.props.isAlbum) return i._("End of album");
                else return i._("End of photos")
            }, b) || babelHelpers.assertThisInitialized(d)
        }
        var d = b.prototype;
        d.render = function() {
            return l.jsxs("div", {
                className: "_1_ap" + (this.props.visible ? " _1_aq" : ""),
                children: [l.jsxs("div", {
                    className: "_1_ar",
                    children: [l.jsx(c("XUIText.react"), {
                        display: "block",
                        children: this.$1()
                    }), l.jsxs(c("Link.react"), {
                        className: "_1_as",
                        onClick: this.props.onReturn,
                        children: [l.jsx(c("Image.react"), {
                            className: "_1_at",
                            src: j("88724")
                        }), i._("Return to beginning")]
                    })]
                }), l.jsx(c("PhotosetSearchPivot.react"), {
                    className: "_1_au",
                    fbid: this.props.visible ? this.props.fbid : null,
                    linesAroundHeader: !0
                })]
            })
        };
        return b
    }(l.Component);
    a.propTypes = {
        fbid: c("prop-types").string,
        isAlbum: c("prop-types").bool,
        albumOwnerName: c("prop-types").string,
        visible: c("prop-types").bool,
        onReturn: c("prop-types").func
    };
    g["default"] = a
}), 98);
__d("DisableContextMenuMixin", ["Event", "emptyFunction"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("emptyFunction");
    c = {
        getContextMenuContainer: a,
        _contextMenuEventHandler: null,
        disableContextMenu: function() {
            if (this._contextMenuEventHandler) return;
            this._contextMenuEventHandler = b("Event").listen(this.getContextMenuContainer(), "contextmenu", function(a) {
                a.preventDefault(), a.stopPropagation()
            })
        },
        enableContextMenu: function() {
            this._contextMenuEventHandler && (this._contextMenuEventHandler.remove(), this._contextMenuEventHandler = null)
        }
    };
    e.exports = c
}), null);
__d("LikeConfirmer", ["AsyncDialog", "AsyncRequest"], (function(a, b, c, d, e, f) {
    var g = !1,
        h = !1;
    a = {
        likeContent: function() {},
        like: function(a, c) {
            var d = this;
            this.likeContent = a;
            if (h) return;
            if (g) this.likeContent();
            else {
                a = new(b("AsyncRequest"))().setURI("/like/confirm_like.php").setRelativeTo(c);
                b("AsyncDialog").send(a, function(a) {
                    h = !0, a.subscribe("hide", d.onCloseLikeConfirmDialog.bind(d)), a.setCausalElement(c)
                })
            }
            return !1
        },
        isShowingConfirmation: function() {
            return h
        },
        onCloseLikeConfirmDialog: function() {
            h = !1
        },
        likeSkipConfirmation: function(a) {
            g = a, this.likeContent()
        }
    };
    e.exports = a
}), null);
__d("ObjectionableContentFilterMixin", ["csx", "cx", "CSS", "DOM", "emptyFunction"], (function(a, b, c, d, e, f, g, h) {
    a = b("emptyFunction");
    c = {
        getObjectionableWarningContainer: a,
        getObjectionableWarningHiddenContent: a,
        _objectionableWarningMarkup: null,
        _objectionableWarningOverlay: null,
        _objectionableWarningHiddenContentWrapper: null,
        _objectionableWarningHiddenContent: null,
        showObjectionableWarning: function(a) {
            var c = "._f_2",
                d = "._f_g";
            this._objectionableWarningMarkup && this.hideObjectionableWarning();
            this._objectionableWarningOverlay = b("DOM").scry(a, c).pop();
            this._objectionableWarningHiddenContentWrapper = b("DOM").scry(a, d).pop();
            this._objectionableWarningOverlay && b("CSS").show(this._objectionableWarningOverlay);
            this._objectionableWarningHiddenContentWrapper && (this.getObjectionableWarningContainer().replaceChild(a, this.getObjectionableWarningHiddenContent()), this._objectionableWarningHiddenContentWrapper.appendChild(this.getObjectionableWarningHiddenContent()), b("CSS").addClass(a, "_dbl"));
            this._objectionableWarningMarkup = a;
            this._objectionableWarningHiddenContent = this.getObjectionableWarningHiddenContent()
        },
        hideObjectionableWarning: function() {
            if (!this.getObjectionableWarningContainer().contains(this._objectionableWarningMarkup)) return;
            this.getObjectionableWarningContainer().replaceChild(this._objectionableWarningHiddenContent, this._objectionableWarningMarkup)
        }
    };
    e.exports = c
}), null);
__d("PhotoSnowliftBackLink.react", ["cx", "prop-types", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.render = function() {
            return i.jsx("a", {
                className: "_1cac" + (this.props.visible ? " _1cad" : ""),
                href: this.props.href,
                children: this.props.name
            })
        };
        return b
    }(i.Component);
    a.propTypes = {
        href: c("prop-types").string,
        name: c("prop-types").string,
        visible: c("prop-types").bool
    };
    g["default"] = a
}), 98);
__d("PhotoSnowliftViewable", ["cx", "CSS", "DOM", "EventEmitter", "Vector"], (function(a, b, c, d, e, f, g, h) {
    var i = 2e3;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, d) {
            var e;
            b === void 0 && (b = i);
            d === void 0 && (d = 1);
            e = a.call(this) || this;
            e.$PhotoSnowliftViewable5 = c("DOM").create("div", {
                className: "_2-sx"
            });
            e.$PhotoSnowliftViewable4 = b;
            e.$PhotoSnowliftViewable3 = d;
            e.$PhotoSnowliftViewable1 = null;
            e.$PhotoSnowliftViewable2 = 0;
            e.$PhotoSnowliftViewable6();
            setTimeout(function() {
                return e.whenReady(function() {
                    return e.$PhotoSnowliftViewable7()
                })
            }, 0);
            return e
        }
        var e = b.prototype;
        e.$PhotoSnowliftViewable6 = function() {
            var a = this;
            this.$PhotoSnowliftViewable1 = setTimeout(function() {
                return a.$PhotoSnowliftViewable8()
            }, this.$PhotoSnowliftViewable4)
        };
        e.$PhotoSnowliftViewable8 = function() {
            if (this.isReady()) return;
            this.$PhotoSnowliftViewable2 < this.$PhotoSnowliftViewable3 ? (this.reload(), this.$PhotoSnowliftViewable2++, this.$PhotoSnowliftViewable6()) : this.emit("loadingfailed")
        };
        e.reload = function() {};
        e.$PhotoSnowliftViewable7 = function() {
            this.$PhotoSnowliftViewable1 !== null && (clearTimeout(this.$PhotoSnowliftViewable1), this.$PhotoSnowliftViewable1 = null)
        };
        e.getElement = function() {
            return this.$PhotoSnowliftViewable5
        };
        e.show = function() {
            d("CSS").show(this.getElement())
        };
        e.hide = function() {
            d("CSS").hide(this.getElement())
        };
        e.suspend = function() {};
        e.resume = function() {};
        e.onToggleIntoFullScreen = function() {};
        e.onToggleOutOfFullScreen = function() {};
        e.onEnterFullScreen = function() {};
        e.onExitFullScreen = function() {};
        e.getNaturalDimensions = function() {
            return this.getDimensions()
        };
        e.getDimensions = function() {
            return c("Vector").getElementDimensions(this.getElement())
        };
        e.setDimensions = function(a) {
            var b = this.getElement();
            b.style.width = a.x + "px";
            b.style.height = a.y + "px"
        };
        e.isReady = function() {
            throw new Error("Viewable has no concept of readiness - should be calling a subclass")
        };
        e.whenReady = function(a) {
            this.isReady() ? setTimeout(a, 0) : this.once("ready", a)
        };
        return b
    }(c("EventEmitter"));
    g["default"] = a
}), 98);
__d("PhotoSnowliftViewableImageWrapper", ["Event", "ImageUtils", "PhotoSnowliftViewable", "TimeSlice", "Vector"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            var d;
            d = a.call(this) || this;
            d.$PhotoSnowliftViewableImageWrapper1 = b;
            d.getElement().appendChild(b);
            if (d.$PhotoSnowliftViewableImageWrapper1.complete) d.$PhotoSnowliftViewableImageWrapper2();
            else {
                b = c("TimeSlice").getGuardedContinuation("PhotoSnowLiftViewable photo load");
                c("Event").listen(d.$PhotoSnowliftViewableImageWrapper1, "load", b.bind(null, function() {
                    return d.$PhotoSnowliftViewableImageWrapper2()
                }))
            }
            return d
        }
        var e = b.prototype;
        e.$PhotoSnowliftViewableImageWrapper2 = function() {
            this.emit("ready")
        };
        e.isReady = function() {
            return d("ImageUtils").hasLoaded(this.$PhotoSnowliftViewableImageWrapper1)
        };
        e.getNaturalDimensions = function() {
            return this.$PhotoSnowliftViewableImageWrapper1 && this.$PhotoSnowliftViewableImageWrapper1.naturalWidth && this.$PhotoSnowliftViewableImageWrapper1.naturalHeight ? c("Vector").from(this.$PhotoSnowliftViewableImageWrapper1.naturalWidth, this.$PhotoSnowliftViewableImageWrapper1.naturalHeight) : a.prototype.getNaturalDimensions.call(this)
        };
        return b
    }(c("PhotoSnowliftViewable"));
    g["default"] = a
}), 98);
__d("PhotoSnowliftViewablePhoto", ["Bootloader", "DOM", "EncryptedImg", "Event", "ImageUtils", "PhotoSnowliftViewable", "TimeSlice", "Vector"], (function(a, b, c, d, e, f, g) {
    function h(a, b) {
        if (a.src && a.complete) setTimeout(b, 0);
        else var d = c("Event").listen(a, "load", function() {
            d.remove(), b()
        })
    }

    function i(a, b) {
        c("EncryptedImg").isEncrypted(b) ? c("EncryptedImg").insertIntoDOM(b, a) : a.src = b
    }
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d, e, f, g, h, i, j) {
            var k;
            d === void 0 && (d = !1);
            g === void 0 && (g = !1);
            h === void 0 && (h = !1);
            j === void 0 && (j = !1);
            k = a.call(this) || this;
            k.$PhotoSnowliftViewablePhoto2 = e;
            k.$PhotoSnowliftViewablePhoto7 = b;
            k.$PhotoSnowliftViewablePhoto6 = c;
            k.$PhotoSnowliftViewablePhoto3 = d;
            k.$PhotoSnowliftViewablePhoto1 = i;
            k.$PhotoSnowliftViewablePhoto8 = f;
            k.$PhotoSnowliftViewablePhoto9 = g;
            k.$PhotoSnowliftViewablePhoto10 = h;
            k.$PhotoSnowliftViewablePhoto11 = j;
            k.addListener("imageloaded", function(a) {
                return k.$PhotoSnowliftViewablePhoto13(a)
            });
            k.$PhotoSnowliftViewablePhoto14();
            return k
        }
        var e = b.prototype;
        e.$PhotoSnowliftViewablePhoto14 = function() {
            var a = this;
            this.$PhotoSnowliftViewablePhoto4 && this.$PhotoSnowliftViewablePhoto4.parentElement && this.$PhotoSnowliftViewablePhoto4.parentElement.removeChild(this.$PhotoSnowliftViewablePhoto4);
            var b = c("DOM").create("img", {
                className: "spotlight",
                alt: this.$PhotoSnowliftViewablePhoto1
            });
            this.$PhotoSnowliftViewablePhoto2 && this.$PhotoSnowliftViewablePhoto2.setElementDimensions(b);
            this.$PhotoSnowliftViewablePhoto4 = b;
            this.$PhotoSnowliftViewablePhoto4.setAttribute("aria-busy", "true");
            this.getElement().appendChild(this.$PhotoSnowliftViewablePhoto4);
            this.$PhotoSnowliftViewablePhoto12 = c("TimeSlice").getGuardedContinuation("PhotoSnowliftViewable image load");
            this.$PhotoSnowliftViewablePhoto15(this.$PhotoSnowliftViewablePhoto16());
            h(this.$PhotoSnowliftViewablePhoto4, this.$PhotoSnowliftViewablePhoto12.bind(void 0, function() {
                a.emit("imageloaded", b)
            }));
            this.whenReady(function() {
                return a.$PhotoSnowliftViewablePhoto17()
            });
            this.$PhotoSnowliftViewablePhoto18();
            this.$PhotoSnowliftViewablePhoto19()
        };
        e.$PhotoSnowliftViewablePhoto19 = function() {
            var a = this;
            this.$PhotoSnowliftViewablePhoto10 && !this.$PhotoSnowliftViewablePhoto9 && c("Bootloader").loadModules(["PhotoSnowliftViewableWithContextMenuLogging"], function(b) {
                b = b.setupContextMenuLogging;
                b(a.getElement(), a.$PhotoSnowliftViewablePhoto8)
            }, "PhotoSnowliftViewablePhoto")
        };
        e.$PhotoSnowliftViewablePhoto18 = function() {
            var a = this;
            if (!this.$PhotoSnowliftViewablePhoto11) return;
            c("Bootloader").loadModules(["PhotoSnowliftViewableWithShieldIconOverlay"], function(b) {
                b = b.setupShieldIconOverlay;
                b(a.getElement())
            }, "PhotoSnowliftViewablePhoto")
        };
        e.$PhotoSnowliftViewablePhoto15 = function(a) {
            this.$PhotoSnowliftViewablePhoto5 = a, i(this.$PhotoSnowliftViewablePhoto4, this.$PhotoSnowliftViewablePhoto5)
        };
        e.$PhotoSnowliftViewablePhoto13 = function(a) {
            if (this.$PhotoSnowliftViewablePhoto4 !== a) return;
            this.emit("ready")
        };
        e.reload = function() {
            this.$PhotoSnowliftViewablePhoto14()
        };
        e.$PhotoSnowliftViewablePhoto16 = function() {
            return this.$PhotoSnowliftViewablePhoto3 ? this.$PhotoSnowliftViewablePhoto7 : this.$PhotoSnowliftViewablePhoto6 || this.$PhotoSnowliftViewablePhoto7
        };
        e.$PhotoSnowliftViewablePhoto17 = function() {
            this.$PhotoSnowliftViewablePhoto4.setAttribute("aria-busy", "false")
        };
        e.isReady = function() {
            return this.$PhotoSnowliftViewablePhoto4.src && d("ImageUtils").hasLoaded(this.$PhotoSnowliftViewablePhoto4)
        };
        e.getNaturalDimensions = function() {
            if (this.$PhotoSnowliftViewablePhoto2) return this.$PhotoSnowliftViewablePhoto2;
            return this.$PhotoSnowliftViewablePhoto4 && this.$PhotoSnowliftViewablePhoto4.naturalWidth && this.$PhotoSnowliftViewablePhoto4.naturalHeight ? c("Vector").from(this.$PhotoSnowliftViewablePhoto4.naturalWidth, this.$PhotoSnowliftViewablePhoto4.naturalHeight) : a.prototype.getNaturalDimensions.call(this)
        };
        e.$PhotoSnowliftViewablePhoto20 = function() {
            return this.$PhotoSnowliftViewablePhoto5 === this.$PhotoSnowliftViewablePhoto7
        };
        e.onToggleIntoFullScreen = function() {
            this.$PhotoSnowliftViewablePhoto20() || this.$PhotoSnowliftViewablePhoto5 !== this.$PhotoSnowliftViewablePhoto7 && i(new Image(), this.$PhotoSnowliftViewablePhoto7)
        };
        e.onEnterFullScreen = function() {
            this.$PhotoSnowliftViewablePhoto20() || this.$PhotoSnowliftViewablePhoto15(this.$PhotoSnowliftViewablePhoto7)
        };
        return b
    }(c("PhotoSnowliftViewable"));
    g["default"] = a
}), 98);
__d("SphericalMediaBootloaded.react", ["cx", "BootloadedComponent.react", "JSResource", "LoadingIndicator.react", "SphericalMediaConstants", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = function(a, b) {
            return i.jsx("div", {
                className: a,
                style: b,
                children: i.jsx(c("LoadingIndicator.react"), {
                    className: "_4qlq",
                    size: "small",
                    color: "white"
                })
            })
        };
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            switch (this.props.componentName) {
                case c("SphericalMediaConstants").COMP_PHOTO_EDIT_THUMB:
                    var a = this.props.loadingElement || j("_7d7", {
                        width: this.props.width,
                        height: this.props.height
                    });
                    return i.jsx(c("BootloadedComponent.react"), babelHelpers["extends"]({
                        bootloadLoader: c("JSResource")("SphericalPhotoEditThumbnail.react").__setRef("SphericalMediaBootloaded.react"),
                        bootloadPlaceholder: a
                    }, this.props));
                case c("SphericalMediaConstants").COMP_PHOTO_VIEWER:
                    a = i.jsx("div", {});
                    return i.jsx(c("BootloadedComponent.react"), babelHelpers["extends"]({
                        bootloadLoader: c("JSResource")("SphericalPhotoViewer.react").__setRef("SphericalMediaBootloaded.react"),
                        bootloadPlaceholder: a
                    }, this.props));
                default:
                    return null
            }
        };
        return b
    }(i.PureComponent);
    g["default"] = a
}), 98);
__d("SphericalMediaGyroOverlay.react", ["cx", "CSS", "joinClasses", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = 800,
        k = function(a, b, c) {
            b === void 0 && (b = !0);
            c === void 0 && (c = !1);
            return {
                gyroRoot: "_1zvy" + (a ? " _2dz7" : "") + (b ? " _4z8s" : "") + (c ? " _4z8p" : ""),
                gyroOuter: "_4z8q",
                gyroInner: "_4z8r",
                gyroMeridian: "_4z8t",
                gyroEquator: "_4z8u",
                gyroTextShell: "_4z8v",
                gyroText: "_4z8w"
            }
        };
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.rootRef = i.createRef(), b) || babelHelpers.assertThisInitialized(c)
        }
        var e = b.prototype;
        e.componentDidUpdate = function(a) {
            var b = this;
            if (a.isActive && !this.props.isActive) setTimeout(function() {
                var a = b.rootRef.current;
                a instanceof Element && d("CSS").hide(a)
            }, j);
            else if (!this.props.isActive) {
                a = this.rootRef.current;
                a instanceof Element && d("CSS").hide(a)
            }
        };
        e.componentDidMount = function() {
            if (!this.props.isActive) {
                var a = this.rootRef.current;
                a instanceof Element && d("CSS").hide(a)
            }
        };
        e.render = function() {
            var a = this.props,
                b = a.className,
                d = a.isActive,
                e = a.isInfinite;
            a = a.isPaused;
            d = k(d, e, a);
            return i.jsx("div", {
                className: c("joinClasses")(b, d.gyroRoot),
                ref: this.rootRef,
                children: i.jsxs("div", {
                    className: d.gyroOuter,
                    children: [i.jsxs("div", {
                        className: d.gyroInner,
                        children: [i.jsx("div", {
                            className: d.gyroMeridian
                        }), i.jsx("div", {
                            className: d.gyroEquator
                        })]
                    }), i.jsx("div", {
                        className: d.gyroTextShell,
                        children: i.jsx("span", {
                            className: d.gyroText,
                            children: "360"
                        })
                    })]
                })
            })
        };
        return b
    }(i.PureComponent);
    g["default"] = a
}), 98);
__d("SphericalPhotoPlaceHolderWithGyroOverlay.react", ["cx", "BackgroundImage.react", "Image.react", "SphericalMediaGyroOverlay.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            return i.jsxs("div", {
                className: "_5nxw _1c1o",
                children: [this.props.showNewRenderer ? i.jsx(c("BackgroundImage.react"), {
                    backgroundSize: "contain",
                    height: this.props.height,
                    src: this.props.placeholderImageURL,
                    width: this.props.width
                }) : i.jsx(c("Image.react"), {
                    className: "_1c1p",
                    height: this.props.height,
                    src: this.props.placeholderImageURL,
                    width: this.props.width
                }), i.jsx(c("SphericalMediaGyroOverlay.react"), {
                    className: "_1c1q",
                    isActive: !0
                })]
            })
        };
        return b
    }(i.PureComponent);
    g["default"] = a
}), 98);
__d("PhotoSnowliftViewableSphericalPhoto", ["cx", "Arbiter", "Bootloader", "CSS", "DOM", "DOMQuery", "PhotoSnowliftViewable", "ReactDOM", "SphericalMediaActions", "SphericalMediaBaseActions", "SphericalMediaBootloaded.react", "SphericalMediaConstants", "SphericalPhotoPlaceHolderWithGyroOverlay.react", "SphericalPhotoTypedConfig", "SubscriptionsHandler", "Vector", "getViewportDimensions", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = 2e3 * 16,
        k = 360;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, e, f, g, h, i, k, l, m, n, o, p, q, r, s) {
            var t;
            l === void 0 && (l = !1);
            t = a.call(this, j) || this;
            t.$PhotoSnowliftViewableSphericalPhoto31 = function(a) {
                var b = a.dispatch;
                a.getState;
                b(d("SphericalMediaBaseActions").updateFeedRootElement(t.$PhotoSnowliftViewableSphericalPhoto5));
                return function(a) {
                    return function(b) {
                        return a(b)
                    }
                }
            };
            t.$PhotoSnowliftViewableSphericalPhoto32 = function(a) {
                var b = a.dispatch,
                    e = a.getState;
                t.$PhotoSnowliftViewableSphericalPhoto15.getTagger() ? b(d("SphericalMediaBaseActions").updateTagger(t.$PhotoSnowliftViewableSphericalPhoto15.getTagger())) : t.$PhotoSnowliftViewableSphericalPhoto19.addSubscriptions(c("Arbiter").subscribe(t.$PhotoSnowliftViewableSphericalPhoto15.getEventString("TAGGER_READY"), function(a, c) {
                    b(d("SphericalMediaBaseActions").updateTagger(t.$PhotoSnowliftViewableSphericalPhoto15.getTagger()))
                }));
                t.$PhotoSnowliftViewableSphericalPhoto19.addSubscriptions(c("Arbiter").subscribe("PhotoTagger.START_TAGGING", function(a, c) {
                    t.$PhotoSnowliftViewableSphericalPhoto22 = !0, b(d("SphericalMediaBaseActions").enterTaggingMode())
                }), c("Arbiter").subscribe("PhotoTagger.STOP_TAGGING", function(a, c) {
                    b(d("SphericalMediaBaseActions").exitTaggingMode()), t.$PhotoSnowliftViewableSphericalPhoto22 = !1
                }), c("Arbiter").subscribe("PhotoTags.SHOWTAG", function(a, f) {
                    c("Bootloader").loadModules(["SphericalMediaTaggingUtils"], function(a) {
                        a = a.getSpatialTagFromFBID;
                        a = a(f, e().base.tags);
                        b(d("SphericalMediaBaseActions").updateTargetedTag(a))
                    }, "PhotoSnowliftViewableSphericalPhoto")
                }), c("Arbiter").subscribe("PhotoTags.HIDETAG", function(a, c) {
                    b(d("SphericalMediaBaseActions").updateTargetedTag(null))
                }), c("Arbiter").subscribe(t.$PhotoSnowliftViewableSphericalPhoto15.getEventString("EXTRA_DATA_CHANGE"), function(a, e) {
                    a = e ? e.spatialTags : null;
                    if (a && Array.isArray(a)) {
                        b(d("SphericalMediaBaseActions").updateSpatialTags(a));
                        b(d("SphericalMediaBaseActions").taggingStop());
                        var f = 0;
                        a.forEach(function(a) {
                            a.type !== c("SphericalMediaConstants").UNTAGGED_FACEBOX && f++
                        });
                        if (t.$PhotoSnowliftViewableSphericalPhoto13 && t.$PhotoSnowliftViewableSphericalPhoto13 > f) {
                            e = t.$PhotoSnowliftViewableSphericalPhoto13 - f;
                            for (var a = 0; a < e; a++) b(d("SphericalMediaBaseActions").deletedSpatialTag())
                        }
                        t.$PhotoSnowliftViewableSphericalPhoto13 = f
                    }
                }));
                return function(a) {
                    return function(b) {
                        return a(b)
                    }
                }
            };
            t.$PhotoSnowliftViewableSphericalPhoto30 = function(a) {
                a.getState;
                return function(a) {
                    return function(b) {
                        if (b.type === d("SphericalMediaActions").SHOW_FALLBACK) {
                            t.$PhotoSnowliftViewableSphericalPhoto11 = !0;
                            d("CSS").hide(t.$PhotoSnowliftViewableSphericalPhoto4);
                            var c = d("DOMQuery").scry(t.$PhotoSnowliftViewableSphericalPhoto15.stageWrapper, ".fbPhotosPhotoActionsTag.tagButton");
                            c.length > 0 && d("CSS").hide(c[0])
                        }
                        return a(b)
                    }
                }
            };
            t.$PhotoSnowliftViewableSphericalPhoto27 = function() {
                return function(a) {
                    return function(b) {
                        b.type === d("SphericalMediaActions").SETUP_RENDERER && (t.$PhotoSnowliftViewableSphericalPhoto11 = !0, d("CSS").hide(t.$PhotoSnowliftViewableSphericalPhoto4), t.$PhotoSnowliftViewableSphericalPhoto15.adjustStageSize());
                        return a(b)
                    }
                }
            };
            t.$PhotoSnowliftViewableSphericalPhoto28 = function(a) {
                var b = a.dispatch;
                return function(a) {
                    return function(c) {
                        if (c.type === d("SphericalMediaActions").SETUP_RENDERER) {
                            var e = t.$PhotoSnowliftViewableSphericalPhoto15.getTagger();
                            e && e.taggingMode != t.$PhotoSnowliftViewableSphericalPhoto22 && (t.$PhotoSnowliftViewableSphericalPhoto22 = e.taggingMode, b(e.taggingMode ? d("SphericalMediaBaseActions").enterTaggingMode() : d("SphericalMediaBaseActions").exitTaggingMode()))
                        }
                        return a(c)
                    }
                }
            };
            t.$PhotoSnowliftViewableSphericalPhoto29 = function(a) {
                a.getState;
                var b = a.dispatch;
                return function(a) {
                    return function(c) {
                        if (c.type === d("SphericalMediaActions").TURN_ON || c.type === d("SphericalMediaActions").SHOW_FALLBACK) {
                            var e = function() {
                                var a = t.$PhotoSnowliftViewableSphericalPhoto26();
                                b(d("SphericalMediaBaseActions").updateDimension(a.x, a.y))
                            };
                            t.$PhotoSnowliftViewableSphericalPhoto18.addSubscriptions(t.addListener("onEnterFullScreen", e), t.addListener("onExitFullScreen", e), t.addListener("onSetDimensions", e));
                            e()
                        }
                        return a(c)
                    }
                }
            };
            t.$PhotoSnowliftViewableSphericalPhoto1 = s;
            t.$PhotoSnowliftViewableSphericalPhoto2 = f;
            t.$PhotoSnowliftViewableSphericalPhoto3 = m;
            t.$PhotoSnowliftViewableSphericalPhoto6 = r;
            t.$PhotoSnowliftViewableSphericalPhoto7 = o;
            t.$PhotoSnowliftViewableSphericalPhoto8 = !1;
            t.$PhotoSnowliftViewableSphericalPhoto9 = l;
            t.$PhotoSnowliftViewableSphericalPhoto10 = !1;
            t.$PhotoSnowliftViewableSphericalPhoto11 = !1;
            t.$PhotoSnowliftViewableSphericalPhoto14 = n;
            t.$PhotoSnowliftViewableSphericalPhoto15 = p;
            t.$PhotoSnowliftViewableSphericalPhoto16 = q;
            t.$PhotoSnowliftViewableSphericalPhoto17 = e;
            t.$PhotoSnowliftViewableSphericalPhoto18 = new(c("SubscriptionsHandler"))();
            t.$PhotoSnowliftViewableSphericalPhoto20 = g;
            t.$PhotoSnowliftViewableSphericalPhoto21 = b;
            t.$PhotoSnowliftViewableSphericalPhoto5 = c("DOM").create("div", {
                className: "_zq_ _5nxw"
            });
            t.$PhotoSnowliftViewableSphericalPhoto4 = c("DOM").create("div", {
                className: "_zr0 _5nxw"
            });
            t.getElement().appendChild(t.$PhotoSnowliftViewableSphericalPhoto5);
            t.getElement().appendChild(t.$PhotoSnowliftViewableSphericalPhoto4);
            d("CSS").addClass(t.getElement(), "_zr1");
            t.$PhotoSnowliftViewableSphericalPhoto12 = {
                fov: h,
                pitch: i,
                yaw: k
            };
            t.$PhotoSnowliftViewableSphericalPhoto19 = new(c("SubscriptionsHandler"))();
            d("CSS").addClass(t.$PhotoSnowliftViewableSphericalPhoto15.stage, "_1ziy");
            t.$PhotoSnowliftViewableSphericalPhoto23();
            return t
        }
        var e = b.prototype;
        e.$PhotoSnowliftViewableSphericalPhoto24 = function(a) {
            this.$PhotoSnowliftViewableSphericalPhoto20.useTiledRenderer && c("SphericalPhotoTypedConfig").show_new_renderer ? d("ReactDOM").render(i.jsx(c("SphericalPhotoPlaceHolderWithGyroOverlay.react"), {
                placeholderImageURL: this.$PhotoSnowliftViewableSphericalPhoto25(),
                showNewRenderer: !0,
                width: a.x,
                height: a.y
            }), this.$PhotoSnowliftViewableSphericalPhoto4) : d("ReactDOM").render(i.jsx(c("SphericalPhotoPlaceHolderWithGyroOverlay.react"), {
                placeholderImageURL: this.$PhotoSnowliftViewableSphericalPhoto25()
            }), this.$PhotoSnowliftViewableSphericalPhoto4)
        };
        e.$PhotoSnowliftViewableSphericalPhoto23 = function() {
            var a = this.$PhotoSnowliftViewableSphericalPhoto26(),
                b = [this.$PhotoSnowliftViewableSphericalPhoto27, this.$PhotoSnowliftViewableSphericalPhoto28, this.$PhotoSnowliftViewableSphericalPhoto29, this.$PhotoSnowliftViewableSphericalPhoto30, this.$PhotoSnowliftViewableSphericalPhoto31];
            c("SphericalPhotoTypedConfig").www_can_viewer_tag && b.push(this.$PhotoSnowliftViewableSphericalPhoto32);
            this.$PhotoSnowliftViewableSphericalPhoto24(a);
            d("ReactDOM").render(i.jsx(c("SphericalMediaBootloaded.react"), {
                ambientAudio: this.$PhotoSnowliftViewableSphericalPhoto1,
                componentName: c("SphericalMediaConstants").COMP_PHOTO_VIEWER,
                canvasNamespace: "Snowlift",
                cubeImageURI: this.$PhotoSnowliftViewableSphericalPhoto2,
                fallback: this.$PhotoSnowliftViewableSphericalPhoto6,
                enableGyro: !0,
                enableZoom: !0,
                enableTagging: !0,
                enableRubberBanding: !0,
                height: a.y,
                initialView: this.$PhotoSnowliftViewableSphericalPhoto12,
                photoID: this.$PhotoSnowliftViewableSphericalPhoto7,
                partialLimits: this.$PhotoSnowliftViewableSphericalPhoto14,
                photoSphereMetadata: this.$PhotoSnowliftViewableSphericalPhoto16,
                surface: c("SphericalMediaConstants").LOGGER_SURFACES.snowlift,
                tiledSphericalConfig: this.$PhotoSnowliftViewableSphericalPhoto20,
                middlewares: b,
                useLargeVolumeIcon: !0,
                width: a.x
            }), this.$PhotoSnowliftViewableSphericalPhoto5);
            this.$PhotoSnowliftViewableSphericalPhoto10 = !0;
            this.emit("ready")
        };
        e.$PhotoSnowliftViewableSphericalPhoto33 = function() {
            this.$PhotoSnowliftViewableSphericalPhoto19.release(), this.$PhotoSnowliftViewableSphericalPhoto18.release(), d("ReactDOM").unmountComponentAtNode(this.$PhotoSnowliftViewableSphericalPhoto4), d("ReactDOM").unmountComponentAtNode(this.$PhotoSnowliftViewableSphericalPhoto5)
        };
        e.suspend = function() {
            this.$PhotoSnowliftViewableSphericalPhoto33()
        };
        e.resume = function() {
            this.$PhotoSnowliftViewableSphericalPhoto23()
        };
        e.reload = function() {
            this.$PhotoSnowliftViewableSphericalPhoto23()
        };
        e.hide = function() {
            a.prototype.hide.call(this), this.$PhotoSnowliftViewableSphericalPhoto33()
        };
        e.getDimensions = function() {
            var a = c("getViewportDimensions")(),
                b = a.width;
            a = a.height;
            c("SphericalPhotoTypedConfig").should_snowlift_fit_to_screen ? (this.$PhotoSnowliftViewableSphericalPhoto8 || (b -= k), this.isRenderReady() || (b = a = Math.min(b, a))) : b = a = Math.min(b, a);
            return c("Vector").from(b, a)
        };
        e.$PhotoSnowliftViewableSphericalPhoto26 = function() {
            var a = c("Vector").getElementDimensions(this.getElement());
            return a.x === 0 || a.y === 0 ? this.$PhotoSnowliftViewableSphericalPhoto3 || a : a
        };
        e.$PhotoSnowliftViewableSphericalPhoto34 = function(a) {
            var b = this.getElement().parentElement;
            a = new(c("Vector"))(a.x, a.y);
            if (b && b instanceof HTMLElement) {
                b = c("Vector").getElementDimensions(b);
                var d = c("Vector").getElementDimensions(this.getElement());
                (b.x !== d.x || a.x < b.x || a.y < b.y) && (a.x = b.x, a.y = b.y)
            }
            return a
        };
        e.isReady = function() {
            return this.$PhotoSnowliftViewableSphericalPhoto10
        };
        e.isRenderReady = function() {
            return this.$PhotoSnowliftViewableSphericalPhoto11
        };
        e.setDimensions = function(b) {
            a.prototype.setDimensions.call(this, this.$PhotoSnowliftViewableSphericalPhoto34(b));
            if (this.$PhotoSnowliftViewableSphericalPhoto20.useTiledRenderer && c("SphericalPhotoTypedConfig").show_new_renderer) {
                b = this.$PhotoSnowliftViewableSphericalPhoto26();
                !this.$PhotoSnowliftViewableSphericalPhoto11 && (!this.$PhotoSnowliftViewableSphericalPhoto3 || this.$PhotoSnowliftViewableSphericalPhoto3.x !== b.x || this.$PhotoSnowliftViewableSphericalPhoto3.y !== b.y) && this.$PhotoSnowliftViewableSphericalPhoto24(b);
                this.$PhotoSnowliftViewableSphericalPhoto3 = b
            }
            this.emit("onSetDimensions")
        };
        e.onToggleIntoFullScreen = function() {};
        e.onEnterFullScreen = function() {
            if (this.$PhotoSnowliftViewableSphericalPhoto8) return;
            this.$PhotoSnowliftViewableSphericalPhoto8 = !0;
            this.emit("onEnterFullScreen");
            d("CSS").addClass(this.getElement(), "_tz-")
        };
        e.onExitFullScreen = function() {
            if (!this.$PhotoSnowliftViewableSphericalPhoto8) return;
            this.$PhotoSnowliftViewableSphericalPhoto8 = !1;
            this.emit("onExitFullScreen");
            d("CSS").removeClass(this.getElement(), "_tz-")
        };
        e.$PhotoSnowliftViewableSphericalPhoto25 = function() {
            return this.$PhotoSnowliftViewableSphericalPhoto9 ? this.$PhotoSnowliftViewableSphericalPhoto21 : this.$PhotoSnowliftViewableSphericalPhoto17 || this.$PhotoSnowliftViewableSphericalPhoto21
        };
        return b
    }(c("PhotoSnowliftViewable"));
    g["default"] = a
}), 98);
__d("PhotoSnowliftViewableUtils", ["cx", "DOM", "PhotoSnowliftViewableImageWrapper", "PhotoSnowliftViewablePhoto", "PhotoSnowliftViewableSphericalPhoto", "ReactDOM", "SphericalMediaGyroOverlay.react", "react"], (function(a, b, c, d, e, f, g, h) {
    var i = d("react"),
        j = 65,
        k = 0,
        l = 0;

    function a(a, b) {
        return new(c("PhotoSnowliftViewableSphericalPhoto"))(a.url, a.smallurl, a.cubeImageURI, a.tiledSphericalConfig, a.initialView.fov || j, a.initialView.pitch || k, a.initialView.yaw || l, b.shouldShowHiRes(a), a.dimensions, a.partialLimits, String(a.fbid), b, a.photoSphereMetadata, a.fallback, a.ambientAudio)
    }

    function b(a, b) {
        if (a.spherical) return new(c("PhotoSnowliftViewableSphericalPhoto"))(a.url, a.smallurl, a.spherical.cubestripuri, a.spherical.tiledsphericalconfig, a.spherical.initialviewverticalfov || j, a.spherical.initialpitch || k, a.spherical.initialheading || l, b.shouldShowHiRes(a), a.dimensions, a.spherical.partialLimits, String(a.info.fbid), b, a.spherical.photosphereMetadata, a.spherical.fallback, a.spherical.ambientAudio);
        else return new(c("PhotoSnowliftViewablePhoto"))(a.url, a.smallurl, b.shouldShowHiRes(a), a.dimensions, String(a.info.fbid), !!a.info.disablecontextmenu, !!a.info.logcontextmenu, a.info.caption, a.info.shouldshowshield)
    }

    function m() {
        var a = c("DOM").create("div", {
            className: "_4yca _5nxw"
        });
        d("ReactDOM").render(i.jsx(c("SphericalMediaGyroOverlay.react"), {
            isActive: !0
        }), a);
        return a
    }

    function e(a, b) {
        var d = a.parentElement;
        a = new(c("PhotoSnowliftViewableImageWrapper"))(a);
        d && d.appendChild(a.getElement());
        b && a.getElement().appendChild(m());
        return a
    }
    g.fromSphericalPhotoData = a;
    g.fromStreamData = b;
    g.fromImageElement = e
}), 98);
__d("PhotoViewer", ["Bootloader", "CSS", "DOM"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a() {
            this.image = null, this.root = null, this.stream = null
        }
        var c = a.prototype;
        c.getEventString = function(a) {
            var b = this.getEventPrefix();
            return b ? b + "." + a : null
        };
        c.getImage = function() {
            return this.image
        };
        c.getPosition = function() {
            return this.stream ? this.stream.getCursor() : null
        };
        c.getRoot = function() {
            return this.root
        };
        c.hiliteAllBoxes = function() {
            b("DOM").scry(this.stageWrapper, "div.tagsWrapper div.faceBox").forEach(function(a) {
                b("CSS").addClass(a, "otherActive")
            }), b("DOM").scry(this.stageWrapper, "div.tagsWrapper div.fbPhotosPhotoTagboxBaseComments").forEach(function(a) {
                b("CSS").addClass(a, "otherActive")
            })
        };
        c.getEventPrefix = function() {
            return null
        };
        c.getSourceString = function() {
            return null
        };
        c.getVersionConst = function() {
            return null
        };
        c.getViewerSource = function() {
            return null
        };
        c.getViewerSet = function() {
            return null
        };
        a.bootstrap = function(a, c) {
            b("Bootloader").loadModules(["PhotoSnowlift"], function(b) {
                b.bootstrap(a, c)
            }, "PhotoViewer")
        };
        return a
    }();
    e.exports = a
}), null);
__d("ReactComponentRenderer", ["ReactDOM", "react", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    a = function() {
        function a(a, b) {
            this.klass = a, this.container = b, this.props = {}, this.component = null
        }
        var b = a.prototype;
        b.replaceProps = function(a, b) {
            this.props = {}, this.setProps(a, b)
        };
        b.setProps = function(a, b) {
            var c = this.klass;
            if (c == null) return;
            Object.assign(this.props, a);
            a = h.createElement(c, this.props);
            var e = this;
            d("ReactDOM").render(a, this.container, function() {
                e.component = this, b && b.call(this)
            })
        };
        b.unmount = function() {
            d("ReactDOM").unmountComponentAtNode(this.container), this.klass = null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("SnowliftVideoPivotsCarouselController", [], (function(a, b, c, d, e, f) {
    a = {
        setPivotsCarousel: function(a, b) {
            this._pivotsCarousel = a, this.adjustCarousel(b)
        },
        adjustCarousel: function(a) {
            this._pivotsCarousel && this._pivotsCarousel.pageTo(a)
        },
        adjustCarouselOnAutoPlay: function() {
            this._pivotsCarousel && this._pivotsCarousel.page()
        }
    };
    e.exports = a
}), null);
__d("PhotoSnowlift", ["csx", "cx", "fbt", "invariant", "$", "Arbiter", "AsyncRequest", "Bootloader", "CSS", "DOM", "DOMControl", "DOMQuery", "DataAttributeUtils", "DataStore", "Dialog", "DisableContextMenuMixin", "EncryptedImg", "ErrorUtils", "Event", "FBLogger", "FullScreen", "FunnelLogger", "ImageUtils", "Input", "Keys", "Layer", "LikeConfirmer", "LinkController", "LitestandShareAttachment", "LitestandStoryInsertionStatus", "Locale", "MutationObserver", "ObjectionableContentFilterMixin", "PHPQuerySerializer", "PageTransitions", "Parent", "PhotoLogger", "PhotoPermalinkURI", "PhotoSessionLog", "PhotoSnowliftActionsGating", "PhotoSnowliftBackLink.react", "PhotoSnowliftLoader", "PhotoSnowliftLoggingConfig", "PhotoSnowliftViewableUtils", "PhotoStreamCache", "PhotoViewer", "PhotosConst", "PhotosUtils", "PhotosetPivotSlide.react", "PhotosetSearchPivot.react", "PhotosetSearchPivotData", "ReactComponentRenderer", "ReactDOM", "Rect", "ScriptPath", "ScrollableArea", "SnowliftDestroyVideoPlayerExperiment", "SnowliftUFIContextualParentExperiment", "SnowliftVideoPivotsCarouselController", "Style", "SubscriptionsHandler", "TimeSlice", "Toggler", "Tooltip", "TrackingNodeTypes", "TrackingNodes", "UFIFeedbackTargets", "UIPagelet", "URI", "UserAgent_DEPRECATED", "Vector", "VideoData", "VideoPermalinkURI", "VideoPlayerAbortLoadingExperiment", "Visibility", "classWithMixins", "computeRelativeURI", "emptyFunction", "ge", "getActiveElement", "gkx", "goURI", "isNode", "killswitch", "mixin", "react", "setImmediate", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g, h, i, j) {
    "use strict";
    var k, l, m, n, o = k || b("react"),
        p = "WWW_SNOWLIFT_ACTIONS_FUNNEL",
        q = 74,
        r = 75,
        s = 70,
        t = 76,
        u = 315,
        v = 200,
        w = 2e3,
        x = new RegExp("\\/posts\\/(\\d+)\\/?$");
    a = function(a) {
        babelHelpers.inheritsLoose(c, a);

        function c() {
            var d;
            d = a.call(this) || this;
            d.bootstrap = function(a, c) {
                d.preload(a, c);
                d._href = a;
                d._elem = c;
                if (d.closeDirty) {
                    window.setTimeout(d.bootstrap.bind(babelHelpers.assertThisInitialized(d), a, c), 0);
                    return
                }
                d.resetUriStack = !0;
                if (d.isOpen)
                    if (d.openExplicitly) d.closeCleanup(), d.resetUriStack = !1;
                    else return;
                d._dataFt = null;
                var e = null;
                c && (e = b("Parent").bySelector(c, "._4oep"));
                if (e === null) {
                    var f = b("Parent").byAttribute(c, "data-cursor");
                    if (f) try {
                        var g = JSON.parse(b("DataAttributeUtils").getDataFt(f));
                        d._dataFt = g
                    } catch (a) {} else try {
                        f = b("Parent").byAttribute(c, "data-ad");
                        f = b("DataAttributeUtils").getParentByAttributeOrDataStoreKey(c, "data-ad", "data-ad");
                        g = JSON.parse(b("DataAttributeUtils").getDataAttribute(f, "data-ad"));
                        d._dataFt = {
                            ad_id: g.adid
                        }
                    } catch (a) {}
                }
                d.returningToStart = !1;
                d.loading && b("CSS").removeClass(d.loading, "loading");
                if (c) {
                    b("CSS").addClass(d.loading = c, "loading");
                    b("SnowliftUFIContextualParentExperiment").useUfiContextualParent ? f = e || b("Parent").byClass(c, "uiStreamStory") || b("Parent").bySelector(c, "._5jmm") : f = b("Parent").byClass(c, "uiStreamStory") || e || b("Parent").bySelector(c, "._5jmm");
                    if (f) d.storyID = f.id;
                    else {
                        g = b("Parent").bySelector(c, "._5b9c");
                        g && (d.storyID = g.getAttribute("data-ownerid"))
                    }
                    d._updateContainerOwnerID();
                    d.getThumbAndSize(c)
                } else d.loading = null;
                b("Arbiter").inform("PhotoSnowlift.GO", a, "state");
                d.loadFrameIfUninitialized()
            };
            d.handleNavigateAway = function(a) {
                var c = b("computeRelativeURI")(b("PageTransitions").getMostRecentURI().getQualifiedURI(), a.getAttribute("href"));
                if (d.backButton && b("ReactDOM").findDOMNode(d.backButton) === a) {
                    d._navHistory.pop();
                    d.resetUriStack = !1;
                    d.open(c.toString());
                    d._navHistory.pop();
                    d.currentAuthorName = null;
                    return !1
                }
                if (b("Parent").bySelector(a, "._56lp a")) {
                    d.resetUriStack = !1;
                    d.open(c.toString());
                    return !1
                }
                if (d.isOpen && c instanceof(l || (l = b("URI"))) && c.getUnqualifiedURI().toString() != d.startingURI.toString() && c.getPath() != "/photo.php") {
                    d.closingAction || (d.closingAction = b("PhotoSessionLog").NAVIGATE);
                    d.returnToStartingURI(!1, c);
                    d.close();
                    return !1
                }
                c instanceof(l || (l = b("URI"))) && c.getPath() == "/photo.php" && (l || (l = b("URI"))).getMostRecentURI().getPath() !== "/photo.php" && d.close();
                return !0
            };
            d.closeCleanup = function() {
                b("ScriptPath").closeOverlayView("snowlift");
                d.closeDirty = !1;
                b("CSS").removeClass(d.root, "dataLoading");
                b("PhotoSessionLog").logPhotoViews(d.closingAction);
                d.destroy();
                b("CSS").hide(d.errorBox);
                d._viewable.hide();
                d.thumbSpherical = !1;
                d.thumbSrc = null;
                d.shouldStretch = !1;
                d.resetUriStack = !0;
                var a = d.stream.getCursor();
                if (b("VideoPlayerAbortLoadingExperiment").canAbort) {
                    var c;
                    for (c = 0; c < d.stream.getLength(); c++) {
                        var e = d.stream.getImageData(d.stream.getCursorAt(c));
                        e && e.video && e.controller && e.controller.abortLoading()
                    }
                }
                b("CSS").removeClass(d.stageWrapper, "showVideo");
                d._emptyVideoStage();
                d.PhotoSnowliftVideoNode && d.PhotoSnowliftVideoNode.destroyVideoNode();
                d.uncollapseRHC();
                d.currentImageSize = null;
                d.currentMinSize = null;
                d.setStagePagersState("reset");
                d.recacheData();
                d.stream.destroy();
                d.root.setAttribute("aria-busy", "true");
                d._navHistory = [];
                e = d.closingAction === b("PhotoSessionLog").NAVIGATE;
                d.closingAction = null;
                d.openHandlerRegistered || (b("PageTransitions").registerHandler(d.openHandler.bind(babelHelpers.assertThisInitialized(d))), d.openHandlerRegistered = !0);
                b("Arbiter").inform("layer_hidden", {
                    type: "PhotoSnowlift"
                });
                b("Arbiter").inform("PhotoSnowlift.CLOSE", {
                    is_navigating: e,
                    fbid: a
                })
            };
            d.adjustScroller = function() {
                window.clearTimeout(d.scrollerTimeout);
                d.initializeScroller();
                d.scrollableArea.resize();
                var a = b("Vector").getElementDimensions(d.rhc);
                a = a.y;
                a -= b("Vector").getElementDimensions(d.rhcHeader).y;
                a -= b("Vector").getElementDimensions(d.ufiInputContainer).y;
                d.seeMore && (a -= b("Vector").getElementDimensions(d.seeMore).y);
                if (d.placeInfo) {
                    var e = b("Vector").getElementDimensions(d.placeInfo);
                    a -= e.y
                }
                a = Math.max(0, a);
                e = b("Vector").getElementDimensions(d.scrollerBody).y;
                var f = Math.max(c.MIN_UFI_HEIGHT, a);
                e >= f ? a > f ? a -= f : a = 0 : a -= e;
                d.scrollableArea.adjustGripper()
            };
            d.shouldShowHiRes = function(a) {
                if (!a || !a.smallurl) return !1;
                var b = d.getStageSize(a.dimensions);
                b = d._adjustStageSizeForPixelRatio(b);
                a = d.getImageSizeInStage(a.dimensions, b);
                return a.x > c.STAGE_NORMAL_MAX.x || a.y > c.STAGE_NORMAL_MAX.y
            };
            d.buttonListener = function(a) {
                var c = a.getTarget(),
                    e = Date.now();
                if (b("Parent").byClass(c, "fbPhotoTagApprovalBox")) {
                    b("FunnelLogger").appendAction(p, "approve_photo_tag");
                    return
                }
                if (e - d.lastPage < 350) return;
                if (b("Parent").byClass(c, "fbPhotosPhotoLike")) d.likePhoto();
                else if (b("Parent").byClass(c, "tagApproveIgnore")) d.updateTagBox(a, c), b("FunnelLogger").appendAction(p, "ignore_photo_tag");
                else if (b("Parent").bySelector(c, "._5ymu")) {
                    if (!d._showingMorePhotos) {
                        e = d.stream.getCursor();
                        e && d.showMorePhotos(String(e))
                    } else d.hideMorePhotos();
                    return
                }
                d.hideMorePhotos()
            };
            d.likePhoto = function() {
                b("FunnelLogger").appendActionWithTag(p, "like_photo", "snowlift-feedback");
                b("PhotoSessionLog").addButtonLike();
                var a = b("DOM").scry(d.ufiForm, "._6a-y")[0];
                if (a) {
                    a.click();
                    return
                }
                var c = b("$")("fbPhotoSnowliftFeedback");
                a = b("DOM").scry(c, "button.like_link")[0];
                a || (a = b("DOM").scry(c, "a.UFILikeLink")[0]);
                c = a.getAttribute("href");
                b("FullScreen").isFullScreen() && (b("UserAgent_DEPRECATED").chrome() && a.setAttribute("href", "javascript:;"));
                a.click();
                a.setAttribute("href", c)
            };
            d.hilitePager = function(a) {
                var e = b("Vector").getEventPosition(a),
                    f = b("Vector").getElementPosition(d.stage),
                    g = b("Vector").getElementDimensions(d.stage);
                b("Locale").isRTL() ? d.stagePagerPrev = g.x - (e.x - f.x) < c.GOPREV_AREA : d.stagePagerPrev = e.x - f.x < c.GOPREV_AREA;
                b("CSS").hasClass(d.prevPager, "hilightPager") !== d.stagePagerPrev && b("CSS").conditionClass(d.prevPager, "hilightPager", d.stagePagerPrev);
                b("CSS").hasClass(d.nextPager, "hilightPager") === d.stagePagerPrev && b("CSS").conditionClass(d.nextPager, "hilightPager", !d.stagePagerPrev);
                var h;
                g = a.getTarget();
                !b("Parent").byClass(g, "snowliftOverlay") && !b("Parent").byClass(g, "bottomBarActions") && !b("Parent").byClass(g, "snowliftPager") && (h = c.PAGER_FADE);
                d.showPagers(h)
            };
            d.unhiliteAllTags = function() {
                window.clearTimeout(d.unhiliteTimer);
                b("DOM").scry(d.stage, "div.tagsWrapper div.hover").forEach(function(a) {
                    b("CSS").removeClass(a, "hover")
                });
                b("DOM").scry(d.stage, "div.tagsWrapper div.otherActive").forEach(function(a) {
                    b("CSS").removeClass(a, "otherActive")
                });
                d.hilitedTag = null;
                d.showingTypeaheadSuggestions = !1;
                if (!b("CSS").hasClass(d.root, "taggingMode")) {
                    var a = d.getTagger();
                    a && !a.isSpherical && (a.hideTagger(), a.setCurrentFacebox(null))
                }
            };
            d.switchHilitedTags = function(a, c) {
                d.switchTimer !== null && (window.clearTimeout(d.switchTimer), d.switchTimer = null);
                d.unhiliteAllTags();
                d.hiliteAllBoxes();
                var e = b("ge")(a);
                if (e) {
                    d.hilitedTag = a;
                    if (!b("CSS").hasClass(d.root, "taggingMode") && b("PhotosUtils").isFacebox(d.hilitedTag)) {
                        var f = d.getTagger();
                        if (f) {
                            b("CSS").addClass(e, "hover");
                            a = f.getFacebox(a);
                            f.setCurrentFacebox(a);
                            a && f.addTagFromFacebox(a)
                        }
                    } else b("CSS").addClass(e, "hover");
                    b("CSS").hasClass(e, "tagBoxPending") && !b("CSS").hasClass(e, "showPendingTagName") && c === !0 && (b("DOM").scry(d.stage, "div.tagsWrapper div.showPendingTagName").forEach(function(a) {
                        b("CSS").removeClass(a, "showPendingTagName")
                    }), b("CSS").addClass(e, "showPendingTagName"))
                }
            };
            d.hiliteTagsOnMouseMove = function(a) {
                if (!d.stream.getCurrentExtraData() || d.getVideoOnStage()) return;
                if (d.switchTimer !== null) return;
                if (d.obscuredByOverlay) return;
                var c = a.getTarget();
                if (b("Parent").byClass(c, "snowliftOverlay") || b("Parent").byClass(c, "fbPhotoSnowliftTagApproval") || b("Parent").byClass(c, "tagPointer") || b("Parent").byClass(c, "arrow") || b("Parent").byClass(c, "faceboxSuggestion") || b("Parent").byClass(c, "typeaheadWrapper") || b("Parent").byClass(c, "photoTagTypeahead") || b("Parent").byClass(c, "ufiContainer")) return;
                c = b("Parent").byClass(c, "tagBoxPending");
                var e = !1;
                if (d.hilitedTag) {
                    var f = b("ge")(d.hilitedTag);
                    e = f && b("CSS").hasClass(f, "tagBoxPending")
                }
                f = !d.hilitedTag && c || !e && c;
                if (f) {
                    d.switchHilitedTags(c.id);
                    return
                }
                if (c && c.id == d.hilitedTag) return;
                f = 250;
                c = 15;
                a = b("Vector").getEventPosition(a);
                d.startingMousePos || (d.startingMousePos = a);
                var g = b("PhotosUtils").absoluteToNormalizedPosition(d._viewable.getElement(), a);
                if (!d.haveLeftBufferRegion && d.startingMousePos.distanceTo(a) < c) return;
                else d.haveLeftBufferRegion = !0;
                if (d.currentTagHasPrecedence(g)) return;
                a = b("PhotosUtils").getNearestBox(d.stream.getCurrentExtraData().tagRects, g);
                if (!a) {
                    e || (d.unhiliteAllTags(), d.reHilitePendingTag());
                    return
                }
                c = null;
                if (e) {
                    var h = {};
                    h[d.hilitedTag] = d.stream.getCurrentExtraData().tagRects[d.hilitedTag];
                    c = b("PhotosUtils").getNearestBox(h, g)
                }
                if (c !== null && e) return;
                d.hilitedTag != a && (e ? d.switchTimer = window.setTimeout(d.switchHilitedTags.bind(babelHelpers.assertThisInitialized(d), a), f) : (d._showHover && !d._seenTags[a] && (d._seenTags[a] = !0), d.switchHilitedTags(a)))
            };
            d.pageListener = function(a) {
                var c = b("Event").getKeyCode(a),
                    e = a.getTarget();
                if (!d.shouldPageOnAction(c, e)) return;
                if (d.shouldHandlePendingTag(a)) return;
                a = 0;
                var f = null;
                if (c == b("Keys").RIGHT || c == r) a = 1, b("FunnelLogger").appendActionWithTag(p, "image_prev", "key-right"), b("PhotoSessionLog").setPagingAction("key_right"), d._disableMouseOver = !0;
                else if (c == b("Keys").LEFT || c == q) a = -1, b("FunnelLogger").appendActionWithTag(p, "image_next", "key-left"), b("PhotoSessionLog").setPagingAction("key_left"), d._disableMouseOver = !0;
                else if (b("Parent").byClass(e, "next")) a = 1, b("FunnelLogger").appendActionWithTag(p, "image_next", "button-next"), b("PhotoSessionLog").setPagingAction("click_next");
                else if (b("Parent").byClass(e, "prev")) a = -1, b("FunnelLogger").appendActionWithTag(p, "image_prev", "button-prev"), b("PhotoSessionLog").setPagingAction("click_prev");
                else if (f = b("Parent").byClass(e, "seek")) {
                    c = b("DataStore").get(f, "seek-fbid");
                    a = d.stream.getRelativeMovement(c);
                    b("PhotoSessionLog").setPagingAction("seek")
                } else !d.stagePagerPrev ? (a = 1, b("FunnelLogger").appendAction(p, "image_next", "click-stage"), b("PhotoSessionLog").setPagingAction("click_stage")) : (a = -1, b("FunnelLogger").appendAction(p, "image_prev", "click-stage"), b("PhotoSessionLog").setPagingAction("click_stage_back"));
                e = b("DOM").scry(d.ufiForm, "input.mentionsHidden");
                f = !1;
                for (var c = 0; c < e.length; c++)
                    if (!b("Input").isEmpty(e[c])) {
                        f = !0;
                        break
                    }
                f || b("CSS").hasClass(d.root, "fbPhotoSnowliftEditMode") ? d.warnLeavePage(d.page.bind(babelHelpers.assertThisInitialized(d), a)) : d.page(a, b("UserAgent_DEPRECATED").chrome() && b("FullScreen").isFullScreen())
            };
            d.page = function(a, e, f) {
                if (!d.stream.isValidMovement(a) || !d.stream.nonCircularPhotoSetCanPage(a)) {
                    d.showPagers(c.PAGER_FADE);
                    return
                }
                var g = d.stream.getCursorAt(d.stream.calculatePositionForMovement(a));
                if (d.snowflake && (d.stream.getCursor() == d.firstInSet && a < 0 || d.firstInSet == g && a > 0)) {
                    d.showPagers(c.PAGER_FADE);
                    return
                }
                d.lastPage = Date.now();
                d.unhiliteAllTags();
                d.startingMousePos = null;
                d.haveLeftBufferRegion = !1;
                d._seenTags = {};
                d._navCount += a;
                var h = d.stream.allLoaded ? Math.abs(d._navCount) - d.stream.getLength() : null;
                if (d._extraSlidePivot && d._albumFBID) {
                    !d._albumBoundaries.end && h === 0 ? (d._albumBoundaries.end = d.stream.getCursor(), d._albumBoundaries.dir = a) : h === -1 && b("PhotosetSearchPivotData").fetch(d._albumFBID, d.stream);
                    if (!d.onExtraSlide)
                        if (d.stream.getCursor() === d._albumBoundaries.end && g === d._albumBoundaries.start && a === d._albumBoundaries.dir) {
                            d.showPivotSlide(d._albumFBID, e);
                            return
                        } else d.stream.getCursor() === d._albumBoundaries.start && g === d._albumBoundaries.end && a === -d._albumBoundaries.dir && d.showPivotSlide(d._albumFBID, e);
                    else {
                        d.hidePivotSlide();
                        if (a === -d._albumBoundaries.dir) return
                    }
                }
                g = d.getVideoOnStage();
                g && d.switchVideo(g, !1);
                if (d.pivots && d.pivots.page(a)) return;
                b("Arbiter").inform("PhotoSnowlift.PAGE");
                b("Toggler").hide();
                d.recacheData();
                d.stream.moveCursor(a);
                d._viewable.hide();
                a !== 0 && (d.storyID = null, d._updateContainerOwnerID());
                if (d.stream.errorInCurrent()) {
                    d.setLoadingState(c.STATE_HTML, !0);
                    b("CSS").show(d.errorBox);
                    return
                }
                d.movementDelta += a;
                g = d.stream.getCurrentImageData();
                if (g) {
                    a = d.getImageURL(g);
                    a ? d._switchViewable(a, null, !0) : g.video && d.switchVideo(g.video, !0, f);
                    d._updateObjectionableWarning(g);
                    g.info.disablecontextmenu ? d.disableContextMenu() : d.enableContextMenu();
                    e || (d.replaceUrl = !0, b("goURI")(g.info.permalink));
                    d.setLoadingState(c.STATE_IMAGE_DATA, !1)
                } else d.setLoadingState(c.STATE_IMAGE_PIXELS, !0), d.setLoadingState(c.STATE_IMAGE_DATA, !0);
                d.stream.getCurrentHtml() ? d.swapData() : d.setLoadingState(c.STATE_HTML, !0);
                d.setLeftAndRightPagersState();
                !d._extraSlidePivot && d._showMorePhotos && d._albumFBID && (h === -1 ? b("PhotosetSearchPivotData").fetch(d._albumFBID, d.stream) : h === 0 ? (d.showMorePhotos(d._albumFBID, !0), d.showPagers(), d._navCount = 0) : (d.hideMorePhotos(), d.hidePagers()));
                d._initLitestandShareAttachments()
            };
            d.transitionHandler = function(a) {
                if (a.getQueryData().closeTheater || a.getQueryData().permPage || d.returningToStart) {
                    d.isOpen && d.close();
                    d.transitionHandlerRegistered = !1;
                    return !1
                }
                if (d.replaceUrl) {
                    d.replaceUrl = !1;
                    d._uriStack.push(a.getQualifiedURI().toString());
                    b("PageTransitions").transitionComplete(!0);
                    return !0
                }
                var c = d._uriStack.length;
                c >= 2 && d._uriStack[c - 2] == a.getQualifiedURI().toString() && d._uriStack.pop();
                c = d.stream.getCursorForURI(a.getUnqualifiedURI().toString());
                if (c) {
                    a = d.stream.getRelativeMovement(c);
                    d.page(a, !0);
                    b("PageTransitions").transitionComplete(!1);
                    return !0
                }
                if (d.isOpen) {
                    b("PageTransitions").transitionComplete(!0);
                    d.close();
                    return !0
                }
                d.transitionHandlerRegistered = !1;
                return !1
            };
            d.reloadIfTimeout = function() {
                if (!b("ImageUtils").hasLoaded(d.image)) {
                    var a = d.makeNewImage(d.image.src, !0);
                    b("Event").listen(a, "load", d.useImage.bind(babelHelpers.assertThisInitialized(d), a, null, !0));
                    d._log(a.src)
                }
            };
            d.useImage = function(a, c, e, f) {
                f === void 0 && (f = !1);
                if (e && b("ImageUtils").hasLoaded(d.image)) return;
                e = function() {
                    b("DOM").replace(d.image, a), d.image = a, d.adjustStageSize(c)
                };
                !f || b("ImageUtils").hasLoaded(a) ? e() : b("Event").listen(a, "load", e)
            };
            d.handleAutoplay = function(a) {
                a = a.info.fbid.toString();
                a === d.stream.getCursor() && a !== d.stream.fbidList[d.stream.fbidList.length - 1] && (b("SnowliftVideoPivotsCarouselController").adjustCarouselOnAutoPlay(), d.page(1, !1, "autoplay_initiated"));
                d.removeAutoplayOptionScreen();
                d.haltAutoplay = !1
            };
            d.checkVideoStatus = function(a) {
                d.videoLoadTimer && window.clearTimeout(d.videoLoadTimer);
                var b = d.getVideoOnStage();
                if (!b) return;
                else {
                    if (b !== a) return;
                    d.adjustStageSizeForVideo(a)
                }
            };
            d.adjustStageSizeForVideo = function(a) {
                var b = d.getVideoElement(a);
                !b ? d.videoLoadTimer = window.setTimeout(d.checkVideoStatus.bind(babelHelpers.assertThisInitialized(d), a), 200) : d.adjustStageSize(d.getVideoSize(b))
            };
            d.onHiliteTag = function(a, c) {
                if (c.version != b("PhotosConst").VIEWER_SNOWLIFT) return;
                a = c.tag;
                a && d.switchHilitedTags(a, !0)
            };
            var e = new Error();
            b("FBLogger")("Photos", "photo_snowlift_render").catching(e).warn("[photos] PhotoSnowlift is still being used");
            d.switchTimer = null;
            d.imageRefreshTimer = null;
            d.imageLoadingTimer = null;
            d.lastPage = 0;
            d.currentMinSize = null;
            d._vpcsToDestroyOnDestroy = new Set();
            d.didReceivePayloadHavingInitProperty = !1;
            d.payloadsReceivedBeforePayloadHavingInitProperty = [];
            d.currentImageSize = null;
            d.resetUriStack = !0;
            d.thumbSpherical = !1;
            d.thumbSrc = null;
            d.shouldStretch = !1;
            d.sphericalPhotoData = null;
            d.stageMax = c.STAGE_NORMAL_MAX;
            d.stageChrome = c.STAGE_CHROME;
            d.stagePagerPrev = null;
            d.ua = null;
            d.PhotoTagger = null;
            d.obscuredByOverlay = !1;
            d._inputBarAdjusted = !1;
            d._seenTags = {};
            d._navCount = 0;
            d._navHistory = [];
            d._preloadTimeout = 0;
            d.actorID = null;
            d.clearAlbumBoundaries();
            return d
        }
        var d = c.prototype;
        d.preload = function(a, c) {
            var d = this;
            b("Bootloader").loadModules(["PhotoTagger", "Live", "PhotoTagApproval", "PhotoTags", "TagTokenizer"], function(a) {
                d.PhotoTagger = a
            }, "PhotoSnowlift")
        };
        d._updateContainerOwnerID = function() {
            this.container && (this.storyID ? this.container.setAttribute("data-ownerid", this.storyID) : this.container.removeAttribute("data-ownerid"))
        };
        d.getEventPrefix = function() {
            return "PhotoSnowlift"
        };
        d.getRoot = function() {
            return this.root
        };
        d.getSourceString = function() {
            return "snowlift"
        };
        d.getViewerSource = function() {
            return this.source
        };
        d.getViewerSet = function() {
            return this.stream.getPhotoSet()
        };
        d.getVersionConst = function() {
            return b("PhotosConst").VIEWER_SNOWLIFT
        };
        d.getImage = function() {
            return this._viewable.getElement()
        };
        d.getImageId = function() {
            return this.stream.getCursor()
        };
        d.getRHCHeader = function() {
            return this.rhcHeader
        };
        d.getRHCBody = function() {
            return this.ufiForm
        };
        d.getLoadQuery = function() {
            return this.loadQuery
        };
        d.getCurrentPhotoInfo = function() {
            var a = this.stream.getCurrentImageData();
            return a ? a.info : null
        };
        d.getOwnerId = function() {
            var a = this.stream.getCurrentImageData();
            return a ? a.info.owner : null
        };
        d.getThumbAndSize = function(a) {
            this.currentImageSize = null;
            this.thumbSpherical = !1;
            this.thumbSrc = null;
            var d = new(l || (l = b("URI")))(a.getAttribute("ajaxify")).getQueryData();
            if (!d.size) return;
            d = b("Vector").deserialize(d.size);
            if (!d.x || !d.y) return;
            this.currentImageSize = d;
            if (a.getAttribute("data-cropped")) return;
            d = b("DOM").scry(a, "img")[0];
            var e = b("DOM").scry(a, "i")[0];
            a = b("Parent").byAttribute(a, "data-size");
            this.shouldStretch = a && this.currentImageSize && d && a.getAttribute("data-size") === "2" && this.currentImageSize.x > this.currentImageSize.y && this.currentImageSize.x <= c.TIMELINE_STRETCH_WIDTH && d.offsetWidth === c.TIMELINE_STRETCH_WIDTH;
            if (d) a = d.src, this.thumbSpherical = Boolean(d.getAttribute("data-is-spherical-photo")), this.sphericalPhotoData = b("DataStore").get(d, "sphericalPhotoData");
            else if (e) a = b("Style").get(e, "backgroundImage").replace(/.*url\(\"?([^\"]*)\"?\).*/, "$1");
            else return;
            this.thumbSrc = a
        };
        d.loadFrameIfUninitialized = function() {
            if (this.root) return;
            var a = String((l || (l = b("URI"))).getMostRecentURI().getQueryData().viewas);
            b("PhotoSnowliftLoader").loadFrame(a)
        };
        d.init = function(a, c) {
            var d = this;
            this.init = b("emptyFunction");
            this._shouldLog = c.photos_client_loading;
            this._logger = null;
            this._shouldLog && (this._logger = new(b("PhotoLogger"))(b("PhotosConst").VIEWER_SNOWLIFT_STRING));
            this._showHover = c.pivot_hover;
            this._showMorePhotos = c.show_more_photos;
            this._extraSlidePivot = c.extra_slide_pivot;
            this._uiRefresh = c.snowlift_ui_refresh;
            b("PhotoSessionLog").setEndMetrics(c.pivot_end_metric);
            this.startingMousePos = null;
            this.haveLeftBufferRegion = !1;
            this.showingTypeaheadSuggestions = !1;
            this.isFullScreenSupported = b("FullScreen").isSupportedWithKeyboardInput();
            this.showOGVideos = c.og_videos;
            this.spotlight = a;
            this.spotlight.subscribe("blur", function() {
                d.closingAction = b("PhotoSessionLog").OUTSIDE
            });
            this.spotlight.subscribe("hide", this.closeHandler.bind(this));
            this.spotlight.subscribe("key", this.keyHandler.bind(this));
            this._actionMenuOpen = !1;
            this._mouseOnPhotoStage = !1;
            this.initializeNodes(this.spotlight.getRoot());
            this.disableContextMenu();
            this.subscription || (b("LinkController").registerHandler(this.handleNavigateAway.bind(this)), this.subscription = b("Arbiter").subscribe("PhotoSnowlift.GO", function(a, c) {
                d.openExplicitly = !0, d.loading && b("CSS").removeClass(d.loading, "loading"), d.open(c)
            }));
            this.transitionHandlerRegistered = !1;
            this.returningToStart = !1;
            b("PageTransitions").registerHandler(this.openHandler.bind(this));
            this.openHandlerRegistered = !0;
            b("Arbiter").subscribe("PhotoTagApproval.HILITE_TAG", this.onHiliteTag.bind(this));
            b("Arbiter").subscribe("PhotoTagApproval.UPDATE_TAG_BOX", this.onUpdateTagBox.bind(this));
            b("Arbiter").subscribe("ObjectionableContentToggleButton.COVERED", this.handleObjectionableContentToggleButtonClicked.bind(this));
            this.buttonTruncateGk = c.snowlift_button_truncate;
            this.allowIrrelevantRequests = !!c.snowlift_allow_irrelevant_requests;
            this.snowflake && (b("CSS").addClass(this.root, "snowflake"), this.extraClasses.forEach(function(a) {
                b("CSS").addClass(this.root, a)
            }, this))
        };
        d.initializeNodes = function(a) {
            var c;
            this.root = a;
            this.container = (c = b("DOM")).find(a, "div.fbPhotoSnowliftContainer");
            this._updateContainerOwnerID();
            this.snowliftPopup = c.find(this.container, "div.fbPhotoSnowliftPopup");
            this.rhc = c.find(this.snowliftPopup, "div.rhc");
            this.details = c.find(this.rhc, "#fbPhotoSnowliftDetails");
            this.rhcBody = c.find(this.rhc, "div.rhcBody");
            this.rhcHeader = c.find(this.rhc, "div.rhcHeader");
            this.taglist = c.find(this.rhc, "span.fbPhotoTagList");
            this.ufiForm = c.find(this.rhc, "form.fbPhotosSnowliftFeedbackForm");
            this.ufiInputContainer = c.find(this.rhc, "div.fbPhotosSnowboxFeedbackInput");
            this.ufiMainContainer = this.ufiForm.appendChild(document.createElement("div"));
            this.ufiStageActionsContainer = c.scry(this.root, "._29qf")[0];
            this.ufiContainers = {
                ufiMainContainer: this.ufiMainContainer,
                ufiComposerContainer: this.ufiInputContainer,
                ufiStageActionsContainer: this.ufiStageActionsContainer
            };
            this.scroller = c.find(this.rhc, "div.rhcScroller");
            this.scrollerBody = c.find(this.scroller, "div.uiScrollableAreaBody");
            this.stageWrapper = c.find(this.snowliftPopup, "div.stageWrapper");
            this.overlay = c.find(this.snowliftPopup, "div.snowliftOverlay");
            this.errorBox = c.find(this.stageWrapper, "div.stageError");
            this._viewable = b("PhotoSnowliftViewableUtils").fromImageElement(c.find(this.stageWrapper, "img.spotlight"));
            this.stage = c.find(this.stageWrapper, "div.stage");
            this.videoStage = c.find(this.stageWrapper, "div.videoStage");
            this.prevPager = c.find(this.snowliftPopup, "a.snowliftPager.prev");
            this.nextPager = c.find(this.snowliftPopup, "a.snowliftPager.next");
            this.stageActions = c.find(a, "div.stageActions");
            this._uiRefresh || (this.buttonActions = b("DOM").find(this.stageActions, "div.fbPhotosPhotoButtons"));
            this.placeInfo = b("DOM").find(this.rhc, "div.fbPhotosSnowliftPlaceInfo");
            this.seeMore = b("DOM").find(this.rhc, "._jke");
            b("CSS").conditionClass(this.root, "fullScreenAvailable", this.isFullScreenSupported)
        };
        d.getContextMenuContainer = function() {
            return this.stageWrapper
        };
        d.getObjectionableWarningContainer = function() {
            return this.stageWrapper
        };
        d.getObjectionableWarningHiddenContent = function() {
            return this.isVideo() ? this.videoStage : this.stage
        };
        d.isVideo = function() {
            var a = this.stream.getCurrentImageData();
            return a && a.info.video ? !0 : !1
        };
        d.initializeScroller = function() {
            var a = this,
                c, d;
            this.initializeScroller = b("emptyFunction");
            b("CSS").addClass(this.scroller, "_467y");
            this.scrollableArea = b("ScrollableArea").fromNative(this.scroller, {
                fade: !0,
                persistent: !0
            });
            var e = function(c) {
                c = b("Event").$E(c).getTarget();
                if (b("DOM").contains(a.ufiInputContainer, c)) {
                    var d = b("DOMControl").getInstance(c);
                    if (d) {
                        a.scrollableArea.scrollToBottom();
                        var e = d.subscribe("resize", function() {
                                var b = a.scrollableArea.isScrolledToBottom();
                                a.adjustScroller();
                                b && a.scrollableArea.scrollToBottom()
                            }),
                            f = b("Event").listen(c, "blur", function() {
                                d.unsubscribe(e), f.remove()
                            })
                    }
                }(c.classList.contains("UFIPagerLink") || c.classList.contains("UFICommentLink")) && (a.autoplayOptionScreenConfig && a.autoplayOptionScreenConfig.enabled && (a.haltAutoplay = !0))
            };
            (c = b("Arbiter")).subscribe("ufi/inputHeightChanged", function(c, d) {
                b("DOM").contains(a.ufiInputContainer, d.node) && a.adjustScroller()
            });
            c.subscribe("ufi/photoPreviewHightChanged", function(c, d) {
                (!d.node || b("DOM").contains(a.ufiInputContainer, d.node)) && a.adjustScroller()
            });
            (d = b("Visibility")).addListener(d.HIDDEN, function() {
                b("PhotoSessionLog").updateDuration()
            });
            d.addListener(d.VISIBLE, function() {
                b("PhotoSessionLog").updateLastVisibleTime()
            });
            c.subscribe("ufi/changed", function(b, c) {
                a.ufiForm === c.form && a.adjustScrollerIfNecessary()
            });
            c.subscribe("ufi/comment", function(b, c) {
                a.ufiForm === c.form && (a.adjustScrollerIfNecessary(), c.isinverted ? a.scrollableArea.scrollToTop() : a.scrollableArea.scrollToBottom())
            });
            b("Event").listen(this.rhc, "click", function(c) {
                c = c.getTarget();
                (b("Parent").byTag(c, "a") || b("Parent").byTag(c, "button") || b("DOM").isNodeOfType(c, "input")) && a.adjustScrollerIfNecessary()
            });
            c.subscribe(["reflow", "CommentUFI.Pager"], function() {
                a.isOpen && a.adjustScrollerIfNecessary()
            });
            c.subscribe("ufi/translationRendered", function() {
                a.adjustScrollerIfNecessary()
            });
            b("Event").listen(this.ufiForm, "focusin", e)
        };
        d.openHandler = function(a) {
            if (this.isOpen || !b("PhotoPermalinkURI").isValid(a) || this.returningToStart || a.getQueryData().closeTheater || a.getQueryData().permPage) {
                this.openHandlerRegistered = !1;
                return !1
            }
            this.open(a);
            this._uriStack.push(new(l || (l = b("URI")))(a).getQualifiedURI().toString());
            b("PageTransitions").transitionComplete(!0);
            return !0
        };
        d.addHaltAutoplaySubscription = function() {
            var a = this;
            b("Arbiter").subscribe(["ufi/focus"], function() {
                a.haltAutoplay = !0
            });
            b("Arbiter").subscribe(["ufi/blur"], function(b, c) {
                a.haltAutoplay = c.hasEnteredText
            })
        };
        d.open = function(a) {
            var d = this,
                e = new(l || (l = b("URI")))(a),
                f = e.getQueryData(),
                g = Object.create(null),
                h = b("PhotoPermalinkURI").parse(e);
            h != null && (f.fbid = h.photo_id, f.set = h.set_token, g.snowlift_content_id = h.photo_id);
            h = b("VideoPermalinkURI").parse(e);
            h != null && (f.v = h.video_id, f.set = h.set_token, g.snowlift_content_id = h.video_id);
            this._elem != null && (f.external_log_id = this._elem.getAttribute("data-external-log-id"), f.player_origin = this._elem.getAttribute("data-player-origin"));
            b("ScriptPath").openOverlayView("snowlift", g);
            if (!f.fbid && !f.v && !f.pid) {
                h = x.exec(e.getPath());
                h && (f.v = h[1])
            }
            f.fbid == null && f.v == null && b("FBLogger")("photo_snowlift").blameToPreviousFile().mustfix("Attempted to open Snowlift with an invalid URI. Loading PhotoViewerInitPagelet requires a query string that contains either a non-null `?fbid` or `?v`. Got URI: %s", a.toString());
            this.resetUriStack && (this._uriStack = []);
            this.initialLoad || (f.firstLoad = !0, this.initialLoad = !0, b("LitestandStoryInsertionStatus").registerBlocker(function() {
                return d.isOpen
            }));
            this.sessionID = Date.now();
            this.loadQuery = Object.assign(f, {
                ssid: this.sessionID
            });
            this._dataFt && (this.loadQuery.data_ft = this._dataFt);
            this.isOpen = !0;
            this.pagersShown = !1;
            this.refreshOnClose = !1;
            this.hilitedTag = null;
            this.loadingStates = {
                image: !1,
                html: !1
            };
            this.replaceUrl = !1;
            this.movementDelta = 0;
            this.pivotsCarouselElement = null;
            this.autoplayOptionScreenConfig = null;
            this.haltAutoplay = !1;
            this.shouldRenderVideoPivots = !1;
            b("CSS").show(this.nextPager);
            b("CSS").show(this.prevPager);
            this.source = null;
            this.saveTagSubscription = b("Arbiter").subscribe("PhotoTagger.SAVE_TAG", this.onTagSaved.bind(this));
            this.taggedPhotoIds = [];
            this.didReceivePayloadHavingInitProperty = !1;
            this.payloadsReceivedBeforePayloadHavingInitProperty.length = 0;
            this.stream = new(b("PhotoStreamCache"))();
            this.stream.init(b("PhotosConst").VIEWER_SNOWLIFT, "PhotoViewerPagelet", "pagelet_photo_viewer", this._shouldLog ? this._logger : null, f.tagSuggestionMode || "everyone");
            (l || (l = b("URI"))).getMostRecentURI().getQueryData().viewas && this.stream.setViewAs((l || (l = b("URI"))).getMostRecentURI().getQueryData().viewas + "");
            (l || (l = b("URI"))).getMostRecentURI().getQueryData().ifg && this.stream.setIsFromGroups((l || (l = b("URI"))).getMostRecentURI().getQueryData().ifg);
            this.fetchInitialData();
            this.setLoadingState(c.STATE_HTML, !0);
            this.rhcCollapsed = !1;
            this._open(a);
            b("Bootloader").loadModules(["PhotosButtonTooltips"], function(a) {
                a.init()
            }, "PhotoSnowlift");
            this._navHistory.push(e.getQualifiedURI().toString())
        };
        d._open = function(a) {
            var d = this;
            this.createLoader();
            this.hideObjectionableWarning();
            this.spotlight.show();
            b("Arbiter").inform("layer_shown", {
                type: "PhotoSnowlift"
            });
            b("Arbiter").inform("PhotoSnowlift.OPEN");
            var e = this.adjustForResize.bind(this);
            this.stageHandlers && this.stageHandlers.release();
            this.stageHandlers = new(b("SubscriptionsHandler"))();
            this.stageHandlers.addSubscriptions(b("Event").listen(window, "resize", function() {
                if (b("FullScreen").isFullScreen()) return;
                e()
            }), b("FullScreen").subscribe("changed", function() {
                b("setImmediate")(e)
            }), b("Event").listen(this.stageWrapper, "click", function(a) {
                a = b("DataAttributeUtils").getClickTrackingParent(a.getTarget());
                if (!a) return;
                try {
                    a = JSON.parse(b("DataAttributeUtils").getDataFt(a));
                    if (!a.tn) return;
                    var c = b("TrackingNodes").parseTrackingNodeString(a.tn);
                    a = Object.keys(b("TrackingNodeTypes")).filter(function(a) {
                        return b("TrackingNodeTypes")[a] === c
                    });
                    a.length && b("FunnelLogger").appendAction(p, "click_" + a.join("_"))
                } catch (a) {}
            }), b("Event").listen(this.stageWrapper, "click", this.buttonListener.bind(this)), b("Event").listen(this.stageWrapper, "mouseleave", function(a) {
                a = a.getTarget();
                if (b("Parent").bySelector(a, "._khz") || b("Parent").bySelector(a, "._6a-y")) return;
                b("Parent").byClass(a, "snowliftOverlay") || b("Parent").byClass(a, "fbPhotoSnowliftTagApproval") || b("Parent").byClass(a, "tagPointer") || b("Parent").byClass(a, "arrow") || b("Parent").byClass(a, "faceboxSuggestion") || b("Parent").byClass(a, "typeaheadWrapper") || b("Parent").byClass(a, "photoTagTypeahead") || b("Parent").byClass(a, "fbPhotoTagger") || d.unhiliteAllTags();
                d._mouseOnPhotoStage = !1;
                d.hidePagers()
            }), b("Event").listen(this.stageWrapper, "mousemove", this.hilitePager.bind(this)), b("Event").listen(this.stageWrapper, "mousemove", this.hiliteTagsOnMouseMove.bind(this)), b("Event").listen(this.stageWrapper, "mouseenter", function() {
                d._mouseOnPhotoStage = !0, b("Arbiter").inform("lwf/entryModal/logImpression")
            }), b("Event").listen(this.overlay, "mouseenter", this.unhiliteAllTags.bind(this)), b("Event").listen(this.container, "mousemove", this._enableMouseOver.bind(this)), b("Event").listen(this.container, "mouseover", this._interceptMouseOver.bind(this)), b("Event").listen(this.stageWrapper, "focusin", this.hilitePager.bind(this)), b("Event").listen(this.rhc, "focusin", this.hidePagers.bind(this)), b("Event").listen(this.root, "click", function(a) {
                a = a.getTarget();
                if (b("Parent").bySelector(a, "._418x")) {
                    if (b("FullScreen").isFullScreen()) {
                        b("FunnelLogger").appendActionWithTagIfNew(p, "fullscreen_exit", "fbPhotoSnowlift/close");
                        b("FullScreen").toggleFullScreen();
                        return
                    }
                    d.closingAction = b("PhotoSessionLog").X;
                    d.spotlight.hide()
                } else d._isLiveBroadcast && b("Parent").bySelector(a, "._3ixn") && d.spotlight.hide()
            }), b("Event").listen(this.container, "click", function(a) {
                var c = a.getTarget();
                if (b("Parent").byClass(c, "rotateRight")) b("FunnelLogger").appendActionWithTag(p, "rotate_image", "right"), d.rotate("right");
                else if (b("Parent").byClass(c, "rotateLeft")) b("FunnelLogger").appendActionWithTag(p, "rotate_image", "left"), d.rotate("left");
                else if (b("Parent").bySelector(c, "._32_l")) {
                    b("FunnelLogger").appendAction(p, "click-pivot-item");
                    var e = b("Parent").bySelector(c, "._32_l");
                    e = e.getAttribute("data-fbid");
                    var f = d.stream.getCursor();
                    f = d.stream.calculateDistance(f, e);
                    e = d.stream.fbidList.indexOf(e);
                    b("SnowliftVideoPivotsCarouselController").adjustCarousel(e);
                    d.page(f, !1);
                    d.haltAutoplay = !1;
                    d.removeAutoplayOptionScreen()
                } else b("Parent").byClass(c, "fbPhotoSnowliftZoom") ? d.openZoom(a) : d.isFullScreenSupported && (b("Parent").byClass(c, "fbPhotoSnowliftFullScreen") ? (b("FunnelLogger").appendActionWithTagIfNew(p, b("FullScreen").isFullScreen() ? "fullscreen_exit" : "fullscreen_enter", "fbPhotoSnowliftFullScreen"), d.toggleFullScreen()) : b("Parent").byClass(c, "fbPhotoSnowliftCollapse") ? (d.toggleCollapse(), b("FunnelLogger").appendAction(p, "toggle_collapse-rhc")) : b("FullScreen").isFullScreen() && (b("Parent").bySelector(c, ".overlayBarButtons .comment_link") || b("Parent").bySelector(c, ".overlayBarButtons ._666h")) && (d.toggleCollapse(), b("FunnelLogger").appendAction(p, "toggle_collapse-rhc")));
                e = b("Parent").byAttribute(c, "data-action-type");
                if (e) {
                    f = e.getAttribute("data-action-type");
                    a = e.getAttribute("data-action-tag");
                    b("FunnelLogger").appendActionWithTag(p, f, a)
                } else if (b("Parent").byClass(c, "addLocation")) {
                    e = b("Parent").byClass(c, "addLocation");
                    b("FunnelLogger").appendActionWithTag(p, "add_location", b("CSS").hasClass(e, "photosTruncatingUIButton") ? null : "from-action-bar")
                } else if (b("Parent").byClass(c, "fbPhotosPhotoActionsTag")) {
                    f = b("Parent").byClass(c, "fbPhotosPhotoActionsTag");
                    b("CSS").hasClass(f, "tagButton") ? b("FunnelLogger").appendActionWithTag(p, "tag_photo", "start-tagging") : b("CSS").hasClass(f, "doneTaggingLink") ? b("FunnelLogger").appendActionWithTag(p, "tag_photo", "end-tagging") : b("CSS").hasClass(f, "taggingOff") ? b("FunnelLogger").appendActionWithTag(p, "tag_photo", "tagging-off") : b("CSS").hasClass(f, "taggingOn") && b("FunnelLogger").appendActionWithTag(p, "tag_photo", "tagging-on")
                } else b("Parent").byClass(c, "UFILikeLink") && b("FunnelLogger").appendAction(p, "like-photo")
            }));
            a = b("ge")("fbPhotoSnowliftFeedback");
            a && this.stageHandlers.addSubscriptions(b("Event").listen(a, "click", function(a) {
                var c = a.getTarget();
                (b("Parent").byClass(c, "like_link") || b("Parent").byClass(c, "UFILikeLink") && b("Parent").byClass(c, "UIActionLinks")) && d.toggleLikeButton();
                c = b("Parent").byClass(a.getTarget(), "uiUfiCollapsedComment");
                c && (b("FunnelLogger").appendActionWithTag(p, "like-photo", "snowlift-feedback"), b("CSS").addClass(c, "uiUfiCollapsedCommentToggle"))
            }));
            a = b("ge")("fbPhotoSnowliftOnProfile");
            a && this.stageHandlers.addSubscriptions(b("Event").listen(a, "click", function(a) {
                b("Parent").byClass(a.getTarget(), "fbPhotoRemoveFromProfileLink") && (d.refreshOnClose = !0)
            }));
            this.resetUriStack && (this.startingURI = (l || (l = b("URI"))).getMostRecentURI().addQueryData({
                closeTheater: 1
            }).getUnqualifiedURI());
            this.setLoadingState(c.STATE_IMAGE_DATA, !0);
            this.transitionHandlerRegistered || (b("PageTransitions").registerHandler(this.transitionHandler.bind(this)), this.transitionHandlerRegistered = !0);
            b("PhotoSessionLog").initLogging(b("PhotoSessionLog").SNOWLIFT);
            this._dataFt && (b("PhotoSessionLog").setTopLevelPostId(this._dataFt.top_level_post_id), b("gkx")("831476") && (this._dataFt.story_location && b("PhotoSessionLog").setStoryLocation(this._dataFt.story_location), this._dataFt.story_attachment_style && b("PhotoSessionLog").setStoryAttachmentStyle(this._dataFt.story_attachment_style), this._dataFt.attached_story_attachment_style && b("PhotoSessionLog").setAttachedStoryAttachmentStyle(this._dataFt.attached_story_attachment_style), this._dataFt.qid && b("PhotoSessionLog").setQid(this._dataFt.qid), this._dataFt.mf_story_key && b("PhotoSessionLog").setMfStoryKey(this._dataFt.mf_story_key), this._dataFt.page_insights && !b("killswitch")("PAGE_INSIGHTS_STOP_SENDING_PI_TRACKING_DATA_FROM_SNOWLIFT") && b("PhotoSessionLog").setPageInsightsData(this._dataFt.page_insights)));
            this.pivots && b("PhotoSessionLog").setRelevantCount(this.pivots.relevantCount)
        };
        d.toggleFullScreen = function() {
            var a = b("FullScreen").toggleFullScreen(document.documentElement);
            a ? (this._viewable.onToggleIntoFullScreen(), b("PhotoSessionLog").logEnterFullScreen(this.stream.getCursor())) : this._viewable.onToggleOutOfFullScreen()
        };
        d._getIsZoomAllowed = function(a) {
            return !!(a && !a.video && !a.spherical && a.dimensions && (a.dimensions.x > window.innerWidth || a.dimensions.y > window.innerHeight))
        };
        d.showZoom = function(a) {
            b("CSS").conditionClass(this.root, "zoomAvailable", this._getIsZoomAllowed(a))
        };
        d.openZoom = function(a) {
            var c = this.stream.getCurrentImageData();
            this._viewable.onToggleIntoFullScreen();
            var d = b("DOM").find(this.stageWrapper, "._2-sx"),
                e = d.getBoundingClientRect();
            d.style.width = "auto";
            d.style.height = "auto";
            d.classList.add("zoom");
            var f, g;
            if (c) {
                c = c.dimensions;
                f = Math.max(0, c.x - window.innerWidth);
                g = Math.max(0, c.y - window.innerHeight)
            } else {
                c = d.getBoundingClientRect();
                f = Math.max(0, c.width - window.innerWidth);
                g = Math.max(0, c.height - window.innerHeight)
            }
            c = !1;
            f && (c = !0, f += v * 2, d.classList.add("overflowX"));
            g && (c = !0, g += v * 2, d.classList.add("overflowY"));
            var h;
            if (c) {
                c = -a.clientX / window.innerWidth * f + "px";
                a = -a.clientY / window.innerHeight * g + "px";
                d.style.transform = "translate3d(" + c + "," + a + ",0)";
                h = b("Event").listen(d, "mousemove", function(a) {
                    var b = -a.clientX / window.innerWidth * f + "px";
                    a = -a.clientY / window.innerHeight * g + "px";
                    d.style.transform = "translate3d(" + b + "," + a + ",0)"
                })
            }
            var i = null,
                j = null;
            c = function() {
                d.style.width = e.width + "px";
                d.style.height = e.height + "px";
                d.style.transform = "";
                d.classList.remove("zoom", "overflowX", "overflowY");
                h && h.remove();
                i.remove();
                k.unsubscribe(j);
                k.destroy();
                return !1
            };
            var k = new(b("Layer"))({}, document.createElement("div"));
            j = k.subscribe("key", c);
            k.show();
            i = b("Event").listen(d, "click", c);
            this._viewable.onEnterFullScreen()
        };
        d.getStream = function() {
            return this.stream
        };
        d.fetchInitialData = function() {
            this.stream.waitForInitData();
            var a = this.loadQuery.within_business ? this.loadQuery.business_thread_id : this.loadQuery.fbid;
            a = b("UFIFeedbackTargets").getFeedbackTargetIfExists(a) || {};
            a = {
                actorID: a.actorforpost || null,
                usePipe: !0,
                jsNonblock: !0,
                crossPage: !0,
                allowIrrelevantRequests: this.allowIrrelevantRequests
            };
            this.loadQuery.__tn__ && this.loadQuery.__xts__ && (a.query = (m || (m = b("PHPQuerySerializer"))).serialize({
                __tn__: this.loadQuery.__tn__,
                __xts__: this.loadQuery.__xts__
            }));
            b("UIPagelet").loadFromEndpoint("PhotoViewerInitPagelet", b("ge")("pagelet_photo_viewer_init", this.root), this.loadQuery, a);
            this.adjustScroller()
        };
        d.toggleCollapse = function() {
            this.rhcCollapsed ? this.uncollapseRHC() : this.collapseRHC()
        };
        d.collapseRHC = function() {
            this.rhcCollapsed = !0, b("CSS").addClass(this.root, "collapseRHC"), this.adjustForResize()
        };
        d.uncollapseRHC = function() {
            this.rhcCollapsed = !1, b("CSS").removeClass(this.root, "collapseRHC"), this.adjustForResize()
        };
        d.closeHandler = function() {
            if (!this.isOpen) return;
            this.closingAction = this.closingAction || b("PhotoSessionLog").ESC;
            if ((l || (l = b("URI"))).getMostRecentURI().addQueryData({
                    closeTheater: 1
                }).getUnqualifiedURI().toString() == this.startingURI.toString()) {
                this.close();
                return
            }
            this.returnToStartingURI(this.refreshOnClose);
            this.close()
        };
        d.returnToStartingURI = function(a, c) {
            var d = this;
            a || (c ? this.squashNextTransition(b("goURI").bind(null, c)) : this.squashNextTransition());
            this.returningToStart = !0;
            var e = b("Arbiter").subscribe("page_transition", function() {
                d.returningToStart = !1, e.unsubscribe()
            });
            c = a || isNaN(b("UserAgent_DEPRECATED").opera());
            a = this._uriStack.length;
            if (c && a < window.history.length) a !== 0 && window.history.go(-a);
            else {
                c = this.startingURI;
                a = new(l || (l = b("URI")))(c).removeQueryData("closeTheater");
                c.getQueryData().sk == "approve" && c.getPath() == "/profile.php" && (a.removeQueryData("highlight"), a.removeQueryData("notif_t"));
                b("goURI")(a)
            }
        };
        d.squashNextTransition = function(a) {
            var c = this;
            this.squashNext = !0;
            b("PageTransitions").registerHandler(function() {
                if (c.squashNext) {
                    c.squashNext = !1;
                    a && window.setTimeout(a, 0);
                    b("PageTransitions").transitionComplete(!0);
                    return !0
                }
                return !1
            }, 7)
        };
        d.postProcessTaggedPhotos = function() {
            if (this.taggedPhotoIds && this.taggedPhotoIds.length > 0) {
                var a = null;
                this.source === c.COLLECTIONS_UNTAGGED_PHOTOS ? a = "/ajax/photos/photo/edit/skiptag/" : (this.source === c.PHOTOS_OF_YOU_SUGGESTIONS || this.source === c.FRIENDS_IN_PHOTOS_SUGGESTIONS) && (a = "/ajax/photos/photo/add_to_star_grid/");
                a && new(b("AsyncRequest"))().setURI(a).setAllowCrossPageTransition(!0).setData({
                    media_id: this.taggedPhotoIds,
                    source: this.source
                }).send()
            }
        };
        d.onTagSaved = function(a, b) {
            if (this.taggedPhotoIds) {
                if (this.source === c.PHOTOS_OF_YOU_SUGGESTIONS && !b.self_tag) return;
                this.taggedPhotoIds.push(b.photo_fbid)
            }
        };
        d.clearAlbumBoundaries = function() {
            this._albumBoundaries = {
                start: 0,
                end: 0,
                dir: 0
            }
        };
        d.close = function() {
            if (!this.isOpen) return;
            b("FunnelLogger").appendActionWithTag(p, "close_snowlift", b("PhotoSessionLog").closingTypeToString(this.closingAction));
            b("FunnelLogger").endFunnel(p);
            this._albumFBID = null;
            this.hideMorePhotos();
            this.hidePivotSlide();
            this._pauseVideoIfNeeded();
            this._destroyVideoIfNeeded(this._videoPlayerStateManager);
            this._bodyMutationObserver && (this._bodyMutationObserver.disconnect(), this._bodyMutationObserver = null);
            this.isOpen = !1;
            this._navCount = 0;
            this.clearAlbumBoundaries();
            this.isFullScreenSupported && b("FullScreen").disableFullScreen();
            b("CSS").removeClass(document.body, "fbPhotoSnowliftFullScreenMode");
            this.spotlight.hide();
            this.openExplicitly = !1;
            this.postProcessTaggedPhotos();
            b("Arbiter").inform("lwf/unmount");
            b("Arbiter").unsubscribe(this.saveTagSubscription);
            this.taggedPhotoIds = [];
            this.closeDirty = !0;
            b("setTimeoutAcrossTransitions")(this.closeCleanup.bind(this), 0);
            this.snowflake && (b("CSS").removeClass(this.root, "snowflake"), this.extraClasses.forEach(function(a) {
                b("CSS").removeClass(this.root, a)
            }, this));
            this.extraClasses = [];
            this.snowflake = !1;
            this.firstInSet = null;
            this.movementDelta = 0
        };
        d.createLoader = function(a) {
            var d = this;
            if (this.currentImageSize === null) this.adjustStageSize(c.STAGE_MIN);
            else {
                var e = this.getStageSize(this.currentImageSize);
                e = new(b("Vector"))(Math.max(e.x, this.getMinimumStageWidth()), Math.max(e.y, c.STAGE_MIN.y));
                e = this.getImageSizeInStage(this.currentImageSize, e);
                this._elem && this._elem.getAttribute("data-ploi") && (this.thumbSrc = b("PhotoSnowliftLoader").getImageURL(this._elem));
                if (this.thumbSrc === null) this.adjustStageSize(e);
                else {
                    var f = b("TimeSlice").getGuardedContinuation("Snowlift thumb image load");
                    f = b("DOM").create("img", {
                        className: "spotlight",
                        alt: "",
                        src: this.thumbSrc,
                        style: {
                            width: e.x + "px",
                            height: e.y + "px"
                        },
                        onload: f.bind(void 0, b("emptyFunction"))
                    });
                    var g;
                    this.thumbSpherical && this.sphericalPhotoData ? g = b("PhotoSnowliftViewableUtils").fromSphericalPhotoData(this.sphericalPhotoData, this) : g = b("PhotoSnowliftViewableUtils").fromImageElement(f, this.thumbSpherical);
                    this._useViewable(g, e, !1)
                }
            }
            this.setLoadingState(this.STATE_IMAGE_PIXELS, !0);
            a && window.setTimeout(function() {
                var e = function(b) {
                        b === void 0 && (b = null);
                        if (!d.isOpen) return;
                        (!d.stream || !d.stream.errorInCurrent()) && (d._switchViewable(b ? b : a, d.currentImageSize), d.setLoadingState(c.STATE_IMAGE_DATA, !1))
                    },
                    f = b("TimeSlice").getGuardedContinuation("PhotoSnowlift image load");
                e = f.bind(null, e);
                if (b("EncryptedImg").isEncrypted(a)) b("EncryptedImg").load(a, e);
                else {
                    f = new Image();
                    var g = b("Event").listen(f, "load", e);
                    e = function() {
                        g && (g.remove(), g = null)
                    };
                    b("Arbiter").subscribeOnce("PhotoSnowlift.SWITCH_IMAGE", e);
                    b("Arbiter").subscribeOnce("PhotoSnowlift.CLOSE", e);
                    f.src = a
                }
                d._log(a)
            }, 0);
            b("CSS").hide(this.stageActions);
            this.setStagePagersState("disabled")
        };
        d.initialDataFetched = function(a) {
            b("PhotoSessionLog").setPhotoSet(this.stream.getPhotoSet());
            b("PhotoSessionLog").setLogFbids(a.logids);
            a.eid && b("PhotoSessionLog").setEid(a.eid);
            this._albumBoundaries.start = this.stream.getCursor();
            a = this.stream.getCurrentImageData();
            if (a) {
                var c = this.getImageURL(a);
                c = !b("PhotoSnowliftLoggingConfig").checkForImage || c;
                c && (b("PhotoSessionLog").addPhotoView(a.info, this.shouldShowHiRes(a), this.isFullScreenSupported && b("FullScreen").isFullScreen()), b("PhotoSnowliftLoggingConfig").logOnlyOnInit && b("PhotoSessionLog").logInitialLoad())
            }
            c = this.stream.getCurrentExtraData();
            c && c.source !== void 0 && (this.source = parseInt(c.source, 10), b("PhotoSessionLog").setSource(this.source));
            this.pageHandlers && this.pageHandlers.release();
            this.pageHandlers = new(b("SubscriptionsHandler"))();
            this.pageHandlers.addSubscriptions(b("Event").listen(this.root, "click", this.pageListener.bind(this)), b("Event").listen(this.root, "mouseleave", this.mouseLeaveListener.bind(this)));
            this.showZoom(a);
            b("CSS").show(this.stageActions);
            this.root.setAttribute("aria-busy", "false");
            this._updateObjectionableWarning(a);
            a.info.disablecontextmenu ? this.disableContextMenu() : this.enableContextMenu()
        };
        d.adjustScrollerIfNecessary = function() {
            window.clearTimeout(this.scrollerTimeout), this.scrollerTimeout = window.setTimeout(this.adjustScroller.bind(this), 0)
        };
        d.adjustForResize = function() {
            this.currentMinSize = null, this.adjustStageSize(), this.adjustForNewData()
        };
        d._adjustStageSizeForPixelRatio = function(a) {
            window.devicePixelRatio && window.devicePixelRatio > 1 && (a = new(b("Vector"))(a.x * window.devicePixelRatio, a.y * window.devicePixelRatio));
            return a
        };
        d.getImageURL = function(a) {
            if (a.video) return null;
            else if (a.smallurl && !this.shouldShowHiRes(a)) return a.smallurl;
            return a.url
        };
        d.getImageOrVideoDimensions = function(a) {
            if (a.video) {
                a = this.getVideoElement(a.video);
                if (a) return this.getVideoSize(a)
            }
            return this._viewable.getNaturalDimensions()
        };
        d.getStageSize = function(a, d) {
            var e = b("Vector").getViewportDimensions();
            this._isLiveBroadcast && (e.y -= 200);
            var f = new(b("Vector"))(a.x, a.y);
            d && (f = new(b("Vector"))(Math.max(a.x, d.x), Math.max(a.y, d.y)));
            if (this.isFullScreenSupported && b("FullScreen").isFullScreen()) {
                a = screen.height - c.FULL_SCREEN_PADDING * 2;
                return new(b("Vector"))(this.rhcCollapsed ? screen.width : screen.width - c.SIDEBAR_SIZE_MAX, a)
            } else {
                d = Math.min(f.x, e.x - c.SIDEBAR_SIZE_MAX - c.STAGE_CHROME.x);
                e = e.y - c.STAGE_CHROME.y;
                a = Math.min(f.y, e)
            }
            if (d === 0 && a === 0) return new(b("Vector"))(0, 0);
            e = d / a;
            f = f.x / f.y;
            return e < f ? new(b("Vector"))(d, Math.round(d / f)) : new(b("Vector"))(Math.round(a * f), a)
        };
        d.getExtraVerticalSpace = function() {
            return this.getVideoOnStage() ? c.VIDEO_BOTTOM_BAR_SPACE * 2 : 0
        };
        d.getComponentsHeight = function() {
            var a = this.getVideoOnStage();
            if (a) {
                a = b("ge")(a);
                if (a) return this.getVideoComponentsHeight(a)
            }
            return 0
        };
        d.getMinimumStageWidth = function() {
            var a = c.STAGE_MIN.x;
            if (this.getVideoOnStage()) return a;
            b("PhotoSnowliftActionsGating").ALLOW_MAKE_PROFILE_PICTURE_BUTTON && (a += c.PROFILE_PICTURE_BUTTON_WIDTH);
            return a
        };
        d.getImageSizeInStage = function(a, c) {
            var d = a.x;
            a = a.y;
            var e = this.getComponentsHeight(),
                f = this.getExtraVerticalSpace();
            a -= e;
            c = new(b("Vector"))(c.x, c.y - e - f);
            if (d >= c.x || a >= c.y) {
                f = c.x / c.y;
                var g = d / a;
                f < g ? (d = c.x, a = Math.round(d / g)) : f > g ? (a = c.y, d = Math.round(a * g)) : (d = c.x, a = c.y)
            }
            return new(b("Vector"))(d, a + e)
        };
        d.adjustStageSize = function(a) {
            var d = this.currentImageSize;
            if (a) d = a;
            else {
                a = this.stream && this.stream.getCurrentImageData();
                a && (d = this.getImageOrVideoDimensions(a))
            }
            if (!d) return;
            this.currentImageSize = d;
            a = this.getExtraVerticalSpace();
            this.shouldStretch && !this.getVideoOnStage() && d.x > d.y && d.x <= c.TIMELINE_STRETCH_WIDTH && d.x >= c.TIMELINE_STRETCH_MIN && (d.y = Math.round(d.y * c.TIMELINE_STRETCH_WIDTH / d.x), d.x = c.TIMELINE_STRETCH_WIDTH);
            var e = this.getStageSize(d, this.currentMinSize);
            this.currentMinSize || (this.currentMinSize = new(b("Vector"))(0, 0));
            this.currentMinSize = new(b("Vector"))(Math.max(e.x, this.getMinimumStageWidth(), this.currentMinSize.x), Math.max(e.y, c.STAGE_MIN.y, this.currentMinSize.y));
            e = this.getImageSizeInStage(d, this.currentMinSize);
            d = this.currentMinSize.x - e.x;
            var f = this.currentMinSize.y - e.y;
            d > 0 && d < c.PADDING_MIN ? this.currentMinSize.x -= d : f > 0 && f < c.PADDING_MIN && (this.currentMinSize.y -= f);
            f = this.currentMinSize.x + c.SIDEBAR_SIZE_MAX;
            this.rhcCollapsed && (f = this.currentMinSize.x);
            var g = this.getVideoOnStage() && this.pivotsCarouselElement,
                h = 0,
                i = this.currentMinSize.y;
            if (g) {
                var j = this.pivotsCarouselElement.clientHeight;
                h = Math.ceil(j / 100) * 100;
                i += h
            }
            this.snowliftPopup.style.cssText = "width:" + f + "px;height:" + i + "px;";
            j = this.currentMinSize.y - a;
            f = j + h;
            if (b("UserAgent_DEPRECATED").firefox()) {
                var k = b("Style").get(this.stageWrapper, "font-size");
                j = j / parseFloat(k) + "em";
                f = f / parseFloat(k) + "em"
            } else j += "px", f += "px";
            this.stageWrapper.style.cssText = "width:" + this.currentMinSize.x + "px;line-height:" + j + ";";
            if (this.getVideoOnStage()) {
                this.videoStage.style.cssText = "width:" + this.currentMinSize.x + "px;height:" + f + ";";
                if (!this._inputBarAdjusted && this._isLiveBroadcast) {
                    i = parseInt(b("Style").get(this._liveInputBar, "right"), 10);
                    b("Style").set(this._liveInputBar, "right", i + d / 2 + "px");
                    this._inputBarAdjusted = !0
                }
            }
            e.y -= this.getComponentsHeight();
            this.setMediaElementSize(e);
            g && this.setPivotCarouselElementWidth(k);
            a = this.getTagger();
            a && a.repositionTagger();
            this.adjustScrollerIfNecessary()
        };
        d.setMediaElementSize = function(a) {
            var c = this.image;
            if (this.getVideoOnStage())
                if (this._videoPlayerStateManager && this._videoPlayerStateManager.setDimensions) {
                    this._videoPlayerStateManager.setDimensions(a.x, a.y);
                    return
                } else c = b("DOM").scry(this.videoStage, "._53j5")[0] || c;
            else {
                this._viewable.setDimensions(a);
                return
            }
            if (!c) return;
            c.style.cssText = "width:" + a.x + "px;height:" + a.y + "px;"
        };
        d.setPivotCarouselElementWidth = function(a) {
            var c = this.videoStage.clientWidth;
            b("UserAgent_DEPRECATED").firefox() ? c = c / parseFloat(a) + "em" : c += "px";
            this.pivotsCarouselElement.style.width = c
        };
        d.adjustForNewData = function() {
            var a = this._viewable.getDimensions(),
                c = b("DOM").scry(this.stage, "div.tagsWrapper")[0];
            c && (b("Style").set(c, "width", a.x + "px"), b("Style").set(c, "height", a.y + "px"))
        };
        d.setLoadingState = function(a, d) {
            switch (a) {
                case c.STATE_IMAGE_PIXELS:
                    b("CSS").conditionClass(this.root, "imagePixelsLoading", d);
                    break;
                case c.STATE_IMAGE_DATA:
                    this.loadingStates[a] = d;
                    b("CSS").conditionClass(this.root, "imageLoading", d);
                    break;
                case c.STATE_HTML:
                    this.loadingStates[a] = d;
                    b("CSS").conditionClass(this.root, "dataLoading", d);
                    this.rhc.setAttribute("aria-busy", d ? "true" : "false");
                    break
            }
        };
        d.destroy = function() {
            var a = this;
            this.stageHandlers && this.stageHandlers.release();
            this.stageHandlers = null;
            this.pageHandlers && this.pageHandlers.release();
            this.pageHandlers = null;
            this._actionsMenuSubscriptionsHandler && (this._actionsMenuSubscriptionsHandler.release(), this._actionsMenuSubscriptionsHandler = null);
            b("gkx")("1418061") && this._vpcsToDestroyOnDestroy.forEach(function(b) {
                a._destroyVideoIfNeeded(b)
            });
            this._vpcsToDestroyOnDestroy.clear();
            this._videoPlayerStateManager = null
        };
        d.checkState = function(a, d) {
            var e = this;
            d === void 0 && (d = !1);
            if (a != c.STATE_ERROR && !this.loadingStates[a]) return;
            switch (a) {
                case c.STATE_IMAGE_DATA:
                    var f = this.stream.getCurrentImageData();
                    if (f) {
                        var g = this.getImageURL(f);
                        g ? this._switchViewable(g, null, !0, d) : f.video && (f.shouldDelayStartupVideo ? b("setImmediate")(function() {
                            return e.switchVideo(f.video, !0)
                        }) : this.switchVideo(f.video, !0));
                        this.setLoadingState(a, !1)
                    }
                    break;
                case c.STATE_HTML:
                    this.stream.getCurrentHtml() && (this.swapData(), this.setLoadingState(a, !1));
                    break;
                default:
                    this.stream.errorInCurrent() && (this._viewable.hide(), b("CSS").show(this.errorBox));
                    break
            }
        };
        d.toggleLikeButton = function() {
            var a = b("DOM").scry(this.buttonActions, "a.fbPhotosPhotoLike")[0];
            if (a) {
                var c = b("DOM").find(this.root, ".likeCount"),
                    d = b("DOM").find(c, ".likeCountNum"),
                    e = b("CSS").hasClass(a, "viewerLikesThis");
                b("FunnelLogger").appendActionWithTag(p, e ? "unlike_photo" : "like_photo", "snowlift-feedback");
                c && (e ? b("DOM").setContent(d, parseInt(d.textContent, 10) - 1) : b("DOM").setContent(d, parseInt(d.textContent, 10) + 1));
                b("CSS").toggleClass(a, "viewerLikesThis");
                b("CSS").removeClass(a, "viewerAlreadyLikedThis")
            }
        };
        d.likePhotoWithKey = function() {
            return b("LikeConfirmer").like(this.likePhoto.bind(this), b("getActiveElement")())
        };
        d.updateTagBox = function(a, c) {
            this.unhiliteAllTags();
            a = b("ge")(a);
            if (!a) return;
            b("CSS").addClass(a, "tagBox");
            b("CSS").addClass(a, "tagBoxPendingResponse");
            b("CSS").removeClass(a, "tagBoxPending");
            b("CSS").hide(b("DOM").find(a, "span.tagForm"));
            c ? b("CSS").show(b("DOM").find(a, "span.tagApproved")) : b("CSS").show(b("DOM").find(a, "span.tagIgnored"))
        };
        d.rotate = function(a) {
            var d = this,
                e = this.stream.getCursor();
            if (this.getVideoOnStage()) {
                var f = a == "left" ? 270 : 90;
                !this.videoRotateURI && j(0, 197);
                b("Bootloader").loadModules(["VideoRotate"], function(a) {
                    new a(e, d.videoRotateURI).motionRotate(f)
                }, "PhotoSnowlift");
                return
            }
            var g = babelHelpers["extends"]({
                fbid: e,
                opaquecursor: this.stream.getOpaqueCursor(e),
                cs_ver: b("PhotosConst").VIEWER_SNOWLIFT
            }, this.stream.getPhotoSetQuery());
            g[a] = 1;
            this.setLoadingState(c.STATE_IMAGE_DATA, !0);
            this.setLoadingState(this.STATE_IMAGE_PIXELS, !0);
            this._viewable.hide();
            new(b("AsyncRequest"))("/ajax/photos/photo/rotate/").setAllowCrossPageTransition(!0).setData(g).setErrorHandler(this.rotationError.bind(this, e)).setFinallyHandler(this.rotationComplete.bind(this, e)).setMethod("POST").setReadOnly(!1).send()
        };
        d.rotationComplete = function(a, b) {
            a == this.stream.getCursor() && (this.setLoadingState(c.STATE_IMAGE_DATA, !1), this._switchViewable(this.getImageURL(this.stream.getCurrentImageData())), this.swapData())
        };
        d.rotationError = function(a, d) {
            a == this.stream.getCursor() && (this.setLoadingState(c.STATE_IMAGE_DATA, !1), this._switchViewable(this.getImageURL(this.stream.getCurrentImageData())), b("Bootloader").loadModules(["AsyncResponse"], function(a) {
                a.defaultErrorHandler(d)
            }, "PhotoSnowlift"))
        };
        d.saveTagsFromPayload = function(a) {
            this.storeFromData(a), "data" in a && this.stream.getCursor() in a.data && this.swapData()
        };
        d.saveEdit = function() {
            var a = this;
            if (!b("CSS").hasClass(this.root, "fbPhotoSnowliftEditMode")) return;
            b("Bootloader").loadModules(["PhotoInlineEditor", "FormSubmit"], function(b, c) {
                b = b.getInstance(a.getViewerConst());
                b && c.send(b.getForm().controller)
            }, "PhotoSnowlift")
        };
        d.mouseLeaveListener = function(a) {
            this.unhiliteAllTags(), this.reHilitePendingTag()
        };
        d.showPagers = function(a) {
            window.clearTimeout(this.fadePagerTimer), this.setStagePagersActivated(!0), a !== void 0 && (this.fadePagerTimer = window.setTimeout(this.hidePagers.bind(this), a))
        };
        d.hidePagers = function() {
            if (this._mouseOnPhotoStage || this._actionMenuOpen) return;
            window.clearTimeout(this.fadePagerTimer);
            this.setStagePagersActivated(!1)
        };
        d.getTagger = function() {
            return this.PhotoTagger && this.PhotoTagger.getInstance(b("PhotosConst").VIEWER_SNOWLIFT)
        };
        d.reHilitePendingTag = function() {
            var a = b("ge")(this.hilitedTag);
            if (a && b("CSS").hasClass(a, "showPendingTagName")) return;
            a = b("DOM").scry(this.stage, "div.tagsWrapper div.showPendingTagName")[0];
            a && this.switchHilitedTags(a.id)
        };
        d.currentTagHasPrecedence = function(a) {
            if (!this.hilitedTag) return !1;
            if (this.stream.getCurrentExtraData().tagRects[this.hilitedTag] === void 0) {
                this.hilitedTag = null;
                return !1
            }
            var c = this.stream.getCurrentExtraData().tagRects[this.hilitedTag];
            c = new(b("Rect"))(c.t + c.h() / 2, c.r, c.b + (b("PhotosUtils").isFacebox(this.hilitedTag) ? 10 : 0), c.l, c.domain);
            return c.contains(a)
        };
        d.getVideoOnStage = function() {
            var a = this.stream && this.stream.getCurrentImageData();
            return a && a.video
        };
        d.shouldPageOnAction = function(a, c) {
            var d = this;
            if (!this.isOpen || b("LikeConfirmer").isShowingConfirmation()) return !1;
            var e = b("isNode")(c) && (b("Parent").byClass(c, "snowliftPager") || b("Parent").byClass(c, "stagePagers") || b("Parent").byClass(c, "pivotPageColumn")),
                f = b("isNode")(c) && b("Parent").byClass(c, "stage"),
                g = b("CSS").hasClass(c, "faceBox");
            g = !b("CSS").hasClass(this.root, "taggingMode") && g && !e;
            if (g) {
                this.showingTypeaheadSuggestions || (this.getTagger().updateWithSuggestions(), window.setTimeout(function() {
                    b("DOM").find(d.getTagger().tagger, "input.textInput").focus()
                }, 0));
                this.showingTypeaheadSuggestions = !this.showingTypeaheadSuggestions;
                return !1
            }
            var h = f && b("DOM").scry(this.stage, ".fbPhotosPhotoTagboxBase.tagBox.hover a");
            if (h && h.length > 0) {
                h[0].click();
                return !1
            }
            h = f && b("CSS").hasClass(this.root, "taggingMode") || b("Parent").byClass(c, "tagBoxPending") || b("Parent").byClass(c, "tagBoxPendingResponse") || b("Parent").byClass(c, "fbPhotoTagApprovalBox") || b("Parent").byClass(c, "tag") || b("Parent").byClass(c, "sphericalHeadingIndicator") || b("Parent").byClass(c, "sphericalVolumeControl") || b("Parent").byClass(c, "sphericalPhotoWrapper");
            return h ? !1 : a == b("Keys").LEFT || a == b("Keys").RIGHT || a == q || a == r || e || g || f
        };
        d.keyHandler = function(a, d) {
            if (d.getModifiers().any || b("Layer").getTopmostLayer() !== this.spotlight) return !0;
            switch (b("Event").getKeyCode(d)) {
                case b("Keys").LEFT:
                case b("Keys").RIGHT:
                case q:
                case r:
                    this.pageListener(d);
                    return !1;
                case s:
                    b("FunnelLogger").appendActionWithTagIfNew(p, b("FullScreen").isFullScreen() ? "fullscreen_exit" : "fullscreen_enter", "key-f");
                    return this.toggleFullScreen();
                case t:
                    return this.likePhotoWithKey();
                case b("Keys").SPACE:
                    this.showPagers(c.PAGER_FADE);
                    return !1
            }
            return null
        };
        d.shouldHandlePendingTag = function(a) {
            var c = this.getTagger();
            if (!c || !c.tags.length) return !1;
            a = b("PhotosUtils").absoluteToNormalizedPosition(this.getImage(), b("Vector").getEventPosition(a));
            c = c.findNearestTag(a);
            if (!c || !b("CSS").hasClass(c.node, "tagBoxPending")) return !1;
            b("Arbiter").inform("PhotoTagApproval.PENDING_TAG_PHOTO_CLICK", {
                id: c.id,
                version: this.getVersionConst()
            });
            return !0
        };
        d.warnLeavePage = function(a) {
            new(b("Dialog"))().setTitle(i._("Are You Sure You Want To Leave This Page?")).setBody(i._("You have unsaved changes that will be lost if you leave the page.")).setButtons([{
                name: "leave_page",
                label: i._("Leave This Page"),
                handler: a
            }, {
                name: "continue_editing",
                label: i._("Stay on This Page"),
                className: "inputaux"
            }]).setModal(!0).show()
        };
        d.getUsesOpaqueCursor = function() {
            return this.stream.getUsesOpaqueCursor()
        };
        d.getOpaqueCursor = function(a) {
            return this.stream.getOpaqueCursor(a)
        };
        d.setReachedLeftEnd = function() {
            this.stream.setReachedLeftEnd()
        };
        d.setReachedRightEnd = function() {
            this.stream.setReachedRightEnd()
        };
        d._initLitestandShareAttachments = function() {
            var a = b("DOMQuery").scry(this.root, "." + b("LitestandShareAttachment").getSimpleCropClass());
            a.forEach(function(a) {
                return b("LitestandShareAttachment").init(a)
            })
        };
        d.showMorePhotos = function(a, c) {
            if (this._showingMorePhotos) return;
            this._showingMorePhotos = !0;
            this.searchPivot || (this.searchPivot = this.overlay.appendChild(document.createElement("div")));
            b("CSS").addClass(this.stageWrapper, "_5ymv");
            this.searchPivotComponent = new(b("ReactComponentRenderer"))(b("PhotosetSearchPivot.react"), this.searchPivot);
            this.searchPivotComponent.setProps({
                className: "_27g",
                fbid: a,
                onclose: this.hideMorePhotos.bind(this),
                endofalbum: c || !1,
                withBackground: !0
            })
        };
        d.hideMorePhotos = function() {
            this.searchPivotComponent && this._showingMorePhotos && (this._showingMorePhotos = !1, b("CSS").removeClass(this.stageWrapper, "_5ymv"), this.searchPivotComponent.setProps({
                fbid: null
            }))
        };
        d.showPivotSlide = function(a, c) {
            if (this.onExtraSlide) return;
            this.onExtraSlide = !0;
            b("CSS").addClass(this.stageWrapper, "_3tvf");
            this.pivotSlide || (this.pivotSlide = b("DOM").create("div"), b("DOM").insertBefore(this.stageActions, this.pivotSlide));
            this.pivotSlideComponent = new(b("ReactComponentRenderer"))(b("PhotosetPivotSlide.react"), this.pivotSlide);
            this.pivotSlideComponent.setProps({
                fbid: a,
                isAlbum: this._isAlbum,
                albumOwnerName: this._albumOwnerName,
                visible: !0,
                onReturn: this.page.bind(this, this._albumBoundaries.dir, c)
            })
        };
        d.hidePivotSlide = function() {
            this.pivotSlideComponent && this.onExtraSlide && (this.pivotSlideComponent.setProps({
                visible: !1
            }), b("CSS").removeClass(this.stageWrapper, "_3tvf")), this.onExtraSlide = !1
        };
        d.logImpressionDetailsForPhoto = function() {
            var a = [].concat(b("DOM").scry(b("$")("fbPhotoSnowliftTagList"), "input.photoImpressionDetails"), b("DOM").scry(b("$")("fbPhotoSnowliftFeedback"), "input.photoImpressionDetails"));
            if (a.length === 0) return;
            var c = {};
            for (var d = 0; d < a.length; d++) c[a[d].name] = a[d].value;
            if (this.getVideoOnStage()) c.width = 0, c.height = 0;
            else {
                a = this._viewable.getNaturalDimensions();
                c.width = a.x;
                c.height = a.y
            }
            b("PhotoSessionLog").addDetailData(this.stream.getCursor(), c)
        };
        d.recacheData = function() {
            if (!this.loadingStates.html) {
                var a = this.stream.getCurrentHtml();
                for (var c in a) {
                    var d = b("ge")(c);
                    d && (a[c] = Array.from(d.childNodes), b("DOM").empty(d))
                }
                this.stream.containsUFIConfig() && this._clearUFIContainers()
            }
        };
        d._useViewable = function(a, c, d, e) {
            var f = this;
            e === void 0;
            if (d && this._viewable.isReady()) return;
            e = function() {
                var d = f._viewable;
                f._viewable = a;
                b("DOM").replace(d.getElement(), a.getElement());
                f.setLoadingState(f.STATE_IMAGE_PIXELS, !1);
                f.adjustStageSize(c);
                window.setTimeout(function() {
                    f.isOpen && (f.adjustStageSize(), f.adjustForNewData())
                }, 0);
                d.suspend()
            };
            a.whenReady(e)
        };
        d.makeNewImage = function(a, d) {
            var e = this;
            this.imageLoadingTimer ? (window.clearTimeout(this.imageLoadingTimer), this.imageLoadingTimer = null) : d || (this.imageRefreshTimer = window.setTimeout(this.reloadIfTimeout.bind(this), c.LOADING_TIMEOUT));
            d = b("DOM").create("img", {
                className: "spotlight",
                alt: ""
            });
            d.setAttribute("aria-describedby", "fbPhotosSnowliftCaption");
            d.setAttribute("aria-busy", "true");
            var f = function() {
                window.clearTimeout(e.imageRefreshTimer), e.image.setAttribute("aria-busy", "false"), e.setLoadingState(e.STATE_IMAGE_PIXELS, !1), window.setTimeout(function() {
                    e.isOpen && (e.adjustStageSize(), e.adjustForNewData())
                }, 0)
            };
            b("Event").listen(d, "load", f);
            this._log(a);
            b("EncryptedImg").isEncrypted(a) ? b("EncryptedImg").insertIntoDOM(a, d) : d.src = a;
            return d
        };
        d._updateObjectionableWarning = function(a) {
            a.info.ocmarkup ? (this.showObjectionableWarning(a.info.ocmarkup), this.obscuredByOverlay = !0) : (this.hideObjectionableWarning(), this.obscuredByOverlay = !1)
        };
        d.handleObjectionableContentToggleButtonClicked = function(a, b) {
            this.obscuredByOverlay = b, b && this.getTagger().deactivateTagging()
        };
        d._switchViewable = function(a, c, d, e) {
            e === void 0 && (e = !1);
            b("CSS").hide(this.errorBox);
            e || this._viewable.hide();
            this.setLoadingState(this.STATE_IMAGE_PIXELS, !0);
            var f = this.stream && this.stream.getCurrentImageData();
            f && (e || b("PhotoSessionLog").addPhotoView(f.info, this.shouldShowHiRes(f), this.isFullScreenSupported && b("FullScreen").isFullScreen()), this._updateObjectionableWarning(f));
            var g = this._viewable.getElement().children[0],
                h;
            this.isSpherical() ? h = !!this.sphericalPhotoData && f.info.fbid.toString() === this.sphericalPhotoData.fbid : h = g.src === a;
            if (!h) {
                h = b("PhotoSnowliftViewableUtils").fromStreamData(f, this);
                this.sphericalPhotoData = null;
                this.isFullScreenSupported && b("FullScreen").isFullScreen() && (h.onToggleIntoFullScreen(), h.onEnterFullScreen());
                this._log(a);
                this._useViewable(h, c, !1, e)
            } else g.setAttribute("alt", f.info.caption), g.setAttribute("aria-busy", "true"), this.adjustStageSize(c), this._viewable.show(), this._log(a);
            d && this.stream.preloadImages(this.shouldShowHiRes.bind(this));
            b("Arbiter").inform("PhotoSnowlift.SWITCH_IMAGE")
        };
        d._preloadNextVideo = function() {
            var a = this.stream.calculatePositionForMovement(1);
            a = this.stream.getCursorAt(a);
            a = this.stream.getImageData(a);
            a && a.video && a.controller && a.controller.preload()
        };
        d._emptyVideoStage = function() {
            b("DOM").empty(this.videoStage)
        };
        d.switchVideo = function(a, c, d) {
            var e = this;
            this._pauseVideoIfNeeded();
            var f = "swf_" + a;
            window.videoStage = this.videoStage;
            this._emptyVideoStage();
            if (c) {
                this._preloadNextVideo();
                b("CSS").addClass(this.stageWrapper, "showVideo");
                var g = this.stream.getCurrentImageData();
                this.shouldRenderVideoPivots && (b("CSS").hide(this.nextPager), b("CSS").hide(this.prevPager));
                var h, i;
                this._abortVideoWhenSwitch = !0;
                if (g.useReactPlayer) {
                    h = b("DOM").create("div");
                    c = new(b("VideoData"))(g.videoData);
                    var j = g.PhotoSnowliftVideoNode;
                    j && !this.PhotoSnowliftVideoNode && (this.PhotoSnowliftVideoNode = j);
                    var k = j.getVideoNode(c.getVideoID());
                    if (k) h = k.getVideoContainer(), this._videoPlayerStateManager = k.getVideoPlayerController(), k.updateDimension(g.width, g.height), g.keepReactVideoNodeLoaded && (this._abortVideoWhenSwitch = !1);
                    else {
                        k = g.PhotoSnowliftVideo;
                        b("ReactDOM").render(o.jsx(k, {
                            width: g.width,
                            height: g.height,
                            videoData: c,
                            ref: function(a) {
                                return i = a
                            }
                        }), h);
                        this._videoPlayerStateManager = i.getVpc();
                        j.destroyVideoNode()
                    }
                } else h = g.video_element, b("DOM").scry(h, "._ox1")[0].style.cssText = "", this._videoPlayerStateManager = g.controller;
                this._vpcsToDestroyOnDestroy.add(this._videoPlayerStateManager_);
                k = null;
                this.pivotsCarouselElement && (k = b("DOMQuery").scry(this.pivotsCarouselElement, "._32_l"));
                k && k.forEach(function(a) {
                    var c = a.getAttribute("data-fbid"),
                        d = e.stream.getCursor();
                    a = b("DOM").find(a, "._1pqn");
                    c === d ? b("CSS").show(a) : b("CSS").hide(a)
                });
                b("CSS").addClass(h, "videoStageContainer");
                b("DOM").appendContent(this.videoStage, h);
                b("DOM").appendContent(this.videoStage, this.pivotsCarouselElement);
                this.videoContainer = h;
                window[f] && !b("ge")(f) && window[f].write(a);
                c = "video_warning_" + a;
                j = b("ge")(a);
                this.videoWarnings || (this.videoWarnings = []);
                j && this.videoWarnings[c] && b("DOM").setContent(j, this.videoWarnings[c]);
                g.abortedLoadingOtherVideos && (this._preloadTimeout && window.clearTimeout(this._preloadTimeout), this._preloadTimeout = window.setTimeout(function() {
                    var a = [e.stream.getPreviousImageData(), e.stream.getNextImageData()],
                        b = a[0];
                    a = a[1];
                    a && a.controller && a.controller.preload();
                    b && b.controller && b.controller.preload()
                }, w));
                g.useReactPlayer || this._videoPlayerStateManager.reset();
                this._videoPlayerStateManager.collectFeedTrackingData();
                this._videoPlayerStateManager.hasOption("PhotoSnowlift", "isInSnowlift") || this._videoPlayerStateManager.registerOption("PhotoSnowlift", "isInSnowlift", function() {
                    return !0
                });
                this._videoPlayerStateManager.emit("PhotoSnowlift/enterSnowlift");
                k = b("gkx")("1573969");
                k && this.adjustStageSizeForVideo(a);
                if (this._autoplayVideos) {
                    j = d || "user_initiated";
                    this._videoPlayerStateManager.play(j)
                }
                this._autoplayNextVideo && this._videoPlayerStateManager.addListener("finishPlayback", function() {
                    var a = g.info.fbid.toString();
                    if (e.haltAutoplay && a !== e.stream.fbidList[e.stream.fbidList.length - 1]) {
                        if (e.autoplayOptionScreenConfig) {
                            a = e.autoplayOptionScreenConfig.controller;
                            a.registerCallbacks(h, e.chooseToReplayVideo.bind(e, e._videoPlayerStateManager), e.handleAutoplay.bind(e, g))
                        }
                    } else e.handleAutoplay(g)
                });
                k || window.setTimeout(this.adjustStageSizeForVideo.bind(this, a), 0)
            } else window[f] && window[f].addVariable("video_autoplay", 0), this.videoLoadTimer && window.clearTimeout(this.videoLoadTimer), b("CSS").removeClass(this.stageWrapper, "showVideo")
        };
        d.removeAutoplayOptionScreen = function() {
            this.autoplayOptionScreenConfig && this.autoplayOptionScreenConfig.controller.removeSelf()
        };
        d.chooseToReplayVideo = function(a) {
            a.play("user_initiated"), this.removeAutoplayOptionScreen(), this.haltAutoplay = !1
        };
        d.getVideoSize = function(a) {
            a = new(b("Vector"))(a.getAttribute("data-video-width"), +a.getAttribute("data-video-height") + this.getVideoComponentsHeight(a));
            if (this._videoPlayerStateManager && this._videoPlayerStateManager.isSpherical && this._videoPlayerStateManager.isSpherical()) {
                var c = b("Vector").getViewportDimensions(),
                    d = c.x;
                c = c.x / 2;
                return new(b("Vector"))(d, c)
            } else return a
        };
        d.getVideoElement = function(a) {
            return b("DOM").scry(this.videoStage, "._ox1")[0]
        };
        d.getVideoComponentsHeight = function(a) {
            var c = 0;
            a = b("Parent").bySelector(a, "._1c_u");
            if (!a) return 0;
            a = b("DOM").scry(a, "._2i84");
            if (a.length) {
                a = a[0].getBoundingClientRect();
                c = a.bottom - a.top
            }
            return c
        };
        d.handleServerError = function(a, c) {
            b("DOM").setContent(this.errorBox, a), this.storeFromData(c)
        };
        d.fixButtonText = function(a) {
            if (!this.buttonTruncateGk) return;
            var c = b("DOM").scry(a, ".photosTruncatingUIButton");
            a = parseInt(b("Style").get(a, "width"), 10);
            if (a > u) {
                a = {
                    tagPhoto: i._("Tag Photo"),
                    doneTagPhoto: i._("Done Tagging"),
                    addLocation: i._("Add Location"),
                    editPhoto: i._("Edit")
                };
                for (var d = 0; d < c.length; d++) {
                    var e = c[d];
                    b("CSS").addClass(e, "_2n0k");
                    b("Tooltip").set(e, a[e.getAttribute("data-buttonname")], "below", "center")
                }
            }
        };
        d._clearUFIContainers = function() {
            Object.entries(this.ufiContainers).forEach(function(a) {
                a[0];
                a = a[1];
                return a && b("DOM").empty(a)
            })
        };
        d._swapUFI = function() {
            var a = this;
            this.stream.getCurrentUFIRoots(function(c, d) {
                var e = c.ufiMainRoot,
                    f = c.ufiComposerRoot;
                c = c.ufiStageActionsRoot;
                var g = a.ufiContainers,
                    h = g.ufiMainContainer,
                    i = g.ufiComposerContainer;
                g = g.ufiStageActionsContainer;
                h && b("DOM").setContent(h, e);
                i && b("DOM").setContent(i, f);
                g && b("DOM").setContent(g, c);
                d && d.emit("inserted")
            })
        };
        d.swapData = function() {
            var a = this,
                d = this.stream.getCurrentHtml();
            this._bodyMutationObserver && this._bodyMutationObserver.disconnect();
            if (d) {
                this.setLoadingState(c.STATE_HTML, !1);
                this._swapUFI();
                this._bodyMutationObserver == null && (this._bodyMutationObserver = new(b("MutationObserver"))(function(b) {
                    a.adjustScrollerIfNecessary()
                }));
                this.rhcBody instanceof Node && this._bodyMutationObserver.observe(this.rhcBody, {
                    attributes: !1,
                    characterData: !1,
                    childList: !0,
                    subtree: !0
                });
                for (var e in d) {
                    var f = b("ge")(e);
                    f && b("DOM").setContent(f, d[e])
                }
                f = b("ge")("photosTruncatingUIButtonGroup");
                f && this.fixButtonText(f);
                d = this.stream.getCurrentImageData();
                e = d != null ? d.info : {};
                b("Arbiter").inform("PhotoSnowlift.DATA_CHANGE", Object.assign(e != null ? e : {}, {
                    movement: this.movementDelta,
                    isSpherical: this.isSpherical()
                }), "state");
                this.movementDelta = 0;
                this.stream.getCurrentExtraData() && b("Arbiter").inform("PhotoSnowlift.EXTRA_DATA_CHANGE", this.stream.getCurrentExtraData(), "state")
            }
            this.adjustScroller();
            this.scrollableArea.showScrollbar({
                hideAfterDelay: !0
            });
            this.adjustForNewData();
            b("CSS").conditionClass(this.details, "_6iil", !0);
            b("CSS").conditionClass(this.rhcBody, "_72zy", !0);
            b("CSS").conditionClass(this.rhcHeader, "_72zz", !0);
            b("CSS").conditionClass(this.scroller, "_72z-", !0)
        };
        d.updateTotalCount = function(a, c, d) {
            var e = this.stream.getCurrentHtml();
            if (e) {
                var f = b("$")("fbPhotoSnowliftPositionAndCount");
                b("DOM").replace(f, d);
                f = d;
                b("CSS").show(f);
                d = "fbPhotoSnowliftPositionAndCount";
                e[d] = Array.from(f.childNodes)
            }
            this.stream.setTotalCount(a);
            this.stream.setFirstCursorIndex(c)
        };
        d.addPhotoFbids = function(a, b, c, d) {
            if (d && this.sessionID && d != this.sessionID) return;
            d = this.stream.getCursor() === null;
            this.shouldRenderVideoPivots && !this._videoSameAsSource && (this.stream.fbidList = []);
            this.stream.attachToFbidsList(a, b, c);
            c && d && this.page(0, !0);
            this.pivots && c && this.pivots.setCycleCount(this.stream.calculateDistance(this.stream.getCursor(), this.stream.firstCursor));
            !this.pagersShown && this.stream.canPage() && this.setStagePagersState("ready");
            this.setLeftAndRightPagersState();
            if (this.shouldRenderVideoPivots && !this._videoSameAsSource) {
                a = this.stream.getCursor();
                b = this.stream.calculateDistance(a, this._mediaFBID);
                this.stream.moveCursor(b)
            }
        };
        d.attachTagger = function(a, c, d) {
            b("DOM").appendContent(this.stageActions, a), c && c.setTokenarea(this.taglist), d && b("DOM").appendContent(b("DOM").find(a, "div.faceBox"), d)
        };
        d.setAuthorName = function(a, c) {
            var d = b("Parent").bySelector(c, ".rhc");
            if (d) {
                this.previousAuthorName = this.currentAuthorName;
                this.currentAuthorName = a;
                if (this._navHistory.length > 1 && this.previousAuthorName) {
                    d = this._navHistory[this._navHistory.length - 2];
                    this.backButton = b("ReactDOM").render(o.jsx(b("PhotoSnowliftBackLink.react"), {
                        href: d,
                        name: this.previousAuthorName,
                        visible: !0
                    }), c)
                } else this.backButton = b("ReactDOM").render(o.jsx(b("PhotoSnowliftBackLink.react"), {
                    visible: !1
                }), c)
            }
        };
        d.storeFromData = function(a) {
            var d = this;
            if (!this.isOpen) return;
            a.pivots && (this.pivotsCarouselElement = a.pivots);
            a.autoplay_option_screen_config && (this.autoplayOptionScreenConfig = a.autoplay_option_screen_config, this.autoplayOptionScreenConfig && this.autoplayOptionScreenConfig.enabled && this.addHaltAutoplaySubscription());
            this.shouldRenderVideoPivots = a.should_render_pivots;
            if (a.ssid && this.sessionID && this.sessionID != a.ssid) return;
            if ("error" in a) {
                this.stream.storeToCache(a);
                this.checkState(c.STATE_ERROR);
                return
            }
            if (this.didReceivePayloadHavingInitProperty === !1 && Object.prototype.hasOwnProperty.call(a, "init") === !1) {
                this.payloadsReceivedBeforePayloadHavingInitProperty.push(a);
                return
            }
            var e = this.stream.storeToCache(a);
            if ("init" in a) {
                var f;
                this.shouldRenderVideoPivots && (this._videoSameAsSource = a.init.videoSameAsSource);
                this._mediaFBID = a.init.fbid;
                this._albumFBID = a.init.album_fbid;
                this._isAlbum = a.init.is_album;
                this._albumOwnerName = a.init.album_owner_name;
                this._autoplayVideos = a.init.autoplay_videos;
                this._autoplayNextVideo = a.init.autoplay_next_video;
                this._referrerProfileID = a.init.referrer_profile_id;
                this._ownerID = a == null ? void 0 : (f = a.image[this._mediaFBID]) == null ? void 0 : (f = f.info) == null ? void 0 : f.owner
            } else this._preloadNextVideo();
            f = "init" in e;
            f && (this.initialDataFetched(e.init), this.openExplicitly && (this.replaceUrl = !0, b("goURI")(this.stream.getCurrentImageData().info.permalink)), this.stream.canPage() && this.setStagePagersState("ready"), this.setLeftAndRightPagersState());
            "image" in e && this.checkState(c.STATE_IMAGE_DATA, f);
            "data" in e && this.checkState(c.STATE_HTML);
            if (Object.prototype.hasOwnProperty.call(a, "init")) {
                this.didReceivePayloadHavingInitProperty = !0;
                if (this.payloadsReceivedBeforePayloadHavingInitProperty.length) {
                    f = [].concat(this.payloadsReceivedBeforePayloadHavingInitProperty);
                    this.payloadsReceivedBeforePayloadHavingInitProperty.length = 0;
                    f.forEach(function(a) {
                        (n || (n = b("ErrorUtils"))).applyWithGuard(function() {
                            d.storeFromData(a)
                        }, null, null, null, "PhotoSnowlift::storeFromData() payload queue flusher")
                    })
                }
            }
            e = this.stream.getCursor();
            a = a == null ? void 0 : (f = a.data) == null ? void 0 : (a = f[e]) == null ? void 0 : (f = a.ufi_config) == null ? void 0 : (e = f.props) == null ? void 0 : e.defaultActorID;
            a != null && (this.actorID = a)
        };
        d.setLeftAndRightPagersState = function() {
            this.stream.isNonCircularPhotoSet() && (b("CSS").conditionClass(this.root, "disableLeft", !this.stream.nonCircularPhotoSetCanPage(-1)), b("CSS").conditionClass(this.root, "disableRight", !this.stream.nonCircularPhotoSetCanPage(1)));
            if (this.snowflake) {
                b("CSS").conditionClass(this.root, "disableLeft", this.stream.getCursor() == this.firstInSet);
                var a = this.stream.getCursorAt(this.stream.calculatePositionForMovement(1));
                b("CSS").conditionClass(this.root, "disableRight", a == this.firstInSet)
            }
        };
        d.setStagePagersActivated = function(a) {
            b("CSS").hasClass(this.root, "pagingActivated") !== a && b("CSS").conditionClass(this.root, "pagingActivated", a)
        };
        d.setStagePagersState = function(a) {
            switch (a) {
                case "ready":
                    b("CSS").addClass(this.root, "pagingReady");
                    this.pagersShown = !0;
                    return;
                case "disabled":
                case "reset":
                    b("CSS").removeClass(this.root, "pagingReady");
                    return
            }
        };
        d.deletePhoto = function(a) {
            this.closeRefresh()
        };
        d.closeRefresh = function() {
            this.refreshOnClose = !0, this.spotlight.hide()
        };
        d.onUpdateTagBox = function(a, c) {
            c.version == b("PhotosConst").VIEWER_SNOWLIFT && this.updateTagBox(c.id, c.approve)
        };
        d.isSpherical = function() {
            var a = this.stream.getCurrentImageData();
            return Boolean(a && a.spherical) || this.thumbSpherical
        };
        d._log = function(a) {
            if (this._shouldLog) {
                this._logger && this._logger.log(a.startsWith("data:") ? b("EncryptedImg").dataUrlPrefix(a) : a, String(this.stream.getCursor()), this.getViewerSource(), this._referrerProfileID);
                return !0
            }
            return !1
        };
        d._enableMouseOver = function() {
            this._disableMouseOver = !1
        };
        d._interceptMouseOver = function(a) {
            this._disableMouseOver && a.kill()
        };
        d.isReturningToStart = function() {
            return !!this.returningToStart
        };
        d._pauseVideoIfNeeded = function() {
            if (this._videoPlayerStateManager) {
                var a = b("gkx")("1418061") ? "video_data_switch" : "unloaded";
                this._videoPlayerStateManager.pause(a);
                b("VideoPlayerAbortLoadingExperiment").canAbort && this._abortVideoWhenSwitch && this._videoPlayerStateManager.abortLoading();
                this._videoPlayerStateManager.hasOption("PhotoSnowlift", "isInSnowlift") && this._videoPlayerStateManager.unregisterOption("PhotoSnowlift", "isInSnowlift");
                this._videoPlayerStateManager.emit("PhotoSnowlift/exitSnowlift")
            }
        };
        d._destroyVideoIfNeeded = function(a) {
            a && b("SnowliftDestroyVideoPlayerExperiment").destroyVideoOnExit && (a.destroy(), this._vpcsToDestroyOnDestroy["delete"](a))
        };
        d.setIsLiveBroadcast = function() {
            this._isLiveBroadcast = !0
        };
        d.registerLiveInputBar = function(a) {
            this._liveInputBar = a
        };
        d.setActionsMenuState = function(a) {
            this._actionMenuOpen = a, a || this.hidePagers()
        };
        d.registerActionsMenu = function(a) {
            var c = this;
            this._actionsMenuSubscriptionsHandler = new(b("SubscriptionsHandler"))();
            this._actionsMenuSubscriptionsHandler.addSubscriptions(a.getPopover().subscribe("show", function() {
                return c.setActionsMenuState(!0)
            }), a.getPopover().subscribe("hide", function() {
                return c.setActionsMenuState(!1)
            }))
        };
        c.getInstance = function() {
            c._instance || (c._instance = new c());
            return c._instance
        };
        c.initWithSpotlight = function(a, b) {
            c.getInstance().init(a, b)
        };
        c.addPhotoFbids = function(a, b, d, e) {
            c.getInstance().addPhotoFbids(a, b, d, e)
        };
        c.registerActionsMenu = function(a) {
            var b = c.getInstance();
            b || j(0, 198);
            b.registerActionsMenu(a)
        };
        c.registerLiveInputBar = function(a) {
            c.getInstance().registerLiveInputBar(a)
        };
        c.setIsLiveBroadcast = function() {
            c.getInstance().setIsLiveBroadcast()
        };
        c.setReachedLeftEnd = function() {
            c.getInstance().setReachedLeftEnd()
        };
        c.setReachedRightEnd = function() {
            c.getInstance().setReachedRightEnd()
        };
        c.attachFollowFlyout = function(a) {
            b("DOM").insertAfter(b("$")("fbPhotoSnowliftSubscribe"), a)
        };
        c.attachSubscribeFlyout = function(a) {
            b("DOM").insertAfter(b("$")("fbPhotoSnowliftSubscribe"), a)
        };
        c.attachTagger = function(a, b, d) {
            c.getInstance().attachTagger(a, b, d)
        };
        c.bootstrap = function(a, d) {
            var e = String((l || (l = b("URI"))).getMostRecentURI().getQueryData().viewas),
                f = new l(a).getQueryData();
            if (!b("PhotoSnowliftLoader").shouldUseSnowlift(f, a, d, e)) return;
            b("FunnelLogger").startFunnel(p);
            d != null && b("Parent").bySelector(d, "._18ia") != null && b("FunnelLogger").addFunnelTag(p, "via_search_media_module");
            c.getInstance().bootstrap(a, d)
        };
        c.closeRefresh = function() {
            c.getInstance().closeRefresh()
        };
        c.deletePhoto = function(a) {
            c.getInstance().deletePhoto(a)
        };
        c.getImage = function() {
            return c.getInstance().getImage()
        };
        c.getImageId = function() {
            return c.getInstance().getImageId()
        };
        c.getLoadQuery = function() {
            return c.getInstance().getLoadQuery()
        };
        c.getRHCBody = function() {
            return c.getInstance().getRHCBody()
        };
        c.getRHCHeader = function() {
            return c.getInstance().getRHCHeader()
        };
        c.getRoot = function() {
            return c.getInstance().getRoot()
        };
        c.saveTagsFromPayload = function(a) {
            c.getInstance().saveTagsFromPayload(a)
        };
        c.saveTagsFromPayloadDelayed = function(a) {
            window.setTimeout(c.saveTagsFromPayload.bind(null, a), 2e3)
        };
        c.handleServerError = function(a, b) {
            c.getInstance().handleServerError(a, b)
        };
        c.setAuthorName = function(a, b) {
            c.getInstance().setAuthorName(a, b)
        };
        c.storeFromData = function(a) {
            c.getInstance().storeFromData(a)
        };
        c.swapData = function() {
            c.getInstance().swapData()
        };
        c.updateTotalCount = function(a, b, d) {
            c.getInstance().updateTotalCount(a, b, d)
        };
        c.setVideoRotateURI = function(a) {
            c.getInstance().videoRotateURI = a
        };
        return c
    }(b("classWithMixins")(b("PhotoViewer"), b("mixin")(b("ObjectionableContentFilterMixin"), b("DisableContextMenuMixin"))));
    Object.assign(a, {
        STATE_ERROR: "error",
        STATE_HTML: "html",
        STATE_IMAGE_PIXELS: "image_pixels",
        STATE_IMAGE_DATA: "image",
        LOADING_TIMEOUT: 2e3,
        PAGER_FADE: 3e3,
        FULL_SCREEN_PADDING: 10,
        STAGE_NORMAL_MAX: b("PhotoSnowliftLoader").STAGE_NORMAL_MAX,
        STAGE_MIN: {
            x: 520,
            y: 520
        },
        PROFILE_PICTURE_BUTTON_WIDTH: 140,
        SIDEBAR_SIZE_MAX: b("PhotoSnowliftLoader").SIDEBAR_SIZE_MAX,
        STAGE_CHROME: b("PhotoSnowliftLoader").STAGE_CHROME,
        VIDEO_BOTTOM_BAR_SPACE: 50,
        GOPREV_AREA: 120,
        TIMELINE_STRETCH_WIDTH: 843,
        TIMELINE_STRETCH_MIN: 480,
        MIN_TAG_DISTANCE: 83,
        PADDING_MIN: 40,
        MIN_UFI_HEIGHT: 250,
        COLLECTIONS_UNTAGGED_PHOTOS: 3,
        PHOTOS_OF_YOU_SUGGESTIONS: 28,
        FRIENDS_IN_PHOTOS_SUGGESTIONS: 31,
        PINNED_UFI_ADJUSTMENT: 11,
        ADD_COMMENT_HEIGHT: 54,
        _instance: null,
        touch: b("emptyFunction"),
        touchMarkup: b("emptyFunction")
    });
    e.exports = a
}), null);
__d("FaceboxSourceConstants", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        SNOWLIFT_SUGGEST: "snowlift_suggest",
        SNOWLIFT_DISMISS: "photo_snowlift_unit_suggestions",
        PERMALINK_SUGGEST: "permalink_suggest",
        PERMALINK_DISMISS: "photo_permalink_suggestions",
        UPLOADER_SUGGEST: "uploader_suggest",
        UPLOADER_DISMISS: "album_uploader_suggestions"
    })
}), null);
__d("PhotoTagger", ["csx", "ActorURI", "Arbiter", "AsyncRequest", "AsyncResponse", "CSS", "DOM", "DOMQuery", "Event", "FaceboxSourceConstants", "Hovercard", "Keys", "LegacyMentionsInput.react", "Parent", "PhotoTagStore", "PhotosConst", "PhotosTaggingWaterfall", "PhotosUtils", "QE2Logger", "Style", "UFIAddCommentController", "Vector", "getElementPosition", "removeFromArray"], (function(a, b, c, d, e, f, g) {
    function h(a, b) {
        return (a % b + b) % b
    }
    a = function() {
        "use strict";

        function a(b) {
            this.TAG_BOX_SIZE = 100, this.EPSILON = .0025, this.HUGE_FACE_THRESH = 90, this.HUGE_FACE_SHRINK_FACTOR = .6, this.elemNames = {
                6: {
                    addTagLink: "div.fbPhotosPhotoOwnerButtons",
                    overlayActions: "div.snowliftOverlayBar"
                }
            }, this.viewer = b, this.version = b.getVersionConst(), this.isPhotoEditor = !1, this.datasources = {}, this.photoData = {}, this.tagRects = {}, this.spatialTags = [], this.isSpherical = !1, this.sphericalPhotoXY = null, this.fromSphericalFacebox = !1, this.disableSaveSpatialTag = !1, this.ajaxURIs = {
                tagsInit: "/ajax/photos/photo/tags/tags_init.php",
                tagsAlbum: "/ajax/photos/photo/tags/tags_album.php",
                fetchDatasource: "/ajax/photos/photo/tags/fetch_datasource.php",
                tagAction: "/ajax/photo_tagging_ajax.php",
                tagWithAction: "/ajax/with_tagging_ajax.php"
            }, this.recognizedUsers = [], this.addedSuggestions = [], this.featuredSuggestions = [], this.albumSuggestions = [], this.friendSuggestions = [], this.suggestionAlbum = -1, this.addCommentController = null, this.isFirstBackspace = !0, this.previousQueryString = "", a.instances[this.version] = this
        }
        var c = a.prototype;
        c.initSnowlift = function(a, c, d, e) {
            this._init(a, c, d, this.viewer.container, e), b("Arbiter").inform("PhotoSnowlift.TAGGER_READY")
        };
        c.initPermalink = function(a, b, c) {
            this._init(a, b, c, this.viewer.actionList)
        };
        c.initSphericalPhoto = function(a, c, d) {
            this._init(a, c, d, this.viewer.container), b("Arbiter").inform("PhotoTagger.SPATIAL_TAGGER_READY")
        };
        c._init = function(a, c, d, e, f) {
            this.root = this.viewer.getRoot();
            this.tagger = a;
            this.tokenizer = c;
            this.ufi = f;
            this._qn = null;
            this.typeahead = c.getTypeahead();
            this.userId = d;
            this.makeProfilePicMenuContainer = e;
            this.faceboxes = [];
            this.tags = [];
            this.currentFacebox = null;
            this.currentTextbox = null;
            this.revokedFaceboxes = [];
            this.requestFaceboxNextTag = !1;
            this.clickState = b("DOM").find(this.root, "div.stageActions");
            this.newTagBox = b("DOM").scry(this.clickState, "div.newTagBox")[0];
            this.addTagLink = null;
            this.overlayActions = null;
            this.elemNames[this.version] && (this.addTagLink = b("DOM").find(this.root, this.elemNames[this.version].addTagLink), this.overlayActions = b("DOM").find(this.root, this.elemNames[this.version].overlayActions));
            this.setupHandlers();
            this.hideNewTagTimer = null;
            this.needAlbumSuggestionsFetch = !0;
            this.fetchTaggingSuggestions({
                owner: this.photoData.owner
            });
            this.setDataSource(this.typeahead.getData());
            this.updateFaceboxes();
            this.tagAccumulating = !1;
            return this
        };
        c.setTagAccumulator = function(a) {
            this.tagAccumulating = a
        };
        c.fetchTaggingSuggestions = function(a) {
            var c = this;
            new(b("AsyncRequest"))().setAllowCrossPageTransition(!0).setAllowCrossOrigin(!0).setURI(this.ajaxURIs.tagsInit).setData(a).setOption("retries", 1).setHandler(function(a) {
                a = a.getPayload();
                c.featuredSuggestions = a.featuredTaggees;
                c.friendSuggestions = a.friendTaggees;
                c.updateTypeaheadSuggestions()
            }).send();
            var d = this.typeahead.subscribe("bootstrap", function(a, b) {
                b && !b.bootstrapping && (c.taggingMode && c.updateWithSuggestions(), c.typeahead.unsubscribe(d), c.typeahead.subscribe("focus", function() {
                    c.taggingMode && c.updateWithSuggestions()
                }), c.typeahead.subscribe("click", function() {
                    c.taggingMode || c.updateWithSuggestions()
                }), c.tokenizer.subscribe("removeToken", c.updateWithSuggestions.bind(c)), c.tokenizer.subscribe("addToken", c.addSuggestion.bind(c)), c.typeahead.subscribe("respond", function(a, b) {
                    c.taggingMode && b && !b.results.length && c.updateWithSuggestions()
                }))
            })
        };
        c.fetchAlbumTaggingSuggestions = function() {
            var a = this;
            new(b("AsyncRequest"))().setURI(this.ajaxURIs.tagsAlbum).setData({
                cachedAlbum: this.suggestionAlbum,
                photo: this.photoData.fbid
            }).setOption("retries", 1).setAllowCrossPageTransition(!0).setHandler(function(b) {
                a.needAlbumSuggestionsFetch = !1;
                b = b.getPayload();
                if (b.length === 0) return;
                a.suggestionAlbum = b.album;
                a.albumSuggestions = b.taggees;
                a.updateTypeaheadSuggestions()
            }).send()
        };
        c.resetAlbumTaggingSuggestions = function() {
            this.needAlbumSuggestionsFetch = !0, this.updateTypeaheadSuggestions()
        };
        c.updateTypeaheadSuggestions = function() {
            this.typeahead.getView().setSuggestions(this.addedSuggestions.concat(this.recognizedUsers, this.featuredSuggestions, this.needAlbumSuggestionsFetch ? [] : this.albumSuggestions, this.friendSuggestions))
        };
        c.saveClickPosition = function(a, c) {
            var d = b("Vector").getElementPosition(a);
            a = b("Vector").getElementDimensions(a);
            this.clickPercentToPhoto = new(b("Vector"))((c.x - d.x) / a.x, (c.y - d.y) / a.y)
        };
        c.getCalculatedClickPosition = function(a) {
            var c = b("Vector").getElementPosition(a);
            a = b("Vector").getElementDimensions(a);
            return a.x === 0 || a.y === 0 ? null : new(b("Vector"))(this.clickPercentToPhoto.x * a.x + c.x, this.clickPercentToPhoto.y * a.y + c.y, "document")
        };
        c.repositionTagger = function() {
            if (this.clickPercentToPhoto) {
                var a = this.viewer.getImage();
                a = this.getCalculatedClickPosition(a);
                if (!a) return;
                this.addTagFromClickPos(a)
            }
        };
        c._setIsFirstBackspace = function(a) {
            this.isFirstBackspace = a
        };
        c.setupHandlers = function() {
            var a = this;
            this.handlers = [b("Event").listen(this.clickState, "click", function(b) {
                a.isSpherical || a.addTag(b)
            })];
            this.addTagLink && this.handlers.push(b("Event").listen(this.addTagLink, "click", this.checkActions.bind(this)));
            this.overlayActions && this.handlers.push(b("Event").listen(this.overlayActions, "click", this.checkActions.bind(this)));
            this.setupAddTagHandlers();
            b("Event").listen(document.documentElement, "keydown", function(c) {
                if (!a.taggingMode) return;
                var d = b("Event").getKeyCode(c);
                d === b("Keys").TAB && a.addNextTagFromFacebox(c.shiftKey ? -1 : 1)
            });
            this.subscriptions = [b("Arbiter").subscribe(this.viewer.getEventString("PAGE"), this.restartTagging.bind(this)), b("Arbiter").subscribe(this.viewer.getEventString("DATA_CHANGE"), this.setPhotoData.bind(this)), b("Arbiter").subscribe(this.viewer.getEventString("EXTRA_DATA_CHANGE"), this.setExtraData.bind(this)), b("Arbiter").subscribe(this.viewer.getEventString("CLOSE"), this.deactivateTagging.bind(this))];
            this.tokenizer.subscribe("addToken", this.saveTag.bind(this));
            this.tokenizer.subscribe("removeToken", this.removeTag.bind(this));
            this.tokenizer.subscribe("markTagAsSpam", this.markTagAsSpam.bind(this))
        };
        c.setupAddTagHandlers = function() {
            if (this.ufi) {
                var a = b("DOM").scry(this.root, ".tagPhotoLink");
                a.forEach(function(a) {
                    b("Event").listen(a, "click", this.showTaggerFromClick.bind(this))
                }, this)
            }
        };
        c.updateWithSuggestions = function(a, b) {
            a = this.typeahead.getData().buildUids(" ", this.typeahead.getView().getSuggestions(), this.typeahead.getCore().getExclusions());
            if (!a.length) return;
            b = this.typeahead.getData().respond("", a);
            for (var a = 0; a < b.length; a++) b[a].index = -1e3 + a
        };
        c.addSuggestion = function(a, b) {
            a = b.info && b.info.uid;
            a && (this.addedSuggestions.unshift(a), this.updateTypeaheadSuggestions())
        };
        c.setQueueName = function(a) {
            this._qn = a;
            return this
        };
        c._sendWaterfallLogSignal = function(a) {
            b("PhotosTaggingWaterfall").sendSignal({
                qn: this._qn,
                source: this.viewer.getSourceString(),
                step: a,
                pid: this.photoData.pid
            })
        };
        c._sendFaceboxSuggestionLogSignal = function(a, c, d) {
            b("PhotosTaggingWaterfall").sendSignal({
                step: b("PhotosTaggingWaterfall").SHOW_SUGGEST,
                photo_owner: this.photoData.owner,
                tagee: a,
                is_first: !0,
                source: c,
                photo_id: this.photoData.fbid,
                facebox_id: d
            })
        };
        c._bumpQueueName = function() {
            this._qn && (this._qn += 1)
        };
        c.activateTagging = function() {
            b("Arbiter").inform("PhotoTagger.ACTIVATE_TAGGING"), this.getDataSource() ? this.dataSourceFetched(this.getDataSource()) : new(b("AsyncRequest"))(this.ajaxURIs.fetchDatasource).setData({
                fbid: this.photoData.fbid,
                version: this.version,
                data_source_type: this.dataSourceType
            }).send(), this.needAlbumSuggestionsFetch && this.fetchAlbumTaggingSuggestions()
        };
        c.restartTagging = function() {
            this.hideNewTag(), this.hideTagger(), this.hideExistingTags(), this.revokedFaceboxes = [], this.setCurrentFacebox(null), this.taggingMode && (this.requestFaceboxNextTag = !0, this.activateTagging())
        };
        c.getDataSource = function() {
            return this.datasources[this.getDataSourceKey()]
        };
        c.getDataSourceKey = function() {
            var a;
            this.photoData.ownertype == "user" && !this.photoData.obj_id ? a = "friends" : a = this.photoData.obj_id || this.photoData.owner;
            return a
        };
        c.setDataSource = function(a) {
            this.typeahead.getData() != a && this.typeahead.swapData(a), this.datasources[this.getDataSourceKey()] = a
        };
        c.dataSourceFetched = function(a) {
            b("CSS").removeClass(this.root, "peopleTagging"), this.taggingMode = !0, b("CSS").addClass(this.root, "taggingMode"), this.dataSourceType && (this.dataSourceType === "default", b("CSS").addClass(this.root, "peopleTagging")), this._hidePivots(), b("Arbiter").inform("PhotoTagger.START_TAGGING"), this._bumpQueueName(), this._sendWaterfallLogSignal(b("PhotosTaggingWaterfall").BEGIN), this.setDataSource(a)
        };
        c.deactivateTagging = function() {
            this.taggingMode === !0 && this._sendWaterfallLogSignal(b("PhotosTaggingWaterfall").FINISH), this.taggingMode = !1, this.hideNewTag(), this.hideTagger(), this.hideExistingTags(), this.setCurrentFacebox(null), this._showPivots(), b("CSS").removeClass(this.root, "taggingMode"), b("CSS").removeClass(this.root, "peopleTagging"), b("Arbiter").inform("PhotoTagger.STOP_TAGGING")
        };
        c._hidePivots = function() {
            var a = b("DOMQuery").scry(this.root, ".tag");
            for (var c = 0; c < a.length; c++) b("CSS").hide(a[c])
        };
        c._showPivots = function() {
            var a = b("DOMQuery").scry(this.root, ".tag");
            for (var c = 0; c < a.length; c++) b("CSS").show(a[c])
        };
        c.checkActions = function(a) {
            a = a.getTarget();
            a = b("Parent").byClass(a, "fbPhotosPhotoActionsTag");
            if (a) {
                a = b("CSS").hasClass(this.root, "peopleTagging");
                a = a;
                this.taggingMode && !a ? this.deactivateTagging() : (this.dataSourceType = "default", this.activateTagging(), this.isSpherical || this.addNextTagFromFacebox(1))
            }
        };
        c.hideTagger = function() {
            b("CSS").hide(this.tagger);
            this.clickPercentToPhoto = null;
            var a = b("DOM").scry(this.tagger, "input.textInput")[0];
            a && a.blur()
        };
        c.showTaggerFromClick = function(a) {
            a = a.getTarget();
            a = b("Parent").byClass(a, "tagPhotoLink");
            var c = a.getAttribute("data-x");
            a = a.getAttribute("data-y");
            if (c !== null && a !== null) {
                c = new(b("Vector"))(c, a);
                a = this.viewer.getImage();
                c = b("PhotosUtils").normalizedToAbsolutePosition(a, c);
                this.setClickPosAndFacebox(c);
                this.addTagFromClickPos(c)
            }
            this.showTagger()
        };
        c.showTagger = function() {
            var a = this;
            b("QE2Logger").logExposureForUser("www_snowlift_photo_tagger_qe");
            b("DOM").scry(this.root, ".fbPhotosPhotoTagboxBase").forEach(function(a) {
                b("CSS").removeClass(a, "hover"), b("CSS").removeClass(a, "tagClick"), this.taggingMode && b("CSS").hide(b("DOM").find(a, ".tag"))
            }, this);
            var c = b("DOM").find(this.tagger, ".typeaheadContainer"),
                d = b("DOM").find(c, ".arrow .nub"),
                e = 3;
            b("Style").set(c, "margin-left", 0);
            b("Style").set(d, "margin-left", 0);
            var f = b("getElementPosition")(c);
            f.x <= 0 && (b("CSS").hasClass(this.tagger, "fbPhotoTaggerFlipped") || (b("Style").set(c, "margin-left", -2 * f.x + "px"), b("Style").set(d, "margin-left", f.x - e + "px")));
            if (this.ufi) {
                d = b("DOM").find(this.tagger, "._12nb");
                b("CSS").show(c);
                b("CSS").hide(d)
            }
            b("CSS").show(this.tagger);
            window.setTimeout(function() {
                b("DOM").find(a.tagger, "input.textInput").focus()
            }, 0);
            this.hideNewTag();
            b("Arbiter").inform("reflow")
        };
        c.showNewTag = function(a, c) {
            if (c && this.ufi) {
                b("CSS").addClass(c, "hover");
                b("DOM").find(c, ".uiLinkButtonInput").value = a;
                return
            }
            if (!this.newTagBox) return;
            b("DOM").setContent(b("DOM").find(this.newTagBox, "div.tagName"), b("DOM").create("span", null, a));
            b("CSS").show(this.newTagBox);
            this.hideNewTagTimer = window.setTimeout(this.hideNewTag.bind(this), 3e3)
        };
        c.hideNewTag = function() {
            if (!this.newTagBox) return;
            this.hideNewTagTimer !== null && (window.clearTimeout(this.hideNewTagTimer), this.hideNewTagTimer = null);
            b("CSS").hide(this.newTagBox)
        };
        c.getTaggerPositioningOrigin = function() {
            return b("Vector").getElementPosition(this.clickState, "document")
        };
        c.setClickPosAndFacebox = function(a) {
            var c = this.viewer.getImage();
            this.saveClickPosition(c, a);
            c = b("PhotosUtils").absoluteToNormalizedPosition(c, a);
            this.setCurrentFacebox(this.findNearestFacebox(c))
        };
        c.addTagFromClickPos = function(a) {
            this.currentTextbox = null;
            this.hideExistingTags();
            if (this.currentFacebox) this.addTagFromFaceboxDontSave(this.currentFacebox);
            else {
                var c = this.viewer.getImage(),
                    d = b("PhotosUtils").absoluteToNormalizedPosition(c, a);
                if (this.tags !== void 0)
                    for (var e = 0; e < this.tags.length; e++) this.tags[e].rect.contains(d) && (this.showExistingTag(this.tags[e]), this.currentTextbox = this.tags[e]);
                this.removeSuggestionFromTagger();
                b("CSS").removeClass(b("DOM").find(this.tagger, ".faceBox"), "faceBoxHidden");
                if (this.currentTextbox) {
                    e = this.currentTextbox.rect.w() / 100 * b("Vector").getElementDimensions(c).x;
                    this.addTagFromPosition(a, e)
                } else this.addTagFromPosition(a, this.TAG_BOX_SIZE)
            }
        };
        c.showExistingTag = function(a) {
            this.taggingMode ? (this._hidePivots(), b("CSS").show(b("DOM").find(a.node, ".tag")), b("CSS").addClass(a.node, "tagClick")) : b("CSS").addClass(a.node, "hover"), this.hideTagger()
        };
        c.hideExistingTags = function() {
            var a = this,
                c = b("DOM").scry(this.root, ".tagClick");
            c && c.forEach(function(c) {
                b("CSS").removeClass(c, "tagClick"), a.taggingMode && b("CSS").hide(b("DOM").find(c, ".tag"))
            })
        };
        c.addTag = function(a) {
            var c = a.getTarget(),
                d = b("Parent").byClass(c, "fbPhotosPhotoButtons");
            if (!this.taggingMode || d && c !== d || b("Parent").byClass(c, "fbPhotosPhotoActions") || b("Parent").byClass(c, "faceboxSuggestion") || b("Parent").byClass(c, "photoTagTypeahead") || b("Parent").byClass(c, "tagUfi")) return;
            d = b("Vector").getEventPosition(a);
            this.setClickPosAndFacebox(d);
            this.addTagFromClickPos(d)
        };
        c.addSpatialTag = function(a, c) {
            c = c.getTarget();
            var d = b("Parent").byClass(c, "fbPhotosPhotoButtons"),
                e = a.inTaggingMode ? this.viewer.stageActions : this.viewer.stage;
            if (d && c !== d || b("Parent").byClass(c, "fbPhotosPhotoActions") || b("Parent").byClass(c, "faceboxSuggestion") || b("Parent").byClass(c, "photoTagTypeahead") || b("Parent").byClass(c, "tagUfi") || !a.screenPos || !a.photoXY || !a.size || !this.isSpherical || !e) return;
            this.sphericalPhotoXY = a.photoXY;
            this.fromSphericalFacebox = a.fromTag;
            d = b("getElementPosition")(e);
            this.fromSphericalFacebox && !!a.suggestion ? this.addTagFromFaceboxDontSave(a.suggestion) : this.removeSuggestionFromTagger();
            this.addTagFromPosition(b("Vector").from(a.screenPos.x + d.x, a.screenPos.y + d.y, "document"), a.size);
            c = b("DOM").find(this.tagger, ".faceBox");
            this.fromSphericalFacebox && !b("CSS").hasClass(c, "faceBoxHidden") && b("CSS").addClass(c, "faceBoxHidden");
            !this.fromSphericalFacebox && b("CSS").hasClass(c, "faceBoxHidden") && b("CSS").removeClass(c, "faceBoxHidden")
        };
        c.showTagIfCommentAdded = function() {
            if (this.taggingMode) {
                var a = this.getClickPointForSave(),
                    c = b("Vector").from(a.x, a.y);
                if (a !== null)
                    for (var a = 0; a < this.tags.length; a++)
                        if (this.tags[a].rect.contains(c)) {
                            this.showExistingTag(this.tags[a]);
                            this.hideTagger();
                            return
                        }
            }
        };
        c.commentAdded = function(a, c) {
            a.forEach(function(a) {
                var c = this.getClickPointForSave(),
                    d = null;
                if (a.isPhotoTag && a.photoTextTagID == null && a.photoTagX !== null && a.photoTagY !== null)
                    if (c !== null && a.photoTagX === c.x && a.photoTagY === c.y) d = b("DOM").find(this.tagger, "._12nb");
                    else {
                        c = new(b("Vector"))(a.photoTagX, a.photoTagY);
                        c = this.findNearestTag(c);
                        c !== null && (d = b("DOM").find(c.node, "._12nb"))
                    }
                if (d !== null) {
                    b("DOM").find(d, ".UFIContainer");
                    c = {};
                    c[a.author] = {
                        id: a.author
                    };
                    b("Style").set(b("DOM").find(d, ".UFIAddComment"), "opacity", .5);
                    b("DOM").find(d, "textarea").setAttribute("disabled", "disabled")
                }
            }, this)
        };
        c.showTaggerUFI = function(a) {
            a = b("DOM").find(this.tagger, ".typeaheadContainer");
            var c = b("DOM").find(this.tagger, "._12nb"),
                d = b("DOM").find(c, ".arrow .nub"),
                e = 3,
                f = b("getElementPosition")(c);
            f.x <= 0 && !b("CSS").hasClass(this.tagger, "fbPhotoTaggerFlipped") ? (b("Style").set(c, "margin-left", -2 * f.x + "px"), b("Style").set(d, "margin-left", f.x - e + "px")) : (b("Style").set(c, "margin-left", 0), b("Style").set(d, "margin-left", 0));
            f = this.getClickPointForSave();
            e = b("DOM").find(c, ".tagUfiAddComment");
            d = b("DOM").find(this.viewer.ufiInputContainer, 'input[name="ft_ent_identifier"]');
            d = {
                ftentidentifier: d.value,
                source: e.getAttribute("data-source"),
                mentionsinput: {
                    inputComponent: b("LegacyMentionsInput.react")
                },
                hideActorPhoto: !0,
                isPhotoTag: !0,
                photoFBID: this.viewer.getCurrentPhotoInfo().fbid,
                photoTagX: f.x,
                photoTagY: f.y
            };
            this.addCommentController = b("UFIAddCommentController").factory(e, d);
            f = b("DOM").find(c, ".UFIContainer");
            f.firstChild !== null && b("DOM").remove(f.firstChild);
            b("Style").set(b("DOM").find(c, ".UFIAddComment"), "opacity", 1);
            b("DOM").find(c, "textarea").removeAttribute("disabled");
            b("CSS").show(this.tagger);
            b("CSS").hide(a);
            b("CSS").show(c);
            b("Arbiter").inform("reflow")
        };
        c._findNearest = function(a, b) {
            var c = Infinity,
                d = null;
            a.forEach(function(a) {
                if (a.rect.contains(b)) {
                    var e = b.distanceTo(a.rect.getCenter());
                    e < c && (c = e, d = a)
                }
            });
            return d
        };
        c.findNearestFacebox = function(a) {
            return this._findNearest(this.faceboxes, a)
        };
        c.findNearestTag = function(a) {
            return this._findNearest(this.tags, a)
        };
        c.addNextTagFromFacebox = function(a) {
            if (this.faceboxes.length === 0) return;
            if (!this.currentFacebox) this.setCurrentFacebox(this.faceboxes[0]);
            else {
                var b = this.faceboxes.indexOf(this.currentFacebox);
                a = h(b + a, this.faceboxes.length);
                if (a === b) return;
                this.setCurrentFacebox(this.faceboxes[a])
            }
            this.addTagFromFacebox(this.currentFacebox)
        };
        c.addTagFromFaceboxDontSave = function(a) {
            b("CSS").addClass(a.node, "active");
            b("CSS").addClass(b("DOM").find(this.tagger, ".faceBox"), "faceBoxHidden");
            var c = a.rect.getCenter(),
                d = this.viewer.getImage();
            c = b("PhotosUtils").normalizedToAbsolutePosition(d, c);
            d = a.rect.w() / 100 * b("Vector").getElementDimensions(d).x;
            a.rect.w() > this.HUGE_FACE_THRESH && a.rect.h() > this.HUGE_FACE_THRESH && (d *= this.HUGE_FACE_SHRINK_FACTOR);
            var e = this.getFaceboxSuggestionFromFaceboxElem(a.node);
            if (e) {
                var f = this.version === b("PhotosConst").VIEWER_PERMALINK ? b("FaceboxSourceConstants").PERMALINK_DISMISS : b("FaceboxSourceConstants").SNOWLIFT_DISMISS;
                this.addSuggestionToTagger(a, e);
                this._sendFaceboxSuggestionLogSignal(e.getAttribute("data-id"), f, a.id)
            } else this.removeSuggestionFromTagger();
            this.isSpherical || this.addTagFromPosition(c, d);
            return c
        };
        c.getFaceboxSuggestionFromFaceboxElem = function(a) {
            return b("DOM").scry(a, "._570u")[0]
        };
        c.addSuggestionToTagger = function(a, c) {
            this.removeSuggestionFromTagger();
            b("CSS").addClass(this.tagger, "suggestionActive");
            var d = b("DOM").find(this.tagger, ".typeaheadContainer");
            c = c.cloneNode(!0);
            this.stripReactID(c);
            b("DOM").appendContent(d, c);
            this.setupFaceboxSuggestionHandlers(a, c)
        };
        c.stripReactID = function(a) {
            a.removeAttribute("data-reactid");
            for (var b = 0; b < a.children.length; b++) this.stripReactID(a.children[b])
        };
        c.removeSuggestionFromTagger = function() {
            b("CSS").removeClass(this.tagger, "suggestionActive");
            var a = b("DOM").scry(this.tagger, ".faceboxSuggestion");
            a && a.forEach(function(a) {
                b("DOM").remove(a)
            })
        };
        c.dismissFaceboxSuggestion = function(a, c, d, e) {
            new(b("AsyncRequest"))().setURI("/ajax/dismiss_tag_suggest.php").setMethod("POST").setData({
                facebox_logs: [{
                    facebox: a,
                    log_data: {
                        photo_owner: d,
                        tagee: c,
                        is_first: !0
                    }
                }],
                closing_source: e,
                closing_action: "no"
            }).setAllowCrossPageTransition(!0).send()
        };
        c.addTagFromFacebox = function(a) {
            this.currentTextbox = null;
            a = this.addTagFromFaceboxDontSave(a);
            var b = this.viewer.getImage();
            this.saveClickPosition(b, a)
        };
        c.addTagFromPosition = function(a, c) {
            var d = this.viewer.getImage(),
                e = this.calcTaggerPosition(d, a, c);
            this.calcClickPoint(d, a);
            if (!e) {
                this.hideTagger();
                return
            }
            e.setElementPosition(this.tagger);
            this.newTagBox && (e.setElementPosition(this.newTagBox), new(b("Vector"))(c, c).setElementDimensions(this.newTagBox));
            e = b("Vector").getElementPosition(d);
            c = b("Vector").getElementDimensions(d);
            d = this.typeahead.getView();
            var f = 3 / 4;
            a.y > e.y + c.y * f ? (b("CSS").addClass(this.tagger, "fbPhotoTaggerFlipped"), d.addTypeaheadFlip("fbPhotoTaggerFlipped"), a.x > e.x + c.x * 1 / 2 ? this.flipRules("fbPhotoTaggerRight", "fbPhotoTaggerLeft", d) : this.flipRules("fbPhotoTaggerLeft", "fbPhotoTaggerRight", d)) : (b("CSS").removeClass(this.tagger, "fbPhotoTaggerFlipped"), b("CSS").removeClass(this.tagger, "fbPhotoTaggerLeft"), b("CSS").removeClass(this.tagger, "fbPhotoTaggerRight"), d.removeTypeaheadFlip("fbPhotoTaggerFlipped"), d.removeTypeaheadFlip("fbPhotoTaggerLeft"), d.removeTypeaheadFlip("fbPhotoTaggerRight"));
            (!this.taggingMode || this.currentTextbox === null) && this.ufi && this.currentFacebox === null ? this.showTaggerUFI() : this.showTagger();
            this.taggingMode ? this._sendWaterfallLogSignal(b("PhotosTaggingWaterfall").TAG_FACE) : this._sendWaterfallLogSignal(b("PhotosTaggingWaterfall").HOVER_TAG_FACE)
        };
        c.flipRules = function(a, c, d) {
            b("CSS").addClass(this.tagger, a), b("CSS").removeClass(this.tagger, c), d.addTypeaheadFlip(a), d.removeTypeaheadFlip(c)
        };
        c.calcTaggerPosition = function(a, c, d, e) {
            e = e || d;
            var f = b("Vector").getElementPosition(a);
            a = b("Vector").getElementDimensions(a);
            var g = new(b("Vector"))(d / 2, e / 2),
                h = c.sub(f);
            for (var i in {
                    x: 1,
                    y: 1
                }) {
                if (c[i] < f[i] || c[i] > f[i] + a[i]) return null;
                var j = i === "x" ? d : e;
                h[i] < j / 2 ? g[i] = h[i] : a[i] < h[i] + j / 2 && (g[i] = j - (a[i] - h[i]))
            }
            j = 3;
            i = b("DOM").find(this.tagger, ".faceBox");
            a = Math.max(0, d - j * 2);
            f = Math.max(0, e - j * 2);
            b("Style").set(i, "width", a + "px");
            b("Style").set(i, "height", f + "px");
            h = c.sub(this.getTaggerPositioningOrigin());
            return h.sub(g.x, g.y)
        };
        c.calcClickPoint = function(a, c) {
            var d = b("Vector").getElementDimensions(a);
            a = b("Vector").getElementPosition(a);
            c = c.sub(a);
            !this.isSpherical ? this.clickPoint = {
                x: c.x / d.x,
                y: c.y / d.y
            } : this.clickPoint = {
                x: this.sphericalPhotoXY.x,
                y: this.sphericalPhotoXY.y
            }
        };
        c.getClickPointForSave = function() {
            return this.clickPoint === void 0 ? null : {
                x: this.clickPoint.x * 100,
                y: this.clickPoint.y * 100
            }
        };
        c.getTaggingDataForSave = function(a, b) {
            a = this.getTaggingData("add", a.isFreeform() ? "" : a.getValue(), a.getText(), b);
            b = this.getClickPointForSave();
            a.x = b.x;
            a.y = b.y;
            a.from_facebox = this.isSpherical ? this.fromSphericalFacebox : !!this.currentFacebox;
            a.tagging_mode = !!this.taggingMode;
            return a
        };
        c.saveTag = function(a, c, d) {
            if (this.disableSaveSpatialTag && this.isSpherical && this.tagAccumulating) return;
            a = this.getTaggingDataForSave(c, d);
            if (this.tagAccumulating) this.isSpherical ? b("Arbiter").inform("PhotoTagger.SAVE_SPATIAL_TAG", a) : b("PhotoTagStore").getInstance().storeTagWithOptions(this.photoData.fbid, a.subject, a.x, a.y, a);
            else {
                this.isSpherical && b("Arbiter").inform("PhotoTagger.SAVE_SPATIAL_TAG");
                d = b("ActorURI").create(this.ajaxURIs.tagAction, this.viewer.actorID);
                new(b("AsyncRequest"))().setURI(d).setMethod("POST").setData(a).setAllowCrossPageTransition(!0).setHandler(this.tagsChangeHandler.bind(this)).setErrorHandler(this.checkError.bind(this, c)).send()
            }
            d = this.userId === a.subject;
            if (d && !this.isSpherical) {
                var e = b("DOM").scry(this.makeProfilePicMenuContainer, '[data-picid="' + this.viewer.getCurrentPhotoInfo().fbid + '"]');
                if (e.length === 1) {
                    e = e[0];
                    b("CSS").removeClass(e, "hide")
                }
            }
            if (!this.isSpherical) {
                e = new(b("Vector"))(a.x, a.y);
                var f = this.findNearestTag(e);
                f && f.rect.contains(e) ? this.showNewTag(c.getText(), f.node) : this.showNewTag(c.getText())
            }
            this.hideTagger();
            if (!this.isSpherical) {
                e = this.currentFacebox;
                e && (this.taggingMode && this.addNextTagFromFacebox(1), this.removeFacebox(e))
            }
            b("Arbiter").inform("PhotoTagger.ADDING_TAG", {
                subject: a.subject,
                text: c.getText()
            });
            b("Arbiter").inform("PhotoTagger.SAVE_TAG", {
                photo_fbid: this.photoData.fbid,
                self_tag: d
            })
        };
        c.getTaggingData = function(a, b, c, d) {
            return {
                cs_ver: this.version,
                pid: this.photoData.pid,
                fbid: this.photoData.fbid,
                id: this.photoData.owner,
                subject: b,
                name: c,
                action: a,
                source: d ? d : this.viewer.getSourceString(),
                qn: this._qn,
                position: this.getPosition(),
                slsource: this.viewer.getViewerSource(),
                slset: this.viewer.getViewerSet()
            }
        };
        c.getPosition = function() {
            return this.viewer.getPosition()
        };
        c.tagsChangeHandler = function(a) {};
        c.checkError = function(a, c) {
            c.getPayload() && c.getPayload().clear_tag && (a.already_untagged = !0, this.tokenizer.removeToken(a)), b("AsyncResponse").defaultErrorHandler(c)
        };
        c.removeTag = function(a, c, d) {
            var e = this;
            if (c.already_untagged || this.tagAccumulating && this.isSpherical) return;
            a = "remove";
            b("DOM").scry(c.element, "a.pending")[0] && (a = "retract");
            c.blockUser && (a = "remove_block");
            this.tagAccumulating ? c.isFreeform() ? b("PhotoTagStore").getInstance().removeTextTag(this.photoData.fbid, c.getInfo().text) : b("PhotoTagStore").getInstance().removeTag(this.photoData.fbid, c.getInfo().uid) : new(b("AsyncRequest"))().setURI(this.ajaxURIs.tagAction).setMethod("POST").setData(this.getTaggingData(a, c.isFreeform() ? "" : c.getInfo().uid, c.getInfo().text)).setHandler(function(a) {
                e.tagsChangeHandler(a), d && d()
            }).setAllowCrossPageTransition(!0).send();
            if (this.userId === parseInt(c.getValue(), 10) && this.userId !== this.viewer.getCurrentPhotoInfo().owner) {
                a = b("DOM").scry(this.makeProfilePicMenuContainer, '[data-picid="' + this.viewer.getCurrentPhotoInfo().fbid + '"]');
                if (a.length === 1) {
                    c = a[0];
                    b("CSS").addClass(c, "hide")
                }
                b("Arbiter").inform("PhotoTagger.REMOVED_MAKE_PROFILE_PIC_OPTION")
            }
        };
        c.removeTagByID = function(a, b, c) {
            a = this.tokenizer.tokens;
            for (var d = 0; d < a.length; d++)
                if (a[d].info.uid == b) return this.removeTag(null, a[d], c);
            return null
        };
        c.removeTagByIDFromHovercardLink = function(a, c, d) {
            this.removeTagByID(a, c, function() {
                b("Hovercard").contains(d) && b("Hovercard").hide(!0)
            })
        };
        c.removeWithTag = function(a, c) {
            var d = this;
            new(b("AsyncRequest"))().setURI(this.ajaxURIs.tagWithAction).setMethod("POST").setData({
                action: "remove_with",
                taggee: c,
                tag: a,
                version: this.version,
                fbid: this.photoData.fbid
            }).setHandler(function(a) {
                d.tagsChangeHandler(a), b("Hovercard").hide(!0)
            }).setAllowCrossPageTransition(!0).send()
        };
        c.setPhotoData = function(a, b) {
            this.clickPercentToPhoto = null;
            this.photoData = b;
            this.isSpherical = b.isSpherical;
            return this
        };
        c.setExtraData = function(a, b) {
            var c = this;
            this.tagRects = b.tagRects;
            b.spatialTags && (this.spatialTags = b.spatialTags);
            this.updateFaceboxes();
            this.setupAddTagHandlers();
            this._setInitialFaceboxFromID(b);
            b.openTag && window.setTimeout(function() {
                c.activateTagging(), c._setInitialFaceboxFromID(b), c.faceboxes.length === 1 ? c.addTagFromFacebox(c.currentFacebox) : c.addNextTagFromFacebox(1)
            }, 0);
            return this
        };
        c._setInitialFaceboxFromID = function(a) {
            if (a.initialFaceboxID !== null && this.faceboxes.length !== 0) {
                a = this.getFacebox(a.initialFaceboxID);
                if (a !== null) {
                    a = this.faceboxes.indexOf(a);
                    a = h(a - 1, this.faceboxes.length);
                    this.setCurrentFacebox(this.faceboxes[a])
                }
            }
        };
        c.markTagAsSpam = function(a, c) {
            new(b("AsyncRequest"))().setURI(this.ajaxURIs.tagAction).setMethod("POST").setData(this.getTaggingData("mark_as_spam", c, null)).send()
        };
        c.removeFacebox = function(a) {
            if (a === null) return;
            this.revokedFaceboxes.push(a.rect.getCenter());
            b("removeFromArray")(this.faceboxes, a);
            b("DOM").remove(a.node);
            a === this.currentFacebox && this.setCurrentFacebox(null)
        };
        c.setCurrentFacebox = function(a) {
            this.currentFacebox && b("CSS").removeClass(this.currentFacebox.node, "active"), this.currentFacebox = a, a && (this.recognizedUsers = JSON.parse(a.node.getAttribute("data-recognizeduids")), this.updateTypeaheadSuggestions())
        };
        c.updateRevokedFaceboxes = function() {
            var a = this;
            this.revokedFaceboxes = this.revokedFaceboxes.filter(function(b) {
                for (var c = 0; c < a.faceboxes.length; ++c) {
                    var d = a.faceboxes[c];
                    d = b.distanceTo(d.rect.getCenter());
                    if (d < a.EPSILON) return !0
                }
                return !1
            });
            this.revokedFaceboxes.forEach(function(c) {
                c = a.findNearestFacebox(c);
                b("removeFromArray")(a.faceboxes, c);
                b("DOM").remove(c.node)
            })
        };
        c.updateFaceboxes = function() {
            this.faceboxes = [];
            this.tags = [];
            for (var a in this.tagRects) {
                var c;
                b("PhotosUtils").isFacebox(a) ? c = this.faceboxes : b("PhotosUtils").isTag(a) && (c = this.tags);
                if (c) {
                    var d = "container";
                    this.version === b("PhotosConst").VIEWER_PERMALINK && (d = "root");
                    d = b("DOM").scry(this.viewer[d], "#" + a);
                    d.length > 0 && c.push({
                        node: d[0],
                        id: a,
                        rect: this.tagRects[a]
                    })
                }
                this.showTagIfCommentAdded()
            }
            this.updateRevokedFaceboxes();
            this.faceboxes.sort(function(a, b) {
                return a.rect.getCenter().x - b.rect.getCenter().x
            });
            if (this.currentFacebox) {
                d = this.currentFacebox.rect.getCenter();
                this.setCurrentFacebox(this.findNearestFacebox(d));
                b("CSS").addClass(this.currentFacebox.node, "active")
            }
            this.requestFaceboxNextTag && (this.addNextTagFromFacebox(1), this.requestFaceboxNextTag = !1)
        };
        c.getFacebox = function(a) {
            for (var b = 0; b < this.faceboxes.length; ++b)
                if (this.faceboxes[b].id === a) return this.faceboxes[b];
            return null
        };
        c.setupFaceboxSuggestionHandlers = function(a, c) {
            var d = this,
                e = b("DOM").find(c, "a._570w"),
                f = b("DOM").find(c, "a._570x");
            this.handlers.push(b("Event").listen(e, "click", function(e) {
                e = d._getCurrentFaceboxID();
                var f = d.version === b("PhotosConst").VIEWER_PERMALINK ? b("FaceboxSourceConstants").PERMALINK_DISMISS : b("FaceboxSourceConstants").SNOWLIFT_DISMISS;
                d.dismissFaceboxSuggestion(a.id.replace("face:", ""), c.getAttribute("data-id"), d.photoData.owner, f);
                d.removeSuggestionFromTagger();
                d.hideTagger();
                b("DOM").remove(d.getFaceboxSuggestionFromFaceboxElem(a.node));
                b("Arbiter").inform("PhotoTagger.TAG_SUGGESTION_REJECTED/" + e)
            }), b("Event").listen(f, "click", function(a) {
                a = d._getCurrentFaceboxID();
                var e = {
                    uid: c.getAttribute("data-id"),
                    text: c.getAttribute("data-text")
                };
                e = d.tokenizer.createToken(e);
                var f = d.version === b("PhotosConst").VIEWER_PERMALINK ? b("FaceboxSourceConstants").PERMALINK_SUGGEST : b("FaceboxSourceConstants").SNOWLIFT_SUGGEST;
                d.saveTag(null, e, f);
                b("Arbiter").inform("PhotoTagger.TAG_SUGGESTION_CONFIRMED/" + a)
            }))
        };
        c._getCurrentFaceboxID = function() {
            return this.currentFacebox && this.currentFacebox.id.substring(5)
        };
        a.getInstance = function(b) {
            return a.instances[b]
        };
        a.resetAlbumTaggingSuggestions = function(b) {
            b = a.getInstance(b);
            b && b.resetAlbumTaggingSuggestions()
        };
        return a
    }();
    Object.assign(a, {
        instances: {}
    });
    e.exports = a
}), null);
__d("PhotoTags", ["csx", "Arbiter", "CSS", "DOM", "Event", "Parent", "PhotosConst", "ge"], (function(a, b, c, d, e, f, g) {
    a = function() {
        "use strict";

        function a(a, c, d) {
            var e = this;
            this.tagTargets = a;
            this.tagBox = c;
            this.version = d || b("PhotosConst").VIEWER_PERMALINK;
            this.handlers = [];
            this.tagTargets.forEach(function(a) {
                e.handlers.push(b("Event").listen(a, {
                    mouseover: e.showTag.bind(e),
                    mouseout: e.hideTags.bind(e)
                }))
            });
            this.subscriptions = [];
            this.version == b("PhotosConst").VIEWER_SNOWLIFT && this.subscriptions.push(b("Arbiter").subscribe("PhotoSnowlift.PAGE", this.hideTags.bind(this)))
        }
        var c = a.prototype;
        c.showTag = function(a) {
            a = a.getTarget();
            var c = b("CSS").hasClass(a, "taggee"),
                d = b("CSS").matchesSelector(a, "._54ru"),
                e = null,
                f = null;
            if (c) e = a.getAttribute("data-tag"), f = a.getAttribute("data-tagtype");
            else if (d) {
                c = b("Parent").byTag(a, "a");
                e = c && c.getAttribute("data-tag")
            }
            e || (a = b("Parent").byClass(a, "taggee"), a && (e = a.getAttribute("data-tag"), f = a.getAttribute("data-tagtype")));
            d = this.version == b("PhotosConst").VIEWER_PERMALINK ? "perm:tag:" + e : "tag:" + e;
            c = d && b("ge")(d);
            c && (f === "product" ? b("CSS").addClass(c, "hover") : b("CSS").addClass(c, "showTag"), b("CSS").addClass(this.tagBox, "showingTag"), b("Arbiter").inform("PhotoTags.SHOWTAG", e))
        };
        c.hideTags = function() {
            b("CSS").removeClass(this.tagBox, "showingTag"), b("DOM").scry(this.tagBox, "div.showTag").forEach(function(a) {
                b("CSS").removeClass(a, "showTag")
            }), b("DOM").scry(this.tagBox, "div.hover").forEach(function(a) {
                b("CSS").removeClass(a, "hover")
            }), b("Arbiter").inform("PhotoTags.HIDETAG")
        };
        c.destroy = function() {
            for (var a in this.handlers) this.handlers[a].remove();
            this.subscriptions.forEach(b("Arbiter").unsubscribe, b("Arbiter"))
        };
        return a
    }();
    e.exports = a
}), null);
__d("PhotoViewerFollow", ["$", "Arbiter", "AsyncRequest", "CSS", "DOM", "Event", "ODS", "Parent", "PhotosConst", "collectDataAttributes"], (function(a, b, c, d, e, f) {
    var g = {};
    a = function() {
        "use strict";

        function a(a) {
            this.FOLLOW_LOCATION_PHOTO = 48, this.viewer = a
        }
        var c = a.prototype;
        c.init = function(a, c, d, e, f, g, h) {
            var i = this;
            this.subscribeLink = a;
            this.unsubscribeFlyout = c;
            this.subscribeEndpoints = f;
            this.unsubscribeEndpoints = g;
            this.unsubLinks = e;
            this.unsubDiv = d;
            this.reset();
            this.activate();
            this.type = h;
            b("Event").listen(this.subscribeLink, "click", function(a) {
                b("Parent").byClass(a.getTarget(), "photoViewerFollowLink") && i.subscribePhotoOwner()
            });
            b("Event").listen(this.unsubLinks.user, "click", this.unsubscribePhotoOwner.bind(this));
            b("Event").listen(this.unsubLinks.page, "click", this.unsubscribePhotoOwner.bind(this));
            b("Arbiter").subscribe(["FollowUser", "FollowUserFail", "UnfollowUser", "UnfollowUserFail"], this.updateSubscribe.bind(this));
            b("Arbiter").subscribe(this.viewer.getEventString("DATA_CHANGE"), this.showSubscribeLinkOnChange.bind(this));
            this.viewer.getVersionConst() === b("PhotosConst").VIEWER_SNOWLIFT && (b("Arbiter").subscribe(this.viewer.getEventString("CLOSE"), this.reset.bind(this)), b("Arbiter").subscribe(this.viewer.getEventString("OPEN"), this.activate.bind(this)));
            this.registerUnsubscribeTarget()
        };
        c.activate = function() {
            this.activated = !0
        };
        c.reset = function() {
            this.unsubscribeFlyout && this.unsubscribeFlyout.clearNodes(), this.subscriptionChange = {}, this.activated = !1
        };
        c.registerUnsubscribeTarget = function() {
            if (!this.unsubscribeFlyout) return;
            var a = b("DOM").scry(this.subscribeLink, ".photoViewerFollowedMsg")[0];
            a && !b("CSS").hasClass(a, "unsubFlyoutEnabled") && (this.unsubscribeFlyout.initNode(a), b("CSS").addClass(a, "unsubFlyoutEnabled"))
        };
        c.updateSubscribe = function(a, b) {
            if (!this.activated) return;
            b = b.profile_id;
            b && (this.subscriptionChange[b] = a === "FollowUser" || a === "UnfollowUserFail" ? "following" : "unfollowed", this.toggleSubscribeLink(b))
        };
        c.showSubscribeLinkOnChange = function(a, c) {
            this.type = c.ownertype, b("CSS").conditionClass(this.unsubDiv, "isPage", this.type === "page"), this.toggleSubscribeLink(c.owner)
        };
        c.toggleSubscribeLink = function(a) {
            var c = b("DOM").scry(this.subscribeLink, "span.fbPhotoSubscribeWrapper")[0];
            if (!c) return;
            this.subscriptionChange[a] && (b("CSS").conditionClass(c, "followingOwner", this.subscriptionChange[a] === "following"), this.subscriptionChange[a] === "unfollowed" && (this.unsubscribeFlyout && this.unsubscribeFlyout.hideFlyout(!0)));
            this.registerUnsubscribeTarget()
        };
        c.subscribePhotoOwner = function() {
            if (!this.viewer.getOwnerId()) return;
            var a = this.type === "user" ? {
                profile_id: this.viewer.getOwnerId()
            } : {
                fbpage_id: this.viewer.getOwnerId(),
                add: !0,
                reload: !1,
                fan_origin: "photo_snowlift"
            };
            b("Arbiter").inform("FollowUser", {
                profile_id: this.viewer.getOwnerId()
            });
            this.type === "page" && b("ODS").bumpEntityKey(2966, "snowlift_page_like", "snowlift_page_like.clicked_link");
            a.location = this.FOLLOW_LOCATION_PHOTO;
            var c = event.getTarget();
            c && Object.assign(a, {
                ft: b("collectDataAttributes")(c, ["ft"]).ft
            });
            new(b("AsyncRequest"))(this.subscribeEndpoints[this.type]).setAllowCrossPageTransition(!0).setData(a).setMethod("POST").setReadOnly(!1).setErrorHandler(b("Arbiter").inform.bind(null, "FollowUserFail", a)).send()
        };
        c.unsubscribePhotoOwner = function() {
            if (!this.viewer.getOwnerId()) return;
            var a = this.type === "user" ? {
                profile_id: this.viewer.getOwnerId()
            } : {
                fbpage_id: this.viewer.getOwnerId(),
                add: !1,
                reload: !1
            };
            b("Arbiter").inform("UnfollowUser", {
                profile_id: this.viewer.getOwnerId()
            });
            a.location = this.FOLLOW_LOCATION_PHOTO;
            var c = event.getTarget();
            c && Object.assign(a, {
                ft: b("collectDataAttributes")(c, ["ft"]).ft
            });
            new(b("AsyncRequest"))(this.unsubscribeEndpoints[this.type]).setAllowCrossPageTransition(!0).setData(a).setMethod("POST").setReadOnly(!1).setErrorHandler(b("Arbiter").inform.bind(null, "UnfollowUserFail", a)).send()
        };
        a.createInstance = function(c, d, e, f, h, i, j, k) {
            c = c.getInstance();
            var l = new a(c);
            l.init(b("$")(d), e, f, h, i, j, k);
            g[c.getVersionConst()] = l;
            return l
        };
        a.getInstance = function(a) {
            return g[a]
        };
        return a
    }();
    e.exports = a
}), null);
__d("PhotoViewerInitPagelet", ["DOM", "PhotoSnowlift", "PhotoTagApproval", "PhotoTagger", "PhotoTags", "ge"], (function(a, b, c, d, e, f) {
    a = function(a) {
        "use strict";
        b("PhotoSnowlift").attachTagger(a.tagging, a.tokenizer, a.ufi);
        var c = b("PhotoSnowlift").getInstance(),
            d = c.getRoot();
        new(b("PhotoTags"))([b("ge")("fbPhotoSnowliftAuthorName"), b("DOM").find(d, "span.fbPhotoTagList")], b("ge")("fbPhotoSnowliftTagBoxes"), a.version);
        if (a.setupPhotoTagger) {
            d = new(b("PhotoTagger"))(c);
            d.initSnowlift(a.tagging, a.tokenizer, a.userId, a.ufi);
            d.setQueueName(a.queueName)
        }
        new(b("PhotoTagApproval"))(c)
    };
    e.exports = a
}), null);
__d("TagToken", ["DOM", "Token"], (function(a, b, c, d, e, f) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(b) {
            return a.call(this, b, "tag") || this
        }
        var d = c.prototype;
        d.createElement = function() {
            var a = this.isFreeform(),
                c = b("DOM").create("span", {
                    className: "separator"
                }, ", "),
                d = b("DOM").create(a ? "span" : "a", {
                    className: "taggee",
                    "data-tag": this.getValue()
                }, this.getText());
            a || (d.href = this.getInfo().path);
            return b("DOM").create("span", {
                className: "tagItem"
            }, [c, d])
        };
        return c
    }(b("Token"));
    e.exports = a
}), null);
__d("TagTokenizer", ["fbt", "Arbiter", "CSS", "DOM", "Parent", "TagToken", "Tokenizer", "createObjectFrom", "ge", "getElementText"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(c, d, e, f, g) {
            e = a.call(this, e, f, g) || this;
            b("Arbiter").subscribe("PhotoInlineEditor.CANCEL_INLINE_EDITING", e.updateTokenareaVisibility.bind(babelHelpers.assertThisInitialized(e)), "new");
            e.appphoto = d;
            b("Arbiter").subscribe(c.getInstance().getEventString("DATA_CHANGE"), e.setup.bind(babelHelpers.assertThisInitialized(e)), "new");
            return e
        }
        var d = c.prototype;
        d.setup = function(a, b) {
            this.appphoto = b.byapp;
            this.byowner = b.isowner;
            return this.reset()
        };
        d.reset = function() {
            var c = this,
                d = this.getTokenElements().map(this.getTokenDataFromTag, this);
            this.withTagKeys = {};
            var e = this.getWithTagTokenElements().map(function(a) {
                return c._tokenKey(c.getTokenDataFromTag(a))
            });
            this.withTagKeys = b("createObjectFrom")(e);
            return a.prototype.reset.call(this, d)
        };
        d.processEvents = function(a, c, d) {
            if (b("Parent").byClass(c, "remove")) {
                d = this.getTokenFromElement(d);
                d = this.addTokenData(d, c);
                this.removeToken(d);
                a.kill()
            }
        };
        d.insertToken = function(a) {
            return null
        };
        d.removeToken = function(a) {
            if (this.appphoto) return this.replaceToken(a);
            else this.inform("removeToken", a), b("Arbiter").inform("Form/change", {
                node: this.element
            });
            return null
        };
        d.addTokenData = function(a, c) {
            b("Parent").byClass(c, "blockuser") && (a.blockUser = !0);
            return a
        };
        d.getTokenDataFromTag = function(a) {
            return {
                uid: b("DOM").find(a, "input").value,
                text: b("getElementText")(b("DOM").find(a, ".taggee"))
            }
        };
        d.getTokenElementFromTarget = function(a) {
            return b("Parent").byClass(a, "tagItem")
        };
        d.getTokenElements = function() {
            return b("DOM").scry(this.tokenarea, "span.tagItem").filter(this.filterNonTokenElements, this)
        };
        d.getWithTagTokenElements = function() {
            return b("DOM").scry(this.tokenarea, "span.withTagItem")
        };
        d.filterNonTokenElements = function(a) {
            return !b("CSS").hasClass(a, "markasspam") && !b("CSS").hasClass(a, "reported") && !b("CSS").hasClass(a, "withTagItem")
        };
        d.createToken = function(a, c) {
            var d = this.getToken(this._tokenKey(a));
            d = d || new(b("TagToken"))(a);
            c && d.setElement(c);
            return d
        };
        d.updateTokenareaVisibility = function() {
            var a = this.getTokenElements().filter(function(a) {
                    return b("CSS").shown(a)
                }),
                c = this.getWithTagTokenElements(),
                d = b("DOM").scry(this.tokenarea, "span.ogTagItem");
            b("CSS").conditionShow(this.tokenarea, a.length !== 0 || c.length !== 0 || d.length !== 0)
        };
        d.replaceToken = function(a) {
            if (!a) return;
            var c = this.tokens.indexOf(a);
            if (c < 0) return;
            this.tokens.splice(this.tokens.indexOf(a), 1);
            delete this.unique[this._tokenKey(a.getInfo())];
            c = b("ge")("tagspam" + a.getValue());
            c && b("DOM").remove(c);
            c = [" [", g._("Tag Removed."), " "];
            c.push(b("DOM").create("a", {
                onclick: this.markAsSpam.bind(this, a.getValue())
            }, g._("Mark tag as spam")));
            c.push("] ");
            c = b("DOM").create("span", {
                className: "fbPhotosTaglistTag tagItem markasspam",
                id: "tagspam" + a.getValue()
            }, c);
            b("DOM").replace(a.getElement(), c);
            this.updateTokenarea();
            this.inform("removeToken", a);
            b("Arbiter").inform("Form/change", {
                node: this.element
            })
        };
        d.markAsSpam = function(a) {
            var c = b("ge")("tagspam" + a),
                d = [" [", g._("Tag Reported"), "] "];
            d = b("DOM").create("span", {
                className: "fbPhotosTaglistTag tagItem reported",
                id: "tagspam" + a
            }, d);
            b("DOM").replace(c, d);
            this.inform("markTagAsSpam", a)
        };
        d.removeTokenForSpatialTag = function(b) {
            a.prototype.removeToken.call(this, b)
        };
        return c
    }(b("Tokenizer"));
    e.exports = a
}), null);
__d("TagTypeaheadView", ["AsyncRequest", "CSS", "ContextualTypeaheadView", "DOM", "FamilyTaggingConfig", "Parent"], (function(a, b, c, d, e, f) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(b, c) {
            b = a.call(this, b, c) || this;
            b.hintText = c.hintText;
            b.userEd = c.userEd;
            b.origAutoSelect = c.autoSelect;
            b.setSuggestions(c.suggestions);
            return b
        }
        var d = c.prototype;
        d.init = function() {
            b("CSS").addClass(this.element, "uiTagTypeaheadView"), a.prototype.init.call(this)
        };
        d.buildResults = function(c) {
            this.hasResultsWithEmptyInput = !1;
            (!this.value || this.hasResultsWithEmptyInput) && this.hintText && c.unshift({
                subtext: this.hintText,
                type: "hintText"
            });
            this.userEd && (new(b("AsyncRequest"))().setURI("/ajax/fof/user_education.php").setData({
                increment: 1
            }).send(), c.unshift({
                subtext: this.userEd,
                type: "userEdText"
            }));
            if (b("FamilyTaggingConfig").gk) {
                var d = [],
                    e = [];
                for (var f = 0; f < c.length; f++) c[f].type !== "family_tags" && c[f].index != -1e3 && c[f].type !== "hintText" ? d.push(c[f]) : e.push(c[f]);
                c = e.concat(d);
                a.prototype.updateResults.call(this, c)
            }
            f = a.prototype.buildResults.call(this, c);
            this.userEd && c.shift();
            (!this.value || this.hasResultsWithEmptyInput) && c.shift();
            return f
        };
        d.show = function() {
            var c = b("DOM").scry(this.context, ".typeaheadBackdrop");
            c.length > 0 && b("CSS").addClass(c[0], "resultsPresent");
            return a.prototype.show.call(this)
        };
        d.hide = function() {
            var c = b("DOM").scry(this.context, ".typeaheadBackdrop");
            c.length > 0 && b("CSS").removeClass(c[0], "resultsPresent");
            return a.prototype.hide.call(this)
        };
        d.render = function(b, c, d) {
            this.autoSelect = this.origAutoSelect && b.length, this.disableAutoSelect = b.length === 0, c = c.concat(this.getAdditionalResults()), a.prototype.render.call(this, b, c, d)
        };
        d.getItems = function() {
            var b = a.prototype.getItems.call(this);
            (!this.value || this.hasResultsWithEmptyInput) && b.shift();
            this.userEd && b.shift();
            return b
        };
        d.getSuggestions = function() {
            return this.suggestions
        };
        d.setSuggestions = function(a) {
            this.suggestions = a ? a.map(String) : [], this.visible = !!this.suggestions.length
        };
        d.addSuggestion = function(a) {
            this.suggestions.unshift(a)
        };
        d.addTypeaheadFlip = function(a) {
            b("CSS").addClass(this.element, a)
        };
        d.removeTypeaheadFlip = function(a) {
            b("CSS").removeClass(this.element, a)
        };
        d.getContext = function() {
            var c = b("Parent").byClass(this.element, "typeaheadContainer");
            if (c) return c;
            else return a.prototype.getContext.call(this)
        };
        d.getAdditionalResults = function() {
            return []
        };
        return c
    }(b("ContextualTypeaheadView"));
    e.exports = a
}), null);
__d("UFI2ReactionsCount.react", ["cx", "fbt", "invariant", "JSResource", "NumberFormat", "ShimButton.react", "UFI2BluePrimerDialog.react", "UFI2CometRelayCreateFragmentContainer", "UFI2ReactionsCount_feedback.graphql", "UFI2Tooltip.react", "UFIReactionsProfileBrowserUtils", "intlList", "lazyLoadComponent", "react"], (function(a, b, c, d, e, f, g, h, i, j) {
    "use strict";
    var k, l = d("react"),
        m = function(a) {
            return l.jsx("span", babelHelpers["extends"]({}, a))
        },
        n = c("lazyLoadComponent")(c("JSResource")("UFI2ReactionsCountTooltipContent.react").__setRef("UFI2ReactionsCount.react"));
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$1 = function(a) {}, b) || babelHelpers.assertThisInitialized(c)
        }
        var e = b.prototype;
        e.render = function() {
            var a = this.props,
                b = a.feedback;
            a = a.relay;
            var e = b.i18n_reaction_count,
                f = b.id,
                g = b.important_reactors,
                h = b.reaction_count,
                i = b.reaction_display_config,
                k = b.viewer_actor,
                p = b.viewer_feedback_reaction_info;
            b = (b = (b = b.viewer_actor) == null ? void 0 : b.id) != null ? b : "0";
            h = h == null ? void 0 : h.count;
            f != null || j(0, 3978);
            h != null || j(0, 3979);
            e != null || j(0, 3980);
            if (h === 0) return null;
            k = k == null ? void 0 : k.name;
            g = (g = g == null ? void 0 : g.nodes) != null ? g : [];
            p = p != null;
            var q = p ? g.length + 1 : g.length;
            q = q < h;
            var r = q ? c("UFI2Tooltip.react") : m;
            q = q ? {
                environment: a.environment,
                tooltipContentComponent: n,
                tooltipContentProps: {
                    queryVariables: {
                        feedbackTargetID: f
                    },
                    reactionCount: h
                }
            } : {};
            a = d("UFIReactionsProfileBrowserUtils").getPrimerProps({
                actorID: b,
                feedbackTargetID: f
            });
            b = (i == null ? void 0 : i.reaction_display_strategy) === "HIDE_COUNTS";
            return l.jsx(c("UFI2BluePrimerDialog.react"), {
                Component: c("ShimButton.react"),
                props: babelHelpers["extends"]({}, a, {
                    children: l.jsxs(l.Fragment, {
                        children: [!b && l.jsx("span", {
                            "aria-hidden": !0,
                            className: "_3dlg",
                            children: l.jsx(r, babelHelpers["extends"]({
                                className: "_3dlh"
                            }, q, {
                                children: l.jsx("span", {
                                    className: "_81hb",
                                    children: e
                                })
                            }))
                        }, "count-sentence"), l.jsx("span", {
                            className: "_3dlh _3dli",
                            "data-testid": void 0,
                            children: l.jsx(r, babelHelpers["extends"]({}, q, {
                                children: l.jsx("span", {
                                    className: "_81hb",
                                    children: l.jsx(o, {
                                        actorName: k,
                                        i18nReactionCount: e,
                                        importantReactors: g,
                                        isPrivateFeedback: b,
                                        reactionCount: h,
                                        viewerReacted: p
                                    })
                                })
                            }))
                        }, "social-sentence")]
                    }),
                    className: "_3dlf" + (b ? " _8io7" : ""),
                    "data-testid": "UFI2ReactionsCount/root",
                    form: this.props.disableReactorDialog === !0 ? "none" : "link",
                    onClick: this.$1
                })
            })
        };
        return b
    }(l.Component);
    a.displayName = "UFI2ReactionsCount";

    function o(a) {
        var b = a.actorName,
            d = a.i18nReactionCount,
            e = a.importantReactors,
            f = a.isPrivateFeedback;
        f = f === void 0 ? !1 : f;
        var g = a.reactionCount;
        a = a.viewerReacted;
        if (a && g === 1) return b;
        if (!a && e.length === 0 && !f) return p(d, g);
        b = [a ? i._("You") : null].concat(e.map(function(a) {
            return a == null ? void 0 : a.name
        })).filter(Boolean);
        a = g - b.length;
        if (f) {
            e = 3;
            f = b.slice(0, e);
            e = g > f.length;
            return c("intlList")([].concat(f, [e && f.length > 0 && i._("others")]).filter(Boolean))
        }
        a > 0 && b.push(i._({
            "*": "{number} others",
            "_1": "1 other"
        }, [i._plural(a, "number", p(d, a))]));
        return c("intlList")(b)
    }

    function p(a, b) {
        var c = Math.floor(Math.log10(b));
        return c < 3 ? d("NumberFormat").formatInteger(b) : a
    }
    e = c("UFI2CometRelayCreateFragmentContainer").createFragmentContainer(a, {
        feedback: k !== void 0 ? k : k = b("UFI2ReactionsCount_feedback.graphql")
    });
    g["default"] = e
}), 98);
__d("SnowliftUFISummary.react", ["cx", "RelayModern", "SnowliftUFISummary_feedback.graphql", "TrackingNodes", "UFI2CommentsCount.react", "UFI2ErrorBoundary.react", "UFI2PrivateReplyIndicator.react", "UFI2ReactionsCount.react", "UFI2SeenByCount.react", "UFI2SharesCount.react", "UFI2TopReactions.react", "UFI2ViewCount.react", "joinClasses", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = d("react");

    function a(a) {
        var b, d = a.feedback;
        a = a.onClickCommentsCount;
        var e = d.can_show_seen_by,
            f = d.comment_count,
            g = d.is_unseen,
            h = d.reaction_count,
            i = d.seen_by_count,
            l = d.share_count,
            m = d.video_view_count;
        b = (b = d) != null ? (b = b.page_private_reply) != null ? b.status : b : b;
        i = ((i = i) != null ? i.count : i) || 0;
        e = e === !0 && i > 0;
        f = (i = f) != null ? i.total_count : i;
        h = (i = h) != null ? i.count : i;
        l = (i = l) != null ? i.count : i;
        i = c("UFI2PrivateReplyIndicator.react").shouldRender(b);
        return !e && !f && !h && !l && !m && !i ? j.jsx("div", {
            className: "_6iib"
        }) : j.jsxs("div", {
            className: "_6iib",
            "data-testid": void 0,
            children: [j.jsxs("div", {
                className: "_6iic",
                children: [h ? j.jsxs(j.Fragment, {
                    children: [j.jsxs("div", {
                        className: "_6iid",
                        children: [j.jsx(c("UFI2ErrorBoundary.react"), {
                            children: j.jsx(c("UFI2TopReactions.react"), {
                                className: "_6iie",
                                feedback: d
                            })
                        }), j.jsx(c("UFI2ErrorBoundary.react"), {
                            children: j.jsx(c("UFI2ReactionsCount.react"), {
                                feedback: d
                            })
                        })]
                    }), j.jsx("div", {
                        className: "_6iif"
                    })]
                }) : null, j.jsx(k, {
                    className: h ? "" : "_6iig",
                    feedback: d,
                    onClickCommentsCount: a
                }), i ? j.jsx(c("UFI2PrivateReplyIndicator.react"), {
                    className: "_6iih" + (h ? "" : " _6iig")
                }) : null]
            }), g === !0 ? j.jsx("div", {
                className: "_6iii"
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function k(a) {
        var b = a.feedback,
            d = a.onClickCommentsCount,
            e = c("TrackingNodes").getTrackingInfo(c("TrackingNodes").types.BLINGBOX);
        return j.jsxs("div", {
            className: c("joinClasses")("_6iij", a.className),
            children: [j.jsx(c("UFI2ErrorBoundary.react"), {
                children: j.jsx(c("UFI2CommentsCount.react"), {
                    className: "_6iik",
                    feedback: b,
                    onClick: d,
                    trackingInfo: e
                })
            }), j.jsx(c("UFI2ErrorBoundary.react"), {
                children: j.jsx(c("UFI2SharesCount.react"), {
                    className: "_6iik",
                    feedback: b
                })
            }), j.jsx(c("UFI2ErrorBoundary.react"), {
                children: j.jsx(c("UFI2SeenByCount.react"), {
                    className: "_6iik",
                    feedback: b
                })
            }), j.jsx(c("UFI2ErrorBoundary.react"), {
                children: j.jsx(c("UFI2ViewCount.react"), {
                    className: "_6iik",
                    feedback: b
                })
            })]
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";
    a.displayName = "SnowliftUFISummary";
    e = d("RelayModern").createFragmentContainer(a, {
        feedback: i !== void 0 ? i : i = b("SnowliftUFISummary_feedback.graphql")
    });
    g["default"] = e
}), 98);
__d("SnowliftUFIRenderer.react", ["cx", "fbt", "invariant", "BootloadedComponent.react", "FBLogger", "JSResource", "ReactDOM", "RelayFBEnvironment", "RelayModern", "RelayUFI2Environment", "ScriptPath", "SnowliftUFIRenderer_feedback.graphql", "SnowliftUFIRenderer_shareableConfig.graphql", "SnowliftUFISummary.react", "UFI2ActorSelector.react", "UFI2Comment.react", "UFI2CommentActionLink.react", "UFI2CommentDisabledNotice.react", "UFI2CommentTranslateAllButton.react", "UFI2CommentsFilterFallbackWarning.react", "UFI2CommentsList.react", "UFI2CommentsPager.react", "UFI2Composer.react", "UFI2CreateCommentMutation", "UFI2FeedbackCommentReactSubscription", "UFI2FeedbackReactSubscription", "UFI2HiddenCommentsPlaceholder.react", "UFI2LazyCodedErrorDialog.react", "UFI2PaginationProgressIndicator.react", "UFI2PrivateReplyActionLink.react", "UFI2ReactionActionLink.react", "UFI2RealtimeContainer.react", "UFI2RealtimeRoot.react", "UFI2RepliesCollapser.react", "UFI2RepliesExpander.react", "UFI2ShareActionLink.react", "UFI2SurfaceContainerContext", "UFI2ViewOption", "XUISpinner.react", "getCommentCreateMutationPropertiesFromTrackingData", "getConsumerFacebookUFI2ComposerPlugins__DEPRECATED", "getViewportViewDurationPropertiesFromTrackingData", "getWorkplaceUFI2ComposerPlugins__DEPRECATED", "isCommentTokenOrFBID", "joinClasses", "justknobx", "lazyLoadComponent", "logCommentViewportViewDuration", "nullthrows", "react"], (function(a, b, c, d, e, f, g, h, i, j) {
    "use strict";
    var k, l, m = d("react"),
        n = c("BootloadedComponent.react").create(c("JSResource")("UFI2ViewOptionsSelector.react").__setRef("SnowliftUFIRenderer.react")),
        o = c("lazyLoadComponent")(c("JSResource")("UFI2CommentEditor.react").__setRef("SnowliftUFIRenderer.react"));

    function p(a) {
        return a != null ? d("RelayUFI2Environment").forActor(a) : c("RelayFBEnvironment")
    }

    function q(a, b) {
        var d = a.getComposerPluginsToInsertBeforePositions,
            e = a.feedback,
            f = a.feedbackTargetID;
        a = a.isWorkplace;
        var g = e.viewer_actor,
            h = e.mentions_datasource_js_constructor_args_json,
            i = g && g.id,
            j = p(i);
        d = d ? d({
            feedback: e,
            feedbackTargetID: f
        }) : null;
        return {
            composerPluginProps: {
                initialPlugins: [].concat(a === !0 ? c("getWorkplaceUFI2ComposerPlugins__DEPRECATED")({
                    environment: j,
                    feedback: e,
                    feedbackTargetID: f,
                    group: e == null ? void 0 : e.associated_group,
                    pluginsToInsertBeforePositions: null
                }) : c("getConsumerFacebookUFI2ComposerPlugins__DEPRECATED")({
                    actor: g,
                    environment: j,
                    feedback: e,
                    group: null,
                    pluginsToInsertBeforePositions: d
                })).filter(Boolean)
            },
            editingCommentID: null,
            maybeCodedError: null,
            mirroredCurrentActor: i,
            mirroredMentionsDataSourceJSON: h,
            renderedTranslationCommentID: null,
            shouldRequestTranslationForAllComments: Boolean(b == null ? void 0 : b.shouldRequestTranslationForAllComments)
        }
    }
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, e;
            for (var f = arguments.length, g = new Array(f), h = 0; h < f; h++) g[h] = arguments[h];
            return (b = e = a.call.apply(a, [this].concat(g)) || this, e.$1 = null, e.state = q(e.props, null), e.$2 = function() {
                var a = e.props.feedback,
                    b = a.id;
                a = a.subscription_target_id;
                return b != null && a != null ? d("UFI2FeedbackCommentReactSubscription").subscribe(p(e.state.mirroredCurrentActor), {
                    top_level_feedback_id: b
                }, e.props.useDefaultActor, e.context.isComet) : null
            }, e.$3 = function() {
                var a = e.props.feedback,
                    b = a.id;
                a = a.subscription_target_id;
                return b != null && a != null ? d("UFI2FeedbackReactSubscription").subscribe(p(e.state.mirroredCurrentActor), {
                    feedback_id: b
                }, e.props.useDefaultActor) : null
            }, e.$4 = function() {
                e.$1 && e.$1.Actions.toggleList({
                    focusComposer: !1
                })
            }, e.$5 = function(a) {
                e.$1 ? (e.$1.Actions.expandList({
                    focusComposer: !0,
                    scrollToComposer: !0
                }), a.preventDefault()) : c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", e.props.feedbackTargetID || "UNKNOWN").mustfix("The 'comment' button was clicked but no comments list ref could be found. That ref is needed to make sure the comments list is open.")
            }, e.$6 = function() {
                e.$1 && e.$1.Actions.expandList({
                    focusComposer: !0,
                    scrollToComposer: !0
                })
            }, e.$7 = function(a) {
                var b = a.actorID,
                    f = a.clientID,
                    g = a.commentData,
                    h = a.entitiesByID,
                    i = a.environment,
                    j = a.focusCommentID,
                    k = a.getTrackingDataFn,
                    l = a.topLevelFeedbackID;
                a = a.useDefaultActor;
                if (!g) return;
                d("UFI2CreateCommentMutation").commit({
                    actorID: b,
                    clientID: f,
                    containerMapping: c("nullthrows")((b = e.context) == null ? void 0 : b.containerMapping),
                    entitiesByID: h,
                    environment: i,
                    feedbackSource: 17,
                    focusCommentID: j,
                    input: babelHelpers["extends"]({}, g, c("getCommentCreateMutationPropertiesFromTrackingData")(k)),
                    isComet: e.context.isComet,
                    onError: e.$8,
                    topLevelFeedbackId: l,
                    triggerAccessibilityAlert: null,
                    useDefaultActor: a
                })
            }, e.$9 = function() {
                e.setState(function(a) {
                    return a.maybeCodedError == null ? null : {
                        maybeCodedError: babelHelpers["extends"]({}, a.maybeCodedError, {
                            acknowledged: !0
                        })
                    }
                })
            }, e.$8 = function(a) {
                e.setState({
                    maybeCodedError: {
                        acknowledged: !1,
                        error: a
                    }
                })
            }, e.$10 = function() {
                e.setState({
                    shouldRequestTranslationForAllComments: !0
                })
            }, e.$11 = function(a) {
                e.setState({
                    editingCommentID: a
                })
            }, e.$12 = function(a) {
                e.setState({
                    renderedTranslationCommentID: a
                })
            }, b) || babelHelpers.assertThisInitialized(e)
        }
        b.getDerivedStateFromProps = function(a, b) {
            var c, d = b.mirroredCurrentActor,
                e = b.mirroredMentionsDataSourceJSON,
                f = a.feedback;
            return ((c = f) != null ? (c = c.viewer_actor) != null ? c.id : c : c) !== d || f.mentions_datasource_js_constructor_args_json !== e ? q(a, b) : null
        };
        var e = b.prototype;
        e.render = function() {
            var a = this,
                b = this.props,
                e = b.composerPortalNode,
                f = b.displayCommentsFeedbackContext,
                g = b.domAttachmentEventEmitter,
                h = b.feedback,
                i = b.feedbackTargetID,
                j = b.focusCommentID,
                k = b.onActorChange,
                l = b.shareableConfig,
                n = b.stageActionsPortalNode,
                o = b.storyRenderLocation,
                p = b.useDefaultActor;
            b = this.state;
            var q = b.composerPluginProps,
                u = b.editingCommentID,
                w = b.maybeCodedError,
                x = b.renderedTranslationCommentID,
                y = b.shouldRequestTranslationForAllComments,
                z = {
                    feedback: h,
                    feedbackTargetID: i,
                    onActorChange: k,
                    onClickCommentsCount: this.$4,
                    onCommentClick: this.$5,
                    shareableConfig: l,
                    useDefaultActor: p
                };
            b = c("justknobx")._("197") === !0 ? h.can_viewer_see_ufi : !0;
            return b === !1 ? null : m.jsxs(m.Fragment, {
                children: [m.jsx(c("UFI2RealtimeRoot.react"), {
                    enabled: h.is_eligible_for_real_time_updates === !0,
                    children: m.jsx(c("UFI2RealtimeContainer.react"), {
                        subscribe: this.$2,
                        children: m.jsx(c("UFI2CommentsList.react"), {
                            displayCommentsContext: {
                                feedbackContext: f
                            },
                            fallback: m.jsxs(m.Fragment, {
                                children: [m.jsx(c("UFI2RealtimeContainer.react"), {
                                    subscribe: this.$3,
                                    children: m.jsx(r, babelHelpers["extends"]({}, z))
                                }), (k = this.props.commentsListFallback) != null ? k : null]
                            }),
                            feedback: h,
                            feedbackSource: 17,
                            focusCommentID: j,
                            listRef: function(b) {
                                a.$1 = b
                            },
                            useDefaultActor: p,
                            children: function(b) {
                                return m.jsxs(m.Fragment, {
                                    children: [m.jsx(c("UFI2RealtimeContainer.react"), {
                                        subscribe: a.$3,
                                        children: m.jsx(r, babelHelpers["extends"]({
                                            commentsListRenderProps: b
                                        }, z))
                                    }), m.jsx(t, {
                                        commentsListRenderProps: b,
                                        composerPluginProps: q,
                                        domAttachmentEventEmitter: g,
                                        editingCommentID: u,
                                        feedback: h,
                                        feedbackTargetID: i,
                                        focusCommentID: j,
                                        onAddCommentClick: a.$6,
                                        onCommitCommentCreate: a.$7,
                                        onEditCommentError: a.$8,
                                        onTranslateAllClick: a.$10,
                                        renderedTranslationCommentID: x,
                                        setEditingCommentID: a.$11,
                                        setRenderedTranslationCommentID: a.$12,
                                        storyRenderLocation: o,
                                        shouldRequestTranslationForAllComments: y
                                    }), e ? d("ReactDOM").createPortal(m.jsx(v, {
                                        commentsListRenderProps: b,
                                        composerPluginProps: q,
                                        feedback: h,
                                        feedbackTargetID: i,
                                        onCommitCommentCreate: a.$7
                                    }), e) : null, n ? d("ReactDOM").createPortal(m.jsx(c("UFI2RealtimeContainer.react"), {
                                        subscribe: a.$3,
                                        children: m.jsx(s, {
                                            feedback: h,
                                            feedbackTargetID: i,
                                            onCommentClick: a.$5,
                                            shareableConfig: l,
                                            useDefaultActor: p
                                        })
                                    }), n) : null]
                                })
                            }
                        })
                    })
                }), w && m.jsx(c("UFI2LazyCodedErrorDialog.react"), {
                    error: w.error,
                    onHide: this.$9,
                    shown: w.acknowledged === !1
                })]
            })
        };
        return b
    }(m.Component);
    a.displayName = "SnowliftUFIRenderer";
    a.contextType = c("UFI2SurfaceContainerContext");

    function r(a) {
        var b = a.commentsListRenderProps,
            d = a.feedback,
            e = a.feedbackTargetID,
            f = a.onActorChange,
            g = a.onCommentClick,
            h = a.onClickCommentsCount,
            i = a.shareableConfig;
        a = a.useDefaultActor;
        var j = d.comment_count;
        j = (j = j) != null ? j.total_count : j;
        j = (b == null ? void 0 : b.isInitiallyExpanded) && j != null && j > 0 && (d.num_localized_comment_orderings || 0) > 1;
        var k = null;
        b && j === !0 && (k = m.jsx("div", {
            className: "_6iin",
            children: m.jsx(n, {
                bootloadPlaceholder: m.jsx("div", {
                    className: "_6iip"
                }),
                className: "_6iio",
                feedback: d,
                onChange: function(a) {
                    return b.Actions.setViewOption({
                        viewOption: a
                    })
                },
                selectedViewOption: b.viewOption
            })
        }));
        return m.jsxs(m.Fragment, {
            children: [m.jsx(c("SnowliftUFISummary.react"), {
                feedback: d,
                onClickCommentsCount: h
            }), m.jsxs("div", {
                className: "_6iis",
                children: [d.can_see_voice_switcher === !0 ? m.jsx(c("UFI2ActorSelector.react"), {
                    className: "_6iit",
                    feedback: d,
                    onActorChange: f
                }) : null, m.jsxs("div", {
                    className: "_6iiu",
                    children: [d.can_viewer_react === !0 && m.jsx(c("UFI2ReactionActionLink.react"), {
                        enableAnimations: !0,
                        feedback: d,
                        feedbackSource: 17,
                        useDefaultActor: a
                    }), d.can_viewer_comment === !0 && m.jsx(c("UFI2CommentActionLink.react"), {
                        onClick: g
                    }), m.jsx(c("UFI2ShareActionLink.react"), {
                        feedback: d,
                        feedbackTargetID: e,
                        shareableConfig: i
                    }), m.jsx(c("UFI2PrivateReplyActionLink.react"), {
                        feedback: d,
                        feedbackSource: 17,
                        seeResponseLabel: !1
                    })]
                })]
            }), j === !0 ? k : null]
        })
    }

    function s(a) {
        var b = a.feedback,
            d = a.feedbackTargetID,
            e = a.onCommentClick,
            f = a.shareableConfig;
        a = a.useDefaultActor;
        return m.jsxs("div", {
            className: "_6r2x",
            children: [b.can_viewer_react === !0 && m.jsx(c("UFI2ReactionActionLink.react"), {
                feedback: b,
                feedbackSource: 17,
                useDefaultActor: a,
                className: "_6r2y",
                inverse: !0
            }), b.can_viewer_comment === !0 && m.jsx(c("UFI2CommentActionLink.react"), {
                onClick: e,
                className: "_6r2y",
                inverse: !0
            }), m.jsx(c("UFI2ShareActionLink.react"), {
                feedback: b,
                feedbackTargetID: d,
                shareableConfig: f,
                className: "_6r2y",
                inverse: !0
            }), m.jsx(c("UFI2PrivateReplyActionLink.react"), {
                feedback: b,
                feedbackSource: 17,
                seeResponseLabel: !1
            })]
        })
    }
    s.displayName = s.name + " [from " + f.id + "]";

    function t(a) {
        var b = a.commentsListRenderProps,
            e = a.composerPluginProps,
            f = a.domAttachmentEventEmitter,
            g = a.editingCommentID,
            h = a.feedback,
            k = a.feedbackTargetID,
            l = a.focusCommentID,
            n = a.onCommitCommentCreate,
            p = a.onEditCommentError,
            q = a.onTranslateAllClick,
            r = a.renderedTranslationCommentID,
            s = a.setEditingCommentID,
            t = a.setRenderedTranslationCommentID,
            v = a.shouldRequestTranslationForAllComments,
            w = a.storyRenderLocation;
        b.depth === 0 || j(0, 1563);
        a = b.Selectors;
        var x = b.addReplyToCommentCallback,
            y = b.clearReplyToCommentCallback,
            z = b.depth,
            A = b.getCommentEditorProps,
            B = b.getCommentProps,
            C = b.getFilterWarningPropsForOlderComments,
            D = b.getHiddenCommentsPlaceholderProps,
            E = b.getPagerPropsForNewerComments,
            F = b.getPagerPropsForOlderComments,
            G = b.getPaginationProgressProps,
            H = b.getNestedCommentsListProps,
            I = b.listState,
            J = b.onCommentsListMouseEnter,
            K = b.onCommentsListMouseLeave,
            L = b.viewOption;
        b = d("UFI2ViewOption").shouldDisplayInReverse(L);
        var M = a.isListExpanded({
                depth: z,
                state: I
            }),
            N = a.isListLoading({
                depth: z,
                state: I
            }),
            O = a.getVisibleCommentsCount({
                depth: z,
                state: I
            });
        if (!M) return null;
        if (M && O === 0 && N) return m.jsx("div", {
            className: "_6iiv _6iiw",
            children: m.jsx(c("XUISpinner.react"), {
                className: "_6iji",
                size: "large"
            })
        });
        M = a.getVisibleCommentsWithHiddenCommentsCollapsed({
            depth: z,
            reverse: b,
            state: I
        });
        var P = (N = h) != null ? N.viewer_actor : N;
        N = h.can_viewer_comment === !0;
        N && !P && c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", k || "UNKNOWN").mustfix("SnowliftUFI: Cant render composer without actor");
        N = m.jsx(c("UFI2CommentsPager.react"), babelHelpers["extends"]({}, E(), {
            className: "_6ijj"
        }));
        k = m.jsx(c("UFI2CommentsPager.react"), babelHelpers["extends"]({}, F(), {
            className: "_6ijj"
        }));
        E = a.isPagerVisible({
            depth: z,
            direction: "forward",
            state: I
        }) ? m.jsx(c("UFI2PaginationProgressIndicator.react"), babelHelpers["extends"]({}, G(), {
            className: "_6ijj"
        })) : null;
        return m.jsxs("div", {
            className: c("joinClasses")("_6iiv" + (O > 0 ? " _6r_e" : "")),
            "data-testid": void 0,
            onMouseEnter: J,
            onMouseLeave: K,
            children: [m.jsx("h6", {
                className: "accessible_elem",
                children: i._("Comments")
            }), m.jsxs("div", {
                className: "_6iiz _77bo",
                children: [b ? k : N, b ? E : null]
            }), O > 0 ? m.jsx("ul", {
                className: "_77bp",
                children: M.map(function(a, b) {
                    if (a.state === "COLLAPSED") {
                        var i;
                        return m.jsx("li", {
                            children: m.jsx(c("UFI2HiddenCommentsPlaceholder.react"), babelHelpers["extends"]({}, D(), {
                                className: "_6ijk" + (b === 0 ? " _77bq" : ""),
                                commentIDs: a.comments.map(function(a) {
                                    return a.id
                                })
                            }))
                        }, "hidden-" + ((i = (i = a.comments[0]) == null ? void 0 : i.id) != null ? i : b))
                    } else if (a.state === "VISIBLE") return m.jsx(m.Fragment, {
                        children: a.comments.map(function(a, i) {
                            var j = a.id,
                                k = a.optimistic_action == null && a.optimistic_error == null,
                                z = B(a);
                            i = m.jsx(c("UFI2Comment.react"), babelHelpers["extends"]({}, z, {
                                className: "_6ijk" + (i === 0 && b === 0 ? " _77bq" : "") + " clearfix",
                                domAttachmentEventEmitter: f,
                                feedbackSource: 17,
                                isHighlighted: c("isCommentTokenOrFBID")(l, a),
                                logCommentViewportViewDuration: k ? function(a, b, e) {
                                    c("logCommentViewportViewDuration")(babelHelpers["extends"]({
                                        commentID: j,
                                        endpoint: d("ScriptPath").getScriptPath(),
                                        isLivePinnedComment: !1,
                                        isReply: !1,
                                        milliseconds: b,
                                        storyRenderLocation: w
                                    }, c("getViewportViewDurationPropertiesFromTrackingData")(e), {
                                        visibleStartTime: a
                                    }))
                                } : null,
                                onEdit: function() {
                                    return s(j)
                                },
                                onTranslated: function() {
                                    return t(j)
                                },
                                onUntranslated: function() {
                                    r === j && t(null)
                                },
                                storyRenderLocation: w,
                                translationRequested: v
                            }));
                            k = z.key || j;
                            return m.jsxs("li", {
                                children: [j === g ? m.jsx(m.Suspense, {
                                    fallback: m.jsx("div", {
                                        "aria-busy": "true",
                                        className: "aero",
                                        children: i
                                    }),
                                    children: m.jsx(o, babelHelpers["extends"]({}, e, A(), {
                                        comment: a,
                                        depth: 0,
                                        onError: p,
                                        onFinishEdit: function() {
                                            return s(null)
                                        },
                                        storyRenderLocation: w
                                    }))
                                }) : i, j === r && !v ? m.jsx(c("UFI2CommentTranslateAllButton.react"), {
                                    onClick: q
                                }) : null, m.jsx(c("UFI2CommentsList.react"), babelHelpers["extends"]({}, H(j), {
                                    children: function(a) {
                                        return m.jsx(u, {
                                            addReplyToCommentCallback: x,
                                            clearReplyToCommentCallback: y,
                                            composerPluginProps: e,
                                            currentActor: P,
                                            domAttachmentEventEmitter: f,
                                            editingCommentID: g,
                                            feedback: h,
                                            focusCommentID: l,
                                            onCommitCommentCreate: n,
                                            onEditCommentError: p,
                                            onTranslateAllClick: q,
                                            renderedTranslationCommentID: r,
                                            repliesListRenderProps: a,
                                            setEditingCommentID: s,
                                            setRenderedTranslationCommentID: t,
                                            storyRenderLocation: w,
                                            shouldRequestTranslationForAllComments: v,
                                            topLevelViewOption: L
                                        })
                                    }
                                }))]
                            }, k)
                        })
                    }, b);
                    return null
                })
            }) : null, L === "RANKED_THREADED" && m.jsx(c("UFI2CommentsFilterFallbackWarning.react"), babelHelpers["extends"]({}, C(), {
                className: "_6ijk"
            })), m.jsxs("div", {
                className: "_6iiz _77br",
                children: [b ? N : k, b ? null : E]
            })]
        })
    }
    t.displayName = t.name + " [from " + f.id + "]";
    var u = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a() {
            return b.apply(this, arguments) || this
        }
        var e = a.prototype;
        e.render = function() {
            var a = this.props,
                b = a.composerPluginProps,
                e = a.currentActor,
                f = a.domAttachmentEventEmitter,
                g = a.editingCommentID,
                h = a.focusCommentID,
                i = a.onCommitCommentCreate,
                k = a.onEditCommentError,
                l = a.onTranslateAllClick,
                n = a.renderedTranslationCommentID,
                p = a.repliesListRenderProps,
                q = a.setEditingCommentID,
                r = a.setRenderedTranslationCommentID,
                s = a.shouldRequestTranslationForAllComments,
                t = a.storyRenderLocation;
            a = a.topLevelViewOption;
            p.depth === 1 || j(0, 1564);
            var u = p.Selectors,
                v = p.depth,
                w = p.getCommentEditorProps,
                x = p.getCommentProps,
                y = p.getComposerProps,
                z = p.getHiddenCommentsPlaceholderProps,
                A = p.getFilterWarningPropsForOlderComments,
                B = p.getFilterWarningPropsForNewerComments,
                C = p.getPagerPropsForNewerComments,
                D = p.getPagerPropsForOlderComments,
                E = p.getRepliesCollapserProps,
                F = p.getRepliesExpanderProps,
                G = p.listState,
                H = p.onCommentsListMouseEnter,
                I = p.onCommentsListMouseLeave;
            p = p.viewOption;
            p = d("UFI2ViewOption").shouldDisplayInReverse(p);
            var J = u.getVisibleCommentsWithHiddenCommentsCollapsed({
                    depth: v,
                    reverse: p,
                    state: G
                }),
                K = u.isComposerVisible({
                    depth: v,
                    state: G
                }),
                L = u.isListExpanded({
                    depth: v,
                    state: G
                }),
                M = u.isRepliesExpanderLoading({
                    depth: v,
                    state: G
                });
            u = u.getVisibleCommentsCount({
                depth: v,
                state: G
            });
            y = babelHelpers["extends"]({}, b, y(), {
                actor: e,
                className: "_6ijm",
                commentAction: "ADD",
                commentID: null,
                depth: v,
                key: "composerForUID" + ((G = e == null ? void 0 : e.id) != null ? G : "UNKNOWN"),
                onCommit: i
            });
            v = !L || M ? m.jsx(c("UFI2RepliesExpander.react"), babelHelpers["extends"]({}, F(), {
                className: "_6ii- _6ijj"
            })) : m.jsxs(m.Fragment, {
                children: [m.jsx(c("UFI2RepliesCollapser.react"), babelHelpers["extends"]({}, E(), {
                    className: "_6iiy"
                })), m.jsx(c("UFI2CommentsPager.react"), babelHelpers["extends"]({}, p ? D() : C(), {
                    className: "_6ii- _6ijj"
                })), a === "RANKED_THREADED" && m.jsx(c("UFI2CommentsFilterFallbackWarning.react"), babelHelpers["extends"]({}, p ? A() : B(), {
                    className: "_6ijl clearfix",
                    viewOption: a
                })), u > 0 ? m.jsx("ul", {
                    children: J.map(function(a, e) {
                        if (a.state === "COLLAPSED") {
                            var i;
                            return m.jsx("li", {
                                children: m.jsx(c("UFI2HiddenCommentsPlaceholder.react"), babelHelpers["extends"]({}, z(), {
                                    className: "_6ijk",
                                    commentIDs: a.comments.map(function(a) {
                                        return a.id
                                    })
                                }))
                            }, "hidden-" + ((i = (i = a.comments[0]) == null ? void 0 : i.id) != null ? i : e))
                        } else if (a.state === "VISIBLE") return m.jsx(m.Fragment, {
                            children: a.comments.map(function(a) {
                                var e = a.id,
                                    i = a.optimistic_action == null && a.optimistic_error == null,
                                    j = x(a);
                                i = m.jsx(c("UFI2Comment.react"), babelHelpers["extends"]({}, j, {
                                    className: "_6ijl clearfix",
                                    domAttachmentEventEmitter: f,
                                    feedbackSource: 17,
                                    isHighlighted: c("isCommentTokenOrFBID")(h, a),
                                    logCommentViewportViewDuration: i ? function(a, b, f) {
                                        c("logCommentViewportViewDuration")(babelHelpers["extends"]({
                                            commentID: e,
                                            endpoint: d("ScriptPath").getScriptPath(),
                                            isLivePinnedComment: !1,
                                            isReply: !0,
                                            milliseconds: b,
                                            storyRenderLocation: t
                                        }, c("getViewportViewDurationPropertiesFromTrackingData")(f), {
                                            visibleStartTime: a
                                        }))
                                    } : null,
                                    onEdit: function() {
                                        return q(e)
                                    },
                                    onTranslated: function() {
                                        return r(e)
                                    },
                                    onUntranslated: function() {
                                        n === e && r(null)
                                    },
                                    storyRenderLocation: t,
                                    translationRequested: s
                                }));
                                return m.jsxs("li", {
                                    children: [e === g ? m.jsx(m.Suspense, {
                                        fallback: m.jsx("div", {
                                            "aria-busy": "true",
                                            className: "aero",
                                            children: i
                                        }),
                                        children: m.jsx(o, babelHelpers["extends"]({}, b, w(), {
                                            comment: a,
                                            depth: 1,
                                            feedbackSource: 17,
                                            onError: k,
                                            onFinishEdit: function() {
                                                return q(null)
                                            },
                                            storyRenderLocation: t
                                        }))
                                    }) : i, e === n && !s ? m.jsx(c("UFI2CommentTranslateAllButton.react"), {
                                        onClick: l
                                    }) : null]
                                }, j.key || e)
                            })
                        }, e);
                        return null
                    })
                }) : null, a === "RANKED_THREADED" && m.jsx(c("UFI2CommentsFilterFallbackWarning.react"), babelHelpers["extends"]({}, p ? B() : A(), {
                    className: "_6ijl clearfix",
                    viewOption: a
                })), m.jsx(c("UFI2CommentsPager.react"), babelHelpers["extends"]({}, p ? C() : D(), {
                    className: "_6ii- _6ijj"
                })), K && e != null ? m.jsx(c("UFI2Composer.react"), babelHelpers["extends"]({}, y, {
                    actor: e
                })) : null]
            });
            return m.jsx("div", {
                className: "_6iix",
                "data-testid": void 0,
                onMouseEnter: H,
                onMouseLeave: I,
                children: v
            })
        };
        return a
    }(m.Component);

    function v(a) {
        var b = a.commentsListRenderProps,
            d = a.composerPluginProps,
            e = a.feedback,
            f = a.feedbackTargetID;
        a = a.onCommitCommentCreate;
        b.depth === 0 || j(0, 1563);
        var g = b.Selectors,
            h = b.depth,
            i = b.getComposerProps;
        b = b.listState;
        var k = g.isComposerVisible({
            depth: h,
            state: b
        });
        g = g.isListExpanded({
            depth: h,
            state: b
        });
        if (!g) return null;
        g = (b = e) != null ? b.viewer_actor : b;
        b = e.can_viewer_comment === !0;
        b && !g && c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", f || "UNKNOWN").mustfix("SnowliftUFI: Cant render composer without actor");
        return e.have_comments_been_disabled === !0 || e.is_viewer_muted === !0 ? m.jsx(c("UFI2CommentDisabledNotice.react"), {
            feedback: e
        }) : k && b && g != null ? m.createElement(c("UFI2Composer.react"), babelHelpers["extends"]({}, d, i(), {
            actor: g,
            className: "clearfix _6ijr",
            commentAction: "ADD",
            commentID: null,
            depth: h,
            formClassName: "_6ijs",
            key: "composerForUID" + ((f = g.id) != null ? f : "UNKNOWN"),
            onCommit: a
        })) : null
    }
    e = d("RelayModern").createFragmentContainer(a, {
        feedback: k !== void 0 ? k : k = b("SnowliftUFIRenderer_feedback.graphql"),
        shareableConfig: l !== void 0 ? l : l = b("SnowliftUFIRenderer_shareableConfig.graphql")
    });
    g["default"] = e
}), 98);
__d("isIntern", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        if (typeof window === "undefined" || !window || !window.location || !window.location.pathname) return !1;
        var a = window.location.pathname,
            b = "/intern";
        return a.substr(0, b.length) === b
    }
    f["default"] = a
}), 66);
__d("SnowliftUFIRoot.react", ["cx", "BootloadedComponent.react", "FBLogger", "FDSSpinner.react", "JSResource", "RelayAPIConfig", "RelayModern", "RelayPreloadedQueryRenderer.react", "RelayUFI2Environment", "SnowliftUFIRenderer.react", "SnowliftUFIRootQuery.graphql", "UFI2LocalUserAction", "UFIODSLogger", "isIntern", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = d = a.call.apply(a, [this].concat(f)) || this, d.state = {
                actorID: d.props.defaultActorID || c("RelayAPIConfig").actorID
            }, d.$1 = function(a) {
                var b = a.error;
                a = a.props;
                var e = d.props.queryVariables;
                if (b) return j.jsx(c("BootloadedComponent.react"), {
                    bootloadLoader: c("JSResource")("SnowliftUFIError.react").__setRef("SnowliftUFIRoot.react"),
                    bootloadPlaceholder: j.jsx("div", {
                        className: "_6iji",
                        children: j.jsx(c("FDSSpinner.react"), {})
                    }),
                    error: b
                });
                if (a == null) return j.jsx("div", {
                    className: "_6iji",
                    children: j.jsx(c("FDSSpinner.react"), {})
                });
                b = a.feedback;
                a = a.shareable_config;
                if (!b) {
                    c("isIntern")() ? c("FBLogger")("ufi2").mustfix("Query is missing feedback data for an intern endpoint.") : c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", e.feedbackTargetID || "UNKNOWN").mustfix("Query is missing feedback data.");
                    return null
                }
                var f = e.displayCommentsFeedbackContext,
                    g = e.feedbackTargetID,
                    h = e.focusCommentID;
                return j.jsx(c("SnowliftUFIRenderer.react"), {
                    getComposerPluginsToInsertBeforePositions: d.props.getComposerPluginsToInsertBeforePositions,
                    composerPortalNode: d.props.composerPortalNode,
                    displayCommentsFeedbackContext: f,
                    domAttachmentEventEmitter: d.props.domAttachmentEventEmitter,
                    feedback: b,
                    feedbackTargetID: g,
                    focusCommentID: h,
                    onActorChange: d.$2,
                    shareableConfig: a,
                    stageActionsPortalNode: d.props.stageActionsPortalNode,
                    storyRenderLocation: d.props.storyRenderLocation,
                    useDefaultActor: d.state.actorID === d.props.defaultActorID,
                    isWorkplace: e.containerIsWorkplace
                })
            }, d.$2 = function(a) {
                d.setState({
                    actorID: a
                })
            }, b) || babelHelpers.assertThisInitialized(d)
        }
        var e = b.prototype;
        e.componentDidMount = function() {
            d("UFIODSLogger").bump("componentDidMount.snowlift", "relay")
        };
        e.componentDidUpdate = function(a, b) {
            b.actorID !== this.state.actorID && c("UFI2LocalUserAction").emit("actor-changed", {
                actorID: this.state.actorID,
                feedbackID: this.props.queryVariables.feedbackTargetID
            })
        };
        e.render = function() {
            var a = this.state.actorID,
                e = a === this.props.defaultActorID;
            if (this.props.usePreloadedQueryRenderer && e) return j.jsx(c("RelayPreloadedQueryRenderer.react"), {
                disableEnforcement: !0,
                environment: d("RelayUFI2Environment").forActor(a),
                query: b.query,
                render: this.$1
            });
            var f = this.props.queryVariables;
            return j.jsx(d("RelayModern").QueryRenderer, {
                environment: d("RelayUFI2Environment").forActor(a),
                query: b.query,
                render: this.$1,
                variables: babelHelpers["extends"]({}, f, {
                    useDefaultActor: e
                })
            })
        };
        return b
    }(j.PureComponent);
    a.query = i !== void 0 ? i : i = b("SnowliftUFIRootQuery.graphql");
    a.displayName = "SnowliftUFIRoot";
    g["default"] = a
}), 98);
__d("SnowliftUFI.react", ["invariant", "FeedStoryUFICommentActionLinks.react", "FeedStoryUFICommentActorLinkBadges.react", "FeedStoryUFICommentAttachments.react", "FeedStoryUFICommentBody.react", "SnowliftUFIRoot.react", "UFI2CommentActorName.react", "UFI2ProfileLink.react", "UFI2SurfaceContainerProvider.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            var a = {
                containerIsFeedStory: !0,
                containerIsWorkplace: !1,
                containerIsTahoe: !1,
                containerIsLiveStory: !1
            };
            return i.jsx(c("UFI2SurfaceContainerProvider.react"), {
                providerValue: {
                    components: {
                        CommentActionLinksComponent: c("FeedStoryUFICommentActionLinks.react"),
                        CommentActorLinkBadgesComponent: c("FeedStoryUFICommentActorLinkBadges.react"),
                        CommentActorNameComponent: c("UFI2CommentActorName.react"),
                        CommentAttachmentComponent: c("FeedStoryUFICommentAttachments.react"),
                        CommentBodyComponent: c("FeedStoryUFICommentBody.react"),
                        ProfileLinkComponent: c("UFI2ProfileLink.react")
                    },
                    containerMapping: a,
                    isComet: !1
                },
                children: i.jsx(c("SnowliftUFIRoot.react"), babelHelpers["extends"]({}, this.props))
            })
        };
        return b
    }(i.PureComponent);
    g["default"] = a
}), 98);
__d("UFI2UnifiedInputComposerAction.react", ["cx", "fbt", "JSResource", "UFI2ComposerAction.react", "UFI2ComposerActionPlaceholder.react", "lazyLoadComponent", "react"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = c("lazyLoadComponent")(c("JSResource")("UFI2UnifiedInputButton.react").__setRef("UFI2UnifiedInputComposerAction.react"));
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            var a = this,
                b = i._("Post stickers, emojis and GIFs");
            return j.jsx(c("UFI2ComposerAction.react"), {
                createComponentProps: function(c) {
                    c = c.clicked;
                    return {
                        buttonClassName: "_1t9_ _1ta3",
                        config: a.props.config,
                        iconActiveClassName: "UFICommentEmojiIconActive",
                        iconClassName: "InsertEmoji",
                        initiallyVisible: c,
                        label: b,
                        onComposerStateChange: a.props.onComposerStateChange
                    }
                },
                label: b,
                placeholder: j.jsx(c("UFI2ComposerActionPlaceholder.react"), {
                    buttonClassName: "_1t9_ _1ta3",
                    iconClassName: "InsertEmoji",
                    label: b
                }),
                resource: k
            })
        };
        return b
    }(j.PureComponent);
    g["default"] = a
}), 98);
__d("FreeformTokenizerBehavior", ["Event", "Input", "Keys"], (function(a, b, c, d, e, f) {
    function a(a, c) {
        var d = c.matcher && new RegExp(c.matcher, "i"),
            e = c.splitter && new RegExp(c.splitter),
            f = c.tokenize_on_blur !== !1,
            g = c.tokenize_on_paste !== !1,
            h = c.split_on_check === !0,
            i = c.select_on_comma !== !1,
            j = c.select_on_space === !0,
            k = c.never_submit === !0;

        function l(c) {
            var f = b("Input").getValue(a.getInput()).trim();
            e && c && c.type == "paste" ? f = f.split(e) : e && h ? f = f.split(e) : f = [f];
            var g = !1;
            for (var i = 0; i < f.length; i++) {
                var j = f[i].trim();
                if (j && (!d || d.test(j))) {
                    j = {
                        uid: j,
                        text: j,
                        freeform: !0
                    };
                    a.addToken(a.createToken(j));
                    g = !0
                }
            }
            c && g && (a.getTypeahead().getCore().afterSelect(), c.kill())
        }
        a.subscribe("keydown", function(c, d) {
            c = d.event;
            d = b("Event").getKeyCode(c);
            if (d == b("Keys").RETURN || i && d == b("Keys").COMMA || j && d == b("Keys").SPACE) {
                var e = a.getTypeahead().getView();
                e.getSelection() ? (e.select(), c.kill()) : l(c)
            }
            d == b("Keys").RETURN && k && c.kill()
        });
        a.subscribe("paste", function(a, b) {
            g && setTimeout(l.bind(null, b.event), 20)
        });
        a.subscribe("blur", function(b, c) {
            f && l(), a.getTypeahead().getCore().reset()
        })
    }
    e.exports = a
}), null);
__d("TypeaheadHintText", ["emptyFunction"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a(a) {
            this._typeahead = a
        }
        var b = a.prototype;
        b.enable = function() {
            this._typeahead.getCore().resetOnKeyup = !1
        };
        return a
    }();
    Object.assign(a.prototype, {
        disable: b("emptyFunction")
    });
    e.exports = a
}), null);
__d("legacy:HintTextTypeaheadBehavior", ["TypeaheadHintText"], (function(a, b, c, d, e, f) {
    a.TypeaheadBehaviors || (a.TypeaheadBehaviors = {}), a.TypeaheadBehaviors.hintText = function(a) {
        a.enableBehavior(b("TypeaheadHintText"))
    }
}), 3);
__d("TypeaheadMetrics", ["AsyncRequest", "Event", "QueriesHistory", "emptyFunction"], (function(a, b, c, d, e, f) {
    var g = 1e3;
    a = function() {
        "use strict";

        function a(a) {
            this.extraData = {}, Object.assign(this, a)
        }
        var c = a.prototype;
        c.init = function(a) {
            this.init = b("emptyFunction"), this._initImpl(a)
        };
        c._initImpl = function(a) {
            this.core = a.getCore(), this.view = a.getView(), this.data = a.getData(), this.queriesHistory = new(b("QueriesHistory"))(g), this.stats = {}, this.sessionActive = !1, this._sessionStartEvents = [], this._sessionEndEvents = [], this._reset(), this.initEvents()
        };
        c._reset = function() {
            this.log = [], this.stats = {}, this.avgStats = {}, this.sessionActive = !1, this._setSid(Math.floor(Date.now() * Math.random())), this.request_ids = [], this.lastNotBackspacedQuery = "", this.queriesHistory.reset(), this._logEvent("session_started", {})
        };
        c._logEvent = function(a, b) {
            a = {
                type: a,
                data: b,
                time: Date.now()
            };
            this.log.push(a)
        };
        c._setSid = function(a) {
            this.sid = a, typeof this.data.queryData === "object" && this.data.queryData !== null ? this.data.queryData.sid = this.sid : this.data.setQueryData({
                sid: this.sid
            }), typeof this.data.bootstrapData === "object" && this.data.bootstrapData !== null ? this.data.bootstrapData.sid = this.sid : this.data.setBootstrapData({
                sid: this.sid
            })
        };
        c.resetWithData = function(a) {
            this.init = b("emptyFunction"), this._initImpl(a)
        };
        c.resetWithDataBeforeSessionEnd = function(a) {
            var c = this.sessionActive;
            this.init = b("emptyFunction");
            this._initImpl(a);
            this.sessionActive = c
        };
        c.recordSelect = function(a) {
            var b = a.selected;
            b.uid == null ? this.recordStat("selected_id", "SELECT_NULL") : this.recordStat("selected_id", b.uid);
            this.recordStat("selected_type", b.type);
            this.recordStat("selected_score", b.score);
            this.recordStat("selected_original_id", b.original_id);
            this.recordStat("place_id", b.place_id);
            this.recordStat("client_time", b.client_time);
            this.recordStat("selected_position", a.index);
            this.recordStat("selected_with_mouse", a.clicked ? 1 : 0);
            this.recordStat("selected_query", a.query);
            this._sessionEnd()
        };
        c.bindSessionStart = function(a, b, c) {
            var d = this;
            if (c)
                for (var c = 0; c < this._sessionStartEvents.length; ++c) {
                    var e = this._sessionStartEvents[c];
                    e.obj.unsubscribe(e.token)
                }
            this._sessionStartEvents.push({
                obj: a,
                token: a.subscribe(b, function(a, b) {
                    d._sessionStart()
                })
            })
        };
        c.bindSessionEnd = function(a, b, c) {
            var d = this;
            if (c)
                for (var c = 0; c < this._sessionEndEvents.length; ++c) {
                    var e = this._sessionEndEvents[c];
                    e.obj.unsubscribe(e.token)
                }
            this._sessionEndEvents.push({
                obj: a,
                token: a.subscribe(b, function(a, b) {
                    d._sessionEnd()
                })
            })
        };
        c.dataSubscribe = function(a, b) {
            var c = this.data,
                d = this.data.subscribe(a, b);
            this._dataSubscriptions.push(function() {
                c.unsubscribe(d)
            })
        };
        c.initEvents = function() {
            var a = this;
            this._dataSubscriptions = this._dataSubscriptions || [];
            this._dataSubscriptions.forEach(function(a) {
                a()
            });
            this._dataSubscriptions = [];
            this.bindSessionStart(this.core, "focus", !1);
            this.bindSessionEnd(this.core, "blur", !1);
            this.view.subscribe("select", function(b, c) {
                a.recordSelect(c)
            });
            this.bindSessionEnd(this.view, "select", !1);
            this.view.subscribe("render", function(b, c) {
                a.results = c
            });
            this.dataSubscribe("beforeQuery", function(b, c) {
                a._logEvent("user_typed", {
                    query: c.value
                });
                if (!c.value) return;
                a.query = c.value;
                a.queriesHistory.add(a.query);
                a.lastNotBackspacedQuery.indexOf(a.query) !== 0 && (a.lastNotBackspacedQuery = a.query);
                a.recordCountStat("num_queries")
            });
            this.dataSubscribe("beforeFetch", function(b, c) {
                c.fetch_context.bootstrap ? a.bootstrapBegin = Date.now() : c.fetch_context.queryBegin = Date.now(), a._logEvent("async_query_started", {
                    query: c.fetch_context.value,
                    request_id: c.fetch_context.request_id
                })
            });
            this.dataSubscribe("fetchComplete", function(b, c) {
                a._logEvent("async_query_completed", {
                    query: c.fetch_context.value,
                    request_id: c.fetch_context.request_id
                });
                if (c.fetch_context.bootstrap) {
                    a.recordAvgStat("bootstrap_latency", Date.now() - a.bootstrapBegin);
                    var d = {};
                    c.response.payload.entries.forEach(function(a) {
                        !d[a.type] ? d[a.type] = 1 : d[a.type]++
                    });
                    a.recordStat("bootstrap_response_types", d);
                    a.bootstrapped = !0
                } else "filtered_count" in c.response.payload && a.recordStat("filtered_count", c.response.payload.filtered_count), a.recordAvgStat("avg_query_latency", Date.now() - c.fetch_context.queryBegin)
            });
            this.dataSubscribe("respond", function(b, c) {
                a._logEvent("respond", {
                    query: c.value,
                    num_results: c.results.length
                });
                b = a.data.tokenizeBackend(c.value || "").flatValue;
                c = a.data.findBestPreviousQuery(b, a.data.getQueryIDs()) || "";
                b = a.data.getQueryIDs()[c];
                a.normalized_backend_query = c;
                a.request_id = b;
                a.request_ids.push(b)
            });
            this.dataSubscribe("dirty", function(b, c) {
                a.bootstrapped = !1
            })
        };
        c._sessionStart = function() {
            if (this.sessionActive) return;
            this.sessionActive = !0
        };
        c._sessionEnd = function() {
            if (!this.sessionActive) return;
            this.sessionActive = !1;
            this.submit();
            this._reset()
        };
        c.recordStat = function(a, b) {
            this.stats[a] = b
        };
        c.recordCountStat = function(a) {
            var b = this.stats[a];
            this.stats[a] = b ? b + 1 : 1
        };
        c.recordAvgStat = function(a, b) {
            this.avgStats[a] ? (this.avgStats[a][0] += b, ++this.avgStats[a][1]) : this.avgStats[a] = [b, 1]
        };
        c.hasStats = function() {
            return !!Object.keys(this.stats).length
        };
        c.submit = function() {
            if ("log_all_sessions" in this.extraData || this.hasStats()) {
                Object.assign(this.stats, this.extraData);
                if (this.results) {
                    var a = this.results.map(function(a, b) {
                        return a.uid
                    });
                    this.recordStat("candidate_results", JSON.stringify(a))
                }
                this.query && this.recordStat("query", this.query);
                this.lastNotBackspacedQuery && this.recordStat("last_not_backspaced_query", this.lastNotBackspacedQuery);
                this.recordStat("queries_history", JSON.stringify(this.queriesHistory.getQueries()));
                this.normalized_backend_query && this.recordStat("normalized_backend_query", this.normalized_backend_query);
                this.request_id && this.recordStat("request_id", this.request_id);
                this.request_ids.length && this.recordStat("request_ids", this.request_ids);
                this.sid && this.recordStat("sid", this.sid);
                this.bootstrapped && this.recordStat("bootstrapped", 1);
                for (var a in this.avgStats) {
                    var c = this.avgStats[a];
                    this.stats[a] = c[0] / c[1]
                }
                this.recordStat("log", JSON.stringify(this.log));
                new(b("AsyncRequest"))().setURI(this.endPoint).setMethod("POST").setData({
                    stats: this.stats
                }).setErrorHandler(b("emptyFunction")).send();
                this._reset()
            }
        };
        a.register = function(a, c, d) {
            if (document.activeElement === a) c.init(d);
            else var e = b("Event").listen(a, "focus", function() {
                c.init(d), e.remove()
            })
        };
        return a
    }();
    Object.assign(a.prototype, {
        endPoint: "/ajax/typeahead/record_basic_metrics.php"
    });
    e.exports = a
}), null);
__d("createEmojiElement", ["cx", "JSXDOM"], (function(a, b, c, d, e, f, g, h) {
    function a(a, b, d) {
        d = d || 16;
        d = {
            height: d + "px",
            width: d + "px",
            fontSize: d + "px",
            backgroundImage: "url('" + b + "')"
        };
        return c("JSXDOM").span({
            className: "_5mfr"
        }, [c("JSXDOM").span({
            className: "_6qdm",
            style: d
        }, a)])
    }
    g["default"] = a
}), 98);
__d("DOMEmoji", ["cx", "EmojiImageURL", "EmojiRenderer", "FBEmojiUtils", "JSXDOM", "createEmojiElement", "flattenArray", "isElementNode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        MAX_ITEMS: 40,
        transform: function(a, c) {
            var d = this;
            c = c || {};
            var e = c.size || 16,
                f = c.emojiUrlGenerator || b("EmojiImageURL").getFBEmojiURL;
            return b("flattenArray")(a.map(function(a) {
                if (!b("isElementNode")(a)) return b("EmojiRenderer").render(a, function(a) {
                    var c = b("FBEmojiUtils").getSupportedKey(a);
                    return c ? b("createEmojiElement")(a.join(""), f(c, e), e) : b("JSXDOM").span({
                        className: "_4ay8" + (e === 16 ? " _3kkw" : "")
                    }, a.join(""))
                }, d.MAX_ITEMS);
                else return a
            }))
        },
        params: function(a) {
            if (!a) return this;
            var b = this;
            return {
                __params: !0,
                obj: b,
                params: a
            }
        }
    };
    e.exports = a
}), null);
__d("EmoticonEmojiList", [], (function(a, b, c, d, e, f) {
    a = {
        ":)": "slightsmile",
        ":-)": "slightsmile",
        ":]": "slightsmile",
        "=)": "smile",
        "(:": "slightsmile",
        "(=": "smile",
        ":(": "frown",
        ":-(": "frown",
        ":[": "frown",
        "=(": "frown",
        ")=": "frown",
        ";-P": "winktongue",
        ";P": "winktongue",
        ";-p": "winktongue",
        ";p": "winktongue",
        ":dog:": "dog",
        ":poop:": "poop",
        ":trans:": "transflag",
        ":P": "tongue",
        ":-P": "tongue",
        ":-p": "tongue",
        ":p": "tongue",
        "=P": "tongue",
        "=p": "tongue",
        "=D": "grin",
        ":-D": "slightgrin",
        ":D": "slightgrin",
        ":o": "gasp",
        ":-O": "gasp",
        ":O": "gasp",
        ":-o": "gasp",
        ";)": "wink",
        ";-)": "wink",
        "8-)": "glasses",
        "8)": "glasses",
        "B-)": "glasses",
        "B)": "glasses",
        ">:(": "grumpy",
        ">:-(": "grumpy",
        ":/": "unsure",
        ":-/": "unsure",
        ":\\": "unsure",
        ":-\\": "unsure",
        "=/": "unsure",
        "=\\": "unsure",
        ":'(": "cry",
        ":'-(": "cry",
        ":\u2019(": "cry",
        ":\u2019-(": "cry",
        "3:)": "devil",
        "3:-)": "devil",
        "O:)": "angel",
        "O:-)": "angel",
        "0:)": "angel",
        "0:-)": "angel",
        ":*": "kiss",
        ":-*": "kiss",
        ";-*": "winkkiss",
        ";*": "winkkiss",
        "<3": "heart",
        "&lt;3": "heart",
        "\u2665": "heart",
        "^_^": "kiki",
        "^~^": "kiki",
        "-_-": "expressionless",
        ":-|": "squint",
        ":|": "squint",
        ">:o": "upset",
        ">:O": "upset",
        ">:-O": "upset",
        ">:-o": "upset",
        ">_<": "persevere",
        ">.<": "persevere",
        '<(")': "penguin",
        O_O: "flushface",
        o_o: "flushface",
        "0_0": "flushface",
        T_T: "crying",
        "T-T": "crying",
        ToT: "crying",
        "T.T": "crying",
        "-3-": "flushkiss",
        "'-_-": "sweating",
        "\u2019-_-": "sweating",
        "(y)": "like",
        ":like:": "like",
        "(Y)": "like",
        ":+1:": "thumbsup",
        "(n)": "dislike",
        "(N)": "dislike"
    };
    b = {
        slightsmile: "1f642",
        smile: "1f60a",
        frown: "1f61e",
        winktongue: "1f61c",
        dog: "1f436",
        poop: "1f4a9",
        transflag: "1f3f3_200d_26a7",
        tongue: "1f61b",
        slightgrin: "1f600",
        grin: "1f603",
        gasp: "1f62e",
        wink: "1f609",
        glasses: "1f60e",
        grumpy: "1f620",
        unsure: "1f615",
        cry: "1f622",
        devil: "1f608",
        angel: "1f607",
        kiss: "1f617",
        winkkiss: "1f618",
        heart: "2764",
        kiki: "1f60a",
        expressionless: "1f611",
        squint: "1f610",
        upset: "1f620",
        persevere: "1f623",
        penguin: "1f427",
        flushface: "1f633",
        crying: "1f62d",
        flushkiss: "1f61a",
        sweating: "1f613",
        like: "f0000",
        thumbsup: "1f44d",
        dislike: "1f44e"
    };
    c = {
        slightsmile: ":)",
        smile: "=)",
        frown: ":(",
        winktongue: ";-P",
        dog: ":dog:",
        poop: ":poop:",
        transflag: ":trans:",
        tongue: ":P",
        slightgrin: ":D",
        grin: "=D",
        gasp: ":o",
        wink: ";)",
        glasses: "8-)",
        grumpy: ">:(",
        unsure: ":/",
        cry: ":'(",
        devil: "3:)",
        angel: "O:)",
        kiss: ":*",
        winkkiss: ";*",
        heart: "<3",
        kiki: "^_^",
        expressionless: "-_-",
        squint: ":-|",
        upset: ">:o",
        persevere: ">_<",
        penguin: '<(")',
        flushface: "O_O",
        crying: "T_T",
        flushkiss: "-3-",
        sweating: "'-_-",
        like: "(y)",
        thumbsup: ":+1:",
        dislike: "(n)"
    };
    d = /(^|[\s\'\".])(:\)(?!\))|:\-\)(?!\))|:\]|=\)(?!\))|\(:|\(=|:\(|:\-\(|:\[|=\(|\)=|;P|;\-P|;\-p|;p|:dog:|:poop:|:trans:|:P|:\-P|:\-p|:p|=P|=p|=D|:\-D|:D|:o|:\-O|:O|:\-o|;\)(?!\))|;\-\)(?!\))|8\-\)(?!\))|B\-\)(?!\))|B\)(?!\))|8\)(?!\))|>:\(|>:\-\(|:\/|:\-\/|:\\|:\-\\|=\/|=\\|:\'\(|:\'\-\(|:\u2019\(|:\u2019\-\(|3:\)(?!\))|3:\-\)(?!\))|O:\)(?!\))|O:\-\)(?!\))|0:\)(?!\))|0:\-\)(?!\))|:\*|:\-\*|;\*|;\-\*|<3|&lt;3|\u2665|\^_\^|\^~\^|\-_\-|:\-\||:\||>:o|>:O|>:\-O|>:\-o|>_<|>\.<|<\(\"\)(?!\))|O_O|o_o|0_0|T_T|T\-T|ToT|T\.T|\-3\-|\'\-_\-|\u2019\-_\-|\(y\)(?!\))|:like:|\(Y\)(?!\))|:\+1:(?!\))|\(n\)(?!\))|\(N\)(?!\)))([\s\'\".,!?]|<br>|$)/;
    e = /(?:^|[\s\'\".])(:\)(?!\))|:\-\)(?!\))|:\]|=\)(?!\))|\(:|\(=|:\(|:\-\(|:\[|=\(|\)=|;P|;\-P|;\-p|;p|:dog:|:poop:|:trans:|:P|:\-P|:\-p|:p|=P|=p|=D|:\-D|:D|:o|:\-O|:O|:\-o|;\)(?!\))|;\-\)(?!\))|8\-\)(?!\))|B\-\)(?!\))|B\)(?!\))|8\)(?!\))|>:\(|>:\-\(|:\/|:\-\/|:\\|:\-\\|=\/|=\\|:\'\(|:\'\-\(|:\u2019\(|:\u2019\-\(|3:\)(?!\))|3:\-\)(?!\))|O:\)(?!\))|O:\-\)(?!\))|0:\)(?!\))|0:\-\)(?!\))|:\*|:\-\*|;\*|;\-\*|<3|&lt;3|\u2665|\^_\^|\^~\^|\-_\-|:\-\||:\||>:o|>:O|>:\-O|>:\-o|>_<|>\.<|<\(\"\)(?!\))|O_O|o_o|0_0|T_T|T\-T|ToT|T\.T|\-3\-|\'\-_\-|\u2019\-_\-|\(y\)(?!\))|:like:|\(Y\)(?!\))|:\+1:(?!\))|\(n\)(?!\))|\(N\)(?!\)))(?:[\s\'\".,!?]|<br>|$)/;
    f.names = a;
    f.emote2emojis = b;
    f.symbols = c;
    f.regexp = d;
    f.noncapturingRegexp = e
}), 66);
__d("TransformTextToDOMMixin", ["flattenArray", "isElementNode"], (function(a, b, c, d, e, f) {
    var g = 3;
    a = {
        transform: function(a, c) {
            return b("flattenArray")(a.map(function(a) {
                if (!b("isElementNode")(a)) {
                    var d = a,
                        e = [],
                        f = this.MAX_ITEMS || g;
                    while (f--) {
                        var h = c ? [d].concat(c) : [d];
                        h = this.match.apply(this, h);
                        if (!h) break;
                        e.push(d.substring(0, h.startIndex));
                        e.push(h.element);
                        d = d.substring(h.endIndex)
                    }
                    d && e.push(d);
                    return e
                }
                return a
            }.bind(this)))
        },
        params: function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            var d = this;
            return {
                __params: !0,
                obj: d,
                params: b
            }
        }
    };
    e.exports = a
}), null);
__d("DOMEmote", ["cx", "fbt", "EmojiImageURL", "EmoticonEmojiList", "EmoticonsList", "JSXDOM", "SupportedFacebookEmoji", "TransformTextToDOMMixin"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = {
        MAX_ITEMS: 40,
        match: function(a, b) {
            var c = b && b.getMessengerEmote;
            a = c ? d("EmoticonEmojiList").regexp.exec(a) : d("EmoticonsList").regexp.exec(a);
            if (!a || !a.length) return !1;
            var e = a[2];
            a = a.index + a[1].length;
            c = c ? d("EmoticonEmojiList").names[e] : d("EmoticonsList").emotes[e];
            return {
                startIndex: a,
                endIndex: a + e.length,
                element: j._element(e, c, b)
            }
        },
        _element: function(a, b, e) {
            e = e && e.getMessengerEmote;
            var f = e ? d("EmoticonEmojiList").emote2emojis[b] : d("EmoticonsList").emoji[b];
            if (f == null) return a;
            b = i._("{emoticonName} emoticon", [i._param("emoticonName", b)]);
            return c("JSXDOM").span({
                className: "_47e3 _5mfr",
                title: b
            }, [c("JSXDOM").img({
                "aria-hidden": !0,
                className: "img",
                height: 16,
                src: e ? d("EmojiImageURL").getMessengerURL(f, 16) : c("SupportedFacebookEmoji")[f] ? d("EmojiImageURL").getFBEmojiURL(f) : d("EmojiImageURL").getFBEmojiExtendedURL(f),
                width: 16
            }), c("JSXDOM").span({
                "aria-hidden": !0,
                className: "_7oe"
            }, a)])
        }
    };
    a = Object.assign(j, d("TransformTextToDOMMixin"));
    g["default"] = a
}), 98);
__d("transformTextToDOM", ["createArrayFromMixed"], (function(a, b, c, d, e, f) {
    function a(a, c) {
        var d = [a];
        c = b("createArrayFromMixed")(c);
        c.forEach(function(a) {
            var b, c = a;
            a.__params && (b = a.params, c = a.obj);
            d = c.transform(d, b)
        });
        return d
    }
    e.exports = a
}), null);
__d("emojiAndEmote", ["DOMEmoji", "DOMEmote", "FbtResultBase", "transformTextToDOM"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a, c) {
        if (a instanceof b("FbtResultBase")) return [a];
        var d = c ? {
            isSupportedEmoji: c.isSupportedEmoji
        } : null;
        c = c ? {
            getMessengerEmote: c.getMessengerEmote
        } : null;
        d = [b("DOMEmoji").params(d), b("DOMEmote").params(c)];
        return b("transformTextToDOM")(a, d)
    };
    e.exports = a
}), null);
__d("CompactTypeaheadRenderer", ["BadgeHelper", "DOM", "TypeaheadFacepile", "emojiAndEmote", "isSocialPlugin"], (function(a, b, c, d, e, f) {
    function a(a, c) {
        c = [];
        if (a.xhp) return b("DOM").create("li", {
            className: "raw"
        }, a.xhp);
        var d = a.photos || a.photo;
        d && (d instanceof Array ? d = b("TypeaheadFacepile").render(d) : d = b("DOM").create("img", {
            alt: "",
            src: d
        }), c.push(d));
        d = a.iconClass;
        if (d) {
            d = b("DOM").create("span", {
                className: d
            });
            c.push(d)
        }
        d = a.debug_info;
        d && c.push(b("DOM").create("span", {
            className: "debugInfo"
        }, d));
        if (a.text) {
            d = [a.text];
            b("isSocialPlugin")() || (d = b("emojiAndEmote")(a.text));
            a.is_verified ? d.push(b("BadgeHelper").renderBadge("xsmall", "verified")) : a.is_trending_hashtag && d.push(b("BadgeHelper").renderBadge("xsmall", "trending"));
            c.push(b("DOM").create("span", {
                className: "text"
            }, d))
        }
        d = a.subtext;
        var e = a.category;
        if (d || e) {
            var f = [];
            d && f.push(d);
            d && e && f.push(" \xb7 ");
            e && f.push(e);
            c.push(b("DOM").create("span", {
                className: "subtext"
            }, f))
        }
        d = b("DOM").create("li", {
            className: a.type || ""
        }, c);
        a.text && (d.setAttribute("title", a.text), d.setAttribute("aria-label", a.text));
        return d
    }
    a.className = "compact";
    e.exports = a
}), null);