if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometLegacyListItemBase.react", ["joinClasses", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.addon,
            d = a.children,
            e = a.className,
            f = a.right;
        a = a.testid;
        return h.jsxs("div", {
            className: c("joinClasses")("x78zum5", e),
            "data-testid": void 0,
            children: [b != null ? h.jsx("div", {
                className: "xq8finb xl56j7k x78zum5 x1cy8zhl",
                children: b
            }) : null, h.jsx("div", {
                className: "xeuugli xs83m0k x1iyjqo2 x1r8uery xamitd3",
                children: d
            }), f != null ? h.jsx("div", {
                className: "x16n37ib xl56j7k xdt5ytf x78zum5",
                children: f
            }) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometListCellGlimmer.react", ["BaseGlimmer.react", "BaseLoadingStateElement.react", "CometColumn.react", "CometColumnItem.react", "CometLegacyListItemBase.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = a.imageSize,
            d = b === void 0 ? 36 : b;
        b = a.imageStyle;
        var e = b === void 0 ? "none" : b;
        b = a.numberOfItems;
        var f = b === void 0 ? 1 : b;
        b = a.paddingHorizontal;
        b = b === void 0 ? 16 : b;
        var g = a.removeFirstItemPadding,
            j = g === void 0 ? !0 : g;
        g = a.spacing;
        a = i(function() {
            return Array(f).fill().map(function(a, b) {
                return Math.floor(Math.PI * Math.pow(10, b % 10) % 4)
            })
        }, [f]);
        return h.jsx(c("BaseLoadingStateElement.react"), {
            children: h.jsx(c("CometColumn.react"), {
                paddingHorizontal: b,
                spacing: g,
                children: a.map(function(a, b) {
                    return h.jsx(c("CometColumnItem.react"), {
                        children: h.jsx(c("CometLegacyListItemBase.react"), {
                            addon: e !== "none" ? h.jsx(c("BaseGlimmer.react"), {
                                className: c("stylex")(d === 20 ? {
                                    "height-1": "x1qx5ct2",
                                    "width-1": "xw4jnvo"
                                } : {}, d === 36 ? {
                                    "height-1": "xc9qbxq",
                                    "width-1": "x14qfxbe"
                                } : null, d === 40 ? {
                                    "height-1": "x1vqgdyp",
                                    "width-1": "x100vrsf"
                                } : null, d === 48 ? {
                                    "height-1": "xsdox4t",
                                    "width-1": "x1useyqa"
                                } : null, d === 56 ? {
                                    "height-1": "xnnlda6",
                                    "width-1": "x15yg21f"
                                } : null, d === 60 ? {
                                    "height-1": "xng8ra",
                                    "width-1": "x1247r65"
                                } : null, e === "circle" ? {
                                    "border-top-start-radius-1": "x14yjl9h",
                                    "border-top-end-radius-1": "xudhj91",
                                    "border-bottom-end-radius-1": "x18nykt9",
                                    "border-bottom-start-radius-1": "xww2gxu"
                                } : null, e === "roundedRect" ? {
                                    "border-top-start-radius-1": "x1lq5wgf",
                                    "border-top-end-radius-1": "xgqcy7u",
                                    "border-bottom-end-radius-1": "x30kzoy",
                                    "border-bottom-start-radius-1": "x9jhf4c"
                                } : null),
                                index: b
                            }) : null,
                            className: c("stylex")({
                                "padding-top-1": "x1y1aw1k",
                                "padding-bottom-1": "xwib8y2"
                            }, b === 0 && j ? {
                                "padding-top-1": "xexx8yu"
                            } : null),
                            children: h.jsx(c("BaseGlimmer.react"), {
                                className: c("stylex")({
                                    "border-top-start-radius-1": "x1lq5wgf",
                                    "border-top-end-radius-1": "xgqcy7u",
                                    "border-bottom-end-radius-1": "x30kzoy",
                                    "border-bottom-start-radius-1": "x9jhf4c",
                                    "height-1": "xx3o462"
                                }, a === 0 ? {
                                    "width-1": "x3hqpx7"
                                } : null, a === 1 ? {
                                    "width-1": "xgkjt62"
                                } : null, a === 2 ? {
                                    "width-1": "x1l3jyfm"
                                } : null, a === 3 ? {
                                    "width-1": "xh8yej3"
                                } : null),
                                index: b
                            })
                        })
                    }, b)
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSettingsListDropdownLoadingState.react", ["CometListCellGlimmer.react", "CometPopover.react", "TetraText.react", "qex", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = c("qex")._("999"),
        j = {
            actions: {
                height: "x17rw0jw",
                width: "xvy4d1p"
            },
            card: {
                width: "x1cvmir6"
            },
            cardFullHeight: {
                height: "x20eyyc",
                maxWidth: "xvv7f4i"
            },
            heading: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexShrink: "x2lah0s",
                justifyContent: "x1qughib",
                minHeight: "x21xpn4",
                paddingTop: "xz9dl7a",
                paddingEnd: "x1pi30zi",
                paddingBottom: "xjkvuk6",
                paddingStart: "x1swvt13"
            },
            root: {
                marginEnd: "x1emribx",
                marginTop: "x1ok221b"
            }
        };

    function k(a) {
        var b = a.glimmerSize;
        b = b === void 0 ? 56 : b;
        var d = a.hasActions;
        d = d === void 0 ? !1 : d;
        var e = a.numberOfItems;
        a = a.title;
        return i === !0 ? h.jsx(k.WithoutPopover, {
            glimmerSize: b,
            hasActions: d,
            numberOfItems: e,
            title: a
        }) : h.jsx("div", {
            className: c("stylex")(j.root),
            children: h.jsx(c("CometPopover.react"), {
                children: h.jsx(k.WithoutPopover, {
                    glimmerSize: b,
                    hasActions: d,
                    numberOfItems: e,
                    title: a
                })
            })
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";
    var l = 76;
    k.InnerGlimmer = function(a) {
        var b = a.numberOfItems;
        a = a.size;
        a = a === void 0 ? 56 : a;
        return h.jsx(c("CometListCellGlimmer.react"), {
            imageSize: a,
            imageStyle: "circle",
            numberOfItems: b != null ? b : Math.max(Math.ceil((window.innerHeight - 72 - 45) / l), 1)
        })
    };
    k.WithoutPopover = function(a) {
        var b = a.glimmerSize;
        b = b === void 0 ? 56 : b;
        var d = a.hasActions;
        d = d === void 0 ? !1 : d;
        var e = a.numberOfItems;
        a = a.title;
        return h.jsxs("div", {
            className: c("stylex")(j.card, e == null && j.cardFullHeight),
            children: [h.jsxs("div", {
                className: c("stylex")([j.heading]),
                children: [h.jsx(c("TetraText.react"), {
                    isSemanticHeading: !0,
                    type: "headlineEmphasized1",
                    children: a
                }), d && h.jsx("div", {
                    className: c("stylex")(j.actions)
                })]
            }), h.jsx(k.InnerGlimmer, {
                numberOfItems: e,
                size: b
            })]
        })
    };
    g["default"] = k
}), 98);
__d("TetraCircleButton.react", ["CometCircleButton.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        return h.jsx(c("CometCircleButton.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometTopNavListDropdown.react", ["fbt", "ix", "BaseHeading.react", "CometPopover.react", "CometRow.react", "CometRowItem.react", "Locale", "TetraCircleButton.react", "TetraText.react", "fbicon", "qex", "react", "stylex"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = c("qex")._("999"),
        l = {
            card: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                maxWidth: "xvv7f4i",
                minHeight: "x1t2pt76"
            },
            cardFullHeight: {
                minHeight: "xs7fzxq"
            },
            cardMaxHeight: {
                maxHeight: "x11c7tjg"
            },
            cardPanelHeight: {
                height: "xtp0wl1"
            },
            cardWidth: {
                width: "x1cvmir6"
            },
            heading: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexShrink: "x2lah0s",
                justifyContent: "x1qughib",
                minHeight: "x21xpn4",
                paddingTop: "xz9dl7a",
                paddingEnd: "x1pi30zi",
                paddingBottom: "xjkvuk6",
                paddingStart: "x1swvt13"
            },
            headingOffsetWithGlobalPanel: {
                paddingTop: "x1cnzs8"
            },
            root: {
                marginEnd: "x1emribx",
                marginTop: "x1ok221b"
            }
        },
        m = {
            "base-wash": {
                backgroundColor: "x1vtvx1t"
            },
            "card-flat": {
                backgroundColor: "xlhe6ec"
            },
            "dark-wash": {
                backgroundColor: "xatbrnm"
            },
            error: {
                backgroundColor: "x1ciooss"
            },
            highlight: {
                backgroundColor: "xwnonoy"
            },
            "light-wash": {
                backgroundColor: "x443n21"
            },
            transparent: {
                backgroundColor: "xjbqb8w"
            },
            white: {
                backgroundColor: "x2bj2ny"
            }
        };

    function a(a) {
        var b = a.children,
            d = a.label;
        a = a.name;
        if (k === !0) return j.jsx(j.Fragment, {
            children: b
        });
        else return j.jsx("div", {
            className: c("stylex")(l.root),
            children: j.jsx(c("CometPopover.react"), {
                label: d,
                popoverName: a,
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a.Card = function(a) {
        var b = a.background;
        b = b === void 0 ? "white" : b;
        var d = a.children,
            e = a.testid;
        e = a.useFullHeight;
        e = e === void 0 ? !1 : e;
        var f = a.useFullWidth;
        f = f === void 0 ? !1 : f;
        var g = a.useGlobalPanelStyles;
        g = g === void 0 ? !1 : g;
        a = a.useMaxHeight;
        return j.jsx("div", {
            className: c("stylex")(l.card, f === !1 && l.cardWidth, a === !0 && l.cardMaxHeight, e === !0 && l.cardFullHeight, g ? l.cardPanelHeight : a === !0 && l.cardMaxHeight, m[b]),
            "data-testid": void 0,
            children: d
        })
    };
    a.Title = function(a) {
        var b = a.actions;
        b = b === void 0 ? [] : b;
        var e = a.onReturn,
            f = a.testid;
        f = a.title;
        a = a.useGlobalPanelStyles;
        a = a === void 0 ? !1 : a;
        return j.jsxs("header", {
            className: c("stylex")([l.heading, a && l.headingOffsetWithGlobalPanel]),
            "data-testid": void 0,
            children: [j.jsxs(c("CometRow.react"), {
                paddingHorizontal: 0,
                paddingTop: 0,
                spacingHorizontal: 8,
                children: [e != null ? j.jsx(c("CometRowItem.react"), {
                    children: j.jsx(c("TetraCircleButton.react"), {
                        icon: d("Locale").isRTL() ? d("fbicon")._(i("514454"), 20) : d("fbicon")._(i("512647"), 20),
                        label: h._("Back"),
                        onPress: e,
                        size: 32,
                        type: "deemphasized"
                    })
                }) : null, j.jsx(c("CometRowItem.react"), {
                    verticalAlign: "center",
                    children: j.jsx(c("BaseHeading.react"), {
                        isPrimaryHeading: !0,
                        children: j.jsx(c("TetraText.react"), {
                            type: "headlineEmphasized1",
                            children: f
                        })
                    })
                })]
            }), j.jsx(c("CometRow.react"), {
                paddingHorizontal: 0,
                paddingTop: 0,
                spacingHorizontal: 8,
                children: b.map(function(a, b) {
                    return j.jsx(c("CometRowItem.react"), {
                        children: a
                    }, b)
                })
            })]
        })
    };
    a.styles = {
        cardWidth: l.cardWidth
    };
    g["default"] = a
}), 98);
__d("useLayerKeyCommands", ["CometLayerKeyCommandWidget"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("CometLayerKeyCommandWidget").useKeyCommands
}), 98);
__d("CometGlobalPanelPopoverActiveContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        isPopoverActive: !1,
        setIsPopoverActive: function() {}
    });
    g["default"] = b
}), 98);
__d("CometSwitcherGating", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        return c("gkx")("5844")
    };
    b = function() {
        return c("gkx")("223")
    };
    d = function() {
        return c("gkx")("6886")
    };
    g.shouldPreserveUrlOnProfileSwitch = a;
    g.shouldShowSimpleDropdownHeader = b;
    g.shouldShowProfileSwitcher = d
}), 98);
__d("previousProfileIdForToastSessionStorage", ["WebStorage"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        get: function() {
            var a;
            return (a = c("WebStorage").getSessionStorage()) == null ? void 0 : a.getItem("previous_profile_id")
        },
        remove: function() {
            var a;
            (a = c("WebStorage").getSessionStorage()) == null ? void 0 : a.removeItem("previous_profile_id")
        },
        set: function(a) {
            c("WebStorage").setItemGuarded(c("WebStorage").getSessionStorage(), "previous_profile_id", a)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("CometSection.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var c = a.children,
            d = a.className,
            e = a.name,
            f = a.role;
        a = a.testid;
        return h.jsx("div", {
            "aria-label": e,
            className: d,
            "data-testid": void 0,
            ref: b,
            role: f,
            children: c
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometContentArea.react", ["CometSection.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.applyFullHeight;
        b = b === void 0 ? !1 : b;
        var d = a.children,
            e = a.hasNoRole;
        e = e === void 0 ? !1 : e;
        a = a.verticalAlign;
        a = a === void 0 ? "top" : a;
        return h.jsx("div", {
            className: "x1t2pt76 x193iq5w xl56j7k x78zum5 x1qjc9v5" + (b ? " x5yr21d" : ""),
            children: h.jsx(c("CometSection.react"), {
                className: "xh8yej3 x1t2pt76 x193iq5w xdt5ytf x78zum5 x6s0dn4" + (a === "middle" ? " xl56j7k" : ""),
                role: e ? void 0 : "main",
                children: d
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("PushNotificationsEventEmitterQueue", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = [];
    f["default"] = a
}), 66);
__d("PushNotificationsEventEmitter", ["BaseEventEmitter", "PushNotificationsEventEmitterQueue"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = new(c("BaseEventEmitter"))();
    b = a;
    a.once("openInstallPush", function() {
        for (var a = arguments.length, b = new Array(a), d = 0; d < a; d++) b[d] = arguments[d];
        c("PushNotificationsEventEmitterQueue").push({
            args: b,
            type: "openInstallPush"
        })
    });
    g["default"] = b
}), 98);
__d("useCometNUXTourTarget", ["BaseContextualLayerAnchorRootContext", "CometNUXTourConsumerContext", "react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useEffect,
        j = b.useRef;

    function a(a) {
        var b = a.contextualLayerOptions,
            d = b === void 0 ? null : b,
            e = a.description,
            f = a.image;
        b = a.isTargetFixed;
        var g = b === void 0 ? !1 : b,
            k = a.targetKey,
            l = a.title;
        b = a.withArrow;
        var m = b === void 0 ? !0 : b,
            n = j(null),
            o = h(c("CometNUXTourConsumerContext")),
            p = h(c("BaseContextualLayerAnchorRootContext")),
            q = j({
                hasAnsweredSurvey: !1
            });
        i(function() {
            if (o == null) return;
            var a = o.registerTarget,
                b = o.unregisterTarget;
            a(k, {
                anchorRootRef: p,
                contextRef: n,
                contextualLayerOptions: (a = d) != null ? a : {},
                description: e,
                image: f,
                isTargetFixed: g,
                key: k,
                storageRef: q,
                title: l,
                withArrow: m
            });
            return function() {
                b(k)
            }
        }, [p, o, d, e, f, k, l]);
        o == null && c("recoverableViolation")("Unable to register nux tour targets", "comet_ui");
        return n
    }
    g["default"] = a
}), 98);
__d("CometContextualLayer.react", ["BaseContextualLayer.react", "react", "useCometVisualChangeTracker", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = c("useCometVisualChangeTracker")();
        b = c("useMergeRefs")(b, d);
        return h.jsx(c("BaseContextualLayer.react"), babelHelpers["extends"]({}, a, {
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometNullState.react", ["CometIcon.react", "FlightSerializableIcon", "IconSource", "TetraTextPairing.react", "react", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var e = a.action,
            f = a.body;
        f = f === void 0 ? null : f;
        var g = a.bodyColor;
        g = g === void 0 ? "secondary" : g;
        var i = a.headline,
            j = a.headlineColor;
        j = j === void 0 ? "secondary" : j;
        var k = a.icon,
            l = a.iconColor,
            m = a.small;
        m = m === void 0 ? !1 : m;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["action", "body", "bodyColor", "headline", "headlineColor", "icon", "iconColor", "small"]);
        var n = c("useCurrentDisplayMode")();
        n = n === "dark";
        m = m ? 4 : 2;
        k = d("FlightSerializableIcon").parseFlightIcon(k);
        l = k != null ? k instanceof c("IconSource") ? h.jsx(c("CometIcon.react"), {
            color: l,
            icon: k
        }) : h.jsx(c("CometIcon.react"), {
            icon: n && k.dark != null ? k.dark : k["default"]
        }) : null;
        return h.jsxs("div", babelHelpers["extends"]({
            className: "xbbxn1n xwxc41k xxbr6pl x1p5oq8j xl56j7k xdt5ytf x78zum5 x6s0dn4"
        }, a, {
            ref: b,
            children: [h.jsx("div", {
                className: "xieb3on",
                children: l
            }), h.jsx(c("TetraTextPairing.react"), {
                body: f,
                bodyColor: g,
                headline: i,
                headlineColor: j,
                level: m,
                textAlign: "center"
            }), e != null ? h.jsx("div", {
                className: "xqui205",
                children: e
            }) : null]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("TetraNullState.react", ["CometNullState.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("CometNullState.react"), babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("NullState404FailedLoading", ["cr:2306"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:2306")
}), 98);
__d("NullStateGeneral", ["cr:3211"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:3211")
}), 98);
__d("NullStatePermissions", ["cr:3587"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:3587")
}), 98);
__d("BaseListCell.react", ["BaseRow.react", "BaseRowItem.react", "BaseView.react", "CometCompositeStructureContext", "Locale", "getItemRoleFromCompositeRole", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            bottomAddOn: {
                display: "x78zum5",
                flexDirection: "xdt5ytf"
            },
            bottomAddOnResponsive: {
                flexGrow: "x1iyjqo2"
            },
            item: {
                display: "x78zum5"
            },
            root: {
                alignItems: "x1qjc9v5",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                justifyContent: "xl56j7k",
                minWidth: "xeuugli"
            },
            textContent: {
                flexGrow: "x1iyjqo2"
            },
            textContentContainer: {
                flexBasis: "xdl72j9"
            },
            textWithResponsiveAddOnBottom: {
                flexBasis: "x4pfjvb",
                maxWidth: "x193iq5w",
                minWidth: "x1mkiy5m"
            }
        };

    function a(a, b) {
        var d = a.addOnBottom,
            e = a.addOnBottomResponsive;
        e = e === void 0 ? !1 : e;
        var f = a.addOnEnd,
            g = a.addOnEndVerticalAlign,
            k = a.addOnFooter,
            l = a.addOnStart,
            m = a.addOnStartVerticalAlign,
            n = a.addOnStartXStyle,
            o = a["aria-hidden"];
        o = o === void 0 ? !1 : o;
        var p = a.content,
            q = a.contentId,
            r = a.nestedSpacing,
            s = a.testid;
        s = a.verticalAlign;
        s = s === void 0 ? "center" : s;
        a = a.xstyle;
        var t = c("Locale").isRTL();
        t = r != null ? t ? {
            marginRight: r
        } : {
            marginLeft: r
        } : void 0;
        r = i(c("CometCompositeStructureContext"));
        r = r.role;
        r = c("getItemRoleFromCompositeRole")(r);
        return h.jsxs(c("BaseView.react"), {
            "aria-hidden": o ? !0 : void 0,
            ref: b,
            role: (o = r) != null ? o : void 0,
            testid: void 0,
            xstyle: [j.root, a],
            children: [h.jsxs(c("BaseRow.react"), {
                verticalAlign: s,
                children: [t != null && h.jsx(c("BaseRowItem.react"), {
                    children: h.jsx("div", {
                        style: t
                    })
                }), l != null && h.jsx(c("BaseRowItem.react"), {
                    verticalAlign: m,
                    xstyle: [j.item, n],
                    children: l
                }), h.jsxs(c("BaseRow.react"), {
                    expanding: !0,
                    verticalAlign: "center",
                    wrap: "forward",
                    xstyle: j.textContentContainer,
                    children: [h.jsx(c("BaseRowItem.react"), {
                        xstyle: [j.textContent, e && j.textWithResponsiveAddOnBottom],
                        children: q != null ? h.jsx("div", {
                            "aria-hidden": !0,
                            id: q,
                            children: p
                        }) : p
                    }), d != null && h.jsx(c("BaseRowItem.react"), {
                        xstyle: [j.bottomAddOn, e && j.bottomAddOnResponsive],
                        children: d
                    })]
                }), f != null && h.jsx(c("BaseRowItem.react"), {
                    verticalAlign: g,
                    xstyle: j.item,
                    children: f
                })]
            }), k != null && k]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseBaseMultiStepContainer.react", ["BaseMultiPageViewContext", "BaseView.react", "FocusRegion.react", "HiddenSubtreeContextProvider.react", "Locale", "emptyFunction", "focusScopeQueries", "mergeRefs", "react", "recoverableViolation", "stylex", "testID", "useDebouncedComet", "useDynamicCallbackDANGEROUS", "usePrevious", "useResizeObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useRef,
        m = b.useState,
        n = d("Locale").isRTL(),
        o = {
            page: {
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                transitionDuration: "x1k90msu",
                transitionProperty: "x6o7n8i",
                transitionTimingFunction: "x1qfuztq"
            },
            pageAbsolute: {
                position: "x10l6tqk",
                start: "x17qophe"
            },
            pageFullWidth: {
                width: "xh8yej3"
            },
            pageHidden: {
                visibility: "xlshs6z"
            },
            pageVisible: {
                opacity: "x1hc1fzr",
                pointerEvents: "x71s49j"
            },
            root: {
                height: "xt7dq6l",
                outline: "x1a2a7pz",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x1n2onr6",
                width: "x14atkfc"
            },
            rootWithAnimations: {
                transform: "xzhk7wv",
                transitionDuration: "x1k90msu",
                transitionProperty: "x1xw1sup",
                transitionTimingFunction: "x1qfuztq"
            }
        },
        p = {
            bottom: {
                bottom: "x1ey2m1c"
            },
            top: {
                top: "x13vifvy"
            }
        };

    function q(a) {
        var b = a.children,
            d = a.currentPageComponent,
            e = a.fallback,
            f = a.popPage,
            g = a.pushPage;
        a = k(function() {
            return d != null ? {
                fallback: e,
                popPage: function(a) {
                    f(d, a)
                },
                pushPage: g
            } : {
                fallback: e,
                pushPage: g
            }
        }, [d, e, f, g]);
        return h.jsx(c("BaseMultiPageViewContext").Provider, {
            value: a,
            children: b
        })
    }
    q.displayName = q.name + " [from " + f.id + "]";

    function a(a, b) {
        var e = a.align,
            f = e === void 0 ? "top" : e;
        e = a.children;
        var g = a.disableFocusContainment,
            r = g === void 0 ? !1 : g;
        g = a.disableInitialAutoFocus;
        g = g === void 0 ? !1 : g;
        var s = a.fallback,
            t = a.fitContentWidth,
            u = t === void 0 ? !1 : t;
        t = a.onPageChange;
        t = t === void 0 ? c("emptyFunction") : t;
        var v = a.pageCursor,
            w = a.pageComponents,
            x = a.setPopPageState,
            y = a.setPushPageState;
        a = m(!1);
        var z = a[0],
            A = a[1],
            B = l(null);
        a = m(!1);
        var C = a[0],
            D = a[1],
            E = i(function(a, b) {
                var c = B.current;
                c != null && (c.style.setProperty("height", a + "px"), u ? c.style.setProperty("width", b + "px") : c.style.removeProperty("width"), D(!0))
            }, [u]);
        a = i(function(a) {
            return E(a.height, a.width)
        }, [E]);
        var F = c("useResizeObserver")(a),
            G = i(function(a) {
                a != null && E(a.clientHeight, a.clientWidth), F(a)
            }, [F, E]),
            H = c("useDebouncedComet")(function(a) {
                window.requestAnimationFrame(function() {
                    A(!0), y(a)
                })
            }, {
                leading: !0,
                wait: 350
            }),
            I = i(function(a, b) {
                window.requestAnimationFrame(function() {
                    var d = w.indexOf(a),
                        e = b == null ? void 0 : b.index;
                    if (e != null && e > d) {
                        c("recoverableViolation")("Attempting to return to page with index " + e + ", which does not  exist. Please provide an index less than " + d + " and greater than or equal to 0.", "BaseMultiStepContainer");
                        return
                    }
                    e = (e = e) != null ? e : d;
                    if (e < 0) {
                        c("recoverableViolation")("Attempting to close a page that does not exist anymore.", "BaseMultiStepContainer");
                        return
                    }
                    A(!0);
                    x(e)
                })
            }, [w, x]),
            J = c("useDynamicCallbackDANGEROUS")(t);
        j(function() {
            J && J(v)
        }, [J, v]);
        a = i(function() {
            return A(!1)
        }, []);
        t = i(function(a) {
            a.currentTarget.scrollLeft = 0, a.currentTarget.scrollTop = 0
        }, []);
        var K = k(function() {
                return c("mergeRefs")(B, b)
            }, [b]),
            L = c("usePrevious")(v);
        return h.jsx(d("FocusRegion.react").FocusRegion, {
            autoRestoreFocus: !0,
            recoverFocusQuery: d("focusScopeQueries").tabbableScopeQuery,
            children: h.jsx("div", babelHelpers["extends"]({}, c("testID")("BaseMultiStepContainer"), {
                className: c("stylex")(o.root, z && o.rootWithAnimations),
                onScroll: t,
                onTransitionEnd: a,
                ref: K,
                children: [h.jsx(c("BaseView.react"), {
                    "aria-hidden": v !== 0 ? !0 : void 0,
                    ref: v === 0 ? G : null,
                    style: {
                        transform: "translateX(" + (n ? 1 : -1) * v + "00%) translateZ(1px)"
                    },
                    testid: void 0,
                    xstyle: [o.page, C && o.pageAbsolute, p[f], v === 0 ? o.pageVisible : !z && o.pageHidden, !u && o.pageFullWidth],
                    children: h.jsx(d("FocusRegion.react").FocusRegion, {
                        autoFocusQuery: v === 0 && (!g || L === 1) ? d("focusScopeQueries").tabbableScopeQuery : null,
                        containFocusQuery: r ? null : d("focusScopeQueries").tabbableScopeQuery,
                        children: h.jsx(c("HiddenSubtreeContextProvider.react"), {
                            isHidden: v !== 0,
                            children: h.jsx(q, {
                                fallback: s,
                                popPage: I,
                                pushPage: H,
                                children: typeof e === "function" ? e(H) : e
                            })
                        })
                    })
                }, 0)].concat(w.map(function(a, b) {
                    return h.jsx(c("BaseView.react"), {
                        "aria-hidden": v !== b + 1 ? !0 : void 0,
                        ref: v === b + 1 ? G : null,
                        style: {
                            transform: "translateX(" + (n ? 1 : -1) * (v - b - 1) + "00%) translateZ(1px)"
                        },
                        xstyle: [o.page, o.pageAbsolute, p[f], v === b + 1 ? o.pageVisible : !z && o.pageHidden, !u && o.pageFullWidth],
                        children: h.jsx(d("FocusRegion.react").FocusRegion, {
                            autoFocusQuery: v === b + 1 ? d("focusScopeQueries").tabbableScopeQuery : null,
                            containFocusQuery: r ? null : d("focusScopeQueries").tabbableScopeQuery,
                            children: h.jsx(c("HiddenSubtreeContextProvider.react"), {
                                isHidden: v !== b + 1,
                                children: h.jsx(q, {
                                    currentPageComponent: a,
                                    fallback: s,
                                    popPage: I,
                                    pushPage: H,
                                    children: h.jsx(a, {
                                        onReturn: function(b) {
                                            return I(a, b)
                                        }
                                    })
                                })
                            })
                        })
                    }, b + 1)
                }), [h.jsx(c("BaseView.react"), {
                    "aria-hidden": !0,
                    style: {
                        transform: "translateX(" + (n ? 1 : -1) * (v - w.length - 1) + "00%) translateZ(1px)"
                    },
                    xstyle: [o.page, o.pageAbsolute, !u && o.pageFullWidth]
                }, w.length + 1)])
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometCardedDialogLoadingStateGlimmer.react", ["BaseGlimmer.react", "BaseLoadingStateElement.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            bodyGlimmer: {
                borderTopStartRadius: "x1rcc7c0",
                borderTopEndRadius: "xbtbmw4",
                borderBottomEndRadius: "x1lie4ck",
                borderBottomStartRadius: "x16hxpj1",
                height: "x1v9usgg",
                marginBottom: "x1u7kmwd"
            },
            bodyGlimmerContainer: {
                paddingTop: "x1cnzs8",
                paddingEnd: "xc73u3c",
                paddingBottom: "x1gwgq1z",
                paddingStart: "x5ib6vp"
            },
            bodyGlimmerFirst: {
                width: "xktia5q"
            },
            bodyGlimmerSecond: {
                width: "xz84dc7"
            },
            header: {
                alignItems: "x6s0dn4",
                borderBottom: "xua58t2",
                display: "x78zum5",
                height: "xng8ra",
                justifyContent: "xl56j7k",
                textAlign: "x2b8uid"
            },
            headerGlimmer: {
                borderTopStartRadius: "x1rcc7c0",
                borderTopEndRadius: "xbtbmw4",
                borderBottomEndRadius: "x1lie4ck",
                borderBottomStartRadius: "x16hxpj1",
                height: "x1v9usgg",
                width: "x1exxlbk"
            }
        };

    function a(a) {
        var b = a.bodyGlimmerContainerXStyle;
        b = b === void 0 ? null : b;
        a = a.withHeader;
        a = a === void 0 ? !1 : a;
        return h.jsxs(c("BaseLoadingStateElement.react"), {
            children: [a && h.jsx("div", {
                className: c("stylex")(i.header),
                children: h.jsx(c("BaseGlimmer.react"), {
                    className: c("stylex")(i.headerGlimmer),
                    index: 0
                })
            }), h.jsxs("div", {
                className: c("stylex")(i.bodyGlimmerContainer, b),
                children: [h.jsx(c("BaseGlimmer.react"), {
                    className: c("stylex")(i.bodyGlimmer, i.bodyGlimmerFirst),
                    index: 1
                }), h.jsx(c("BaseGlimmer.react"), {
                    className: c("stylex")(i.bodyGlimmer, i.bodyGlimmerSecond),
                    index: 2
                })]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometCardedDialogLoadingStateLegacy.react", ["CometCardedDialogLegacy.react", "CometCardedDialogLoadingStateGlimmer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx("div", {
            "aria-busy": !0,
            className: "x1ojsi0c xmqsq3q x4b6v7d",
            children: h.jsx(c("CometCardedDialogLegacy.react"), babelHelpers["extends"]({}, a, {
                children: h.jsx(c("CometCardedDialogLoadingStateGlimmer.react"), {
                    withHeader: a.title == null
                })
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometControlledUserBlockingDialog.react", ["BaseModal.react", "CometCardedDialogLegacy.react", "CometCardedDialogLoadingStateLegacy.react", "CometPlaceholder.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children,
            d = a.disableClosingWithMask,
            e = a.labelledBy,
            f = a.onDismiss;
        f = f === void 0 ? c("emptyFunction") : f;
        var g = a.disableHeaderDivider;
        g = g === void 0 ? !1 : g;
        var i = a.title,
            j = a.withCloseButton;
        a = a.size;
        a = a === void 0 ? "small" : a;
        return h.jsx(c("BaseModal.react"), {
            blockKeyCommands: !0,
            stackingBehavior: "above-everything",
            children: h.jsx(c("CometPlaceholder.react"), {
                fallback: h.jsx(c("CometCardedDialogLoadingStateLegacy.react"), {
                    onClose: f
                }),
                children: h.jsx(c("CometCardedDialogLegacy.react"), {
                    disableClosingWithMask: d,
                    disableHeaderDivider: g,
                    labelledBy: e,
                    onClose: f,
                    size: a,
                    title: i,
                    withCloseButton: j,
                    children: b
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometAlertDialog", ["CometDialogLoadingState.react", "react", "requireDeferred", "useCometDeferredDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useCallback,
        j = c("requireDeferred")("CometAlertDialogImpl.react").__setRef("useCometAlertDialog");

    function k() {
        return h.jsx(c("CometDialogLoadingState.react"), {})
    }
    k.displayName = k.name + " [from " + f.id + "]";

    function a() {
        var a = c("useCometDeferredDialog")(j, k);
        return i(function(b, c) {
            c === void 0 && (c = function() {}), a(b, c)
        }, [a])
    }
    g["default"] = a
}), 98);
__d("ArrowLeftFilled20.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            fill: "currentColor",
            viewBox: "0 0 20 20",
            width: "1em",
            height: "1em"
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("g", {
                fillRule: "evenodd",
                transform: "translate(-446 -350)",
                children: h.jsxs("g", {
                    fillRule: "nonzero",
                    children: [h.jsx("path", {
                        d: "M100.249 201.999a1 1 0 0 0-1.415-1.415l-5.208 5.209a1 1 0 0 0 0 1.414l5.208 5.209A1 1 0 0 0 100.25 211l-4.501-4.501 4.5-4.501z",
                        transform: "translate(355 153.5)"
                    }), h.jsx("path", {
                        d: "M107.666 205.5H94.855a1 1 0 1 0 0 2h12.813a1 1 0 1 0 0-2z",
                        transform: "translate(355 153.5)"
                    })]
                })
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("ArrowLeftFilled20IconSvg.react", ["ArrowLeftFilled20.svg.react", "SVGIcon"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("SVGIcon").svgIcon(c("ArrowLeftFilled20.svg.react"));
    g["default"] = a
}), 98);
__d("ArrowRightFilled20.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            fill: "currentColor",
            viewBox: "0 0 20 20",
            width: "1em",
            height: "1em"
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("g", {
                fillRule: "evenodd",
                transform: "translate(-446 -350)",
                children: h.jsxs("g", {
                    fillRule: "nonzero",
                    children: [h.jsx("path", {
                        d: "M101.751 211.001a1 1 0 0 0 1.415 1.415l5.208-5.209a1 1 0 0 0 0-1.414l-5.208-5.209A1 1 0 0 0 101.75 202l4.501 4.501-4.5 4.501z",
                        transform: "translate(355 153.5)"
                    }), h.jsx("path", {
                        d: "M94.334 207.5h12.812a1 1 0 1 0 0-2H94.333a1 1 0 1 0 0 2z",
                        transform: "translate(355 153.5)"
                    })]
                })
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("ArrowRightFilled20IconSvg.react", ["ArrowRightFilled20.svg.react", "SVGIcon"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("SVGIcon").svgIcon(c("ArrowRightFilled20.svg.react"));
    g["default"] = a
}), 98);
__d("CometTooltipGroup.react", ["BaseTooltipGroup.react", "CometTooltipImpl.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(d("BaseTooltipGroup.react").Container, babelHelpers["extends"]({}, a, {
            tooltipImpl: c("CometTooltipImpl.react")
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSuspendWhileWaitingOnDOM.react", ["CometSSRClientRender", "CometSSRReactFizzEnvironment", "ExecutionEnvironment", "Promise", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.children;
        if (!c("ExecutionEnvironment").canUseDOM)
            if (d("CometSSRReactFizzEnvironment").isReactFizzEnvironment()) throw d("CometSSRClientRender").CometSSRClientRender();
            else throw b("Promise").reject();
        return h.jsx(h.Fragment, {
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDOMOnlyBoundary.react", ["CometPlaceholder.react", "CometSuspendWhileWaitingOnDOM.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children;
        a = a.fallback;
        return h.jsx(c("CometPlaceholder.react"), {
            fallback: a,
            children: h.jsx(c("CometSuspendWhileWaitingOnDOM.react"), {
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometProductAttributionContextProvider.react", ["CometProductAttributionContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.children,
            d = a.value,
            e = i(c("CometProductAttributionContext"));
        a = j(function() {
            return e != null && e.length > 0 ? [].concat(e, [d]) : [d]
        }, [d, e]);
        return h.jsx(c("CometProductAttributionContext").Provider, {
            value: a,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometPassiveGetRouterStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useTopNavigationLogging", ["CometPassiveGetRouterStateContext", "CometProductAttribution", "WebSession", "react", "requireDeferred", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    var h = a.useCallback,
        i = a.useContext,
        j = a.useMemo,
        k = c("requireDeferred")("CometTopnavItemClickFalcoEvent").__setRef("useTopNavigationLogging"),
        l = c("requireDeferred")("CometTopnavItemImpressionFalcoEvent").__setRef("useTopNavigationLogging"),
        m = function(a) {
            var b = a.badgeValue;
            b = b === void 0 ? "" : b;
            var c = a.itemKey,
                e = a.navItemType,
                f = a.passiveGetRouterState,
                g = a.position;
            g = g === void 0 ? 0 : g;
            a = a.selected;
            a = a === void 0 ? !1 : a;
            return {
                bt: "number",
                bv: b,
                nii: null,
                nin: c,
                nip: g,
                nit: e,
                pa: d("CometProductAttribution").getMinifiedTopMostRouteProductAttribution(f),
                sel: a,
                si: d("WebSession").getId()
            }
        },
        n = function(a) {
            return h(function() {
                k.onReady(function(b) {
                    b.log(function() {
                        return m(a)
                    })
                })
            }, [a])
        },
        o = function(a) {
            var b = h(function() {
                l.onReady(function(b) {
                    b.log(function() {
                        return m(a)
                    })
                })
            }, [a]);
            return c("useVisibilityObserver")({
                onVisible: b
            })
        },
        p = function(a) {
            var b = a.badgeValue,
                d = b === void 0 ? "" : b,
                e = a.itemKey,
                f = a.navItemType,
                g = a.position;
            b = a.selected;
            var h = b === void 0 ? !1 : b,
                k = i(c("CometPassiveGetRouterStateContext"));
            a = j(function() {
                return {
                    badgeValue: d,
                    itemKey: e,
                    navItemType: f,
                    passiveGetRouterState: k,
                    position: g,
                    selected: h
                }
            }, [k, d, e, f, g, h]);
            return [n(a), o(a)]
        };
    b = function() {
        return p({
            itemKey: "logo",
            navItemType: "logo"
        })
    };
    e = function() {
        return p({
            itemKey: "create-button",
            navItemType: "create"
        })
    };
    f = function() {
        return p({
            itemKey: "mega-menu-jewel",
            navItemType: "mega_menu"
        })
    };
    a = function(a, b) {
        return p({
            itemKey: a,
            navItemType: "create",
            position: b
        })
    };
    var q = function() {
            return p({
                itemKey: "settings-button",
                navItemType: "jewel"
            })
        },
        r = function() {
            return p({
                itemKey: "home-link",
                navItemType: "topnav-link"
            })
        },
        s = function() {
            return p({
                itemKey: "profile-link",
                navItemType: "topnav-link"
            })
        },
        t = function() {
            return p({
                itemKey: "find-friends",
                navItemType: "topnav-link"
            })
        },
        u = function(a, b, c) {
            return p({
                itemKey: a,
                navItemType: "settings",
                position: b,
                selected: c
            })
        },
        v = function() {
            return p({
                itemKey: "messenger-jewel",
                navItemType: "jewel"
            })
        },
        w = function() {
            return p({
                itemKey: "friends-jewel",
                navItemType: "jewel"
            })
        },
        x = function(a) {
            return p({
                badgeValue: a,
                itemKey: "notifications-jewel",
                navItemType: "jewel"
            })
        },
        y = function() {
            return p({
                itemKey: "birthdays",
                navItemType: "birthdays"
            })
        },
        z = function() {
            return p({
                itemKey: "inline-friends-rhc",
                navItemType: "inline_friends_rhc"
            })
        },
        A = function() {
            return p({
                itemKey: "pages-rhc",
                navItemType: "pages_rhc"
            })
        },
        B = function() {
            return p({
                itemKey: "friends-count-rhc",
                navItemType: "friend_count_rhc"
            })
        },
        C = function() {
            return p({
                itemKey: "event",
                navItemType: "events"
            })
        },
        D = function() {
            return p({
                itemKey: "live-video-rhc",
                navItemType: "live_video_rhc"
            })
        },
        E = function() {
            return p({
                itemKey: "watch-video-rhc",
                navItemType: "watch_video_rhc"
            })
        };
    g.useLogoLoggingCallbacks = b;
    g.useCreateButtonLoggingCallbacks = e;
    g.useMegaMenuLoggingCallbacks = f;
    g.useCreateItemLoggingCallbacks = a;
    g.useSettingsButtonLoggingCallbacks = q;
    g.useHomeLinkLoggingCallbacks = r;
    g.useProfileLinkLoggingCallbacks = s;
    g.useFindFriendsLinkLoggingCallbacks = t;
    g.useSettingsItemLoggingCallbacks = u;
    g.useMessengerButtonLoggingCallbacks = v;
    g.useFriendsButtonLoggingCallbacks = w;
    g.useNotificationsButtonLoggingCallbacks = x;
    g.useBirthdaysButtonLoggingCallbacks = y;
    g.useInlineFriendRequestsRHCLoggingCallbacks = z;
    g.usePagesRHCLoggingCallbacks = A;
    g.useFriendRequestsCountRHCLoggingCallbacks = B;
    g.useEventsButtonLoggingCallbacks = C;
    g.useLiveVideoRHCLoggingCallbacks = D;
    g.useWatchVideoRHCLoggingCallbacks = E
}), 98);
__d("PagesCometBusinessSuiteRedirectDialogUtils", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a;
        return (a = c("qex")._("743")) != null ? a : !1
    }
    g.isInBizWebRedirectModalQe = a
}), 98);
__d("useBusinessSuiteRedirectHook", ["JSResourceForInteraction", "useCometLazyDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        var a = c("JSResourceForInteraction")("PagesCometBusinessSuiteRedirectDialog.react").__setRef("useBusinessSuiteRedirectHook");
        a = c("useCometLazyDialog")(a);
        a = a[0];
        return a
    };
    b = a;
    g["default"] = b
}), 98);
__d("useQuickPromotionFalcoEvent", ["react", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback,
        i = c("requireDeferred")("QpActionFalcoEvent").__setRef("useQuickPromotionFalcoEvent"),
        j = c("requireDeferred")("QpImpressionFalcoEvent").__setRef("useQuickPromotionFalcoEvent");

    function a(a) {
        var b = a.context_surface_id;
        a = a.context_trigger;
        var c = a === void 0 ? "newsfeed" : a,
            d = function(a) {
                return a instanceof Map ? Object.fromEntries(a) : Object.entries((a = a) != null ? a : {}).reduce(function(a, b) {
                    var c = b[0];
                    b = b[1];
                    a[c] = b;
                    return a
                }, {})
            };
        a = h(function(a, e, f, g) {
            if (e == null || f == null) return;
            var h = "" + b,
                j = d(g);
            i.onReady(function(b) {
                b = b.log;
                b(function() {
                    return {
                        action_type: a,
                        context_surface_id: h,
                        context_trigger: c,
                        extra_client_data: j,
                        instance_log_data: f,
                        promotion_id: e
                    }
                })
            })
        }, [b, c]);
        var e = h(function(a, e, f) {
            if (a == null || e == null) return;
            var g = "" + b,
                h = d(f);
            j.onReady(function(b) {
                b = b.log;
                b(function() {
                    return {
                        context_surface_id: g,
                        context_trigger: c,
                        extra_client_data: h,
                        instance_log_data: e,
                        promotion_id: a
                    }
                })
            })
        }, [b, c]);
        return {
            logAction: a,
            logImpression: e
        }
    }
    g["default"] = a
}), 98);
__d("MessageRequestsBulkActionsContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        bulkActionsSelectedThreads: new Set(),
        bulkActionsUnreadSelectedThreads: new Set(),
        isBulkActionsEditMode: !1,
        setBulkActionsSelectedThreads: function() {},
        setBulkActionsUnreadSelectedThreads: function() {},
        setIsBulkActionsEditMode: function() {}
    });
    g["default"] = b
}), 98);
__d("MWChatLoadingDelay.react", ["MWChatLoadingDelayImpl.re", "RunComet", "cr:758", "qex", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = function(a) {
            var c = a.children,
                e = a.loadingDelayInterruptMs;
            d("RunComet").onAfterLoad(function() {
                e > 0 ? b("cr:758") != null && b("cr:758")(j, e) : j()
            });
            return h.jsx(d("MWChatLoadingDelayImpl.re").make, {
                children: c
            })
        };
    a = function() {};
    e = function(a) {
        var b;
        a = a.children;
        b = (b = c("qex")._("161")) != null ? b : -1;
        return b < 0 ? h.jsx(d("MWChatLoadingDelayImpl.re").make, {
            children: a
        }) : h.jsx(i, {
            loadingDelayInterruptMs: b,
            children: a
        })
    };
    var j = (f = d("MWChatLoadingDelayImpl.re").interrupt) != null ? f : a;
    g.MWChatLoadingDelay = e;
    g.interrupt = j
}), 98);
__d("MWChatEncryptedBackupsUpsellChatTabVisibilityContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    a = d("react");
    b = a.createContext;
    var i = a.useContext,
        j = a.useMemo,
        k = a.useState,
        l = b({
            enabledState: [!1, c("emptyFunction")],
            openState: [!1, c("emptyFunction")]
        });
    e = function(a) {
        a = a.children;
        var b = k(!1),
            c = k(!1);
        return h.jsx(l.Provider, {
            value: j(function() {
                return {
                    enabledState: c,
                    openState: b
                }
            }, [b, c]),
            children: a
        })
    };
    f = function() {
        var a = i(l);
        a = a.enabledState;
        return a
    };
    d = function() {
        var a = i(l);
        a = a.openState;
        return a
    };
    g.MWChatEncryptedBackupsUpsellChatTabVisibilityContextProvider = e;
    g.useMWChatEncryptedBackupsUpsellChatTabEnabled = f;
    g.useMWChatEncryptedBackupsUpsellChatTabOpen = d
}), 98);
__d("LsSystemFolderInterop.bs", ["LsSystemFolder.bs"], (function(a, b, c, d, e, f) {
    "use strict";
    c = (a = b("LsSystemFolder.bs")).inbox;
    d = a.mplace;
    e = a.community;
    b = a.other;
    var g = a.pending,
        h = a.jobs;
    a = a.archived;
    f.inbox = c;
    f.mplace = d;
    f.community = e;
    f.other = b;
    f.pending = g;
    f.jobs = h;
    f.archived = a
}), null);
__d("LsSystemFolderInterop.re", ["LsSystemFolderInterop.bs"], (function(a, b, c, d, e, f) {
    c = (a = b("LsSystemFolderInterop.bs")).inbox;
    f.inbox = c;
    d = a.mplace;
    f.mplace = d;
    e = a.community;
    f.community = e;
    b = a.other;
    f.other = b;
    c = a.pending;
    f.pending = c;
    d = a.jobs;
    f.jobs = d;
    e = a.archived;
    f.archived = e
}), null);
__d("MWCMJewelContext", ["LsSystemFolderInterop.re", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        selectedFolderTab: d("LsSystemFolderInterop.re").inbox,
        setSelectedFolderTab: null
    });
    g["default"] = b
}), 98);
__d("MWJewelPopoverDialogContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        isOpenForDialog: !1,
        setIsOpenForDialog: function() {}
    });
    g["default"] = b
}), 98);
__d("PresenceStatusContext", ["emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    var h = [];
    b = a.createContext({
        addListener: function() {
            return c("emptyFunction")
        },
        get: function() {
            return 0
        },
        getChatVisibility: function() {
            return !1
        },
        getOnlineIDs: function() {
            return h
        },
        getStatus: function() {
            return null
        }
    });
    g["default"] = b
}), 98);
__d("MAWMessengerStatusOnFacebookEventEmitter", ["BaseEventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "messengerisActiveOnFacebook",
        i = "messengerStatusOnFacebook",
        j = new(c("BaseEventEmitter"))();

    function a() {
        j.emit(i, h)
    }

    function b(a) {
        var b = j.addListener(i, a);
        return function() {
            return b.remove()
        }
    }
    g.MESSENGER_IS_ACTIVE_ON_FACEBOOK = h;
    g.markMessegnerIsActiveOnFacebook = a;
    g.subscribe = b
}), 98);
__d("RTWebCallWindowControllerLoader", ["FBLogger", "JSResourceForInteraction", "Promise", "regeneratorRuntime", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("RTWebCallWindowOpener").__setRef("RTWebCallWindowControllerLoader"),
        i = c("requireDeferred")("ZenonCallWindowController").__setRef("RTWebCallWindowControllerLoader"),
        j = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a() {
                return b.apply(this, arguments) || this
            }
            return a
        }(babelHelpers.wrapNativeSuper(Error));
    a = function() {
        function a(a, b) {
            this.$1 = null, this.$2 = a, this.$3 = b
        }
        var d = a.prototype;
        d.init = function() {
            var a, d, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        f.prev = 0;
                        f.next = 3;
                        return b("regeneratorRuntime").awrap(b("Promise").all([i.load(), h.load()]));
                    case 3:
                        a = f.sent;
                        d = a[0];
                        e = a[1];
                        this.$1 = new d(this.$2, {
                            callWindowInitializerResource: this.$3,
                            callWindowOpener: new e(),
                            uriBuilderResource: c("JSResourceForInteraction")("ZenonUriBuilder").__setRef("RTWebCallWindowControllerLoader")
                        });
                        f.next = 12;
                        break;
                    case 9:
                        f.prev = 9, f.t0 = f["catch"](0), c("FBLogger")("rtc_www").catching(f.t0).warn("Failed to initialize call window controller");
                    case 12:
                    case "end":
                        return f.stop()
                }
            }, null, this, [
                [0, 9]
            ])
        };
        d.initCall = function(a) {
            if (this.$1) return this.$1.initCall(a);
            else throw new j()
        };
        return a
    }();
    a.ResourceNotReadyError = j;
    g["default"] = a
}), 98);
__d("RTWebIncomingRingConfiguration", ["UserAgent", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return (c("gkx")("1582") ? c("UserAgent").isBrowser("Chrome >= 69") : c("UserAgent").isBrowser("Chrome >= 49")) || c("UserAgent").isBrowser("Edge (Chromium Based) >= 74.1") || c("UserAgent").isBrowser("Opera >= 58") || c("UserAgent").isBrowser("Firefox >= 59") || c("UserAgent").isBrowser("Safari >= 14") && c("gkx")("1451") || c("UserAgent").isBrowser("Oculus Browser >= 6") && c("gkx")("1188589")
    }

    function b() {
        return c("gkx")("5709") && (c("UserAgent").isBrowser("Chrome >= 86") || c("UserAgent").isBrowser("Edge (Chromium Based) >= 86"))
    }
    g.isSupportedClientForProtocol = a;
    g.isE2EESupportedClient = b
}), 98);
__d("RTWebPreCallContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react").createContext;
    b = a(null);
    g["default"] = b
}), 98);
__d("ZenonCallInviteModelLoader", ["BaseEventEmitter", "Promise", "emptyFunction", "regeneratorRuntime", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("ZenonCallInviteModel").__setRef("ZenonCallInviteModelLoader"),
        i = c("requireDeferred")("delegateZenonCallInviteModel").__setRef("ZenonCallInviteModelLoader");
    a = function(a) {
        babelHelpers.inheritsLoose(d, a);

        function d(b) {
            var d;
            d = a.call(this) || this;
            d.$ZenonCallInviteModelLoader1 = null;
            d.getCurrentInvite = function() {
                return null
            };
            d.startListening = function(a) {
                this.$ZenonCallInviteModelLoader1 = a
            };
            d.stopListening = function() {
                this.$ZenonCallInviteModelLoader1 = null
            };
            d.dismiss = c("emptyFunction");
            d.accept = c("emptyFunction");
            d.decline = c("emptyFunction");
            d.$ZenonCallInviteModelLoader2 = b;
            return d
        }
        var e = d.prototype;
        e.init = function() {
            var a, c, d, e;
            return b("regeneratorRuntime").async(function(f) {
                while (1) switch (f.prev = f.next) {
                    case 0:
                        f.next = 2;
                        return b("regeneratorRuntime").awrap(b("Promise").all([h.load(), i.load()]));
                    case 2:
                        a = f.sent, c = a[0], d = a[1], e = new c(this.$ZenonCallInviteModelLoader2), d(this, e), this.$ZenonCallInviteModelLoader1 !== null && e.startListening(this.$ZenonCallInviteModelLoader1);
                    case 8:
                    case "end":
                        return f.stop()
                }
            }, null, this)
        };
        return d
    }(c("BaseEventEmitter"));
    g["default"] = a
}), 98);
__d("CometTypeaheadBackButton.react", ["fbt", "ArrowLeftFilled20IconSvg.react", "ArrowRightFilled20IconSvg.react", "CometVisualCompletionAttributes", "Locale", "TetraIcon.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.onPress;
        b = b === void 0 ? c("emptyFunction") : b;
        a = a.testid;
        a = d("Locale").isRTL() ? c("ArrowRightFilled20IconSvg.react") : c("ArrowLeftFilled20IconSvg.react");
        return i.jsx("div", babelHelpers["extends"]({
            className: "x14qfxbe"
        }, c("CometVisualCompletionAttributes").IGNORE, {
            children: i.jsx("div", {
                className: "xgd8bvy",
                children: i.jsx(c("TetraIcon.react"), {
                    "aria-hidden": !0,
                    "aria-label": h._("Exit typeahead"),
                    color: "secondary",
                    focusable: !1,
                    icon: a,
                    onPress: b,
                    size: 20,
                    testid: void 0
                })
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTypeaheadRoundedInputGlimmer.react", ["BaseGlimmer.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            glimmer: {
                borderTopStartRadius: "xnwf7zb",
                borderTopEndRadius: "x40j3uw",
                borderBottomEndRadius: "x1s7lred",
                borderBottomStartRadius: "x15gyhx8",
                height: "x5yr21d",
                width: "xh8yej3"
            }
        };

    function a(a) {
        a = a.xStyle;
        return h.jsx("div", {
            className: c("stylex")(a),
            children: h.jsx(c("BaseGlimmer.react"), {
                className: c("stylex")(i.glimmer),
                index: 0
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CastingContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    c = a.createContext(null);
    e = a.createContext(null);
    f = a.createContext(null);
    g.CastingStateContext = b;
    g.CastingExperienceStateContext = c;
    g.SetCastingControllerContext = e;
    g.CastingControllerContext = f
}), 98);
__d("CometPictureInPictureExpContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        pictureInPictureExpConfig: {
            isInPictureInPictureExp: !1,
            isInPictureInPictureExpControlGroup: !1,
            isSkipAndChainingDisabled: !1
        },
        setPictureInPictureExpConfig: function() {}
    });
    g["default"] = b
}), 98);
__d("generateChainingSessionID", ["Random"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return "f" + (d("Random").random() * (1 << 30)).toString(16).replace(".", "")
    }
    g["default"] = a
}), 98);
__d("useCometTahoeChainingDepth", ["generateChainingSessionID", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    a = d("react");
    b = a.createContext;
    var i = a.useContext,
        j = a.useMemo,
        k = a.useReducer,
        l = a.useState,
        m = b({
            chainingDepthDispatch: null,
            chainingDepthState: 0,
            chainingSessionID: null
        });
    e = function() {
        var a = 0,
            b = function(a, b) {
                switch (b.type) {
                    case "INCREMENT":
                        return a + 1;
                    default:
                        return a
                }
            };
        b = k(b, a);
        var d = b[0],
            e = b[1];
        a = l(function() {
            return c("generateChainingSessionID")()
        });
        var f = a[0];
        a[1];
        return j(function() {
            return {
                chainingDepthDispatch: e,
                chainingDepthState: d,
                chainingSessionID: f
            }
        }, [e, d, f])
    };
    f = function() {
        return i(m)
    };
    d = function(a) {
        var b = a.children;
        a = a.value;
        return h.jsx(m.Provider, {
            value: a,
            children: b
        })
    };
    g.useChainingDepth = e;
    g.useChainingDepthContext = f;
    g.CometTahoeChainingDepthContextProvider = d
}), 98);
__d("CometSetWatchAndScrollVideoContext", ["react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(function() {
        c("recoverableViolation")("No provider of CometSetWatchAndScrollVideoContext exists", "comet_video_player")
    });
    g["default"] = b
}), 98);
__d("CometWatchAndScrollVideoContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometWatchAndScrollSetStoryViewabilityLoggerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(function() {});
    g["default"] = b
}), 98);
__d("CometWatchAndScrollSoundContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        muted: null,
        setMuted: function() {},
        setVolume: function() {},
        volume: null
    });
    g["default"] = b
}), 98);
__d("CometWatchAndScrollStoryViewabilityLoggerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("ZenonSignalingProtocol", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("$InternalEnum")({
        MW: "mw",
        MWPP: "mw++"
    });
    c = a;
    f["default"] = c
}), 66);
__d("ZenonIncomingRingSDK", ["BaseEventEmitter", "ZenonSignalingProtocol", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("ZenonParentCallsManager").__setRef("ZenonIncomingRingSDK"),
        i = [1, 2, 15, 16];
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.$ZenonIncomingRingSDK1 = [], c.$ZenonIncomingRingSDK2 = [], b) || babelHelpers.assertThisInitialized(c)
        }
        var d = b.prototype;
        d.init = function(a) {
            var b = this;
            this.$ZenonIncomingRingSDK3 = a;
            h.onReady(function(c) {
                b.callsManager == null && (b.callsManager = new c(a));
                c = b.callsManager;
                c.addListener("unsupportedRing", function(a) {
                    return b.emit("unsupportedRing", a)
                });
                c.addListener("incomingRing", function(a) {
                    var c;
                    if (a.actorID != null && !((c = b.$ZenonIncomingRingSDK3) == null ? void 0 : c.enableIncomingActorCalls)) return;
                    b.emit("incomingRing", a)
                });
                c.addListener("ringCancel", function(a) {
                    return b.emit("ringCancel", a)
                });
                c.initListeners(b.$ZenonIncomingRingSDK1);
                while (b.$ZenonIncomingRingSDK2.length > 0) {
                    var d = b.$ZenonIncomingRingSDK2.shift();
                    c.startOutgoingCallIntent(d.nonce, d.callParams)
                }
            })
        };
        d.initListeners = function(a) {
            var b = this.callsManager;
            if (b != null) b.initListeners(a);
            else {
                (b = this.$ZenonIncomingRingSDK1).push.apply(b, a)
            }
        };
        d.removeListeners = function(a) {
            var b = this;
            if (this.callsManager != null) this.callsManager.removeListeners(a);
            else {
                var c = function() {
                    if (e) {
                        if (f >= d.length) return "break";
                        g = d[f++]
                    } else {
                        f = d.next();
                        if (f.done) return "break";
                        g = f.value
                    }
                    var a = g;
                    b.$ZenonIncomingRingSDK1 = b.$ZenonIncomingRingSDK1.filter(function(b) {
                        return b !== a
                    })
                };
                for (var d = a, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var g;
                    a = c();
                    if (a === "break") break
                }
            }
        };
        d.isCallSupported = function(a) {
            switch (a.type) {
                case "thread":
                    if (this.$ZenonIncomingRingSDK3 && i.includes(a.threadType)) return this.$ZenonIncomingRingSDK3.isSupportedClientForProtocol(c("ZenonSignalingProtocol").MW);
                    break;
                default:
                    return !1
            }
            return !1
        };
        d.startCallIntent = function(a, b) {
            this.callsManager ? this.callsManager.startOutgoingCallIntent(a, b) : this.$ZenonIncomingRingSDK2.push({
                callParams: b,
                nonce: a
            })
        };
        return b
    }(c("BaseEventEmitter"));
    g["default"] = a
}), 98);
__d("persistentQueryParams", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = ["__DEV__", "__hs", "__xtrace__", "_country_override_", "artillery_sample", "big_pipe", "break_on_name", "break_on_pass", "browserlab_logging", "browserlab_test", "cacheobs_sample", "cavalry_cohort", "demo_ad", "dpr", "ego_services", "egodebug", "fbtrace", "feed_demo_ad", "flog", "force_logging", "force_megaphone_reload", "forced_qp_id", "gk_debug", "gk_disable", "gk_enable", "gomez_sample", "hide_dev_console", "js_debug", "js_nocatch", "killabyte", "locale", "mh_function_visitor_off", "mh_function_visitor_on", "mh_p_content_refs", "mh_p_function_visitor", "mh_p_inline_require", "mh_p_min", "nobatch", "nocache", "no_dev_console", "pagelet_ts", "pagelet_whitelist", "profiling_mode", "prod_graphql", "public_mode", "qe", "qrt_version", "react_log_top_level_renders", "react_perf", "ro_group", "ro_name", "rollout", "se_default", "se_gs", "sk", "sr_sourcemaps", "sri", "story_type", "teak_sample", "test_id_inspector", "__tier", "theme", "tlog", "tti", "vid", "webdriver", "wirehog_sample", "showlog", "__spin_b", "__spin_t", "__spin_r", "__spin_dev_mhenv"];
    f["default"] = a
}), 66);
__d("RTWebPreCallContextSingleton", ["FBLogger", "JSResource", "RTWebCallWindowControllerLoader", "RTWebIncomingRingConfiguration", "ZenonCallInviteModelLoader", "ZenonIncomingRingSDK", "gkx", "promiseDone", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("RTWebSignalingListener").__setRef("RTWebPreCallContextSingleton"),
        i = !1,
        j;

    function a(a) {
        if (!c("gkx")("1811099")) return null;
        if (j != null) return j;
        try {
            var b = new(c("ZenonIncomingRingSDK"))();
            j = {
                callInviteModel: new(c("ZenonCallInviteModelLoader"))(b),
                callWindowController: new(c("RTWebCallWindowControllerLoader"))(a, c("JSResource")("RTWebMercuryCallWindowInitializer").__setRef("RTWebPreCallContextSingleton")),
                incomingRingSDK: b
            };
            return j
        } catch (a) {
            c("FBLogger")("rtc_www").catching(a).mustfix("Pre-call context initialization failed! This breaks all calling!");
            return null
        }
    }

    function b() {
        if (!c("gkx")("1811099")) return null;
        if (i) return j;
        i = !0;
        j.callInviteModel.init();
        j.callWindowController.init();
        j.incomingRingSDK.init({
            isSupportedClientForProtocol: d("RTWebIncomingRingConfiguration").isSupportedClientForProtocol,
            enableIncomingActorCalls: !1
        });
        c("promiseDone")(h.load(), function(a) {
            j.incomingRingSDK.initListeners([new a()])
        });
        return j
    }

    function e() {
        return j
    }
    g.create = a;
    g.init = b;
    g.get = e
}), 98);
__d("getRequestConstUri", ["ConstUriUtils", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = d("ConstUriUtils").getUri(window.location.href);
        if (a == null) throw c("unrecoverableViolation")("Cannot create ConstUriImpl of current request", "comet_infra");
        return a
    }
    g["default"] = a
}), 98);
__d("requireNUX", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        throw new Error("Cannot use raw untransformed requireNUX.")
    }
    f["default"] = a
}), 66);
__d("XCometGamingControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/gaming/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XCometNotificationsControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/notifications/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XCometProfileReactivationControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/settings/reactivation/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("XCometWatchControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/watch/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("recoil-shared/util/Recoil_err", ["fb-error"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("fb-error").err;
    e.exports = a
}), null);
__d("refine/Refine_API", ["recoil-shared/util/Recoil_err"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a, c) {
        if (c != null) {
            var d = c.path.toString();
            c = c.message;
            throw b("recoil-shared/util/Recoil_err")("[refine.js (path=" + d + ", message=" + c + ")]: " + a)
        }
        throw b("recoil-shared/util/Recoil_err")("[refine.js (null result)]: " + a)
    }

    function a(a, b) {
        b === void 0 && (b = "assertion error");
        return function(c) {
            c = a(c);
            return c.type === "success" ? c.value : g(b, c)
        }
    }

    function c(a, b) {
        return function(c) {
            c = a(c);
            b != null && b(c);
            return c.type === "success" ? c.value : null
        }
    }
    e.exports = {
        assertion: a,
        coercion: c
    }
}), null);
__d("refine/Refine_Checkers", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function() {
        function a(a, b) {
            a === void 0 && (a = null), b === void 0 && (b = "<root>"), this.parent = a, this.field = b
        }
        var b = a.prototype;
        b.extend = function(b) {
            return new a(this, b)
        };
        b.toString = function() {
            var a = [],
                b = this;
            while (b != null) {
                var c = b,
                    d = c.field;
                c = c.parent;
                a.push(d);
                b = c
            }
            return a.reverse().join("")
        };
        return a
    }();

    function a(a, b) {
        return {
            type: "success",
            value: a,
            warnings: b
        }
    }

    function b(a, b) {
        return {
            type: "failure",
            message: a,
            path: b
        }
    }

    function c(a, b) {
        return function(c, d) {
            d === void 0 && (d = new g());
            c = a(c, d);
            return c.type === "failure" ? c : b(c, d)
        }
    }
    e.exports = {
        Path: g,
        success: a,
        failure: b,
        compose: c
    }
}), null);
__d("refine/Refine_ContainerCheckers", ["refine/Refine_Checkers"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = (b = b("refine/Refine_Checkers")).Path,
        h = b.compose,
        i = b.failure,
        j = b.success;

    function k(a) {
        if (Object.prototype.toString.call(a) !== "[object Object]") return !1;
        a = Object.getPrototypeOf(a);
        return a === null || a === Object.prototype
    }

    function l(a) {
        return function(b, c) {
            c === void 0 && (c = new g());
            if (!Array.isArray(b)) return i("value is not an array", c);
            var d = b.length,
                e = new Array(d),
                f = [];
            for (var h = 0; h < d; h++) {
                var k = b[h];
                k = a(k, c.extend("[" + h + "]"));
                if (k.type === "failure") return i(k.message, k.path);
                e[h] = k.value;
                k.warnings.length !== 0 && f.push.apply(f, k.warnings)
            }
            return j(e, f)
        }
    }

    function a() {
        for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
        return function(a, c) {
            c === void 0 && (c = new g());
            if (!Array.isArray(a)) return i("value is not an array", c);
            var d = new Array(b.length),
                e = [];
            for (var f = b.entries(), h = Array.isArray(f), k = 0, f = h ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var l;
                if (h) {
                    if (k >= f.length) break;
                    l = f[k++]
                } else {
                    k = f.next();
                    if (k.done) break;
                    l = k.value
                }
                l = l;
                var m = l[0];
                l = l[1];
                l = l(a[m], c.extend("[" + m + "]"));
                if (l.type === "failure") return i(l.message, l.path);
                d[m] = l.value;
                l.warnings.length !== 0 && e.push.apply(e, l.warnings)
            }
            return j(d, e)
        }
    }

    function m(a) {
        return function(b, c) {
            c === void 0 && (c = new g());
            if (typeof b !== "object" || b === null || !k(b)) return i("value is not an object", c);
            var d = {},
                e = [];
            b = Object.entries(b);
            for (var f = 0; f < b.length; f++) {
                var h = b[f],
                    l = h[0];
                h = h[1];
                h = a(h, c.extend("." + l));
                if (h.type === "failure") return i(h.message, h.path);
                d[l] = h.value;
                h.warnings.length !== 0 && e.push.apply(e, h.warnings)
            }
            return j(d, e)
        }
    }
    var n = function(a) {
        this.checker = a
    };

    function c(a) {
        return new n(function(b, c) {
            c === void 0 && (c = new g());
            b = a(b, c);
            if (b.type === "failure") return babelHelpers["extends"]({}, b, {
                message: "(optional property) " + b.message
            });
            else return b
        })
    }

    function o(a) {
        var b = Object.keys(a);
        return function(c, d) {
            d === void 0 && (d = new g());
            if (typeof c !== "object" || c === null || !k(c)) return i("value is not an object", d);
            var e = {},
                f = [];
            for (var h = b, l = Array.isArray(h), m = 0, h = l ? h : h[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var o;
                if (l) {
                    if (m >= h.length) break;
                    o = h[m++]
                } else {
                    m = h.next();
                    if (m.done) break;
                    o = m.value
                }
                o = o;
                var p = a[o],
                    q = void 0,
                    r;
                if (p instanceof n) {
                    q = p.checker;
                    if (!Object.prototype.hasOwnProperty.call(c, o)) continue;
                    r = c[o]
                } else q = p, r = Object.prototype.hasOwnProperty.call(c, o) ? c[o] : void 0;
                p = q(r, d.extend("." + o));
                if (p.type === "failure") return i(p.message, p.path);
                e[o] = p.value;
                p.warnings.length !== 0 && f.push.apply(f, p.warnings)
            }
            return j(e, f)
        }
    }

    function d(a) {
        return function(b, c) {
            c === void 0 && (c = new g());
            if (!(b instanceof Set)) return i("value is not a Set", c);
            var d = new Set(),
                e = [];
            for (var b = b, f = Array.isArray(b), h = 0, b = f ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var k;
                if (f) {
                    if (h >= b.length) break;
                    k = b[h++]
                } else {
                    h = b.next();
                    if (h.done) break;
                    k = h.value
                }
                k = k;
                k = a(k, c.extend("[]"));
                if (k.type === "failure") return i(k.message, k.path);
                d.add(k.value);
                k.warnings.length && e.push.apply(e, k.warnings)
            }
            return j(d, e)
        }
    }

    function f(a, b) {
        return function(c, d) {
            d === void 0 && (d = new g());
            if (!(c instanceof Map)) return i("value is not a Map", d);
            var e = new Map(),
                f = [];
            for (var c = c.entries(), h = Array.isArray(c), k = 0, c = h ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var l;
                if (h) {
                    if (k >= c.length) break;
                    l = c[k++]
                } else {
                    k = c.next();
                    if (k.done) break;
                    l = k.value
                }
                l = l;
                var m = l[0];
                l = l[1];
                var n = a(m, d.extend("[" + m + "] key"));
                if (n.type === "failure") return i(n.message, n.path);
                var o = b(l, d.extend("[" + m + "]"));
                if (o.type === "failure") return i(o.message, o.path);
                e.set(m, l);
                f.push.apply(f, n.warnings.concat(o.warnings))
            }
            return j(e, f)
        }
    }

    function p(a) {
        return h(l(a), function(a) {
            var b = a.value;
            a = a.warnings;
            return j([].concat(b), a)
        })
    }

    function q(a) {
        return h(m(a), function(a) {
            var b = a.value;
            a = a.warnings;
            return j(babelHelpers["extends"]({}, b), a)
        })
    }

    function r(a) {
        return h(o(a), function(a) {
            var b = a.value;
            a = a.warnings;
            return j(babelHelpers["extends"]({}, b), a)
        })
    }
    e.exports = {
        array: l,
        tuple: a,
        object: o,
        optional: c,
        dict: m,
        set: d,
        map: f,
        writableArray: p,
        writableDict: q,
        writableObject: r
    }
}), null);
__d("refine/Refine_JSON", ["refine/Refine_API"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("refine/Refine_API").assertion;

    function h(a, b) {
        if (a == null) return null;
        try {
            return JSON.parse(a, b)
        } catch (a) {
            return null
        }
    }

    function a(a, b) {
        var c = g(a, (a = b) != null ? a : "value is invalid");
        return function(a) {
            return c(h((a = a) != null ? a : ""))
        }
    }

    function c(a) {
        return function(b) {
            b = a(h(b));
            return b.type === "success" ? b.value : null
        }
    }
    e.exports = {
        jsonParserEnforced: a,
        jsonParser: c
    }
}), null);
__d("refine/Refine_PrimitiveCheckers", ["refine/Refine_Checkers"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = (b = b("refine/Refine_Checkers")).Path,
        h = b.compose,
        i = b.failure,
        j = b.success;

    function a() {
        return k
    }
    var k = function(a) {
        return j(a, [])
    };

    function c(a) {
        var b = function(a) {
            return JSON.stringify(a)
        };
        return function(c, d) {
            d === void 0 && (d = new g());
            return c === a ? j(a, []) : i("value is not literal " + ((c = b(a)) != null ? c : "void"), d)
        }
    }

    function d() {
        return function(a, b) {
            b === void 0 && (b = new g());
            return typeof a === "boolean" ? j(a, []) : i("value is not a boolean", b)
        }
    }

    function f() {
        return function(a, b) {
            b === void 0 && (b = new g());
            return typeof a === "number" ? j(a, []) : i("value is not a number", b)
        }
    }

    function l(a) {
        return function(b, c) {
            c === void 0 && (c = new g());
            if (typeof b !== "string") return i("value is not a string", c);
            return a != null && !a.test(b) ? i("value does not match regex: " + a.toString(), c) : j(b, [])
        }
    }

    function m(a) {
        return function(b, c) {
            c === void 0 && (c = new g());
            if (typeof b !== "string") return i("value must be a string", c);
            b = a[b];
            return b == null ? i("value is not one of " + Object.keys(a).join(", "), c) : j(b, [])
        }
    }

    function n(a) {
        var b = Object.keys(a).reduce(function(b, c) {
                return Object.assign(b, (b = {}, b[a[c]] = a[c], b))
            }, {}),
            c = m(b);
        return function(a, b) {
            b === void 0 && (b = new g());
            var d = typeof a === "number" ? a.toString() : a;
            d = c(d, b);
            return d.type === "success" && typeof d.value !== typeof a ? i("input must be the same type as the enum values", b) : d
        }
    }

    function o() {
        return function(a, b) {
            b === void 0 && (b = new g());
            if (!(a instanceof Date)) return i("value is not a date", b);
            return isNaN(a) ? i("invalid date", b) : j(a, [])
        }
    }

    function p() {
        return h(l(), function(a, b) {
            var c = a.value;
            a = a.warnings;
            c = new Date(c);
            return Number.isNaN(c) ? i("value is not valid date string", b) : j(c, a)
        })
    }
    e.exports = {
        mixed: a,
        literal: c,
        bool: d,
        number: f,
        string: l,
        stringLiterals: m,
        date: o,
        jsonDate: p,
        enumObject: n
    }
}), null);
__d("refine/Refine_UtilityCheckers", ["refine/Refine_Checkers"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = (b = b("refine/Refine_Checkers")).Path,
        h = b.compose,
        i = b.failure,
        j = b.success;

    function a(a, b) {
        return h(a, function(a) {
            var c = a.value;
            a = a.warnings;
            return j(b(c), a)
        })
    }

    function k(a, b, c) {
        return i(a + ": " + c.map(function(a) {
            return a.message
        }).join(", "), b)
    }

    function c(a, b) {
        return function(c, d) {
            d === void 0 && (d = new g());
            var e = a(c, d);
            if (e.type === "success") return j(e.value, e.warnings);
            c = b(c, d);
            return c.type === "success" ? j(c.value, c.warnings) : k("value did not match any types in or()", d, [e, c])
        }
    }

    function l() {
        for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
        return function(a, c) {
            c === void 0 && (c = new g());
            var d = [];
            for (var e = 0; e < b.length; e++) {
                var f = b[e];
                f = f(a, c);
                if (f.type === "success") return j(f.value, f.warnings);
                d.push(f)
            }
            return k("value did not match any types in union", c, d)
        }
    }

    function d() {
        return l.apply(void 0, arguments)
    }

    function f(a, b) {
        b = (b = b) != null ? b : {};
        b = b.nullWithWarningWhenInvalid;
        var c = b === void 0 ? !1 : b;
        return function(b, d) {
            d === void 0 && (d = new g());
            if (b == null) return j(b, []);
            b = a(b, d);
            if (b.type === "success") return j(b.value, b.warnings);
            if (c) return j(null, [b]);
            d = b.message;
            b = b.path;
            return i(d, b)
        }
    }

    function m(a, b) {
        b = (b = b) != null ? b : {};
        b = b.undefinedWithWarningWhenInvalid;
        var c = b === void 0 ? !1 : b;
        return function(b, d) {
            d === void 0 && (d = new g());
            if (b === void 0) return j(void 0, []);
            b = a(b, d);
            if (b.type === "success") return j(b.value, b.warnings);
            if (c) return j(void 0, [b]);
            d = b.message;
            b = b.path;
            return i(d, b)
        }
    }

    function n(a, b) {
        return function(c, d) {
            d === void 0 && (d = new g());
            if (c == null) return j(b, []);
            c = a(c, d);
            return c.type === "failure" || c.value != null ? c : j(b, [])
        }
    }

    function o(a, b) {
        return h(a, function(a, c) {
            var d = a.value;
            a = a.warnings;
            var e = b(d);
            e = typeof e === "boolean" ? [e, "value failed constraint check"] : e;
            var f = e[0];
            e = e[1];
            return f ? j(d, a) : i(e, c)
        })
    }

    function p(a) {
        return function(b, c) {
            c === void 0 && (c = new g());
            var d = a();
            return d(b, c)
        }
    }

    function q(a, b) {
        b === void 0 && (b = "failed to return non-null from custom checker.");
        return function(c, d) {
            d === void 0 && (d = new g());
            try {
                c = a(c);
                return c != null ? j(c, []) : i(b, d)
            } catch (a) {
                return i(a.message, d)
            }
        }
    }
    e.exports = {
        or: c,
        union: l,
        match: d,
        nullable: f,
        voidable: m,
        withDefault: n,
        constraint: o,
        asType: a,
        lazy: p,
        custom: q
    }
}), null);
__d("refine", ["refine/Refine_API", "refine/Refine_Checkers", "refine/Refine_ContainerCheckers", "refine/Refine_JSON", "refine/Refine_PrimitiveCheckers", "refine/Refine_UtilityCheckers"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    a = b("refine/Refine_API").assertion;
    c = b("refine/Refine_API").coercion;
    d = b("refine/Refine_Checkers").Path;
    var h = (f = b("refine/Refine_ContainerCheckers")).array,
        i = f.dict,
        j = f.map,
        k = f.object,
        l = f.optional,
        m = f.set,
        n = f.tuple,
        o = f.writableArray,
        p = f.writableDict;
    f = f.writableObject;
    var q = b("refine/Refine_JSON").jsonParser,
        r = b("refine/Refine_JSON").jsonParserEnforced,
        s = (g = b("refine/Refine_PrimitiveCheckers")).bool,
        t = g.date,
        u = g.enumObject,
        v = g.jsonDate,
        w = g.literal,
        x = g.mixed,
        y = g.number,
        z = g.string;
    g = g.stringLiterals;
    var A = (b = b("refine/Refine_UtilityCheckers")).asType,
        B = b.constraint,
        C = b.custom,
        D = b.lazy,
        E = b.match,
        F = b.nullable,
        G = b.or,
        H = b.union,
        I = b.voidable;
    b = b.withDefault;
    e.exports = {
        assertion: a,
        coercion: c,
        jsonParser: q,
        jsonParserEnforced: r,
        Path: d,
        mixed: x,
        literal: w,
        bool: s,
        number: y,
        string: z,
        stringLiterals: g,
        enumObject: u,
        date: t,
        jsonDate: v,
        asType: A,
        or: G,
        union: H,
        match: E,
        nullable: F,
        voidable: I,
        withDefault: b,
        constraint: B,
        lazy: D,
        custom: C,
        array: h,
        tuple: n,
        dict: i,
        object: k,
        optional: l,
        set: m,
        map: j,
        writableArray: o,
        writableDict: p,
        writableObject: f
    }
}), null);
__d("$InternalEnumUtils", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = Object.prototype.hasOwnProperty;

    function a(a) {
        return function(b) {
            return b == null || !g.call(a, b) ? null : a[b]
        }
    }
    var h = typeof WeakMap === "function" ? new WeakMap() : new Map();

    function b(a) {
        return function(b) {
            if (b == null) return null;
            var c = h.get(a);
            c == null && (c = new Map(Object.getOwnPropertyNames(a).map(function(b) {
                return [a[b], b]
            })), h.set(a, c));
            return (c = c.get(b)) != null ? c : null
        }
    }
    f.createToJSEnum = a;
    f.createFromJSEnum = b
}), 66);
__d("CometMessagingJewelCommunitiesQPBannerContainerQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5370850649701085"
}), null);
__d("CometMessagingJewelDropdownQPBannerContainerQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5777080552322971"
}), null);
__d("EnumType", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    a = b("$InternalEnum")({
        TYPE_INT: 0,
        TYPE_STRING: 1,
        TYPE_MIXED: 2
    });
    c = a;
    f["default"] = c
}), 66);
__d("XCometHomeControllerRouteBuilder", ["jsRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")("/", Object.freeze({}), void 0);
    b = a;
    g["default"] = b
}), 98);
__d("CometErrorRoot.react", ["fbt", "CometContentArea.react", "CometLink.react", "ConstUriUtils", "InteractionTracing", "NullState404FailedLoading", "NullStateGeneral", "NullStatePermissions", "TetraButton.react", "TetraNullState.react", "TetraText.react", "XCometHomeControllerRouteBuilder", "XCometProfileReactivationControllerRouteBuilder", "clearTimeout", "react", "setTimeout", "unrecoverableViolation", "useCometRouterDispatcher"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useCallback,
        k = b.useEffect,
        l = b.useState,
        m = 8460,
        n = 6e3;

    function o() {
        var a = 0,
            b = 0;
        while (a === 0) a = Math.random();
        while (b === 0) b = Math.random();
        return Math.sqrt(-2 * Math.log(a)) * Math.cos(2 * Math.PI * b)
    }

    function a(a) {
        var b, e, f, g = c("NullStateGeneral");
        (a == null ? void 0 : (b = a.routeProps) == null ? void 0 : b.privacy) && (g = c("NullStatePermissions"));
        (a == null ? void 0 : (b = a.routeProps) == null ? void 0 : b.fourZerofour) && (g = c("NullState404FailedLoading"));
        b = c("XCometHomeControllerRouteBuilder").buildURL({});
        var p = c("useCometRouterDispatcher")(),
            q = j(function() {
                p && p.goBack && p.goBack()
            }, [p]);
        c("InteractionTracing").getPendingInteractions().forEach(function(a) {
            a.addAnnotationInt("isError", 1)
        });
        var r = i.jsx(c("TetraButton.react"), {
            label: h._("Reload Page"),
            onPress: function() {
                return window.location.reload(!0)
            },
            padding: "wide",
            size: "large"
        });
        e = (e = d("ConstUriUtils").getUri("/help")) == null ? void 0 : (e = e.getQualifiedUri()) == null ? void 0 : e.toString();
        if (e == null) throw c("unrecoverableViolation")("help URL was null", "comet_infra");
        var s;
        if ((a == null ? void 0 : (f = a.routeProps) == null ? void 0 : f.isAdminViewingDeactivatedProfile) === !0) {
            f = c("XCometProfileReactivationControllerRouteBuilder").buildURL({});
            r = i.jsx(c("TetraButton.react"), {
                label: h._("Reactivate Page"),
                linkProps: {
                    url: f
                },
                padding: "wide",
                size: "large"
            });
            s = i.jsx("div", {
                className: "x9otpla xdt5ytf x78zum5 x6s0dn4",
                children: i.jsx("div", {
                    className: "xw7yly9",
                    children: i.jsx(c("CometLink.react"), {
                        href: b,
                        target: "_blank",
                        children: i.jsx(c("TetraText.react"), {
                            color: "blueLink",
                            type: "bodyLink2",
                            children: h._("Go to News Feed")
                        })
                    })
                })
            })
        } else((a == null ? void 0 : (f = a.routeProps) == null ? void 0 : f.fourZerofour) || (a == null ? void 0 : (f = a.routeProps) == null ? void 0 : f.privacy)) && (r = i.jsx(c("TetraButton.react"), {
            label: h._("Go to News Feed"),
            linkProps: {
                url: b
            },
            padding: "wide",
            size: "large"
        }), s = i.jsxs("div", {
            className: "x9otpla xdt5ytf x78zum5 x6s0dn4",
            children: [i.jsx(c("CometLink.react"), {
                onClick: q,
                target: "_blank",
                children: i.jsx(c("TetraText.react"), {
                    color: "blueLink",
                    type: "bodyLink2",
                    children: h._("Go Back")
                })
            }), i.jsx("div", {
                className: "xw7yly9",
                children: i.jsx(c("CometLink.react"), {
                    href: e,
                    target: "_blank",
                    children: i.jsx(c("TetraText.react"), {
                        color: "blueLink",
                        type: "bodyLink2",
                        children: h._("Visit Help Center")
                    })
                })
            })]
        }));
        f = l(null);
        b = f[0];
        var t = f[1],
            u = a == null ? void 0 : (q = a.routeProps) == null ? void 0 : q.isBOC;
        k(function() {
            if (u === !0) {
                var a = Math.abs(m + o() * n),
                    b = c("setTimeout")(function() {
                        t(i.jsx("iframe", {
                            className: "xnalus7 xqtp20y xm0m39n x1qhh985 xcfux6l x972fbf"
                        }))
                    }, a);
                return function() {
                    return c("clearTimeout")(b)
                }
            }
        }, [u]);
        return i.jsx(c("CometContentArea.react"), {
            verticalAlign: "middle",
            children: i.jsxs("div", {
                className: "x1ifrov1 xvue9z xdt5ytf x78zum5 x6s0dn4",
                "data-testid": void 0,
                children: [i.jsx(c("TetraNullState.react"), {
                    action: r,
                    body: ((e = a.routeProps) == null ? void 0 : e.body) || h._("This may be because of a technical error that we're working to get fixed. Try reloading this page."),
                    headline: ((f = a.routeProps) == null ? void 0 : f.title) || h._("This Page Isn't Available Right Now"),
                    icon: g
                }), s, b]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometRoutePassthroughPropsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterParentRouteContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometRouterRefreshKeyContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometRouterRenderTypeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useCometRouterMainTabKey", ["unrecoverableViolation", "useCometRouterState"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useCometRouterState")();
        if (a == null) throw c("unrecoverableViolation")("Attempting to get main tab key without a router state (provided by the CometRouterStateProvider/CometRouterStateContext).", "comet_infra");
        return (a = a.main.route.tabKey) != null ? a : "__main_tab"
    }
    g["default"] = a
}), 98);
__d("useRoutePassthroughProps", ["CometRoutePassthroughPropsContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRoutePassthroughPropsContext"))
    }
    g["default"] = a
}), 98);
__d("currentCometRouterInstance", ["FBLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;

    function a() {
        h == null && c("FBLogger")("CometRouter").warn("Something attempted to access the Comet router before it was initialized.");
        return h
    }

    function b(a) {
        h = a
    }
    g.get = a;
    g.register = b
}), 98);
__d("isRouteTransparent", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a.routeType === "routable_dialog") return !0;
        return a.transparent === !0 ? !0 : !1
    }
    f["default"] = a
}), 66);
__d("coerceRouteParam", ["EnumType", "FBLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        if (a == null && b !== "EXISTS") return {
            valid: !0,
            value: null
        };
        switch (b) {
            case "BOOL":
                return {
                    valid: !0,
                    value: h(a)
                };
            case "STRING":
                return {
                    valid: !0,
                    value: l(a)
                };
            case "FBID":
                b = m(a);
                return b !== null ? {
                    valid: !0,
                    value: b
                } : {
                    valid: !1
                };
            case "FLOAT":
                b = j(a);
                if (b !== null) return {
                    valid: !0,
                    value: b
                };
                else return {
                    valid: !1
                };
            case "INT":
                b = k(a);
                if (b !== null) return {
                    valid: !0,
                    value: b
                };
                else return {
                    valid: !1
                };
            case "INT_VECTOR":
                return n(k, a, !0);
            case "STRING_VECTOR":
                return n(l, a);
            case "FLOAT_VECTOR":
                return n(j, a, !0);
            case "STRING_SET":
                return o(l, a);
            case "EXISTS":
                return {
                    valid: !0,
                    value: i(a)
                };
            case "STRING_TO_INT_MAP":
                return p(l, k, a);
            case "STRING_TO_FLOAT_MAP":
                return p(l, j, a);
            case "STRING_TO_BOOL_MAP":
                return p(l, h, a);
            case "STRING_TO_STRING_MAP":
                return p(l, l, a);
            case "INT_TO_FLOAT_MAP":
                return p(k, j, a);
            case "INT_TO_INT_MAP":
                return p(k, k, a);
            case "INT_TO_BOOL_MAP":
                return p(k, h, a);
            case "INT_TO_STRING_MAP":
                return p(k, l, a);
            case "ENUM":
                b = c("EnumType").cast(d);
                if (b != null) switch (b) {
                    case 0:
                        d = q(k, a);
                        return d !== null ? {
                            valid: !0,
                            value: d
                        } : {
                            valid: !1
                        };
                    case 1:
                        b = q(l, a);
                        return b !== null ? {
                            valid: !0,
                            value: b
                        } : {
                            valid: !1
                        };
                    default:
                        c("FBLogger")("url_param_validators_codegen").warn("Enum Type is not handled for coercing");
                        return {
                            valid: !0,
                            value: a
                        }
                }
        }
        return {
            valid: !0,
            value: a
        }
    }

    function h(a) {
        if (typeof a === "boolean") return a;
        var b = String(a).toLowerCase();
        return b === "0" || b === "false" ? !1 : Boolean(a)
    }

    function i(a) {
        if (typeof a === "boolean") return a;
        return a === void 0 ? !1 : !0
    }

    function j(a) {
        if (a === "") return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function k(a) {
        if (a === "") return null;
        a = Number(a);
        return Number.isInteger(a) ? a : null
    }

    function l(a) {
        return String(a)
    }

    function m(a) {
        var b = k(a);
        return b !== null ? l(a) : null
    }

    function n(a, b, c) {
        c === void 0 && (c = !1);
        if (Array.isArray(b)) {
            var d = b.map(function(b) {
                return a(b)
            });
            return !d.includes(null) ? {
                valid: !0,
                value: d
            } : {
                valid: !1
            }
        } else if (c === !0) {
            d = String(b);
            c = d.split(",");
            return n(a, c)
        }
        return {
            valid: !1
        }
    }

    function o(a, b, c) {
        c === void 0 && (c = !1);
        if (Array.isArray(b)) {
            var d = new Set();
            b.forEach(function(b) {
                d.add(a(b))
            });
            var e = Array.from(d);
            return !e.includes(null) ? {
                valid: !0,
                value: e
            } : {
                valid: !1
            }
        } else if (c) {
            e = String(b);
            c = e.split(",");
            return o(a, c)
        }
        return {
            valid: !1
        }
    }

    function p(a, b, c) {
        if (typeof c === "object" || Array.isArray(c)) {
            var d = {};
            c = Object.entries((c = c) != null ? c : {});
            for (var e = 0; e < c.length; e++) {
                var f = c[e],
                    g = f[0];
                f = f[1];
                if (f !== null) {
                    g = a(g);
                    f = b(f);
                    if (g === null || f === null) return {
                        valid: !1
                    };
                    d[g] = f
                }
            }
            return {
                valid: !0,
                value: d
            }
        }
        return {
            valid: !1
        }
    }

    function q(a, b) {
        return a(b)
    }
    g["default"] = a
}), 98);