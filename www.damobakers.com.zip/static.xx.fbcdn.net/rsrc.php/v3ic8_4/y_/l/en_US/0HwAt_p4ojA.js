if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("CometGlobalPanelLayoutContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("CometInteractionSourceContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(10);
    g["default"] = b
}), 98);
__d("CometSetBlinkingTitleMessageContext", ["react", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(function() {
        c("recoverableViolation")("No provider of CometSetBlinkingTitleMessageContext exists", "comet_ui")
    });
    g["default"] = b
}), 98);
__d("CometMissingFieldHandlers", ["UFI2CommentsConnectionHandler", "getRelayFBMissingFieldHandlers", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = [].concat(c("getRelayFBMissingFieldHandlers")(), [{
        handle: function(a, b, c, e) {
            if (b != null && b.__typename === d("relay-runtime").ROOT_TYPE && a.name === "user" && Object.prototype.hasOwnProperty.call(c, "id")) return c.id;
            if (b != null && b.__typename === d("relay-runtime").ROOT_TYPE && a.name === "story" && Object.prototype.hasOwnProperty.call(c, "story_id")) return c.story_id;
            if (b != null && b.__typename === "Story" && a.name === "comet_sections" && b[d("relay-runtime").getStorageKey(a, {
                    renderLocation: "homepage_stream"
                })] != null) {
                var f = b[d("relay-runtime").getStorageKey(a, {
                    renderLocation: "homepage_stream"
                })];
                if (f != null && typeof f === "object" && Object.prototype.hasOwnProperty.call(f, "__ref") && typeof f.__ref === "string") return f.__ref
            }
            if (b != null && typeof b.id === "string" && b.__typename === "Feedback" && a.name.startsWith("__UFI2CommentsProvider_feedback_display_comments_ufi2_comments")) {
                f = e.get(b.id);
                if (!f) return void 0;
                f = d("UFI2CommentsConnectionHandler").getConnection(f, "UFI2CommentsProvider_feedback_display_comments", {
                    feedback_source: 1
                });
                return !f ? void 0 : f.getDataID()
            }
            if (b != null && typeof b.id === "string" && b.__typename === "Feedback" && a.name === "display_comments") {
                f = e.get(b.id);
                if (!f) return void 0;
                e = f.getLinkedRecord("display_comments", c);
                if (e) return e.getDataID();
                e = f.getLinkedRecord("display_comments");
                if (e) return e.getDataID();
                Object.prototype.hasOwnProperty.call(c, "is_initial_fetch") && (e = f.getLinkedRecord("display_comments", babelHelpers["extends"]({}, c, {
                    is_initial_fetch: !c.is_initial_fetch
                })));
                return e ? e.getDataID() : void 0
            }
            return b != null && a.name === "video" && Object.prototype.hasOwnProperty.call(c, "id") ? c.id : void 0
        },
        kind: "linked"
    }]);
    b = a;
    g["default"] = b
}), 98);
__d("CometRootInitServerFlag", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = !1;

    function a() {
        g = !0
    }

    function b() {
        return g
    }
    f.enableServerEnvironment = a;
    f.isServerEnvironment = b
}), 66);
__d("ReactFlightDOMRelayClient", ["cr:1342471"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1342471")
}), 98);
__d("RelayFBFlightPayloadDeserializer", ["ReactFlightDOMRelayClient"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = a;
        var b = c("ReactFlightDOMRelayClient").createResponse();
        for (var d = 0; d < a.length; d++) {
            var e = a[d];
            c("ReactFlightDOMRelayClient").resolveRow(b, e)
        }
        c("ReactFlightDOMRelayClient").close(b);
        return b
    }
    b = a;
    g["default"] = b
}), 98);
__d("RelayFBFlightServerErrorHandler", ["FBLogger", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        switch (a) {
            case "FAIL_JS_ERROR":
                c("FBLogger")("react-flight").addMetadata("REACT_FLIGHT", "ERROR_MESSAGE", b[0].message).addMetadata("REACT_FLIGHT", "ERROR_STACK", b[0].message + "\n" + b[0].stack).warn('RelayFBFlightServerErrorHandler: HaaS threw a JSRuntimeException "%s". Please see Component Stack for more details.\n%s', b[0].message, b[0].message + "\n" + b[0].stack);
                c("warning")(!1, 'RelayFBFlightServerErrorHandler: HaaS threw a JSRuntimeException "%s". Please see Component Stack for more details.\n%s', b[0].message, b[0].message + "\n" + b[0].stack);
                break;
            case "FAIL_RELAY_FLIGHT_RENDERER_CONTINUATION_ERROR":
            case "FAIL_RELAY_FLIGHT_RENDERER_ERROR":
                c("FBLogger")("react-flight").addMetadata("REACT_FLIGHT", "ERROR_MESSAGE", b[0].message).addMetadata("REACT_FLIGHT", "ERROR_STACK", b[0].stack).warn("RelayFBFlightServerErrorHandler: %s.\nPlease see Component Stack for more details.\n%s", b[0].message, b[0].stack);
                c("warning")(!1, "RelayFBFlightServerErrorHandler: %s\nPlease see Component Stack for more details.\n%s", b[0].message, b[0].stack);
                break;
            default:
                c("FBLogger")("react-flight").addMetadata("REACT_FLIGHT", "ERROR_MESSAGE", b[0].message).addMetadata("REACT_FLIGHT", "ERROR_STACK", b[0].stack).warn("RelayFBFlightServerErrorHandler: %s.\n%s", b[0].message, b[0].stack), c("warning")(!1, "RelayFBFlightServerErrorHandler: %s\n%s", b[0].message, b[0].stack)
        }
    }
    b = a;
    g["default"] = b
}), 98);
__d("CometNewsFeedConnectionHandler", ["FBLogger", "RelayFBConnectionHandler_UNSTABLE", "gkx", "relay-runtime", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "comet_news_feed",
        i = "__connection_next_edge_index",
        j = "received_edges_count";

    function a(a, b) {
        var e, f = a.get(b.dataID);
        if (!f) return;
        var g = d("relay-runtime").ConnectionInterface.get();
        g = g.EDGES;
        if (b.args.before != null) throw c("unrecoverableViolation")("The newsfeed connection does not support backward pagination by design", "comet_feed");
        var h = f.getLinkedRecord(b.fieldKey);
        if (!h) {
            c("FBLogger")("comet_feed").mustfix("Newsfeed connection is null in the store, this means no feed stories will be shown");
            return
        }
        var m = d("relay-runtime").generateClientID(f.getDataID(), b.handleKey),
            n = f.getLinkedRecord(b.handleKey);
        e = (e = n) != null ? e : a.get(m);
        if (!e) {
            var o = a.create(m, h.getType());
            o.setValue(0, i);
            o.copyFieldsFrom(h);
            m = h.getLinkedRecords(g);
            m && (m = m.map(function(b) {
                return d("relay-runtime").ConnectionHandler.buildConnectionEdge(a, o, b)
            }), o.setLinkedRecords(m, g), o.setValue(m.length, j));
            f.setLinkedRecord(o, b.handleKey);
            k(a, m, m, o, h);
            return
        }
        n == null && f.setLinkedRecord(e, b.handleKey);
        var p = e;
        m = h.getLinkedRecords(g);
        m && (m = m.map(function(b) {
            return d("relay-runtime").ConnectionHandler.buildConnectionEdge(a, p, b)
        }), p.setValue(m.length, j));
        n = p.getLinkedRecords(g);
        p.copyFieldsFrom(h);
        f = [];
        e = new Set();
        if (b.args.after != null || ((b = (b = m) == null ? void 0 : b.length) != null ? b : 0) === 0) {
            l((b = n) != null ? b : [], f, e)
        }
        l((n = m) != null ? n : [], f, e);
        p.setLinkedRecords(f, g);
        k(a, m, f, p, h)
    }

    function k(a, b, e, f, g) {
        var h = d("relay-runtime").ConnectionInterface.get(),
            i = h.END_CURSOR,
            j = h.HAS_NEXT_PAGE,
            k = h.HAS_PREV_PAGE,
            l = h.PAGE_INFO;
        h = h.PAGE_INFO_TYPE;
        g = g.getLinkedRecord(l);
        var m = f.getLinkedRecord(l);
        m == null && (m = a.create(d("relay-runtime").generateClientID(f.getDataID(), l), h), f.setLinkedRecord(m, l));
        a = g == null ? void 0 : g.getValue(i);
        m.setValue(!1, k);
        if (c("gkx")("1250838")) {
            m.setValue(((h = b == null ? void 0 : b.length) != null ? h : 0) > 0 || (g == null ? void 0 : g.getValue(j)) === !0, j)
        } else {
            m.setValue(((f = b == null ? void 0 : b.length) != null ? f : 0) > 0, j)
        }
        l = e != null ? e[e.length - 1] : null;
        k = null;
        l != null && (k = l.getValue("cursor"));
        if (k == null && a == null) {
            c("FBLogger")("comet_feed").info("Unable to set end_cursor as neither the server end cursor, or last edge cursor is defined, this can happen on initial load when there are no stories but shouldn't happen otherwise", "comet_feed");
            return
        }
        m.setValue((h = a) != null ? h : k, i)
    }

    function b(a, b, c) {
        b = d("relay-runtime").getRelayHandleKey(h, b, null);
        return a.getLinkedRecord(b, c)
    }

    function e(a, b, c) {
        return d("RelayFBConnectionHandler_UNSTABLE").unstable_getAllConnectionsWithKey(a, b, c, h)
    }

    function l(a, b, e) {
        var f = d("relay-runtime").ConnectionInterface.get();
        f = f.NODE;
        for (var g = 0; g < a.length; g++) {
            var h = a[g];
            if (!h) continue;
            var i = h.getLinkedRecord(f);
            if (!i) continue;
            i = i && i.getDataID();
            if (i == null) {
                c("FBLogger")("comet_feed").mustfix("Found edge without deduplication nodeID in comet_news_feed, this can lead to duplicate feed stories being rendered");
                b.push(h);
                continue
            }
            if (e.has(i)) continue;
            e.add(i);
            b.push(h)
        }
    }

    function f(a, b, e, f) {
        if (e == null) return e;
        var g = d("relay-runtime").ConnectionInterface.get();
        g = g.EDGES;
        var h = b.getValue(i);
        if (typeof h !== "number") throw c("unrecoverableViolation")("CometNewsFeedConnectionHandler: Expected edgeIndex to be a number", "comet_feed");
        f = (f = f) != null ? f : d("relay-runtime").generateClientID(b.getDataID(), g, h);
        g = a.create(f, e.getType());
        g.copyFieldsFrom(e);
        b.setValue(h + 1, i);
        return g
    }
    g.update = a;
    g.getConnection = b;
    g.unstable_getAllConnectionsWithKey = e;
    g.buildConnectionEdge = f;
    g.insertEdgeBefore = d("relay-runtime").ConnectionHandler.insertEdgeBefore
}), 98);
__d("CometNotificationsThinClientConnectionHandler", ["relay-runtime", "unrecoverableViolation", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "comet_notifications_thin_client",
        i = "__connection_next_edge_index";

    function a(a, b) {
        var e, f = a.get(b.dataID);
        if (!f) return;
        var g = d("relay-runtime").ConnectionInterface.get(),
            h = g.EDGES,
            n = g.END_CURSOR,
            o = g.HAS_NEXT_PAGE,
            p = g.HAS_PREV_PAGE,
            q = g.PAGE_INFO,
            r = g.PAGE_INFO_TYPE;
        g = g.START_CURSOR;
        var s = f.getLinkedRecord(b.fieldKey),
            t = s && s.getLinkedRecord(q);
        if (!s) {
            f.setValue(null, b.handleKey);
            return
        }
        var u = d("relay-runtime").generateClientID(f.getDataID(), b.handleKey),
            v = f.getLinkedRecord(b.handleKey);
        e = (e = v) != null ? e : a.get(u);
        var w = e && e.getLinkedRecord(q);
        if (!e) {
            var x = a.create(u, s.getType());
            x.setValue(0, i);
            x.copyFieldsFrom(s);
            u = s.getLinkedRecords(h);
            if (u) {
                var y = d("relay-runtime").ConnectionInterface.get(),
                    z = y.NODE;
                u = u.reduce(function(b, c) {
                    if (!c) return b;
                    var d = c.getLinkedRecord(z);
                    d = d == null ? void 0 : d.getType();
                    return d === "NotifPageCachedNotificationRow" ? b : b.concat(j(a, x, c))
                }, []);
                x.setLinkedRecords(u, h)
            }
            f.setLinkedRecord(x, b.handleKey);
            w = a.create(d("relay-runtime").generateClientID(x.getDataID(), q), r);
            w.setValue(!1, o);
            w.setValue(!1, p);
            w.setValue(null, n);
            w.setValue(null, g);
            t && w.copyFieldsFrom(t);
            x.setLinkedRecord(w, q)
        } else {
            v == null && f.setLinkedRecord(e, b.handleKey);
            var A = e;
            y = s.getLinkedRecords(h);
            y && (y = y.map(function(b) {
                return j(a, A, b)
            }));
            u = A.getLinkedRecords(h);
            r = A.getLinkedRecord(q);
            A.copyFieldsFrom(s);
            u && A.setLinkedRecords(u, h);
            r && A.setLinkedRecord(r, q);
            v = [];
            f = b.args;
            if (u && y)
                if (f.after != null)
                    if (w && f.after === w.getValue(n)) {
                        e = new Set();
                        k(u, v, e);
                        k(y, v, e)
                    } else {
                        c("warning")(!1, "Relay: Unexpected after cursor `%s`, edges must be fetched from the end of the list (`%s`).", f.after, w && w.getValue(n));
                        return
                    }
            else if (f.before != null)
                if (w && f.before === w.getValue(g)) {
                    s = new Set();
                    k(y, v, s);
                    k(u, v, s)
                } else {
                    c("warning")(!1, "Relay: Unexpected before cursor `%s`, edges must be fetched from the beginning of the list (`%s`).", f.before, w && w.getValue(g));
                    return
                }
            else {
                r = l(u);
                q = new Set();
                m(y, v, r, q)
            } else y ? v = y : v = u;
            v != null && v !== u && A.setLinkedRecords(v, h);
            if (w && t)
                if (f.after == null && f.before == null) w.copyFieldsFrom(t);
                else if (f.before != null || f.after == null && f.last) {
                w.setValue(!!t.getValue(p), p);
                b = t.getValue(g);
                typeof b === "string" && w.setValue(b, g)
            } else if (f.after != null || f.before == null && f.first) {
                w.setValue(!!t.getValue(o), o);
                e = t.getValue(n);
                typeof e === "string" && w.setValue(e, n)
            }
        }
    }

    function b(a, b, c) {
        b = d("relay-runtime").getRelayHandleKey(h, b, null);
        return a.getLinkedRecord(b, c)
    }

    function j(a, b, e) {
        if (e == null) return e;
        var f = d("relay-runtime").ConnectionInterface.get(),
            g = f.EDGES;
        f = f.NODE;
        var h = b.getValue(i);
        if (typeof h !== "number") throw c("unrecoverableViolation")("CometNotificationsThinClientConnectionHandler: Expected edgeIndex to be a number", "Notifications");
        g = d("relay-runtime").generateClientID(b.getDataID(), g, h);
        var j = e.getLinkedRecord(f);
        if (j) {
            var k = d("relay-runtime").generateClientID(e.getDataID(), f, h);
            k = a.create(k, j.getType());
            k.copyFieldsFrom(j);
            e.setLinkedRecord(k, f)
        }
        j = a.create(g, e.getType());
        j.copyFieldsFrom(e);
        b.setValue(h + 1, i);
        return j
    }

    function k(a, b, c) {
        var e = d("relay-runtime").ConnectionInterface.get();
        e = e.NODE;
        for (var f = 0; f < a.length; f++) {
            var g = a[f];
            if (!g) continue;
            var h = g.getLinkedRecord(e);
            h = h && h.getDataID();
            if (h != null) {
                if (c.has(h)) continue;
                c.add(h)
            }
            b.push(g)
        }
    }

    function l(a) {
        var b = {},
            c = d("relay-runtime").ConnectionInterface.get();
        c = c.NODE;
        for (var e = 0; e < a.length; e++) {
            var f = a[e];
            if (!f) continue;
            f = f.getLinkedRecord(c);
            var g = f && f.getType();
            if (g === "NotifPageNotificationRow") {
                g = f == null ? void 0 : (g = f.getLinkedRecord("notif")) == null ? void 0 : g.getValue("id");
                typeof g === "string" && (b[g] = f)
            }
        }
        return b
    }

    function m(a, b, c, e) {
        var f = d("relay-runtime").ConnectionInterface.get();
        f = f.NODE;
        for (var g = 0; g < a.length; g++) {
            var h, i = a[g];
            if (!i) continue;
            var j = i.getLinkedRecord(f),
                k = j && j.getDataID();
            if (k != null) {
                if (e.has(k)) continue;
                e.add(k)
            }
            k = j == null ? void 0 : j.getType();
            h = j == null ? void 0 : (h = j.getLinkedRecord("notif")) == null ? void 0 : h.getValue("id");
            if (j && k === "NotifPageCachedNotificationRow") {
                if (typeof h === "string") {
                    k = c[h];
                    k && (k.copyFieldsFrom(j), i.setLinkedRecord(k, f), b.push(i))
                }
            } else b.push(i)
        }
    }
    g.update = a;
    g.getConnection = b;
    g.buildConnectionEdge = j
}), 98);
__d("PinnedCommentEventsConnectionHandler", ["expectationViolation", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        a = a.get(b.dataID);
        if (!a) return;
        var c = a.getLinkedRecords(b.fieldKey);
        if (!c) {
            a.setValue(null, b.handleKey);
            return
        }
        var d = a.getLinkedRecords(b.handleKey);
        if (!d) {
            a.setLinkedRecords(c, b.handleKey);
            return
        }
        var e;
        d == null ? e = c : c == null ? e = d : e = h(d, c);
        a.setLinkedRecords((d = e) != null ? d : [], b.handleKey)
    }

    function h(a, b) {
        var d = 0,
            e = 0,
            f = new Set(),
            g = [],
            h = function(a) {
                var b = a == null ? void 0 : a.getValue("id");
                if (b == null) {
                    c("expectationViolation")("Pinned Comment Event should have id");
                    return
                }
                if (f.has(b)) return;
                f.add(b);
                g.push(a)
            };
        while (d < a.length && e < b.length) {
            var i, j;
            i = (i = a[d]) == null ? void 0 : i.getValue("vod_time_offset");
            j = (j = b[e]) == null ? void 0 : j.getValue("vod_time_offset");
            if (typeof i != "number") {
                d++;
                continue
            }
            if (typeof j != "number") {
                e++;
                continue
            }
            if (i > j) {
                h(a[d]);
                d++;
                continue
            }
            if (i < j) {
                h(b[e]);
                e++;
                continue
            }
            h(a[d]);
            h(b[e]);
            d++;
            e++
        }
        for (var i = d; i < a.length; i++) h(a[i]);
        for (var j = e; j < b.length; j++) h(b[j]);
        return g
    }

    function i(a) {
        return d("relay-runtime").getRelayHandleKey("pinned_comment_events", a, null)
    }

    function j(a, b, c) {
        return (a = a.getLinkedRecords(i(b), c)) != null ? a : []
    }

    function b(a, b, c, d) {
        a.setLinkedRecords(j(a, b, d).filter(function(a) {
            return (a == null ? void 0 : a.getValue("id")) !== c
        }), i(b));
        return
    }
    g.update = a;
    g.getEvents = j;
    g.deleteEvent = b
}), 98);
__d("mergeCommentEdgesSortedByTimestampInVideo", ["expectationViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
        a = a == null ? void 0 : (a = a.getLinkedRecord("node")) == null ? void 0 : a.getValue("timestamp_in_video");
        return typeof a !== "number" ? null : a
    };

    function a(a, b) {
        var d = 0,
            e = 0,
            f = new Set(),
            g = [],
            i = function(a) {
                var b;
                b = a == null ? void 0 : (b = a.getLinkedRecord("node")) == null ? void 0 : b.getValue("id");
                if (b == null) {
                    c("expectationViolation")("Node should have id");
                    return
                }
                if (f.has(b)) return;
                f.add(b);
                g.push(a)
            };
        while (d < a.length && e < b.length) {
            var j = h(a[d]),
                k = h(b[e]);
            if (j == null) {
                d++;
                continue
            }
            if (k == null) {
                e++;
                continue
            }
            if (j < k) {
                i(a[d]);
                d++;
                continue
            }
            if (j > k) {
                i(b[e]);
                e++;
                continue
            }
            i(a[d]);
            i(b[e]);
            d++;
            e++
        }
        for (var j = d; j < a.length; j++) i(a[j]);
        for (var k = e; k < b.length; k++) i(b[k]);
        return g
    }
    g["default"] = a
}), 98);
__d("VideoTimestampedCommentsConnectionHandler", ["mergeCommentEdgesSortedByTimestampInVideo", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var e = a.get(b.dataID);
        if (!e) return;
        var f = e.getLinkedRecord(b.fieldKey);
        if (!f) {
            e.setValue(null, b.handleKey);
            return
        }
        var g = e.getLinkedRecord(b.handleKey);
        if (!g) {
            a = a.create(d("relay-runtime").generateClientID(e.getDataID(), b.handleKey), f.getType());
            a.copyFieldsFrom(f);
            e.setLinkedRecord(a, b.handleKey);
            return
        }
        e = f.getLinkedRecords("edges");
        a = g.getLinkedRecords("edges");
        a == null ? b = e : e == null ? b = a : b = c("mergeCommentEdgesSortedByTimestampInVideo")(a, e);
        g.setLinkedRecords((f = b) != null ? f : [], "edges")
    }

    function b(a, b, c) {
        b = d("relay-runtime").getRelayHandleKey("video_timestamped_comments", b, null);
        return a.getLinkedRecord(b, c)
    }

    function e(a, b) {
        var d = a.getLinkedRecords("edges");
        if (!d) {
            a.setLinkedRecords([b], "edges");
            return
        }
        d = c("mergeCommentEdgesSortedByTimestampInVideo")(d, [b]);
        a.setLinkedRecords((b = d) != null ? b : [], "edges");
        return
    }
    g.update = a;
    g.getConnection = b;
    g.insertEdge = e
}), 98);
__d("cometHandlerProvider", ["BizKitNotificationsThinClientConnectionHandler", "CometNewsFeedConnectionHandler", "CometNotificationsThinClientConnectionHandler", "PinnedCommentEventsConnectionHandler", "UFI2CommentsConnectionHandler", "VideoTimestampedCommentsConnectionHandler", "relay-runtime", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        switch (a) {
            case "connection":
                return d("relay-runtime").ConnectionHandler;
            case "video_timestamped_comments":
                return d("VideoTimestampedCommentsConnectionHandler");
            case "pinned_comment_events":
                return d("PinnedCommentEventsConnectionHandler");
            case "ufi2_comments":
                return d("UFI2CommentsConnectionHandler");
            case "comet_news_feed":
                return d("CometNewsFeedConnectionHandler");
            case "comet_notifications_thin_client":
                return d("CometNotificationsThinClientConnectionHandler");
            case "bizkit_notifications_thin_client":
                return d("BizKitNotificationsThinClientConnectionHandler");
            case "deleteRecord":
                return d("relay-runtime").MutationHandlers.DeleteRecordHandler;
            case "appendEdge":
                return d("relay-runtime").MutationHandlers.AppendEdgeHandler;
            case "prependEdge":
                return d("relay-runtime").MutationHandlers.PrependEdgeHandler;
            case "deleteEdge":
                return d("relay-runtime").MutationHandlers.DeleteEdgeHandler;
            case "appendNode":
                return d("relay-runtime").MutationHandlers.AppendNodeHandler;
            case "prependNode":
                return d("relay-runtime").MutationHandlers.PrependNodeHandler
        }
        throw c("unrecoverableViolation")("RelayCometEnvironment: No handler defined for `" + a + "`.", "comet_ui")
    }
    g["default"] = a
}), 98);
__d("OneTraceQPLLogger", ["QuickPerformanceLogger", "performanceNavigationStart", "performanceNow"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
            CANCEL: 4,
            ERROR: 87,
            FAIL: 3,
            OFFLINE: 160,
            START: 1,
            SUCCESS: 2,
            TIMEOUT: 113
        },
        i = c("performanceNavigationStart")();

    function a(a, b) {
        if (a == null) return;
        c("QuickPerformanceLogger").markerStart(a, b.instanceKey, b.startTime + i)
    }

    function b(a, b) {
        if (a == null) return;
        c("QuickPerformanceLogger").markerAnnotate(a, b.annotations, {
            instanceKey: b.instanceKey
        });
        for (var d in b.markerPoints) c("QuickPerformanceLogger").markerPoint(a, d, {
            data: b.markerPoints[d].data,
            instanceKey: b.instanceKey,
            timestamp: b.markerPoints[d].timeSinceStart + i
        });
        d = h[b.status];
        c("QuickPerformanceLogger").markerEnd(a, d, b.instanceKey, ((a = b.endTime) != null ? a : c("performanceNow")()) + i)
    }
    g.qplActionMap = h;
    g.initQPL = a;
    g.logQPL = b
}), 98);
__d("InteractionTracingConfigDefault", ["OneTraceQPLLogger", "SiteData", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = 6e4;
    b = {
        defaultTracePolicy: "default",
        enableMemoryLogging: c("gkx")("1475"),
        logLateMutationReactStack: c("gkx")("1914427"),
        logVCReactStack: c("gkx")("1778371"),
        heroLatePlaceholderDetection: c("gkx")("4638"),
        heroDebugTracing: c("gkx")("4639"),
        pkgCohort: c("SiteData").pkg_cohort,
        timeout: a,
        qplActionMap: d("OneTraceQPLLogger").qplActionMap,
        useDocumentBodyForVCRoot: !0,
        navigationCancelsInteractions: !1,
        heroNestedRootsFix: c("gkx")("8428")
    };
    g.DEFAULT_TRACING_CONFIG = b
}), 98);
__d("InteractionTracing", ["InteractionTracingConfigDefault", "InteractionTracingMetrics", "WebSession", "cr:70", "interaction-tracing"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var c = a.cfg;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["cfg"]);
        return babelHelpers["extends"]({}, a, {
            cfg: babelHelpers["extends"]({}, d("InteractionTracingConfigDefault").DEFAULT_TRACING_CONFIG, c),
            deps: b("cr:70")
        })
    }
    a = babelHelpers["extends"]({}, c("interaction-tracing").InteractionTracingCore, {
        transformStartMetadata: h,
        startInteraction: function(a, b) {
            return c("interaction-tracing").InteractionTracingCore.startInteraction(h(a), b)
        },
        trace: function(a) {
            function b(b, c, d, e, f, g, h, i, j) {
                return a.apply(this, arguments)
            }
            b.toString = function() {
                return a.toString()
            };
            return b
        }(function(a, e, f, g, h, i, j, k, l) {
            l = c("interaction-tracing").InteractionTracingCore.trace(babelHelpers["extends"]({}, d("InteractionTracingConfigDefault").DEFAULT_TRACING_CONFIG, l), b("cr:70"), a, e, f, g, h, i, j, k);
            a = d("WebSession").getSessionId();
            a != null && c("InteractionTracingMetrics").addMetadata(l, "websession_id", a);
            return l
        }),
        logServerTimings: function(a, d, e) {
            c("interaction-tracing").logServerTimings(b("cr:70"), a, d, e)
        },
        navigation: c("interaction-tracing").NavigationTracing
    });
    g["default"] = a
}), 98);
__d("CometRelayFlightEventLogger", ["InteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map();

    function a(a) {
        a.name === "execute.start" && a.params.name === "MarketplacePDPContainerQuery" && h.set(a.executeId, {
            totalDuration: 0,
            totalFlightPayloadDeserializeDuration: 0,
            totalModuleDuration: 0,
            totalPayloadDuration: 0
        });
        if (a.executeId != null && !h.has(a.executeId)) return;
        if (a.name === "execute.next") {
            var b = h.get(a.executeId);
            b && (b.totalDuration += a.duration, b.totalPayloadDuration += a.duration)
        }
        if (a.name === "execute.async.module") {
            b = h.get(a.executeId);
            b && (b.totalDuration += a.duration, b.totalModuleDuration += a.duration)
        }
        if (a.name === "execute.flight.payload_deserialize") {
            b = h.get(a.executeId);
            b && (b.totalFlightPayloadDeserializeDuration += a.duration)
        }
        if (a.name === "execute.complete") {
            b = h.get(a.executeId);
            if (b) {
                var d = b.totalDuration,
                    e = b.totalFlightPayloadDeserializeDuration,
                    f = b.totalModuleDuration,
                    g = b.totalPayloadDuration;
                c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                    a.addAnnotationInt("MarketplacePDPContainerQueryModuleProcessingSuccessDuration", f), a.addAnnotationInt("MarketplacePDPContainerQueryPayloadProcessingSuccessDuration", g), a.addAnnotationInt("MarketplacePDPContainerQueryFlightDeserializationSuccessDuration", e), a.addAnnotationInt("MarketplacePDPContainerQueryRelayProcessingSuccessDuration", d)
                })
            }
            h["delete"](a.executeId)
        }
        a.name === "execute.error" && h["delete"](a.executeId)
    }
    g.log = a
}), 98);
__d("CometRelayPerfStore", ["ExecutionEnvironment", "performanceNow", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 5 * 6e4,
        i = {},
        j = {},
        k = {};

    function a(a) {
        if (!c("ExecutionEnvironment").canUseDOM) return;
        if (a.name === "network.start") {
            var b = {
                flushes: [],
                hasteResponseLogEvents: [],
                name: a.params.name,
                start: c("performanceNow")()
            };
            j[a.networkRequestId] = b;
            i[a.params.name] = b;
            c("setTimeout")(function() {
                delete j[a.networkRequestId], b && delete i[b.name]
            }, h)
        } else if (a.name === "network.next") {
            var d = j[a.networkRequestId];
            if (d) {
                var e = a.response,
                    f = function(a) {
                        d.flushes.push({
                            label: (a = a.label) != null ? a : "root",
                            time: c("performanceNow")()
                        })
                    };
                e instanceof Array ? e.forEach(f) : f(e)
            }
        } else if (a.name === "network.complete") {
            f = j[a.networkRequestId];
            f && (f.end = c("performanceNow")())
        } else if (a.name === "queryresource.fetch") {
            if (a.operation.root.node.name != null) {
                e = a.operation.root.node.name;
                f = i[e];
                f != null && (k[a.resourceID] = f, c("setTimeout")(function() {
                    delete k[a.resourceID]
                }, h))
            }
        } else if (a.name === "queryresource.retain") {
            e = k[a.resourceID];
            if (e != null) {
                f = a.profilerContext;
                f.retainQuery && f.retainQuery(e)
            }
        } else if (a.name === "network.info") {
            f = a.info;
            if (f != null && typeof f === "object" && Object.prototype.hasOwnProperty.call(f, "prefetched")) {
                e = j[a.networkRequestId];
                e && (e.start = 0)
            }
            if (f != null && typeof f === "object" && "srPayloadStats" in f && f.srPayloadStats != null && typeof f.srPayloadStats === "object") {
                e = j[a.networkRequestId];
                e && e.hasteResponseLogEvents.push(f.srPayloadStats)
            }
        } else if (a.name === "entrypoint.root.consume") {
            e = a.profilerContext;
            typeof e.consumeBootload === "function" && e.consumeBootload(a.rootModuleID)
        }
    }
    g.log = a
}), 98);
__d("OzSystemicRiskUtils", ["oz-player/networks/OzBandwidthUtils"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 50;

    function i(a, b, c) {
        a = d("oz-player/networks/OzBandwidthUtils").getEstimatedRequestTimeToLastByteMs(a, b, c);
        return b / a * 8e3
    }

    function a(a, b, c, d) {
        a = a * b;
        b = a * c / 8e3;
        c = i(d, b, h);
        return a < c
    }

    function j(a, b, c, d) {
        if (a > 0) return c <= a;
        return d != null && d > 0 ? d <= b : !1
    }

    function b(a) {
        var b = a.bandwidthDiagnostics,
            c = a.bitrate,
            d = a.bufferAhead,
            e = a.config,
            f = a.hasMadeInitialDecision,
            g = a.initialRiskFactor,
            k = a.lowMosResolution,
            l = a.minWatchableMos,
            m = a.previousMos,
            n = a.previousResolution,
            o = a.remainingVideoDurationMs;
        a = a.segmentFetchRangeDurationMs;
        c = c * a / 8e3;
        a = i(b, c, e.getNumber("systemic_risk_abr_high_estimate_confidence", 52));
        b = i(b, c, h);
        c = j(k, l, n, m);
        k = 1;
        c || (k = b / a);
        l = f || c ? 1 : g;
        b = l * (c ? e.getNumber("systemic_risk_abr_low_mos_risk_factor", 1.3) : e.getNumber("systemic_risk_abr_risk_factor", 1.75));
        a = (o - d * 1e3) / o;
        f = b * k;
        g = f * a;
        l = Math.max(g, 1);
        return {
            bandwidth: k,
            buffer: a,
            encoding: b,
            lowMos: c,
            multiplier: l,
            previousMos: m,
            previousResolution: n
        }
    }
    g.getBandwidthEstimateForRequest = i;
    g.isEffectiveBitrateBelowBandwidthEstimate = a;
    g.getRiskFactorsForRepresentation = b
}), 98);
__d("CometDASHPrefetchCache", ["ConstUriUtils", "MosUtils", "OzSystemicRiskUtils", "clearTimeout", "oz-player/configs/OzGlobalConfig", "oz-player/networks/OzBandwidthEstimator", "oz-player/parsers/getMIMECodecs", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 6e4,
        i = 2e3,
        j = 500;
    a = function() {
        function a() {
            this.$1 = new Map()
        }
        var b = a.prototype;
        b.fetch = function(a) {
            this.$1.size === 0 && (this.$2(a), this.$3(a))
        };
        b.clear = function() {
            var a = this;
            this.$1.forEach(function(b, c) {
                a.$4(c)
            });
            this.$1.clear()
        };
        b.hasCacheValue = function(a) {
            return this.$1.has(a)
        };
        b.getCacheValue = function(a) {
            var b = this.$1.get(a);
            b && (this.$4(a), this.$1["delete"](a));
            return b == null ? void 0 : b.request
        };
        b.getCachedRepresentations = function() {
            var a = [];
            this.$1.forEach(function(b) {
                b = b.representationID;
                a.indexOf(b) === -1 && a.push(b)
            });
            return a
        };
        b.$4 = function(a) {
            a = this.$1.get(a);
            a && a.cancelTimeoutID != null && c("clearTimeout")(a.cancelTimeoutID)
        };
        b.$3 = function(a) {
            a = a.find(function(a) {
                return a.mimeType.indexOf("audio") > -1
            });
            if (a == null) return;
            this.$5(a)
        };
        b.$2 = function(a) {
            a = a.filter(function(a) {
                return a.mimeType.indexOf("video") > -1
            });
            if (a.length === 0) return;
            var b = a[0];
            a.sort(function(a, b) {
                return a.bandwidth - b.bandwidth
            });
            a = this.$6(a);
            if (a.length === 0) return;
            var e = c("oz-player/networks/OzBandwidthEstimator").getBandwidthDiagnostics(c("oz-player/configs/OzGlobalConfig"));
            if (e == null) {
                this.$5(b);
                return
            }
            b = null;
            for (var f = 0; f < a.length; f++) {
                var g = a[Math.max(f - 1, 0)],
                    k = Math.min(g.height, g.width),
                    l = null,
                    m = c("oz-player/configs/OzGlobalConfig").getNumber("systemic_risk_abr_prefetch_low_mos_resolution", 0);
                if (c("oz-player/configs/OzGlobalConfig").getBool("systemic_risk_abr_parse_prefetch_mos", !1)) {
                    g = d("MosUtils").parsePlaybackMos(g.playbackResolutionMOS);
                    g != null && (l = d("MosUtils").getMosValue(g, j), m = 0)
                }
                g = d("OzSystemicRiskUtils").getRiskFactorsForRepresentation({
                    bandwidthDiagnostics: e,
                    bitrate: a[f].bandwidth,
                    bufferAhead: 0,
                    config: c("oz-player/configs/OzGlobalConfig"),
                    hasMadeInitialDecision: !1,
                    initialRiskFactor: c("oz-player/configs/OzGlobalConfig").getNumber("systemic_risk_abr_prefetch_initial_risk_factor", 1),
                    lowMosResolution: m,
                    minWatchableMos: c("oz-player/configs/OzGlobalConfig").getNumber("systemic_risk_abr_min_watchable_mos", 0),
                    previousMos: l,
                    previousResolution: k,
                    remainingVideoDurationMs: h,
                    segmentFetchRangeDurationMs: i
                });
                m = g.multiplier;
                if (isNaN(m)) break;
                l = d("OzSystemicRiskUtils").isEffectiveBitrateBelowBandwidthEstimate(a[f].bandwidth, m, i, e);
                if (l) b = a[f];
                else break
            }
            g = (k = b) != null ? k : a[0];
            this.$5(g)
        };
        b.$5 = function(a) {
            var b = this;
            a.segments.forEach(function(c) {
                c = b.$7(a.baseURL, c);
                if (c == null) return;
                var d = window.fetch(c).then(function(a) {
                    return {
                        initiator: "FETCH",
                        response: a
                    }
                });
                d = d["catch"](function() {});
                b.$8(c, {
                    representationID: a.representationID,
                    request: d
                })
            })
        };
        b.$8 = function(a, b) {
            var d = this;
            this.$4(a);
            var e = c("oz-player/configs/OzGlobalConfig").getNumber("prefetch_retention_duration_ms", 0),
                f = null;
            e > 0 && (f = c("setTimeout")(function() {
                d.$1["delete"](a)
            }, e));
            this.$1.set(a, babelHelpers["extends"]({}, b, {
                cancelTimeoutID: f
            }))
        };
        b.$7 = function(a, b) {
            return (a = d("ConstUriUtils").getUri(a)) == null ? void 0 : (a = a.addQueryParam("bytestart", b.start)) == null ? void 0 : (a = a.addQueryParam("byteend", b.end)) == null ? void 0 : a.toString()
        };
        b.$6 = function(a) {
            var b;
            a = a.filter(function(a) {
                var b;
                return (b = window.MediaSource) == null ? void 0 : b.isTypeSupported(c("oz-player/parsers/getMIMECodecs")(a.mimeType, a.codecs))
            });
            var d = (b = window.devicePixelRatio) != null ? b : 1,
                e = c("oz-player/configs/OzGlobalConfig").getNumber("prefetch_resolution_threshold", 0);
            e === 0 && (e = Infinity);
            b = a.filter(function(a) {
                a = Math.min(a.width, a.height);
                return a / d <= e
            });
            return b.length > 0 ? b : a.length > 0 ? [a[0]] : []
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("RunComet", ["ExecutionEnvironment", "FBLogger", "createCancelableFunction", "emptyFunction", "recoverableViolation", "setTimeout", "unexpectedUseInComet"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {},
        i = !1,
        j = !1,
        k = {
            remove: c("emptyFunction")
        };

    function l(a, b) {
        h.unload == null && (h.unload = [], h.afterunload = [], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("unload", function() {
            o("unload"), o("afterunload")
        })), h[a] == null ? (c("recoverableViolation")("EVENT_LISTENERS." + a + " wasn't initialized but should have been!", "comet_infra"), h[a] = [b]) : h[a].push(b)
    }

    function m(a) {
        a || c("recoverableViolation")("Undefined event listener handler is not allowed", "comet_infra");
        return c("createCancelableFunction")((a = a) != null ? a : c("emptyFunction"))
    }

    function n(a) {
        return {
            remove: function() {
                a.cancel()
            }
        }
    }

    function o(a) {
        var b = h[a] || [];
        for (var d = 0; d < b.length; d++) {
            var e = b[d];
            try {
                e()
            } catch (b) {
                c("FBLogger")("comet_infra").catching(b).mustfix("Hit an error while executing '" + a + "' event listeners.")
            }
        }
        h[a] = []
    }

    function p(a) {
        if (i) {
            a();
            return n(m(c("emptyFunction")))
        }
        a = m(a);
        h.domcontentloaded == null ? (h.domcontentloaded = [a], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("DOMContentLoaded", function() {
            o("domcontentloaded")
        }, !0)) : h.domcontentloaded.push(a);
        return n(a)
    }

    function a(a) {
        a = m(a);
        l("afterunload", a);
        return n(a)
    }

    function b(a) {
        a = m(a);
        h.load == null ? (h.load = [a], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("load", function() {
            o("domcontentloaded"), o("load")
        })) : h.load.push(a);
        j && c("setTimeout")(function() {
            o("domcontentloaded"), o("load")
        }, 0);
        return n(a)
    }

    function d(a) {
        a = m(a);
        l("unload", a);
        return n(a)
    }

    function e(a, b) {
        if (b !== !1) {
            b = "Run.onBeforeUnload was called with include_quickling_events as true or undefined, but this is not valid in Comet.";
            c("FBLogger")("comet_infra").blameToPreviousFrame().mustfix(b)
        }
        b = m(a);
        h.beforeunload == null && (h.beforeunload = [], c("ExecutionEnvironment").canUseEventListeners && window.addEventListener("beforeunload", function(a) {
            var b = h.beforeunload || [];
            for (var b = b, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (d) {
                    if (e >= b.length) break;
                    f = b[e++]
                } else {
                    e = b.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                var g = void 0;
                try {
                    g = f()
                } catch (a) {
                    c("FBLogger")("comet_infra").catching(a).mustfix("Hit an error while executing onBeforeUnload event listeners.")
                }
                if (g !== void 0) {
                    g != null && g.body != null && (g = g.body);
                    a.preventDefault();
                    a.returnValue = g;
                    return g
                }
            }
        }));
        h.beforeunload.push(b);
        return n(b)
    }
    var q = e;

    function f(a) {
        c("unexpectedUseInComet")("Run.onLeave");
        return k
    }

    function r(a, b) {
        c("unexpectedUseInComet")("Run.onCleanupOrLeave");
        return k
    }

    function s(a) {
        c("unexpectedUseInComet")("Run.removeHook")
    }

    function t() {
        document.readyState === "loading" ? p(function() {
            i = !0
        }) : i = !0;
        if (document.readyState === "complete") j = !0;
        else {
            var a = window.onload;
            window.onload = function() {
                a && a(), j = !0
            }
        }
    }
    c("ExecutionEnvironment").canUseDOM && t();
    t = null;
    var u = null;
    g.onLoad = p;
    g.onAfterUnload = a;
    g.onAfterLoad = b;
    g.onUnload = d;
    g.onBeforeUnload = e;
    g.maybeOnBeforeUnload = q;
    g.onLeave = f;
    g.onCleanupOrLeave = r;
    g.__removeHook = s;
    g.__domContentCallback = t;
    g.__onloadCallback = u
}), 98);
__d("CometDASHPrefetchCacheManager", ["CometDASHPrefetchCache", "RunComet", "oz-player/configs/OzGlobalConfig"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            var a = this;
            this.$1 = new Map();
            c("oz-player/configs/OzGlobalConfig").getBool("clear_prefetch_on_unload", !1) && d("RunComet").onUnload(function() {
                a.$1.forEach(function(a) {
                    a.clear()
                })
            })
        }
        var b = a.prototype;
        b.fetch = function(a, b) {
            var d = this.$1.get(a),
                e = c("oz-player/configs/OzGlobalConfig").getBool("allow_subsequent_prefetch", !1);
            d || (d = new(c("CometDASHPrefetchCache"))(), this.$1.set(a, d), e || d.fetch(b));
            e && d.fetch(b)
        };
        b.get = function(a) {
            return this.$1.get(a)
        };
        return a
    }();
    b = new a();
    e = b;
    g["default"] = e
}), 98);
__d("cometPrefetchVideoDashV2", ["CometDASHPrefetchCacheManager"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (window.__comet_ssr_is_server_env_DO_NOT_USE === !0) return;
        c("CometDASHPrefetchCacheManager") != null && a != null && Array.isArray(a) && a.forEach(function(a) {
            if (a != null && a.video_id != null) {
                var b = String(a.video_id),
                    d = [];
                Array.isArray(a.representations) && a.representations.forEach(function(a) {
                    var b = [];
                    if (a != null && Array.isArray(a.segments) && typeof a.representation_id === "string" && typeof a.mime_type === "string" && typeof a.codecs === "string" && typeof a.bandwidth === "number" && typeof a.width === "number" && typeof a.height === "number" && typeof a.base_url === "string" && typeof a.playback_resolution_mos === "string") {
                        var c = {
                            bandwidth: a.bandwidth,
                            baseURL: a.base_url,
                            codecs: a.codecs,
                            height: a.height,
                            mimeType: a.mime_type,
                            playbackResolutionMOS: a.playback_resolution_mos,
                            representationID: a.representation_id,
                            segments: [],
                            width: a.width
                        };
                        a.segments.forEach(function(a) {
                            a != null && typeof a.start === "number" && typeof a.end === "number" && b.push({
                                end: a.end,
                                start: a.start
                            })
                        });
                        b.length > 0 && (c.segments = b, d.push(c))
                    }
                });
                d.length > 0 && c("CometDASHPrefetchCacheManager").fetch(b, d)
            }
        })
    }
    b = a;
    g["default"] = b
}), 98);
__d("SilenceableErrorMessageUtils", ["killswitch"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        return c("killswitch")("COMET_HIDE_SILENT_ERROR_MESSAGE") ? !1 : a.is_silent === !0
    }

    function i(a) {
        if (typeof a === "object" && a instanceof Error) {
            var b = a.description,
                c = a.message,
                d = a.source;
            return {
                code: d == null ? void 0 : d.code,
                is_silent: d == null ? void 0 : d.is_silent,
                message: (d = b) != null ? d : c,
                timestamp: Date.now()
            }
        }
        return {
            is_silent: (b = a.source) == null ? void 0 : b.is_silent,
            message: a.description
        }
    }

    function a(a, b) {
        var c, d = a.description,
            e = a.message,
            f = a.source;
        c = (f = (c = (c = f == null ? void 0 : (c = f.exception) == null ? void 0 : c.message) != null ? c : f == null ? void 0 : f.description) != null ? c : d) != null ? f : e;
        h(i(a)) && b(c)
    }
    g.shouldHideErrorMessage = h;
    g.getMetadataFromError = i;
    g.handleSilentError = a
}), 98);
__d("CometRelayErrorHandling", ["errorCode", "SilenceableErrorMessageUtils"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i;
    try {
        i = new WeakMap()
    } catch (a) {
        i = null
    }

    function a(a) {
        var b;
        (b = i) == null ? void 0 : b.set(a, !0)
    }

    function b(a) {
        var b, c = a == null ? void 0 : a.source;
        b = (b = c == null ? void 0 : c.errorCode) != null ? b : c == null ? void 0 : c.code;
        if (b === 1357001) return !1;
        return b === 1675030 ? !0 : ((c = i) == null ? void 0 : c.get(a)) === !0 || d("SilenceableErrorMessageUtils").shouldHideErrorMessage(d("SilenceableErrorMessageUtils").getMetadataFromError(a))
    }
    g.markErrorAsHandled = a;
    g.shouldSkipErrorSideEffects = b
}), 98);
__d("cometWrapWithRetryOnError", ["relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return d("relay-runtime").Observable.create(function(c) {
            var d, e = function e() {
                d = a.subscribe({
                    complete: c.complete,
                    error: function(a) {
                        var d = function(b) {
                            c.error((b = b) != null ? b : a)
                        };
                        d = b(a, e, d);
                        d || c.error(a)
                    },
                    next: c.next
                })
            };
            e();
            return function() {
                return d.unsubscribe()
            }
        })
    }
    g["default"] = a
}), 98);
__d("cometWrapNetworkObservable", ["CometRelayErrorHandling", "cometWrapWithRetryOnError", "cr:1196", "cr:641", "gkx", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        if (!b("cr:641")) return function(a) {
            return a
        };
        else return function(a) {
            return d("relay-runtime").Observable.create(function(e) {
                return h(a).subscribe({
                    complete: e.complete,
                    error: function(a) {
                        var f, g, h, i = e.error(a);
                        if (d("CometRelayErrorHandling").shouldSkipErrorSideEffects(a)) return i;
                        a = a == null ? void 0 : a.source;
                        f = (f = (f = a == null ? void 0 : a.errorCode) != null ? f : a == null ? void 0 : a.code) != null ? f : a == null ? void 0 : a.error;
                        g = (g = a == null ? void 0 : a.errorDescription) != null ? g : a == null ? void 0 : a.description;
                        h = (h = a == null ? void 0 : a.errorSummary) != null ? h : a == null ? void 0 : a.summary;
                        var j = null;
                        if (c("gkx")("2581")) {
                            var k;
                            j = (k = a == null ? void 0 : a.debug_info) != null ? k : a == null ? void 0 : a.message;
                            g === j && (j = null)
                        }
                        f && h && g && b("cr:641")(f, h, g, a == null ? void 0 : a.redirectTo, !0, j);
                        return i
                    },
                    next: function(a) {
                        if (Array.isArray(a))
                            for (var b = a, c = Array.isArray(b), d = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                var f;
                                if (c) {
                                    if (d >= b.length) break;
                                    f = b[d++]
                                } else {
                                    d = b.next();
                                    if (d.done) break;
                                    f = d.value
                                }
                                f = f;
                                f = i(f);
                                if (f != null) {
                                    e.error(f);
                                    return
                                }
                            } else {
                                f = i(a);
                                if (f != null) {
                                    e.error(f);
                                    return
                                }
                            }
                        e.next(a)
                    }
                })
            })
        }
    }

    function h(a) {
        return !b("cr:1196") ? a : c("cometWrapWithRetryOnError")(a, b("cr:1196"))
    }

    function i(a) {
        var b = a.data;
        a = Object.prototype.hasOwnProperty.call(a, "errors") ? a.errors : void 0;
        if (Array.isArray(a))
            for (var a = a, c = Array.isArray(a), e = 0, a = c ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f;
                if (c) {
                    if (e >= a.length) break;
                    f = a[e++]
                } else {
                    e = a.next();
                    if (e.done) break;
                    f = e.value
                }
                f = f;
                if (f != null && typeof f === "object" && (f.severity === "CRITICAL" || f.severity === "ERROR") && Array.isArray(f.path) && f.path.length === 3 && f.path[0] === "viewer" && f.path[1] === "news_feed" && f.path[2] === "edges") {
                    f = b == null ? void 0 : (f = b.viewer) == null ? void 0 : f.news_feed;
                    var g = f == null ? void 0 : f.edges;
                    if (f != null && (g == null || Array.isArray(g) && g.length === 0)) return d("relay-runtime").RelayError.create("CometNewsFeed", "Error evaluating Comet News Feed, edges cannot be resolved.")
                }
            }
    }
    g["default"] = a
}), 98);
__d("createCometStore", ["CometRelayConfig", "RelayFBGCScheduler", "RelayFBOperationLoader", "cr:2928", "gkx", "qex", "relayFBGetDataID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("1151941");
    e = 1e3 * 60 * 15;
    var i = c("qex")._("1555") ? 3e4 : void 0;
    i != null && (i = Math.max(Math.min(i, e), 0));

    function a(a) {
        var e = new(b("cr:2928").RecordSource)();
        e = new(b("cr:2928").Store)(e, {
            gcReleaseBufferSize: d("CometRelayConfig").gc_release_buffer_size,
            gcScheduler: c("RelayFBGCScheduler"),
            getDataID: c("relayFBGetDataID"),
            log: a,
            operationLoader: c("RelayFBOperationLoader"),
            queryCacheExpirationTime: i
        });
        h || e.holdGC();
        return e
    }
    g["default"] = a
}), 98);
__d("GraphqlLiveQueryEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743656");
    c = b("FalcoLoggerInternal").create("graphql_live_query_event", a);
    e.exports = c
}), null);
__d("LiveQueryEventsLoggingResolver", ["GraphqlLiveQueryEventFalcoEvent", "Random", "RealtimeFrameworksCounterFalcoEvent", "gkx"], (function(a, b, c, d, e, f, g) {
    var h = "default",
        i = "without_sampling";

    function a() {
        if (c("gkx")("1133447")) return {
            force_log_context: i,
            sampling_rate: 1,
            client_has_ods_usecase_counters: !0
        };
        else if (d("Random").coinflip(1e4)) return {
            force_log_context: h,
            sampling_rate: 1e4,
            client_has_ods_usecase_counters: !0
        }
    }

    function b(a, b, d, e, f, g, h, i) {
        g != null && g.sampling_rate != null && c("GraphqlLiveQueryEventFalcoEvent").log(function() {
            return {
                event: a,
                event_source: "web",
                event_reason: b,
                config_id: e,
                doc_id_str: d,
                force_log_context: g.force_log_context,
                logging_sampling_rate: g.sampling_rate,
                live_query_request_id: f,
                error_info: h,
                initial_response_latency_ms: i
            }
        }), c("RealtimeFrameworksCounterFalcoEvent").log(function() {
            return {
                event: a,
                event_detail: b,
                use_case: e,
                use_case_type: "live_query"
            }
        })
    }
    g.tempResolveLoggingContext = a;
    g.logEvent = b
}), 98);
__d("RealtimeGraphQLRequest", ["invariant", "RTISubscriptionManagerConfig", "RequestStreamCommonRequestStreamCommonTypes", "TransportSelectingClientSingleton", "nullthrows", "regeneratorRuntime"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = function() {
        function a(a) {
            var b = this,
                e = a.method,
                f = a.doc_id,
                g = a.is_intern,
                i = a.extra_headers;
            a = a.body;
            this.$11 = function(a) {
                switch (a) {
                    case d("RequestStreamCommonRequestStreamCommonTypes").FlowStatus.Started:
                        if (b.$10) {
                            b.$9 != null || h(0, 13576);
                            a = Date.now() - c("nullthrows")(b.$9);
                            b.$7 != null && b.$7(a)
                        } else b.$10 = !0, b.$5 != null && b.$5();
                        break;
                    case d("RequestStreamCommonRequestStreamCommonTypes").FlowStatus.Stopped:
                        b.$9 = Date.now();
                        b.$6 != null && b.$6(!1, !1);
                        break;
                    default:
                        break
                }
            };
            this.$10 = !1;
            e = {
                method: e,
                doc_id: f
            };
            g = typeof g === "boolean" ? g : (f = c("RTISubscriptionManagerConfig").is_intern) != null ? f : !1;
            g && (e = babelHelpers["extends"]({}, e, {
                www_tier: "intern"
            }));
            i != null && (e = babelHelpers["extends"]({}, e, i));
            this.$1 = e;
            this.$2 = JSON.stringify(a)
        }
        var e = a.prototype;
        e.onResponse = function(a) {
            this.$3 = a;
            return this
        };
        e.onError = function(a) {
            this.$4 = a;
            return this
        };
        e.onActive = function(a) {
            this.$5 = a;
            return this
        };
        e.onPause = function(a) {
            this.$6 = a;
            return this
        };
        e.onResume = function(a) {
            this.$7 = a;
            return this
        };
        e.onRetryUpdateRequestBody = function(a) {
            this.$8 = a;
            this.$1 = babelHelpers["extends"]({}, this.$1, {
                request_stream_retry: "false"
            });
            return this
        };
        e.send = function() {
            var a, d;
            return b("regeneratorRuntime").async(function(e) {
                while (1) switch (e.prev = e.next) {
                    case 0:
                        this.$3 != null || h(0, 33593);
                        a = {
                            onData: c("nullthrows")(this.$3)
                        };
                        this.$4 != null && (a = babelHelpers["extends"]({}, a, {
                            onTermination: this.$4
                        }));
                        a = babelHelpers["extends"]({}, a, {
                            onFlowStatus: this.$11
                        });
                        this.$8 != null && (a = babelHelpers["extends"]({}, a, {
                            onRetryUpdateRequestBody: this.$8
                        }));
                        e.next = 7;
                        return b("regeneratorRuntime").awrap(c("TransportSelectingClientSingleton").requestStream(this.$1, this.$2, a));
                    case 7:
                        d = e.sent;
                        return e.abrupt("return", {
                            cancel: function() {
                                d.cancel()
                            },
                            amendExperimental: function(a) {
                                try {
                                    d.amendWithoutAck(JSON.stringify(a));
                                    return !0
                                } catch (a) {
                                    return !1
                                }
                            }
                        });
                    case 9:
                    case "end":
                        return e.stop()
                }
            }, null, this)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("makeGraphQLLiveQueryRequest", ["RealtimeGraphQLRequest"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "FBLQ";

    function a(a) {
        var b = a.doc_id,
            d = a.config_id,
            e = a.live_query_request_id,
            f = a.actor_id,
            g = a.variables,
            i = a.is_intern,
            j = a.access_token,
            k = a.graphiql_impersonation,
            l = a.logging_context,
            m = a.last_response_digest,
            n = a.priming_token;
        a = a.enable_canonical_naming;
        var o = h + ":" + d;
        b = {
            method: o,
            doc_id: b,
            body: {
                variables: (o = g) != null ? o : {}
            }
        };
        i != null && (b = babelHelpers["extends"]({}, b, {
            is_intern: i
        }));
        g = {
            config_id: d,
            live_query_request_id: e
        };
        m != null && (g = babelHelpers["extends"]({}, g, {
            last_response_digest: m
        }));
        f != null && (g = babelHelpers["extends"]({}, g, {
            actor_id: f
        }));
        n != null && (g = babelHelpers["extends"]({}, g, {
            priming_token: n
        }));
        l != null && (g = babelHelpers["extends"]({}, g, {
            logging_context: l
        }));
        j != null && (g = babelHelpers["extends"]({}, g, {
            access_token: j
        }));
        k != null && (g = babelHelpers["extends"]({}, g, {
            graphiql_impersonation: k
        }));
        a === !0 && (g = babelHelpers["extends"]({}, g, {
            enable_canonical_naming: !0
        }));
        b = babelHelpers["extends"]({}, b, {
            extra_headers: g
        });
        return new(c("RealtimeGraphQLRequest"))(b)
    }
    f.exports = a
}), 34);
__d("liveQueryFetch", ["invariant", "LiveQueryEventsLoggingResolver", "LiveQueryWebRelayKillList", "RelayGraphQLRequestUtils", "RelayRuntime", "makeGraphQLLiveQueryRequest", "nullthrows", "promiseDone", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = b("RelayRuntime").Observable,
        i = b("RelayRuntime").RelayError;

    function a(a, c, d) {
        if (!l() || k(d.config_id)) return h.create(function(a) {
            a.complete();
            return
        });
        var e = Date.now(),
            f = 0;
        a.id != null || g(0, 13279);
        var m = j();
        a.metadata.live != null && (typeof a.metadata.live.live_query_request_id === "string" && (m = a.metadata.live.live_query_request_id), typeof a.metadata.live.timeStamp === "number" && (e = a.metadata.live.timeStamp));
        var n = {
            doc_id: b("nullthrows")(a.id),
            config_id: d.config_id,
            actor_id: d.actor_id,
            variables: c,
            live_query_request_id: m
        };
        d.access_token !== "" && (n = babelHelpers["extends"]({}, n, {
            access_token: d.access_token
        }));
        var o = b("LiveQueryEventsLoggingResolver").tempResolveLoggingContext();
        o != null && (o = babelHelpers["extends"]({}, o, {
            client_send_request_timestamp: e
        }), n = babelHelpers["extends"]({}, n, {
            logging_context: o
        }));
        return h.create(function(a) {
            var c = b("makeGraphQLLiveQueryRequest")(n).onResponse(function(c) {
                var d = Date.now(),
                    h;
                try {
                    h = b("RelayGraphQLRequestUtils").parsePayload(c), typeof h === "object" || g(0, 12937)
                } catch (c) {
                    b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_parsing_response", n.doc_id, n.config_id, m, o, c.message);
                    return a.error(c)
                }
                if (!("errors" in h) && !("data" in h)) {
                    b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_empty_response", n.doc_id, n.config_id, m, o, "Parsed network response is empty");
                    return a.error(i.createWarning("EmptyResponseError", "Parsed network response is empty"))
                }
                if (h.errors)
                    for (var c = h.errors, j = Array.isArray(c), k = 0, c = j ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var l;
                        if (j) {
                            if (k >= c.length) break;
                            l = c[k++]
                        } else {
                            k = c.next();
                            if (k.done) break;
                            l = k.value
                        }
                        l = l;
                        if (l.severity === "CRITICAL") {
                            l = b("RelayGraphQLRequestUtils").createErrorFromPayload(l);
                            b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_in_response", n.doc_id, n.config_id, m, o, l.message);
                            return a.error(l)
                        }
                    }
                f == 0 ? b("LiveQueryEventsLoggingResolver").logEvent("client_update", "live_query_initial", n.doc_id, n.config_id, m, o, null, d - e) : b("LiveQueryEventsLoggingResolver").logEvent("client_update", "regular_response_update", n.doc_id, n.config_id, m, o);
                f += 1;
                a.closed || a.next(h)
            }).onError(function(a) {
                b("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_received", n.doc_id, n.config_id, m, o, a.message)
            }).onActive(function() {
                b("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "initial_subscribe_request", n.doc_id, n.config_id, m, o)
            }).onPause(function(a, c) {
                b("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "subscription_paused", n.doc_id, n.config_id, m, o)
            }).onResume(function(a) {
                b("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "subscription_resumed", n.doc_id, n.config_id, m, o)
            }).send();
            return function() {
                b("promiseDone")(c, function(a) {
                    a.cancel(), b("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "regular_unsubscribe", n.doc_id, n.config_id, m, o)
                })
            }
        })
    }

    function j() {
        return b("uuid")()
    }

    function k(a) {
        for (var c = b("LiveQueryWebRelayKillList").liveQueryWebRelayKillList, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= c.length) break;
                f = c[e++]
            } else {
                e = c.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            if (a === f) return !0
        }
        return !1
    }

    function l() {
        return "WebSocket" in window
    }
    e.exports = a
}), null);
__d("liveQueryFetchWithWWWInitial", ["invariant", "LiveQueryEventsLoggingResolver", "LiveQueryWebRelayKillList", "RelayGraphQLRequestUtils", "RelayRuntime", "makeGraphQLLiveQueryRequest", "nullthrows", "promiseDone", "uuid"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, e, f) {
        if (!k() || j(e.config_id)) return f;
        var g = Date.now();
        a.id != null || h(0, 13279);
        var l = i();
        a.metadata.live != null && (typeof a.metadata.live.live_query_request_id === "string" && (l = a.metadata.live.live_query_request_id), typeof a.metadata.live.timeStamp === "number" && (g = a.metadata.live.timeStamp));
        var m = {
            doc_id: c("nullthrows")(a.id),
            config_id: e.config_id,
            actor_id: e.actor_id,
            variables: b,
            live_query_request_id: l
        };
        e.access_token !== "" && (m = babelHelpers["extends"]({}, m, {
            access_token: e.access_token
        }));
        var n = d("LiveQueryEventsLoggingResolver").tempResolveLoggingContext();
        n != null && (m = babelHelpers["extends"]({}, m, {
            logging_context: n
        }));
        return d("RelayRuntime").Observable.create(function(a) {
            var b = !1,
                e = null;
            f.subscribe({
                next: function(c) {
                    var e = Date.now();
                    if (c.extensions != null && c.extensions.is_final === !0) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_update", "www_initials_is_final", m.doc_id, m.config_id, l, n, null, e - g);
                        if (c.extensions != null && c.extensions.live_query != null) {
                            e = c.extensions.live_query;
                            typeof e.priming_token === "string" && (m = babelHelpers["extends"]({}, m, {
                                priming_token: e.priming_token
                            }));
                            typeof e.response_digest === "string" && (m = babelHelpers["extends"]({}, m, {
                                last_response_digest: e.response_digest
                            }));
                            typeof e.disable === "boolean" && (b = e.disable)
                        }
                    }
                    a.next(c)
                },
                error: function(b) {
                    a.error(b)
                },
                complete: function() {
                    if (b) {
                        a.complete();
                        return function() {}
                    }
                    e = c("makeGraphQLLiveQueryRequest")(m).onResponse(function(b) {
                        var e;
                        try {
                            e = c("RelayGraphQLRequestUtils").parsePayload(b), typeof e === "object" || h(0, 12937)
                        } catch (b) {
                            d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_parsing_response", m.doc_id, m.config_id, l, n, b.message);
                            return a.error(b)
                        }
                        if (!("errors" in e) && !("data" in e)) {
                            d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_empty_response", m.doc_id, m.config_id, l, n, "Parsed network response is empty");
                            return a.error(d("RelayRuntime").RelayError.createWarning("EmptyResponseError", "Parsed network response is empty"))
                        }
                        if (e.errors)
                            for (var b = e.errors, f = Array.isArray(b), g = 0, b = f ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                var i;
                                if (f) {
                                    if (g >= b.length) break;
                                    i = b[g++]
                                } else {
                                    g = b.next();
                                    if (g.done) break;
                                    i = g.value
                                }
                                i = i;
                                if (i.severity === "CRITICAL") {
                                    i = c("RelayGraphQLRequestUtils").createErrorFromPayload(i);
                                    d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_in_response", m.doc_id, m.config_id, l, n, i.message);
                                    return a.error(i)
                                }
                            }
                        d("LiveQueryEventsLoggingResolver").logEvent("client_update", "regular_response_update", m.doc_id, m.config_id, l, n);
                        a.closed || a.next(e)
                    }).onError(function(a) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_update", "error_received", m.doc_id, m.config_id, l, n, a.message)
                    }).onActive(function() {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "initial_subscribe_request", m.doc_id, m.config_id, l, n)
                    }).onPause(function(a, b) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "subscription_paused", m.doc_id, m.config_id, l, n)
                    }).onResume(function(a) {
                        d("LiveQueryEventsLoggingResolver").logEvent("client_subscribe", "subscription_resumed", m.doc_id, m.config_id, l, n)
                    }).send()
                }
            });
            return function() {
                e != null && c("promiseDone")(e, function(a) {
                    a.cancel(), d("LiveQueryEventsLoggingResolver").logEvent("client_unsubscribe", "regular_unsubscribe", m.doc_id, m.config_id, l, n)
                })
            }
        })
    }

    function i() {
        return c("uuid")()
    }

    function j(a) {
        for (var b = c("LiveQueryWebRelayKillList").liveQueryWebRelayKillList, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= b.length) break;
                f = b[e++]
            } else {
                e = b.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            if (a === f) return !0
        }
        return !1
    }

    function k() {
        return "WebSocket" in window
    }
    g["default"] = a
}), 98);
__d("createCometRelayEnvironmentConfig", ["ActorURIConfig", "CometMissingFieldHandlers", "CometRelayFlightEventLogger", "CometRelayPerfStore", "CometRootInitServerFlag", "RelayAPIConfig", "RelayFBFlightPayloadDeserializer", "RelayFBFlightServerErrorHandler", "RelayFBOperationLoader", "RelayRequiredFieldLogger", "cometHandlerProvider", "cometPrefetchVideoDashV2", "cometWrapNetworkObservable", "cr:1121434", "cr:1445039", "cr:1467370", "cr:851", "createCometStore", "createRelayFBNetwork", "createRelayFBNetworkFetch", "createRelayFBSubscribeFunction", "liveQueryFetch", "liveQueryFetchWithWWWInitial", "relay-runtime", "relayFBGetDataID"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        var d = c("RelayAPIConfig").actorID === a && b == null ? " DEFAULT" : "";
        b = b == null ? "" : " - " + b;
        return "CometRelayEnvironment (" + String(a) + b + ")" + d
    }

    function i(a, b) {
        return c("createRelayFBNetwork")(c("createRelayFBNetworkFetch")({
            actorID: a,
            batchResponseChunks: !0,
            getAdditionalData: function() {
                var b = {};
                a != null && (b[c("ActorURIConfig").PARAMETER_ACTOR] = a);
                c("RelayAPIConfig").useXController === !1 && c("RelayAPIConfig").accessToken !== "" && (b.access_token = c("RelayAPIConfig").accessToken);
                return b
            },
            graphURI: b,
            liveQueryFetchFn: c("liveQueryFetch"),
            liveQueryFetchWithWWWInitialFn: c("liveQueryFetchWithWWWInitial"),
            wrapObservableFn: c("cometWrapNetworkObservable")()
        }), c("createRelayFBSubscribeFunction")({
            actorID: a
        }), null, c("cometPrefetchVideoDashV2"))
    }

    function j(a) {
        return b("cr:1445039") != null ? b("cr:1445039").create(String(a), 2e3) : null
    }

    function k(a) {
        var c = b("cr:1121434") != null ? b("cr:1121434")() : null;
        return function(e) {
            c && c(e), a && a.log(e), d("CometRelayPerfStore").log(e), d("CometRelayFlightEventLogger").log(e), b("cr:851") && b("cr:851").log(e)
        }
    }

    function l(a) {
        return a != null ? function(b) {
            return a.log(b)
        } : null
    }

    function a(a) {
        var e = a.actorID,
            f = a.actorEnvironmentKey;
        a = a.graphURI;
        a = a === void 0 ? void 0 : a;
        var g = j(e);
        return {
            UNSTABLE_defaultRenderPolicy: "partial",
            actorID: e,
            configName: h(e, f),
            getDataID: c("relayFBGetDataID"),
            handlerProvider: c("cometHandlerProvider"),
            isServer: d("CometRootInitServerFlag").isServerEnvironment(),
            log: k(g),
            missingFieldHandlers: c("CometMissingFieldHandlers"),
            network: i(e, a),
            operationLoader: c("RelayFBOperationLoader"),
            operationTracker: new(d("relay-runtime").__internal.OperationTracker)(),
            reactFlightPayloadDeserializer: c("RelayFBFlightPayloadDeserializer"),
            reactFlightServerErrorHandler: c("RelayFBFlightServerErrorHandler"),
            requiredFieldLogger: d("RelayRequiredFieldLogger").create(),
            scheduler: b("cr:1467370"),
            store: c("createCometStore")(l(g))
        }
    }
    g.createCometEnvironmentConfigName = h;
    g.createCometNetwork = i;
    g.createCometRelayEventLogger = j;
    g.createCometEnvironmentLogFn = k;
    g.createCometStoreLoggerFn = l;
    g.createCometRelayEnvironmentConfig = a
}), 98);
__d("cometCreateMulitActorEnvironmentConfig", ["CometMissingFieldHandlers", "CometRootInitServerFlag", "RelayFBFlightPayloadDeserializer", "RelayFBFlightServerErrorHandler", "RelayFBOperationLoader", "RelayRequiredFieldLogger", "cometHandlerProvider", "cr:1467370", "createCometRelayEnvironmentConfig", "createCometStore", "relayFBGetDataID"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, e, f) {
        f === void 0 && (f = void 0);
        var g = d("createCometRelayEnvironmentConfig").createCometRelayEventLogger(a);
        return {
            createConfigNameForActor: function(a) {
                return d("createCometRelayEnvironmentConfig").createCometEnvironmentConfigName(String(a), e) + " (Multi Actor)"
            },
            createNetworkForActor: function(a) {
                return d("createCometRelayEnvironmentConfig").createCometNetwork(String(a), f)
            },
            createStoreForActor: function() {
                return c("createCometStore")(d("createCometRelayEnvironmentConfig").createCometStoreLoggerFn(g))
            },
            getDataID: c("relayFBGetDataID"),
            handlerProvider: c("cometHandlerProvider"),
            isServer: d("CometRootInitServerFlag").isServerEnvironment(),
            logFn: d("createCometRelayEnvironmentConfig").createCometEnvironmentLogFn(g),
            missingFieldHandlers: c("CometMissingFieldHandlers"),
            operationLoader: c("RelayFBOperationLoader"),
            reactFlightPayloadDeserializer: c("RelayFBFlightPayloadDeserializer"),
            reactFlightServerErrorHandler: c("RelayFBFlightServerErrorHandler"),
            requiredFieldLogger: d("RelayRequiredFieldLogger").create(),
            scheduler: b("cr:1467370")
        }
    }
    g["default"] = a
}), 98);
__d("relay-runtime/multi-actor-environment/ActorSpecificEnvironment", ["relay-runtime/network/wrapNetworkWithLogObserver", "relay-runtime/store/RelayOperationTracker", "relay-runtime/store/RelayPublishQueue", "relay-runtime/store/StoreInspector", "relay-runtime/store/defaultGetDataID", "relay-runtime/util/registerEnvironmentWithDevTools"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            var c = this;
            this.configName = a.configName;
            this.actorIdentifier = a.actorIdentifier;
            this.multiActorEnvironment = a.multiActorEnvironment;
            this.__log = a.logFn;
            this.requiredFieldLogger = a.requiredFieldLogger;
            this.$3 = new(b("relay-runtime/store/RelayOperationTracker"))();
            this.$5 = a.store;
            this.$2 = b("relay-runtime/network/wrapNetworkWithLogObserver")(this, a.network);
            this.$4 = new(b("relay-runtime/store/RelayPublishQueue"))(a.store, a.handlerProvider, b("relay-runtime/store/defaultGetDataID"));
            this.$1 = a.defaultRenderPolicy;
            this.options = {
                actorID: this.actorIdentifier
            };
            this["@@RelayModernEnvironment"] = !0;
            b("relay-runtime/util/registerEnvironmentWithDevTools")(this)
        }
        var c = a.prototype;
        c.getPublishQueue = function() {
            return this.$4
        };
        c.UNSTABLE_getDefaultRenderPolicy = function() {
            return this.$1
        };
        c.applyMutation = function(a) {
            return this.multiActorEnvironment.applyMutation(this, a)
        };
        c.applyUpdate = function(a) {
            return this.multiActorEnvironment.applyUpdate(this, a)
        };
        c.revertUpdate = function(a) {
            return this.multiActorEnvironment.revertUpdate(this, a)
        };
        c.replaceUpdate = function(a, b) {
            return this.multiActorEnvironment.replaceUpdate(this, a, b)
        };
        c.check = function(a) {
            return this.multiActorEnvironment.check(this, a)
        };
        c.subscribe = function(a, b) {
            return this.multiActorEnvironment.subscribe(this, a, b)
        };
        c.retain = function(a) {
            return this.multiActorEnvironment.retain(this, a)
        };
        c.commitUpdate = function(a) {
            return this.multiActorEnvironment.commitUpdate(this, a)
        };
        c.commitPayload = function(a, b) {
            return this.multiActorEnvironment.commitPayload(this, a, b)
        };
        c.getNetwork = function() {
            return this.$2
        };
        c.getStore = function() {
            return this.$5
        };
        c.getOperationTracker = function() {
            return this.$3
        };
        c.lookup = function(a) {
            return this.multiActorEnvironment.lookup(this, a)
        };
        c.execute = function(a) {
            return this.multiActorEnvironment.execute(this, a)
        };
        c.executeSubscription = function(a) {
            return this.multiActorEnvironment.executeSubscription(this, a)
        };
        c.executeMutation = function(a) {
            return this.multiActorEnvironment.executeMutation(this, a)
        };
        c.executeWithSource = function(a) {
            return this.multiActorEnvironment.executeWithSource(this, a)
        };
        c.isRequestActive = function(a) {
            return this.multiActorEnvironment.isRequestActive(this, a)
        };
        c.isServer = function() {
            return this.multiActorEnvironment.isServer()
        };
        return a
    }();
    e.exports = a
}), null);
__d("relay-runtime/multi-actor-environment/MultiActorEnvironment", ["relay-runtime/handlers/RelayDefaultHandlerProvider", "relay-runtime/multi-actor-environment/ActorSpecificEnvironment", "relay-runtime/network/RelayObservable", "relay-runtime/store/OperationExecutor", "relay-runtime/store/RelayModernStore", "relay-runtime/store/RelayRecordSource", "relay-runtime/store/defaultGetDataID", "relay-runtime/store/defaultRequiredFieldLogger"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a(a) {
            var c;
            this.$1 = new Map();
            this.$12 = a.operationLoader;
            this.$3 = a.createNetworkForActor;
            this.$16 = a.scheduler;
            this.$6 = (c = a.getDataID) != null ? c : b("relay-runtime/store/defaultGetDataID");
            this.$7 = a.handlerProvider ? a.handlerProvider : b("relay-runtime/handlers/RelayDefaultHandlerProvider");
            this.$9 = (c = a.logFn) != null ? c : g;
            this.$11 = new Map();
            this.$15 = (c = a.requiredFieldLogger) != null ? c : b("relay-runtime/store/defaultRequiredFieldLogger");
            this.$17 = a.shouldProcessClientComponents;
            this.$18 = (c = a.treatMissingFieldsAsNull) != null ? c : !1;
            this.$8 = (c = a.isServer) != null ? c : !1;
            this.$10 = a.missingFieldHandlers;
            this.$4 = a.createStoreForActor;
            this.$13 = a.reactFlightPayloadDeserializer;
            this.$14 = a.reactFlightServerErrorHandler;
            this.$2 = a.createConfigNameForActor;
            this.$5 = (c = a.defaultRenderPolicy) != null ? c : "partial"
        }
        var c = a.prototype;
        c.forActor = function(a) {
            var c = this.$1.get(a);
            if (c == null) {
                var d = new(b("relay-runtime/multi-actor-environment/ActorSpecificEnvironment"))({
                    configName: this.$2 ? this.$2(a) : null,
                    actorIdentifier: a,
                    multiActorEnvironment: this,
                    logFn: this.$9,
                    requiredFieldLogger: this.$15,
                    store: this.$4 != null ? this.$4(a) : new(b("relay-runtime/store/RelayModernStore"))(b("relay-runtime/store/RelayRecordSource").create()),
                    network: this.$3(a),
                    handlerProvider: this.$7,
                    defaultRenderPolicy: this.$5
                });
                this.$1.set(a, d);
                return d
            } else return c
        };
        c.check = function(a, c) {
            var d = this;
            return this.$10 == null || this.$10.length === 0 ? a.getStore().check(c, {
                handlers: [],
                defaultActorIdentifier: a.actorIdentifier,
                getSourceForActor: function(a) {
                    return d.forActor(a).getStore().getSource()
                },
                getTargetForActor: function() {
                    return b("relay-runtime/store/RelayRecordSource").create()
                }
            }) : this.$19(a, c, this.$10)
        };
        c.$19 = function(a, c, d) {
            var e = this,
                f = new Map([
                    [a.actorIdentifier, b("relay-runtime/store/RelayRecordSource").create()]
                ]);
            c = a.getStore().check(c, {
                handlers: d,
                defaultActorIdentifier: a.actorIdentifier,
                getSourceForActor: function(a) {
                    return e.forActor(a).getStore().getSource()
                },
                getTargetForActor: function(a) {
                    var c = f.get(a);
                    c == null && (c = b("relay-runtime/store/RelayRecordSource").create(), f.set(a, c));
                    return c
                }
            });
            a = function() {
                if (h) {
                    if (i >= g.length) return "break";
                    d = g[i++]
                } else {
                    i = g.next();
                    if (i.done) return "break";
                    d = i.value
                }
                var a = d,
                    b = a[0],
                    c = a[1];
                c.size() > 0 && e.$20(function() {
                    var a = e.forActor(b).getPublishQueue();
                    a.commitSource(c);
                    a.run()
                })
            };
            for (var g = f, h = Array.isArray(g), i = 0, g = h ? g : g[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var j = a();
                if (j === "break") break
            }
            return c
        };
        c.subscribe = function(a, b, c) {
            return a.getStore().subscribe(b, c)
        };
        c.retain = function(a, b) {
            return a.getStore().retain(b)
        };
        c.applyUpdate = function(a, b) {
            var c = this,
                d = a.getPublishQueue();
            a = function() {
                c.$20(function() {
                    d.revertUpdate(b), d.run()
                })
            };
            this.$20(function() {
                d.applyUpdate(b), d.run()
            });
            return {
                dispose: a
            }
        };
        c.revertUpdate = function(a, b) {
            var c = a.getPublishQueue();
            this.$20(function() {
                c.revertUpdate(b), c.run()
            })
        };
        c.replaceUpdate = function(a, b, c) {
            var d = a.getPublishQueue();
            this.$20(function() {
                d.revertUpdate(b), d.applyUpdate(c), d.run()
            })
        };
        c.applyMutation = function(a, c) {
            var d = this.$21(a, {
                createSource: function() {
                    return b("relay-runtime/network/RelayObservable").create(function(a) {})
                },
                isClientPayload: !1,
                operation: c.operation,
                optimisticConfig: c,
                updater: null
            }).subscribe({});
            return {
                dispose: function() {
                    return d.unsubscribe()
                }
            }
        };
        c.commitUpdate = function(a, b) {
            var c = a.getPublishQueue();
            this.$20(function() {
                c.commitUpdate(b), c.run()
            })
        };
        c.commitPayload = function(a, c, d) {
            this.$21(a, {
                createSource: function() {
                    return b("relay-runtime/network/RelayObservable").from({
                        data: d
                    })
                },
                isClientPayload: !0,
                operation: c,
                optimisticConfig: null,
                updater: null
            }).subscribe({})
        };
        c.lookup = function(a, b) {
            return a.getStore().lookup(b)
        };
        c.execute = function(a, b) {
            var c = b.operation;
            return this.$21(a, {
                createSource: function() {
                    return a.getNetwork().execute(c.request.node.params, c.request.variables, c.request.cacheConfig || {}, null)
                },
                isClientPayload: !1,
                operation: c,
                optimisticConfig: null,
                updater: null
            })
        };
        c.executeSubscription = function(a, b) {
            var c = b.operation;
            b = b.updater;
            return this.$21(a, {
                createSource: function() {
                    return a.getNetwork().execute(c.request.node.params, c.request.variables, c.request.cacheConfig || {}, null)
                },
                isClientPayload: !1,
                operation: c,
                optimisticConfig: null,
                updater: b
            })
        };
        c.executeMutation = function(a, b) {
            var c = b.operation,
                d = b.optimisticResponse,
                e = b.optimisticUpdater,
                f = b.updater,
                g = b.uploadables,
                h;
            (d || e) && (h = {
                operation: c,
                response: d,
                updater: e
            });
            return this.$21(a, {
                createSource: function() {
                    return a.getNetwork().execute(c.request.node.params, c.request.variables, babelHelpers["extends"]({}, c.request.cacheConfig, {
                        force: !0
                    }), g)
                },
                isClientPayload: !1,
                operation: c,
                optimisticConfig: h,
                updater: f
            })
        };
        c.executeWithSource = function(a, b) {
            return this.$21(a, {
                createSource: function() {
                    return b.source
                },
                isClientPayload: !1,
                operation: b.operation,
                optimisticConfig: null,
                updater: null
            })
        };
        c.isRequestActive = function(a, b) {
            a = this.$11.get(b);
            return a === "active"
        };
        c.isServer = function() {
            return this.$8
        };
        c.$21 = function(a, c) {
            var d = this,
                e = c.createSource,
                f = c.isClientPayload,
                g = c.operation,
                h = c.optimisticConfig,
                i = c.updater;
            return b("relay-runtime/network/RelayObservable").create(function(c) {
                var j = b("relay-runtime/store/OperationExecutor").execute({
                    actorIdentifier: a.actorIdentifier,
                    getDataID: d.$6,
                    isClientPayload: f,
                    operation: g,
                    operationExecutions: d.$11,
                    operationLoader: d.$12,
                    operationTracker: a.getOperationTracker(),
                    optimisticConfig: h,
                    getPublishQueue: function(a) {
                        return d.forActor(a).getPublishQueue()
                    },
                    reactFlightPayloadDeserializer: d.$13,
                    reactFlightServerErrorHandler: d.$14,
                    scheduler: d.$16,
                    shouldProcessClientComponents: d.$17,
                    sink: c,
                    source: e(),
                    getStore: function(a) {
                        return d.forActor(a).getStore()
                    },
                    treatMissingFieldsAsNull: d.$18,
                    updater: i,
                    log: d.$9
                });
                return function() {
                    return j.cancel()
                }
            })
        };
        c.$20 = function(a) {
            var b = this.$16;
            b != null ? b.schedule(a) : a()
        };
        c.commitMultiActorUpdate = function(a) {
            var b = function() {
                if (d) {
                    if (e >= c.length) return "break";
                    f = c[e++]
                } else {
                    e = c.next();
                    if (e.done) return "break";
                    f = e.value
                }
                var b = f,
                    g = b[0],
                    h = b[1];
                h.commitUpdate(function(b) {
                    a(g, h, b)
                })
            };
            for (var c = this.$1, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var f, g = b();
                if (g === "break") break
            }
        };
        return a
    }();

    function g() {}
    e.exports = a
}), null);
__d("relay-runtime/multi-actor-environment", ["relay-runtime/multi-actor-environment/ActorIdentifier", "relay-runtime/multi-actor-environment/MultiActorEnvironment"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("relay-runtime/multi-actor-environment/ActorIdentifier").getActorIdentifier;
    e.exports = {
        MultiActorEnvironment: b("relay-runtime/multi-actor-environment/MultiActorEnvironment"),
        getActorIdentifier: a
    }
}), null);
__d("CometRelayMultiActorEnvironment", ["RelayAPIConfig", "cometCreateMulitActorEnvironmentConfig", "relay-runtime/multi-actor-environment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map(),
        i = new(d("relay-runtime/multi-actor-environment").MultiActorEnvironment)(c("cometCreateMulitActorEnvironmentConfig")(c("RelayAPIConfig").actorID));

    function a(a) {
        var b = function(b, c, d) {
            a(String(b), c, d)
        };
        for (var c = h.values(), d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var f;
            if (d) {
                if (e >= c.length) break;
                f = c[e++]
            } else {
                e = c.next();
                if (e.done) break;
                f = e.value
            }
            f = f;
            f.commitMultiActorUpdate(b)
        }
        i.commitMultiActorUpdate(b)
    }

    function b(a, b) {
        var e;
        b != null ? (e = h.get(b), e == null && (e = new(d("relay-runtime/multi-actor-environment").MultiActorEnvironment)(c("cometCreateMulitActorEnvironmentConfig")(c("RelayAPIConfig").actorID, b)), h.set(b, e))) : e = i;
        return e.forActor(a)
    }
    g.commitMultiActorUpdate = a;
    g.forActor = b
}), 98);
__d("resolveImmediate", ["Promise"], (function(a, b, c, d, e, f) {
    var g = b("Promise").resolve();

    function a(a) {
        g.then(a)["catch"](h)
    }

    function h(a) {
        setTimeout(function() {
            throw a
        }, 0)
    }
    f["default"] = a
}), 66);
__d("createRelayFBLocalEnvironment", ["RelayFBHandlerProvider", "RelayFBOperationLoader", "RelayRequiredFieldLogger", "RelayRuntime", "getRelayFBMissingFieldHandlers", "relayFBGetDataID", "resolveImmediate"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("RelayRuntime").Environment,
        h = b("RelayRuntime").RecordSource,
        i = b("RelayRuntime").Store,
        j = {
            execute: function(a) {
                throw new Error("RelayFBLocalEnvironment: Network requests are not allowed in the local environment, got: " + a.name)
            }
        };

    function a(a) {
        var c = a.handlerProvider,
            d = a.missingFieldHandlers,
            e = a.scheduler,
            f = a.store,
            k = a.configName,
            l = a.log,
            m = a.operationTracker;
        a = a.getDataID;
        c = new g({
            configName: (k = k) != null ? k : "RelayFBLocalEnvironment",
            handlerProvider: (k = c) != null ? k : b("RelayFBHandlerProvider"),
            missingFieldHandlers: (c = d) != null ? c : b("getRelayFBMissingFieldHandlers")(),
            operationLoader: b("RelayFBOperationLoader"),
            scheduler: e,
            store: (k = f) != null ? k : new i(new h(), {
                getDataID: b("relayFBGetDataID"),
                gcReleaseBufferSize: 10,
                gcScheduler: b("resolveImmediate"),
                operationLoader: b("RelayFBOperationLoader")
            }),
            network: j,
            operationTracker: m,
            log: l,
            getDataID: (d = a) != null ? d : b("relayFBGetDataID"),
            options: {
                isLocal: !0
            },
            requiredFieldLogger: b("RelayRequiredFieldLogger").create()
        });
        return c
    }
    e.exports = a
}), null);
__d("cometCreateLocalEnvironment", ["CometMissingFieldHandlers", "cometHandlerProvider", "createCometStore", "createRelayFBLocalEnvironment"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("createRelayFBLocalEnvironment")({
            configName: "CometRelayLocalEnvironment",
            handlerProvider: c("cometHandlerProvider"),
            missingFieldHandlers: c("CometMissingFieldHandlers"),
            scheduler: null,
            store: c("createCometStore")()
        })
    }
    g["default"] = a
}), 98);
__d("RelayFlightClientImpl.client", ["invariant", "react-relay/relay-hooks/useFragment", "react-relay/relay-hooks/useLazyLoadQuery", "relay-runtime"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, d) {
        return c("react-relay/relay-hooks/useLazyLoadQuery")(a, b, {
            fetchPolicy: "store-only",
            UNSTABLE_renderPolicy: d == null ? void 0 : d.UNSTABLE_renderPolicy
        })
    }

    function b(a) {
        return a
    }

    function e(a, b) {
        a = a.params.id;
        a != null || h(0, 23333);
        return {
            id: a,
            variables: b
        }
    }
    f = {
        loadFragmentForClient: b,
        loadQueryForClient: e,
        useFragment: c("react-relay/relay-hooks/useFragment"),
        useReadQuery: a,
        readInlineData: d("relay-runtime").readInlineData
    };
    g["default"] = f
}), 98);
__d("RelayFlight.hybrid", ["RelayFlightClientImpl.client", "err", "relay-runtime/query/GraphQLTag", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null;

    function i() {
        return a.__flight_execution_mode_DO_NOT_USE === "flight"
    }

    function j() {
        if (!i() && h == null) {
            var a = b("RelayFlightClientImpl.client");
            h = a
        }
        if (h == null) throw c("err")("Expected RelayFlight::initialize_INTERNAL_DO_NOT_USE() to be called before using other APIs.");
        return h
    }

    function e(a) {
        if (h != null) {
            c("warning")(h === a, "RelayFlight::initialize_INTERNAL_DO_NOT_USE(): Already initialized, this module may not be initialized again.");
            return
        }
        h = a
    }
    var k = function() {
            var a = j();
            return a.readInlineData.apply(a, arguments)
        },
        l = function() {
            var a = j();
            return a.useFragment.apply(a, arguments)
        };

    function f(a, b, c) {
        var d = j();
        return d.useReadQuery(a, b, c)
    }

    function m(a) {
        var b = j();
        return b.loadFragmentForClient(a)
    }

    function n(a, b) {
        var c = j();
        return c.loadQueryForClient(a, b)
    }
    g.isServer_INTERNAL_DO_NOT_USE = i;
    g.initialize_INTERNAL_DO_NOT_USE = e;
    g.readInlineData = k;
    g.useFragment = l;
    g.useReadQuery = f;
    g.loadFragmentForClient = m;
    g.loadQueryForClient = n;
    g.graphql = d("relay-runtime/query/GraphQLTag").graphql
}), 98);
__d("configureRelayFlight", ["RelayFlight.hybrid", "RelayFlightClientImpl.client"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        d("RelayFlight.hybrid").isServer_INTERNAL_DO_NOT_USE() || d("RelayFlight.hybrid").initialize_INTERNAL_DO_NOT_USE(c("RelayFlightClientImpl.client"))
    }
    g["default"] = a
}), 98);
__d("CometRelayEnvironmentFactory", ["CometRelayMultiActorEnvironment", "RelayAPIConfig", "cometCreateLocalEnvironment", "cometHandlerProvider", "configureRelayFlight", "configureRelayForWWW", "createCometRelayEnvironmentConfig", "relay-runtime/multi-actor-environment"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c("configureRelayForWWW")();
    c("configureRelayFlight")();

    function a(a, b) {
        return d("CometRelayMultiActorEnvironment").forActor(d("relay-runtime/multi-actor-environment").getActorIdentifier(a), b)
    }
    e = a(c("RelayAPIConfig").actorID);

    function b(a) {
        return d("CometRelayMultiActorEnvironment").commitMultiActorUpdate(a)
    }
    g.createLocalEnvironment = c("cometCreateLocalEnvironment");
    g.configEnvironment = d("createCometRelayEnvironmentConfig").createCometRelayEnvironmentConfig;
    g.cometHandlerProvider = c("cometHandlerProvider");
    g.commitLocalUpdateForEachEnvironment = b;
    g.defaultEnvironment = e;
    g.getForActorID = a
}), 98);
__d("CometRelayEnvironment", ["CometRelayEnvironmentFactory"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = d("CometRelayEnvironmentFactory").defaultEnvironment
}), 98);
__d("OutsideExceptionKeyCommandListener.react", ["BaseKeyCommandListener.react", "CometLayerKeyCommandWrapper.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("BaseKeyCommandListener.react"), {
            observersEnabled: !1,
            children: h.jsx(c("CometLayerKeyCommandWrapper.react"), {
                debugName: "outside exception layer",
                children: a.children
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useGlobalKeyCommands", ["CometGlobalKeyCommandWidget"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("CometGlobalKeyCommandWidget").useKeyCommands
}), 98);
__d("cometGetKeyCommandConfig", ["fbt", "cr:2011405", "cr:2011406", "gkx", "recoverableViolation"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = {
        command: null,
        description: h._("Missing shortcut"),
        handler: function() {
            return void 0
        },
        isHiddenCommand: !0
    };

    function j(a, b, d, e, f) {
        if (e == null) {
            c("recoverableViolation")(f, "comet_ax");
            return i
        }
        if (!Object.prototype.hasOwnProperty.call(e, a) || !Object.prototype.hasOwnProperty.call(e[a].shortcuts, b)) {
            c("recoverableViolation")("Missing default key command config for " + a + " and " + b, "comet_ax");
            return i
        }
        f = e[a].shortcuts[b];
        e = f.command;
        var g = f.description;
        return e != null && g != null ? {
            command: e,
            commandID: b,
            description: g,
            groupID: a,
            handler: d,
            isHiddenCommand: f.isHiddenCommand,
            singleCharDescription: f.singleCharDescription,
            triggerFromInputs: f.triggerFromInputs
        } : i
    }

    function a(a, c, d) {
        return j(a, c, d, b("cr:2011405"), "getCometKeyCommandConfig should only be used in Comet")
    }

    function d(a, d, e) {
        var f = c("gkx")("1224637") ? b("cr:2011406") : b("cr:2011405");
        return j(a, d, e, f, "Reached unreachable code")
    }
    g.getKeyCommandConfig = j;
    g.getCometKeyCommandConfig = a;
    g.getCometAndGeminiKeyCommandConfig = d
}), 98);
__d("CometGlobalPanelGating.entrypointutils", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return Boolean(c("qex")._("1742"))
    }

    function b() {
        return Boolean(c("qex")._("19"))
    }

    function d() {
        var a;
        return (a = c("qex")._("245")) != null ? a : !1
    }
    g.isCommunityPanelEMCopresenceEnabled = a;
    g.isGlobalPanelEnabled = b;
    g.shouldUseBookmarkRanking = d
}), 98);
__d("CometGlobalPanelGating", ["CometGlobalPanelGating.entrypointutils", "gkx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a;
        return (a = c("qex")._("296")) != null ? a : !0
    }

    function b() {
        var a;
        return (a = c("qex")._("117")) != null ? a : 3
    }

    function e() {
        var a;
        return (a = c("qex")._("179")) != null ? a : !1
    }

    function f() {
        var a;
        return (a = c("qex")._("1810")) != null ? a : !1
    }

    function h() {
        return c("gkx")("8516")
    }
    g.isCommunityPanelEMCopresenceEnabled = d("CometGlobalPanelGating.entrypointutils").isCommunityPanelEMCopresenceEnabled;
    g.isGlobalPanelEnabled = d("CometGlobalPanelGating.entrypointutils").isGlobalPanelEnabled;
    g.shouldShowGroupsInGlobalPanel = a;
    g.getGlobalPanelBaseNumTargetedTabs = b;
    g.shouldShowGlobalPanelExpandedBookmarks = e;
    g.shouldShowGlobalPanelSeeAllButton = f;
    g.shouldShowGlobalPanelPopoversOnHover = h
}), 98);
__d("CometRouterRouteTopNavTypeContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext("default");
    g["default"] = b
}), 98);
__d("useShouldRenderFullTopNav", ["CometRouterRouteTopNavTypeContext", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext,
        i = c("gkx")("1266082");

    function a() {
        var a = h(c("CometRouterRouteTopNavTypeContext"));
        return a === "default" && i
    }
    g["default"] = a
}), 98);
__d("useShouldShowMessagingEntrypoint", ["ProfilePlusMessaging", "gkx", "useShouldRenderFullTopNav"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var d, e = c("useShouldRenderFullTopNav")();
        if (!e || a == null) return !1;
        if (!c("gkx")("1673554") || !c("gkx")("1812744")) return !1;
        if (b !== "JEWEL" && c("ProfilePlusMessaging").shouldRedirectMessagesForAP) return !1;
        e = a.entityKeyConfig;
        e = b === "JEWEL" && (e == null ? void 0 : (d = e.entity_type) == null ? void 0 : d.value) === "group" && ((d = e.section) == null ? void 0 : d.value) === "CHATS";
        if (e) return !0;
        return b === "JEWEL" && a.routeType === "media_viewer" ? !0 : !Boolean(a.hideChat)
    }
    g["default"] = a
}), 98);
__d("CometRouterStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useCometRouterState", ["CometRouterStateContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRouterStateContext"))
    }
    g["default"] = a
}), 98);
__d("useShouldShowMessagingEntrypointInCometRoot", ["useCometRouterState", "useShouldShowMessagingEntrypoint"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = c("useCometRouterState")(),
            d = b == null ? void 0 : b.main;
        b = b == null ? void 0 : b.pushViewStack;
        b = b && b.length > 0 ? b[b.length - 1] : d;
        return c("useShouldShowMessagingEntrypoint")(b == null ? void 0 : b.route, a)
    }
    g["default"] = a
}), 98);
__d("isBlueprintStylesEnabled", ["qex"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        return c("qex")._("1022") || !1
    }
    g["default"] = a
}), 98);
__d("goForceFullPageRedirectTo", ["ConstUriUtils", "FBLogger", "err"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var e = typeof a === "string" ? d("ConstUriUtils").getUri(a) : a;
        if (e) b === !0 ? window.location.replace(e.toString()) : window.location = e.toString();
        else {
            b = "Invalid URI " + a.toString() + " provided to goFullPageRedirectTo";
            c("FBLogger")("comet_infra").blameToPreviousFrame().mustfix(b)
        }
    }
    g["default"] = a
}), 98);
__d("handleCheckpointRedirect", ["ConstUriUtils", "goForceFullPageRedirectTo"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a = (a = d("ConstUriUtils").getUri(a)) == null ? void 0 : a.addQueryParam("next", location.toString());
        c("goForceFullPageRedirectTo")((a = a) != null ? a : "/")
    }
    g["default"] = a
}), 98);
__d("CometMiddot.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("span", babelHelpers["extends"]({}, a, {
            children: [h.jsx("span", {
                className: "x1i1rx1s x10l6tqk x10wlt62 x6ikm8r xjm9jq1 xzpqnlu",
                children: "\xa0"
            }), h.jsx("span", {
                "aria-hidden": "true",
                children: " \xb7 "
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNonBreakingSpace.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            .25: {
                marginEnd: "x1yi58nm"
            },
            .5: {
                marginEnd: "xgnuv6c"
            },
            .75: {
                marginEnd: "x1jnq1ez"
            },
            1: {
                marginEnd: "x1xxsv49"
            }
        };

    function a(a) {
        a = a.size;
        if (a != null) return h.jsx("span", {
            className: c("stylex")(i[a]),
            children: "\ufeff"
        });
        else return h.jsx(h.Fragment, {
            children: "\xa0"
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometNUXInlineSurvey.react", ["fbt", "CometLink.react", "CometMiddot.react", "CometNonBreakingSpace.react", "TetraText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useMemo,
        k = b.useState;

    function a(a) {
        var b = a.bodyColor,
            d = a.initialHasAnsweredSurvey,
            e = a.linkColor,
            f = a.onAnswer,
            g = a.onHelpful,
            h = a.onNotHelpful;
        a = k(d);
        d = a[0];
        var n = a[1];
        a = j(function() {
            function a() {
                n(!0), f == null ? void 0 : f()
            }
            return {
                onHelpful: function() {
                    a(), g == null ? void 0 : g()
                },
                onNotHelpful: function() {
                    a(), h == null ? void 0 : h()
                }
            }
        }, [f, g, h]);
        var o = a.onHelpful;
        a = a.onNotHelpful;
        b = (b = b) != null ? b : "secondary";
        return i.jsx(c("TetraText.react"), {
            color: b,
            type: "body4",
            children: d !== !0 ? i.jsx(l, {
                linkColor: e,
                onHelpful: o,
                onNotHelpful: a
            }) : i.jsx(m, {})
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function l(a) {
        var b = a.linkColor,
            d = a.onHelpful;
        a = a.onNotHelpful;
        b = (b = b) != null ? b : "highlight";
        return i.jsxs(i.Fragment, {
            children: [h._("Was this tip helpful?"), i.jsx(c("CometNonBreakingSpace.react"), {
                size: 1
            }), i.jsx(c("CometLink.react"), {
                color: b,
                onClick: d,
                children: h._("Yes")
            }), i.jsx(c("CometMiddot.react"), {}), i.jsx(c("CometLink.react"), {
                color: b,
                onClick: a,
                children: h._("No")
            })]
        })
    }

    function m() {
        return h._("Thanks for your feedback.")
    }
    m.displayName = m.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseView.react", ["LegacyHidden", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            hidden: {
                display: "x1s85apg"
            },
            root: {
                boxSizing: "x9f619",
                position: "x1n2onr6",
                zIndex: "x1ja2u2z"
            }
        };

    function a(a, b) {
        var d = a.children,
            e = a.suppressHydrationWarning,
            f = a.testid,
            g = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "suppressHydrationWarning", "testid", "xstyle"]);
        var j = a.hidden === !0;
        return h.jsx(c("LegacyHidden"), {
            htmlAttributes: babelHelpers["extends"]({}, a, c("testID")(f), {
                className: c("stylex")(i.root, g, j && i.hidden)
            }),
            mode: j ? "hidden" : "visible",
            ref: b,
            suppressHydrationWarning: e,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometBase.react", ["BaseView.react"], (function(a, b, c, d, e, f) {
    "use strict";
    f["default"] = b("BaseView.react")
}), 66);
__d("CometCalloutContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("useCometCallout", ["BaseContextualLayerAnchorRootContext", "BaseScrollableAreaContext", "CometCalloutContext", "LayoutAnimationBoundaryContext", "react", "useCometUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useEffect,
        j = b.useRef;

    function a(a, b) {
        var d = h(c("CometCalloutContext")),
            e = h(c("BaseContextualLayerAnchorRootContext")),
            f = j(null),
            g = c("useCometUniqueID")(),
            k = h(c("BaseScrollableAreaContext")),
            l = h(c("LayoutAnimationBoundaryContext"));
        i(function() {
            if (d == null || f.current == null) return;
            if (a != null && b === !0) {
                d.addCallout({
                    anchorRootRefContext: e,
                    animationContext: l,
                    calloutID: g,
                    calloutProps: a,
                    contextRef: f,
                    scrollableAreaContext: k
                });
                return function() {
                    return d.removeCallout(g)
                }
            }
        }, [l, e, d, g, a, b, k]);
        return f
    }
    g["default"] = a
}), 98);
__d("CometCircleButton.react", ["CometIcon.react", "CometPressable.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            pressableOverlayPressed: {
                backgroundColor: "x1lxk4cn"
            },
            pressed: {
                transform: "x1n5d1j9"
            },
            root: {
                alignItems: "x6s0dn4",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                paddingTop: "xexx8yu",
                paddingEnd: "x4uap5",
                paddingBottom: "x18d9i69",
                paddingStart: "xkhd6sd",
                position: "x1n2onr6"
            }
        },
        j = (b = {}, b[24] = {
            height: "xxk0z11",
            width: "xvy4d1p"
        }, b[28] = {
            height: "x1fgtraw",
            width: "xgd8bvy"
        }, b[32] = {
            height: "x10w6t97",
            width: "x1td3qas"
        }, b[36] = {
            height: "xc9qbxq",
            width: "x14qfxbe"
        }, b[40] = {
            height: "x1vqgdyp",
            width: "x100vrsf"
        }, b[48] = {
            height: "xsdox4t",
            width: "x1useyqa"
        }, b),
        k = {
            "dark-overlay": {
                backgroundColor: "x18l40ae",
                color: "x14ctfv"
            },
            deemphasized: {
                backgroundColor: "xjbqb8w"
            },
            "deemphasized-overlay": {
                backgroundColor: "x1hr4nm9"
            },
            normal: {
                backgroundColor: "x1qhmfi1"
            },
            overlay: {
                backgroundColor: "x9bbmet",
                boxShadow: "x10f5nwc",
                color: "xi81zsa"
            },
            "overlay-floating": {
                backgroundColor: "x1l31dnx",
                boxShadow: "x1qeybcx"
            },
            "overlay-raised": {
                backgroundColor: "x9bbmet",
                boxShadow: "x1k54i6l",
                color: "xi81zsa"
            },
            "primary-background-overlay": {
                backgroundColor: "xtvsq51"
            }
        },
        l = {
            "dark-overlay": {
                backgroundColor: "x18l40ae"
            },
            deemphasized: {
                backgroundColor: "xjbqb8w"
            },
            "deemphasized-overlay": {
                backgroundColor: "x1f2gare"
            },
            normal: {
                backgroundColor: "xwcfey6"
            },
            overlay: {
                backgroundColor: "x1ahlmzr",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxShadow: "xxnfx33",
                color: "x1dntmbh"
            },
            "primary-background-overlay": {
                backgroundColor: "xtvsq51"
            }
        },
        m = (e = {}, e[24] = 12, e[28] = 16, e[32] = 16, e[36] = 20, e[40] = 20, e[48] = 24, e),
        n = (d = {}, d[24] = 20, d[28] = 20, d[32] = 24, d[36] = 28, d[40] = 32, d[48] = 32, d);

    function a(a, b) {
        var d = a["aria-hidden"],
            e = a["aria-pressed"],
            f = a.color,
            g = a.dataAttributes,
            p = a.disabled,
            q = p === void 0 ? !1 : p;
        p = a.focusable;
        var r = a.icon,
            s = a.iconRatio,
            t = a.label,
            u = a.linkProps,
            v = a.onFocusIn,
            w = a.onFocusOut,
            x = a.onHoverIn,
            y = a.onHoverOut,
            z = a.onPress,
            A = a.onPressIn,
            B = a.onPressOut,
            C = a.overlayHoveredStyle,
            D = a.size,
            E = a.testid;
        E = a.testOnly_pressed;
        a = a.type;
        var F = a === void 0 ? "normal" : a;
        a = g != null ? Object.keys(g).reduce(function(a, b) {
            a != null && b != null && (a["data-" + b] = g[b]);
            return a
        }, {}) : null;
        t = h.jsx(c("CometPressable.react"), {
            "aria-hidden": d,
            "aria-label": t,
            "aria-pressed": e,
            disabled: q,
            display: "inline",
            focusable: p,
            linkProps: u,
            onFocusIn: v,
            onFocusOut: w,
            onHoverIn: x,
            onHoverOut: y,
            onPress: z,
            onPressIn: A,
            onPressOut: B,
            overlayHoveredStyle: C,
            overlayPressedStyle: i.pressableOverlayPressed,
            overlayRadius: "50%",
            ref: b,
            testOnly_pressed: E,
            testid: void 0,
            xstyle: function(a) {
                a = a.pressed;
                return [i.root, j[D], k[F], q && l[F === "overlay-raised" || F === "overlay-floating" ? "overlay" : F], a && i.pressed]
            },
            children: h.jsx(c("CometIcon.react"), {
                color: q ? "disabled" : (d = f) != null ? d : o(F),
                icon: r,
                size: s === "large" ? n[D] : m[D]
            })
        });
        return a != null ? h.jsx("div", babelHelpers["extends"]({}, a, {
            children: t
        })) : t
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function o(a) {
        switch (a) {
            case "dark-overlay":
                return "white";
            case "deemphasized-overlay":
                return "highlight";
            default:
                return "primary"
        }
    }
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometColumnContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometColumnItem.react", ["BaseView.react", "CometColumnContext", "CometErrorBoundary.react", "CometPlaceholder.react", "UserAgent", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            divider: {
                borderTopColor: "x8cjs6t",
                borderTopStyle: "x13fuv20",
                borderTopWidth: "x178xt8z",
                ":first-child": {
                    display: "xh99ass"
                }
            },
            dividerMargin: {
                ":first-child:empty + *": {
                    marginTop: "xb939ph"
                }
            },
            expanding: {
                flexBasis: "x1l7klhg",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minHeight: "x2lwn1j"
            },
            expandingIE11: {
                flexBasis: "xdl72j9"
            },
            marginFirstChild: {
                ":first-child": {
                    marginTop: "x14l7nz5"
                }
            },
            marginLastChild: {
                ":last-child": {
                    marginBottom: "xzboxd6"
                }
            },
            root: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexShrink: "x2lah0s",
                maxWidth: "x193iq5w"
            }
        },
        k = {
            center: {
                alignItems: "x6s0dn4"
            },
            end: {
                alignItems: "xuk3077"
            },
            start: {
                alignItems: "x1cy8zhl"
            }
        },
        l = {
            4: {
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4"
            },
            8: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha"
            },
            12: {
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou"
            },
            16: {
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13"
            },
            20: {
                paddingEnd: "xc73u3c",
                paddingStart: "x5ib6vp"
            }
        },
        m = {
            0: {
                paddingTop: "xexx8yu"
            },
            4: {
                paddingTop: "x1iorvi4"
            },
            8: {
                paddingTop: "x1y1aw1k"
            },
            12: {
                paddingTop: "xz9dl7a"
            },
            16: {
                paddingTop: "xyamay9"
            },
            20: {
                paddingTop: "x1cnzs8"
            },
            40: {
                paddingTop: "x13zrc24"
            }
        },
        n = {
            4: {
                paddingTop: "x1iorvi4",
                paddingBottom: "xjkvuk6"
            },
            8: {
                paddingTop: "x1y1aw1k",
                paddingBottom: "xwib8y2"
            },
            12: {
                paddingTop: "xz9dl7a",
                paddingBottom: "xsag5q8"
            },
            16: {
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v"
            },
            20: {
                paddingTop: "x1cnzs8",
                paddingBottom: "xx6bls6"
            },
            40: {
                paddingTop: "x13zrc24",
                paddingBottom: "x1t1ogtf"
            }
        },
        o = {
            4: {
                marginTop: "xr9ek0c",
                marginBottom: "xjpr12u"
            },
            8: {
                marginTop: "x1gslohp",
                marginBottom: "x12nagc"
            },
            12: {
                marginTop: "x1k70j0n",
                marginBottom: "xzueoph"
            },
            16: {
                marginTop: "x1xmf6yo",
                marginBottom: "x1e56ztr"
            },
            20: {
                marginTop: "x1anpbxc",
                marginBottom: "xyorhqc"
            },
            24: {
                marginTop: "x14vqqas",
                marginBottom: "xod5an3"
            },
            32: {
                marginTop: "xw7yly9",
                marginBottom: "x1yztbdb"
            },
            40: {
                marginTop: "x1sy10c2",
                marginBottom: "xieb3on"
            }
        },
        p = {
            bottom: {
                justifyContent: "x13a6bvl"
            },
            center: {
                justifyContent: "xl56j7k"
            },
            "space-between": {
                justifyContent: "x1qughib"
            }
        },
        q = {
            4: {
                marginEnd: "xw3qccf",
                marginStart: "xsgj6o6"
            },
            8: {
                marginEnd: "x1emribx",
                marginStart: "x1i64zmx"
            },
            12: {
                marginEnd: "xq8finb",
                marginStart: "x16n37ib"
            },
            16: {
                marginEnd: "xktsk01",
                marginStart: "x1d52u69"
            },
            20: {
                marginEnd: "x1h5jrl4",
                marginStart: "xmn8rco"
            }
        },
        r = c("UserAgent").isBrowser("IE >= 11");

    function a(a, b) {
        var d, e, f, g;
        d = (d = i(c("CometColumnContext"))) != null ? d : {};
        var t = a.align;
        e = t === void 0 ? (e = d.align) != null ? e : "stretch" : t;
        t = a.children;
        var u = a.expanding;
        u = u === void 0 ? !1 : u;
        var v = a.fallback,
            w = a.paddingHorizontal;
        f = w === void 0 ? (f = d.paddingHorizontal) != null ? f : 0 : w;
        w = a.paddingTop;
        var x = a.paddingVertical;
        x = x === void 0 ? 0 : x;
        var y = a.placeholder,
            z = a.verticalAlign;
        z = z === void 0 ? "top" : z;
        var A = babelHelpers.objectWithoutPropertiesLoose(a, ["align", "children", "expanding", "fallback", "paddingHorizontal", "paddingTop", "paddingVertical", "placeholder", "verticalAlign"]),
            B = c("stylex").compose(a.xstyle);
        g = h.jsxs(h.Fragment, {
            children: [d.hasDividers === !0 && h.jsx(c("BaseView.react"), {
                role: "separator",
                xstyle: [j.divider, q[(g = d.paddingHorizontal) != null ? g : 0], d.spacing != null && j.dividerMargin]
            }), h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, A, {
                ref: b,
                xstyle: [j.root, u && [j.expanding, r && j.expandingIE11], e !== "stretch" && k[e], z !== "top" && p[z], l[f], n[x], w != null && m[w], d.spacing != null && [o[d.spacing], B.marginBottom == null && j.marginLastChild, B.marginTop == null && j.marginFirstChild], a.xstyle],
                children: h.jsx(c("CometColumnContext").Provider, {
                    value: null,
                    children: t
                })
            }))]
        });
        if (v !== void 0) {
            a.fallback;
            var C = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback"]);
            v === null ? g = h.jsx(c("CometErrorBoundary.react"), {
                children: g
            }) : g = h.jsx(c("CometErrorBoundary.react"), {
                fallback: function(a, c) {
                    return h.jsx(s, babelHelpers["extends"]({}, C, {
                        ref: b,
                        children: typeof v === "function" ? v(a, c) : v
                    }))
                },
                children: g
            })
        }
        if (y !== void 0) {
            a.placeholder;
            A = babelHelpers.objectWithoutPropertiesLoose(a, ["placeholder"]);
            g = h.jsx(c("CometPlaceholder.react"), {
                fallback: y != null ? h.jsx(s, babelHelpers["extends"]({}, A, {
                    ref: b,
                    children: y
                })) : null,
                children: g
            })
        }
        return g
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var s = h.forwardRef(a);
    b = s;
    g["default"] = b
}), 98);
__d("CometColumn.react", ["BaseView.react", "CometColumnContext", "CometColumnItem.react", "UserAgent", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            expanding: {
                flexBasis: "x1l7klhg",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minHeight: "x2lwn1j"
            },
            expandingIE11: {
                flexBasis: "xdl72j9"
            },
            inner: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                minHeight: "x2lwn1j"
            },
            root: {
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexShrink: "x2lah0s",
                maxWidth: "x193iq5w"
            }
        },
        l = {
            0: {
                paddingTop: "xexx8yu"
            },
            4: {
                paddingTop: "x1iorvi4"
            },
            8: {
                paddingTop: "x1y1aw1k"
            },
            12: {
                paddingTop: "xz9dl7a"
            },
            16: {
                paddingTop: "xyamay9"
            },
            20: {
                paddingTop: "x1cnzs8"
            }
        },
        m = {
            4: {
                paddingTop: "x1iorvi4",
                paddingBottom: "xjkvuk6"
            },
            8: {
                paddingTop: "x1y1aw1k",
                paddingBottom: "xwib8y2"
            },
            12: {
                paddingTop: "xz9dl7a",
                paddingBottom: "xsag5q8"
            },
            16: {
                paddingTop: "xyamay9",
                paddingBottom: "x1l90r2v"
            },
            20: {
                paddingTop: "x1cnzs8",
                paddingBottom: "xx6bls6"
            }
        },
        n = {
            bottom: {
                justifyContent: "x13a6bvl"
            },
            center: {
                justifyContent: "xl56j7k"
            },
            "space-between": {
                justifyContent: "x1qughib"
            }
        },
        o = c("UserAgent").isBrowser("IE >= 11");

    function a(a, b) {
        var d = a.align,
            e = d === void 0 ? null : d;
        d = a.children;
        var f = a.expanding;
        f = f === void 0 ? !1 : f;
        var g = a.hasDividers,
            p = g === void 0 ? !1 : g;
        g = a.paddingHorizontal;
        var q = g === void 0 ? null : g;
        g = a.paddingTop;
        var r = a.paddingVertical;
        r = r === void 0 ? 0 : r;
        var s = a.spacing,
            t = s === void 0 ? null : s;
        s = a.verticalAlign;
        s = s === void 0 ? "top" : s;
        var u = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["align", "children", "expanding", "hasDividers", "paddingHorizontal", "paddingTop", "paddingVertical", "spacing", "verticalAlign", "xstyle"]);
        var v = i(c("CometColumnContext")),
            w = j(function() {
                return {
                    align: e,
                    hasDividers: p,
                    paddingHorizontal: q,
                    spacing: t
                }
            }, [e, p, q, t]);
        a = h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            ref: b,
            xstyle: [k.root, f === !0 && [k.expanding, o && k.expandingIE11], m[r], g != null && l[g], u],
            children: h.jsx(c("BaseView.react"), {
                xstyle: [k.inner, s !== "top" && n[s]],
                children: h.jsx(c("CometColumnContext").Provider, {
                    value: w,
                    children: d
                })
            })
        }));
        if (v != null) {
            return h.jsx(c("CometColumnItem.react"), {
                expanding: (b = f) != null ? b : void 0,
                children: a
            })
        }
        return a
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    d = e;
    g["default"] = d
}), 98);
__d("CometContextualLayerAnchorRoot.react", ["BaseContextualLayerAnchorRoot.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("BaseContextualLayerAnchorRoot.react"), babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BasePopover.react", ["cr:2293", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            root: {
                position: "x1n2onr6"
            }
        };

    function a(a, c) {
        var d = a.arrowAlignment;
        d = d === void 0 ? "center" : d;
        var e = a.children,
            f = a.id,
            g = a.label,
            j = a.onBlur,
            k = a.onFocus,
            l = a.role;
        l = l === void 0 ? "dialog" : l;
        var m = a.testid;
        m = a.withArrow;
        a = m === void 0 ? !1 : m;
        return h.jsx(b("cr:2293"), {
            "aria-label": g,
            arrowAlignment: d,
            id: f,
            onBlur: j,
            onFocus: k,
            ref: c,
            role: l,
            testid: void 0,
            withArrow: a,
            xstyle: i.root,
            children: e
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    c = h.forwardRef(a);
    g["default"] = c
}), 98);
__d("useCometDisplayTimingTrackerForInteraction", ["cr:1791501", "performanceAbsoluteNow", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useCallback,
        i = e.useRef;

    function a(a, d, e) {
        d === void 0 && (d = !1);
        var f = i(null);
        return h(function(g) {
            if (a != null && f.current !== g) {
                f.current = g;
                if (g && b("cr:1791501")) {
                    var h = c("performanceAbsoluteNow")(),
                        i = b("cr:1791501").getCurrentVCTraces();
                    if (e != null) {
                        var j = i.get(e);
                        j && j.addMountPoint(g, h, a)
                    } else i.forEach(function(b) {
                        b.interactionType === "INTERACTION" && b.addMountPoint(g, h, a)
                    });
                    d || i.forEach(function(a) {
                        a.interactionType !== "INTERACTION" && a.excludeElement(g)
                    })
                }
            }
        }, [e, d, a])
    }
    g["default"] = a
}), 98);
__d("CometPopover.react", ["BaseContextualLayerOrientationContext", "BasePopover.react", "cr:1941981", "cr:1941982", "gkx", "isBlueprintStylesEnabled", "react", "stylex", "useCometDisplayTimingTrackerForInteraction"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            card: {
                boxSizing: "x9f619"
            },
            cardBackground: {
                backgroundColor: "x1jx94hy"
            },
            cardBorderRadius: {
                borderTopStartRadius: "x1qpq9i9",
                borderTopEndRadius: "xdney7k",
                borderBottomEndRadius: "xu5ydu1",
                borderBottomStartRadius: "xt3gfkd"
            },
            cardOverflow: {
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62"
            },
            cardShadow: {
                boxShadow: "x8ii3r7"
            }
        },
        k = {
            end: {
                borderBottomEndRadius: "x5pf9jr"
            },
            middle: {},
            start: {
                borderBottomStartRadius: "xo71vjh"
            },
            stretch: {}
        },
        l = {
            end: {
                borderTopEndRadius: "x13lgxp2"
            },
            middle: {},
            start: {
                borderTopStartRadius: "x168nmei"
            },
            stretch: {}
        },
        m = {
            end: {
                borderBottomEndRadius: "x5pf9jr"
            },
            middle: {},
            start: {
                borderTopEndRadius: "x13lgxp2"
            },
            stretch: {}
        },
        n = {
            end: {
                borderBottomStartRadius: "xo71vjh"
            },
            middle: {},
            start: {
                borderTopStartRadius: "x168nmei"
            },
            stretch: {}
        };

    function o(a, b) {
        switch (a) {
            case "above":
                return k[b];
            case "below":
                return l[b];
            case "end":
                return n[b];
            case "start":
                return m[b]
        }
    }

    function a(a, d) {
        var e = a.animatedPopover;
        e = e === void 0 ? !1 : e;
        var f = a.children,
            g = a.popoverName,
            k = a.withArrow;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["animatedPopover", "children", "popoverName", "withArrow"]);
        g = c("useCometDisplayTimingTrackerForInteraction")(g);
        var l = i(c("BaseContextualLayerOrientationContext")),
            m = l.align;
        l = l.position;
        return h.jsx(c("BasePopover.react"), babelHelpers["extends"]({}, a, {
            ref: d,
            withArrow: k,
            children: e && b("cr:1941981") != null && b("cr:1941982") != null ? h.jsx(b("cr:1941982"), {
                children: h.jsx(b("cr:1941981"), {
                    backgroundColorXStyle: j.cardBackground,
                    borderRadius: c("isBlueprintStylesEnabled")() ? 16 : 8,
                    boxShadowXStyle: j.cardShadow,
                    ref: g,
                    springConfig: {
                        bounciness: 4,
                        speed: 40
                    },
                    xstyle: j.card,
                    children: f
                })
            }) : h.jsx("div", {
                className: c("stylex")(j.card, j.cardBackground, j.cardShadow, j.cardBorderRadius, j.cardOverflow, k === !0 && c("gkx")("157") && o(l, m)),
                ref: g,
                children: f
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("getLoadingStateAriaProps", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b) {
        var c;
        b = a == null ? {
            "aria-valuetext": h._("Loading...")
        } : {
            "aria-valuemax": (c = b == null ? void 0 : b.max) != null ? c : 100,
            "aria-valuemin": (c = b == null ? void 0 : b.min) != null ? c : 0,
            "aria-valuenow": a
        };
        return babelHelpers["extends"]({
            role: "progressbar",
            tabIndex: 0
        }, b)
    }
    g["default"] = a
}), 98);
__d("useCometLoadingStateTracker", ["CometVisualCompletionAttributes", "cr:1791018", "cr:683059", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    var h = e.useEffect,
        i = e.useRef;

    function a() {
        var a = i(null);
        h(function() {
            var c = a.current,
                d = [];
            b("cr:1791018") && c != null && d.concat(b("cr:1791018").trackLoadingState(c));
            b("cr:683059") && c != null && d.push(b("cr:683059").trackLoadingState(c));
            return function() {
                d.forEach(function(a) {
                    a()
                })
            }
        }, []);
        return [c("CometVisualCompletionAttributes").LOADING_STATE, a]
    }
    g["default"] = a
}), 98);
__d("BaseLoadingStateElement.react", ["getLoadingStateAriaProps", "joinClasses", "react", "stylex", "useCometLoadingStateTracker", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            hideOutline: {
                outline: "x1a2a7pz"
            }
        },
        k = h.createContext(!1);

    function a(a, b) {
        var d = a.children,
            e = a.className_DEPRECATED,
            f = a.disableLoadingStateTracker;
        f = f === void 0 ? !1 : f;
        var g = a.isFocusTarget,
            l = a.progress,
            m = a.style,
            n = a.testid;
        n = a.xstyle;
        a = i(k);
        var o = c("useCometLoadingStateTracker")(),
            p = o[0];
        o = o[1];
        o = c("useMergeRefs")(b, o);
        if (a) return h.jsx("div", {
            className: c("joinClasses")(c("stylex")(n), e),
            "data-testid": void 0,
            ref: b,
            style: m,
            children: d
        });
        a = c("getLoadingStateAriaProps")(l, {
            max: 100,
            min: 0
        });
        return h.jsx(k.Provider, {
            value: !0,
            children: h.jsx("div", babelHelpers["extends"]({}, a, f ? {} : p, {
                className: c("joinClasses")(c("stylex")(j.hideOutline, n), e),
                "data-focus-target": g,
                "data-testid": void 0,
                ref: o,
                style: m,
                children: d
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("BaseImage.react", ["CometSSRPreloadImageCollection", "ExecutionEnvironment", "RecoverableViolationWithComponentStack.react", "mergeRefs", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useMemo,
        k = b.useRef,
        l = {
            contain: {
                objectFit: "x19kjcj4"
            },
            cover: {
                objectFit: "xl1xv1r"
            },
            fill: {
                objectFit: "xz74otr"
            }
        };

    function a(a, b) {
        var e = a.alt;
        e = e === void 0 ? "" : e;
        var f = a["aria-labelledby"],
            g = a.elementtiming,
            m = a.objectFit;
        m = m === void 0 ? "none" : m;
        var n = a.onLoad,
            o = a.referrerPolicy;
        o = o === void 0 ? "origin-when-cross-origin" : o;
        var p = a.src,
            q = a.testid,
            r = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["alt", "aria-labelledby", "elementtiming", "objectFit", "onLoad", "referrerPolicy", "src", "testid", "xstyle"]);
        var s = k(null),
            t = j(function() {
                return c("mergeRefs")(s, b)
            }, [s, b]);
        !c("ExecutionEnvironment").canUseDOM && p && d("CometSSRPreloadImageCollection").addImage(p);
        i(function() {
            var a = s.current;
            n != null && a != null && a.complete && n()
        }, [n]);
        return p === "" ? h.jsx(c("RecoverableViolationWithComponentStack.react"), {
            errorMessage: "Invalid src provided to image",
            projectName: "comet_ui"
        }) : h.jsx("img", babelHelpers["extends"]({}, a, c("testID")(q), {
            alt: e,
            "aria-labelledby": f,
            className: m === "none" && r == null ? void 0 : c("stylex")(m !== "none" && l[m], r),
            elementtiming: g,
            onLoad: n,
            ref: t,
            referrerPolicy: o,
            src: p
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometImageFromIXValue.react", ["BaseImage.react", "CometSSRBackgroundImageUtils", "CometVisualCompletionAttributes", "RecoverableViolationWithComponentStack.react", "coerceImageishSprited", "coerceImageishURL", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var e = a.alt;
        e = e === void 0 ? "" : e;
        var f = a.objectFit,
            g = a.source,
            i = a.testid;
        a = a.xstyle;
        d("CometSSRBackgroundImageUtils").processSpritedImagesForSSRPreload(g);
        var j = c("coerceImageishSprited")(g);
        if (j != null) {
            var k = c("stylex")(a);
            return h.jsx("i", babelHelpers["extends"]({}, c("CometVisualCompletionAttributes").CSS_IMG, c("testID")(i), {
                "aria-label": e === "" ? null : e,
                className: j.type === "css" ? k !== "" ? j.className + " " + k : j.className : k,
                ref: b,
                role: e === "" ? null : "img",
                style: j.type === "cssless" ? j.style : void 0
            }))
        }
        i = c("coerceImageishURL")(g);
        if (i != null) {
            k = i.height;
            j = i.uri;
            g = i.width;
            return h.jsx(c("BaseImage.react"), {
                alt: e,
                draggable: !1,
                height: f === "cover" ? "100%" : k,
                objectFit: f,
                ref: b,
                src: j,
                testid: void 0,
                width: f === "cover" ? "100%" : g,
                xstyle: a
            })
        }
        return h.jsx(c("RecoverableViolationWithComponentStack.react"), {
            errorMessage: "asset provided to CometImageFromIXValue cannot be transformed by Haste",
            projectName: "comet_ui"
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometProgressRingUtils", ["ix"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, c, d) {
        function e(a, b) {
            return 1 - 3 * b + 3 * a
        }

        function f(a, b) {
            return 3 * b - 6 * a
        }

        function g(a) {
            return 3 * a
        }

        function h(a, b, c) {
            return ((e(b, c) * a + f(b, c)) * a + g(b)) * a
        }

        function i(a, b, c) {
            return 3 * e(b, c) * a * a + 2 * f(b, c) * a + g(b)
        }

        function j(b) {
            var d = b;
            for (var e = 0; e < 4; ++e) {
                var f = i(d, a, c);
                if (f === 0) return d;
                var g = h(d, a, c) - b;
                d -= g / f
            }
            return d
        }
        return function(e) {
            return a === b && c === d ? e : h(j(e), b, d)
        }
    }

    function b(a, b, c) {
        switch (b) {
            case "12":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876411");
                            case "disabled":
                                return h("1876443");
                            case "dark":
                                return h("1876427");
                            case "light":
                                return h("1876427");
                            default:
                                return h("1876427")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876419");
                            case "disabled":
                                return h("1876451");
                            case "dark":
                                return h("1876435");
                            case "light":
                                return h("1876427");
                            default:
                                return h("1876435")
                        }
                    default:
                        return h("1876435")
                }
            case "16":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876412");
                            case "disabled":
                                return h("1876444");
                            case "dark":
                                return h("1876428");
                            case "light":
                                return h("1876428");
                            default:
                                return h("1876428")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876420");
                            case "disabled":
                                return h("1876452");
                            case "dark":
                                return h("1876436");
                            case "light":
                                return h("1876428");
                            default:
                                return h("1876436")
                        }
                    default:
                        return h("1876436")
                }
            case "20":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876413");
                            case "disabled":
                                return h("1876445");
                            case "dark":
                                return h("1876429");
                            case "light":
                                return h("1876429");
                            default:
                                return h("1876429")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876421");
                            case "disabled":
                                return h("1876453");
                            case "dark":
                                return h("1876437");
                            case "light":
                                return h("1876429");
                            default:
                                return h("1876437")
                        }
                    default:
                        return h("1876437")
                }
            case "24":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876414");
                            case "disabled":
                                return h("1876446");
                            case "dark":
                                return h("1876430");
                            case "light":
                                return h("1876430");
                            default:
                                return h("1876430")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876422");
                            case "disabled":
                                return h("1876454");
                            case "dark":
                                return h("1876438");
                            case "light":
                                return h("1876430");
                            default:
                                return h("1876438")
                        }
                    default:
                        return h("1876438")
                }
            case "32":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876415");
                            case "disabled":
                                return h("1876447");
                            case "dark":
                                return h("1876431");
                            case "light":
                                return h("1876431");
                            default:
                                return h("1876431")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876423");
                            case "disabled":
                                return h("1876455");
                            case "dark":
                                return h("1876439");
                            case "light":
                                return h("1876431");
                            default:
                                return h("1876439")
                        }
                    default:
                        return h("1876439")
                }
            case "48":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876416");
                            case "disabled":
                                return h("1876448");
                            case "dark":
                                return h("1876432");
                            case "light":
                                return h("1876432");
                            default:
                                return h("1876432")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876424");
                            case "disabled":
                                return h("1876456");
                            case "dark":
                                return h("1876440");
                            case "light":
                                return h("1876432");
                            default:
                                return h("1876440")
                        }
                    default:
                        return h("1876440")
                }
            case "60":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1940508");
                            case "disabled":
                                return h("1940512");
                            case "dark":
                                return h("1940510");
                            case "light":
                                return h("1940510");
                            default:
                                return h("1940510")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1940509");
                            case "disabled":
                                return h("1940513");
                            case "dark":
                                return h("1940511");
                            case "light":
                                return h("1940510");
                            default:
                                return h("1940511")
                        }
                    default:
                        return h("1940511")
                }
            case "72":
                switch (c) {
                    case "dark":
                        switch (a) {
                            case "blue":
                                return h("1876418");
                            case "disabled":
                                return h("1876450");
                            case "dark":
                                return h("1876434");
                            case "light":
                                return h("1876434");
                            default:
                                return h("1876434")
                        }
                    case "light":
                        switch (a) {
                            case "blue":
                                return h("1876426");
                            case "disabled":
                                return h("1876458");
                            case "dark":
                                return h("1876442");
                            case "light":
                                return h("1876434");
                            default:
                                return h("1876442")
                        }
                    default:
                        return h("1876442")
                }
            default:
                return h("1876439")
        }
    }

    function c(a) {
        switch (a) {
            case "dark":
                return {
                    backgroundColor: "var(--progress-ring-neutral-background)",
                    foregroundColor: "var(--progress-ring-neutral-foreground)"
                };
            case "light":
                return {
                    backgroundColor: "var(--progress-ring-on-media-background)",
                    foregroundColor: "var(--progress-ring-on-media-foreground)"
                };
            case "blue":
                return {
                    backgroundColor: "var(--progress-ring-blue-background)",
                    foregroundColor: "var(--progress-ring-blue-foreground)"
                };
            case "disabled":
                return {
                    backgroundColor: "var(--progress-ring-disabled-background)",
                    foregroundColor: "var(--progress-ring-disabled-foreground)"
                };
            default:
                return {
                    backgroundColor: "var(--progress-ring-neutral-background)",
                    foregroundColor: "var(--progress-ring-neutral-foreground)"
                }
        }
    }
    g.getCubicBezierPercentageFunc = a;
    g.getRingGifUrl = b;
    g.getRingColor = c
}), 98);
__d("CometProgressRingIndeterminate.react", ["BaseLoadingStateElement.react", "CometImageFromIXValue.react", "CometProgressRingUtils", "gkx", "react", "stylex", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            animationFillModeAndTimingFn: {
                animationFillMode: "x1u6ievf",
                animationTimingFunction: "x1wnkzza"
            },
            foregroundCircle: {
                animationDuration: "x1c74tu6",
                animationFillMode: "x1u6ievf",
                animationIterationCount: "xa4qsjk",
                animationTimingFunction: "xuxiujg",
                transformOrigin: "x1bndym7"
            },
            foregroundCircle12: {
                animationName: "x1g5b2fw"
            },
            foregroundCircle16: {
                animationName: "xwf99fl"
            },
            foregroundCircle20: {
                animationName: "x1azj7oz"
            },
            foregroundCircle24: {
                animationName: "xuooj1p"
            },
            foregroundCircle32: {
                animationName: "x3w3y3m"
            },
            foregroundCircle48: {
                animationName: "xhb48cq"
            },
            foregroundCircle60: {
                animationName: "x10stsnb"
            },
            foregroundCircle72: {
                animationName: "x152tzm6"
            },
            root: {
                display: "x78zum5"
            },
            rotationCircle: {
                animationDuration: "x1c74tu6",
                animationIterationCount: "xa4qsjk",
                animationName: "x1kfoseq",
                animationTimingFunction: "x193epu2",
                transformOrigin: "x1bndym7"
            }
        },
        j = 2,
        k = "always-enable-animations";

    function a(a) {
        var b = a.color,
            e = a.size,
            f = d("CometProgressRingUtils").getRingColor(b);
        f = f.foregroundColor;
        var g = (e - j) * Math.PI,
            l = c("useCurrentDisplayMode")();
        l = l === "dark";
        l = d("CometProgressRingUtils").getRingGifUrl(b, e.toString(), l ? "dark" : "light");
        return h.jsx(c("BaseLoadingStateElement.react"), {
            xstyle: [i.root, a.xstyle],
            children: !c("gkx")("4231") || b === "dark" ? h.jsx("svg", {
                className: [k, c("stylex")(i.rotationCircle, i.animationFillModeAndTimingFn)].join(" "),
                height: e,
                viewBox: "0 0 " + e + " " + e,
                width: e,
                children: h.jsx("circle", {
                    className: [k, c("stylex")([i.foregroundCircle, e === 12 && i.foregroundCircle12, e === 16 && i.foregroundCircle16, e === 20 && i.foregroundCircle20, e === 24 && i.foregroundCircle24, e === 32 && i.foregroundCircle32, e === 48 && i.foregroundCircle48, e === 60 && i.foregroundCircle60, e === 72 && i.foregroundCircle72])].join(" "),
                    cx: e / 2,
                    cy: e / 2,
                    fill: "none",
                    r: (e - j) / 2,
                    stroke: f,
                    strokeDasharray: g,
                    strokeWidth: j
                })
            }) : h.jsx("div", {
                style: {
                    height: e,
                    width: e
                },
                children: h.jsx(c("CometImageFromIXValue.react"), {
                    source: l,
                    testid: void 0
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometPopoverLoadingState.react", ["fbt", "CometPopover.react", "CometProgressRingIndeterminate.react", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = {
            root: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                height: "xnnlda6",
                justifyContent: "xl56j7k",
                minWidth: "x53cq04",
                width: "xh8yej3"
            }
        };

    function a(a) {
        var b = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["xstyle"]);
        return i.jsx(c("CometPopover.react"), babelHelpers["extends"]({
            label: h._("Loading...")
        }, a, {
            children: i.jsx("div", {
                className: c("stylex")(j.root, b),
                children: i.jsx(c("CometProgressRingIndeterminate.react"), {
                    color: "disabled",
                    size: 24
                })
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("deferredLoadComponentBase", ["Promise", "PromiseAnnotate", "react"], (function(a, b, c, d, e, f, g) {
    var h = c("react"),
        i = {},
        j = {},
        k = new Map();

    function l(a, b) {
        k.set(a, b)
    }

    function m(a) {
        return k.get(a)
    }

    function a(a, c) {
        var e = m(a);
        if (e) return e;
        var g, k = a.getModuleId();

        function n() {
            var d = j[k];
            d || (d = j[k] = new(b("Promise"))(function(b) {
                a.loadImmediately(function(a) {
                    delete j[k], g = c(a), b()
                })
            }));
            return d
        }

        function o() {
            var d = i[k];
            d || (d = i[k] = new(b("Promise"))(function(b) {
                a.onReady(function(a) {
                    g = c(a), delete i[k], b()
                })
            }));
            return d
        }

        function p(b, e) {
            var f = b.loadImmediately;
            b = babelHelpers.objectWithoutPropertiesLoose(b, ["loadImmediately"]);
            if (!g) {
                var i = a.getModuleIfRequireable();
                i != null && (g = c(i));
                if (!g) {
                    i = f === !0 ? n() : o();
                    d("PromiseAnnotate").setDisplayName(i, p.displayName);
                    throw i
                }
            }
            return h.jsx(g, babelHelpers["extends"]({}, b, {
                ref: e
            }))
        }
        p.displayName = p.name + " [from " + f.id + "]";
        p.displayName = "deferredLoadComponent(" + a.getModuleId() + ")";
        e = h.forwardRef(p);
        l(a, e);
        return e
    }
    g["default"] = a
}), 98);
__d("deferredLoadComponent", ["deferredLoadComponentBase"], (function(a, b, c, d, e, f, g) {
    var h = function(a) {
        return a
    };

    function a(a) {
        return c("deferredLoadComponentBase")(a, h)
    }
    g["default"] = a
}), 98);
__d("tracePolicyFromResource", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return a + "." + b.getModuleId()
    }
    f["default"] = a
}), 66);
__d("CometInteractionTracingQPLConfigContext", ["qpl", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    d = d("react");
    var i = d.useContext,
        j = d.useMemo;
    d = {
        dialogTraceQPLEvent: c("qpl")._(30605361, "6204"),
        popoverTraceQPLEvent: c("qpl")._(30605361, "6204")
    };
    var k = h.createContext(d);

    function a() {
        return i(k).dialogTraceQPLEvent
    }

    function b() {
        return i(k).popoverTraceQPLEvent
    }

    function e(a) {
        var b = a.children,
            c = a.dialogTraceQPLEvent,
            d = a.popoverTraceQPLEvent;
        return h.jsx(k.Provider, {
            value: j(function() {
                return {
                    dialogTraceQPLEvent: c,
                    popoverTraceQPLEvent: d
                }
            }, [c, d]),
            children: b
        })
    }
    e.displayName = e.name + " [from " + f.id + "]";
    g.defaultInteractionQPLEvents = d;
    g.useDialogTraceQPLEvent = a;
    g.usePopoverTraceQPLEvent = b;
    g.CometInteractionTracingQPLConfigContextProvider = e
}), 98);
__d("CometInteractionTracingConfig", ["cr:1486287"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        defaultTracePolicy: "comet.app",
        getMetadata: function() {
            return {
                darkMode: Number(b("cr:1486287").getDarkModePreference())
            }
        },
        navigationCancelsInteractions: !0
    };
    g.tracingConfig = a
}), 98);
__d("useCometRouteTracePolicy", ["useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "comet.app";

    function a() {
        var a;
        return (a = (a = c("useCurrentRoute")()) == null ? void 0 : a.tracePolicy) != null ? a : h
    }
    g["default"] = a
}), 98);
__d("useCometInteractionTracing", ["CometInteractionTracingConfig", "InteractionTracing", "forEachObject", "react", "useCometRouteTracePolicy", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback,
        i = 0;

    function j() {
        return i++
    }

    function a(a, b, e, f, g) {
        var i = (f = f) != null ? f : c("useCometRouteTracePolicy")(),
            k = "" + j();
        return h(function(f, h, j, l, m) {
            var n = c("uuid")(),
                o = (l = l) != null ? l : i,
                p = o + "_" + k + (m != null ? "_" + m : "");
            c("InteractionTracing").trace(a, function(a) {
                var b = c("InteractionTracing").checkAndMarkRevisit(o),
                    d = c("InteractionTracing").checkAndMarkRevisit(p);
                a.addMetadata("revisit", b ? 1 : 0);
                a.addMetadata("instance_revisit", d ? 1 : 0);
                g != null && c("forEachObject")(g, function(b, c) {
                    c != null && b != null && a.addMetadata(c, b)
                });
                f(a)
            }, b, e, o, n, h, j, d("CometInteractionTracingConfig").tracingConfig)
        }, [a, b, e, i])
    }
    g["default"] = a
}), 98);
__d("useCometPopoverInteractionTracing", ["CometInteractionTracingQPLConfigContext", "useCometInteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, e) {
        var f = d("CometInteractionTracingQPLConfigContext").usePopoverTraceQPLEvent();
        return c("useCometInteractionTracing")(f, "fluid", "INTERACTION", a, babelHelpers["extends"]({
            interaction_type: "popover",
            load_type: b
        }, e != null ? {
            preload_trigger: e
        } : null))
    }
    g["default"] = a
}), 98);
__d("CometDeferredPopoverTrigger.react", ["BasePopoverTrigger.react", "CometPopoverLoadingState.react", "deferredLoadComponent", "react", "tracePolicyFromResource", "useCometPopoverInteractionTracing"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.doNotCloseOnOutsideClick,
            d = a.fallback,
            e = a.popoverProps,
            f = a.popoverResource,
            g = a.preloadTrigger,
            i = a.tracePolicy;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["doNotCloseOnOutsideClick", "fallback", "popoverProps", "popoverResource", "preloadTrigger", "tracePolicy"]);
        var j = c("deferredLoadComponent")(f);
        i = c("useCometPopoverInteractionTracing")((i = i) != null ? i : c("tracePolicyFromResource")("comet.popover", f), "deferred", g);
        return h.jsx(c("BasePopoverTrigger.react"), babelHelpers["extends"]({
            doNotCloseOnOutsideClick: b,
            fallback: (b = d) != null ? b : h.jsx(c("CometPopoverLoadingState.react"), {
                withArrow: !0
            }),
            interactionTracker: i,
            popover: j,
            popoverPreloadResource: f,
            popoverProps: babelHelpers["extends"]({}, e, {
                loadImmediately: !0
            }),
            preloadTrigger: g
        }, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseDivider.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            divider: {
                backgroundColor: "x14nfmen",
                boxSizing: "x9f619",
                height: "xjm9jq1"
            },
            reset: {
                backgroundColor: "xjbqb8w",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                marginTop: "xdj266r",
                marginEnd: "x11i5rnm",
                marginBottom: "xat24cr",
                marginStart: "x1mh8g0r"
            }
        };

    function a(a) {
        return h.jsx("hr", {
            "aria-hidden": a.ariaHidden,
            className: c("stylex")(i.reset, i.divider, a.xstyle)
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDivider.react", ["BaseDivider.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsx(c("BaseDivider.react"), {
            xstyle: a.xstyle
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometGlimmer.react", ["BaseLoadingStateElement.react", "react", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useState,
        k = 200,
        l = {
            dark: {
                backgroundColor: "xhzw6zf"
            },
            paused: {
                animationPlayState: "xorstpt"
            },
            root: {
                animationDirection: "xpz12be",
                animationDuration: "x1q3qbx4",
                animationIterationCount: "xa4qsjk",
                animationName: "xeuoslp",
                animationTimingFunction: "x193epu2",
                backgroundColor: "x1vtvx1t",
                opacity: "xvpkmg4"
            }
        };

    function a(a) {
        var b = a.children,
            d = a.className,
            e = a.index,
            f = a.theme;
        f = f === void 0 ? "light" : f;
        a = a.xstyle;
        var g = j(!0),
            m = g[0],
            n = g[1];
        g = i(function(a) {
            a = a.hiddenReason;
            a !== "COMPONENT_UNMOUNTED" && n(!0)
        }, []);
        var o = i(function() {
            n(!1)
        }, []);
        g = c("useVisibilityObserver")({
            onHidden: g,
            onVisible: o
        });
        return h.jsx(c("BaseLoadingStateElement.react"), {
            className_DEPRECATED: d,
            ref: g,
            style: {
                animationDelay: e % 10 * k + "ms"
            },
            xstyle: [l.root, m && l.paused, f === "dark" && l.dark, a],
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseGlimmer.react", ["CometGlimmer.react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("CometGlimmer.react")
}), 98);
__d("useFeedImageErrorEventLoggerCbs", ["Banzai", "CometInteractionSourceContext", "Random", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useContext,
        j = b.useRef,
        k = 1e3,
        l = function(a) {
            var b = a.result,
                e = a.src;
            a = a.surface;
            d("Random").coinflip(k) && c("Banzai").post("logger:WWWImageLoadSrcEventLoggerConfig", {
                result: b,
                src: e,
                surface: a
            })
        };

    function a(a) {
        var b = a.onError,
            d = a.onLoad,
            e = a.src,
            f = j(null);
        a = i(c("CometInteractionSourceContext"));
        var g = a === 3 ? "profile" : a === 0 ? "feed" : null;
        a = h(function(a) {
            d != null && d(a);
            if (f.current === e) return;
            typeof e === "string" && (l({
                result: "success",
                src: e,
                surface: g
            }), f.current = e)
        }, [d, e, g]);
        var k = h(function(a) {
            b != null && b(a);
            if (f.current === e) return;
            typeof e === "string" && (l({
                result: "error",
                src: e,
                surface: g
            }), f.current = e)
        }, [b, e, g]);
        return g == null || typeof e !== "string" ? {
            _onError: b,
            _onLoad: d
        } : {
            _onError: k,
            _onLoad: a
        }
    }
    g["default"] = a
}), 98);
__d("CometImage.react", ["BaseImage.react", "CometImageFromIXValue.react", "cr:2010754", "gkx", "mergeRefs", "react", "useFeedImageErrorEventLoggerCbs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useMemo,
        j = e.useRef,
        k = "1";

    function a(a, d) {
        var e = j(null),
            f = i(function() {
                return c("mergeRefs")(e, d)
            }, [e, d]),
            g = a.alt,
            l = a.objectFit,
            m = a.onError,
            n = a.onLoad,
            o = a.src,
            p = a.testid;
        p = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["alt", "objectFit", "onError", "onLoad", "src", "testid", "xstyle"]);
        m = c("useFeedImageErrorEventLoggerCbs")({
            onError: m,
            onLoad: n,
            src: o
        });
        n = m._onError;
        m = m._onLoad;
        var q = c("gkx")("1690028") ? k : void 0;

        function r(a, c, d, f, g, h) {
            b("cr:2010754") && c === "mount" && e.current != null && typeof o === "string" && b("cr:2010754").trackImagePerf(e.current, h, o, {
                mutationType: "reactCommit"
            })
        }
        if (typeof o === "string") {
            a = h.jsx(c("BaseImage.react"), babelHelpers["extends"]({}, a, {
                alt: g,
                elementtiming: q,
                objectFit: l,
                onError: n,
                onLoad: m,
                ref: f,
                src: o,
                testid: void 0,
                xstyle: p
            }));
            return c("gkx")("1690028") ? h.jsx(h.Profiler, {
                id: k,
                onRender: r,
                children: a
            }) : a
        }
        return h.jsx(c("CometImageFromIXValue.react"), {
            alt: g,
            objectFit: l,
            ref: f,
            source: o,
            testid: void 0,
            xstyle: p
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    d = h.forwardRef(a);
    g["default"] = d
}), 98);
__d("CometPressableChildrenWithOverlay.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children;
        a = a.overlay;
        return h.jsxs("div", {
            className: "x1qrby5j x1n2onr6 xarpa2k x3igimt x1beo9mf x1jfb8zj x13rtm0m x1e5q0jg x3x9cwd x1o1ewxj x1h91t0o x4k7w5x",
            children: [b, a]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseSvgImage.react", ["react", "useFeedImageErrorEventLoggerCbs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useRef;

    function a(a) {
        var b = a.src,
            d = a.testid;
        d = babelHelpers.objectWithoutPropertiesLoose(a, ["src", "testid"]);
        a = c("useFeedImageErrorEventLoggerCbs")({
            src: b
        });
        var e = a._onError;
        a = a._onLoad;
        var f = j(null),
            g = j(b);
        i(function() {
            f.current && f.current.getAttribute("xlink:href") !== g.current && f.current.setAttribute("xlink:href", g.current)
        }, [f, g]);
        return h.jsx("image", babelHelpers["extends"]({}, d, {
            "data-testid": void 0,
            height: "100%",
            onError: e,
            onLoad: a,
            preserveAspectRatio: "xMidYMid slice",
            ref: f,
            width: "100%",
            xlinkHref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometLoadingAnimation.react", ["cssVar", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = 38,
        k = 62,
        l = 42,
        m = 2,
        n = 3,
        o = 4,
        p = j / 2,
        q = k / 2,
        r = l / 2,
        s = p - 2,
        t = q - 2,
        u = r - 2;

    function a(a) {
        var b = a.animationPaused;
        b = b === void 0 ? !1 : b;
        a = a.size;
        var d, e, f;
        switch (a) {
            case 36:
                d = j;
                e = p;
                f = s;
                break;
            case 40:
                d = l;
                e = r;
                f = u;
                break;
            case 60:
            default:
                d = k;
                e = q;
                f = t;
                break
        }
        return i.jsx("svg", {
            className: c("stylex")({
                "position-1": "x10l6tqk"
            }, a === 36 ? {
                "start-1": "x1150agl",
                "top-1": "x1e0gzzx"
            } : null, a === 60 ? {
                "start-1": "x1150agl",
                "top-1": "x1e0gzzx"
            } : null, a === 40 ? {
                "start-1": "x1150agl",
                "top-1": "x1e0gzzx"
            } : null),
            height: d,
            width: d,
            children: i.jsx("g", {
                className: "x1bndym7 x1esw782 xnjvcao xa4qsjk xeaay5l" + (b ? " xorstpt" : ""),
                children: i.jsx("circle", {
                    className: c("stylex")({
                        "animation-direction-1": "xeo85xg",
                        "animation-duration-1": "x7s8090",
                        "animation-iteration-count-1": "xa4qsjk",
                        "animation-timing-function-1": "x1esw782",
                        "transform-origin-1": "x1bndym7"
                    }, a === 36 ? {
                        "animation-direction-1": "xeo85xg",
                        "animation-duration-1": "xeaay5l",
                        "animation-iteration-count-1": "xa4qsjk",
                        "animation-name-1": "xq0anyh",
                        "animation-timing-function-1": "x1esw782",
                        "stroke-width-1": "xvlca1e"
                    } : null, a === 40 ? {
                        "animation-direction-1": "xeo85xg",
                        "animation-duration-1": "xeaay5l",
                        "animation-iteration-count-1": "xa4qsjk",
                        "animation-name-1": "x62hu5v",
                        "animation-timing-function-1": "x1esw782",
                        "stroke-width-1": "xqjr0vm"
                    } : null, a === 60 ? {
                        "animation-direction-1": "xeo85xg",
                        "animation-duration-1": "xeaay5l",
                        "animation-iteration-count-1": "xa4qsjk",
                        "animation-name-1": "xm4p48w",
                        "animation-timing-function-1": "x1esw782",
                        "stroke-width-1": "x17ld789"
                    } : null, b ? {
                        "animation-play-state-1": "xorstpt"
                    } : null),
                    cx: e,
                    cy: e,
                    fill: "none",
                    r: f,
                    stroke: "#1877F2",
                    strokeWidth: a === 36 ? m : a === 40 ? n : o
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getCometBadgeColorStyle", ["unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        blue: {
            backgroundColor: "xwnonoy"
        },
        darkGray: {
            backgroundColor: "xhazfnh"
        },
        gray: {
            backgroundColor: "x1d2osyd"
        },
        green: {
            backgroundColor: "xv9rvxn"
        },
        lightBlue: {
            backgroundColor: "xfmpgtx"
        },
        red: {
            backgroundColor: "x1cdvf7c"
        },
        yellow: {
            backgroundColor: "xacajkf"
        }
    };

    function a(a) {
        switch (a) {
            case "blue":
                return h.blue;
            case "gray":
                return h.gray;
            case "darkGray":
                return h.darkGray;
            case "green":
                return h.green;
            case "lightBlue":
                return h.lightBlue;
            case "red":
                return h.red;
            case "yellow":
                return h.yellow;
            default:
                a;
                throw c("unrecoverableViolation")(" Invalid color in getCometBadgeColorStyle", "comet_ui")
        }
    }
    g["default"] = a
}), 98);
__d("CometBadge.react", ["CometVisualCompletionAttributes", "getCometBadgeColorStyle", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            isNoneProfileBadge: {
                marginEnd: "x1emribx"
            },
            normalBorderRadius: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            root: {
                display: "x3nfvp2"
            }
        },
        j = {
            dark: {
                borderTopColor: "x1o7swki",
                borderEndColor: "xp7cj6j",
                borderBottomColor: "x1bkzgmd",
                borderStartColor: "xl02xpf"
            },
            none: {
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n"
            },
            white: {
                borderTopColor: "x6zyg47",
                borderEndColor: "x1xm1mqw",
                borderBottomColor: "xpn8fn3",
                borderStartColor: "xtct9fg"
            }
        },
        k = (b = {}, b[6] = {
            borderTopStartRadius: "x1npaq5j",
            borderTopEndRadius: "x1c83p5e",
            borderBottomEndRadius: "x1enjb0b",
            borderBottomStartRadius: "x199158v",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x5see2y",
            borderEndWidth: "x8ebbdf",
            borderBottomWidth: "x1pzews7",
            borderStartWidth: "x1r61nuk",
            height: "xols6we",
            width: "x1v4s8kt"
        }, b[7] = {
            borderTopStartRadius: "x1inr27j",
            borderTopEndRadius: "x1vcqv9c",
            borderBottomEndRadius: "xfrm7hi",
            borderBottomStartRadius: "xpbad92",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "x1hagigm",
            width: "xci0xqf"
        }, b[8] = {
            borderTopStartRadius: "x1lcm9me",
            borderTopEndRadius: "x1yr5g0i",
            borderBottomEndRadius: "xrt01vj",
            borderBottomStartRadius: "x10y3i5r",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "xdk7pt",
            width: "x1xc55vz"
        }, b[9] = {
            borderTopStartRadius: "x1kkc7ea",
            borderTopEndRadius: "x1yhqcir",
            borderBottomEndRadius: "x1hedi0j",
            borderBottomStartRadius: "xzmsszl",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "xegnrdp",
            width: "x1wc42o8"
        }, b[10] = {
            borderTopStartRadius: "x8u2fvd",
            borderTopEndRadius: "x1ht7hnu",
            borderBottomEndRadius: "x1quq95r",
            borderBottomStartRadius: "x5yzy4c",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "x170jfvy",
            width: "x1fsd2vl"
        }, b[12] = {
            borderTopStartRadius: "xhk9q7s",
            borderTopEndRadius: "x1otrzb0",
            borderBottomEndRadius: "x1i1ezom",
            borderBottomStartRadius: "x1o6z2jb",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "x1kpxq89",
            width: "xsmyaan"
        }, b[14] = {
            borderTopStartRadius: "x1rcc7c0",
            borderTopEndRadius: "xbtbmw4",
            borderBottomEndRadius: "x1lie4ck",
            borderBottomStartRadius: "x16hxpj1",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "x1v9usgg",
            width: "x6jxa94"
        }, b[15] = {
            borderTopStartRadius: "xu7oe1h",
            borderTopEndRadius: "x18k2onv",
            borderBottomEndRadius: "xlkxm3f",
            borderBottomStartRadius: "x1ehahlu",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "xx3o462",
            width: "x1a00udw"
        }, b[18] = {
            borderTopStartRadius: "x12myldv",
            borderTopEndRadius: "x1udsgas",
            borderBottomEndRadius: "xrc8dwe",
            borderBottomStartRadius: "xxxhv2y",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "xamhcws",
            borderEndWidth: "xol2nv",
            borderBottomWidth: "xlxy82",
            borderStartWidth: "x19p7ews",
            height: "xmix8c7",
            width: "x1xp8n7a"
        }, b[20] = {
            borderTopStartRadius: "x1a2cdl4",
            borderTopEndRadius: "xnhgr82",
            borderBottomEndRadius: "x1qt0ttw",
            borderBottomStartRadius: "xgk8upj",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x1gp4ovq",
            borderEndWidth: "xdio9jc",
            borderBottomWidth: "x1h2mt7u",
            borderStartWidth: "x7g060r",
            height: "x1qx5ct2",
            width: "xw4jnvo"
        }, b[22] = {
            borderTopStartRadius: "x13zp6kq",
            borderTopEndRadius: "x1mcfq15",
            borderBottomEndRadius: "xrosliz",
            borderBottomStartRadius: "x1wb7cse",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x1gp4ovq",
            borderEndWidth: "xdio9jc",
            borderBottomWidth: "x1h2mt7u",
            borderStartWidth: "x7g060r",
            height: "x17rw0jw",
            width: "x17z2i9w"
        }, b[24] = {
            borderTopStartRadius: "xyi19xy",
            borderTopEndRadius: "x1ccrb07",
            borderBottomEndRadius: "xtf3nb5",
            borderBottomStartRadius: "x1pc53ja",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x1gp4ovq",
            borderEndWidth: "xdio9jc",
            borderBottomWidth: "x1h2mt7u",
            borderStartWidth: "x7g060r",
            height: "xxk0z11",
            width: "xvy4d1p"
        }, b[32] = {
            borderTopStartRadius: "xfh8nwu",
            borderTopEndRadius: "xoqspk4",
            borderBottomEndRadius: "x12v9rci",
            borderBottomStartRadius: "x138vmkv",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x1gp4ovq",
            borderEndWidth: "xdio9jc",
            borderBottomWidth: "x1h2mt7u",
            borderStartWidth: "x7g060r",
            height: "x10w6t97",
            width: "x1td3qas"
        }, b[41] = {
            borderTopStartRadius: "xt49o24",
            borderTopEndRadius: "x1rtouj8",
            borderBottomEndRadius: "x12fpfo8",
            borderBottomStartRadius: "x136sihb",
            borderTopStyle: "x13fuv20",
            borderEndStyle: "xu3j5b3",
            borderBottomStyle: "x1q0q8m5",
            borderStartStyle: "x26u7qi",
            borderTopWidth: "x1gp4ovq",
            borderEndWidth: "xdio9jc",
            borderBottomWidth: "x1h2mt7u",
            borderStartWidth: "x7g060r",
            height: "x1njhlm6",
            width: "x1r9kitl"
        }, b),
        l = (e = {}, e[6] = {
            marginStart: "x1w4ip6v",
            width: "x1wc42o8"
        }, e[7] = {
            marginStart: "x1b2warb",
            width: "xaw7vzs"
        }, e[8] = {
            marginStart: "xsgj6o6",
            width: "xsmyaan"
        }, e[9] = {
            marginStart: "x1hvlnb8",
            width: "x197psvt"
        }, e[10] = {
            marginStart: "x8j4wrb",
            width: "x1a00udw"
        }, e[12] = {
            marginStart: "x1mnrxsn",
            width: "x1xp8n7a"
        }, e[14] = {
            marginStart: "xnfveip",
            width: "x1kl0l3y"
        }, e[15] = {
            marginStart: "xpw6ms",
            width: "xpcibvc"
        }, e[18] = {
            marginStart: "x1cxxrxm",
            width: "xo7uitg"
        }, e[20] = {
            marginStart: "x17adc0v",
            width: "x1849jeq"
        }, e[22] = {
            marginStart: "x1hy63sm",
            width: "x1npj6m0"
        }, e[24] = {
            marginStart: "x16n37ib",
            width: "x14qfxbe"
        }, e[32] = {
            marginStart: "x1d52u69",
            width: "x1useyqa"
        }, e[41] = {
            marginStart: "x1v860g0",
            width: "x1yaf2ey"
        }, e),
        m = (d = {}, d[6] = {
            marginStart: "x1mnrxsn",
            width: "xsmyaan"
        }, d[7] = {
            marginStart: "xnfveip",
            width: "x6jxa94"
        }, d[8] = {
            marginStart: "x1i64zmx",
            width: "x1kky2od"
        }, d[9] = {
            marginStart: "x1cxxrxm",
            width: "x1xp8n7a"
        }, d[10] = {
            marginStart: "x17adc0v",
            width: "xw4jnvo"
        }, d[12] = {
            marginStart: "x16n37ib",
            width: "xvy4d1p"
        }, d[14] = {
            marginStart: "xwycmqc",
            width: "xgd8bvy"
        }, d[15] = {
            marginStart: "x13ibhcj",
            width: "x1849jeq"
        }, d[18] = {
            marginStart: "x1sliqq",
            width: "x14qfxbe"
        }, d[20] = {
            marginStart: "xmn8rco",
            width: "x100vrsf"
        }, d[22] = {
            marginStart: "x1tv9t25",
            width: "x187nhsf"
        }, d[24] = {
            marginStart: "xmupa6y",
            width: "x1useyqa"
        }, d[32] = {
            marginStart: "x8vdgqj",
            width: "x1fu8urw"
        }, d[41] = {
            marginStart: "x2vb376",
            width: "x1pigqs1"
        }, d);

    function a(a) {
        var b = a.border;
        b = b === void 0 ? "none" : b;
        var d = a.children,
            e = a.color;
        e = e === void 0 ? "blue" : e;
        var f = a.isProfileBadge;
        f = f === void 0 ? !1 : f;
        var g = a.label,
            n = a.role,
            o = a.size;
        o = o === void 0 ? 8 : o;
        var p = a.testid,
            q = a.wide;
        q = q === void 0 ? "normal" : q;
        return h.jsx("span", babelHelpers["extends"]({
            "aria-label": g,
            className: c("stylex")(i.root, !f && i.isNoneProfileBadge, (g = a.colorOverride) != null ? g : c("getCometBadgeColorStyle")(e), k[o], j[b], q === "wide" && l[o], q === "extraWide" && m[o], q === "normal" && i.normalBorderRadius)
        }, c("testID")(p), c("CometVisualCompletionAttributes").IGNORE, {
            role: n,
            children: d
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometScreenReaderText.react", ["BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            visuallyHidden: {
                clip: "xzpqnlu",
                clipPath: "x1hyvwdk",
                height: "xjm9jq1",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x10l6tqk",
                width: "x1i1rx1s"
            }
        };

    function a(a) {
        var b = a.text;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["text"]);
        return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            xstyle: i.visuallyHidden,
            children: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometProfilePhotoAvailabilityBadge.react", ["fbt", "CometBadge.react", "CometPressableChildrenWithOverlay.react", "CometPressableOverlay.react", "CometScreenReaderText.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = h._("Active");

    function a(a) {
        var b = a.pressed;
        a = a.size;
        return i.jsxs("div", {
            className: "x1n2onr6 x10wlt62 x6ikm8r x78zum5 xww2gxu x18nykt9 xudhj91 x14yjl9h",
            children: [i.jsx(c("CometPressableChildrenWithOverlay.react"), {
                overlay: i.jsx(c("CometPressableOverlay.react"), {
                    pressed: b,
                    radius: "50%"
                }),
                children: i.jsx(c("CometBadge.react"), {
                    color: "green",
                    isProfileBadge: !0,
                    size: a
                })
            }), i.jsx(c("CometScreenReaderText.react"), {
                text: j
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useServerTime", ["JSScheduler", "ServerTime", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useState,
        j = 6e4,
        k = new Set(),
        l = null,
        m = !1;

    function n() {
        k.forEach(function(a) {
            return a()
        }), m = !1
    }

    function o(a) {
        a === void 0 && (a = j), l = window.setInterval(function() {
            m || (m = !0, d("JSScheduler").scheduleSpeculativeCallback(n))
        }, a)
    }

    function p() {
        k.size === 0 && (window.clearInterval(l), l = null)
    }

    function q(a, b) {
        b === void 0 && (b = j);
        k.add(a);
        l == null && o(b);
        return function() {
            k["delete"](a), p()
        }
    }

    function r() {
        return new Date(d("ServerTime").getMillis())
    }

    function a(a) {
        a === void 0 && (a = j);
        var b = i(function() {
                return r()
            }),
            c = b[0],
            d = b[1],
            e = function() {
                return d(r())
            };
        h(function() {
            return q(e, a)
        }, [a]);
        return c
    }
    g["default"] = a
}), 98);
__d("CometRelativeTimestamp.react", ["fbt", "react", "useServerTime"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    e = d("react");

    function i(a, b) {
        if (b === "minimized") return h._("1m");
        else if (b === "shortened") return h._("Just now");
        return h._("a few seconds ago")
    }

    function j(a, b) {
        return b === "minimized" ? h._("1m") : h._("in a few seconds")
    }

    function k(a, b) {
        if (b === "minimized") return h._({
            "*": "{minutes}m"
        }, [h._param("minutes", a, [0])]);
        else if (b === "shortened") return h._({
            "*": "{number} mins",
            "_1": "1 min"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "{number} minutes ago",
            "_1": "about a minute ago"
        }, [h._plural(a, "number")])
    }

    function l(a, b) {
        if (b === "minimized") return h._({
            "*": "in {minutes}m"
        }, [h._param("minutes", a, [0])]);
        else if (b === "shortened") return h._({
            "*": "in {number} mins",
            "_1": "in 1 min"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "in {number} minutes",
            "_1": "in about a minute"
        }, [h._plural(a, "number")])
    }

    function m(a, b) {
        if (b === "minimized") return h._("{hours}h", [h._param("hours", a)]);
        else if (b === "shortened") return h._({
            "*": "{number} hrs",
            "_1": "1 hr"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "{number} hours ago",
            "_1": "about an hour ago"
        }, [h._plural(a, "number")])
    }

    function n(a, b) {
        if (b === "minimized") return h._("in {hours}h", [h._param("hours", a)]);
        else if (b === "shortened") return h._({
            "*": "in {number} hrs",
            "_1": "in 1 hr"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "in {number} hours",
            "_1": "in about an hour"
        }, [h._plural(a, "number")])
    }

    function o(a, b) {
        if (b === "minimized") return h._("{days}d", [h._param("days", a)]);
        else if (b === "shortened") return h._({
            "*": "{number} days",
            "_1": "1 day"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "{number} days ago",
            "_1": "a day ago"
        }, [h._plural(a, "number")])
    }

    function p(a, b) {
        if (b === "minimized") return h._("in {days}d", [h._param("days", a)]);
        else if (b === "shortened") return h._({
            "*": "in {number} days",
            "_1": "in 1 day"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "in {number} days",
            "_1": "in a day"
        }, [h._plural(a, "number")])
    }

    function q(a, b) {
        if (b === "minimized") return h._("{weeks}w", [h._param("weeks", a)]);
        else if (b === "shortened") return h._({
            "*": "{number} wks",
            "_1": "1 wk"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "{number} weeks ago",
            "_1": "a week ago"
        }, [h._plural(a, "number")])
    }

    function r(a, b) {
        if (b === "minimized") return h._("in {weeks}w", [h._param("weeks", a)]);
        else if (b === "shortened") return h._({
            "*": "in {number} wks",
            "_1": "in 1 wk"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "in {number} weeks",
            "_1": "in a week"
        }, [h._plural(a, "number")])
    }

    function s(a, b) {
        if (b === "minimized") return h._("{years}y", [h._param("years", a)]);
        else if (b === "shortened") return h._({
            "*": "{number} yrs",
            "_1": "1 yr"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "{number} years ago",
            "_1": "a year ago"
        }, [h._plural(a, "number")])
    }

    function t(a, b) {
        if (b === "minimized") return h._("in {years}y", [h._param("years", a)]);
        else if (b === "shortened") return h._({
            "*": "in {number} yrs",
            "_1": "in 1 yr"
        }, [h._plural(a, "number")]);
        return h._({
            "*": "in {number} years",
            "_1": "in a year"
        }, [h._plural(a, "number")])
    }
    var u = 60,
        v = 60,
        w = 24,
        x = 7,
        y = 365;

    function z(a, b, c) {
        c === void 0 && (c = "normal");
        a = (a.valueOf() - b.valueOf()) / 1e3;
        if (a < u) return i(a, c);
        b = a / u;
        a = Math.floor(b);
        if (a < v) return k(a, c);
        a = b / v;
        b = Math.floor(a);
        if (b < w) return m(b, c);
        b = a / w;
        a = Math.floor(b);
        if (a < x) return o(a, c);
        else if (b < y) {
            a = Math.floor(b / x);
            return q(a, c)
        }
        a = Math.floor(b / y);
        return s(a, c)
    }

    function a(a, b, c) {
        c === void 0 && (c = "normal");
        b = (b.valueOf() - a.valueOf()) / 1e3;
        if (b < u) return j(b, c);
        a = b / u;
        b = Math.floor(a);
        if (b < v) return l(b, c);
        b = a / v;
        a = Math.floor(a / v);
        if (a < w) return n(a, c);
        a = b / w;
        b = Math.floor(a);
        if (b < x) return p(b, c);
        else if (a < y) {
            b = Math.floor(a / x);
            return r(b, c)
        }
        b = Math.floor(a / y);
        return t(b, c)
    }

    function b(a) {
        var b = a.date;
        a = a.format;
        var d = c("useServerTime")();
        d = z(d, b, a);
        return d
    }
    b.displayName = b.name + " [from " + f.id + "]";
    b.getRelativeTimestamp = z;
    b.getRelativeTimestampInFuture = a;
    g["default"] = b
}), 98);
__d("MWChatActivePill.react", ["CometPressableChildrenWithOverlay.react", "CometPressableOverlay.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            badge: {
                backgroundColor: "xbb192p",
                borderTopStartRadius: "xhw592a",
                borderTopEndRadius: "xwihvcr",
                borderBottomEndRadius: "x7wuybg",
                borderBottomStartRadius: "xb9tvrk",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "xamhcws",
                borderEndWidth: "xol2nv",
                borderBottomWidth: "xlxy82",
                borderStartWidth: "x19p7ews",
                boxSizing: "x9f619",
                display: "x78zum5",
                fontWeight: "x117nqv4",
                justifyContent: "xl56j7k",
                marginTop: "x1kgmq87",
                marginEnd: "xwrv7xz",
                marginBottom: "xmgb6t1",
                marginStart: "x8182xy",
                paddingEnd: "xg83lxy",
                paddingStart: "x1h0ha7o"
            },
            badgeContainer: {
                display: "x78zum5",
                justifyContent: "xl56j7k",
                maxWidth: "x193iq5w"
            },
            inner: {
                color: "x6u5lvz",
                fontSize: "x190qgfh",
                lineHeight: "x132q4wb",
                whiteSpace: "xuxw1ft"
            }
        },
        j = {
            "card-background": {
                borderTopColor: "x6zyg47",
                borderEndColor: "x1xm1mqw",
                borderBottomColor: "xpn8fn3",
                borderStartColor: "xtct9fg"
            },
            "secondary-button-background-floating": {
                borderTopColor: "x1bmsi4x",
                borderEndColor: "xrcl4xe",
                borderBottomColor: "x17j0sh5",
                borderStartColor: "x14li8yl"
            },
            "web-wash": {
                borderTopColor: "x1516sgx",
                borderEndColor: "x1fjwj1m",
                borderBottomColor: "x1khxuxv",
                borderStartColor: "x4gm0zg"
            }
        };

    function a(a) {
        var b = a.border;
        b = b === void 0 ? "card-background" : b;
        var d = a.children;
        a = a.pressed;
        return h.jsx("div", {
            className: c("stylex")(i.badgeContainer),
            children: h.jsx(c("CometPressableChildrenWithOverlay.react"), {
                overlay: h.jsx(c("CometPressableOverlay.react"), {
                    pressed: a,
                    radius: 7
                }),
                children: h.jsx("div", {
                    className: c("stylex")(i.badge, j[b]),
                    children: h.jsx("span", {
                        className: c("stylex")(i.inner),
                        children: d
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometProfilePhotoLastActiveTimeBadge.react", ["CometRelativeTimestamp.react", "MWChatActivePill.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.border;
        b = b === void 0 ? "card-background" : b;
        var d = a.pressed;
        a = a.time;
        return h.jsx(c("MWChatActivePill.react"), {
            border: b,
            pressed: d,
            children: h.jsx(c("CometRelativeTimestamp.react"), {
                date: new Date(a * 1e3),
                format: "minimized"
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometProfilePhotoNotificationBadge.react", ["CometBadge.react", "TetraText.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.number;
        return h.jsx(c("CometBadge.react"), {
            color: "red",
            isProfileBadge: !0,
            size: 18,
            wide: a > 9 ? "wide" : "normal",
            children: h.jsx("div", {
                className: "xh8yej3 xuxw1ft xl56j7k x5yr21d x78zum5 x6s0dn4",
                children: h.jsx(c("TetraText.react"), {
                    color: "primaryOnMedia",
                    type: "body4",
                    children: a > 9 ? "9+" : a
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSSRSuspendOnServer.react", ["CometSSRClientRender", "CometSSRReactFizzEnvironment", "ExecutionEnvironment", "Promise", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function a(a) {
        a = a.children;
        if (c("ExecutionEnvironment").canUseDOM) return a;
        if (d("CometSSRReactFizzEnvironment").isReactFizzEnvironment()) throw d("CometSSRClientRender").CometSSRClientRender();
        else throw new(b("Promise"))(function() {})
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometSSRReplaceContentOnHydrationAndBreakEventReplaying.react", ["CometPlaceholder.react", "CometSSRSuspendOnServer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.children;
        a = a.useSuspenseDirectlyForSVG;
        a = a === !0 ? h.Suspense : c("CometPlaceholder.react");
        return h.jsx(a, {
            fallback: b,
            children: h.jsx(c("CometSSRSuspendOnServer.react"), {
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTrackingNodeAbstractViewHierarchyWrapperContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    a = d("react").createContext;
    b = a(void 0);
    c = b;
    g["default"] = c
}), 98);
__d("TrackingNodeConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 58;
    b = 126;
    c = 69;
    d = 42;
    e = 47;
    var g = 6,
        h = 100,
        i = 33,
        j = 38,
        k = (g + 1) * c,
        l = "__tn__";
    f.BASE_CODE_START = a;
    f.BASE_CODE_END = b;
    f.BASE_CODE_SIZE = c;
    f.PREFIX_CODE_START = d;
    f.PREFIX_CODE_END = e;
    f.PREFIX_CODE_SIZE = g;
    f.ENCODE_NUMBER_MAX = h;
    f.ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE = i;
    f.ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE = j;
    f.TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING = k;
    f.TN_URL_PARAM = l
}), 66);
__d("encodeTrackingNode", ["TrackingNodeConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        var c = function(a) {
                return Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, a)
            },
            e = function(a, b) {
                var c = "";
                a = a;
                b = b;
                while (b > 0) {
                    var e = a % d("TrackingNodeConstants").BASE_CODE_SIZE;
                    c = String.fromCharCode(d("TrackingNodeConstants").BASE_CODE_START + e) + c;
                    a = parseInt(a / d("TrackingNodeConstants").BASE_CODE_SIZE, 10);
                    b -= 1
                }
                return c
            },
            f = function(a) {
                a = a - d("TrackingNodeConstants").TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING - 1;
                if (a < c(2)) return String.fromCharCode(d("TrackingNodeConstants").ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE) + e(a, 2);
                a -= c(2);
                return String.fromCharCode(d("TrackingNodeConstants").ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE) + e(a, 3)
            },
            g = (a - 1) % d("TrackingNodeConstants").BASE_CODE_SIZE,
            h = parseInt((a - 1) / d("TrackingNodeConstants").BASE_CODE_SIZE, 10);
        if (a < 1 || a > (d("TrackingNodeConstants").PREFIX_CODE_SIZE + 1) * d("TrackingNodeConstants").BASE_CODE_SIZE + Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, 2) + Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, 3)) throw Error("Invalid tracking node: " + a);
        var i = "";
        h > d("TrackingNodeConstants").PREFIX_CODE_SIZE ? i += f(a) : (h > 0 && (i += String.fromCharCode(h - 1 + d("TrackingNodeConstants").PREFIX_CODE_START)), i += String.fromCharCode(g + d("TrackingNodeConstants").BASE_CODE_START));
        b !== void 0 && b > 0 && (b > 10 && (i += "#"), i += parseInt(Math.min(b, d("TrackingNodeConstants").ENCODE_NUMBER_MAX) - 1, 10));
        return i
    }
    g["default"] = a
}), 98);
__d("useCometTrackingNodes", ["CometTrackingNodesContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometTrackingNodesContext"))
    }
    g["default"] = a
}), 98);
__d("CometTrackingNodeProvider.react", ["CometTrackingNodeAbstractViewHierarchyWrapperContext", "CometTrackingNodesContext", "encodeTrackingNode", "react", "useCometTrackingNodes"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.children,
            d = a.index,
            e = a.trackingNode,
            f = c("useCometTrackingNodes")();
        a = j(function() {
            if (e == null) return f;
            var a = c("encodeTrackingNode")(e, d);
            return [a].concat(f)
        }, [f, e, d]);
        var g = b,
            k = i(c("CometTrackingNodeAbstractViewHierarchyWrapperContext"));
        k != null && (g = k(a, b));
        return h.jsx(c("CometTrackingNodesContext").Provider, {
            value: a,
            children: g
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometProfileVideoGlimmer.react", ["CometGlimmer.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            container: {
                position: "x1n2onr6"
            },
            glimmer: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                height: "x5yr21d",
                position: "x10l6tqk",
                start: "x17qophe",
                top: "x13vifvy",
                width: "xh8yej3"
            }
        };

    function a(a) {
        a = a.size;
        return h.jsx("div", {
            className: c("stylex")(i.container),
            style: {
                height: a,
                width: a
            },
            children: h.jsx(c("CometGlimmer.react"), {
                index: 0,
                xstyle: i.glimmer
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("LazyCometProfileVideoSection.react", ["CometPlaceholder.react", "CometProfileVideoGlimmer.react", "JSResourceForInteraction", "lazyLoadComponent", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = c("lazyLoadComponent")(c("JSResourceForInteraction")("CometProfileVideoSection.react").__setRef("LazyCometProfileVideoSection.react"));

    function a(a) {
        return h.jsx(c("CometPlaceholder.react"), {
            fallback: h.jsx(c("CometProfileVideoGlimmer.react"), {
                size: a.size
            }),
            children: h.jsx(i, babelHelpers["extends"]({}, a))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("profilePhotoUtils", ["Locale", "memoizeWithArgs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("memoizeWithArgs")(function(a, b) {
        b === void 0 && (b = !1);
        a = Math.sqrt(2 * a * a) - a;
        a = Math.round(Math.sqrt(a * a / 2));
        if (b)
            if (d("Locale").isRTL()) return {
                left: a,
                top: a,
                transform: "translate(-50%, -50%)"
            };
            else return {
                right: a,
                top: a,
                transform: "translate(50%, -50%)"
            };
        else if (d("Locale").isRTL()) return {
            bottom: a,
            left: a,
            transform: "translate(-50%, 50%)"
        };
        else return {
            bottom: a,
            right: a,
            transform: "translate(50%, 50%)"
        }
    }, function(a, b) {
        return String(b) + String(a)
    });
    b = c("memoizeWithArgs")(function(a) {
        switch (a) {
            case 24:
            case 32:
            case 36:
            case 40:
                return 2;
            case 48:
            case 56:
            case 60:
                return 3;
            case 132:
            default:
                return 4
        }
    }, function(a) {
        return String(a)
    });
    e = c("memoizeWithArgs")(function(a, b) {
        if (b === "availabilityBadge") switch (a) {
            case 16:
            case 20:
            case 24:
                return [6, 1.5];
            case 28:
                return [7, 2];
            case 32:
            case 36:
                return [8, 2];
            case 40:
            case 48:
                return [9, 2];
            case 56:
            case 60:
                return [10, 2];
            case 72:
                return [12, 2];
            case 80:
            case 88:
                return [14, 2];
            case 96:
            case 100:
                return [15, 2];
            case 120:
            case 132:
            case 168:
                return [20, 4];
            default:
                a;
                return [8, 2]
        }
        switch (a) {
            case 16:
            case 20:
            case 24:
                return [6, 1.5];
            case 28:
                return [7, 1.5];
            case 32:
                return [8, 2];
            case 36:
                return [9, 2];
            case 40:
                return [10, 2];
            case 48:
                return [12, 2];
            case 56:
                return [14, 2];
            case 60:
                return [15, 2];
            case 72:
                return [18, 2];
            case 80:
                return [20, 4];
            case 88:
                return [22, 4];
            case 96:
            case 100:
                return [24, 4];
            case 120:
            case 132:
                return [32, 4];
            case 168:
                return [41, 4];
            default:
                a;
                return [8, 2]
        }
    }, function(a, b) {
        return String(a) + b
    });
    g.getBadgePosition = a;
    g.getStoryRingSize = b;
    g.getBadgeSizeAndStrokeWidth = e
}), 98);
__d("useSetAttributeRef", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback;

    function a(a, b) {
        return h(function(c) {
            c != null && c.setAttribute(a, b)
        }, [a, b])
    }
    g["default"] = a
}), 98);
__d("CometProfilePhoto.react", ["BaseSvgImage.react", "CometErrorBoundary.react", "CometImage.react", "CometLoadingAnimation.react", "CometPlaceholder.react", "CometPressable.react", "CometPressableChildrenWithOverlay.react", "CometPressableOverlay.react", "CometProfilePhotoAvailabilityBadge.react", "CometProfilePhotoLastActiveTimeBadge.react", "CometProfilePhotoNotificationBadge.react", "CometSSRReplaceContentOnHydrationAndBreakEventReplaying.react", "CometSSRSuspendOnServer.react", "CometTrackingNodeProvider.react", "CometVisualCompletionAttributes", "LazyCometProfileVideoSection.react", "profilePhotoUtils", "react", "stylex", "useCometUniqueID", "useSetAttributeRef"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            activityBadge: {
                alignItems: "x6s0dn4",
                borderBottomStyle: "x1q0q8m5",
                borderBottomWidth: "x1qhh985",
                borderEndStyle: "xu3j5b3",
                borderEndWidth: "xcfux6l",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                borderStartStyle: "x26u7qi",
                borderStartWidth: "xm0m39n",
                borderTopStyle: "x13fuv20",
                borderTopWidth: "x972fbf",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                justifyContent: "xl56j7k",
                marginBottom: "xat24cr",
                marginEnd: "x11i5rnm",
                marginStart: "x1mh8g0r",
                marginTop: "xdj266r",
                minHeight: "x2lwn1j",
                minWidth: "xeuugli",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingBottom: "x18d9i69",
                paddingEnd: "x4uap5",
                paddingStart: "xkhd6sd",
                paddingTop: "xexx8yu",
                position: "x1n2onr6",
                zIndex: "x1ja2u2z"
            },
            activityIcon10: {
                height: "x17rw0jw",
                paddingTop: "x123j3cw",
                paddingEnd: "x1mpkggp",
                paddingBottom: "xs9asl8",
                paddingStart: "x1t2a60a",
                width: "x17z2i9w"
            },
            activityIcon16: {
                height: "xd7y6wv",
                paddingTop: "x123j3cw",
                paddingEnd: "x1mpkggp",
                paddingBottom: "xs9asl8",
                paddingStart: "x1t2a60a",
                width: "x23j0i4"
            },
            activityIcon8: {
                height: "x1v9usgg",
                width: "x6jxa94"
            },
            badge: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                position: "x10l6tqk",
                zIndex: "xhtitgo"
            },
            badgeWithBorder: {
                borderTopColor: "x1aoij9j",
                borderEndColor: "xxpsvdv",
                borderBottomColor: "x2e7n7m",
                borderStartColor: "x9387xi",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi"
            },
            badgeWithLastActiveTime: {
                bottom: "x1ey2m1c",
                display: "x78zum5",
                end: "xds687c",
                justifyContent: "x13a6bvl",
                start: "x17qophe"
            },
            badgeWithShadow: {
                boxShadow: "x14ihvte"
            },
            insetSVG: {
                fill: "xbh8q5q",
                stroke: "x1pwv2dq",
                strokeWidth: "xvlca1e"
            },
            photo: {
                verticalAlign: "x3ajldb"
            },
            photoCircle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            photoRoundedRect: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c"
            },
            pressable: {
                color: "xzsf02u",
                display: "x1rg5ohu"
            },
            pressed: {
                transform: "x1n5d1j9"
            },
            storyRingBlue: {
                stroke: "x1p5r69i"
            },
            storyRingGray: {
                stroke: "x1tbtn3x"
            },
            storyRingGreen: {
                stroke: "x1cm6qz0"
            },
            storyRingRed: {
                stroke: "x1c97i5p"
            },
            storyRingSize2: {
                strokeWidth: "xvlca1e"
            },
            storyRingSize3: {
                strokeWidth: "xqjr0vm"
            },
            storyRingSize4: {
                strokeWidth: "x17ld789"
            },
            svgOverlay: {
                fill: "x1tgjyoi"
            },
            videoContainer: {
                WebkitMaskImage: "x1u31j2f",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62"
            },
            videoContainerRectRounded: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c"
            },
            videoContainerRounded: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            wrapper: {
                display: "x1rg5ohu",
                position: "x1n2onr6",
                verticalAlign: "x3ajldb",
                zIndex: "x1ja2u2z"
            }
        };

    function a(a, b) {
        var e = a.addOn,
            f = a.addOnTopEnd,
            g = a.alt,
            k = a.children,
            l = a.cursorDisabled,
            m = a.isOverlapped,
            n = m === void 0 ? !1 : m,
            o = a.linkProps,
            p = a.onHoverIn,
            q = a.onHoverOut,
            r = a.onPress,
            s = a.onPressIn;
        m = a.overlayDisabled;
        m = m === void 0 ? !1 : m;
        a.preview;
        var t = a.profileVideo,
            u = a.shape,
            v = u === void 0 ? "circle" : u;
        u = a.shouldShowCloseFriendsBadge;
        var w = u === void 0 ? !1 : u,
            x = a.size,
            y = a.source;
        u = a.storyStatus;
        var z = u === void 0 ? "none" : u;
        u = a.testid;
        u = a.testOnly_pressed;
        a.testOnly_previewDelay;
        var A = babelHelpers.objectWithoutPropertiesLoose(a, ["addOn", "addOnTopEnd", "alt", "children", "cursorDisabled", "isOverlapped", "linkProps", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "overlayDisabled", "preview", "profileVideo", "shape", "shouldShowCloseFriendsBadge", "size", "source", "storyStatus", "testid", "testOnly_pressed", "testOnly_previewDelay"]),
            B = c("useCometUniqueID")(),
            C = c("useSetAttributeRef")("id", B),
            D = "url(#" + B + ")",
            E = c("useSetAttributeRef")("mask", D),
            F = function(a, b) {
                var l, m = a.overlay;
                a = a.pressed;
                var u = z !== "none" ? d("profilePhotoUtils").getStoryRingSize(x) : 0,
                    F = d("profilePhotoUtils").getBadgePosition(x / 2, !0),
                    G = d("profilePhotoUtils").getBadgeSizeAndStrokeWidth(x, e == null ? void 0 : e.type),
                    H = G[0];
                G = G[1];
                var I = t != null ? {
                        borderWidth: G
                    } : {},
                    J = (e == null ? void 0 : e.type) === "lastActiveTimeBadge" && x > 28,
                    K = J ? {} : d("profilePhotoUtils").getBadgePosition(x / 2, !1);
                J = e != null ? h.jsx("div", babelHelpers["extends"]({
                    className: c("stylex")(i.badge, J && i.badgeWithLastActiveTime, x === 60 && e.type === "activityBadge" && i.badgeWithShadow, e.type === "activityBadge" && (t != null || e.withBorder) && i.badgeWithBorder)
                }, c("CometVisualCompletionAttributes").IGNORE, {
                    style: babelHelpers["extends"]({}, K, I),
                    children: h.jsx(j, {
                        addOn: e,
                        pressed: a,
                        size: x
                    })
                })) : null;
                I = f != null ? h.jsx("div", {
                    className: c("stylex")(i.badge),
                    style: babelHelpers["extends"]({}, F),
                    children: h.jsx(c("CometProfilePhotoNotificationBadge.react"), {
                        number: f.number
                    })
                }) : null;
                var L = typeof y.uri === "string" ? h.jsx(c("BaseSvgImage.react"), {
                    src: y.uri,
                    style: {
                        height: x - u * 4,
                        width: x - u * 4
                    },
                    x: 2 * u,
                    y: 2 * u
                }) : h.jsx(c("CometImage.react"), {
                    alt: g,
                    height: x - 4 * u,
                    src: y.uri,
                    testid: void 0,
                    width: x - 4 * u,
                    xstyle: [i.photo, v === "circle" && i.photoCircle, v === "roundedRect" && i.photoRoundedRect]
                });
                H = typeof y.uri === "string" ? h.jsxs("svg", babelHelpers["extends"]({
                    "aria-hidden": g == null ? !0 : void 0,
                    "aria-label": g,
                    className: c("stylex")(i.photo)
                }, c("CometVisualCompletionAttributes").IGNORE_DYNAMIC, {
                    role: g != null ? "img" : "none",
                    style: {
                        height: x,
                        width: x
                    },
                    children: [h.jsxs("mask", {
                        id: B,
                        ref: C,
                        suppressHydrationWarning: !0,
                        children: [v === "circle" ? h.jsx("circle", {
                            cx: x / 2,
                            cy: x / 2,
                            fill: "white",
                            r: x / 2
                        }) : h.jsx("rect", {
                            cy: x / 2,
                            fill: "white",
                            height: x,
                            rx: v === "square" ? 0 : 8,
                            ry: v === "square" ? 0 : 8,
                            width: x,
                            x: 0,
                            y: 0
                        }), h.jsx(c("CometSSRReplaceContentOnHydrationAndBreakEventReplaying.react"), {
                            useSuspenseDirectlyForSVG: !0,
                            children: J != null && (e == null ? void 0 : e.type) !== "trigger" && (e == null ? void 0 : e.type) !== "lastActiveTimeBadge" && (e == null ? void 0 : e.backgroundColor) !== "none" && h.jsx("circle", babelHelpers["extends"]({
                                cx: (l = K.left) != null ? l : x - ((l = K.right) != null ? l : 0),
                                cy: (l = K.top) != null ? l : x - ((l = K.bottom) != null ? l : 0)
                            }, c("CometVisualCompletionAttributes").IGNORE, {
                                fill: "black",
                                r: Math.max((e == null ? void 0 : e.type) === "activityBadge" ? 8 : 0, H / 2 + G)
                            }))
                        }), I != null && f != null && f.type === "notificationBadge" && h.jsx("rect", {
                            height: 22,
                            rx: 11,
                            ry: 11,
                            width: f.number <= 9 ? 22 : f.number <= 99 ? 33 : 44,
                            x: F.left != null ? F.left - (f.number <= 9 ? 11 : f.number <= 99 ? 22 : 33) : x - ((K = F.right) != null ? K : 0) - 11,
                            y: F.top != null ? F.top - 11 : x - ((l = F.bottom) != null ? l : 0) - 11
                        }), z === "uploading" && (x === 36 || x === 60) ? h.jsx("circle", {
                            cx: x / 2,
                            cy: x / 2,
                            fill: "transparent",
                            r: x / 2 - 1 * u,
                            stroke: "black",
                            strokeWidth: u * 2
                        }) : z !== "none" && u > 0 && h.jsx("circle", {
                            cx: x / 2,
                            cy: x / 2,
                            fill: "transparent",
                            r: x / 2 - 1.5 * u,
                            stroke: "black",
                            strokeWidth: u
                        }), n && h.jsx("circle", {
                            cx: -x / 2 + 4,
                            cy: x / 2,
                            fill: "black",
                            r: x / 2 + 2
                        })]
                    }), h.jsxs("g", {
                        mask: D,
                        ref: E,
                        suppressHydrationWarning: !0,
                        children: [t != null ? h.jsx(c("CometErrorBoundary.react"), {
                            fallback: function() {
                                return L
                            },
                            children: h.jsx(c("CometPlaceholder.react"), {
                                fallback: L,
                                children: h.jsx(c("CometSSRSuspendOnServer.react"), {
                                    children: h.jsx("foreignObject", {
                                        height: "100%",
                                        width: "100%",
                                        x: 2 * u,
                                        y: 2 * u,
                                        children: h.jsx("div", {
                                            className: c("stylex")(i.videoContainer, v === "roundedRect" && i.videoContainerRectRounded, v === "circle" && i.videoContainerRounded),
                                            style: {
                                                height: x - u * 4,
                                                width: x - u * 4
                                            },
                                            children: h.jsx(c("LazyCometProfileVideoSection.react"), babelHelpers["extends"]({
                                                linkProps: o,
                                                onHoverIn: p,
                                                onHoverOut: q,
                                                onPress: r,
                                                onPressIn: s,
                                                profileVideo: t,
                                                size: x - u * 4,
                                                thumbnailUri: y.uri
                                            }, A))
                                        })
                                    })
                                })
                            })
                        }) : L, v === "circle" ? h.jsx("circle", {
                            className: c("stylex")(i.insetSVG, a && i.svgOverlay),
                            cx: x / 2,
                            cy: x / 2,
                            r: x / 2
                        }) : h.jsx("rect", {
                            className: c("stylex")(i.insetSVG, a && i.svgOverlay),
                            cy: x / 2,
                            fill: "white",
                            height: x,
                            rx: v === "square" ? 0 : 8,
                            ry: v === "square" ? 0 : 8,
                            width: x,
                            x: 0,
                            y: 0
                        }), z === "uploading" && (x === 36 || x === 60) ? null : z !== "none" && u > 0 && h.jsx("circle", {
                            className: c("stylex")(z === "unseen" && (w ? i.storyRingGreen : i.storyRingBlue), z === "seen" && i.storyRingGray, z === "live" && i.storyRingRed, u === 4 && i.storyRingSize4, u === 3 && i.storyRingSize3, u === 2 && i.storyRingSize2),
                            cx: x / 2,
                            cy: x / 2,
                            fill: "transparent",
                            r: x / 2 - u / 2,
                            stroke: "var(--accent)",
                            strokeWidth: u
                        })]
                    }), z === "uploading" && (x === 36 || x === 60) && h.jsx("g", {
                        style: {
                            transform: "scale(" + (x - Math.floor(x / 30)) / x + ")"
                        },
                        children: h.jsx(c("CometLoadingAnimation.react"), {
                            size: x
                        })
                    })]
                })) : L;
                return h.jsxs("div", {
                    className: c("stylex")(i.wrapper),
                    ref: b,
                    children: [H, k, m, h.jsx(c("CometSSRReplaceContentOnHydrationAndBreakEventReplaying.react"), {
                        children: J
                    }), I]
                })
            };
        return !r && !o && u !== !0 ? F({
            pressed: !1
        }, b) : h.jsx(c("CometTrackingNodeProvider.react"), {
            trackingNode: 3,
            children: h.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, A, {
                cursorDisabled: l,
                linkProps: o,
                onHoverIn: p,
                onHoverOut: q,
                onPress: r,
                onPressIn: s,
                overlayDisabled: m,
                overlayRadius: v === "circle" ? "50%" : v === "roundedRect" ? 8 : 0,
                ref: b,
                testOnly_pressed: u,
                testid: void 0,
                xstyle: function(a) {
                    a = a.pressed;
                    return [i.pressable, a && i.pressed]
                },
                children: function(a) {
                    var b = a.overlay;
                    a = a.pressed;
                    return F({
                        overlay: b,
                        pressed: a
                    }, null)
                }
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function j(a) {
        var b = a.addOn,
            e = a.pressed;
        a = a.size;
        switch (b.type) {
            case "availabilityBadge":
                a = d("profilePhotoUtils").getBadgeSizeAndStrokeWidth(a, b == null ? void 0 : b.type);
                a = a[0];
                return h.jsx(c("CometProfilePhotoAvailabilityBadge.react"), {
                    pressed: e,
                    size: a
                });
            case "lastActiveTimeBadge":
                return h.jsx(c("CometProfilePhotoLastActiveTimeBadge.react"), {
                    border: b.border,
                    pressed: e,
                    time: b.time
                });
            case "activityBadge":
                return h.jsx(k, {
                    backgroundColor: b.backgroundColor,
                    icon: b.icon,
                    overflow: b.overflow,
                    pressed: e,
                    size: b.size
                });
            case "trigger":
                return b.icon;
            case "multipleVoicesForAction":
                return b.badge;
            default:
                return null
        }
    }
    j.displayName = j.name + " [from " + f.id + "]";

    function k(a) {
        var b = a.backgroundColor;
        b = b === void 0 ? "white" : b;
        var d = a.icon,
            e = a.overflow,
            f = a.pressed;
        a = a.size;
        return h.jsx(c("CometPressableChildrenWithOverlay.react"), {
            overlay: h.jsx(c("CometPressableOverlay.react"), {
                offset: 0,
                pressed: f,
                radius: "50%"
            }),
            children: h.jsx("div", {
                className: c("stylex")(i.activityBadge, a === 8 && i.activityIcon8, a === 10 && i.activityIcon10, a === 16 && i.activityIcon16),
                style: {
                    backgroundColor: b,
                    overflow: e
                },
                children: d
            })
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometPulseEffectBase.react", ["react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            positive: "var(--positive)",
            primary: "var(--primary-button-background)"
        },
        j = 12,
        k = {
            animation: {
                animationDuration: "x7t6ubo",
                animationIterationCount: "xa4qsjk",
                animationTimingFunction: "x1esw782"
            },
            animationDelay: {
                animationDelay: "x1ru42tm"
            },
            childrenContainer: {
                position: "x1n2onr6"
            },
            pulse: {
                alignItems: "x6s0dn4",
                display: "x3nfvp2",
                height: "xo6n4f7",
                justifyContent: "xl56j7k",
                pointerEvents: "x47corl",
                width: "x1ddb473"
            },
            pulseAnimater: {
                animationName: "xw8473l"
            },
            pulseBorder: {
                borderTop: "xdbi22c",
                borderEnd: "x13suj6t",
                borderBottom: "xygn9w",
                borderStart: "x1ua21w8"
            },
            pulseBoxShadow: {
                boxShadow: "x1wr1374"
            },
            pulseContainer: {
                alignItems: "x6s0dn4",
                animationName: "xz4wc60",
                display: "x3nfvp2",
                end: "xds687c",
                height: "xo6n4f7",
                justifyContent: "xl56j7k",
                opacity: "xg01cxk",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                top: "x13vifvy",
                width: "x1ddb473"
            },
            root: {
                display: "x1rg5ohu",
                position: "x1n2onr6"
            }
        };

    function a(a) {
        var b = a.children,
            d = a.disabled;
        d = d === void 0 ? !1 : d;
        var e = a.height,
            f = a.pulseColor;
        f = f === void 0 ? "primary" : f;
        var g = a.radii,
            i = a.visible;
        i = i === void 0 ? !0 : i;
        var j = a.width;
        a = a.xstyle;
        f = m(j, e, f);
        return h.jsxs("div", {
            className: c("stylex")(k.root, a),
            style: f,
            children: [h.jsx("div", {
                className: c("stylex")(k.childrenContainer),
                children: b
            }), i === !1 || d === !0 || f == null ? null : h.jsxs(h.Fragment, {
                children: [h.jsx(l, {
                    radii: g
                }), h.jsx(l, {
                    delay: !0,
                    radii: g
                })]
            }, ((a = j) != null ? a : "") + "_" + ((b = e) != null ? b : "") + "_" + (g == null ? "" : Object.keys(g).toString()))]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";

    function l(a) {
        var b = a.delay;
        b = b === void 0 ? !1 : b;
        a = a.radii;
        return h.jsx("div", {
            className: c("stylex")(k.animation, b && k.animationDelay, k.pulseContainer),
            style: a,
            children: h.jsx("div", {
                className: c("stylex")(k.animation, b && k.animationDelay, k.pulse, k.pulseAnimater, k.pulseBorder),
                style: a,
                children: h.jsx("div", {
                    className: c("stylex")(k.pulse, k.pulseBoxShadow),
                    style: a
                })
            })
        })
    }
    l.displayName = l.name + " [from " + f.id + "]";

    function m(a, b, c) {
        if (a == null || b == null) return null;
        var d = a + 2 * j,
            e = b + 2 * j;
        return {
            "--CometPulseEffect_containerScaleXFactor": "calc(" + d + " / " + a + ")",
            "--CometPulseEffect_containerScaleXFactorAt50": "calc((1 + var(--CometPulseEffect_containerScaleXFactor)) * 0.5)",
            "--CometPulseEffect_containerScaleYFactor": "calc(" + e + " / " + b + ")",
            "--CometPulseEffect_containerScaleYFactorAt50": "calc((1 + var(--CometPulseEffect_containerScaleYFactor)) * 0.5)",
            "--CometPulseEffect_height": b + "px",
            "--CometPulseEffect_pulseColor": i[c],
            "--CometPulseEffect_width": a + "px"
        }
    }
    g["default"] = a
}), 98);
__d("BaseRowContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        columns: 1,
        wrap: "none"
    });
    g["default"] = b
}), 98);
__d("BaseRow.react", ["BaseRowContext", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo,
        j = {
            expanding: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minWidth: "xeuugli"
            },
            row: {
                display: "x78zum5",
                flexShrink: "x2lah0s"
            }
        },
        k = {
            center: {
                justifyContent: "xl56j7k"
            },
            end: {
                justifyContent: "x13a6bvl"
            },
            justify: {
                justifyContent: "x1qughib"
            },
            start: {
                justifyContent: "x1nhvcw1"
            }
        },
        l = {
            bottom: {
                alignItems: "xuk3077"
            },
            center: {
                alignItems: "x6s0dn4"
            },
            stretch: {
                alignItems: "x1qjc9v5"
            },
            top: {
                alignItems: "x1cy8zhl"
            }
        },
        m = {
            backward: {
                flexDirection: "x15zctf7"
            },
            forward: {
                flexDirection: "x1q0g3np"
            }
        },
        n = {
            backward: {
                flexWrap: "x8hhl5t"
            },
            forward: {
                flexWrap: "x1a02dak"
            },
            none: {
                flexWrap: "xozqiw3"
            }
        },
        o = {
            end: "start",
            start: "end"
        };

    function a(a, b) {
        var d = a.align;
        d = d === void 0 ? "justify" : d;
        var e = a.children,
            f = a.columns,
            g = f === void 0 ? 0 : f;
        f = a.direction;
        f = f === void 0 ? "forward" : f;
        var p = a.expanding;
        p = p === void 0 ? !1 : p;
        var q = a.verticalAlign;
        q = q === void 0 ? "stretch" : q;
        var r = a.wrap,
            s = r === void 0 ? "none" : r;
        r = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["align", "children", "columns", "direction", "expanding", "verticalAlign", "wrap", "xstyle"]);
        var t = i(function() {
            return {
                columns: g,
                wrap: s
            }
        }, [g, s]);
        return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            ref: b,
            xstyle: [j.row, p && j.expanding, k[f === "backward" && (d === "start" || d === "end") ? o[d] : d], l[q], n[s], m[f], r],
            children: h.jsx(c("BaseRowContext").Provider, {
                value: t,
                children: e
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometRowContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("BaseRowItem.react", ["BaseRowContext", "BaseView.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            expanding: {
                flexBasis: "x1r8uery",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k"
            },
            expandingWithWrap: {
                flexBasis: "x1l7klhg"
            },
            item: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexShrink: "x2lah0s",
                maxWidth: "x193iq5w",
                minWidth: "xeuugli"
            },
            item_DEPRECATED: {
                maxWidth: "x193iq5w",
                minWidth: "xeuugli"
            }
        },
        k = {
            1: {
                flexBasis: "x1l7klhg"
            },
            2: {
                flexBasis: "x4pfjvb"
            },
            3: {
                flexBasis: "x1upgvki"
            },
            4: {
                flexBasis: "xhnlq4v"
            },
            5: {
                flexBasis: "x15foiic"
            },
            6: {
                flexBasis: "xd8mu38"
            },
            7: {
                flexBasis: "xjtu8lc"
            },
            8: {
                flexBasis: "xvuwby9"
            },
            9: {
                flexBasis: "x1m2iiog"
            },
            10: {
                flexBasis: "x3cfelu"
            }
        },
        l = {
            bottom: {
                alignSelf: "xpvyfi4"
            },
            center: {
                alignSelf: "xamitd3"
            },
            stretch: {
                alignSelf: "xkh2ocl"
            },
            top: {
                alignSelf: "xqcrz7y"
            }
        };

    function a(a, b) {
        var d = a.expanding;
        d = d === void 0 ? !1 : d;
        var e = a.useDeprecatedStyles;
        e = e === void 0 ? !1 : e;
        var f = a.verticalAlign,
            g = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["expanding", "useDeprecatedStyles", "verticalAlign", "xstyle"]);
        var m = i(c("BaseRowContext")),
            n = m.columns;
        m = m.wrap;
        return h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, a, {
            ref: b,
            xstyle: [e ? j.item_DEPRECATED : j.item, d && j.expanding, d && m !== "none" && j.expandingWithWrap, n > 0 && k[n], f != null && l[f], g]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometRowItem.react", ["BaseRowItem.react", "CometErrorBoundary.react", "CometPlaceholder.react", "CometRowContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext,
        j = {
            4: {
                paddingEnd: "xg83lxy",
                paddingStart: "x1h0ha7o"
            },
            8: {
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4"
            },
            12: {
                paddingEnd: "xsyo7zv",
                paddingStart: "x16hj40l"
            },
            16: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha"
            },
            24: {
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou"
            },
            32: {
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13"
            }
        },
        k = {
            4: {
                paddingBottom: "x1120s5i",
                paddingTop: "x1nn3v0j"
            },
            8: {
                paddingBottom: "xjkvuk6",
                paddingTop: "x1iorvi4"
            },
            12: {
                paddingBottom: "x10b6aqq",
                paddingTop: "x1yrsyyn"
            },
            16: {
                paddingBottom: "xwib8y2",
                paddingTop: "x1y1aw1k"
            },
            24: {
                paddingBottom: "xsag5q8",
                paddingTop: "xz9dl7a"
            },
            32: {
                paddingBottom: "x1l90r2v",
                paddingTop: "xyamay9"
            }
        };

    function a(a, b) {
        var d;
        d = (d = i(c("CometRowContext"))) != null ? d : {};
        var e = d.spacingHorizontal;
        d = d.spacingVertical;
        var f = a.fallback,
            g = a.placeholder,
            m = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback", "placeholder"]);
        if (g !== void 0) {
            a.placeholder;
            var n = babelHelpers.objectWithoutPropertiesLoose(a, ["placeholder"]);
            return h.jsx(c("CometPlaceholder.react"), {
                fallback: g != null ? h.jsx(l, babelHelpers["extends"]({}, n, {
                    ref: b,
                    children: g
                })) : null,
                children: h.jsx(l, babelHelpers["extends"]({}, n, {
                    ref: b
                }))
            })
        }
        if (f !== void 0) {
            a.fallback;
            var o = babelHelpers.objectWithoutPropertiesLoose(a, ["fallback"]);
            return f === null ? h.jsx(c("CometErrorBoundary.react"), {
                children: h.jsx(l, babelHelpers["extends"]({}, o, {
                    ref: b
                }))
            }) : h.jsx(c("CometErrorBoundary.react"), {
                fallback: function(a, c) {
                    return h.jsx(l, babelHelpers["extends"]({}, o, {
                        ref: b,
                        children: typeof f === "function" ? f(a, c) : f
                    }))
                },
                children: h.jsx(l, babelHelpers["extends"]({}, o, {
                    ref: b
                }))
            })
        }
        return h.jsx(c("BaseRowItem.react"), babelHelpers["extends"]({}, m, {
            ref: b,
            useDeprecatedStyles: m.useDeprecatedStyles,
            xstyle: [j[e], k[d], m.xstyle],
            children: h.jsx(c("CometRowContext").Provider, {
                value: null,
                children: m.children
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var l = h.forwardRef(a);
    b = l;
    g["default"] = b
}), 98);
__d("CometRow.react", ["BaseRow.react", "CometColumnContext", "CometColumnItem.react", "CometRowContext", "CometRowItem.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            4: {
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4"
            },
            8: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha"
            },
            12: {
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou"
            },
            16: {
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13"
            }
        },
        l = {
            0: {
                paddingTop: "xexx8yu"
            },
            4: {
                paddingTop: "x1iorvi4"
            },
            8: {
                paddingTop: "x1y1aw1k"
            },
            12: {
                paddingTop: "xz9dl7a"
            },
            16: {
                paddingTop: "xyamay9"
            }
        },
        m = {
            4: {
                paddingBottom: "xjkvuk6",
                paddingTop: "x1iorvi4"
            },
            8: {
                paddingBottom: "xwib8y2",
                paddingTop: "x1y1aw1k"
            },
            12: {
                paddingBottom: "xsag5q8",
                paddingTop: "xz9dl7a"
            },
            16: {
                paddingBottom: "x1l90r2v",
                paddingTop: "xyamay9"
            }
        },
        n = {
            4: {
                marginEnd: "xwrv7xz",
                marginStart: "x8182xy"
            },
            8: {
                marginEnd: "xcud41i",
                marginStart: "x139jcc6"
            },
            12: {
                marginEnd: "xykv574",
                marginStart: "xbmpl8g"
            },
            16: {
                marginEnd: "x1n0m28w",
                marginStart: "xp7jhwk"
            },
            24: {
                marginEnd: "x12rz0ws",
                marginStart: "x16hk5td"
            },
            32: {
                marginEnd: "x19f6ikt",
                marginStart: "x169t7cy"
            }
        },
        o = {
            4: {
                marginBottom: "xmgb6t1",
                marginTop: "x1kgmq87"
            },
            8: {
                marginBottom: "x4vbgl9",
                marginTop: "x1rdy4ex"
            },
            12: {
                marginBottom: "x4cne27",
                marginTop: "xifccgj"
            },
            16: {
                marginBottom: "x1wsgfga",
                marginTop: "x9otpla"
            },
            24: {
                marginBottom: "xh3wvx0",
                marginTop: "x7wgvq7"
            },
            32: {
                marginBottom: "x1oo3vh0",
                marginTop: "xwya9rg"
            }
        };

    function a(a, b) {
        var d = i(c("CometColumnContext")),
            e = i(c("CometRowContext")),
            f = (d == null ? void 0 : d.paddingHorizontal) != null ? 0 : 12,
            g = (d == null ? void 0 : d.spacing) != null ? 0 : 16,
            p = a.children,
            q = a.paddingHorizontal;
        f = q === void 0 ? f : q;
        q = a.paddingVertical;
        q = q === void 0 ? 0 : q;
        var r = a.paddingTop;
        g = r === void 0 ? a.paddingVertical == null ? g : null : r;
        r = a.spacing;
        r = r === void 0 ? 12 : r;
        var s = a.spacingHorizontal,
            t = s === void 0 ? r : s;
        s = a.spacingVertical;
        var u = s === void 0 ? r : s;
        r = a.xstyle;
        s = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "paddingHorizontal", "paddingVertical", "paddingTop", "spacing", "spacingHorizontal", "spacingVertical", "xstyle"]);
        a = j(function() {
            return {
                spacingHorizontal: t,
                spacingVertical: u
            }
        }, [t, u]);
        b = h.jsx(c("BaseRow.react"), babelHelpers["extends"]({}, s, {
            ref: b,
            xstyle: [k[f], m[q], g != null && l[g], n[t], o[u], r],
            children: h.jsx(c("CometRowContext").Provider, {
                value: a,
                children: p
            })
        }));
        if (e != null) return h.jsx(c("CometRowItem.react"), {
            expanding: s.expanding,
            children: b
        });
        return d != null ? h.jsx(c("CometColumnItem.react"), {
            expanding: s.expanding,
            children: b
        }) : b
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    d = e;
    g["default"] = d
}), 98);
__d("CometSkittleIcon.react", ["CometIcon.react", "profilePhotoUtils", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            circle: {
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu"
            },
            iconBadge: {
                alignItems: "x6s0dn4",
                backgroundColor: "xwnonoy",
                borderTopColor: "x6zyg47",
                borderEndColor: "x1xm1mqw",
                borderBottomColor: "xpn8fn3",
                borderStartColor: "xtct9fg",
                borderTopStartRadius: "x14yjl9h",
                borderTopEndRadius: "xudhj91",
                borderBottomEndRadius: "x18nykt9",
                borderBottomStartRadius: "xww2gxu",
                borderTopStyle: "x13fuv20",
                borderEndStyle: "xu3j5b3",
                borderBottomStyle: "x1q0q8m5",
                borderStartStyle: "x26u7qi",
                borderTopWidth: "xamhcws",
                borderEndWidth: "xol2nv",
                borderBottomWidth: "xlxy82",
                borderStartWidth: "x19p7ews",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                paddingTop: "x1nn3v0j",
                paddingEnd: "xg83lxy",
                paddingBottom: "x1120s5i",
                paddingStart: "x1h0ha7o",
                position: "x10l6tqk"
            },
            roundedRect: {
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c"
            },
            skittle: {
                alignItems: "x6s0dn4",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                display: "x3nfvp2",
                justifyContent: "xl56j7k",
                position: "x1n2onr6"
            }
        },
        j = {
            accent: {
                backgroundColor: "xwnonoy"
            },
            blue: {
                backgroundColor: "x11goek"
            },
            cherry: {
                backgroundColor: "x1tzrqqp"
            },
            grape: {
                backgroundColor: "x17f3y5z"
            },
            gray: {
                backgroundColor: "x1qhmfi1"
            },
            green: {
                backgroundColor: "xv9rvxn"
            },
            lemon: {
                backgroundColor: "xacajkf"
            },
            lightblue: {
                backgroundColor: "x1hr4nm9"
            },
            lime: {
                backgroundColor: "xbmc1ew"
            },
            pink: {
                backgroundColor: "x1qrsksh"
            },
            red: {
                backgroundColor: "x1ciooss"
            },
            seafoam: {
                backgroundColor: "x1tw9p8u"
            },
            teal: {
                backgroundColor: "x1emf0wh"
            },
            tomato: {
                backgroundColor: "xqjkjv5"
            },
            white: {
                backgroundColor: "x14hiurz"
            }
        },
        k = {
            32: {
                height: "x10w6t97",
                width: "x1td3qas"
            },
            36: {
                height: "xc9qbxq",
                width: "x14qfxbe"
            },
            40: {
                height: "x1vqgdyp",
                width: "x100vrsf"
            },
            48: {
                height: "xsdox4t",
                width: "x1useyqa"
            },
            56: {
                height: "xnnlda6",
                width: "x15yg21f"
            },
            60: {
                height: "xng8ra",
                width: "x1247r65"
            }
        },
        l = (b = {}, b[24] = 16, b[36] = 20, b[40] = 24, b[48] = 24, b[56] = 24, b[60] = 24, b);

    function m(a) {
        switch (a) {
            case "gray":
                return "primary";
            case "white":
                return "primary";
            case "lightblue":
                return "highlight";
            default:
                return "white"
        }
    }

    function a(a, b) {
        var e = a.color,
            f = a.disabled;
        f = f === void 0 ? !1 : f;
        var g = a.icon,
            n = a.iconAria,
            o = a.iconBadge,
            p = a.iconBadgeAria,
            q = a.shape;
        q = q === void 0 ? "circle" : q;
        a = a.size;
        return h.jsxs("div", {
            className: c("stylex")(q === "circle" && i.circle, q === "roundedRect" && i.roundedRect, i.skittle, j[e], k[a]),
            ref: b,
            children: [h.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, n, {
                color: f ? "disabled" : m(e),
                icon: g,
                size: l[a]
            })), o && h.jsx("div", {
                className: c("stylex")(i.iconBadge),
                style: d("profilePhotoUtils").getBadgePosition(a / 2),
                children: h.jsx(c("CometIcon.react"), babelHelpers["extends"]({}, p, {
                    color: "white",
                    icon: o,
                    size: 8
                }))
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometHeadlineWithAddOn.react", ["BaseRow.react", "BaseRowItem.react", "Locale", "TetraText.react", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            addOn: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                justifyContent: "xl56j7k",
                marginStart: "x1i64zmx"
            },
            nonBreakingSpace: {
                visibility: "xlshs6z",
                width: "xnalus7"
            },
            textFlexFixForIE: {
                flexBasis: "xdl72j9"
            }
        },
        j = {
            ltr: {
                direction: "xzt5al7"
            },
            rtl: {
                direction: "xzyj77d"
            }
        },
        k = c("gkx")("1299319");

    function a(a, b) {
        var e = a.addOn,
            f = a.children,
            g = a.color,
            l = a.headlineRef,
            m = a.isPrimaryHeading,
            n = a.isSemanticHeading,
            o = a.numberOfLines;
        a = a.type;
        return h.jsx(c("TetraText.react"), {
            isSemanticHeading: !1,
            ref: b,
            type: a,
            children: h.jsxs(c("BaseRow.react"), {
                verticalAlign: "center",
                xstyle: j[d("Locale").isRTL() ? "rtl" : "ltr"],
                children: [h.jsx(c("BaseRowItem.react"), {
                    expanding: !0,
                    xstyle: k && i.textFlexFixForIE,
                    children: h.jsx(c("TetraText.react"), {
                        color: g,
                        isPrimaryHeading: m,
                        isSemanticHeading: n,
                        numberOfLines: o,
                        ref: l,
                        type: a,
                        children: f
                    })
                }), h.jsx(c("BaseRowItem.react"), {
                    verticalAlign: "top",
                    xstyle: i.addOn,
                    children: h.jsxs(c("BaseRow.react"), {
                        verticalAlign: "center",
                        children: [h.jsx(c("BaseRowItem.react"), {
                            xstyle: i.nonBreakingSpace,
                            children: "\xa0"
                        }), h.jsx(c("BaseRowItem.react"), {
                            children: h.jsx(c("BaseRow.react"), {
                                children: e
                            })
                        })]
                    })
                })]
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("getItemRoleFromCompositeRole", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        switch (a) {
            case "grid":
                return "row";
            case "listbox":
                return "option";
            case "list":
                return "listitem";
            case "radiogroup":
                return "radio";
            case "row":
                return "gridcell";
            case "tablist":
                return "tab"
        }
        return null
    }
    f["default"] = a
}), 66);
__d("BaseDialog.react", ["BaseThemeProvider.react", "BaseView.react", "CometHideLayerOnEscape.react", "pointerEventDistance", "react", "stylex", "useMergeRefs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useEffect,
        j = b.useRef,
        k = {
            anchor: {
                alignItems: "x1cy8zhl",
                boxSizing: "x9f619",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                minHeight: "x2lwn1j",
                minWidth: "xeuugli",
                pointerEvents: "x47corl"
            },
            dialog: {
                boxSizing: "x1afcbsf",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                outline: "x1a2a7pz",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                pointerEvents: "x71s49j"
            },
            root: {
                alignItems: "x1qjc9v5",
                boxSizing: "x9f619",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                justifyContent: "xl56j7k"
            },
            rootWithDeprecatedStyles: {
                flexGrow: "x1c4vz4f",
                minHeight: "xg6iff7"
            }
        };

    function a(a, b) {
        var e = a.anchorXStyle,
            f = a.children,
            g = a.disableClosingWithMask,
            l = g === void 0 ? !1 : g,
            m = a.onClose,
            n = a.rootXStyle;
        g = a.testid;
        g = a.themeConfig;
        var o = a.withDeprecatedStyles,
            p = o === void 0 ? !1 : o,
            q = a.xstyle,
            r = babelHelpers.objectWithoutPropertiesLoose(a, ["anchorXStyle", "children", "disableClosingWithMask", "onClose", "rootXStyle", "testid", "themeConfig", "withDeprecatedStyles", "xstyle"]),
            s = j(null),
            t = j(null),
            u = j(null);
        i(function() {
            var a = s.current,
                b = t.current;
            if (a == null || b == null || l) return;

            function c(c) {
                return c instanceof Node && !b.contains(c) && a.contains(c)
            }
            var e = "PointerEvent" in window;
            if (!e) {
                var f = function(a) {
                    c(a.target) && m()
                };
                a.addEventListener("click", f);
                return function() {
                    a.removeEventListener("click", f)
                }
            }
            var g = !1;

            function h(a) {
                if (a.isPrimary) {
                    var b = c(a.target);
                    g = b;
                    u.current = a
                }
            }

            function i(a) {
                var b = c(a.target);
                if (g && b && u.current != null && a.isPrimary) {
                    b = d("pointerEventDistance").isWithinThreshold(u.current, a);
                    b && m()
                }
                g = !1;
                u.current = null
            }
            a.addEventListener("pointerup", i);
            a.addEventListener("pointerdown", h);
            return function() {
                a.removeEventListener("pointerup", i), a.removeEventListener("pointerdown", h)
            }
        }, [l, m]);
        var v = c("useMergeRefs")(t, b);
        return h.jsx(c("CometHideLayerOnEscape.react"), {
            onHide: m,
            children: h.jsx(c("BaseThemeProvider.react"), {
                config: g,
                children: function(a, b) {
                    return h.jsx("div", {
                        className: c("stylex")([a, k.root, p && k.rootWithDeprecatedStyles, n]),
                        ref: s,
                        style: b,
                        children: h.jsx("div", {
                            className: c("stylex")(k.anchor, e),
                            children: h.jsx(c("BaseView.react"), babelHelpers["extends"]({}, r, {
                                ref: v,
                                role: "dialog",
                                testid: void 0,
                                xstyle: [k.dialog, q],
                                children: f
                            }))
                        })
                    })
                }
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("BaseHeadingContextWrapper.react", ["BaseHeadingContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useContext;

    function a(a) {
        a = a.children;
        var b = i(c("BaseHeadingContext"));
        return h.jsx(c("BaseHeadingContext").Provider, {
            value: b + 1,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("BaseInput.react", ["CometContainerPressableContext", "Locale", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            root: {
                WebkitTapHighlightColor: "x1i10hfl",
                boxSizing: "x9f619",
                touchAction: "xggy1nq",
                ":disabled": {
                    cursor: "x1s07b3s"
                }
            },
            zIndex: {
                zIndex: "x1vjfegm"
            }
        },
        l = d("Locale").isRTL();

    function a(a, b) {
        var d = a.onChange,
            e = a.onClick,
            f = a.onValueChange,
            g = a.testid,
            m = a.type,
            n = m === void 0 ? "text" : m;
        m = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["onChange", "onClick", "onValueChange", "testid", "type", "xstyle"]);
        var o = j(function() {
                switch (n) {
                    case "switch":
                        return "checkbox";
                    default:
                        return n
                }
            }, [n]),
            p = o === "checkbox" || o === "radio",
            q = o === "textarea",
            r = i(c("CometContainerPressableContext")) != null;
        a = babelHelpers["extends"]({
            dir: l ? "rtl" : "ltr"
        }, a, c("testID")(g), {
            className: c("stylex")(k.root, m, r && k.zIndex),
            onChange: function(a) {
                p || f && f(a.target.value, a), d && d(a)
            },
            onClick: function(a) {
                p && (f && f(a.target.checked, a)), e && e(a)
            }
        });
        return q ? h.jsx("textarea", babelHelpers["extends"]({
            suppressHydrationWarning: !0
        }, a, {
            ref: b
        })) : h.jsx("input", babelHelpers["extends"]({
            suppressHydrationWarning: !0
        }, a, {
            ref: b,
            type: o
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.memo(h.forwardRef(a));
    g["default"] = e
}), 98);
__d("BaseModal.react", ["cr:1824473", "cr:994756", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    a = b("cr:1824473") != null ? b("cr:1824473") : b("cr:994756");
    g["default"] = a
}), 98);
__d("BaseMultiPageViewContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("FocusInertRegion.react", ["react", "setElementCanTab", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    var h = d("react"),
        i = d("react").useRef,
        j = h.unstable_Scope;

    function a(a) {
        var b = a.children,
            e = a.disabled,
            f = e === void 0 ? !1 : e,
            g = a.focusQuery,
            k = i(null);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            var a = k.current;
            if (g && a != null) {
                a = a.DO_NOT_USE_queryAllNodes(g);
                if (a !== null)
                    for (var b = 0; b < a.length; b++) {
                        var c = a[b];
                        d("setElementCanTab").setElementCanTab(c, f)
                    }
            }
        }, [f, g]);
        return h.jsx(j, {
            ref: k,
            children: b
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("getPrefersReducedMotion", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = null;

    function h(a) {
        g = a.matches
    }

    function a() {
        if (g == null)
            if (typeof window.matchMedia === "function") {
                var a = matchMedia("(prefers-reduced-motion: reduce)");
                g = a.matches;
                a.addListener(h)
            } else g = !1;
        return g
    }
    f["default"] = a
}), 66);
__d("BaseMultiPageViewContainer.react", ["BaseMultiPageViewContext", "FocusInertRegion.react", "FocusRegion.react", "HiddenSubtreeContextProvider.react", "Locale", "emptyFunction", "focusScopeQueries", "getPrefersReducedMotion", "gkx", "mergeRefs", "react", "stylex", "testID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useImperativeHandle,
        l = b.useMemo,
        m = b.useRef,
        n = {
            page: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                transformOrigin: "x1al4vs7",
                willChange: "x6my1t9"
            },
            pageInactive: {
                display: "x1s85apg",
                left: "xu96u03",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                top: "x13vifvy",
                zIndex: "x1vjfegm"
            },
            root: {
                alignItems: "x1qjc9v5",
                clipPath: "x3vj7og",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                position: "x1n2onr6",
                transformOrigin: "x1al4vs7",
                willChange: "x1so62im"
            }
        },
        o = d("Locale").isRTL(),
        p = 300,
        q = c("getPrefersReducedMotion")() || !c("gkx")("1485");

    function r(a) {
        return Math.cos((a + 1) * Math.PI) / 2 + .5
    }

    function a(a, b) {
        var e = a.children,
            f = a.disableAutoFocus,
            g = f === void 0 ? !1 : f;
        f = a.disableAutoRestoreFocus;
        var s = f === void 0 ? !1 : f;
        f = a.disableFocusContainment;
        var t = f === void 0 ? !1 : f;
        f = a.disableInitialAutoFocus;
        f = f === void 0 ? !1 : f;
        var u = a.fallback,
            v = a.imperativeRef,
            w = a.onPageChange,
            x = w === void 0 ? c("emptyFunction") : w,
            y = a.onAddPage,
            z = a.onPopPage,
            A = a.onClearRemovedPages,
            B = a.pageXStyle,
            C = a.pageHistory,
            D = a.placeholderComponent;
        w = a.xstyle;
        var E = m(null),
            F = m(null),
            G = m(null),
            H = m(!1),
            I = f && !H.current,
            J = i(function() {
                var a = E.current,
                    b = F.current;
                b != null ? G.current = b.getBoundingClientRect() : a != null && (G.current = a.getBoundingClientRect())
            }, []),
            K = i(function(a, b) {
                J(), H.current = !0, y(a, b)
            }, [y, J]),
            L = i(function(a) {
                J(), z(a)
            }, [z, J]),
            M = i(function(a) {
                return K("end", a)
            }, [K]),
            N = l(function() {
                for (var a = C.length - 1; a >= 0; a--) {
                    var b = C[a];
                    if (b.type !== "pushed_page" || !b.removed) return a
                }
                return 0
            }, [C]),
            O = m(N);
        j(function() {
            N !== O.current && (x && x(N)), O.current = N
        }, [x, N]);
        var P = i(function(a) {
            var b = F.current,
                c = E.current;
            if (a != null) {
                var d = C[N];
                d = d.type === "pushed_page" ? d.direction : "end";
                O.current > N && (d = d === "start" ? "end" : "start");
                var e = G.current,
                    f = a.getBoundingClientRect();
                if (!q && b != null && b !== a && e != null && c != null) {
                    d = (d === "start" ? -1 : 1) * (o ? -1 : 1);
                    b.style.cssText = "";
                    a.style.cssText = "";
                    b.style.setProperty("display", "flex");
                    b.style.setProperty("width", e.width + "px");
                    b.style.setProperty("height", e.height + "px");
                    a.style.removeProperty("display");
                    a.style.removeProperty("width");
                    a.style.removeProperty("height");
                    var g = Math.round(60 * (p / 1e3)),
                        h = [],
                        i = [],
                        j = [];
                    for (var k = 0; k <= g; k++) {
                        var l = k / g,
                            m = r(l),
                            n = e.width / f.width,
                            s = e.height / f.height;
                        n = n + (1 - n) * m;
                        s = s + (1 - s) * m;
                        var t = e.left - f.left,
                            u = e.top - f.top;
                        t = t * (1 - m);
                        var v = u * (1 - m),
                            w = Math.min(e.width, f.width),
                            x = w * -d * m;
                        w = w * d * (1 - m);
                        m = u - v;
                        u = -v;
                        h.push({
                            easing: "step-end",
                            offset: l,
                            transform: "translateX(" + t + "px) translateY(" + v + "px) scaleX(" + n + ") scaleY(" + s + ")"
                        });
                        i.push({
                            easing: "step-end",
                            offset: l,
                            transform: "scaleX(" + 1 / n + ") scaleY(" + 1 / s + ") translateX(" + x + "px) translateY(" + m + "px)"
                        });
                        j.push({
                            easing: "step-end",
                            offset: l,
                            transform: "scaleX(" + 1 / n + ") scaleY(" + 1 / s + ") translateX(" + w + "px) translateY(" + u + "px)"
                        })
                    }
                    a.animate(j, p);
                    c.animate(h, p);
                    b.animate(i, p);
                    a.animate([{
                        opacity: 0
                    }, {
                        opacity: 1
                    }], p);
                    b.animate([{
                        opacity: 1
                    }, {
                        opacity: 0
                    }], p).onfinish = function() {
                        b.style.cssText = "", A && A()
                    }
                }
                F.current = a
            }
        }, [N, A, C]);
        k(v, function() {
            return {
                addPage: K,
                popPage: L
            }
        }, [L, K]);
        var Q = l(function() {
            return {
                fallback: u,
                placeholderComponent: D,
                popPage: L,
                pushPage: M
            }
        }, [u, D, L, M]);
        a = l(function() {
            return c("mergeRefs")(E, b)
        }, [b]);
        return h.jsx("div", babelHelpers["extends"]({
            className: c("stylex")(n.root, w),
            ref: a
        }, c("testID")("BaseMultiStepContainer"), {
            children: C.map(function(a, b) {
                return h.jsx("div", babelHelpers["extends"]({
                    "aria-hidden": b !== N,
                    className: c("stylex")(n.page, b !== N && n.pageInactive, B),
                    ref: b === N ? P : null
                }, c("testID")(b === 0 ? "base-multistep-container-first-step" : null), {
                    children: h.jsx(d("FocusRegion.react").FocusRegion, {
                        autoFocusQuery: !g && !I && b === N ? d("focusScopeQueries").headerOrTabbableScopeQuery : null,
                        autoRestoreFocus: !s,
                        containFocusQuery: t ? null : d("focusScopeQueries").tabbableScopeQuery,
                        recoverFocusQuery: d("focusScopeQueries").headerOrTabbableScopeQuery,
                        children: h.jsx(c("FocusInertRegion.react"), {
                            disabled: b === N,
                            children: h.jsx(c("HiddenSubtreeContextProvider.react"), {
                                isHidden: b !== N,
                                children: h.jsx(c("BaseMultiPageViewContext").Provider, {
                                    value: Q,
                                    children: a.type === "initial_page" ? typeof e === "function" ? e(M) : e : a.type === "pushed_page" ? h.createElement(a.component, {
                                        onReturn: L
                                    }) : null
                                })
                            })
                        })
                    })
                }), a.key)
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometDebounce", ["clearTimeout", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        b = b === void 0 ? {} : b;
        var d = b.leading,
            e = b.wait,
            f = !0,
            g;

        function h() {
            for (var b = arguments.length, i = new Array(b), j = 0; j < b; j++) i[j] = arguments[j];
            var k;
            if (d === !0) {
                k = function() {
                    f = !0, g = null
                };
                if (!f) {
                    c("clearTimeout")(g);
                    g = c("setTimeout")(k, e);
                    return
                }
                f = !1;
                a.apply(void 0, i)
            } else h.reset(), k = function() {
                g = null, a.apply(void 0, i)
            };
            g = c("setTimeout")(k, e)
        }
        h.isPending = function() {
            return g != null
        };
        h.reset = function() {
            c("clearTimeout")(g), g = null, f = !0
        };
        return h
    }
    g["default"] = a
}), 98);
__d("BaseScrollableArea.react", ["BaseScrollableAreaContext", "CometDebounce", "CometVisualCompletionAttributes", "Locale", "UserAgent", "gkx", "react", "resize-observer-polyfill", "stylex", "useUnsafeRef_DEPRECATED", "useVisibilityObserver"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useEffect,
        k = b.useImperativeHandle,
        l = b.useMemo,
        m = b.useRef,
        n = b.useState,
        o = {
            baseScroller: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                position: "x1n2onr6"
            },
            baseScrollerHorizontal: {
                flexDirection: "x1q0g3np"
            },
            baseScrollerWithBottomShadow: {
                marginBottom: "x129vozr"
            },
            baseScrollerWithTopShadow: {
                marginTop: "xaci4zi"
            },
            "default": {
                MsOverflowStyle: "x2atdfe",
                MsScrollChaining: "xb57i2i",
                MsScrollRails: "x1q594ok",
                WebkitOverflowScrolling: "x5lxg6s",
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                position: "x1n2onr6",
                zIndex: "x1ja2u2z"
            },
            expanding: {
                flexBasis: "x1l7klhg",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minHeight: "x2lwn1j"
            },
            expandingIE11: {
                flexBasis: "xdl72j9",
                flexGrow: "x1iyjqo2",
                flexShrink: "xs83m0k",
                minHeight: "x2lwn1j"
            },
            hideScrollbar: {
                MsOverflowStyle: "x1pq812k",
                scrollbarWidth: "x1rohswg",
                "::-webkit-scrollbar": {
                    display: "xfk6m8",
                    height: "x1yqm8si",
                    width: "xjx87ck"
                }
            },
            horizontalAuto: {
                overflowX: "xw2csxc",
                overscrollBehaviorX: "x7p5m3t"
            },
            perspective: {
                perspective: "xx8ngbg",
                perspectiveOrigin: "xwo3gff",
                position: "x1n2onr6",
                transformStyle: "x1oyok0e"
            },
            perspectiveRTL: {
                perspectiveOrigin: "x1glq8lk"
            },
            verticalAuto: {
                overflowY: "x1odjw0f",
                overscrollBehaviorY: "x1e4zzel"
            }
        },
        p = {
            base: {
                boxSizing: "x9f619",
                display: "x1s85apg",
                end: "xds687c",
                opacity: "xg01cxk",
                paddingTop: "xexx8yu",
                paddingEnd: "x150jy0e",
                paddingBottom: "x18d9i69",
                paddingStart: "x1e558r4",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                top: "x13vifvy",
                transformOrigin: "x1n4smgl",
                transitionDuration: "x1d8287x",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "xwji4o3",
                width: "x1kky2od"
            },
            hovered: {
                opacity: "x1hc1fzr",
                transitionDuration: "x1p6kkr5"
            },
            inner: {
                backgroundColor: "x1hwfnsy",
                borderTopStartRadius: "x1lcm9me",
                borderTopEndRadius: "x1yr5g0i",
                borderBottomEndRadius: "xrt01vj",
                borderBottomStartRadius: "x10y3i5r",
                height: "x5yr21d",
                width: "xh8yej3"
            },
            rtl: {
                transformOrigin: "xyyilfv"
            }
        },
        q = {
            base: {
                backgroundColor: "x14nfmen",
                display: "x1s85apg",
                end: "xds687c",
                height: "x5yr21d",
                opacity: "xg01cxk",
                position: "x10l6tqk",
                top: "x13vifvy",
                transitionDuration: "x1wsgiic",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "xwji4o3",
                width: "x1kky2od",
                ":hover": {
                    opacity: "x1sd63oq"
                }
            }
        },
        r = {
            cover: {
                display: "x78zum5",
                end: "xds687c",
                flexDirection: "xdt5ytf",
                flexShrink: "x2lah0s",
                height: "x10wjd1d",
                pointerEvents: "x47corl",
                position: "x7wzq59",
                start: "x17qophe",
                zIndex: "x1vjfegm"
            },
            coverBottom: {
                bottom: "x1l3hj4d",
                clipPath: "x1vjtdzu",
                justifyContent: "x13a6bvl",
                marginBottom: "x1yztbdb"
            },
            coverTop: {
                clipPath: "x19bjbvb",
                justifyContent: "x1nhvcw1",
                top: "xepu288"
            },
            shadow: {
                flexShrink: "x2lah0s",
                height: "xlup9mm",
                position: "x7wzq59",
                "::after": {
                    boxShadow: "x7r5tp8",
                    content: "x1s928wv",
                    height: "x1a5uphr",
                    position: "x1j6awrg",
                    top: "x1s71c9q",
                    width: "x4eaejv"
                }
            },
            shadowBottom: {
                bottom: "x1ey2m1c",
                transform: "xtjevij"
            },
            shadowTop: {
                top: "x13vifvy"
            }
        },
        s = d("Locale").isRTL(),
        t = c("gkx")("1299319");

    function a(a, b) {
        var d = a.children,
            e = a.expanding;
        e = e === void 0 ? !1 : e;
        var f = a.forceBrowserDefault,
            g = f === void 0 ? !1 : f;
        f = a.hideScrollbar;
        var v = f === void 0 ? !1 : f,
            w = a.horizontal;
        f = a.id;
        var A = a.onScroll,
            B = a.onScrollBottom,
            C = a.onScrollTop,
            D = a.scrollTracePolicy,
            E = a.style,
            F = a.tabIndex,
            G = a.testid,
            H = a.vertical;
        G = a.withBottomShadow;
        G = G === void 0 ? !1 : G;
        var I = a.withTopShadow;
        I = I === void 0 ? !1 : I;
        var J = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "expanding", "forceBrowserDefault", "hideScrollbar", "horizontal", "id", "onScroll", "onScrollBottom", "onScrollTop", "scrollTracePolicy", "style", "tabIndex", "testid", "vertical", "withBottomShadow", "withTopShadow", "xstyle"]);
        var K = l(function() {
                return g || !H || v || w || z()
            }, [H, v, w, g]),
            L = n(!1),
            M = L[0],
            N = L[1];
        L = n(!1);
        var aa = L[0],
            O = L[1];
        L = n(!1);
        var ba = L[0],
            P = L[1],
            Q = i(c("BaseScrollableAreaContext")),
            R = m(null),
            S = c("useUnsafeRef_DEPRECATED")(null),
            T = m(null),
            U = m(null),
            V = m(null),
            W = m(0);
        j(function() {
            if (K) return;
            var a = R.current,
                b = S.current,
                d = T.current,
                e = U.current;
            if (a == null || b == null || d == null || e == null) return;
            var f = 0,
                g = 0,
                h = function() {
                    e.style.display = "none";
                    d.style.display = "none";
                    var a = b.getBoundingClientRect(),
                        c = Math.ceil(a.height);
                    g = a.top;
                    W.current = b.scrollHeight;
                    a = W.current;
                    a !== b.scrollHeight && (a = b.scrollHeight);
                    f = Math.pow(c, 2) / a;
                    var h = (c - f) / (a - c);
                    s ? (d.style.left = "0px", e.style.left = "0px") : (d.style.right = "0px", e.style.right = "0px");
                    d.style.height = a <= c ? "0px" : f + "px";
                    e.style.height = a + "px";
                    d.style.transform = ["matrix3d(\n          1,0,0,0,\n          0,1,0,0,\n          0,0,1,0,\n          0,0,0,-1)", "scale(" + 1 / h + ")", "translateZ(" + (1 - 1 / h) + "px)", "translateZ(-2px)"].join(" ");
                    d.style.display = "block";
                    e.style.display = a <= c ? "none" : "block"
                },
                i = function(a) {
                    u(a);
                    var c = a.clientY;
                    a = b.clientHeight;
                    var d = b.scrollTop;
                    P(!0);
                    var h = W.current / a;
                    a = d / h;
                    if (c < g + a || c > g + a + f) {
                        var i = c < g + a ? -20 : 20,
                            j = !0,
                            k = window.setInterval(function() {
                                j && b.scrollTo({
                                    top: b.scrollTop + i
                                })
                            }, 16);
                        a = function a(b) {
                            u(b), k && window.clearInterval(k), window.removeEventListener("mouseup", a, !0), e.removeEventListener("mouseenter", l), e.removeEventListener("mouseleave", m)
                        };
                        var l = function(a) {
                                u(a), j = !0
                            },
                            m = function(a) {
                                u(a), j = !1
                            };
                        window.addEventListener("mouseup", a, !0);
                        e.addEventListener("mouseenter", l);
                        e.addEventListener("mouseleave", m);
                        return
                    }
                    var n = function(a) {
                        u(a);
                        a = a.clientY - c;
                        b.scrollTo({
                            top: d + a * h
                        })
                    };
                    a = function a(b) {
                        u(b), P(!1), window.removeEventListener("mousemove", n, !0), window.removeEventListener("mouseup", a, !0)
                    };
                    window.addEventListener("mousemove", n, !0);
                    window.addEventListener("mouseup", a, !0)
                },
                j = c("CometDebounce")(h, {
                    wait: 100
                });
            window.addEventListener("resize", j);
            e.addEventListener("mousedown", i);
            var k = new(c("resize-observer-polyfill"))(j);
            k.observe(a);
            k.observe(b);
            return function() {
                window.removeEventListener("resize", j), e.removeEventListener("mousedown", i), k.disconnect(), j.reset()
            }
        }, [K]);
        L = function() {
            N(!0)
        };
        var ca = function() {
                return N(!1)
            },
            X = function(a) {
                A && A(a), O(!0), V.current && window.clearTimeout(V.current), V.current = window.setTimeout(function() {
                    O(!1)
                }, 1e3)
            };
        j(function() {
            return function() {
                window.clearTimeout(V.current)
            }
        }, []);
        var Y = l(function() {
            return {
                getDOMNode: function() {
                    return S.current
                }
            }
        }, []);
        k(b, function() {
            return Y
        }, [Y]);
        b = l(function() {
            return [].concat(Q, [Y])
        }, [Y, Q]);
        var Z = h.jsx("div", {
                className: c("stylex")(r.cover, r.coverTop),
                children: h.jsx("div", {
                    className: c("stylex")(r.shadow, r.shadowTop)
                })
            }),
            $ = h.jsx("div", {
                className: c("stylex")(r.cover, r.coverBottom),
                children: h.jsx("div", {
                    className: c("stylex")(r.shadow, r.shadowBottom)
                })
            });
        return K ? h.jsx(c("BaseScrollableAreaContext").Provider, {
            value: b,
            children: h.jsxs("div", babelHelpers["extends"]({}, a, {
                className: c("stylex")(o["default"], e && (t ? o.expandingIE11 : o.expanding), v && o.hideScrollbar, w && o.horizontalAuto, H && o.verticalAuto, J),
                "data-testid": void 0,
                id: f,
                onScroll: X,
                ref: S,
                style: E,
                tabIndex: F,
                children: [I && Z, h.jsxs("div", {
                    className: c("stylex")(o.baseScroller, w && !H && o.baseScrollerHorizontal, I && o.baseScrollerWithTopShadow, G && o.baseScrollerWithBottomShadow),
                    children: [C ? h.jsx(y, {
                        onVisible: C,
                        scrollerRef: S
                    }) : null, d, B ? h.jsx(x, {
                        onVisible: B,
                        scrollerRef: S
                    }) : null]
                }), G && $]
            }))
        }) : h.jsx(c("BaseScrollableAreaContext").Provider, {
            value: b,
            children: h.jsxs("div", babelHelpers["extends"]({}, a, {
                className: c("stylex")(o["default"], o.hideScrollbar, e && (t ? o.expandingIE11 : o.expanding), o.perspective, s && o.perspectiveRTL, w && o.horizontalAuto, H && o.verticalAuto, J),
                "data-scrolltracepolicy": D,
                "data-testid": void 0,
                id: f,
                onMouseEnter: L,
                onMouseLeave: ca,
                onScroll: X,
                ref: S,
                style: E,
                tabIndex: F,
                children: [I && Z, h.jsxs("div", {
                    className: c("stylex")(o.baseScroller, w && !H && o.baseScrollerHorizontal, I && o.baseScrollerWithTopShadow, G && o.baseScrollerWithBottomShadow),
                    ref: R,
                    children: [C ? h.jsx(y, {
                        onVisible: C,
                        scrollerRef: S
                    }) : null, d, B ? h.jsx(x, {
                        onVisible: B,
                        scrollerRef: S
                    }) : null]
                }), G && $, h.jsx("div", babelHelpers["extends"]({
                    className: c("stylex")(q.base)
                }, c("CometVisualCompletionAttributes").IGNORE, {
                    "data-thumb": 1,
                    ref: U
                })), h.jsx("div", babelHelpers["extends"]({
                    className: c("stylex")(p.base, s && p.rtl, (M || aa || ba) && p.hovered)
                }, c("CometVisualCompletionAttributes").IGNORE, {
                    "data-thumb": 1,
                    ref: T,
                    children: h.jsx("div", {
                        className: c("stylex")(p.inner)
                    })
                }))]
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var u = function(a) {
            a.preventDefault(), a.stopPropagation(), a.stopImmediatePropagation()
        },
        v = {
            bottom: {
                bottom: "x1ey2m1c"
            },
            main: {
                height: "xjm9jq1",
                opacity: "xg01cxk",
                pointerEvents: "x47corl",
                position: "x10l6tqk",
                width: "x1i1rx1s"
            },
            top: {
                top: "x13vifvy"
            }
        };

    function w(a) {
        var b = a.onVisible,
            d = a.scrollerRef;
        a = a.xstyle;
        var e = l(function() {
            return function() {
                return d.current
            }
        }, [d]);
        b = c("useVisibilityObserver")({
            onVisible: b,
            options: {
                root: e,
                rootMargin: 0
            }
        });
        return h.jsx("div", {
            className: c("stylex")(v.main, a),
            ref: b
        })
    }
    w.displayName = w.name + " [from " + f.id + "]";

    function x(a) {
        var b = a.onVisible;
        a = a.scrollerRef;
        return h.jsx(w, {
            onVisible: b,
            scrollerRef: a,
            xstyle: v.bottom
        })
    }
    x.displayName = x.name + " [from " + f.id + "]";

    function y(a) {
        var b = a.onVisible;
        a = a.scrollerRef;
        return h.jsx(w, {
            onVisible: b,
            scrollerRef: a,
            xstyle: v.top
        })
    }
    y.displayName = y.name + " [from " + f.id + "]";

    function z() {
        return c("UserAgent").isPlatform("iOS") || c("UserAgent").isPlatform("Android") || c("UserAgent").isBrowser("Edge") || c("UserAgent").isBrowser("IE") || c("UserAgent").isBrowser("Firefox < 64")
    }
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("BaseStyledButton.react", ["BaseRow.react", "BaseRowItem.react", "CometPressable.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useRef,
        j = .96,
        k = 10,
        l = {
            button: {
                boxSizing: "x9f619",
                display: "x3nfvp2",
                flexDirection: "xdt5ytf",
                justifyContent: "xl56j7k",
                position: "x1n2onr6",
                width: "xh8yej3"
            },
            content: {
                borderTopStartRadius: "xi112ho",
                borderTopEndRadius: "x17zwfj4",
                borderBottomEndRadius: "x585lrc",
                borderBottomStartRadius: "x1403ito",
                borderTopWidth: "x972fbf",
                borderEndWidth: "xcfux6l",
                borderBottomWidth: "x1qhh985",
                borderStartWidth: "xm0m39n",
                boxSizing: "x9f619",
                paddingEnd: "xn6708d",
                paddingStart: "x1ye3gou"
            },
            disabled: {
                backgroundColor: "xwcfey6"
            },
            item: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexShrink: "x2lah0s",
                marginEnd: "xeyog9w",
                marginStart: "x1w4ip6v"
            },
            offset: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                justifyContent: "xl56j7k",
                marginEnd: "xj3m2qm",
                marginStart: "x1uirj4r",
                width: "x1e0frkt"
            },
            paddingWide: {
                paddingEnd: "xbxaen2",
                paddingStart: "x1u72gb5"
            }
        };

    function a(a, b) {
        var d = a.addOnAbsolute,
            e = a.addOnEnd,
            f = a.addOnStart,
            g = a.content,
            m = a.contentXstyle,
            n = a.disabled,
            o = n === void 0 ? !1 : n;
        n = a.display;
        n = n === void 0 ? "inline" : n;
        var p = a.focusable,
            q = a.icon,
            r = a.id,
            s = a.linkProps,
            t = a.onFocusIn,
            u = a.onFocusOut,
            v = a.onHoverIn,
            w = a.onHoverOut,
            x = a.onPress,
            y = a.onPressIn,
            z = a.onPressOut,
            A = a.overlayHoveredStyle,
            B = a.overlayPressedStyle,
            C = a.padding,
            D = C === void 0 ? "normal" : C;
        C = a.suppressHydrationWarning;
        C = C === void 0 ? !1 : C;
        var E = a.testid;
        E = a.testOnly_pressed;
        E = E === void 0 ? !1 : E;
        var F = a.xstyle;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnAbsolute", "addOnEnd", "addOnStart", "content", "contentXstyle", "disabled", "display", "focusable", "icon", "id", "linkProps", "onFocusIn", "onFocusOut", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "onPressOut", "overlayHoveredStyle", "overlayPressedStyle", "padding", "suppressHydrationWarning", "testid", "testOnly_pressed", "xstyle"]);
        var G = i(null),
            H = function(a) {
                if (G.current != null) {
                    var b = G.current;
                    b.style.transform = "scale(" + Math.max(j, (b.offsetWidth - k) / b.offsetWidth) + ")"
                }
                typeof y === "function" && y(a)
            },
            I = function(a) {
                if (G.current != null) {
                    var b = G.current;
                    b.style.transform = "none"
                }
                typeof z === "function" && z(a)
            };
        F = c("stylex").compose(F);
        var J = F.alignSelf,
            K = F.flexBasis,
            L = F.flexGrow,
            M = F.flexShrink,
            N = F.height,
            O = F.justifySelf,
            P = F.margin,
            Q = F.marginBottom,
            R = F.marginEnd,
            S = F.marginStart,
            T = F.marginTop,
            U = F.maxHeight,
            V = F.maxWidth,
            W = F.minHeight,
            X = F.minWidth,
            Y = F.position,
            Z = F.width,
            $ = babelHelpers.objectWithoutPropertiesLoose(F, ["alignSelf", "flexBasis", "flexGrow", "flexShrink", "height", "justifySelf", "margin", "marginBottom", "marginEnd", "marginStart", "marginTop", "maxHeight", "maxWidth", "minHeight", "minWidth", "position", "width"]);
        F = function(a) {
            a = a.overlay;
            return h.jsxs(c("BaseRow.react"), {
                align: "center",
                ref: G,
                verticalAlign: "center",
                xstyle: [l.content, D === "wide" && l.paddingWide, o && l.disabled, $, m],
                children: [h.jsxs("div", {
                    className: c("stylex")(l.offset),
                    children: [f != null ? h.jsx(c("BaseRowItem.react"), {
                        useDeprecatedStyles: !0,
                        xstyle: l.item,
                        children: f
                    }) : q != null ? h.jsx(c("BaseRowItem.react"), {
                        useDeprecatedStyles: !0,
                        xstyle: l.item,
                        children: q
                    }) : null, g != null ? h.jsx(c("BaseRowItem.react"), {
                        useDeprecatedStyles: !0,
                        xstyle: l.item,
                        children: g
                    }) : null, e != null ? h.jsx(c("BaseRowItem.react"), {
                        useDeprecatedStyles: !0,
                        xstyle: l.item,
                        children: e
                    }) : null]
                }), a, d != null ? d : null]
            })
        };
        return h.jsx(c("CometPressable.react"), babelHelpers["extends"]({}, a, {
            disabled: o,
            display: n,
            focusable: p,
            id: r,
            linkProps: s,
            onFocusIn: t,
            onFocusOut: u,
            onHoverIn: v,
            onHoverOut: w,
            onPress: x,
            onPressIn: H,
            onPressOut: I,
            overlayHoveredStyle: A,
            overlayPressedStyle: B,
            ref: b,
            suppressHydrationWarning: C,
            testOnly_pressed: E,
            testid: void 0,
            xstyle: [l.button, {
                alignSelf: J,
                flexBasis: K,
                flexGrow: L,
                flexShrink: M,
                height: N,
                justifySelf: O,
                margin: P,
                marginBottom: Q,
                marginEnd: R,
                marginStart: S,
                marginTop: T,
                maxHeight: U,
                maxWidth: V,
                minHeight: W,
                minWidth: X,
                position: Y,
                width: Z
            }],
            children: F
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("XPlatReactToasterStateManager", ["clearTimeout", "removeFromArray", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function i(a) {
        var b = !1;
        return function() {
            b || (a(), b = !0)
        }
    }
    a = function() {
        function a(a) {
            var b = a.callbackScheduler;
            a = a.maxQueuedToasts;
            this.$1 = 0;
            this.$2 = new Map();
            this.$3 = [];
            this.$4 = [];
            this.$5 = null;
            this.$7 = b;
            this.$6 = a
        }
        var b = a.prototype;
        b.push = function(a, b) {
            var c = "toast-" + this.$1++;
            b = {
                duration: b,
                expired: !1,
                id: c,
                shown: !1,
                timer: null,
                value: a
            };
            this.$8({
                node: b,
                type: "PUSH"
            });
            return c
        };
        b.replace = function(a, b) {
            this.$8({
                id: a,
                type: "REPLACE",
                value: b
            })
        };
        b.shown = function(a) {
            this.$8({
                id: a,
                type: "SHOWN"
            })
        };
        b["delete"] = function(a) {
            this.$8({
                id: a,
                type: "DELETE"
            })
        };
        b.expire = function(a) {
            this.$8({
                id: a,
                type: "EXPIRE"
            })
        };
        b.hidden = function(a) {
            this.$8({
                id: a,
                type: "HIDDEN"
            })
        };
        b.stopTimer = function(a) {
            this.$8({
                id: a,
                type: "STOP_TIMER"
            })
        };
        b.resetTimer = function(a) {
            this.$8({
                id: a,
                type: "RESET_TIMER"
            })
        };
        b.getState = function() {
            return Object.fromEntries(this.$2)
        };
        b.getEmptyState = function() {
            return h
        };
        b.addListener = function(a) {
            var b = this;
            this.$3.push(a);
            return {
                remove: i(function() {
                    c("removeFromArray")(b.$3, a)
                })
            }
        };
        b.$9 = function(a) {
            (this.$5 == null || a.priority > this.$5.priority) && (this.$5 = a)
        };
        b.registerView = function(a, b) {
            var d = this;
            b === void 0 && (b = 1);
            var e = {
                handler: a,
                priority: b
            };
            this.$4.push(e);
            this.$9(e);
            this.$10();
            return {
                remove: i(function() {
                    c("removeFromArray")(d.$4, e), d.$5 === e && (d.$5 = null, d.$4.forEach(function(a) {
                        return d.$9(a)
                    }))
                })
            }
        };
        b.$8 = function(a) {
            var b = this.$2;
            switch (a.type) {
                case "PUSH":
                    var c = a.node;
                    this.$2 = new Map([].concat(Array.from(this.$2), [
                        [c.id, c]
                    ]));
                    if (this.$6 !== 0) {
                        c = Array.from(this.$2.values()).filter(function(a) {
                            return !a.shown && !a.expired
                        });
                        if (c.length > this.$6) {
                            c = c[0];
                            this["delete"](c.id)
                        }
                    }
                    break;
                case "SHOWN":
                    if (this.$2.has(a.id) && !this.$11(a.id).shown) {
                        c = babelHelpers["extends"]({}, this.$11(a.id), {
                            shown: !0
                        });
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$12(c)]
                        ]))
                    }
                    break;
                case "EXPIRE":
                    if (this.$2.has(a.id)) {
                        c = babelHelpers["extends"]({}, this.$11(a.id), {
                            expired: !0
                        });
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$13(c)]
                        ]));
                        this.$14(c)
                    }
                    break;
                case "HIDDEN":
                    if (this.$2.has(a.id)) {
                        c = this.$11(a.id);
                        (c.shown || c.expired) && (this.$2 = new Map(this.$2), this.$2["delete"](a.id), this.$13(c))
                    }
                    break;
                case "DELETE":
                    if (this.$2.has(a.id)) {
                        c = this.$11(a.id);
                        this.$2 = new Map(this.$2);
                        this.$2["delete"](a.id);
                        this.$13(c)
                    }
                    break;
                case "REPLACE":
                    if (this.$2.has(a.id)) {
                        c = this.$11(a.id);
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, babelHelpers["extends"]({}, c, {
                                value: a.value
                            })]
                        ]))
                    }
                    break;
                case "STOP_TIMER":
                    if (this.$2.has(a.id) && this.$15(this.$11(a.id))) {
                        c = babelHelpers["extends"]({}, this.$11(a.id));
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$13(c)]
                        ]))
                    }
                    break;
                case "RESET_TIMER":
                    if (this.$2.has(a.id) && !this.$15(this.$11(a.id))) {
                        c = babelHelpers["extends"]({}, this.$11(a.id));
                        this.$2 = new Map([].concat(Array.from(this.$2), [
                            [a.id, this.$12(c)]
                        ]))
                    }
                    break;
                default:
                    a.type
            }
            b !== this.$2 && this.$10()
        };
        b.$10 = function() {
            var a = this;
            this.$3.forEach(function(b) {
                return a.$7(function() {
                    b()
                })
            });
            this.$4.forEach(function(b) {
                return a.$7(function() {
                    b.handler(b === a.$5 ? a.getState() : a.getEmptyState())
                })
            })
        };
        b.$12 = function(a) {
            var b = this;
            a.duration !== null && a.timer == null && (a.timer = c("setTimeout")(function() {
                b.expire(a.id)
            }, a.duration));
            return a
        };
        b.$13 = function(a) {
            a.timer != null && (c("clearTimeout")(a.timer), a.timer = null);
            return a
        };
        b.$14 = function(a) {
            var b = this;
            this.$13(a);
            var d = a.id;
            c("setTimeout")(function() {
                b["delete"](d)
            }, 1e3)
        };
        b.$15 = function(a) {
            return a.timer != null
        };
        b.$11 = function(a) {
            a = this.$2.get(a);
            if (a == null) throw c("unrecoverableViolation")("Toast with given identifier was not found", "comet_ui");
            return a
        };
        a.getInstance = function(b) {
            a.$16 == null && (a.$16 = new a(b));
            return a.$16
        };
        a.resetInstance_DO_NOT_USE = function() {
            a.$16 = null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("BaseToasterStateManager", ["CometMaxEnqueuedToastsSitevarConfig", "JSScheduler", "XPlatReactToasterStateManager", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function h(a) {
        d("JSScheduler").scheduleNormalPriCallback(function() {
            a()
        })
    }
    a = {
        getInstance: function() {
            return c("XPlatReactToasterStateManager").getInstance({
                callbackScheduler: h,
                maxQueuedToasts: c("CometMaxEnqueuedToastsSitevarConfig").max
            })
        },
        resetInstance_DO_NOT_USE: function() {
            c("XPlatReactToasterStateManager").resetInstance_DO_NOT_USE()
        }
    };
    g["default"] = a
}), 98);
__d("BaseToasterStateManagerContext.react", ["BaseToasterStateManager", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(c("BaseToasterStateManager").getInstance());
    g["default"] = b
}), 98);
__d("useToasterStateManager", ["BaseToasterStateManagerContext.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("BaseToasterStateManagerContext.react"))
    }
    g["default"] = a
}), 98);
__d("BaseTooltipTargetWrapper.react", ["FocusWithinHandler.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useRef,
        l = b.useState;

    function a(a, b) {
        var d = a.children,
            e = a.forceInlineDisplay,
            f = a.onHide,
            g = a.onShow,
            m = a.tooltipIdentifier;
        a = l(!1);
        var n = a[0];
        a = a[1];
        var o = l(!1),
            p = o[0];
        o = o[1];
        var q = n && p,
            r = k(q);
        j(function() {
            r.current !== q && (q ? g() : f()), r.current = q
        }, [f, g, q]);
        n = i(function(a) {
            var b = a.key;
            b === "Escape" && m != null && (f(), a.stopPropagation())
        }, [f, m]);
        return h.jsx("span", {
            "aria-describedby": m,
            className: c("stylex")({
                "align-content-1": "x4k7w5x",
                "align-items-1": "x1h91t0o",
                "align-self-1": "x1h9r5lt",
                "display-1": "x1jfb8zj",
                "flex-basis-1": "xv2umb2",
                "flex-direction-1": "x1beo9mf",
                "flex-grow-1": "xaigb6o",
                "flex-shrink-1": "x12ejxvf",
                "height-1": "x3igimt",
                "justify-content-1": "xarpa2k",
                "max-height-1": "xedcshv",
                "max-width-1": "x1lytzrv",
                "min-height-1": "x1t2pt76",
                "min-width-1": "x7ja8zs",
                "width-1": "x1qrby5j"
            }, e === !0 ? {
                "display-1": "x3nfvp2"
            } : null),
            "data-testid": void 0,
            onKeyDown: n,
            onPointerEnter: g,
            onPointerLeave: f,
            onPointerUp: f,
            ref: b,
            children: h.jsx(c("FocusWithinHandler.react"), {
                onFocusChange: a,
                onFocusVisibleChange: o,
                children: d
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("useDelayedState", ["clearTimeout", "emptyFunction", "react", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useRef,
        k = b.useState;

    function a(a) {
        a = k(a);
        var b = a[0],
            d = a[1],
            e = j(null);
        i(function() {
            return function() {
                return c("clearTimeout")(e.current)
            }
        }, []);
        a = h(function(a, b, f) {
            b === void 0 && (b = 0), f === void 0 && (f = c("emptyFunction")), c("clearTimeout")(e.current), e.current = null, b === 0 ? (d(a), f(a)) : e.current = c("setTimeout")(function() {
                d(a), f(a), e.current = null
            }, b)
        }, []);
        return [b, a]
    }
    g["default"] = a
}), 98);
__d("BaseTooltipGroup.react", ["BaseTooltipTargetWrapper.react", "react", "recoverableViolation", "useCometUniqueID", "useDelayedState", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    e = d("react");
    var i = e.useCallback,
        j = e.useContext,
        k = e.useMemo,
        l = e.useRef,
        m = e.useState,
        n = h.createContext(null);

    function a(a) {
        var b = a.children;
        a = a.tooltipImpl;
        var d = c("useDelayedState")(!1),
            e = d[0],
            f = d[1];
        d = m(null);
        var g = d[0],
            i = d[1],
            j = c("useCometUniqueID")(),
            l = g != null && g.contentKey != null ? g.contentKey : null;
        d = k(function() {
            return {
                activeContentKey: l,
                isVisible: e,
                onHide: function(a, b) {
                    f(!1, a, b)
                },
                onShow: function(a, b, c) {
                    i(a), f(!0, b, c)
                },
                tooltipIdentifier: j
            }
        }, [l, e, j, f]);
        return h.jsxs(h.Fragment, {
            children: [h.jsx(n.Provider, {
                value: d,
                children: b
            }), g != null ? h.jsx(a, babelHelpers["extends"]({}, g, {
                id: e ? j : void 0,
                isVisible: e
            })) : null]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    var o = 0;

    function p() {
        return "tooltip-" + o++
    }

    function b(a) {
        var b = a.children,
            d = a.disabled,
            e = d === void 0 ? !1 : d;
        d = a.forceInlineDisplay;
        var f = a.hideDelayMs,
            g = a.onVisibilityChange,
            k = a.showDelayMs,
            m = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "disabled", "forceInlineDisplay", "hideDelayMs", "onVisibilityChange", "showDelayMs"]),
            o = c("useStable")(p),
            q = l(null);
        a = j(n);
        var r = a || {},
            s = r.activeContentKey,
            t = r.isVisible,
            u = r.onHide,
            v = r.onShow;
        r = r.tooltipIdentifier;
        var w = i(function() {
                !e && v && v(babelHelpers["extends"]({
                    contentKey: o,
                    contextRef: q
                }, m), k, g)
            }, [e, v, o, m, k, g]),
            x = i(function() {
                u && u(f, g)
            }, [f, u, g]);
        a == null && c("recoverableViolation")("BaseTooltipGroup: Cannot render a BaseTooltipGroupChild component outside of a BaseTooltipGroup component. ", "comet_ui");
        return h.jsx(c("BaseTooltipTargetWrapper.react"), {
            forceInlineDisplay: d,
            onHide: x,
            onShow: w,
            ref: q,
            tooltipIdentifier: t && s === o ? r : void 0,
            children: b
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";
    g.Context = n;
    g.Container = a;
    g.Child = b
}), 98);
__d("BaseTooltip.react", ["BaseTooltipGroup.react", "BaseTooltipTargetWrapper.react", "react", "useCometUniqueID", "useDelayedState"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext,
        k = b.useRef,
        l = 50,
        m = 300;

    function n(a) {
        var b = a.children,
            d = a.delayTooltipMs,
            e = d === void 0 ? m : d;
        d = a.disabled;
        var f = d === void 0 ? !1 : d;
        d = a.forceInlineDisplay;
        var g = a.tooltipImpl,
            j = a.onVisibilityChange;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["children", "delayTooltipMs", "disabled", "forceInlineDisplay", "tooltipImpl", "onVisibilityChange"]);
        var l = c("useDelayedState")(!1),
            n = l[0],
            o = l[1];
        l = k(null);
        var p = c("useCometUniqueID")(),
            q = i(function() {
                if (f) return;
                o(!0, e, j)
            }, [e, f, j, o]),
            r = i(function() {
                o(!1, 0, j)
            }, [j, o]);
        return h.jsxs(h.Fragment, {
            children: [h.jsx(c("BaseTooltipTargetWrapper.react"), {
                forceInlineDisplay: d,
                onHide: r,
                onShow: q,
                ref: l,
                tooltipIdentifier: n ? p : void 0,
                children: b
            }), h.jsx(g, babelHelpers["extends"]({}, a, {
                contentKey: null,
                contextRef: l,
                id: n ? p : void 0,
                isVisible: n
            }))]
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        var b = j(d("BaseTooltipGroup.react").Context);
        if (b != null) {
            b = a.delayTooltipMs;
            b = b === void 0 ? m : b;
            a.tooltipImpl;
            var c = babelHelpers.objectWithoutPropertiesLoose(a, ["delayTooltipMs", "tooltipImpl"]);
            return h.jsx(d("BaseTooltipGroup.react").Child, babelHelpers["extends"]({}, c, {
                hideDelayMs: l,
                showDelayMs: b
            }))
        }
        return h.jsx(n, babelHelpers["extends"]({}, a))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useFadeEffect", ["clearTimeout", "react", "setTimeout", "useDoubleEffectHack_DO_NOT_USE_THIS_IS_TRACKED", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useReducer,
        j = b.useRef,
        k = 1e3;

    function l(a, b) {
        switch (b.type) {
            case "start":
                return {
                    isTransitioning: !0,
                    shouldBeVisible: b.shouldBeVisible
                };
            case "finish":
                return {
                    isTransitioning: !1,
                    shouldBeVisible: a.shouldBeVisible
                };
            default:
                return a
        }
    }

    function a(a) {
        var b = j(null),
            d = i(l, {
                isTransitioning: !1,
                shouldBeVisible: !1
            }),
            e = d[0],
            f = e.isTransitioning;
        e = e.shouldBeVisible;
        var g = d[1],
            m = j(null),
            n = j(null);
        c("useDoubleEffectHack_DO_NOT_USE_THIS_IS_TRACKED")(function() {
            return function() {
                m.current != null && c("clearTimeout")(m.current), n.current != null && window.cancelAnimationFrame(n.current)
            }
        }, []);
        var o = h(function() {
                g({
                    type: "finish"
                }), m.current != null && c("clearTimeout")(m.current), m.current = null
            }, []),
            p = h(function(a) {
                n.current != null && window.cancelAnimationFrame(n.current), n.current = window.requestAnimationFrame(function() {
                    g({
                        shouldBeVisible: a,
                        type: "start"
                    }), n.current = null, m.current != null && c("clearTimeout")(m.current), m.current = c("setTimeout")(o, k)
                })
            }, [o]),
            q = j(!1);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            q.current !== a && (!a || b.current != null) && p(a), q.current = a
        }, [a, p]);
        d = h(function(a) {
            var c = b.current;
            b.current = a;
            a != null ? (a.addEventListener != null && (a.addEventListener("transitionend", o), a.addEventListener("webkitTransitionEnd", o)), q.current === !0 && p(!0)) : c != null && c.removeEventListener != null && (c.removeEventListener("transitionend", o), c.removeEventListener("webkitTransitionEnd", o))
        }, [o, p]);
        f = f || e || a;
        return [f, e, d]
    }
    g["default"] = a
}), 98);
__d("BaseMultiPageViewReducer", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = 0;

    function h() {
        return g++
    }
    b = [{
        key: h(),
        type: "initial_page"
    }];

    function a(a, b) {
        var c = a.filter(function(a) {
            return a.type !== "pushed_page" || !a.removed
        });
        switch (b.type) {
            case "push_page":
                return c.concat([{
                    component: b.component,
                    direction: b.direction,
                    key: h(),
                    removed: !1,
                    type: "pushed_page"
                }]);
            case "clear_removed_pages":
                return c;
            case "pop_page":
                var d = c[c.length - 1];
                if (d.type === "pushed_page") return [].concat(c.slice(0, b.index != null ? Math.max(b.index + 1, 1) : -1), [babelHelpers["extends"]({}, d, {
                    removed: !0
                })])
        }
        return a
    }
    f.initialState = b;
    f.reducer = a
}), 66);
__d("BaseMultiPageView.react", ["BaseMultiPageViewContainer.react", "BaseMultiPageViewReducer", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useReducer;

    function a(a, b) {
        a = babelHelpers["extends"]({}, a);
        var e = j(d("BaseMultiPageViewReducer").reducer, d("BaseMultiPageViewReducer").initialState),
            f = e[0],
            g = e[1];
        e = i(function(a, b) {
            g({
                component: b,
                direction: a,
                type: "push_page"
            })
        }, [g]);
        var k = i(function(a) {
                return g({
                    index: a == null ? void 0 : a.index,
                    type: "pop_page"
                })
            }, [g]),
            l = i(function() {
                g({
                    type: "clear_removed_pages"
                })
            }, [g]);
        return h.jsx(c("BaseMultiPageViewContainer.react"), babelHelpers["extends"]({}, a, {
            onAddPage: e,
            onClearRemovedPages: l,
            onPopPage: k,
            pageHistory: f,
            ref: b
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometDialogLoadingStateContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(!1);
    g["default"] = b
}), 98);
__d("ChevronLeftOutline24.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            fill: "currentColor",
            viewBox: "0 0 24 24",
            width: "1em",
            height: "1em"
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M6.053 12.53a.748.748 0 0 1 0-1.06l7.5-7.5a.75.75 0 1 1 1.061 1.06L7.644 12l6.97 6.97a.75.75 0 0 1-1.061 1.06z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("ChevronRightOutline24.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            fill: "currentColor",
            viewBox: "0 0 24 24",
            width: "1em",
            height: "1em"
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M17.947 12.53a.748.748 0 0 0 0-1.06l-7.5-7.5a.75.75 0 1 0-1.061 1.06l6.97 6.97-6.97 6.97a.75.75 0 0 0 1.061 1.06z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("CometDialogHeaderContainer.react", ["CometDivider.react", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            container: {
                alignItems: "x6s0dn4",
                display: "x78zum5",
                flexShrink: "x2lah0s",
                justifyContent: "x1qughib",
                minHeight: "x879a55",
                position: "x1n2onr6"
            }
        };

    function a(a) {
        var b = a.children,
            d = a.id,
            e = a.withDivider;
        e = e === void 0 ? !1 : e;
        a = a.xstyle;
        return h.jsxs("div", {
            children: [h.jsx("div", {
                className: c("stylex")([i.container, a]),
                id: d,
                children: b
            }), e && h.jsx(c("CometDivider.react"), {})]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CrossFilled24.svg.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        return h.jsxs("svg", babelHelpers["extends"]({
            fill: "currentColor",
            viewBox: "0 0 24 24",
            width: "1em",
            height: "1em"
        }, a, {
            children: [a.title != null && h.jsx("title", {
                children: a.title
            }), a.children != null && h.jsx("defs", {
                children: a.children
            }), h.jsx("path", {
                d: "M18.707 5.293a1 1 0 0 0-1.414 0L12 10.586 6.707 5.293a1 1 0 0 0-1.414 1.414L10.586 12l-5.293 5.293a1 1 0 1 0 1.414 1.414L12 13.414l5.293 5.293a1 1 0 0 0 1.414-1.414L13.414 12l5.293-5.293a1 1 0 0 0 0-1.414z"
            })]
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    a._isSVG = !0;
    b = a;
    g["default"] = b
}), 98);
__d("CometDialogHeader.react", ["fbt", "ChevronLeftOutline24.svg.react", "ChevronRightOutline24.svg.react", "CometCircleButton.react", "CometDialogHeaderContainer.react", "CrossFilled24.svg.react", "Locale", "TetraText.react", "emptyFunction", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = {
            headerItem: {
                marginEnd: "xktsk01",
                marginStart: "x1d52u69"
            },
            headerPlaceholder: {
                height: "xc9qbxq",
                width: "x14qfxbe"
            }
        },
        k = c("Locale").isRTL();

    function a(a) {
        var b = a.backTestID;
        b = b === void 0 ? "back-button" : b;
        b = a.closeTestID;
        b = b === void 0 ? "close-button" : b;
        b = a.disabled;
        b = b === void 0 ? !1 : b;
        var d = a.withBackButton;
        d = d === void 0 ? !1 : d;
        var e = a.withCloseButton;
        e = e === void 0 ? !0 : e;
        var f = a.onClose;
        f = f === void 0 ? c("emptyFunction") : f;
        var g = a.onBack;
        g = g === void 0 ? c("emptyFunction") : g;
        var l = a.withoutDivider;
        l = l === void 0 ? !1 : l;
        var m = a.text;
        a = a.id;
        return i.jsxs(c("CometDialogHeaderContainer.react"), {
            withDivider: !l,
            children: [d ? i.jsx("div", {
                className: c("stylex")(j.headerItem),
                children: i.jsx(c("CometCircleButton.react"), {
                    disabled: b,
                    icon: k ? c("ChevronRightOutline24.svg.react") : c("ChevronLeftOutline24.svg.react"),
                    label: h._("Back"),
                    onPress: g,
                    size: 36,
                    testid: void 0
                })
            }) : i.jsx("div", {
                className: c("stylex")([j.headerItem, j.headerPlaceholder])
            }), m != null && i.jsx(c("TetraText.react"), {
                align: "center",
                id: a,
                isSemanticHeading: !0,
                numberOfLines: 1,
                type: "headlineEmphasized2",
                children: m
            }), e ? i.jsx("div", {
                className: c("stylex")(j.headerItem),
                children: i.jsx(c("CometCircleButton.react"), {
                    disabled: b,
                    icon: c("CrossFilled24.svg.react"),
                    label: h._("Close"),
                    onPress: f,
                    size: 36,
                    testid: void 0
                })
            }) : i.jsx("div", {
                className: c("stylex")([j.headerPlaceholder, j.headerItem])
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogLoadingStateImpl.react", ["CometGlimmer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            firstLine: {
                height: "x1kpxq89",
                marginBottom: "xyorhqc",
                maxWidth: "xq2pcee"
            },
            glimmer: {
                alignSelf: "xqcrz7y",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                boxSizing: "x9f619",
                marginEnd: "xktsk01",
                marginStart: "x1d52u69",
                width: "x19sv2k2"
            },
            heading: {
                height: "x1qx5ct2",
                marginTop: "x1sy10c2",
                marginBottom: "xieb3on",
                maxWidth: "xws0hc0"
            },
            secondLine: {
                height: "x1kpxq89",
                marginBottom: "xieb3on",
                maxWidth: "xg16ivm"
            }
        };

    function a(a) {
        return h.jsxs(h.Fragment, {
            children: [h.jsx(c("CometGlimmer.react"), {
                index: 0,
                xstyle: [i.glimmer, i.heading]
            }), h.jsx(c("CometGlimmer.react"), {
                index: 1,
                xstyle: [i.glimmer, i.firstLine]
            }), h.jsx(c("CometGlimmer.react"), {
                index: 2,
                xstyle: [i.glimmer, i.secondLine]
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogPage.react", ["BaseHeadingContextWrapper.react", "BaseScrollableArea.react", "FocusInertRegion.react", "focusScopeQueries", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            container: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                minHeight: "x7ywyr2"
            },
            inert: {
                pointerEvents: "x47corl",
                userSelect: "x87ps6o"
            },
            root: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                flexGrow: "x1iyjqo2",
                maxHeight: "x1yr2tfi",
                position: "x1n2onr6",
                "@media (max-width: 679px)": {
                    maxHeight: "x1jxyteu"
                }
            },
            rootFullHeight: {
                minHeight: "xw36ugu"
            },
            rootMinHeight: {
                "@media (max-width: 679px)": {
                    minHeight: "x1mfppf3"
                }
            },
            scrollableArea: {
                flexGrow: "x1iyjqo2",
                overscrollBehaviorY: "xy5w88m"
            }
        };

    function a(a) {
        var b = a.children,
            e = a.footer,
            f = a.header,
            g = a.isContentInert;
        g = g === void 0 ? !1 : g;
        var j = a.isFullHeightByDefault;
        j = j === void 0 ? !1 : j;
        var k = a.mobileFullHeight;
        k = k === void 0 ? !0 : k;
        a = a.scrollAreaRef;
        return h.jsxs("div", {
            className: c("stylex")([i.root, j && i.rootFullHeight, k && b != null && i.rootMinHeight]),
            children: [f, b != null && h.jsx(c("BaseHeadingContextWrapper.react"), {
                children: h.jsx(c("BaseScrollableArea.react"), {
                    horizontal: !1,
                    ref: a,
                    vertical: !0,
                    withBottomShadow: e != null,
                    withTopShadow: f != null,
                    xstyle: [i.scrollableArea, g && i.inert],
                    children: h.jsx(c("FocusInertRegion.react"), {
                        disabled: !g,
                        focusQuery: d("focusScopeQueries").tabbableScopeQuery,
                        children: h.jsx("div", {
                            className: c("stylex")(i.container),
                            children: b
                        })
                    })
                })
            }), e]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogPageLoadingState.react", ["CometDialogHeader.react", "CometDialogLoadingStateImpl.react", "CometDialogPage.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.onClose;
        return h.jsx(c("CometDialogPage.react"), {
            footer: null,
            header: h.jsx(c("CometDialogHeader.react"), {
                onClose: a
            }),
            children: h.jsx(c("CometDialogLoadingStateImpl.react"), {})
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogContainer.react", ["BaseDialog.react", "BaseMultiPageView.react", "CometDialogLoadingStateContext", "CometDialogPageLoadingState.react", "emptyFunction", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo,
        k = {
            anchor: {
                alignItems: "x1qjc9v5",
                maxHeight: "x1bwycvy",
                paddingEnd: "x150jy0e",
                paddingStart: "x1e558r4",
                paddingTop: "x1x97wu9",
                paddingBottom: "xbr3nou",
                "@supports (padding: env(safe-area-inset-bottom, 0))": {
                    paddingBottom: "xqit15g",
                    paddingTop: "x1bi8yb4"
                }
            },
            card: {
                backgroundColor: "x1jx94hy",
                borderTopStartRadius: "x1qpq9i9",
                borderTopEndRadius: "xdney7k",
                borderBottomEndRadius: "xu5ydu1",
                borderBottomStartRadius: "xt3gfkd",
                boxShadow: "x104qc98",
                clipPath: "x1gj8qfm",
                flexGrow: "x1iyjqo2",
                overflowX: "x6ikm8r",
                overflowY: "x10wlt62",
                "@media (max-width: 679px)": {
                    boxShadow: "x1likypf",
                    clipPath: "x7b354b",
                    overflowX: "x1e9k66k",
                    overflowY: "x12l8kdc"
                }
            },
            dialog: {
                alignItems: "x1qjc9v5",
                borderTopStartRadius: "x1qpq9i9",
                borderTopEndRadius: "xdney7k",
                borderBottomEndRadius: "xu5ydu1",
                borderBottomStartRadius: "xt3gfkd",
                display: "x78zum5",
                overflowX: "x1plvlek",
                overflowY: "xryxfnj",
                "@media (max-width: 679px)": {
                    boxShadow: "xcatxm7"
                }
            },
            root: {
                "@media (max-width: 679px)": {
                    justifyContent: "xshlqvt"
                }
            }
        },
        l = {
            medium: {
                maxWidth: "xrgej4m",
                width: "xh8yej3"
            },
            small: {
                maxWidth: "x1n7qst7",
                width: "xh8yej3"
            }
        };

    function a(a, b) {
        var d = a.anchorXStyle,
            e = a.children,
            f = a.disableClosingWithMask;
        f = f === void 0 ? !1 : f;
        var g = a.label,
            m = a.labelledBy,
            n = a.onClose,
            o = a.size;
        o = o === void 0 ? "small" : o;
        a = a.testid;
        a = j(function() {
            var a;
            return h.jsx(c("CometDialogPageLoadingState.react"), {
                onClose: (a = n) != null ? a : c("emptyFunction")
            })
        }, [n]);
        var p = i(c("CometDialogLoadingStateContext"));
        return h.jsx(c("BaseDialog.react"), {
            anchorXStyle: [k.anchor, d],
            "aria-label": g,
            "aria-labelledby": m,
            disableClosingWithMask: f,
            onClose: (d = n) != null ? d : c("emptyFunction"),
            ref: b,
            rootXStyle: k.root,
            testid: void 0,
            xstyle: [k.dialog, l[o]],
            children: h.jsx(c("BaseMultiPageView.react"), {
                disableAutoRestoreFocus: p,
                fallback: a,
                xstyle: k.card,
                children: e
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometDialog.react", ["CometDialogContainer.react", "CometDialogPage.react", "react", "useCometUniqueID"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = a.anchorXStyle,
            e = a.disableClosingWithMask,
            f = a.header,
            g = a.label,
            i = a.labelledBy,
            j = a.onClose,
            k = a.size,
            l = a.testid;
        l = babelHelpers.objectWithoutPropertiesLoose(a, ["anchorXStyle", "disableClosingWithMask", "header", "label", "labelledBy", "onClose", "size", "testid"]);
        a = c("useCometUniqueID")();
        var m = f;
        f != null && f.props.id == null && (m = h.cloneElement(f, babelHelpers["extends"]({}, f.props, {
            id: a
        })));
        return h.jsx(c("CometDialogContainer.react"), {
            anchorXStyle: d,
            disableClosingWithMask: e,
            label: g,
            labelledBy: (f = i) != null ? f : a,
            onClose: j,
            ref: b,
            size: k,
            testid: void 0,
            children: h.jsx(c("CometDialogPage.react"), babelHelpers["extends"]({
                header: m
            }, l))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometDialogFooterContainer.react", ["CometColumn.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            root: {
                "@media (max-width: 679px)": {
                    backgroundColor: "x1hlgzme",
                    borderBottomEndRadius: "xvcs8rp",
                    borderBottomStartRadius: "x1bpvpm7",
                    bottom: "xefnots",
                    boxShadow: "x13xjmei",
                    position: "xv7j57z"
                }
            }
        };

    function a(a) {
        a = a.children;
        return h.jsx(c("CometColumn.react"), {
            paddingHorizontal: 16,
            xstyle: i.root,
            children: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogMetaTextItem.react", ["CometColumnItem.react", "TetraText.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.meta;
        a = a.metaPosition;
        a = a === void 0 ? "above" : a;
        var d = b != null && a === "above";
        a = b != null && a === "below";
        return h.jsx(c("CometColumnItem.react"), {
            align: "start",
            paddingTop: a ? 0 : 12,
            paddingVertical: a ? 16 : 0,
            children: h.jsx(c("TetraText.react"), {
                align: d ? "start" : "center",
                color: "secondary",
                type: "body3",
                children: b
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("requireDeferredForDisplay", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("requireDeferred").call(null, a)
    }
    g["default"] = a
}), 98);
__d("CometTooltipImpl.react", ["CometPlaceholder.react", "deferredLoadComponent", "react", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = c("deferredLoadComponent")(c("requireDeferredForDisplay")("CometTooltipDeferredImpl.react").__setRef("CometTooltipImpl.react"));

    function a(a) {
        return h.jsx(c("CometPlaceholder.react"), {
            fallback: null,
            children: h.jsx(i, babelHelpers["extends"]({}, a))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometTooltip.react", ["BaseTooltip.react", "CometTooltipImpl.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.delayMs;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["delayMs"]);
        return h.jsx(c("BaseTooltip.react"), babelHelpers["extends"]({}, a, {
            delayTooltipMs: b,
            tooltipImpl: c("CometTooltipImpl.react")
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometTheme", ["BaseThemeDisplayModeContext", "react", "useCurrentDisplayMode"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo,
        j = {
            dark: "__fb-dark-mode ",
            light: "__fb-light-mode "
        };

    function a(a) {
        var b = c("useCurrentDisplayMode")(),
            d;
        a === "invert" ? d = b === "light" ? "dark" : "light" : d = a;
        b = i(function() {
            return function(a) {
                a = a.children;
                return h.jsx(c("BaseThemeDisplayModeContext").Provider, {
                    value: d,
                    children: a
                })
            }
        }, [d]);
        return [b, {
            theme: j[d]
        }]
    }
    g["default"] = a
}), 98);
__d("TetraButton.react", ["BaseStyledButton.react", "CometGHLRenderingContext", "CometIcon.react", "CometTooltip.react", "TetraText.react", "isBlueprintStylesEnabled", "mergeRefs", "react", "useCometTheme"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useRef,
        k = {
            contentDisabled: {
                opacity: "xuzhngd"
            },
            darkOverlay: {
                backgroundColor: "x18l40ae",
                color: "x14ctfv"
            },
            darkOverlayPressed: {
                backgroundColor: "x1lxk4cn"
            },
            disabled: {
                backgroundColor: "xwcfey6"
            },
            fdsOverrideBlack: {
                backgroundColor: "xal61yo"
            },
            fdsOverrideCollaborativePostCTA: {
                backgroundColor: "x14hiurz",
                mixBlendMode: "x1nor908"
            },
            fdsOverrideNegative: {
                backgroundColor: "x1ciooss"
            },
            fdsOverridePositive: {
                backgroundColor: "xv9rvxn"
            },
            overlay: {
                backgroundColor: "x14hiurz"
            },
            overlayDeemphasized: {
                backgroundColor: "x1f2gare"
            },
            overlayDeemphasizedOverlayPressed: {
                backgroundColor: "x1f2gare"
            },
            overlayDisabled: {
                backgroundColor: "x1ahlmzr"
            },
            overlayOverlayPressed: {
                backgroundColor: "xiwuv7k"
            },
            paddingIconOnly: {
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13"
            },
            primary: {
                backgroundColor: "xtvsq51"
            },
            primaryDeemphasized: {
                backgroundColor: "x1hr4nm9"
            },
            primaryDeemphasizedOverlayPressed: {
                backgroundColor: "x18z898i"
            },
            primaryOverlayPressed: {
                backgroundColor: "x1iutvsz"
            },
            secondary: {
                backgroundColor: "x1qhmfi1"
            },
            secondaryDeemphasized: {
                backgroundColor: "xjbqb8w"
            },
            secondaryDeemphasizedOverlayPressed: {
                backgroundColor: "x18z898i"
            },
            secondaryOverlayPressed: {
                backgroundColor: "x1iutvsz"
            },
            sizeLarge: {
                height: "x1fq8qgq"
            },
            sizeMedium: {
                height: "x1r1pt67"
            }
        },
        l = {
            sizeLarge: {
                borderTopStartRadius: "x4dbc",
                borderTopEndRadius: "x1y9341w",
                borderBottomEndRadius: "x197fjye",
                borderBottomStartRadius: "xjufhxy",
                height: "x1whk3tm"
            },
            sizeMedium: {
                borderTopStartRadius: "xeqyu0i",
                borderTopEndRadius: "x1grejt4",
                borderBottomEndRadius: "x1xrrxpe",
                borderBottomStartRadius: "x17se2pc",
                height: "xfumdyt"
            }
        },
        m = {
            ":deemphasized": {
                iconColor: "highlight",
                overlayPressedStyle: k.primaryDeemphasizedOverlayPressed,
                textColor: "highlight"
            },
            ":disabled": {
                iconColor: "disabled",
                textColor: "disabled"
            },
            iconColor: "white",
            overlayPressedStyle: k.primaryOverlayPressed,
            textColor: "white"
        },
        n = {
            ":deemphasized": {
                iconColor: "highlight",
                overlayPressedStyle: k.secondaryDeemphasizedOverlayPressed,
                textColor: "highlight"
            },
            ":disabled": {
                iconColor: "disabled",
                textColor: "disabled"
            },
            iconColor: "primary",
            overlayPressedStyle: k.secondaryOverlayPressed,
            textColor: "secondary"
        },
        o = {
            ":deemphasized": {
                iconColor: "white",
                overlayPressedStyle: k.overlayDeemphasizedOverlayPressed,
                textColor: "white"
            },
            ":disabled": {
                iconColor: "disabled",
                textColor: "disabled"
            },
            iconColor: "primary",
            overlayPressedStyle: k.overlayOverlayPressed,
            textColor: "primary"
        },
        p = {
            ":deemphasized": {
                iconColor: "white",
                overlayPressedStyle: k.overlayDeemphasizedOverlayPressed,
                textColor: "white"
            },
            ":disabled": {
                iconColor: "disabled",
                textColor: "disabled"
            },
            iconColor: "white",
            overlayPressedStyle: k.darkOverlayPressed,
            textColor: "white"
        };

    function q(a) {
        switch (a) {
            case "fdsOverride_collaborativePostCTA":
            case "secondary":
                return n;
            case "overlay":
                return o;
            case "dark-overlay":
                return p;
            case "primary":
            default:
                return m
        }
    }

    function r(a, b) {
        var c = b.disabled;
        b = b.reduceEmphasis;
        a = q(a);
        return (c ? a[":disabled"] : null) || (b ? a[":deemphasized"] : null) || a
    }

    function a(a, b) {
        var d, e = a.addOnPrimary,
            f = a.addOnSecondary,
            g = a.disabled;
        g = g === void 0 ? !1 : g;
        var m = a.icon,
            n = a.label,
            o = a.labelIsHidden;
        o = o === void 0 ? !1 : o;
        var p = a.linkProps,
            q = a.onFocusIn,
            s = a.onFocusOut,
            t = a.onHoverIn,
            u = a.onHoverOut,
            v = a.onPress,
            w = a.onPressIn,
            x = a.onPressOut,
            y = a.padding;
        y = y === void 0 ? "normal" : y;
        var z = a.reduceEmphasis;
        z = z === void 0 ? !1 : z;
        var A = a.size;
        A = A === void 0 ? "medium" : A;
        var B = a.suppressHydrationWarning;
        B = B === void 0 ? !1 : B;
        var C = a.testid;
        C = a.testOnly_pressed;
        C = C === void 0 ? !1 : C;
        var D = a.tooltip,
            E = a.tooltipPosition;
        E = E === void 0 ? "above" : E;
        var F = a.type;
        F = F === void 0 ? "primary" : F;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["addOnPrimary", "addOnSecondary", "disabled", "icon", "label", "labelIsHidden", "linkProps", "onFocusIn", "onFocusOut", "onHoverIn", "onHoverOut", "onPress", "onPressIn", "onPressOut", "padding", "reduceEmphasis", "size", "suppressHydrationWarning", "testid", "testOnly_pressed", "tooltip", "tooltipPosition", "type"]);
        var G = r(F, {
                disabled: g,
                reduceEmphasis: z
            }),
            H = G.iconColor,
            I = G.overlayPressedStyle;
        G = G.textColor;
        var J = j(null),
            K = c("useCometTheme")("light"),
            L = K[0];
        K = K[1];
        var M = i(c("CometGHLRenderingContext"));
        M = p != null && M;
        d = (d = a["aria-label"]) != null ? d : n;
        M = M ? void 0 : d;
        d = h.jsx(c("BaseStyledButton.react"), babelHelpers["extends"]({}, a, {
            addOnEnd: f,
            addOnStart: e,
            "aria-label": M,
            content: o ? null : h.jsx(c("TetraText.react"), {
                color: G,
                numberOfLines: 1,
                type: A === "large" ? "button1" : "button2",
                children: n
            }),
            contentXstyle: [F === "overlay" && g && k.contentDisabled, F === "overlay" && K, A === "medium" && (c("isBlueprintStylesEnabled")() ? l.sizeMedium : k.sizeMedium), A === "large" && (c("isBlueprintStylesEnabled")() ? l.sizeLarge : k.sizeLarge), m != null && o && k.paddingIconOnly],
            disabled: g,
            icon: m && h.jsx(c("CometIcon.react"), {
                color: H,
                icon: m,
                size: 16
            }),
            linkProps: p,
            onFocusIn: q,
            onFocusOut: s,
            onHoverIn: t,
            onHoverOut: u,
            onPress: v,
            onPressIn: w,
            onPressOut: x,
            overlayPressedStyle: I,
            padding: y,
            ref: c("mergeRefs")(J, b),
            suppressHydrationWarning: B,
            testOnly_pressed: C,
            testid: void 0,
            xstyle: [F === "primary" && k.primary, F === "primary" && z && k.primaryDeemphasized, F === "secondary" && k.secondary, F === "secondary" && z && k.secondaryDeemphasized, F === "fdsOverride_black" && k.fdsOverrideBlack, F === "fdsOverride_negative" && k.fdsOverrideNegative, F === "fdsOverride_positive" && k.fdsOverridePositive, F === "fdsOverride_collaborativePostCTA" && k.fdsOverrideCollaborativePostCTA, F === "overlay" && k.overlay, F === "overlay" && z && k.overlayDeemphasized, g && k.disabled, F === "overlay" && g && k.overlayDisabled, F === "dark-overlay" && k.darkOverlay]
        }));
        a = F === "overlay" ? h.jsx(L, {
            children: d
        }) : d;
        return D != null ? h.jsx(c("CometTooltip.react"), {
            position: E,
            tooltip: D,
            children: a
        }) : a
    }
    a.displayName = a.name + " [from " + f.id + "]";
    e = h.forwardRef(a);
    g["default"] = e
}), 98);
__d("CometDialogConfirmationFooter.react", ["BaseRow.react", "BaseRowItem.react", "CometColumnItem.react", "CometDialogFooterContainer.react", "CometDialogMetaTextItem.react", "TetraButton.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            item: {
                flexBasis: "x1r8uery",
                minWidth: "xl9nvqe",
                "@media (max-width: 679px)": {
                    minWidth: "x17ot9bj"
                }
            },
            secondary: {
                paddingEnd: "x1sxyh0"
            }
        };

    function a(a) {
        var b = a.meta,
            d = a.primary,
            e = a.secondary;
        a = a.size;
        a = a === void 0 ? "medium" : a;
        return h.jsxs(c("CometDialogFooterContainer.react"), {
            children: [b != null && h.jsx(c("CometDialogMetaTextItem.react"), {
                meta: b
            }), h.jsx(c("CometColumnItem.react"), {
                paddingVertical: 16,
                children: h.jsxs(c("BaseRow.react"), {
                    align: "end",
                    direction: "backward",
                    verticalAlign: "stretch",
                    wrap: "forward",
                    children: [h.jsx(c("BaseRowItem.react"), {
                        xstyle: i.item,
                        children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, d, {
                            padding: "wide",
                            size: a
                        }))
                    }), h.jsx(c("BaseRowItem.react"), {
                        xstyle: [i.item, i.secondary],
                        children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({
                            reduceEmphasis: !0,
                            type: "secondary"
                        }, e, {
                            size: a
                        }))
                    })]
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogFooterSingleButtonItem.react", ["BaseRow.react", "BaseRowItem.react", "CometColumnItem.react", "TetraButton.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            item: {
                flexBasis: "x1r8uery",
                minWidth: "xl9nvqe",
                "@media (max-width: 679px)": {
                    minWidth: "xwfmwtl"
                }
            }
        };

    function a(a) {
        var b = a.expanding;
        b = b === void 0 ? !0 : b;
        var d = a.primary;
        a = a.size;
        a = a === void 0 ? "medium" : a;
        return h.jsx(c("CometColumnItem.react"), {
            paddingVertical: 16,
            children: h.jsx(c("BaseRow.react"), {
                align: "end",
                direction: "backward",
                verticalAlign: "stretch",
                wrap: "forward",
                children: h.jsx(c("BaseRowItem.react"), {
                    expanding: b,
                    xstyle: i.item,
                    children: h.jsx(c("TetraButton.react"), babelHelpers["extends"]({}, d, {
                        padding: "wide",
                        size: a
                    }))
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogFooter.react", ["CometDialogFooterContainer.react", "CometDialogFooterSingleButtonItem.react", "CometDialogMetaTextItem.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.expanding,
            d = a.meta,
            e = a.metaPosition;
        e = e === void 0 ? "above" : e;
        var f = a.primary;
        a = a.size;
        var g = d != null && e === "above",
            i = d != null && e === "below";
        return h.jsxs(c("CometDialogFooterContainer.react"), {
            children: [g && h.jsx(c("CometDialogMetaTextItem.react"), {
                meta: d,
                metaPosition: e
            }), h.jsx(c("CometDialogFooterSingleButtonItem.react"), {
                expanding: b,
                primary: f,
                size: a
            }), i && h.jsx(c("CometDialogMetaTextItem.react"), {
                meta: d,
                metaPosition: e
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogLoadingStateHeader.react", ["fbt", "BaseDivider.react", "CometCircleButton.react", "CrossFilled24.svg.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        return i.jsxs(i.Fragment, {
            children: [i.jsx("div", {
                className: "x1n2onr6 x879a55 x1d52u69 xktsk01 x13a6bvl x2lah0s x78zum5 x6s0dn4",
                id: a.id,
                children: i.jsx(c("CometCircleButton.react"), {
                    icon: c("CrossFilled24.svg.react"),
                    label: h._("Close"),
                    onPress: a.onClose,
                    size: 36,
                    testid: void 0
                })
            }), i.jsx(c("BaseDivider.react"), {})]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogLoadingState.react", ["fbt", "CometDialog.react", "CometDialogLoadingStateContext", "CometDialogLoadingStateHeader.react", "CometDialogLoadingStateImpl.react", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.id;
        a = a.onClose;
        return i.jsx(c("CometDialogLoadingStateContext").Provider, {
            value: !0,
            children: i.jsx(c("CometDialog.react"), {
                footer: null,
                header: i.jsx(c("CometDialogLoadingStateHeader.react"), {
                    id: b,
                    onClose: a
                }),
                label: h._("Loading..."),
                onClose: a,
                children: i.jsx(c("CometDialogLoadingStateImpl.react"), {})
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometDialogContext", ["FBLogger", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");

    function a() {
        c("FBLogger")("comet_ui").blameToPreviousFrame().mustfix("Attempted to imperatively render a dialog without CometTransientDialogProvider in the tree. This is not allowed. Please add a CometTransientDialogProvider to render a dialog (https://fburl.com/dialog-provider).")
    }
    e = b.createContext(a);
    g["default"] = e
}), 98);
__d("CometSuspendedDialogImpl.react", ["CometPlaceholder.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.dialog,
            d = a.dialogProps,
            e = a.fallback,
            f = a.onClose;
        a = a.onHide;
        return h.jsx(c("CometPlaceholder.react"), {
            fallback: e(f),
            children: h.jsx(b, babelHelpers["extends"]({}, d, {
                onClose: f,
                onHide: a
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useCometDeferredDialog", ["CometDialogContext", "CometDialogLoadingState.react", "CometSuspendedDialogImpl.react", "deferredLoadComponent", "react", "tracePolicyFromResource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = c("react"),
        i = b.useCallback,
        j = b.useContext,
        k = function(a) {
            return h.jsx(c("CometDialogLoadingState.react"), {
                onClose: a
            })
        };

    function a(a, b) {
        var d = j(c("CometDialogContext"));
        return i(function(e, f) {
            var g = c("deferredLoadComponent")(a);
            d(c("CometSuspendedDialogImpl.react"), {
                dialog: g,
                dialogProps: babelHelpers["extends"]({}, e, {
                    loadImmediately: !0
                }),
                fallback: (g = b) != null ? g : k
            }, {
                loadType: "deferred",
                tracePolicy: c("tracePolicyFromResource")("comet.dialog", a)
            }, f)
        }, [d, a, b])
    }
    g["default"] = a
}), 98);
__d("CometRelayQueryProfiler", ["InteractionTracing", "emptyFunction", "performanceNow", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        if (!b) return c("emptyFunction");
        var d = c("performanceNow")();
        return function(a) {
            var e = {
                usedCache: b.usedCache,
                usedPrefetcher: b.usedPrefetcher
            };
            a && (e.error = a.message);
            c("InteractionTracing").getPendingInteractions().forEach(function(a) {
                a.addSubspan("Relay_" + b.queryName, "RelayQuery", d, c("performanceNow")(), e)
            })
        }
    }
    var i = !1;

    function a() {
        if (i) return;
        d("relay-runtime").RelayProfiler.attachProfileHandler("fetchRelayQuery", h);
        i = !0
    }
    g.install = a
}), 98);
__d("RelayFBCometMutations", ["recoverableViolation", "relay-runtime", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 1;

    function a(a) {
        return function(b, e) {
            var f = e.variables.input || {},
                g = f.actor_id,
                i = f.client_mutation_id;
            f = babelHelpers.objectWithoutPropertiesLoose(f, ["actor_id", "client_mutation_id"]);
            c("warning")(i == null, "RelayFBCometMutations: Found `client_mutation_id` in mutation input`. In the Facebook context, `client_mutation_id` and `actor_id` are added automatically.");
            var j;
            b.options != null && b.options.actorID != null && typeof b.options.actorID === "string" ? j = b.options.actorID : c("recoverableViolation")("RelayFBCometMutations: Expected a non-nullable string actorID to be set on the Relay environment. https://fburl.com/wiki/m19zmtlh", "relay");
            if (g != null && g !== j) {
                var k = d("relay-runtime").getRequest(e.mutation);
                k = k.params.name;
                c("recoverableViolation")('You passed an actor_id parameter "' + g + '" to mutation "' + k + '", but the parameter was overridden by the actor_id "' + ((k = j) != null ? k : "") + '" defined in the ActorContext that wraps your React tree. Update your code to avoid passing the actor_id parameter to your mutation.', "relay");
                j = g
            }
            g = babelHelpers["extends"]({}, e.variables, {
                input: babelHelpers["extends"]({}, f, {
                    actor_id: j,
                    client_mutation_id: (k = i) != null ? k : "" + h++
                })
            });
            return a(b, {
                configs: e.configs,
                mutation: e.mutation,
                onCompleted: e.onCompleted,
                onError: e.onError,
                optimisticResponse: e.optimisticResponse,
                optimisticUpdater: e.optimisticUpdater,
                updater: e.updater,
                uploadables: e.uploadables,
                variables: g
            })
        }
    }
    g.addFBisms = a
}), 98);
__d("react-relay/relay-hooks/MatchContainer", ["react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react"),
        i = h.useMemo;

    function a(a) {
        var b = a.fallback,
            c = a.loader,
            d = a.match;
        a = a.props;
        if (d != null && typeof d !== "object") throw new Error("MatchContainer: Expected `match` value to be an object or null/undefined.");
        d = (d = d) != null ? d : {};
        var e = d.__id,
            f = d.__fragments,
            g = d.__fragmentOwner,
            j = d.__fragmentPropName;
        d = d.__module_component;
        if (g != null && typeof g !== "object" || j != null && typeof j !== "string" || f != null && typeof f !== "object" || e != null && typeof e !== "string") throw new Error("MatchContainer: Invalid 'match' value, expected an object that has a '...SomeFragment' spread.");
        c = d != null ? c(d) : null;
        d = i(function() {
            if (j != null && e != null && f != null) {
                var a = {};
                a[j] = {
                    __id: e,
                    __fragments: f,
                    __fragmentOwner: g
                };
                return a
            }
            return null
        }, [e, f, g, j]);
        if (c != null && d != null) return h.jsx(c, babelHelpers["extends"]({}, a, d));
        else {
            return (c = b) != null ? c : null
        }
    }
    a.displayName = a.name + " [from " + e.id + "]";
    e.exports = a
}), null);
__d("RelayFBMatchContainer", ["RelayFBModuleLoader", "react", "react-relay/relay-hooks/MatchContainer"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.fallback,
            e = a.match;
        a = a.props;
        return h.jsx(c("react-relay/relay-hooks/MatchContainer"), {
            fallback: b,
            loader: d("RelayFBModuleLoader").read,
            match: e,
            props: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("RelayFBModuleResource", ["Promise", "RelayFBModuleLoader", "isPromise", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function i(a) {
        if (a === null || typeof a !== "object") throw c("unrecoverableViolation")("ModuleResource.read(): Expected `match` value to be an object.", "relay");
        a = a.__module_component;
        return a == null ? null : d("RelayFBModuleLoader").read(a)
    }

    function a(a) {
        var d = [],
            e = [];
        for (var f = 0; f < a.length; f++) try {
            var g = i(a[f]);
            d.push(g)
        } catch (a) {
            if (c("isPromise")(a)) e.push(a);
            else throw a
        }
        if (e.length > 0) {
            g = a.map(function(a, b) {
                return (a = j(a)) != null ? a : "UNKNOWN_" + b
            });
            var k = g.join(":");
            f = h[k];
            f == null && (f = h[k] = b("Promise").all(e)["finally"](function() {
                delete h[k]
            }));
            throw f
        }
        return d
    }

    function j(a) {
        if (a === null || typeof a !== "object") throw c("unrecoverableViolation")("ModuleResource.getModuleId(): Expected `match` value to be an object.", "relay");
        a = a.__module_component;
        if (a == null) return null;
        a = d("RelayFBModuleLoader").getModuleReference(a);
        return a.getModuleId()
    }
    g.read = i;
    g.readAll = a;
    g.getModuleId = j
}), 98);
__d("useFragmentNodes_DEPRECATED", ["mapObject", "react", "react-relay/relay-hooks/FragmentResource", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime", "useUnsafeRef_DEPRECATED", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef,
        j = b.useState;

    function a(a, b, e) {
        var f = c("react-relay/relay-hooks/useRelayEnvironment")(),
            g = d("react-relay/relay-hooks/FragmentResource").getFragmentResourceForEnvironment(f),
            m = i(!1),
            n = j(0),
            o = n[1];
        n = l(a, b);
        var p = c("useUnsafeRef_DEPRECATED")(0),
            q = c("useUnsafeRef_DEPRECATED")(0);
        f = k(f);
        n = k(n);
        f = f || n;
        n = j(b);
        var r = n[0];
        n = n[1];
        var s = Object.keys(b).filter(function(b) {
                return !Object.prototype.hasOwnProperty.call(a, b)
            }),
            t = s.some(function(a) {
                return r[a] !== b[a]
            });
        s = s.some(function(a) {
            return !d("relay-runtime").isScalarAndEqual(r[a], b[a])
        });
        s = f || s;
        s && q.current++;
        f && p.current++;
        t && n(b);
        var u = g.readSpec(a, b, e),
            v = i(!0);

        function w() {
            v.current = !0;
            var a = g.checkMissedUpdatesSpec(u);
            a && y()
        }

        function x() {
            v.current = !1
        }

        function y() {
            var a;
            if (m.current === !1 || v.current === !1) return;
            q.current = ((a = q.current) != null ? a : 0) + 1;
            o(function(a) {
                return a + 1
            })
        }
        h(function() {
            m.current = !0;
            var a = g.subscribeSpec(u, y);
            return function() {
                m.current = !1, a.dispose()
            }
        }, [p.current]);
        s = c("mapObject")(u, function(a, b) {
            return a.data
        });
        return {
            data: s,
            disableStoreUpdates: x,
            enableStoreUpdates: w,
            shouldUpdateGeneration: q.current
        }
    }

    function k(a) {
        var b = j(a),
            c = b[0];
        b = b[1];
        c = c !== a;
        c && b(a);
        return c
    }

    function l(a, b) {
        return JSON.stringify(d("relay-runtime").stableCopy(c("mapObject")(a, function(a, c) {
            c = b[c];
            return d("relay-runtime").getFragmentIdentifier(a, c)
        })))
    }
    g["default"] = a
}), 98);
__d("createSuspenseFragmentContainer_DEPRECATED", ["mapObject", "react", "react-relay/assertFragmentMap", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime", "useFragmentNodes_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a, b) {
        var e = a.displayName || a.name || "Unknown",
            f = "RelaySuspenseFragmentContainer(" + e + ")";
        c("react-relay/assertFragmentMap")(e, b);
        e = b;
        var g = c("mapObject")(e, d("relay-runtime").getFragment);

        function j(b, d) {
            var e = c("react-relay/relay-hooks/useRelayEnvironment")(),
                j = i(function() {
                    return {
                        environment: e
                    }
                }, [e]),
                k = c("useFragmentNodes_DEPRECATED")(g, b, f),
                l = k.data;
            k = k.shouldUpdateGeneration;
            return i(function() {
                var c;
                return h.jsx(a, babelHelpers["extends"]({}, b, l, {
                    ref: (c = b.componentRef) != null ? c : d,
                    relay: j
                }))
            }, [k, d])
        }
        j.displayName = f;
        b = h.forwardRef(j);
        return b
    }
    g["default"] = a
}), 98);
__d("createSuspensePaginationContainer_DEPRECATED", ["areEqual", "createSuspenseFragmentContainer_DEPRECATED", "forEachObject", "mapObject", "react", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime", "unrecoverableViolation", "warning"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useMemo,
        l = b.useReducer,
        m = b.useRef,
        n = "forward";

    function a(a, b, e) {
        var f = a.displayName || a.name || "Unknown",
            g = c("mapObject")(b, d("relay-runtime").getFragment),
            h = r(g),
            i = d("relay-runtime").getRequest(e.query);
        h = p(a, f, h.direction, s(h), e.getVariables);
        h = c("createSuspenseFragmentContainer_DEPRECATED")(h, b);
        return o(a, f, g, e.getFragmentRefsFromResponse, i, h)
    }

    function o(a, b, e, f, g, k) {
        var n = "RelaySuspensePaginationContainer(" + b + ")";
        a = function(a, b) {
            var o = c("react-relay/relay-hooks/useRelayEnvironment")(),
                p = {};
            c("forEachObject")(e, function(b, c) {
                b = d("relay-runtime").getSelector(b, a[c]);
                b = b != null && b.kind === "PluralReaderSelector" ? (c = (c = b.selectors[0]) == null ? void 0 : c.owner.variables) != null ? c : {} : (c = b == null ? void 0 : b.owner.variables) != null ? c : {};
                p = babelHelpers["extends"]({}, p, b)
            });
            var r = d("relay-runtime").getDataIDsFromObject(e, a),
                s = l(q, {
                    dataIDs: r,
                    mirroredEnvironment: o,
                    mirroredParentVariables: p,
                    refetchFragmentRefs: {},
                    refetchVariables: null
                }),
                t = s[0],
                u = s[1],
                v = m(!1),
                w = m(null),
                x = function() {
                    w.current && (w.current.dispose(), w.current = null)
                };
            j(function() {
                return function() {
                    v.current = !0, x()
                }
            }, []);
            (o !== t.mirroredEnvironment || !c("areEqual")(p, t.mirroredParentVariables) || !c("areEqual")(t.dataIDs, r)) && (x(), u({
                dataIDs: r,
                environment: o,
                parentVariables: p,
                type: "reset"
            }));
            s = i(function(a, b) {
                if (v.current === !0) {
                    c("warning")(!1, "Relay: Unexpected fetch on unmounted component `%s`. It looks like some instances of your container still trying to fetch data but they already unmounted. Please make sure you clear all timers, intervals, async calls, etc that may trigger a fetch.", n);
                    return null
                }
                a = d("relay-runtime").__internal.getOperationVariables(g.operation, g.params.providedVariables, a);
                var e = b && b.force ? {
                        force: !0
                    } : {},
                    h = d("relay-runtime").createOperationDescriptor(g, a, e),
                    i = null,
                    j = o.retain(h),
                    k = {
                        dispose: function() {
                            var a = i;
                            i = null;
                            a && a.unsubscribe();
                            j.dispose()
                        }
                    };
                e = function() {
                    var a = {
                        complete: function() {
                            x(), u({
                                type: "complete"
                            }), b && b.onComplete && b.onComplete(null)
                        },
                        error: function(a) {
                            function b(b) {
                                return a.apply(this, arguments)
                            }
                            b.toString = function() {
                                return a.toString()
                            };
                            return b
                        }(function(a) {
                            x(), u({
                                type: "abort"
                            }), b && b.onComplete && b.onComplete(a)
                        }),
                        next: function() {
                            var a = o.lookup(h.fragment);
                            u({
                                fragmentRefs: f(a.data),
                                type: "next"
                            })
                        },
                        unsubscribe: function() {
                            if (v.current === !0) return;
                            x();
                            u({
                                type: "abort"
                            })
                        }
                    };
                    i = d("relay-runtime").__internal.fetchQuery(o, h).subscribe(a);
                    return k
                };
                x();
                w.current = e();
                u({
                    refetchVariables: a,
                    type: "fetch"
                });
                return k
            }, [o]);
            return h.jsx(k, babelHelpers["extends"]({}, a, t.refetchFragmentRefs, {
                forwardedRef: b,
                isLoading: w.current != null,
                parentVariables: (r = t.refetchVariables) != null ? r : p,
                refetch: s
            }))
        };
        a.displayName = n;
        b = h.forwardRef(a);
        return b
    }

    function p(a, b, e, f, g) {
        return function(j) {
            var l, m = j.forwardedRef,
                o = j.isLoading,
                p = j.parentVariables,
                q = j.refetch;
            j.relay;
            var r = babelHelpers.objectWithoutPropertiesLoose(j, ["forwardedRef", "isLoading", "parentVariables", "refetch", "relay"]),
                s = c("react-relay/relay-hooks/useRelayEnvironment")();
            j = f(r);
            var u = t(b, e, j),
                v = i(function(a, b) {
                    if (u == null || !u.hasMore) {
                        b && b.onComplete && b.onComplete(null);
                        return null
                    }
                    var f = d("relay-runtime").ConnectionInterface.get(),
                        h = f.END_CURSOR;
                    f = f.START_CURSOR;
                    var i = u.cursor;
                    c("warning")(i, "Relay: Cannot `loadMore` without valid `%s` (got `%s`)", e === n ? h : f, i);
                    return q(g(r, {
                        count: a,
                        cursor: i
                    }, p), b)
                }, [u, q, r, p]),
                w = i(function(a, b, c) {
                    return q(g(r, {
                        count: a,
                        cursor: null
                    }, babelHelpers["extends"]({}, p, b || {})), babelHelpers["extends"]({}, c, {
                        force: !0
                    }))
                }, [q, r, p]),
                x = !!(u && u.hasMore && u.cursor);
            j = k(function() {
                return {
                    environment: s,
                    hasMore: x,
                    isLoading: o,
                    loadMore: v,
                    refetchConnection: w
                }
            }, [s, x, o, v, w]);
            return h.jsx(a, babelHelpers["extends"]({}, r, {
                ref: (l = r.componentRef) != null ? l : m,
                relay: j
            }))
        }
    }

    function q(a, b) {
        var c;
        switch (b.type) {
            case "reset":
                c = {
                    dataIDs: b.dataIDs,
                    mirroredEnvironment: b.environment,
                    mirroredParentVariables: b.parentVariables,
                    refetchFragmentRefs: {},
                    refetchVariables: null
                };
                break;
            case "fetch":
                c = babelHelpers["extends"]({}, a, {
                    refetchVariables: b.refetchVariables
                });
                break;
            case "abort":
                c = babelHelpers["extends"]({}, a);
                break;
            case "next":
                c = babelHelpers["extends"]({}, a, {
                    refetchFragmentRefs: b.fragmentRefs
                });
                break;
            case "complete":
            default:
                c = babelHelpers["extends"]({}, a);
                break
        }
        return c
    }

    function r(a) {
        var b = null;
        for (var d in a) {
            var e = a[d];
            e = e && e.metadata && e.metadata.connection;
            if (e != null) {
                if (!Array.isArray(e)) throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected metadata to be array, got " + ("`" + typeof e + "` instead."), "relay");
                if (e.length !== 1) throw c("unrecoverableViolation")("SuspensePaginationContainer: Only a single @connection is " + ("supported, `" + d + "` has " + e.length + "."), "relay");
                if (b) throw c("unrecoverableViolation")("SuspensePaginationContainer: Only a single fragment with @connection is supported.", "relay");
                b = babelHelpers["extends"]({}, e[0], {
                    fragmentName: d
                })
            }
        }
        if (b === null) throw c("unrecoverableViolation")("SuspensePaginationContainer: A @connection directive must be present.", "relay");
        return b
    }

    function s(a) {
        var b = a.path;
        if (!b) throw c("unrecoverableViolation")("SuspensePaginationContainer: Unable to synthesize a getConnectionFromProps function.", "relay");
        return function(c) {
            c = c[a.fragmentName];
            for (var d = 0; d < b.length; d++) {
                if (!c || typeof c !== "object") return null;
                c = c[b[d]]
            }
            return c
        }
    }

    function t(a, b, e) {
        if (e == null) return null;
        var f = d("relay-runtime").ConnectionInterface.get(),
            g = f.EDGES,
            h = f.END_CURSOR,
            i = f.HAS_NEXT_PAGE,
            j = f.HAS_PREV_PAGE,
            k = f.PAGE_INFO;
        f = f.START_CURSOR;
        if (typeof e !== "object") throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected `getConnectionFromProps()` in " + ("`" + a + "` to return `null` or a plain object with ") + (g + " and " + k + " properties, got `" + e + "`."), "relay");
        var l = e[g];
        e = e[k];
        if (l == null || e == null) return null;
        if (!Array.isArray(l)) throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected `getConnectionFromProps()` in " + ("`" + a + "` to return an object with " + g + ": Array, got ") + ("`" + l + "`."), "relay");
        if (typeof e !== "object") throw c("unrecoverableViolation")("SuspensePaginationContainer: Expected `getConnectionFromProps()` in " + ("`" + a + "` to return an object with " + k + ": Object, ") + ("got `" + e + "`."), "relay");
        g = b === n ? e[i] : e[j];
        e = b === n ? e[h] : e[f];
        if (typeof g !== "boolean" || l.length !== 0 && e === void 0) {
            c("warning")(!1, "Relay: Cannot paginate without %s fields in `%s`. Be sure to fetch %s (got `%s`) and %s (got `%s`).", k, a, b === n ? i : j, g, b === n ? h : f, e);
            return null
        }
        return {
            cursor: e,
            edgeCount: l.length,
            hasMore: g
        }
    }
    g["default"] = a
}), 98);
__d("createSuspenseQueryRenderer_DEPRECATED", ["react", "react-relay/ReactRelayContext", "react-relay/relay-hooks/useLazyLoadQueryNode", "react-relay/relay-hooks/useMemoOperationDescriptor", "react-relay/relay-hooks/useRelayEnvironment", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react").useMemo;

    function a(a) {
        var b = d("relay-runtime").getRequest(a),
            e = "RelaySuspenseQueryRenderer(" + b.params.name + ")";

        function g(b) {
            var f = b.UNSTABLE_renderPolicy,
                g = b.children,
                k = b.fetchKey,
                l = b.fetchPolicy;
            b = b.variables;
            var m = c("react-relay/relay-hooks/useRelayEnvironment")();
            b = c("react-relay/relay-hooks/useMemoOperationDescriptor")(a, b, {
                force: !0
            });
            var n = i(function() {
                    return j(m)
                }, [m]),
                o = c("react-relay/relay-hooks/useLazyLoadQueryNode")({
                    componentDisplayName: e,
                    fetchKey: k,
                    fetchObservable: d("relay-runtime").__internal.fetchQuery(m, b),
                    fetchPolicy: l,
                    query: b,
                    renderPolicy: f
                });
            return h.jsx(c("react-relay/ReactRelayContext").Provider, {
                value: n,
                children: i(function() {
                    return g(o)
                }, [g, o])
            })
        }
        g.displayName = g.name + " [from " + f.id + "]";
        g.displayName = e;
        return g
    }

    function j(a) {
        return {
            environment: a
        }
    }
    g["default"] = a
}), 98);
__d("isRelayFBLocalEnvironment", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.options != null && a.options.isLocal === !0 ? !0 : !1
    }
    f["default"] = a
}), 66);
__d("react-relay/relay-hooks/useBlockingPaginationFragment", ["invariant", "Promise", "react", "react-relay/relay-hooks/useLoadMoreFunction", "react-relay/relay-hooks/useRefetchableFragmentNode", "react-relay/relay-hooks/useStaticFragmentNodeWarning", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h;
    c = h || b("react");
    var i = c.useCallback,
        j = c.useEffect,
        k = c.useRef,
        l = c.useState,
        m = b("relay-runtime").getFragment,
        n = b("relay-runtime").getFragmentIdentifier,
        o = b("relay-runtime").getPaginationMetadata;

    function a(a, c, d) {
        d === void 0 && (d = "useBlockingPaginationFragment()");
        a = m(a);
        b("react-relay/relay-hooks/useStaticFragmentNodeWarning")(a, "first argument of " + d);
        var e = o(a, d),
            f = e.connectionPathInFragmentData,
            h = e.identifierField,
            j = e.paginationRequest,
            k = e.paginationMetadata;
        e = e.stream;
        e === !1 || g(0, 18372);
        e = b("react-relay/relay-hooks/useRefetchableFragmentNode")(a, c, d);
        c = e.fragmentData;
        var l = e.fragmentRef,
            q = e.refetch,
            r = e.disableStoreUpdates;
        e = e.enableStoreUpdates;
        var s = n(a, l),
            t = p({
                componentDisplayName: d,
                connectionPathInFragmentData: f,
                direction: "backward",
                disableStoreUpdates: r,
                enableStoreUpdates: e,
                fragmentData: c,
                fragmentIdentifier: s,
                fragmentNode: a,
                fragmentRef: l,
                identifierField: h,
                paginationMetadata: k,
                paginationRequest: j
            }),
            u = t[0],
            v = t[1],
            w = t[2];
        t = p({
            componentDisplayName: d,
            connectionPathInFragmentData: f,
            direction: "forward",
            disableStoreUpdates: r,
            enableStoreUpdates: e,
            fragmentData: c,
            fragmentIdentifier: s,
            fragmentNode: a,
            fragmentRef: l,
            identifierField: h,
            paginationMetadata: k,
            paginationRequest: j
        });
        d = t[0];
        f = t[1];
        var x = t[2];
        r = i(function(a, b) {
            x();
            w();
            return q(a, babelHelpers["extends"]({}, b, {
                __environment: void 0
            }))
        }, [x, w, q]);
        return {
            data: c,
            loadNext: d,
            loadPrevious: u,
            hasNext: f,
            hasPrevious: v,
            refetch: r
        }
    }

    function p(a) {
        var c = a.disableStoreUpdates,
            d = a.enableStoreUpdates;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["disableStoreUpdates", "enableStoreUpdates"]);
        var e = l(null),
            f = e[0],
            g = e[1],
            h = k(null),
            i = k(null),
            m = function() {
                i.current != null && (i.current(), i.current = null)
            };
        e = function() {
            m()
        };
        var n = {
            complete: m,
            start: function() {
                c();
                var a = new(b("Promise"))(function(a) {
                    i.current = function() {
                        h.current = null, a()
                    }
                });
                h.current = a;
                g(a)
            },
            next: m,
            error: m
        };
        a = b("react-relay/relay-hooks/useLoadMoreFunction")(babelHelpers["extends"]({}, a, {
            observer: n,
            onReset: e
        }));
        n = a[0];
        e = a[1];
        a = a[2];
        if (f != null && f === h.current) throw f;
        j(function() {
            f !== h.current && d()
        }, [f]);
        return [n, e, a]
    }
    e.exports = a
}), null);
__d("react-relay/relay-hooks/useIsParentQueryActive", ["react-relay/relay-hooks/useIsOperationNodeActive", "react-relay/relay-hooks/useStaticFragmentNodeWarning", "relay-runtime"], (function(a, b, c, d, e, f) {
    "use strict";
    var g = b("relay-runtime").getFragment;

    function a(a, c) {
        a = g(a);
        b("react-relay/relay-hooks/useStaticFragmentNodeWarning")(a, "first argument of useIsParentQueryActive()");
        return b("react-relay/relay-hooks/useIsOperationNodeActive")(a, c)
    }
    e.exports = a
}), null);
__d("CometRelay", ["CometRelayQueryProfiler", "RelayFBCometMutations", "RelayFBEnvironmentActorID", "RelayFBMatchContainer", "RelayFBModuleResource", "RelayFBSubscription", "RelayFlight.hybrid", "configureRelayForWWW", "createSuspenseFragmentContainer_DEPRECATED", "createSuspensePaginationContainer_DEPRECATED", "createSuspenseQueryRenderer_DEPRECATED", "enqueueMutation", "isRelayFBLocalEnvironment", "react", "react-relay/relay-hooks/EntryPointContainer.react", "react-relay/relay-hooks/ProfilerContext", "react-relay/relay-hooks/RelayEnvironmentProvider", "react-relay/relay-hooks/loadEntryPoint", "react-relay/relay-hooks/loadQuery", "react-relay/relay-hooks/useBlockingPaginationFragment", "react-relay/relay-hooks/useEntryPointLoader", "react-relay/relay-hooks/useFragment", "react-relay/relay-hooks/useIsParentQueryActive", "react-relay/relay-hooks/useLazyLoadQuery", "react-relay/relay-hooks/usePaginationFragment", "react-relay/relay-hooks/usePreloadedQuery", "react-relay/relay-hooks/useQueryLoader", "react-relay/relay-hooks/useRefetchableFragment", "react-relay/relay-hooks/useRelayEnvironment", "react-relay/relay-hooks/useSubscribeToInvalidationState", "relay-runtime", "useFBMutation", "useFBSubscription"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;
    a = b("RelayFBEnvironmentActorID").getActorID;
    c = b("enqueueMutation").enqueueMutation;
    g || (g = b("react"));
    d = b("react-relay/relay-hooks/loadQuery").loadQuery;
    f = b("relay-runtime").ConnectionHandler;
    var h = b("relay-runtime").MutationTypes,
        i = b("relay-runtime").RangeOperations,
        j = b("relay-runtime").RelayFeatureFlags,
        k = b("relay-runtime").VIEWER_ID,
        l = b("relay-runtime").applyOptimisticMutation,
        m = b("relay-runtime").commitLocalUpdate,
        n = b("relay-runtime").commitMutation,
        o = b("relay-runtime").createPayloadFor3DField,
        p = b("relay-runtime").fetchQuery,
        q = b("relay-runtime").generateUniqueClientID,
        r = b("relay-runtime").graphql,
        s = b("relay-runtime").readInlineData,
        t = b("relay-runtime").requestSubscription;
    t = b("RelayFBSubscription").addFBisms(t);
    b("configureRelayForWWW")();
    b("RelayFlight.hybrid").isServer_INTERNAL_DO_NOT_USE() || b("CometRelayQueryProfiler").install();
    e.exports = {
        ConnectionHandler: f,
        EntryPointContainer: b("react-relay/relay-hooks/EntryPointContainer.react"),
        MatchContainer: b("RelayFBMatchContainer"),
        ModuleResource: b("RelayFBModuleResource"),
        MutationTypes: h,
        ProfilerContext: b("react-relay/relay-hooks/ProfilerContext"),
        RangeOperations: i,
        RelayEnvironmentProvider: b("react-relay/relay-hooks/RelayEnvironmentProvider"),
        RelayFeatureFlags: j,
        VIEWER_ID: k,
        applyOptimisticMutation: l,
        commitLocalUpdate: m,
        commitMutation: b("RelayFBCometMutations").addFBisms(n),
        createPayloadFor3DField: o,
        createSuspenseFragmentContainer_DEPRECATED: b("createSuspenseFragmentContainer_DEPRECATED"),
        createSuspensePaginationContainer_DEPRECATED: b("createSuspensePaginationContainer_DEPRECATED"),
        createSuspenseQueryRenderer_DEPRECATED: b("createSuspenseQueryRenderer_DEPRECATED"),
        enqueueMutation: b("RelayFBCometMutations").addFBisms(c),
        fetchQuery: p,
        generateUniqueClientID: q,
        getActorID: a,
        graphql: r,
        isLocalEnvironment: b("isRelayFBLocalEnvironment"),
        loadEntryPoint: b("react-relay/relay-hooks/loadEntryPoint"),
        loadQuery: d,
        readInlineData: s,
        requestSubscription: t,
        useBlockingPaginationFragment: b("react-relay/relay-hooks/useBlockingPaginationFragment"),
        useEntryPointLoader: b("react-relay/relay-hooks/useEntryPointLoader"),
        useFragment: b("react-relay/relay-hooks/useFragment"),
        useIsParentQueryActive: b("react-relay/relay-hooks/useIsParentQueryActive"),
        useLazyLoadQuery: b("react-relay/relay-hooks/useLazyLoadQuery"),
        useMutation: b("useFBMutation"),
        usePaginationFragment: b("react-relay/relay-hooks/usePaginationFragment"),
        usePreloadedQuery: b("react-relay/relay-hooks/usePreloadedQuery"),
        useQueryLoader: b("react-relay/relay-hooks/useQueryLoader"),
        useRefetchableFragment: b("react-relay/relay-hooks/useRefetchableFragment"),
        useRelayEnvironment: function() {
            return b("react-relay/relay-hooks/useRelayEnvironment")()
        },
        useSubscribeToInvalidationState: b("react-relay/relay-hooks/useSubscribeToInvalidationState"),
        useSubscription: b("useFBSubscription")
    }
}), null);
__d("createCometRelayEntryPointEnvironmentProvider", ["CometRelayEnvironmentFactory"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        a === void 0 && (a = d("CometRelayEnvironmentFactory").defaultEnvironment);
        var b = function(b) {
            b = b == null ? void 0 : b.actorID;
            return b == null ? a : d("CometRelayEnvironmentFactory").getForActorID(String(b))
        };
        return {
            getEnvironment: b
        }
    }
    g["default"] = a
}), 98);
__d("useCometRelayEntrypointContextualEnvironmentProvider", ["CometRelay", "createCometRelayEntryPointEnvironmentProvider", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;

    function a() {
        var a = d("CometRelay").useRelayEnvironment();
        return h(function() {
            return c("createCometRelayEntryPointEnvironmentProvider")(a)
        }, [a])
    }
    g["default"] = a
}), 98);
__d("useCometEntryPointPrerendererWithQueryTimeoutPrivate", ["CometRelay", "clearTimeout", "justknobx", "react", "requireDeferred", "setTimeout", "stableStringify", "useCometPrerenderer", "useCometRelayEntrypointContextualEnvironmentProvider"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");
    b = d("react");
    var h = b.useCallback,
        i = b.useEffect,
        j = b.useRef,
        k = c("requireDeferred")("CometRelayEF").__setRef("useCometEntryPointPrerendererWithQueryTimeoutPrivate"),
        l = 3e4;

    function a(a, b, e, f) {
        var g = j(null),
            m = c("stableStringify")(b),
            n = j(null),
            o = h(function() {
                if (n.current == null) return;
                c("clearTimeout")(n.current);
                n.current = null
            }, []),
            p = h(function() {
                var a;
                o();
                a = (a = g.current) == null ? void 0 : (a = a.preloadedEntryPoint) == null ? void 0 : a.dispose;
                a && a();
                g.current = null
            }, [o]),
            q = h(function() {
                n.current = c("setTimeout")(function() {
                    p()
                }, l)
            }, [p]);
        i(c("justknobx")._("715") ? function() {
            return p
        } : p, [p]);
        var r = c("useCometRelayEntrypointContextualEnvironmentProvider")(),
            s = h(function() {
                o();
                if (b == null) return;
                if (g.current == null || g.current.entryPoint !== a || g.current.preloadParamsHash !== m) {
                    p();
                    g.current = {
                        entryPoint: a,
                        preloadedEntryPoint: d("CometRelay").loadEntryPoint(r, a, b),
                        preloadParamsHash: m
                    };
                    var c = k.getModuleIfRequireable();
                    c && a && c.fetchPredictedResources(a, b)
                }
                return (c = g.current) == null ? void 0 : c.preloadedEntryPoint
            }, [o, a, p, r, m]),
            t = h(function() {
                var c = k.getModuleIfRequireable();
                b && c && c.fetchPredictions(a, b);
                a.root.preload();
                Boolean(f == null ? void 0 : f.queryIsCheap_DO_NOT_USE_OR_YOU_WILL_BE_FIRED) && s()
            }, [a, f == null ? void 0 : f.queryIsCheap_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, b, s]);
        e = c("useCometPrerenderer")(e, !1, t, s, q);
        e[0];
        t = e[1];
        q = e[2];
        var u = e[3];
        e = e[4];
        var v = h(function() {
            var a = s();
            a != null && (g.current = null);
            return a
        }, [s]);
        return [v, {
            onHighIntent: e,
            onHoverIn: t,
            onHoverOut: q,
            onPressIn: u
        }]
    }
    g["default"] = a
}), 98);
__d("useCometEntryPointPrerendererWithQueryTimeout", ["FBLogger", "react", "useCometEntryPointPrerendererWithQueryTimeoutPrivate"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useCallback;

    function a(a, b, d, e) {
        a = c("useCometEntryPointPrerendererWithQueryTimeoutPrivate")(a, b, d, e);
        var f = a[0];
        b = a[1];
        d = b.onHighIntent;
        e = b.onHoverIn;
        a = b.onHoverOut;
        b = b.onPressIn;
        var g = h(function(a, b) {
            var d = f();
            if (d == null) {
                c("FBLogger")("comet_ui").blameToPreviousFrame().mustfix("Unable to present comet page EntryPoint component, preloadParams not set");
                return
            }
            var e = function() {
                b && b.apply(void 0, arguments);
                var a = d == null ? void 0 : d.dispose;
                a && a()
            };
            a(d, e)
        }, [f]);
        return [g, e, a, b, d]
    }
    g["default"] = a
}), 98);
__d("useCometEntryPointDialog", ["CometDialogContext", "CometDialogLoadingState.react", "CometRelay", "CometSuspendedDialogImpl.react", "react", "tracePolicyFromResource", "useCometEntryPointPrerendererWithQueryTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useContext;

    function k(a) {
        var b = a.onClose,
            c = a.onHide,
            e = a.otherProps;
        a = a.preloadedEntryPoint;
        e = babelHelpers["extends"]({}, e, {
            onClose: b,
            onHide: c
        });
        return h.jsx(d("CometRelay").EntryPointContainer, {
            entryPointReference: a,
            props: e
        })
    }
    k.displayName = k.name + " [from " + f.id + "]";
    var l = function(a) {
        return h.jsx(c("CometDialogLoadingState.react"), {
            onClose: a
        })
    };

    function a(a, b, d, e, f) {
        var g = j(c("CometDialogContext")),
            h = k;
        b = c("useCometEntryPointPrerendererWithQueryTimeout")(a, b, d, f);
        var m = b[0];
        f = b[1];
        var n = b[2];
        b = b[3];
        var o = i(function(b, f, i) {
            m(function(f, j) {
                g(c("CometSuspendedDialogImpl.react"), {
                    dialog: h,
                    dialogProps: {
                        otherProps: b,
                        preloadedEntryPoint: f
                    },
                    fallback: (f = e) != null ? f : l
                }, {
                    loadType: "entrypoint",
                    preloadTrigger: d,
                    tracePolicy: (f = i) != null ? f : c("tracePolicyFromResource")("comet.dialog", a.root)
                }, j)
            }, f)
        }, [g, h, a.root, e, d, m]);
        return [o, f, n, b]
    }
    g["default"] = a
}), 98);
__d("CometScrollableArea.react", ["BaseScrollableArea.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a, b) {
        var d = a.horizontal;
        d = d === void 0 ? !0 : d;
        var e = a.id,
            f = a.vertical;
        f = f === void 0 ? !0 : f;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["horizontal", "id", "vertical"]);
        return h.jsx(c("BaseScrollableArea.react"), babelHelpers["extends"]({}, a, {
            horizontal: d,
            id: e,
            ref: b,
            vertical: f
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = h.forwardRef(a);
    g["default"] = b
}), 98);
__d("getTetraTextHierarchyStyle", ["memoizeWithArgs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("memoizeWithArgs")(function(a, b) {
        switch (a) {
            case 1:
                return {
                    bodyType: "body1",
                    headlineType: "headlineEmphasized1",
                    metaType: "meta1"
                };
            case 2:
                return {
                    bodyType: "body2",
                    headlineType: "headlineEmphasized2",
                    metaType: "meta2"
                };
            case 3:
                return {
                    bodyType: "body3",
                    headlineType: b === !0 ? "headline3" : "headlineEmphasized3",
                    metaType: "meta3"
                };
            default:
            case 4:
                return {
                    bodyType: "body4",
                    headlineType: b === !0 ? "headline4" : "headlineEmphasized4",
                    metaType: "meta4"
                };
            case "entityHeader1":
                return {
                    bodyType: "body2",
                    headlineType: "entityHeaderHeadline1",
                    metaType: "entityHeaderMeta1"
                };
            case "entityHeader2":
                return {
                    bodyType: "body2",
                    headlineType: "entityHeaderHeadline2",
                    metaType: "entityHeaderMeta2"
                }
        }
    }, function(a, b) {
        return String(a) + (b === !0 ? "" : "e")
    });
    g["default"] = a
}), 98);
__d("TetraTextPairing.react", ["CometHeadlineWithAddOn.react", "TetraText.react", "getTetraTextHierarchyStyle", "react", "stylex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = {
            item: {
                marginBottom: "xu06os2",
                marginTop: "x1ok221b"
            },
            root: {
                display: "x78zum5",
                flexDirection: "xdt5ytf",
                marginBottom: "xz62fqu",
                marginTop: "x16ldp7u"
            }
        },
        j = {
            1: {
                marginBottom: "x11tup63",
                marginTop: "x16z1lm9"
            },
            2: {
                marginBottom: "x4cne27",
                marginTop: "xifccgj"
            },
            entityHeader1: {
                marginBottom: "x1wsgfga",
                marginTop: "x9otpla"
            },
            entityHeader2: {
                marginBottom: "x1wsgfga",
                marginTop: "x9otpla"
            }
        },
        k = {
            1: {
                marginBottom: "xwoyzhm",
                marginTop: "x1rhet7l"
            },
            2: {
                marginBottom: "xzueoph",
                marginTop: "x1k70j0n"
            },
            entityHeader1: {
                marginBottom: "x1e56ztr",
                marginTop: "x1xmf6yo"
            },
            entityHeader2: {
                marginBottom: "x1e56ztr",
                marginTop: "x1xmf6yo"
            }
        };

    function a(a) {
        var b = a.body,
            d = a.bodyColor;
        d = d === void 0 ? "primary" : d;
        var e = a.bodyLineLimit,
            f = a.bodyRef,
            g = a.headline,
            l = a.headlineAddOn,
            m = a.headlineColor;
        m = m === void 0 ? "primary" : m;
        var n = a.headlineLineLimit,
            o = a.headlineRef,
            p = a.isPrimaryHeading,
            q = a.isSemanticHeading,
            r = a.level,
            s = a.meta,
            t = a.metaColor;
        t = t === void 0 ? "secondary" : t;
        var u = a.metaLineLimit,
            v = a.metaLocation;
        v = v === void 0 ? "below" : v;
        var w = a.metaRef,
            x = a.reduceEmphasis;
        x = x === void 0 ? !1 : x;
        var y = a.testid;
        y = a.textAlign;
        a = y === void 0 ? "start" : y;
        y = c("getTetraTextHierarchyStyle")(r, x);
        x = y.bodyType;
        var z = y.headlineType;
        y = y.metaType;
        var A = c("stylex")(i.item, k[r]);
        l = g != null && h.jsx("div", {
            className: A,
            children: l != null ? h.jsx(c("CometHeadlineWithAddOn.react"), {
                addOn: l,
                color: m,
                headlineRef: o,
                isPrimaryHeading: p,
                isSemanticHeading: q,
                numberOfLines: n,
                type: z,
                children: g
            }) : h.jsx(c("TetraText.react"), {
                align: a,
                color: m,
                isPrimaryHeading: p,
                isSemanticHeading: q,
                numberOfLines: n,
                ref: o,
                type: z,
                children: g
            })
        });
        m = s != null && h.jsx("div", {
            className: A,
            children: h.jsx(c("TetraText.react"), {
                align: a,
                color: t,
                isSemanticHeading: !1,
                numberOfLines: u,
                ref: w,
                type: y,
                children: s
            })
        });
        return h.jsxs("div", {
            className: c("stylex")(i.root, j[r]),
            "data-testid": void 0,
            children: [v === "above" && m, l, b != null && h.jsx("div", {
                className: A,
                children: h.jsx(c("TetraText.react"), {
                    align: a,
                    color: d,
                    isSemanticHeading: !1,
                    numberOfLines: e,
                    ref: f,
                    type: x,
                    children: b
                })
            }), v === "below" && m]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("cometPushToast", ["ix", "BaseToasterStateManager", "CometIcon.react", "deferredLoadComponent", "fbicon", "react", "requireDeferred"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = c("BaseToasterStateManager").getInstance(),
        k = c("deferredLoadComponent")(c("requireDeferred")("CometToast.react").__setRef("cometPushToast"));

    function l(a, b, c) {
        b === void 0 && (b = 2750);
        var d = (c = c) != null ? c : j,
            e = d.push(i.jsx(k, babelHelpers["extends"]({}, a, {
                loadImmediately: !0,
                onDismiss: function() {
                    return d.expire(e)
                }
            })), b);
        return e
    }

    function a(a, b) {
        return l({
            message: a
        }, b)
    }

    function b(a, b, e) {
        b === void 0 && (b = 2750);
        return l(babelHelpers["extends"]({}, a, {
            icon: i.jsx(c("CometIcon.react"), {
                color: "warning",
                icon: d("fbicon")._(h("502062"), 20)
            })
        }), b, e)
    }
    g.cometPushToast = l;
    g.cometPushSimpleToast = a;
    g.cometPushErrorToast = b
}), 98);
__d("useTooltipDelayedContent", ["clearTimeout", "react", "setTimeout", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useRef,
        i = b.useState;

    function a(a) {
        var b = a.delayContentMs,
            d = a.isVisible,
            e = h(d),
            f = h(null);
        a = i(function() {
            return d === !0 && e.current === !1 && b > 0
        });
        var g = a[0],
            j = a[1];
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            if (d === !0 && e.current === !1 && b > 0) {
                j(!0);
                f.current = c("setTimeout")(function() {
                    j(!1), f.current = null
                }, b);
                return function() {
                    c("clearTimeout")(f.current), f.current = null
                }
            } else f.current != null && (j(!1), c("clearTimeout")(f.current), f.current = null);
            e.current = d
        }, [b, d, e]);
        return {
            isPending: g
        }
    }
    g["default"] = a
}), 98);
__d("CometTooltipDeferredImpl.react", ["BaseContextualLayer.react", "CometHeroInteractionContextPassthrough.react", "CometPlaceholder.react", "CometProgressRingIndeterminate.react", "TetraTextPairing.react", "react", "stylex", "useCometDisplayTimingTrackerForInteraction", "useCometTheme", "useFadeEffect", "useTooltipDelayedContent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useLayoutEffect,
        j = b.useRef,
        k = {
            container: {
                backgroundColor: "x1h0vfkc",
                borderTopStartRadius: "x1lq5wgf",
                borderTopEndRadius: "xgqcy7u",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                boxShadow: "x152obne",
                display: "x1lliihq",
                marginBottom: "xjpr12u",
                marginTop: "xr9ek0c",
                maxWidth: "x86nfjv",
                opacity: "xg01cxk",
                paddingTop: "xz9dl7a",
                paddingEnd: "xn6708d",
                paddingBottom: "xsag5q8",
                paddingStart: "x1ye3gou",
                position: "x1n2onr6",
                transitionDuration: "x1ebt8du",
                transitionProperty: "x19991ni",
                transitionTimingFunction: "x1dhq9h"
            },
            containerVisible: {
                opacity: "x1hc1fzr",
                transitionDuration: "xhb22t3",
                transitionTimingFunction: "xls3em1"
            },
            contextualLayer: {
                pointerEvents: "x47corl"
            },
            loadingState: {
                display: "x78zum5",
                justifyContent: "xl56j7k"
            }
        };

    function l(a) {
        var b = a.contextualLayerRef;
        i(function() {
            var a = b.current;
            a && a.reposition({
                autoflip: !0
            })
        }, [b]);
        return null
    }

    function a(a) {
        var b = a.contentKey,
            d = a.delayContentMs;
        d = d === void 0 ? 0 : d;
        var e = a.headline,
            f = a.id,
            g = a.isVisible,
            i = a.tooltip,
            m = a.tooltipTheme;
        m = m === void 0 ? "invert" : m;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["contentKey", "delayContentMs", "headline", "id", "isVisible", "tooltip", "tooltipTheme"]);
        var n = j(null),
            o = c("useFadeEffect")(g),
            p = o[0],
            q = o[1];
        o = o[2];
        var r = c("useCometDisplayTimingTrackerForInteraction")("ToolTip");
        d = c("useTooltipDelayedContent")({
            delayContentMs: d,
            isVisible: g
        });
        g = d.isPending;
        d = c("useCometTheme")(m);
        m = d[0];
        d = d[1];
        if (i == null || !p) return null;
        p = h.jsx("div", {
            className: c("stylex")(k.loadingState),
            children: h.jsx(c("CometProgressRingIndeterminate.react"), {
                color: "dark",
                size: 20
            })
        });
        return h.jsx(c("CometHeroInteractionContextPassthrough.react"), {
            clear: !0,
            children: h.jsx(c("BaseContextualLayer.react"), babelHelpers["extends"]({
                align: "middle"
            }, a, {
                imperativeRef: n,
                ref: r,
                xstyle: k.contextualLayer,
                children: h.jsx(m, {
                    children: h.jsx("span", {
                        className: c("stylex")(d, k.container, q && k.containerVisible),
                        "data-testid": void 0,
                        id: f,
                        ref: o,
                        role: "tooltip",
                        children: h.jsx(c("TetraTextPairing.react"), {
                            body: g ? p : h.jsxs(c("CometPlaceholder.react"), {
                                fallback: p,
                                children: [h.jsx(l, {
                                    contextualLayerRef: n
                                }), i]
                            }, b),
                            bodyColor: "primary",
                            headline: e,
                            headlineColor: "primary",
                            level: 4
                        })
                    })
                })
            }))
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useIsCalledDuringRender", ["FBLogger", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = d("react").useCallback;

    function a() {
        var a;
        return h(function() {
            c("FBLogger")("comet_ui").blameToPreviousFrame().warn("useIsCalledDuringRender should only be used for development purpose. It is implemented in a way that will not work correctly in production.");
            return !1
        }, [a])
    }
    g["default"] = a
}), 98);
__d("CometErrorOverlay", ["ReactDOMComet", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    d("react");

    function h() {
        var a = document.body;
        if (a == null) return null;
        var b = document.createElement("div");
        a.appendChild(b);
        return b
    }

    function a(a) {
        var b = h();
        if (b != null) {
            var c = function() {
                    window.setTimeout(function() {
                        e.unmount(), b.remove()
                    }, 0)
                },
                e = d("ReactDOMComet").createRoot(b, {
                    unstable_concurrentUpdatesByDefault: !0,
                    unstable_strictMode: !0
                });
            a = a(c);
            e.render(a);
            return c
        }
    }
    g.injectComponent = a
}), 98);
__d("useToggle", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useState;

    function a(a) {
        a === void 0 && (a = !1);
        a = i(a);
        var b = a[0],
            c = a[1];
        a = h(function(a) {
            c(a == null ? function(a) {
                return !a
            } : a)
        }, []);
        return [b, a]
    }
    g["default"] = a
}), 98);
__d("CometExceptionDialog.react", ["fbt", "BaseModal.react", "CometColumn.react", "CometColumnItem.react", "CometDialog.react", "CometDialogConfirmationFooter.react", "CometDialogFooter.react", "CometDialogHeader.react", "TetraText.react", "react", "useToggle"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");

    function a(a) {
        var b = a.closeButtonText,
            d = a.debugInfo,
            e = a.errorDescription,
            f = a.errorSummary,
            g = a.onClose;
        a = a.testid;
        a = c("useToggle")(!1);
        var j = a[0],
            k = a[1];
        b = {
            label: (a = b) != null ? a : h._("OK"),
            onPress: g,
            testid: "comet-exception-dialog-ok-button"
        };
        a = {
            label: "[META ONLY] " + (j ? "Hide" : "Show") + " error details",
            onPress: function() {
                return k()
            },
            reduceEmphasis: !1
        };
        a = d != null ? i.jsx(c("CometDialogConfirmationFooter.react"), {
            primary: b,
            secondary: a
        }) : i.jsx(c("CometDialogFooter.react"), {
            expanding: !1,
            primary: babelHelpers["extends"]({}, b, {
                padding: "wide"
            })
        });
        return i.jsx(c("BaseModal.react"), {
            stackingBehavior: "above-everything",
            children: i.jsx(c("CometDialog.react"), {
                footer: a,
                header: i.jsx(c("CometDialogHeader.react"), {
                    onClose: g,
                    text: f
                }),
                onClose: g,
                testid: void 0,
                children: i.jsx(c("CometColumn.react"), {
                    paddingHorizontal: 16,
                    paddingTop: 20,
                    spacing: 8,
                    children: i.jsx(c("CometColumnItem.react"), {
                        children: i.jsxs(c("TetraText.react"), {
                            color: "secondary",
                            type: "body3",
                            children: [e, d != null && i.jsx("div", {
                                children: j && i.jsx("pre", {
                                    className: "xeaf4i8 x1sln4lm x10b6aqq x1iji9kk x1yrsyyn x1a1m0xk x1o6z2jb x1i1ezom x1otrzb0 xhk9q7s x443n21",
                                    children: d
                                })
                            })]
                        })
                    })
                })
            })
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("ServerHTML.react", ["react"], (function(a, b, c, d, e, f, g) {
    var h = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.elementRef = h.createRef(), b) || babelHelpers.assertThisInitialized(c)
        }
        var c = b.prototype;
        c.render = function() {
            var a = this.props,
                b = a.blob;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["blob"]);
            return typeof b === "string" ? h.jsx("div", babelHelpers["extends"]({}, a, {
                ref: this.elementRef,
                children: b
            })) : h.jsx("div", babelHelpers["extends"]({}, a, {
                ref: this.elementRef,
                dangerouslySetInnerHTML: b
            }))
        };
        return b
    }(h.Component);
    g["default"] = a
}), 98);
__d("UserMismatchExpected", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = !1;

    function a(a) {
        g = a
    }

    function b() {
        return g
    }
    f.setIsUserMismatchExpected = a;
    f.getIsUserMismatchExpected = b
}), 66);
__d("handleErrorCodeBasicSideEffects", ["errorCode", "UserMismatchExpected", "gkx"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a) {
        if (a === 1357032 && d("UserMismatchExpected").getIsUserMismatchExpected() === !0) return !0;
        if (c("gkx")("5606")) {
            if (a === 1357032) {
                window.location.reload(!0);
                return !0
            }
        } else if (a === 1357001 || a === 1357032) {
            window.location.reload(!0);
            return !0
        }
        return !1
    }
    g["default"] = a
}), 98);
__d("handleCometErrorCodeSideEffects", ["errorCode", "fbt", "CometDialogLoadingState.react", "CometErrorOverlay", "CometPlaceholder.react", "OutsideExceptionKeyCommandListener.react", "ServerHTML.react", "deferredLoadComponent", "handleCheckpointRedirect", "handleErrorCodeBasicSideEffects", "react", "requireDeferredForDisplay"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = c("deferredLoadComponent")(c("requireDeferredForDisplay")("CometExceptionDialog.react").__setRef("handleCometErrorCodeSideEffects")),
        l = new Set();

    function m(a) {
        return typeof a === "object" && a != null && Object.prototype.hasOwnProperty.call(a, "__html")
    }

    function n(a, b, e, f) {
        f === void 0 && (f = null);
        var g = e,
            h = b;
        g = j.jsx(c("ServerHTML.react"), {
            blob: g
        });
        m(h) && (h = i._("Something went wrong."));
        d("CometErrorOverlay").injectComponent(function(b) {
            return j.jsx(c("OutsideExceptionKeyCommandListener.react"), {
                children: j.jsx(c("CometPlaceholder.react"), {
                    fallback: j.jsx(c("CometDialogLoadingState.react"), {}),
                    children: j.jsx(k, {
                        debugInfo: f,
                        errorDescription: g,
                        errorSummary: h,
                        onClose: function() {
                            l["delete"](a), b()
                        },
                        testid: void 0
                    })
                })
            })
        })
    }

    function a(a, b, d, e, f, g) {
        e === void 0 && (e = null), f === void 0 && (f = !0), g === void 0 && (g = null), c("handleErrorCodeBasicSideEffects")(a) || (a === 1357053 && e != null ? c("handleCheckpointRedirect")(e) : l.has(a) || (l.add(a), f && n(a, b, d, g)))
    }
    g["default"] = a
}), 98);
__d("FriendingCometFriendRequestSubscriptionHelper", ["gkx", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("FriendingCometFriendRequestConfirmSubscription").__setRef("FriendingCometFriendRequestSubscriptionHelper"),
        i = c("requireDeferred")("FriendingCometFriendRequestReceiveSubscription").__setRef("FriendingCometFriendRequestSubscriptionHelper");

    function a(a, b, d, e) {
        var f, g;

        function j(c) {
            c = c.subscribe;
            f = c(a, b, d, e)
        }

        function k(c) {
            c = c.subscribe;
            g = c(a, b, d, e)
        }
        var l = c("gkx")("3868") ? h.onReadyImmediately(j) : h.onReady(j),
            m = c("gkx")("3868") ? i.onReadyImmediately(k) : i.onReady(k);
        return function() {
            var a;
            c("gkx")("3868") && (l.remove(), m.remove());
            (a = g) == null ? void 0 : a.dispose();
            (a = f) == null ? void 0 : a.dispose()
        }
    }
    g.setupFriendingSubscription = a
}), 98);
__d("useDebouncedComet", ["CometDebounce", "react", "useLayoutEffect_SAFE_FOR_SSR", "useStable"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function a(a, b) {
        var d = i(a);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            d.current = a
        }, [a]);
        var e = c("useStable")(function() {
            return c("CometDebounce")(function() {
                d.current.apply(void 0, arguments)
            }, b)
        });
        h(function() {
            return function() {
                e.reset()
            }
        }, []);
        return e
    }
    g["default"] = a
}), 98);
__d("decodeTrackingNode", ["TrackingNodeConstants"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a.length === 0) return [0];
        var b = function(a, b, e) {
                var c = 0;
                for (var f = b; f < e + b; f += 1) {
                    if (!(f < a.length && a.charCodeAt(f) >= d("TrackingNodeConstants").BASE_CODE_START && a.charCodeAt(f) <= d("TrackingNodeConstants").BASE_CODE_END)) return null;
                    c = c * d("TrackingNodeConstants").BASE_CODE_SIZE + (a.charCodeAt(f) - d("TrackingNodeConstants").BASE_CODE_START)
                }
                return c
            },
            c = function(a, c) {
                if (c >= a.length) return [null, c];
                var e = c,
                    f = null,
                    g = 0;
                switch (a.charCodeAt(0)) {
                    case d("TrackingNodeConstants").ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE:
                        f = b(a, c, 2);
                        g = d("TrackingNodeConstants").TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING;
                        e += 2;
                        break;
                    case d("TrackingNodeConstants").ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE:
                        f = b(a, c, 3);
                        g = d("TrackingNodeConstants").TOTAL_IDS_SUPPORTED_BY_LEGACY_ENCODING + Math.pow(d("TrackingNodeConstants").BASE_CODE_SIZE, 2);
                        e += 3;
                        break;
                    default:
                        return [null, c]
                }
                return f === null ? [null, c] : [g + ((a = f) != null ? a : 0) + 1, e]
            },
            e = a.charCodeAt(0),
            f = 1,
            g = 0,
            h = 0,
            i = 0;
        if ([d("TrackingNodeConstants").ENCODED_STRING_WITH_TWO_SYMBOLS_PREFIX_CODE, d("TrackingNodeConstants").ENCODED_STRING_WITH_THREE_SYMBOLS_PREFIX_CODE].includes(e)) {
            var j;
            c = c(a, f);
            if (c[0] === null) return [0];
            i = (j = c[0]) != null ? j : -1;
            f = c[1]
        } else {
            if (e >= d("TrackingNodeConstants").PREFIX_CODE_START && e <= d("TrackingNodeConstants").PREFIX_CODE_END) {
                if (a.length === 1) return [0];
                h = e - d("TrackingNodeConstants").PREFIX_CODE_START + 1;
                g = a.charCodeAt(1);
                f = 2
            } else h = 0, g = e;
            if (g < d("TrackingNodeConstants").BASE_CODE_START || g > d("TrackingNodeConstants").BASE_CODE_END) return [0];
            i = h * d("TrackingNodeConstants").BASE_CODE_SIZE + (g - d("TrackingNodeConstants").BASE_CODE_START) + 1
        }
        if (a.length > f + 2 && a.charAt(f) === "#" && a.charAt(f + 1) >= "0" && a.charAt(f + 1) <= "9" && a.charAt(f + 2) >= "0" && a.charAt(f + 2) <= "9") return [f + 3, [i, parseInt(a.charAt(f + 1) + a.charAt(f + 2), 10) + 1]];
        return a.length > f && a.charAt(f) >= "0" && a.charAt(f) <= "9" ? [f + 1, [i, parseInt(a.charAt(f), 10) + 1]] : [f, [i]]
    }
    g["default"] = a
}), 98);
__d("getRouteInfoForCometProductAttributionDispatch", ["recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        if (b != null) switch (b) {
            case "rootView":
                return a.main;
            case "hostedView":
                b = a.hosted;
                if (b) return b;
                c("recoverableViolation")("Navigation was dispatched from hostedView, but no hosted route in previous state", "comet_infra");
                break;
            case "pushView":
                b = a.pushViewStack;
                if (b && b.length > 0) {
                    b = b[b.length - 1];
                    b.depth;
                    b.key;
                    b = babelHelpers.objectWithoutPropertiesLoose(b, ["depth", "key"]);
                    return b
                }
                c("recoverableViolation")("Navigation was dispatched from pushView, but no push view route in previous state", "comet_infra");
                break
        }
        return a.main
    }
    g["default"] = a
}), 98);
__d("getTopMostRouteInfo", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.hosted,
            c = a.main;
        a = a.pushViewStack;
        if (a && a.length > 0) {
            a = a[a.length - 1];
            a.depth;
            a.key;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["depth", "key"]);
            return a
        }
        return b ? b : c
    }
    f["default"] = a
}), 66);
__d("CometProductAttribution", ["Random", "WebSession", "decodeTrackingNode", "getRouteInfoForCometProductAttributionDispatch", "getTopMostRouteInfo"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function(a) {
            var b = a.bookmark_id,
                c = a.bookmark_type_name,
                e = a.link_context,
                f = a.tap_point;
            a = a.trace_policy;
            return {
                bookmark_id: b,
                bookmark_type_name: c,
                link_context: e,
                session: d("WebSession").getId(),
                subsession: 1,
                tap_point: f,
                timestamp: Date.now(),
                trace_policy: a
            }
        },
        i = function(a) {
            var b = a.bookmark_id,
                c = a.link_context,
                e = a.rootName,
                f = a.tap_point,
                g = a.tracePolicy;
            a = a.trackingNodes;
            return {
                bookmark_id: b,
                "class": e,
                link_context: c,
                module: g,
                scope_id: Math.floor(d("Random").random() * 1e6),
                tap_point: f,
                tracking_nodes: a,
                ts: Date.now()
            }
        },
        j = function(a) {
            var b = a.productAttributionId;
            a = a.tracePolicy;
            if (typeof b === "string") return b;
            return typeof a === "string" ? "tp-" + a : "missing"
        },
        k = new Set(["create_jewel", "mega_menu", "tap_tabbar", "tap_search_bar", "tap_bookmark", "tap_community_panel_popover", "tap_community_panel_shortcuts", "topnav-link", "logo", "via_notification"]),
        l = function(a) {
            return k.has(a)
        };
    a = function(a, b, c, d, e, f) {
        var g;
        f === void 0 && (f = !1);
        g = (g = c == null ? void 0 : c.route) != null ? g : {};
        g = g.tracePolicy;
        b = typeof b === "string" ? {
            tap_point: b
        } : b != null ? b : {
            tap_point: "unexpected"
        };
        var k = b.bookmark_id != null ? String(b.bookmark_id) : j(a);
        g = h({
            bookmark_id: k,
            bookmark_type_name: (k = b == null ? void 0 : b.bookmark_type_name) != null ? k : "",
            link_context: d,
            tap_point: b.tap_point,
            trace_policy: g != null ? g : (k = a.tracePolicy) != null ? k : "missing"
        });
        a.productAttributionId != null && b.bookmark_id != null && a.productAttributionId !== String(b.bookmark_id) && (g = babelHelpers["extends"]({}, g, {
            route_bookmark_id: a.productAttributionId
        }));
        d = [i({
            bookmark_id: b.bookmark_id != null ? String(b.bookmark_id) : a.productAttributionId,
            link_context: d,
            rootName: a.rootView.resource.getModuleId(),
            tap_point: b.tap_point,
            tracePolicy: (k = a.tracePolicy) != null ? k : "missing",
            trackingNodes: null
        })];
        if (c != null && !l(b.tap_point))
            if (f && c.productAttribution.v2 != null) {
                a = [].concat(c.productAttribution.v2);
                a[0] = d[0];
                d = a
            } else {
                k = c.productAttribution.v2;
                if (k != null) {
                    b = k[0];
                    f = k.slice(1);
                    d = [].concat(d, [babelHelpers["extends"]({}, b, {
                        tracking_nodes: (a = e) != null ? a : null
                    })], f)
                }
                d.length > 10 && (d = [].concat(d.slice(0, 9), [d[d.length - 1]]))
            }
        return {
            0: g,
            v2: d
        }
    };
    var m = function(a) {
            return a.replace(/,;/g, "_")
        },
        n = function(a) {
            return (a = a == null ? void 0 : (a = a.v2) == null ? void 0 : a.map(function(a) {
                var b;
                return [a["class"], a.module, a.tap_point, a.ts.toString(), a.scope_id.toString(), (b = a.bookmark_id) != null ? b : "", ((b = a.tracking_nodes) != null ? b : []).reduce(function(a, b) {
                    b = c("decodeTrackingNode")(b);
                    return b.length === 1 ? a : a.concat(b[1][0])
                }, []).join("#")].map(m).join()
            }).join(";")) != null ? a : ""
        };
    b = function(a) {
        return a != null ? n((a = c("getTopMostRouteInfo")(a())) == null ? void 0 : a.productAttribution) : null
    };
    e = function(a, b) {
        if (a == null) return null;
        a = (a = c("getTopMostRouteInfo")(a())) == null ? void 0 : a.productAttribution.v2;
        if (a == null) return null;
        a.length !== 0 && (a[0].tracking_nodes = b);
        return n({
            v2: a
        })
    };
    g.getProductAttributionEntry = h;
    g.getProductAttributionEntryV2 = i;
    g.getProductAttributionIdFromRoute = j;
    g.isSpecialTapPoint = l;
    g.getProductAttributionFromRoute = a;
    g.filterEntryValue = m;
    g.minifyProductAttributionV2 = n;
    g.getMinifiedTopMostRouteProductAttribution = b;
    g.minifiedNavigationChainWithTrackingNodes = e;
    g.getRouteInfoForDispatch = c("getRouteInfoForCometProductAttributionDispatch")
}), 98);
__d("useHideNotificationsToasts", ["useCometRouterState"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useCometRouterState")();
        if (!a) return !1;
        var b = a.pushViewStack;
        b = b != null ? b[b.length - 1] : a == null ? void 0 : a.main;
        return !!((a = b.route) == null ? void 0 : a.hideNotificationToasts)
    }
    g["default"] = a
}), 98);
__d("CometErrorBoundary.re", ["CometErrorBoundary.react"], (function(a, b, c, d, e, f) {
    a = b("CometErrorBoundary.react");
    f.makeTypeChecked = a;
    c = a;
    f.make = c
}), null);
__d("bs_caml_splice_call", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a, b) {
        var c, d;
        d = b.length;
        var e = [];
        for (c = 0; c < d - 1; ++c) e.push(b[c]);
        b = b[d - 1];
        for (c = 0; c < b.length; ++c) e.push(b[c]);
        return a.apply(null, e)
    };
    b = function(a, b, c) {
        var d, e;
        e = c.length;
        var f = [];
        for (d = 0; d < e - 1; ++d) f.push(c[d]);
        c = c[e - 1];
        for (d = 0; d < c.length; ++d) f.push(c[d]);
        return a[b].apply(a, f)
    };
    f.spliceApply = a;
    f.spliceObjApply = b
}), null);
__d("MWChatStateV2IsOpen.bs", ["bs_caml_option", "bs_caml_splice_call"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, c) {
        a = a !== void 0 ? b("bs_caml_option").valFromOption(a) : void 0;
        return c.openWatermark > b("bs_caml_splice_call").spliceApply(Math.max, [a !== void 0 ? [c.closeWatermark, c.minimizeWatermark, c.clientForcedMinimizeWatermark, a] : [c.closeWatermark, c.minimizeWatermark, c.clientForcedMinimizeWatermark]])
    }
    f.isOpen = a
}), null);
__d("MWCount.bs", ["ODS", "gkx"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {}

    function c(a, c) {
        b("ODS").bumpEntityKey(3185, a, c)
    }
    var g = b("gkx")("1430416") ? c : a;

    function d(a) {
        return g("fanta.load", "total")
    }

    function e(a) {
        return g("fanta.killed", a)
    }

    function h(a) {
        return g("fanta.new_message", "process")
    }

    function i(a) {
        g("fanta.new_message", "process");
        return g("fanta.new_message", "process_new")
    }

    function j(a) {
        g("fanta.new_message", "process");
        return g("fanta.new_message", "process_log")
    }

    function k(a) {
        g("fanta.new_message", "process");
        return g("fanta.new_message", "process_messages_received")
    }
    i = {
        newMessage: i,
        logMessage: j,
        messagesReceived: k
    };

    function l(a) {
        return g("fanta.new_message", "reject")
    }

    function m(a) {
        g("fanta.new_message", "reject");
        return g("fanta.new_message", "reject_old")
    }

    function n(a) {
        g("fanta.new_message", "reject");
        return g("fanta.new_message", "reject_supress")
    }
    j = {
        old: m,
        suppress: n
    };

    function o(a) {
        return g("fanta.new_message", "lift")
    }
    k = {
        $$process: h,
        Process: i,
        reject: l,
        Reject: j,
        lift: o
    };

    function p(a) {
        return g("fanta.cookie.lift", "none")
    }

    function q(a) {
        return g("fanta.cookie.lift", "some")
    }

    function r(a) {
        g("fanta.cookie.lift", "some");
        return g("fanta.cookie.lift", "one")
    }

    function s(a) {
        g("fanta.cookie.lift", "some");
        return g("fanta.cookie.lift", "many")
    }
    m = {
        none: p,
        some: q,
        one: r,
        many: s
    };

    function t(a) {
        return g("fanta.cookie.show", "none")
    }

    function u(a) {
        return g("fanta.cookie.show", "some")
    }

    function v(a) {
        g("fanta.cookie.show", "some");
        return g("fanta.cookie.show", "one")
    }

    function w(a) {
        g("fanta.cookie.show", "some");
        return g("fanta.cookie.show", "many")
    }
    n = {
        none: t,
        some: u,
        one: v,
        many: w
    };
    h = {
        Lift: m,
        Show: n
    };
    i = {
        load: d,
        killed: e,
        NewMessage: k,
        Cookie: h
    };

    function x(a) {
        return g("mwchat.load", "total")
    }

    function y(a) {
        return g("mwchat.new_message", "process")
    }

    function z(a) {
        return g("mwchat.new_message", "reject")
    }

    function A(a) {
        return g("mwchat.new_message", "lift")
    }
    l = {
        $$process: y,
        reject: z,
        lift: A
    };

    function B(a) {
        return g("mwchat.cookie.lift", "none")
    }

    function C(a) {
        return g("mwchat.cookie.lift", "some")
    }

    function D(a) {
        g("mwchat.cookie.lift", "some");
        return g("mwchat.cookie.lift", "one")
    }

    function E(a) {
        g("mwchat.cookie.lift", "some");
        return g("mwchat.cookie.lift", "many")
    }
    j = {
        none: B,
        some: C,
        one: D,
        many: E
    };

    function F(a) {
        return g("mwchat.cookie.show", "none")
    }

    function G(a) {
        return g("mwchat.cookie.show", "some")
    }

    function H(a) {
        g("mwchat.cookie.show", "some");
        return g("mwchat.cookie.show", "one")
    }

    function I(a) {
        g("mwchat.cookie.show", "some");
        return g("mwchat.cookie.show", "many")
    }
    o = {
        none: F,
        some: G,
        one: H,
        many: I
    };
    p = {
        Lift: j,
        Show: o
    };
    q = {
        load: x,
        NewMessage: l,
        Cookie: p
    };
    f.noop = a;
    f.log = c;
    f.bump = g;
    f.Blue = i;
    f.Comet = q
}), null);
__d("MessengerWebEventsFalcoEvent.bs", ["MessengerWebEventsFalcoEvent"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        b("MessengerWebEventsFalcoEvent").log(a)
    }

    function c(a) {
        b("MessengerWebEventsFalcoEvent").logAsync(a)
    }

    function d(a) {
        b("MessengerWebEventsFalcoEvent").logImmediately(a)
    }

    function e(a) {
        b("MessengerWebEventsFalcoEvent").logCritical(a)
    }
    f.log = a;
    f.logAsync = c;
    f.logImmediately = d;
    f.logCritical = e
}), null);
__d("MWChatStateV2Logging.bs", ["MWCount.bs", "MessengerWebEvent", "MessengerWebEventsFalcoEvent.bs", "bs_curry", "react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react");

    function a(a) {
        var c = h.useRef(a);
        h.useEffect(function() {
            var a = Array.from(c.current.tabs.values()),
                d = function(a) {
                    return a.openWatermark > Math.max(a.closeWatermark, a.minimizeWatermark, a.clientForcedMinimizeWatermark)
                },
                e = function(a) {
                    return Math.max(a.minimizeWatermark, a.clientForcedMinimizeWatermark) > Math.max(a.openWatermark, a.closeWatermark)
                },
                f = a.filter(d);
            d = a.filter(e);
            f.length > 0 ? (b("bs_curry")._1(b("MWCount.bs").Comet.Cookie.Lift.one, void 0), b("MessengerWebEventsFalcoEvent.bs").log(function() {
                return {
                    event_name: b("MessengerWebEvent").LOAD_TAB_FROM_COOKIE,
                    extra_data: {
                        tabNumber: f.length
                    }
                }
            })) : b("bs_curry")._1(b("MWCount.bs").Comet.Cookie.Lift.none, void 0);
            d.length > 0 ? b("bs_curry")._1(b("MWCount.bs").Comet.Cookie.Show.some, void 0) : b("bs_curry")._1(b("MWCount.bs").Comet.Cookie.Show.none, void 0)
        }, [c])
    }
    f.useCookieLiftLogging = a
}), null);
__d("BroadcastChannel.bs", ["bs_caml_option"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var c = window.BroadcastChannel;
        if (!(c == null)) return b("bs_caml_option").some(new BroadcastChannel(a))
    }
    f.make = a
}), null);
__d("MWChatStateV2IsClosed.bs", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.closeWatermark > Math.max(a.openWatermark, a.minimizeWatermark, a.clientForcedMinimizeWatermark)
    }
    f.isClosed = a
}), null);
__d("MWChatStateV2IsMinimized.bs", ["MWChatStateV2IsClosed.bs", "MWChatStateV2IsOpen.bs", "bs_caml_option"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, c) {
        a = a !== void 0 ? b("bs_caml_option").valFromOption(a) : void 0;
        if (a !== void 0)
            if (b("MWChatStateV2IsOpen.bs").isOpen(b("bs_caml_option").some(a), c)) return !1;
            else return !b("MWChatStateV2IsClosed.bs").isClosed(c);
        else return Math.max(c.minimizeWatermark, c.clientForcedMinimizeWatermark) > Math.max(c.openWatermark, c.closeWatermark)
    }
    f.isMinimized = a
}), null);
__d("DocumentScrollViewPageOffsetsContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterDispatcherContextFactory.react", ["CometRouterDispatcherContext", "DocumentScrollViewPageOffsetsContext", "filterObject", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useContext,
        j = b.useMemo;

    function a(a) {
        var b = a.actorID,
            d = a.children,
            e = a.from,
            f = a.tracePolicy,
            g = a.url,
            k = i(c("CometRouterDispatcherContext")),
            l = i(c("DocumentScrollViewPageOffsetsContext"));
        k = j(function() {
            var a, d = {
                actorID: b,
                from: e,
                pageOffsets: l,
                tracePolicy: f,
                url: g
            };
            d = c("filterObject")(d, function(a) {
                return a !== void 0
            });
            return (a = k) == null ? void 0 : a.withContext(d)
        }, [b, k, e, l, f, g]);
        return k == null ? d : h.jsx(c("CometRouterDispatcherContext").Provider, {
            value: k,
            children: d
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("useIsMountedRef", ["react", "useLayoutEffect_SAFE_FOR_SSR"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useRef;

    function a() {
        var a = h(!1);
        c("useLayoutEffect_SAFE_FOR_SSR")(function() {
            a.current = !0;
            return function() {
                a.current = !1
            }
        }, []);
        return a
    }
    g["default"] = a
}), 98);
__d("CometTransientDialogProvider.react", ["fbt", "BaseModal.react", "CometDialogContext", "CometErrorBoundary.react", "CometHeroLogging", "CometInteractionTracingQPLConfigContext", "FBLogger", "cometPushToast", "cr:945", "react", "useCometInteractionTracing", "useIsCalledDuringRender", "useIsMountedRef"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    e = d("react");
    var j = e.useCallback,
        k = e.useEffect,
        l = e.useRef,
        m = e.useState;

    function n(a) {
        var b = a.dialogConfig,
            e = a.dialogConfigsRef,
            f = a.displayBaseModal_DO_NOT_USE,
            g = a.removeDialogConfig,
            n = l(null);
        k(function() {
            return function() {
                n.current != null && window.cancelAnimationFrame(n.current)
            }
        }, []);
        a = b.dialog;
        var o = b.dialogProps,
            p = m(!1),
            q = p[0];
        p = p[1];
        var r = j(function() {
                for (var a = arguments.length, d = new Array(a), f = 0; f < a; f++) d[f] = arguments[f];
                n.current != null && window.cancelAnimationFrame(n.current);
                var h = e.current.indexOf(b);
                h < 0 && c("FBLogger")("comet_ui").blameToPreviousFrame().mustfix("Attempting to close a dialog that does not exist anymore.");
                n.current = window.requestAnimationFrame(function() {
                    g(b, d), n.current = null
                })
            }, [b, e, g]),
            s = j(function() {
                r(), d("cometPushToast").cometPushErrorToast({
                    message: h._("Something isn't working. This may be because of a technical error we're working to fix."),
                    truncateText: !1
                })
            }, [r]);
        a = i.jsx(a, babelHelpers["extends"]({}, o, {
            onClose: r,
            onHide: p
        }));
        return i.jsx(c("CometErrorBoundary.react"), {
            onError: s,
            children: f === !0 ? i.jsx(c("BaseModal.react"), {
                hidden: q,
                interactionDesc: b.interactionDesc,
                interactionUUID: b.interactionUUID,
                stackingBehavior: "above-nav",
                children: a
            }) : a
        })
    }
    n.displayName = n.name + " [from " + f.id + "]";

    function a(a) {
        var e = a.displayBaseModal_DO_NOT_USE,
            f = e === void 0 ? !0 : e;
        e = babelHelpers.objectWithoutPropertiesLoose(a, ["displayBaseModal_DO_NOT_USE"]);
        a = m([]);
        var g = a[0],
            h = a[1];
        a = d("CometInteractionTracingQPLConfigContext").useDialogTraceQPLEvent();
        var o = c("useCometInteractionTracing")(a, "fluid", "INTERACTION");
        a = c("useIsCalledDuringRender")();
        a = j(function(a, d, e, f) {
            var g = e.loadType,
                i = e.preloadTrigger,
                j = e.tracePolicy;
            o(function(e) {
                var k = c("CometHeroLogging").genHeroInteractionUUIDAndMarkStart(e.getTraceId());
                e.addMetadata("interaction_type", "dialog");
                e.addMetadata("load_type", g);
                i != null && e.addMetadata("preload_trigger", i);
                var l = "Dialog";
                h(function(b) {
                    return b.concat({
                        dialog: a,
                        dialogProps: d,
                        interactionDesc: l,
                        interactionUUID: k,
                        onClose: f,
                        tracePolicy: j
                    })
                });
                b("cr:945") && b("cr:945").logOpen(j, k)
            }, void 0, void 0, j)
        }, [a, o]);
        var p = l(g);
        k(function() {
            p.current = g
        }, [g]);
        var q = c("useIsMountedRef")(),
            r = j(function(a, c) {
                if (!q.current) return;
                h(function(b) {
                    var c = b.indexOf(a);
                    return c < 0 ? b : b.slice(0, c)
                });
                a.onClose && a.onClose.apply(a, c);
                b("cr:945") && b("cr:945").logClose(a.tracePolicy, a.interactionUUID)
            }, [q]);
        return i.jsxs(c("CometDialogContext").Provider, {
            value: a,
            children: [e.children, g.map(function(a, b) {
                return i.jsx(n, {
                    dialogConfig: a,
                    dialogConfigsRef: p,
                    displayBaseModal_DO_NOT_USE: f,
                    removeDialogConfig: r
                }, b)
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("usePrevious", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useRef;

    function a(a) {
        var b = i(null);
        h(function() {
            b.current = a
        });
        return b.current
    }
    g["default"] = a
}), 98);
__d("Actor", ["CometRelay", "CometRelayEnvironmentFactory", "CometRelayMultiActorEnvironment", "CometRouterDispatcherContextFactory.react", "CometTransientDialogProvider.react", "react", "recoverableViolation", "unrecoverableViolation", "usePrevious"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react"),
        i = d("react"),
        j = i.useContext,
        k = i.useMemo,
        l = i.useState;

    function a(a) {
        return function() {
            throw c("unrecoverableViolation")("You are " + a + " the Actor from a React component that is not a descendent of ActorProvider.", "groups_comet")
        }
    }
    var m = h.createContext({
        get: a("reading"),
        set: a("setting")
    });

    function b(a) {
        var b = a.actorEnvironmentKey_DO_NOT_USE_UNLESS_YOU_KNOW_WHAT_YOU_ARE_DOING,
            e = a.children,
            f = a.initialActorID,
            g = a.readonly,
            i = g === void 0 ? !1 : g;
        g = a.scope;
        a = g === void 0 ? null : g;
        g = l(f);
        var j = g[0],
            n = g[1];
        g = c("usePrevious")(a);
        var o = c("usePrevious")(f);
        b = d("CometRelayEnvironmentFactory").getForActorID(j, b);
        o = o != null && o !== f;
        g = g != null && g !== a;
        (o || g) && j !== f && n(f);
        a = k(function() {
            return {
                get: function() {
                    return j
                },
                set: function(a) {
                    if (i) {
                        c("recoverableViolation")("You tried to update the Actor ID, but the <ActorProvider /> closest to your useActor() call has a read-only Actor ID. To fix this, wrap the React tree that you want to set an Actor ID for with your own <ActorProvider />.", "groups_comet");
                        return
                    }
                    n(a)
                }
            }
        }, [j, i]);
        return h.jsx(m.Provider, {
            value: a,
            children: h.jsx(d("CometRelay").RelayEnvironmentProvider, {
                environment: b,
                getEnvironmentForActor: d("CometRelayMultiActorEnvironment").forActor,
                children: h.jsx(c("CometRouterDispatcherContextFactory.react"), {
                    actorID: j,
                    children: h.jsx(c("CometTransientDialogProvider.react"), {
                        children: e
                    })
                })
            })
        })
    }
    b.displayName = b.name + " [from " + f.id + "]";

    function e() {
        var a = j(m);
        return [a.get(), a.set]
    }
    g.ActorProvider = b;
    g.useActor = e
}), 98);
__d("Actor.re", ["Actor"], (function(a, b, c, d, e, f) {
    a = b("Actor").useActor;
    f.useActorTypeChecked = a;
    c = a;
    f.useActor = c
}), null);
__d("bs_int64", ["bs_caml", "bs_caml_format", "bs_caml_int64", "bs_caml_js_exceptions"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function a(a) {
        return b("bs_caml_int64").sub(a, b("bs_caml_int64").one)
    }

    function c(a) {
        if (b("bs_caml").i64_ge(a, b("bs_caml_int64").zero)) return a;
        else return b("bs_caml_int64").neg(a)
    }

    function d(a) {
        return b("bs_caml_int64").xor(a, b("bs_caml_int64").neg_one)
    }

    function e(a) {
        try {
            return b("bs_caml_format").caml_int64_of_string(a)
        } catch (c) {
            a = b("bs_caml_js_exceptions").internalToOCamlException(c);
            if (a.RE_EXN_ID === "Failure") return;
            throw a
        }
    }
    var h = (g = b("bs_caml_int64")).compare;

    function i(a, c) {
        return b("bs_caml_int64").compare(a, c) === 0
    }
    var j = g.zero,
        k = g.one,
        l = g.neg_one,
        m = g.succ,
        n = g.max_int,
        o = g.min_int;
    g = g.to_string;
    f.zero = j;
    f.one = k;
    f.minus_one = l;
    f.succ = m;
    f.pred = a;
    f.abs = c;
    f.max_int = n;
    f.min_int = o;
    f.lognot = d;
    f.of_string_opt = e;
    f.to_string = g;
    f.compare = h;
    f.equal = i
}), null);
__d("MWPActor.bs", ["Actor.re", "bs_caml_format", "bs_int64", "react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react"),
        i = h.createContext(void 0);

    function a(a) {
        var c = h.useContext(i);
        a = b("Actor.re").useActor();
        var d = a[0],
            e = h.useMemo(function() {
                return b("bs_caml_format").caml_int64_of_string(d)
            }, [d]);
        return h.useMemo(function() {
            if (c !== void 0) return c;
            else return e
        }, [e, c])
    }

    function c(a) {
        var c = a.actorId;
        a = a.children;
        if (c !== void 0) return h.jsx(i.Provider, {
            value: c,
            children: a
        }, b("bs_int64").to_string(c));
        else return a
    }
    d = c;
    f.useActor = a;
    f.make = d
}), null);
__d("MWChatStateV2Sync.bs", ["BroadcastChannel.bs", "MWChatStateV2IsMinimized.bs", "MWChatStateV2IsOpen.bs", "MWPActor.bs", "bs_caml_format", "bs_caml_option", "bs_curry", "bs_int64", "gkx", "react", "recoverableViolation"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react");

    function i(a, c) {
        if (a !== void 0) {
            b("bs_caml_option").valFromOption(a).postMessage(c);
            return
        }
    }

    function j(a, c) {
        if (a === void 0) return function(a) {};
        var d = b("bs_caml_option").valFromOption(a),
            e = function(a) {
                return b("bs_curry")._1(c, a.data)
            };
        d.addEventListener("message", e);
        return function(a) {
            d.removeEventListener("message", e)
        }
    }

    function k(a) {
        var c = b("MWPActor.bs").useActor(void 0);
        return h.useMemo(function() {
            return b("BroadcastChannel.bs").make("MWChatStateV2_" + b("bs_int64").to_string(c))
        }, [c])
    }

    function l(a) {
        a = Array.from(a.tabs.values());
        var c = [];
        a.forEach(function(a) {
            var d = a.tabType;
            if (d.TAG === 0) return;
            d = d._0;
            c.push({
                threadKey: b("bs_int64").to_string(d.threadKey),
                threadType: b("bs_int64").to_string(d.threadType),
                openWatermark: a.openWatermark,
                closeWatermark: a.closeWatermark
            })
        });
        return c
    }

    function m(a, c, d) {
        return [{
            TAG: 3,
            _0: {
                TAG: 1,
                _0: {
                    threadKey: a,
                    clientThreadKey: void 0,
                    threadType: c
                }
            },
            _1: {
                shouldFocus: !1
            },
            _2: function(a) {
                if (b("MWChatStateV2IsOpen.bs").isOpen(void 0, a)) return a;
                else return {
                    tabId: a.tabId,
                    tabType: a.tabType,
                    openWatermark: a.openWatermark,
                    minimizeWatermark: d,
                    clientForcedMinimizeWatermark: a.clientForcedMinimizeWatermark,
                    closeWatermark: a.closeWatermark,
                    openFlyoutWatermark: a.openFlyoutWatermark
                }
            },
            _3: function(a) {
                return {
                    tabId: a.tabId,
                    tabType: a.tabType,
                    openWatermark: a.openWatermark,
                    minimizeWatermark: d,
                    clientForcedMinimizeWatermark: a.clientForcedMinimizeWatermark,
                    closeWatermark: a.closeWatermark,
                    openFlyoutWatermark: a.openFlyoutWatermark
                }
            }
        }]
    }

    function n(a, c) {
        return [{
            TAG: 2,
            _0: a,
            _1: {
                shouldFocus: !1
            },
            _2: function(a) {
                if (b("MWChatStateV2IsMinimized.bs").isMinimized(void 0, a)) return {
                    tabId: a.tabId,
                    tabType: a.tabType,
                    openWatermark: a.openWatermark,
                    minimizeWatermark: a.minimizeWatermark,
                    clientForcedMinimizeWatermark: a.clientForcedMinimizeWatermark,
                    closeWatermark: c,
                    openFlyoutWatermark: a.openFlyoutWatermark
                };
                else return a
            }
        }]
    }

    function a(a, c, d, e) {
        var f = k(void 0);
        h.useEffect(function() {
            if (d) {
                b("bs_curry")._1(e, function(a) {
                    return !1
                });
                var c = l(a);
                i(f, c)
            }
        }, [a, f, d]);
        h.useEffect(function() {
            return j(f, function(a) {
                try {
                    a.forEach(function(a) {
                        var d = b("bs_caml_format").caml_int64_of_string(a.threadKey),
                            e = b("bs_caml_format").caml_int64_of_string(a.threadType),
                            f = a.closeWatermark;
                        a = a.openWatermark;
                        if (a > f) return b("bs_curry")._1(c, m(d, e, a));
                        else return b("bs_curry")._1(c, n(d, f))
                    });
                    return
                } catch (a) {
                    b("recoverableViolation")("Cross-tab sync error", "messenger_comet");
                    return
                }
            })
        }, [f, c])
    }
    c = b("gkx")("1812710") ? a : function(a, b, c, d) {};
    f.useCrossTabSync = c
}), null);
__d("MWChatStateV2Types.bs", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = new Map();
    b = {
        tabs: a,
        mediaViewerOpenWatermark: -1,
        focusedTabId: void 0,
        nextTabId: 0
    };
    f.empty = b
}), null);
__d("MWThreadListNewMessageState.bs", ["react", "unrecoverableViolation"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react");
    d = [];
    var i = {
            isActive: !1,
            entries: d
        },
        j = h.createContext(i),
        k = h.createContext(void 0);

    function l(a, b) {
        if (typeof b === "number")
            if (b === 0 || a.entries.length === 0) return i;
            else return a;
        else if (b.TAG === 0) return {
            isActive: b._0,
            entries: a.entries
        };
        else return {
            isActive: a.isActive,
            entries: b._0
        }
    }

    function a(a) {
        var b = a.children;
        a = a.defaultState;
        a = a !== void 0 ? a : i;
        a = h.useReducer(l, a);
        return h.createElement(j.Provider, {
            value: a[0],
            children: h.createElement(k.Provider, {
                value: a[1],
                children: b
            })
        })
    }
    e = {
        make: a
    };

    function c() {
        var a = h.useContext(k);
        if (a !== void 0) return a;
        else return b("unrecoverableViolation")("Tried to get the dispatch function for MWThreadListNewMessageState but none was found. Missing provider (MWThreadListNewMessageState)", "messenger_web_product")
    }
    f.empty = i;
    f.context = j;
    f.dispatchContext = k;
    f.reducer = l;
    f.Provider = e;
    f.useDispatch = c
}), null);
__d("MessagingThreadType.bs", ["bs_caml_int64"], (function(a, b, c, d, e, f) {
    "use strict";
    a = [0, 17];
    c = [0, 18];
    d = [0, 19];
    e = [0, 20];
    var g = [0, 21],
        h = [0, 22],
        i = [0, 23],
        j = [0, 24],
        k = [0, 25],
        l = [0, 150],
        m = [0, 151],
        n = [0, 152],
        o = [0, 153];
    b = b("bs_caml_int64").one;
    var p = [0, 2],
        q = [0, 3],
        r = [0, 4],
        s = [0, 5],
        t = [0, 6],
        u = [0, 7],
        v = [0, 8],
        w = [0, 10],
        x = [0, 11],
        y = [0, 13],
        z = [0, 14],
        A = [0, 15],
        B = [0, 16],
        C = [0, 101],
        D = [0, 102];
    f.communityFolder = a;
    f.communityGroup = c;
    f.communityGroupUnjoined = d;
    f.communityChannelCategory = e;
    f.communityPrivateHiddenJoinedThread = g;
    f.communityPrivateHiddenUnjoinedThread = h;
    f.communityBroadcastJoinedThread = i;
    f.communityBroadcastUnjoinedThread = j;
    f.communityGroupInvitedUnjoined = k;
    f.discoverablePublicChat = l;
    f.discoverablePublicChatUnjoined = m;
    f.discoverablePublicBroadcastChat = n;
    f.discoverablePublicBroadcastChatUnjoined = o;
    f.oneToOne = b;
    f.group = p;
    f.room = q;
    f.montage = r;
    f.marketplace = s;
    f.folder = t;
    f.tincanOneToOne = u;
    f.tincanGroupDisappearing = v;
    f.carrierMessagingOneToOne = w;
    f.carrierMessagingGroup = x;
    f.tincanOneToOneDisappearing = y;
    f.pageFollowUp = z;
    f.secureMessageOverWaOneToOne = A;
    f.secureMessageOverWaGroup = B;
    f.pinned = C;
    f.lwg = D
}), null);
__d("MWV2CookieReader.bs", ["MWChatStateV2Types.bs", "MessagingThreadType.bs", "bs_caml", "bs_caml_format", "bs_caml_option", "bs_int64", "gkx", "killswitch", "recoverableViolation"], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        a = a.split(".");
        var c = a.length,
            d;
        if (c >= 3) d = [void 0, void 0];
        else switch (c) {
            case 0:
                d = [void 0, void 0];
                break;
            case 1:
                c = a[0];
                d = [c, void 0];
                break;
            case 2:
                c = a[0];
                a = a[1];
                d = /^-?[1-9]\d*$/.test(a) ? [c, b("bs_caml_format").caml_int64_of_string(a)] : [void 0, void 0];
                break
        }
        c = d[1];
        a = d[0];
        if (a === void 0) return;
        switch (a) {
            case "g":
                if (c !== void 0) return [c, b("MessagingThreadType.bs").group];
                else return;
            case "sc":
                if (c !== void 0) return [c, b("MessagingThreadType.bs").secureMessageOverWaOneToOne];
                else return;
            case "sg":
                if (c !== void 0) return [c, b("MessagingThreadType.bs").secureMessageOverWaGroup];
                else return;
            default:
                if (c !== void 0) return [c, b("MessagingThreadType.bs").oneToOne];
                else return
        }
    }

    function h(a) {
        var c = a.map(function(a) {
            return b("bs_int64").to_string(a[0])
        });
        c = new Set(c);
        if (c.size !== a.length) {
            b("recoverableViolation")("Duplicate thread in cookie (t3)", "messenger_comet");
            return a.filter(function(a, c, d) {
                var e = a[0];
                return !d.slice(c + 1 | 0).some(function(a) {
                    return b("bs_caml").i64_eq(a[0], e)
                })
            })
        } else return a
    }

    function a(a) {
        if (a == null) return b("MWChatStateV2Types.bs").empty;
        if (!(!b("killswitch")("MESSENGER_WEB_STOP_PERSISTING_CHAT_HEADS") && b("gkx")("1812641") && a.startsWith("C"))) return b("MWChatStateV2Types.bs").empty;
        a = a.slice(1);
        try {
            a = JSON.parse(a)
        } catch (c) {
            b("recoverableViolation")("Error parsing JSON string", "messenger_comet"), a = null
        }
        if (a === null) return b("MWChatStateV2Types.bs").empty;
        var c = [];
        a.t3.forEach(function(a) {
            a = a.i;
            a = g(a);
            if (a !== void 0) {
                c.push(a);
                return
            }
        });
        var d = h(c),
            e = new Map(),
            f = {
                contents: 0
            };
        d.forEach(function(a) {
            e.set(f.contents, {
                tabId: f.contents,
                tabType: {
                    TAG: 1,
                    _0: {
                        threadKey: a[0],
                        clientThreadKey: void 0,
                        threadType: a[1]
                    }
                },
                openWatermark: 0,
                minimizeWatermark: 1,
                clientForcedMinimizeWatermark: 0,
                closeWatermark: 0,
                openFlyoutWatermark: 0
            }), f.contents = f.contents + 1 | 0
        });
        a = a.lm3;
        if (a !== void 0) {
            a = g(b("bs_caml_option").valFromOption(a));
            if (a !== void 0) {
                var i = a[0];
                d.some(function(a) {
                    return b("bs_caml").i64_eq(a[0], i)
                }) || e.set(f.contents, {
                    tabId: f.contents,
                    tabType: {
                        TAG: 1,
                        _0: {
                            threadKey: i,
                            clientThreadKey: void 0,
                            threadType: a[1]
                        }
                    },
                    openWatermark: 1,
                    minimizeWatermark: 0,
                    clientForcedMinimizeWatermark: 0,
                    closeWatermark: 0,
                    openFlyoutWatermark: 0
                });
                f.contents = f.contents + 1 | 0
            }
        }
        return {
            tabs: e,
            mediaViewerOpenWatermark: -1,
            focusedTabId: void 0,
            nextTabId: f.contents
        }
    }
    f.read = a
}), null);
__d("MWChatStateV2.bs", ["CometErrorBoundary.re", "FBLogger", "MWChatStateV2IsOpen.bs", "MWChatStateV2Logging.bs", "MWChatStateV2Sync.bs", "MWChatStateV2Types.bs", "MWThreadListNewMessageState.bs", "MWV2CookieReader.bs", "MessengerWebPresenceCookieData", "RecoverableViolationWithComponentStack.react", "bs_caml", "bs_caml_option", "bs_curry", "react"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = g || b("react");

    function i(a, c) {
        a = Array.from(a.tabs.values()).find(function(a) {
            a = a.tabType;
            if (a.TAG === 0)
                if (c.TAG === 0) return !0;
                else return !1;
            else if (c.TAG === 0) return !1;
            else return b("bs_caml").i64_eq(a._0.threadKey, c._0.threadKey)
        });
        if (a !== void 0) return a.tabId
    }

    function j(a, c) {
        a = Array.from(a.tabs.values()).find(function(a) {
            a = a.tabType;
            if (a.TAG === 0) return c === void 0;
            else if (c !== void 0) return b("bs_caml").i64_eq(a._0.threadKey, c);
            else return !1
        });
        if (a !== void 0) return a.tabId
    }

    function k(a, c, d) {
        if (d)
            if (b("MWChatStateV2IsOpen.bs").isOpen(void 0, c)) return c.tabId;
            else return;
        d = a.focusedTabId;
        if (d !== void 0 && d === c.tabId && !b("MWChatStateV2IsOpen.bs").isOpen(void 0, c)) return;
        else return a.focusedTabId
    }

    function l(a, b) {
        return b.reduce(function(a, b) {
            b = b;
            while (!0) {
                var c = b;
                switch (c.TAG | 0) {
                    case 0:
                        return c._0(a);
                    case 1:
                        var d = c._0,
                            e = a.tabs.get(d);
                        if (e == null) return a;
                        var f = c._2(e),
                            g = k(a, f, c._1.shouldFocus);
                        if (f === e) return a;
                        else return {
                            tabs: new Map(a.tabs).set(d, f),
                            mediaViewerOpenWatermark: a.mediaViewerOpenWatermark,
                            focusedTabId: g,
                            nextTabId: a.nextTabId
                        };
                    case 2:
                        e = j(a, c._0);
                        if (e === void 0) return a;
                        b = {
                            TAG: 1,
                            _0: e,
                            _1: c._1,
                            _2: c._2
                        };
                        continue;
                    case 3:
                        d = c._1;
                        f = c._0;
                        g = i(a, f);
                        if (g !== void 0) {
                            b = {
                                TAG: 1,
                                _0: g,
                                _1: d,
                                _2: c._2
                            };
                            continue
                        }
                        e = a.nextTabId;
                        g = {
                            tabId: e,
                            tabType: f,
                            openWatermark: 0,
                            minimizeWatermark: 0,
                            clientForcedMinimizeWatermark: 0,
                            closeWatermark: 0,
                            openFlyoutWatermark: 0
                        };
                        e = c._3(g);
                        f = k(a, e, d.shouldFocus);
                        return {
                            tabs: new Map(a.tabs).set(e.tabId, e),
                            mediaViewerOpenWatermark: a.mediaViewerOpenWatermark,
                            focusedTabId: f,
                            nextTabId: a.nextTabId + 1 | 0
                        }
                }
            }
        }, a)
    }

    function m(a) {
        return b("MWV2CookieReader.bs").read(b("MessengerWebPresenceCookieData").cookie)
    }
    var n = h.createContext(b("MWChatStateV2Types.bs").empty),
        o = h.createContext(void 0);

    function a(a) {
        a = h.useContext(o);
        if (a !== void 0) return a;
        else return function(a) {
            b("FBLogger")("messenger_web_product").warn("Tried to open a chat tab on Comet under the new chat state system, MWChatStateV2. But no MWChatStateV2 was found in react context. Wrap your component in MWChatStateV2? You are likely also be part of Blue on Comet. If so do ping our oncall")
        }
    }

    function c(a) {
        return h.useContext(n)
    }

    function p(a) {
        a !== void 0 ? b("FBLogger")("messenger_browser_clients").catching(b("bs_caml_option").valFromOption(a)).warn("Error loading MWChatStateV2") : b("FBLogger")("messenger_browser_clients").warn("Error loading MWChatStateV2")
    }

    function q(a) {
        a = a.children;
        var c = h.useReducer(l, b("MWChatStateV2Types.bs").empty, m),
            d = c[1];
        c = c[0];
        var e = h.useState(function() {
                return !1
            }),
            f = e[1],
            g = h.useCallback(function(a) {
                b("bs_curry")._1(f, function(a) {
                    return !0
                });
                return b("bs_curry")._1(d, a)
            }, []);
        b("MWChatStateV2Logging.bs").useCookieLiftLogging(c);
        b("MWChatStateV2Sync.bs").useCrossTabSync(c, d, e[0], f);
        e = h.useContext(o);
        if (e !== void 0) return h.jsx(b("RecoverableViolationWithComponentStack.react"), {
            errorMessage: "You can't nest MWChatStateV2 in another MWChatStateV2.",
            projectName: "messenger_comet"
        });
        else return h.createElement(n.Provider, {
            value: c,
            children: h.createElement(o.Provider, {
                value: g,
                children: a
            })
        })
    }
    e = {
        make: q
    };

    function d(a) {
        a = a.children;
        return h.jsx(b("CometErrorBoundary.re").make, {
            children: h.jsx(q, {
                children: h.jsx(b("MWThreadListNewMessageState.bs").Provider.make, {
                    children: a
                })
            }),
            onError: p
        })
    }
    d = d;
    f.reducer = l;
    f.useDispatch = a;
    f.useState = c;
    f.MWChatStateV2 = e;
    f.make = d
}), null);
__d("MWChatStateV2AreAllTabsClosed.bs", ["MWChatStateV2.bs", "MWChatStateV2IsClosed.bs"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        a = b("MWChatStateV2.bs").useState(function(a) {
            return a.tabs
        });
        a = Array.from(a.tabs.values());
        var c = a.length;
        a = a.filter(b("MWChatStateV2IsClosed.bs").isClosed).length;
        return a === c
    }
    f.useHook = a
}), null);
__d("MWChatStateV2AreAllTabsClosed.re", ["MWChatStateV2AreAllTabsClosed.bs"], (function(a, b, c, d, e, f) {
    a = b("MWChatStateV2AreAllTabsClosed.bs").useHook;
    f.useHook = a
}), null);
__d("MWChatVisibilityOverrideContext", ["MWChatStateV2AreAllTabsClosed.re", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    a = d("react");
    b = a.createContext;
    var i = a.useContext,
        j = b(!1);
    e = function(a) {
        a = a.children;
        var b = !c("MWChatStateV2AreAllTabsClosed.re").useHook();
        return h.jsx(j.Provider, {
            value: b,
            children: a
        })
    };
    f = function(a) {
        var b = i(j);
        return a ? b : !0
    };
    g.MWChatVisibilityOverrideContextProvider = e;
    g.useMWChatVisibilityOverride = f
}), 98);
__d("SearchCometGlobalResultPageTracePolicy", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        DEFAULT_TAB: "comet.search_results.default_tab",
        HASHTAG: "comet.search_results.hashtag",
        PHOTOS_TAB: "comet.search_results.photos_tab",
        PLACES_TAB: "comet.search_results.places_tab",
        TOP_TAB: "comet.search_results.top_tab"
    });
    f["default"] = a
}), 66);
__d("isSearchCometGlobalResultPageTracePolicy", ["SearchCometGlobalResultPageTracePolicy"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return Object.values(c("SearchCometGlobalResultPageTracePolicy")).includes(a)
    }
    g["default"] = a
}), 98);
__d("SearchCometScopedResultPageTracePolicy", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        ENTITY_SCOPED: "comet.search_results.entity_scoped",
        EVENTS_SEARCH: "comet.events.search",
        GAMING_SEARCH: "comet.gaming.search",
        GROUPS_TAB_SEARCH: "comet.groups.search",
        NEWS_COMPASS_SEARCH: "comet.news_compass.search",
        REELS_SEARCH: "comet.reels.search",
        WATCH_SEARCH: "comet.watch.search"
    });
    f["default"] = a
}), 66);
__d("isSearchCometScopedResultPageTracePolicy", ["SearchCometScopedResultPageTracePolicy"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return Object.values(c("SearchCometScopedResultPageTracePolicy")).includes(a)
    }
    g["default"] = a
}), 98);
__d("SearchCometTypeaheadEventEmitterContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useSearchCometGlobalTypeaheadStyles", ["CometGlobalPanelLayoutContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useContext,
        i = b.useMemo,
        j = {
            inputXStyle: {
                alignItems: "x6s0dn4",
                boxSizing: "x9f619",
                display: "x78zum5",
                height: "x1s65kcs",
                marginBottom: "x1wsgfga",
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13"
            },
            inputXStyleWithGlobalPanelTopNav: {
                alignItems: "x6s0dn4",
                boxSizing: "x9f619",
                display: "x78zum5",
                height: "xnnlda6"
            }
        },
        k = {
            typeaheadLayout: {
                display: "x1lliihq",
                position: "x1n2onr6",
                "::before": {
                    bottom: "xhq5o37",
                    boxShadow: "x1qxoq08",
                    content: "x1cpjm7i",
                    end: "x1ryaae9",
                    opacity: "x124lp2h",
                    position: "x1hmns74",
                    start: "x1mhyesy",
                    top: "x1y3wzot"
                }
            },
            typeaheadLayoutOpened: {
                borderBottom: "xaqea5y",
                borderBottomEndRadius: "x30kzoy",
                borderBottomStartRadius: "x9jhf4c",
                borderEnd: "x1b1mbwd",
                borderStart: "xav7gou",
                borderTop: "x6umtig",
                "::before": {
                    borderBottomEndRadius: "x9lpf2z",
                    borderBottomStartRadius: "x1eqyvvh",
                    opacity: "xfbg1o9",
                    transitionDuration: "x1kphnah",
                    transitionProperty: "x1de4urk",
                    transitionTimingFunction: "xyt8op7"
                }
            }
        };

    function a() {
        var a = h(c("CometGlobalPanelLayoutContext"));
        return i(function() {
            return {
                inputXStyle: a ? j.inputXStyleWithGlobalPanelTopNav : j.inputXStyle,
                layoutOpenedXStyle: a ? null : k.typeaheadLayoutOpened,
                layoutXStyle: a ? null : k.typeaheadLayout
            }
        }, [a])
    }
    g["default"] = a
}), 98);
__d("CometUBTContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext(null);
    g["default"] = b
}), 98);
__d("CometThrottle", ["clearTimeout", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d) {
        d = d === void 0 ? {} : d;
        var e = d.leading,
            f = d.trailing,
            g, h, i, j = null,
            k = 0,
            l = function() {
                var b = g;
                g = null;
                var d = h;
                h = null;
                if (b == null) throw c("unrecoverableViolation")("It should be impossible for `cachedArgs` to be `null` at the moment we invoke the throttled function. Investigate why this is the case.", "comet_infra");
                else return a.apply(d, b)
            },
            m = function() {
                k = e === !1 ? 0 : new Date(), j = null, i = l()
            };
        d = function() {
            g = h = null, j != null && (c("clearTimeout")(j), j = null)
        };

        function n() {
            var a = new Date();
            !k && e === !1 && (k = a);
            var d = b - (a - k);
            d <= 0 ? (c("clearTimeout")(j), j = null, k = a, g = arguments, h = this, i = l()) : !j && f !== !1 && (g = arguments, h = this, j = c("setTimeout")(m, d));
            return i
        }
        n.cancel = d;
        return n
    }
    g["default"] = a
}), 98);
__d("DOMRectIsEqual", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        if (!a && !b) return !0;
        else if (!a || !b) return !1;
        return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height
    }
    f["default"] = a
}), 66);
__d("GlobalVideoPortsContexts", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    e = d("react");
    f = e.createContext;
    var h = e.useContext,
        i = f(null),
        j = f(null),
        k = f(null);

    function a() {
        return h(i)
    }

    function b() {
        return h(j)
    }

    function c() {
        return h(k)
    }
    d = i.Provider;
    e = j.Provider;
    f = k.Provider;
    g.useGlobalVideoPortsLoader = a;
    g.useGlobalVideoPortsManager = b;
    g.useGlobalVideoPortsState = c;
    g.GlobalVideoPortsLoaderContextProvider = d;
    g.GlobalVideoPortsManagerContextProvider = e;
    g.GlobalVideoPortsStateContextProvider = f
}), 98);
__d("VideoPlayerViewabilityConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        DEFAULT_VIEWABILITY_PERCENTAGE_FOR_PAUSE: .5
    };
    b = a;
    f["default"] = b
}), 66);
__d("LsSystemFolder.bs", ["bs_caml_int64"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("bs_caml_int64").zero;
    c = b("bs_caml_int64").neg_one;
    d = [-1, 4294967294];
    e = [-1, 4294967293];
    b = [-1, 4294967292];
    var g = [-1, 4294967291],
        h = [-1, 4294967290],
        i = [-1, 4294967289],
        j = [-1, 4294967288],
        k = [-1, 4294967287],
        l = [-1, 4294967286],
        m = [-1, 4294967285],
        n = [-1, 4294967284],
        o = [-1, 4294967283],
        p = [-1, 4294967282],
        q = [-1, 4294967281],
        r = [-1, 4294967278],
        s = [-1, 4294967196],
        t = [-1, 4294967195],
        u = [-1, 4294967194],
        v = [-1, 4294967193],
        w = [-1, 4294967186];
    f.inbox = a;
    f.pending = c;
    f.other = d;
    f.spam = e;
    f.hidden = b;
    f.legacy = g;
    f.disabled = h;
    f.blocked = i;
    f.background = j;
    f.done_ = k;
    f.archived = l;
    f.business = m;
    f.mplace = n;
    f.jobs = o;
    f.community = p;
    f.restricted = q;
    f.businessSupport = r;
    f.secureInbox = s;
    f.securePending = t;
    f.secureOther = u;
    f.secureSpam = v;
    f.secureArchived = w
}), null);
__d("ResourceTimingStore", ["performance"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 4e3,
        i = 3e3,
        j = new Map(),
        k = !1;

    function l() {
        var a = Array.from(j.entries());
        j = new Map(a.slice(-i))
    }

    function m(a) {
        var b = a.indexOf("#");
        return b === -1 ? a : a.slice(0, b)
    }

    function n(a) {
        for (var a = a, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var d;
            if (b) {
                if (c >= a.length) break;
                d = a[c++]
            } else {
                c = a.next();
                if (c.done) break;
                d = c.value
            }
            d = d;
            if (!(d instanceof PerformanceResourceTiming)) continue;
            var e = "";
            try {
                e = new URL(d.name).pathname
            } catch (a) {}
            if (!/\.(css|js)$/.test(e)) continue;
            e = d;
            if (!(e != null && typeof e === "object" && typeof e.encodedBodySize === "number" && typeof e.decodedBodySize === "number" && typeof e.transferSize === "number")) continue;
            j.set(m(d.name), e)
        }
        j.size > h && l()
    }

    function o(a) {
        n(a.getEntries())
    }

    function p() {
        if (k) return;
        k = !0;
        var a;
        if (typeof PerformanceObserver !== "undefined") {
            a = new PerformanceObserver(o);
            try {
                a.observe({
                    buffered: !0,
                    type: "resource"
                })
            } catch (a) {}
        }
        typeof c("performance").getEntriesByType === "function" && n(c("performance").getEntriesByType("resource"))
    }

    function a(a) {
        p();
        return j.get(m(a))
    }
    g.init = p;
    g.getEntryForURL = a
}), 98);
__d("useCustomEqualityMemo", ["react", "useUnsafeRef_DEPRECATED"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useEffect;

    function a(a, b) {
        var d = c("useUnsafeRef_DEPRECATED")(a),
            e = b(d.current, a) ? d.current : a;
        h(function() {
            d.current = e
        }, [e]);
        return e
    }
    g["default"] = a
}), 98);
__d("useDebouncedValue", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useEffect,
        i = b.useState;

    function a(a, b) {
        var c = i(a),
            d = c[0],
            e = c[1];
        h(function() {
            var c = setTimeout(function() {
                return e(a)
            }, b);
            return function() {
                return clearTimeout(c)
            }
        }, [a, b]);
        return d
    }
    g["default"] = a
}), 98);
__d("useRefEffect", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = d("react");
    var h = b.useCallback,
        i = b.useRef;

    function a(a, b) {
        var c = i(null);
        return h(function(b) {
            c.current && (c.current(), c.current = null), b != null && (c.current = a(b))
        }, b)
    }
    g["default"] = a
}), 98);
__d("QPLJoinUtils", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b, c, d) {
        var e;
        d = (d = d == null ? void 0 : d.instanceKey) != null ? d : 0;
        a.markerAnnotate(b, {
            string: (e = {}, e.source = "client", e)
        }, {
            instanceKey: d
        });
        a.markerAnnotate(b, {
            string: (e = {}, e.join_id = c, e)
        }, {
            instanceKey: d
        })
    }

    function b(a, b, c, d) {
        a.markerPoint(b, "join_request_" + c, {
            instanceKey: (b = d == null ? void 0 : d.instanceKey) != null ? b : 0,
            timestamp: (b = d == null ? void 0 : d.timestamp) != null ? b : a.currentTimestamp(),
            data: c != null ? {
                string: {
                    __key: c
                }
            } : null
        })
    }

    function c(a, b, c, d) {
        var e;
        e = (e = d == null ? void 0 : d.instanceKey) != null ? e : 0;
        d = (d = d == null ? void 0 : d.timestamp) != null ? d : a.currentTimestamp();
        a.markerPoint(b, "join_response_" + c, {
            instanceKey: e,
            timestamp: d,
            data: c != null ? {
                string: {
                    __key: c
                }
            } : null
        })
    }
    f.setJoinId = a;
    f.markJoinRequest = b;
    f.markJoinResponse = c
}), 66);
__d("ErrorMetadata", ["fb-error"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        b.addGlobalMetadata = function(b, c, d) {
            a.addGlobalMetadata.call(this, b, c, d)
        };
        return b
    }(c("fb-error").ErrorMetadata);
    g["default"] = a
}), 98);
__d("QPLUserFlow", ["ErrorMetadata", "ErrorPubSub", "QPLEvent", "QPLJoinUtils", "QuickPerformanceLogger", "cr:1752405"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b) {
        if (b === null) {
            var c;
            return (c = a) != null ? c : null
        }
        a = (c = a) != null ? c : {};
        a.string || (a.string = {});
        a.string.uf_debug_info = b;
        return a
    }
    a = function() {
        function a() {
            var a = this;
            b("cr:1752405")();
            c("ErrorPubSub").unshiftListener(function(b) {
                if (b.type !== "fatal") return;
                var d = a.getActiveFlowIDs();
                if (d.length === 0) return;
                var e = new(c("ErrorMetadata"))();
                e.clearEntries();
                d.forEach(function(a) {
                    e.addEntry("QPL", "ACTIVE_FLOW_ID", a.toString())
                });
                d = e.format();
                b.metadata ? b.metadata = [].concat(b.metadata, d) : b.metadata = d
            });
            this.$1 = new Map()
        }
        var e = a.prototype;
        e.$2 = function(a, b, c, e, f) {
            var g = this,
                h;
            if (e == null) return;
            e = window.setTimeout(function() {
                f != null && f(a, b, c), g.endTimeout(a, {
                    instanceKey: b,
                    joinID: c
                })
            }, e);
            this.$1.has(d("QPLEvent").getMarkerId(a)) || this.$1.set(d("QPLEvent").getMarkerId(a), new Map());
            (h = this.$1.get(d("QPLEvent").getMarkerId(a))) == null ? void 0 : h.set(b, e)
        };
        e.start = function(a, b) {
            b = b === void 0 ? {} : b;
            var e = b.instanceKey;
            e = e === void 0 ? 0 : e;
            var f = b.annotations,
                g = b.cancelExisting;
            g = g === void 0 ? !1 : g;
            var h = b.cancelOnUnload;
            h = h === void 0 ? !0 : h;
            var i = b.timestamp,
                j = b.trackedForLoss;
            j = j === void 0 ? !0 : j;
            var k = b.joinID,
                l = b.timeoutInMs,
                m = b.onFlowTimeout;
            b = b.qplInternalDoNotUseAbsoluteTimeOrigin;
            c("QuickPerformanceLogger").markerStart(a, e, i, {
                cancelExisting: g,
                cancelOnUnload: h,
                trackedForLoss: j,
                type: 2,
                samplingBasis: k,
                qplInternalDoNotUseAbsoluteTimeOrigin: b
            });
            this.$2(a, e, k, l, m);
            f && c("QuickPerformanceLogger").markerAnnotate(a, f, {
                instanceKey: e
            });
            k != null && (d("QPLJoinUtils").setJoinId(c("QuickPerformanceLogger"), a, k, {
                instanceKey: e
            }), d("QPLJoinUtils").markJoinRequest(c("QuickPerformanceLogger"), a, k, {
                instanceKey: e
            }))
        };
        e.startFromNavStart = function(a, b) {
            b = b === void 0 ? {} : b;
            var d = b.instanceKey;
            d = d === void 0 ? 0 : d;
            var e = b.annotations,
                f = b.cancelExisting;
            f = f === void 0 ? !1 : f;
            var g = b.cancelOnUnload;
            g = g === void 0 ? !0 : g;
            var h = b.trackedForLoss;
            h = h === void 0 ? !0 : h;
            var i = b.joinID,
                j = b.timeoutInMs,
                k = b.onFlowTimeout;
            b = b.qplInternalDoNotUseConvertToTimeOnServer;
            c("QuickPerformanceLogger").markerStartFromNavStart(a, d, {
                cancelExisting: f,
                cancelOnUnload: g,
                trackedForLoss: h,
                type: 2,
                samplingBasis: i,
                qplInternalDoNotUseConvertToTimeOnServer: b
            });
            this.$2(a, d, i, j, k);
            e && c("QuickPerformanceLogger").markerAnnotate(a, e, {
                instanceKey: d
            })
        };
        e.endSuccess = function(a, b) {
            b = b === void 0 ? {} : b;
            var c = b.instanceKey;
            c = c === void 0 ? 0 : c;
            var d = b.annotations,
                e = b.joinID;
            b = b.timestamp;
            this.$3(a, 2, c, e, d, b)
        };
        e.endFailure = function(a, b, c) {
            c = c === void 0 ? {} : c;
            var d = c.instanceKey;
            d = d === void 0 ? 0 : d;
            var e = c.debugInfo,
                f = c.annotations,
                g = c.joinID,
                h = c.timestamp;
            c = c.error;
            this.markError(a, b, {
                debugInfo: e,
                instanceKey: d,
                error: c
            });
            this.$3(a, 3, d, g, f, h)
        };
        e.endValidationFailure_DO_NOT_USE = function(a, b) {
            b = b === void 0 ? {} : b;
            var c = b.instanceKey;
            c = c === void 0 ? 0 : c;
            var d = b.debugInfo,
                e = b.annotations,
                f = b.joinID;
            b = b.timestamp;
            this.markError(a, "validation_failed", {
                debugInfo: d,
                instanceKey: c
            });
            this.$3(a, 7952, c, f, e, b)
        };
        e.endTimeout = function(a, b) {
            b = b === void 0 ? {} : b;
            var c = b.instanceKey;
            c = c === void 0 ? 0 : c;
            var d = b.annotations,
                e = b.joinID;
            b = b.timestamp;
            this.$3(a, 113, c, e, d, b)
        };
        e.endCancel = function(a, b) {
            b = b === void 0 ? {} : b;
            var c = b.instanceKey;
            c = c === void 0 ? 0 : c;
            var d = b.cancelReason;
            d = d === void 0 ? 4 : d;
            var e = b.annotations,
                f = b.joinID;
            b = b.timestamp;
            this.$3(a, d, c, f, e, b)
        };
        e.$3 = function(a, b, e, f, g, h) {
            var i;
            i = (i = this.$1.get(d("QPLEvent").getMarkerId(a))) == null ? void 0 : i.get(e);
            if (i != null) {
                window.clearTimeout(i);
                (i = this.$1.get(d("QPLEvent").getMarkerId(a))) == null ? void 0 : i["delete"](e)
            }
            g && c("QuickPerformanceLogger").markerAnnotate(a, g, {
                instanceKey: e
            });
            f != null && (h != null ? d("QPLJoinUtils").markJoinResponse(c("QuickPerformanceLogger"), a, f, {
                instanceKey: e,
                timestamp: h
            }) : d("QPLJoinUtils").markJoinResponse(c("QuickPerformanceLogger"), a, f, {
                instanceKey: e
            }));
            h != null ? c("QuickPerformanceLogger").markerEnd(a, b, e, h) : c("QuickPerformanceLogger").markerEnd(a, b, e)
        };
        e.addAnnotations = function(a, b, d) {
            d = d === void 0 ? {} : d;
            d = d.instanceKey;
            c("QuickPerformanceLogger").markerAnnotate(a, b, {
                instanceKey: d
            })
        };
        e.addPoint = function(a, b, d) {
            d = d === void 0 ? {} : d;
            var e = d.instanceKey,
                f = d.debugInfo,
                g = d.data;
            d = d.timestamp;
            f = h(g, (g = f) != null ? g : null);
            c("QuickPerformanceLogger").markerPoint(a, b, {
                data: f,
                instanceKey: e,
                timestamp: d
            })
        };
        e.markError = function(a, b, d) {
            d = d === void 0 ? {} : d;
            var e = d.debugInfo,
                f = d.instanceKey;
            d = d.error;
            c("QuickPerformanceLogger").markerAnnotate(a, babelHelpers["extends"]({}, this.$4(d), {
                bool: (d = {}, d.uf_has_error = !0, d)
            }), {
                instanceKey: f
            });
            this.addPoint(a, b, {
                debugInfo: e,
                instanceKey: f
            })
        };
        e.storeBeforeNavigation = function(a, b) {
            b = b === void 0 ? {} : b;
            b = b.instanceKey;
            b = b === void 0 ? 0 : b;
            c("QuickPerformanceLogger").markerStoreBeforeNavigation(a, {
                instanceKey: b
            })
        };
        e.getActiveFlowIDs = function() {
            return c("QuickPerformanceLogger").getActiveMarkerIds({
                type: 2
            })
        };
        e.$4 = function(a) {
            var b;
            if (a == null) return {};
            var c = {
                "int": {},
                string: {}
            };
            c.string.uf_error_name = a.name;
            a = a;
            (a == null ? void 0 : (b = a.source) == null ? void 0 : b.code) != null && (c["int"].uf_graphql_error_code = a == null ? void 0 : a.source.code);
            if ((a == null ? void 0 : (b = a.source) == null ? void 0 : (b = b.exception) == null ? void 0 : b["class"]) != null) {
                c.string.uf_graphql_exception_class = a == null ? void 0 : (b = a.source) == null ? void 0 : (a = b.exception) == null ? void 0 : a["class"]
            }
            return c
        };
        return a
    }();
    e = new a();
    g["default"] = e
}), 98);
__d("CometRouteProductAttributionContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("CometRouterPushViewStackContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("absoluteToRelative", ["memoizeStringOnly"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("memoizeStringOnly")(function(a) {
        return a.replace(/^https?:\/\/[^\/]+/i, "")
    });

    function a(a) {
        return h((a = a) != null ? a : "#")
    }
    g["default"] = a
}), 98);
__d("CometRouteURL", ["ConstUriUtils", "absoluteToRelative", "memoizeStringOnly", "useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("memoizeStringOnly")(function(a) {
            a = d("ConstUriUtils").getUri(a);
            return a != null ? a.getPath() : null
        }),
        i = c("memoizeStringOnly")(function(a) {
            a = d("ConstUriUtils").getUri(a);
            return a != null ? Object.fromEntries(a.getQueryParams()) : null
        });

    function j() {
        var a;
        if (window.location.href == null) return null;
        a = (a = d("ConstUriUtils").getUri(window.location.href)) == null ? void 0 : a.toString();
        return a != null ? c("absoluteToRelative")(a) : null
    }

    function a() {
        var a = j();
        return a != null ? i(a) : null
    }

    function k() {
        var a = c("useCurrentRoute")();
        if (a != null) {
            var b;
            return (b = a.canonicalUrl) != null ? b : a.url
        } else {
            return (b = j()) != null ? b : ""
        }
    }

    function b() {
        var a = k();
        return (a = h(a)) != null ? a : ""
    }

    function e() {
        var a = k();
        return (a = i(a)) != null ? a : {}
    }
    g.getWindowURL = j;
    g.getWindowURLParams = a;
    g.useRouteURL = k;
    g.useRouteURLPath = b;
    g.useRouteURLParams = e
}), 98);
__d("CometRouteParams", ["CometRouteURL", "useCurrentRoute"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h() {
        var a = c("useCurrentRoute")();
        if (a != null) return a.params;
        else {
            return (a = d("CometRouteURL").getWindowURLParams()) != null ? a : {}
        }
    }

    function a(a) {
        return a(h())
    }
    g.useRouteParams = h;
    g.useCometRefinedRouteParams = a
}), 98);
__d("getCometEntityKey", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.entityKeyConfig;
        return b == null ? null : g(b, a)
    }

    function g(a, b) {
        var c = {};
        for (var d in a) c[d] = i(a[d], b);
        return c
    }

    function h(a, b) {
        return a == null || a[b] == null ? null : String(a[b])
    }

    function i(a, b) {
        switch (a.source) {
            case "prop":
                return h(b.rootView.props, a.value);
            case "param":
                return h(b.params, a.value);
            case "constant":
                return a.value
        }
        return null
    }
    f["default"] = a
}), 66);
__d("getTopMostRoute", ["getTopMostRouteInfo"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("getTopMostRouteInfo")(a).route
    }
    g["default"] = a
}), 98);
__d("useCometEntityKey", ["getCometEntityKey", "getTopMostRoute", "useCometRouterState"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useCometRouterState")();
        if (a == null) return null;
        a = c("getTopMostRoute")(a);
        return c("getCometEntityKey")(a)
    }
    g["default"] = a
}), 98);
__d("useRouteProductAttribution", ["CometRouteProductAttributionContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRouteProductAttributionContext"))
    }
    g["default"] = a
}), 98);
__d("useMinifiedProductAttribution", ["CometProductAttribution", "useRouteProductAttribution"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("useRouteProductAttribution")();
        return a != null ? d("CometProductAttribution").minifyProductAttributionV2(a) : null
    }
    g["default"] = a
}), 98);