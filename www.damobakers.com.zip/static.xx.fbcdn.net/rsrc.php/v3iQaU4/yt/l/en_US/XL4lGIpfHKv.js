if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("FeedComposerCometRootQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6208113752537665"
}), null);
__d("FeedComposerCometRootQuery$Parameters", ["FeedComposerCometRootQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        kind: "PreloadableConcreteRequest",
        params: {
            id: b("FeedComposerCometRootQuery_facebookRelayOperation"),
            metadata: {},
            name: "FeedComposerCometRootQuery",
            operationKind: "query",
            text: null
        }
    };
    e.exports = a
}), null);
__d("CometOnMobileContext.react", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = {
        isCometOnMobile: !1
    };
    c = a.createContext(b);
    g["default"] = c
}), 98);
__d("useIsCometOnMobile.hybrid", ["CometOnMobileContext.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometOnMobileContext.react")).isCometOnMobile
    }
    g["default"] = a
}), 98);
__d("CometCardedDialogLegacy.react", ["fbt", "ix", "BaseDialog.react", "BaseHeadingContextWrapper.react", "CometCircleButton.react", "CometTrackingNodeProvider.react", "TetraText.react", "TetraTextPairing.react", "fbicon", "react", "stylex", "useCometUniqueID", "useIsCometOnMobile.hybrid"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j = d("react"),
        k = {
            anchor: {
                paddingEnd: "x1sxyh0",
                paddingStart: "xurb0ha",
                paddingTop: "x1x97wu9",
                paddingBottom: "xbr3nou",
                "@media (max-width: 564px)": {
                    paddingEnd: "x1dzdb2q",
                    paddingStart: "x3v4vwv"
                }
            },
            anchorInMobileEnvironment: {
                paddingTop: "xexx8yu",
                paddingBottom: "x18d9i69"
            },
            backButton: {
                position: "x10l6tqk",
                start: "x16q8cke",
                top: "x1tk7jg1",
                zIndex: "x1vjfegm"
            },
            card: {
                backgroundColor: "x1jx94hy",
                borderTopStartRadius: "x1qpq9i9",
                borderTopEndRadius: "xdney7k",
                borderBottomEndRadius: "xu5ydu1",
                borderBottomStartRadius: "xt3gfkd",
                boxShadow: "x104qc98",
                "@media (max-width: 564px)": {
                    borderTopStartRadius: "x1g2kw80",
                    borderTopEndRadius: "x16n5opg",
                    borderBottomEndRadius: "xl7ujzl",
                    borderBottomStartRadius: "xhkep3z"
                }
            },
            closeButton: {
                end: "x92rtbv",
                position: "x10l6tqk",
                top: "x1tk7jg1",
                zIndex: "x1vjfegm"
            },
            header: {
                boxSizing: "x9f619",
                height: "xng8ra"
            },
            headerBottomBorder: {
                borderBottom: "xua58t2"
            },
            headerWithBackButton: {
                paddingStart: "xyxze6z"
            },
            headerWithCloseButton: {
                paddingEnd: "x525zg8"
            },
            headerWithPadding: {
                paddingEnd: "x525zg8",
                paddingStart: "xyxze6z"
            },
            rootInMobileEnvironment: {
                justifyContent: "x1nhvcw1"
            },
            titleWrapper: {
                alignItems: "x6s0dn4",
                boxSizing: "x9f619",
                display: "x78zum5",
                height: "x5yr21d",
                paddingEnd: "x1pi30zi",
                paddingStart: "x1swvt13"
            }
        },
        l = {
            content: {
                maxWidth: "x193iq5w"
            },
            "content-mobile-safe": {
                width: "xh8yej3"
            },
            medium: {
                maxWidth: "xrgej4m",
                width: "xh8yej3"
            },
            small: {
                maxWidth: "x1n7qst7",
                width: "xh8yej3"
            }
        },
        m = {
            center: {
                justifyContent: "xl56j7k"
            },
            start: {
                justifyContent: "x1nhvcw1"
            }
        };

    function a(a, b) {
        var e, f, g, n = a.anchorXStyle,
            o = a.rootXStyle,
            p = a.backButtonType,
            q = a.children,
            r = a.disableHeaderDivider;
        r = r === void 0 ? !1 : r;
        var s = a.closeButtonType,
            t = a.header,
            u = a.onBack;
        u = u === void 0 ? function() {} : u;
        var v = a.onClose;
        v = v === void 0 ? function() {} : v;
        var w = a.disableClosingWithMask;
        w = w === void 0 ? !1 : w;
        var x = a.labelledBy,
            y = a.size;
        y = y === void 0 ? "small" : y;
        var z = a.testid;
        z = a.title;
        var A = a.titleWithEntities,
            B = a.subtitle,
            C = a.titleHorizontalAlignment;
        C = C === void 0 ? "center" : C;
        var D = a.withBackButton;
        D = D === void 0 ? !1 : D;
        var E = a.withCloseButton;
        E = E === void 0 ? !1 : E;
        a = a.withDeprecatedStyles;
        a = a === void 0 ? !0 : a;
        var F = c("useIsCometOnMobile.hybrid")();
        y = y === "content-mobile-safe" && !F ? "content" : y;
        e = (e = z) != null ? e : A;
        var G = c("useCometUniqueID")();
        f = z == null && ((f = t) != null ? f : A) != null ? G : void 0;
        return j.jsxs(c("BaseDialog.react"), {
            anchorXStyle: [k.anchor, F && k.anchorInMobileEnvironment, n],
            "aria-label": x != null ? void 0 : (A = z) != null ? A : void 0,
            "aria-labelledby": (G = x) != null ? G : f,
            disableClosingWithMask: w,
            onClose: v,
            ref: b,
            rootXStyle: [F && k.rootInMobileEnvironment, o],
            testid: void 0,
            withDeprecatedStyles: a,
            xstyle: [k.card, l[y]],
            children: [t != null && j.jsx("div", {
                className: c("stylex")(k.header, !r && k.headerBottomBorder, E && k.headerWithCloseButton, D && k.headerWithBackButton, (E || D) && C === "center" && k.headerWithPadding),
                id: f,
                children: t
            }), e != null && t == null && j.jsx("div", {
                className: c("stylex")(k.header, !r && k.headerBottomBorder, E && k.headerWithCloseButton, D && k.headerWithBackButton, (E || D) && C === "center" && k.headerWithPadding),
                id: f,
                children: j.jsx("div", {
                    className: c("stylex")(k.titleWrapper, m[C]),
                    children: B != null ? j.jsx(c("TetraTextPairing.react"), {
                        body: B,
                        bodyLineLimit: 2,
                        headline: e,
                        headlineLineLimit: 1,
                        isSemanticHeading: !0,
                        level: F ? 3 : 2,
                        textAlign: "center"
                    }) : j.jsx(c("TetraText.react"), {
                        isSemanticHeading: !0,
                        numberOfLines: 1,
                        type: F ? "headlineEmphasized3" : "headlineEmphasized2",
                        children: e
                    })
                })
            }), E ? j.jsx(c("CometTrackingNodeProvider.react"), {
                trackingNode: 141,
                children: j.jsx("div", {
                    className: c("stylex")(k.closeButton),
                    "data-testid": void 0,
                    children: j.jsx(c("CometCircleButton.react"), {
                        color: "secondary",
                        icon: d("fbicon")._(i("478233"), 20),
                        label: h._("Close"),
                        onPress: v,
                        size: 36,
                        type: s
                    })
                })
            }) : null, D ? j.jsx("div", {
                className: c("stylex")(k.backButton),
                "data-testid": void 0,
                children: j.jsx(c("CometCircleButton.react"), {
                    color: "secondary",
                    icon: d("fbicon")._(i("512647"), 20),
                    label: h._("Back"),
                    onPress: u,
                    size: 36,
                    type: p
                })
            }) : null, j.jsx(c("BaseHeadingContextWrapper.react"), {
                children: q
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    b = j.forwardRef(a);
    g["default"] = b
}), 98);
__d("CometComposerMinutiaeBarLoading.react", ["BaseGlimmer.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a() {
        return h.jsxs("div", {
            className: "xh8yej3 xyamay9 x78zum5 x9f619 x6s0dn4",
            children: [h.jsx(c("BaseGlimmer.react"), {
                className: "x100vrsf x1vqgdyp xww2gxu x18nykt9 xudhj91 x14yjl9h",
                index: 1
            }), h.jsx("div", {
                className: "x3hqpx7",
                children: h.jsx(c("BaseGlimmer.react"), {
                    className: "x16n37ib xod5an3 xq8finb x14vqqas x17rw0jw x9jhf4c x30kzoy xgqcy7u x1lq5wgf",
                    index: 1
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("CometComposerStylingConstants", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 16;
    b = 500;
    c = 500;
    d = 680;
    e = 1e3;
    var g = 1,
        h = 60,
        i = 85,
        j = 1080 / 750,
        k = 500 / 500,
        l = 63206,
        m = 100,
        n = 25,
        o = 2500;
    f.COMPOSER_PADDING_SIDE = a;
    f.COMPOSER_ORIGINAL_HEIGHT = b;
    f.COMPOSER_ORIGINAL_WIDTH = c;
    f.GEMINI_COMPOSER_WIDTH = d;
    f.GEMINI_MULTILINGUAL_COMPOSER_MAX_WIDTH = e;
    f.COMPOSER_ATTACHMENT_AREA_BORDER = g;
    f.PUSH_PAGE_HEADER_HEIGHT = h;
    f.MAX_DYNAMIC_TEXT_LENGTH = i;
    f.SATP_ASPECT_RATIO = j;
    f.AVATAR_SATP_ASPECT_RATIO = k;
    f.COMPOSER_CHARACTER_LIMIT = l;
    f.COMPOSER_WARNING_LIMIT = m;
    f.PAGE_RECOMMENDATIONS_MIN_CHARS = n;
    f.REELS_COMPOSER_CHARACTER_LIMIT = o
}), 66);
__d("FeedComposerCometGlimmer.react", ["BaseGlimmer.react", "CometComposerMinutiaeBarLoading.react", "CometComposerStylingConstants", "gkx", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        a = a.responsive;
        a = a === void 0 ? !1 : a;
        var b = c("gkx")("1224637") ? d("CometComposerStylingConstants").GEMINI_COMPOSER_WIDTH : d("CometComposerStylingConstants").COMPOSER_ORIGINAL_WIDTH;
        return h.jsxs("div", {
            className: "x1swvt13 x18d9i69 x1pi30zi xexx8yu x1qughib xboal0k xdt5ytf x78zum5 x9f619",
            style: {
                width: a === !1 && b
            },
            children: [h.jsx(c("CometComposerMinutiaeBarLoading.react"), {}), h.jsx("div", {
                className: "xh8yej3",
                children: h.jsx(c("BaseGlimmer.react"), {
                    className: "x1mh8g0r x1yztbdb x11i5rnm x1gslohp x1s1d1n7 x9jhf4c x30kzoy xgqcy7u x1lq5wgf",
                    index: 2
                })
            })]
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("ComposerCancelFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743444");
    c = b("FalcoLoggerInternal").create("composer_cancel", a);
    e.exports = c
}), null);
__d("ComposerEntryFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743449");
    c = b("FalcoLoggerInternal").create("composer_entry", a);
    e.exports = c
}), null);
__d("ComposerFeatureIntentFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743450");
    c = b("FalcoLoggerInternal").create("composer_feature_intent", a);
    e.exports = c
}), null);
__d("ComposerPostCancelFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743454");
    c = b("FalcoLoggerInternal").create("composer_post_cancel", a);
    e.exports = c
}), null);
__d("ComposerPostFailureFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743455");
    c = b("FalcoLoggerInternal").create("composer_post_failure", a);
    e.exports = c
}), null);
__d("ComposerPostFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743456");
    c = b("FalcoLoggerInternal").create("composer_post", a);
    e.exports = c
}), null);
__d("ComposerPostMutationStartFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743457");
    c = b("FalcoLoggerInternal").create("composer_post_mutation_start", a);
    e.exports = c
}), null);
__d("ComposerPostServerContentRenderedFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743458");
    c = b("FalcoLoggerInternal").create("composer_post_server_content_rendered", a);
    e.exports = c
}), null);
__d("ComposerPostSuccessFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743459");
    c = b("FalcoLoggerInternal").create("composer_post_success", a);
    e.exports = c
}), null);
__d("ComposerPostTerminalFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743460");
    c = b("FalcoLoggerInternal").create("composer_post_terminal", a);
    e.exports = c
}), null);
__d("ComposerPublishFlowFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1743461");
    c = b("FalcoLoggerInternal").create("composer_publish_flow", a);
    e.exports = c
}), null);
__d("cometComposerLogger", ["ComposerCancelFalcoEvent", "ComposerEntryFalcoEvent", "ComposerFeatureIntentFalcoEvent", "ComposerPostCancelFalcoEvent", "ComposerPostFailureFalcoEvent", "ComposerPostFalcoEvent", "ComposerPostMutationStartFalcoEvent", "ComposerPostServerContentRenderedFalcoEvent", "ComposerPostSuccessFalcoEvent", "ComposerPostTerminalFalcoEvent", "ComposerPublishFlowFalcoEvent", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("cometComposerQPLLogger").__setRef("cometComposerLogger");

    function a(a, b, c) {
        t(a);
        switch (a.type) {
            case "COMPOSER_ENTRY":
                i(a.fields, b, c);
                break;
            case "COMPOSER_FEATURE_INTENT":
                j(a.fields, b, c);
                break;
            case "COMPOSER_CANCEL":
                k(a.fields, b, c);
                break;
            case "COMPOSER_POST":
                l(a.fields, b);
                break;
            case "COMPOSER_POST_MUTATION_START":
                m(a.fields, b);
                break;
            case "COMPOSER_POST_SUCCESS":
                n(a.fields, b);
                break;
            case "COMPOSER_POST_FAILURE":
                o(a.fields, b);
                break;
            case "COMPOSER_POST_CANCEL":
                p(a.fields, b);
                break;
            case "COMPOSER_POST_TERMINAL":
                q(a.fields, b);
                break;
            case "COMPOSER_POST_SERVER_CONTENT_RENDERED":
                r(a.fields, b);
                break;
            case "COMPOSER_PUBLISH_FLOW_OPTIMISTIC_PROCESS":
                s(a.fields, b);
                break;
            default:
                break
        }
    }

    function i(a, b, d) {
        c("ComposerEntryFalcoEvent").log(function() {
            var c;
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                feature_type: a == null ? void 0 : a.featureType,
                is_edit_composer: a == null ? void 0 : a.isEditComposer,
                target_id: d == null ? void 0 : (c = d.target) == null ? void 0 : c.id,
                target_type: (d == null ? void 0 : (c = d.target) == null ? void 0 : c.type) ? d == null ? void 0 : d.target.type : null
            }
        })
    }

    function j(a, b, d) {
        c("ComposerFeatureIntentFalcoEvent").log(function() {
            var c;
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                feature_type: a == null ? void 0 : a.featureType,
                is_edit_composer: a == null ? void 0 : a.isEditComposer,
                source: a == null ? void 0 : a.source,
                target_type: (d == null ? void 0 : (c = d.target) == null ? void 0 : c.type) ? d == null ? void 0 : d.target.type : null
            }
        })
    }

    function k(a, b, d) {
        c("ComposerCancelFalcoEvent").log(function() {
            var c;
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                is_edit_composer: a == null ? void 0 : a.isEditComposer,
                target_id: d == null ? void 0 : (c = d.target) == null ? void 0 : c.id,
                target_type: (d == null ? void 0 : (c = d.target) == null ? void 0 : c.type) ? d == null ? void 0 : d.target.type : null
            }
        })
    }

    function l(a, b) {
        c("ComposerPostFalcoEvent").log(function() {
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                is_edit_composer: a == null ? void 0 : a.isEditComposer,
                is_my_story_selected: a == null ? void 0 : a.isMyStorySelected,
                is_news_feed_selected: a == null ? void 0 : a.isNewsFeedSelected,
                payload: a == null ? void 0 : a.payload,
                unpublished_content_type: a == null ? void 0 : a.unpublishedContentType
            }
        })
    }

    function m(a, b) {
        c("ComposerPostMutationStartFalcoEvent").log(function() {
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                destination: a == null ? void 0 : a.destination,
                is_edit_composer: a == null ? void 0 : a.isEditComposer
            }
        })
    }

    function n(a, b) {
        c("ComposerPostSuccessFalcoEvent").log(function() {
            var c;
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                is_edit_composer: a == null ? void 0 : a.isEditComposer,
                logging_ids: a == null ? void 0 : a.loggingIds,
                payload: a == null ? void 0 : a.payload,
                retry_count: (c = a == null ? void 0 : a.retryCount) != null ? c : "0",
                unpublished_content_type: a == null ? void 0 : a.unpublishedContentType
            }
        })
    }

    function o(a, b) {
        c("ComposerPostFailureFalcoEvent").log(function() {
            var c;
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                error_details: a == null ? void 0 : a.errorDescription,
                error_info: a == null ? void 0 : a.errorInfo,
                is_edit_composer: a == null ? void 0 : a.isEditComposer,
                payload: a == null ? void 0 : a.payload,
                retry_count: (c = a == null ? void 0 : a.retryCount) != null ? c : "0",
                unpublished_content_type: a == null ? void 0 : a.unpublishedContentType
            }
        })
    }

    function p(a, b) {
        c("ComposerPostCancelFalcoEvent").log(function() {
            return {
                cancel_source: a == null ? void 0 : a.cancelSource,
                creation_session_id: b
            }
        })
    }

    function q(a, b) {
        c("ComposerPostTerminalFalcoEvent").log(function() {
            var c;
            return {
                creation_session_id: b,
                terminal_reason: (c = a == null ? void 0 : a.terminalReason) != null ? c : ""
            }
        })
    }

    function r(a, b) {
        c("ComposerPostServerContentRenderedFalcoEvent").log(function() {
            var c;
            return {
                composer_entry_picker: a == null ? void 0 : a.composerEntryPicker,
                composer_entry_point_name: a == null ? void 0 : a.composerEntryPointName,
                composer_source_surface: a == null ? void 0 : a.composerSourceSurface,
                composer_type: a == null ? void 0 : a.composerType,
                creation_session_id: b,
                destination: (c = a == null ? void 0 : a.destination) != null ? c : "",
                is_edit_composer: a == null ? void 0 : a.isEditComposer
            }
        })
    }

    function s(a, b) {
        var d = a == null ? void 0 : a.publishFlowOptimisticStep;
        if (d == null) return;
        var e = {
            creation_session_id: b,
            publish_flow: d
        };
        (d === "CREATE_OPTIMISTIC_RESPONSE" || d === "INSERT_OPTIMISTIC_POST") && (e = babelHelpers["extends"]({}, e, {
            debug_info: JSON.stringify({
                type_of_optimistic_post: a == null ? void 0 : a.typeOfOptimisticPost
            })
        }));
        c("ComposerPublishFlowFalcoEvent").log(function() {
            return e
        })
    }

    function t(a) {
        if (a.fields && a.fields.payload != null) {
            var b = a.fields.payload.qplEvent;
            b != null && h.onReady(function(b) {
                return b(a)
            })
        }
    }
    g["default"] = a
}), 98);
__d("composerCometCardedDialogProps", [], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        anchor: {
            minHeight: "x1xoerdy"
        }
    };
    b = {
        anchorXStyle: a.anchor,
        size: "content"
    };
    g["default"] = b
}), 98);
__d("useCometComposerEntryPointDialog", ["fbt", "CometCardedDialogLegacy.react", "FeedComposerCometGlimmer.react", "cometComposerLogger", "composerCometCardedDialogProps", "react", "useCometEntryPointDialog", "uuid"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    b = d("react");
    var j = b.useCallback,
        k = b.useRef,
        l = {
            withCloseButton: !0
        };

    function m(a) {
        return i.jsx("div", {
            children: i.jsx(c("CometCardedDialogLegacy.react"), babelHelpers["extends"]({
                title: a.title
            }, c("composerCometCardedDialogProps"), a, {
                children: i.jsx(c("FeedComposerCometGlimmer.react"), {})
            }))
        })
    }
    m.displayName = m.name + " [from " + f.id + "]";

    function a(a) {
        var b = a || {},
            d = b.composerEntryPointName,
            e = b.composerSourceSurface,
            f = b.composerDialogEntryPoint,
            g = b.composerType,
            n = b.disableClosingWithMask,
            o = b.onBeforeClose,
            p = b.onClose,
            q = b.onCloseWithoutSave,
            r = b.onSaveError,
            s = b.onSubmit,
            t = b.reactionType,
            u = b.storyID,
            v = b.profileID,
            w = b.title,
            x = w === void 0 ? h._("Create post") : w,
            y = b.tracePolicy,
            z = b.renderLocation;
        w = k(null);
        b = c("useCometEntryPointDialog")(f, {
            composerType: g,
            profileID: v,
            reactionType: t,
            storyID: u
        }, "button", function(a) {
            return i.jsx(m, babelHelpers["extends"]({
                onClose: a,
                title: x
            }, l))
        }, {
            queryIsCheap_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: !0
        });
        var A = b[0];
        t = b[1];
        u = b[2];
        b = b[3];
        var B = j(function(b) {
                a != null && a.onSave != null && (a.onSave && a.onSave(b))
            }, [a]),
            C = j(function(a) {
                var b, h;
                a = a || {};
                var i = a.beginningViewState;
                a = a.pushedPageOnLoad;
                b = (b = i == null ? void 0 : i.creationSessionID) != null ? b : c("uuid")();
                h = {
                    composerEntryPointName: d,
                    composerSourceSurface: e,
                    composerType: (h = g) != null ? h : f.root.getModuleId()
                };
                h = {
                    fields: h,
                    type: "COMPOSER_ENTRY"
                };
                c("cometComposerLogger")(h, b);
                A(babelHelpers["extends"]({
                    beginningViewState: babelHelpers["extends"]({}, i, {
                        creationSessionID: b
                    }),
                    composerEntryPointName: d,
                    composerSourceSurface: e,
                    composerType: g,
                    disableClosingWithMask: n,
                    onBeforeClose: o,
                    onCloseWithoutSave: q,
                    onSave: B,
                    onSaveError: r,
                    onSubmit: s,
                    profileID: v,
                    pushedPageOnLoad: a,
                    renderLocation: z,
                    title: x
                }, l), p, y)
            }, [f.root, d, e, g, n, o, p, q, B, r, s, v, z, A, x, y]);
        return [C, w, t, u, b]
    }
    g["default"] = a
}), 98);
__d("createEmptyCometComposerViewState", ["uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return a != null ? a : {
            audience: {},
            creationSessionID: c("uuid")(),
            editorState: babelHelpers["extends"]({
                __type: "plain-text",
                hasFocus: !1,
                isComposing: !1,
                isPendingSelection: !1,
                selectionOffsets: null,
                text: ""
            }, b)
        }
    }
    g["default"] = a
}), 98);
__d("FeedComposerCometDialog.entrypoint", ["FeedComposerCometRootQuery$Parameters", "JSResourceForInteraction", "WebPixelRatio"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        getPreloadProps: function(a) {
            var c = a.profileID;
            a = a.storyID;
            return {
                queries: {
                    composerQueryReference: {
                        options: {
                            fetchPolicy: "store-or-network"
                        },
                        parameters: b("FeedComposerCometRootQuery$Parameters"),
                        variables: {
                            hasStory: a != null && a !== "",
                            privacySelectorRenderLocation: "COMET_COMPOSER",
                            profileID: c,
                            scale: d("WebPixelRatio").get(),
                            storyID: (c = a) != null ? c : ""
                        }
                    }
                }
            }
        },
        root: c("JSResourceForInteraction")("FeedComposerCometDialog.react").__setRef("FeedComposerCometDialog.entrypoint")
    };
    g["default"] = a
}), 98);
__d("useFeedComposerCometDialog", ["cr:1810733"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:1810733")
}), 98);
__d("useFeedComposerCometDialogImplementation.good", ["FeedComposerCometDialog.entrypoint", "useCometComposerEntryPointDialog"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        return c("useCometComposerEntryPointDialog")(babelHelpers["extends"]({}, a, {
            composerDialogEntryPoint: c("FeedComposerCometDialog.entrypoint")
        }))
    }
    g["default"] = a
}), 98);
__d("useFeedComposerCometDialogImplementation", ["cr:404"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:404")
}), 98);
__d("CometAsyncFetchError", [], (function(a, b, c, d, e, f) {
    "use strict";

    function g(a) {
        if (a == null) return "";
        if (typeof a === "string") return a;
        try {
            return String.fromCharCode.apply(null, new Uint16Array(a))
        } catch (a) {
            return "<error parsing ArrayBuffer>"
        }
    }
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d, e, f) {
            var g;
            g = a.call(this, b) || this;
            g.errorMsg = b;
            g.errorCode = c;
            g.errorRawResponseHeaders = d;
            g.errorRawTransport = e;
            g.errorType = f;
            return g
        }
        var c = b.prototype;
        c.toString = function() {
            var a;
            a = ((a = this.errorCode) != null ? a : "") + "." + g(this.errorMsg) + "." + ((a = this.errorRawResponseHeaders) != null ? a : "") + "." + ((a = this.errorRawTransport) != null ? a : "") + "." + ((a = this.errorType) != null ? a : "") + "." + ((a = this.errorRawTransportStatus) != null ? a : "");
            return "CometAyncFetchError: " + a
        };
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f["default"] = a
}), 66);
__d("cometAsyncRequestHeaders", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = [];

    function a() {
        return g.reduce(function(a, b) {
            b = b();
            return Object.assign(b, a)
        }, {})
    }

    function b(a) {
        g.push(a)
    }
    f.getHeaders = a;
    f.registerHeaderProvider = b
}), 66);
__d("cometAsyncFetch", ["CSRFGuard", "CometAsyncFetchError", "ConstUriUtils", "DTSG", "DTSG_ASYNC", "NetworkStatus", "PHPQuerySerializer", "Promise", "XHRRequest", "cometAsyncRequestHeaders", "getAsyncParams", "handleCometErrorCodeSideEffects", "isFacebookURI", "isInternalFBURI", "isMessengerDotComURI", "isWorkplaceDotComURI", "recoverableViolation", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 250;

    function a(a, e) {
        e === void 0 && (e = {
            data: {},
            method: "GET"
        });
        var f = 0,
            g;
        return new(b("Promise"))(function(b, k) {
            var l;

            function m(f) {
                if (e.ignoreResponse === !0) return b();
                var g;
                f = f.trim();
                try {
                    d("CSRFGuard").exists(f) && (f = d("CSRFGuard").clean(f)), g = JSON.parse(f)
                } catch (b) {
                    c("recoverableViolation")('Unable to parse uri "' + a.toString() + '" response. ' + (b == null ? void 0 : b.message), "comet_infra");
                    k(b);
                    return
                }
                if (j(a)) {
                    var h;
                    f = (f = g) == null ? void 0 : f.dtsgToken;
                    h = (h = g) == null ? void 0 : h.dtsgAsyncGetToken;
                    f && d("DTSG").setToken(f);
                    h && d("DTSG_ASYNC").setToken(h)
                }
                if (g.error) {
                    c("handleCometErrorCodeSideEffects")(g.error, g.errorSummary, g.errorDescription, g.redirectTo, e.shouldShowErrorDialog);
                    k({
                        error: g.error,
                        errorMsg: g.errorDescription,
                        errorType: g.errorSummary,
                        redirectTo: g.redirectTo
                    });
                    return
                }
                if (((f = e) == null ? void 0 : f.getFullPayload) === !0) {
                    b(g);
                    return
                }
                b((h = g) == null ? void 0 : h.payload)
            }

            function n(a) {
                var b = e.retryCount != null && e.retryCount > 0 && f <= e.retryCount;
                if (b) c("setTimeout")(p, h);
                else {
                    b = new(c("CometAsyncFetchError"))(a.errorMsg, a.errorCode, a.errorRawResponseHeaders, a.errorRawTransport, a.errorType);
                    return k(b)
                }
            }

            function o() {
                var b = new(c("CometAsyncFetchError"))("Request to " + a + " was aborted", null, null, null, "Abort");
                return k(b)
            }

            function p() {
                var a;
                if (((a = e.abortSignal) == null ? void 0 : a.aborted) === !0) return o();
                q();
                r()
            }

            function q() {
                l != null && (l.abort(), l = null)
            }

            function r() {
                var b, g = (b = e.requestHeaders) != null ? b : {};
                Object.assign(g, d("cometAsyncRequestHeaders").getHeaders());
                b = Object.keys(g).reduce(function(a, b) {
                    return a.setRequestHeader(b, g[b])
                }, new(c("XHRRequest"))(a)).setMethod(e.method).setData(babelHelpers["extends"]({}, e.data, c("getAsyncParams")(e.method))).setRawData(e.formData).setResponseHandler(m).setErrorHandler(n).setAbortHandler(o).setUploadProgressHandler(e.onUploadProgress).setDataSerializer(c("PHPQuerySerializer").serialize);
                l = b;
                e.withCredentials === !0 && i(a) && b.setWithCredentials(!0);
                b.send();
                f++
            }
            e.abortSignal && (e.abortSignal.onabort = function() {
                q()
            });
            c("NetworkStatus").isOnline() ? p() : g = c("NetworkStatus").onChange(function(a) {
                a = a.online;
                a && (p(), g.remove())
            })
        })
    }

    function i(a) {
        a = d("ConstUriUtils").getUri(a);
        return a == null ? !1 : c("isFacebookURI")(a) || c("isInternalFBURI")(a) || c("isMessengerDotComURI")(a) || c("isWorkplaceDotComURI")(a)
    }

    function j(a) {
        a = d("ConstUriUtils").getUri(a);
        if (a == null) return !1;
        return !a.getProtocol() && !a.getDomain() ? !0 : document.location.origin === a.getOrigin()
    }
    g["default"] = a
}), 98);
__d("PresenceContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext({
        chatVisibility: !1
    });
    g["default"] = b
}), 98);
__d("CometSSREntrypoint", ["objectValues", "relay-runtime"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a) {
        var b, c = d("relay-runtime").__internal.withProvidedVariables(a.variables, a.parameters.params.providedVariables);
        return {
            actor_id: (b = (b = a.environmentProviderOptions) == null ? void 0 : b.actorID) != null ? b : null,
            id: a.parameters.params.id,
            name: a.parameters.params.name,
            ssr_boundary: (a = (b = a.environmentProviderOptions) == null ? void 0 : b.ssrBoundary) != null ? a : null,
            variables: c
        }
    }

    function i(a, b) {
        b = a.getPreloadProps(b);
        var d = b.entryPoints;
        b = b.queries;
        b = (b = b) != null ? b : {};
        var e = c("objectValues")(b).filter(function(a) {
                return a != null
            }),
            f = [a.root.getModuleId()];
        if (d != null) {
            b = Object.keys(d);
            b.forEach(function(a) {
                a = d[a];
                if (a == null) return;
                var b = a.entryPoint;
                a = a.entryPointParams;
                b = i(b, a);
                e = e.concat(b.queries);
                f = f.concat(b.roots)
            })
        }
        return {
            queries: e,
            roots: f
        }
    }

    function a(a, b) {
        a = i(a, b);
        b = a.queries;
        return b.map(h)
    }

    function b(a) {
        a = a.map(function(a) {
            return i(a.entryPoint, a.entryPointParams)
        });
        return a.map(function(a) {
            var b = a.queries;
            a = a.roots;
            return {
                quries: b.map(h),
                roots: a
            }
        })
    }

    function e(a, b) {
        a = i(a, b);
        b = a.queries;
        a = a.roots;
        return {
            queries: b.map(h),
            roots: a
        }
    }

    function f() {
        throw new Error("This function should not be called. It exists solely for the type-generation")
    }

    function j(a, b) {
        var d;
        a = a.map(function(a) {
            return i(a.entryPoint, a.entryPointParams)
        });
        a = a.map(function(a) {
            var b = a.queries;
            a = a.roots;
            return {
                queries: b.map(h),
                roots: a
            }
        });
        d = c("objectValues")((d = b == null ? void 0 : b.getDisplayQueries()) != null ? d : {}).filter(function(a) {
            return a != null
        }).map(h);
        b = c("objectValues")((b = b == null ? void 0 : b.getDeferredQueries()) != null ? b : {}).filter(function(a) {
            return a != null
        }).map(h);
        return {
            appshellQueries: {
                deferred: b,
                display: d
            },
            routeObjects: a
        }
    }
    g.processRootEntryPoint = a;
    g.processRootEntryPoints = b;
    g.processRootEntryPointData = e;
    g.preloadQuery = f;
    g.processServerEntryPoints = j
}), 98);
__d("XCometMessengerControllerRouteBuilder", ["jsExtraRouteBuilder"], (function(a, b, c, d, e, f, g) {
    a = c("jsExtraRouteBuilder")("/messages/t/{?thread_key}/{?*extra_junk}/", Object.freeze({
        initial_e2ee_toggle_position: !1
    }), ["/messages/archived/new/", "/messages/e2ee/t/{?thread_key}/", "/messages/filtered/", "/messages/filtered/new/", "/messages/filtered/t/{?thread_key}/", "/messages/gallery/", "/messages/groups/", "/messages/groups/new/", "/messages/groups/t/{?thread_key}/", "/messages/people/", "/messages/people/new/", "/messages/people/t/{?thread_key}/", "/messages/requests/new/", "/messages/new/", "/messages/read/", "/messages/search/", "/messages/search/t/{?thread_key}/", "/messages/search/new/"], void 0);
    b = a;
    g["default"] = b
}), 98);
__d("LSPresenceStatus", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        OFFLINE: 1,
        ACTIVE: 2
    });
    f["default"] = a
}), 66);
__d("CometRouteReferrerContext", ["react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = a.createContext();
    g["default"] = b
}), 98);
__d("useRouteReferrer", ["CometRouteReferrerContext", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useContext;

    function a() {
        return h(c("CometRouteReferrerContext"))
    }
    g["default"] = a
}), 98);