if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("createFeedCometMentionsDataEntryWithTagSuggestion_data.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            kind: "RootArgument",
            name: "scale"
        }],
        kind: "Fragment",
        metadata: {
            mask: !1
        },
        name: "createFeedCometMentionsDataEntryWithTagSuggestion_data",
        selections: [{
            alias: null,
            args: null,
            concreteType: "User",
            kind: "LinkedField",
            name: "node",
            plural: !1,
            selections: [{
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "name",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }, {
                    alias: "photo",
                    args: [{
                        kind: "Literal",
                        name: "height",
                        value: 40
                    }, {
                        kind: "Variable",
                        name: "scale",
                        variableName: "scale"
                    }, {
                        kind: "Literal",
                        name: "width",
                        value: 40
                    }],
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "profile_picture",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "uri",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "Profile",
                abstractKey: "__isProfile"
            }],
            storageKey: null
        }],
        type: "SuggestedWithTagsEdge",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("createFeedCometMentionsDataEntryWithTag_data.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            kind: "RootArgument",
            name: "scale"
        }],
        kind: "Fragment",
        metadata: {
            mask: !1
        },
        name: "createFeedCometMentionsDataEntryWithTag_data",
        selections: [{
            alias: null,
            args: null,
            concreteType: "User",
            kind: "LinkedField",
            name: "node",
            plural: !1,
            selections: [{
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "name",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }, {
                    alias: "photo",
                    args: [{
                        kind: "Literal",
                        name: "height",
                        value: 40
                    }, {
                        kind: "Variable",
                        name: "scale",
                        variableName: "scale"
                    }, {
                        kind: "Literal",
                        name: "width",
                        value: 40
                    }],
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "profile_picture",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "uri",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "Profile",
                abstractKey: "__isProfile"
            }],
            storageKey: null
        }],
        type: "FriendsEdge",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("createFeedCometMentionsDataEntry_data.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            b = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mentions_subtext",
                storageKey: null
            },
            c = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_verified",
                storageKey: null
            },
            d = {
                alias: "photo",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 40
                }, {
                    kind: "Variable",
                    name: "scale",
                    variableName: "scale"
                }, {
                    kind: "Literal",
                    name: "width",
                    value: 40
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "uri",
                    storageKey: null
                }],
                storageKey: null
            },
            e = {
                alias: null,
                args: null,
                concreteType: "WorkForeignEntityInfo",
                kind: "LinkedField",
                name: "work_foreign_entity_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }],
                storageKey: null
            },
            f = [a, b, d];
        return {
            argumentDefinitions: [{
                kind: "RootArgument",
                name: "scale"
            }],
            kind: "Fragment",
            metadata: {
                mask: !1
            },
            name: "createFeedCometMentionsDataEntry_data",
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "score",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "icon_shape",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "node",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [a, b, c, d, {
                        kind: "InlineFragment",
                        selections: [{
                            kind: "InlineFragment",
                            selections: [e],
                            type: "User",
                            abstractKey: null
                        }, {
                            kind: "InlineFragment",
                            selections: [e, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "is_multi_company_group",
                                storageKey: null
                            }],
                            type: "Group",
                            abstractKey: null
                        }],
                        type: "Entity",
                        abstractKey: "__isEntity"
                    }],
                    type: "User",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: f,
                    type: "XFBWorkroomsBaseUser",
                    abstractKey: "__isXFBWorkroomsBaseUser"
                }, {
                    kind: "InlineFragment",
                    selections: f,
                    type: "Group",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: f,
                    type: "Event",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [a, b, c, d],
                    type: "Page",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [a, d],
                    type: "ContextualProfile",
                    abstractKey: "__isContextualProfile"
                }, {
                    kind: "InlineFragment",
                    selections: f,
                    type: "GroupRule",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: f,
                    type: "ProductItem",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: f,
                    type: "BatchMentions",
                    abstractKey: null
                }],
                storageKey: null
            }],
            type: "CometComposerTypeaheadResultEntry",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("createFeedCometMentionsDataEntry_profile.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            kind: "RootArgument",
            name: "scale"
        }],
        kind: "Fragment",
        metadata: {
            mask: !1
        },
        name: "createFeedCometMentionsDataEntry_profile",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "name",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: "photo",
            args: [{
                kind: "Literal",
                name: "height",
                value: 40
            }, {
                kind: "Variable",
                name: "scale",
                variableName: "scale"
            }, {
                kind: "Literal",
                name: "width",
                value: 40
            }],
            concreteType: "Image",
            kind: "LinkedField",
            name: "profile_picture",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "uri",
                storageKey: null
            }],
            storageKey: null
        }],
        type: "Profile",
        abstractKey: "__isProfile"
    };
    e.exports = a
}), null);
__d("useFeedComposerCometMentionsBootloadDataSourceQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6017483851596315"
}), null);
__d("useFeedComposerCometMentionsBootloadDataSourceQuery.graphql", ["useFeedComposerCometMentionsBootloadDataSourceQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "include_viewer"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "options"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "typeahead_context"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "types"
            }],
            c = [{
                kind: "Variable",
                name: "include_viewer",
                variableName: "include_viewer"
            }, {
                kind: "Variable",
                name: "options",
                variableName: "options"
            }, {
                kind: "Variable",
                name: "typeahead_context",
                variableName: "typeahead_context"
            }, {
                kind: "Variable",
                name: "types",
                variableName: "types"
            }],
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "score",
                storageKey: null
            },
            e = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "icon_shape",
                storageKey: null
            },
            f = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            g = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mentions_subtext",
                storageKey: null
            },
            i = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_verified",
                storageKey: null
            },
            j = {
                alias: "photo",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 40
                }, {
                    kind: "Variable",
                    name: "scale",
                    variableName: "scale"
                }, {
                    kind: "Literal",
                    name: "width",
                    value: 40
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "uri",
                    storageKey: null
                }],
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                concreteType: "WorkForeignEntityInfo",
                kind: "LinkedField",
                name: "work_foreign_entity_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }],
                storageKey: null
            };
        k = {
            kind: "InlineFragment",
            selections: [g, h, i, j, {
                kind: "InlineFragment",
                selections: [{
                    kind: "InlineFragment",
                    selections: [k],
                    type: "User",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [k, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_multi_company_group",
                        storageKey: null
                    }],
                    type: "Group",
                    abstractKey: null
                }],
                type: "Entity",
                abstractKey: "__isEntity"
            }],
            type: "User",
            abstractKey: null
        };
        var l = [g, h, j],
            m = {
                kind: "InlineFragment",
                selections: l,
                type: "XFBWorkroomsBaseUser",
                abstractKey: "__isXFBWorkroomsBaseUser"
            },
            n = {
                kind: "InlineFragment",
                selections: l,
                type: "Group",
                abstractKey: null
            },
            o = {
                kind: "InlineFragment",
                selections: l,
                type: "Event",
                abstractKey: null
            };
        h = {
            kind: "InlineFragment",
            selections: [g, h, i, j],
            type: "Page",
            abstractKey: null
        };
        i = {
            kind: "InlineFragment",
            selections: [g, j],
            type: "ContextualProfile",
            abstractKey: "__isContextualProfile"
        };
        g = {
            kind: "InlineFragment",
            selections: l,
            type: "GroupRule",
            abstractKey: null
        };
        j = {
            kind: "InlineFragment",
            selections: l,
            type: "ProductItem",
            abstractKey: null
        };
        l = {
            kind: "InlineFragment",
            selections: l,
            type: "BatchMentions",
            abstractKey: null
        };
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "useFeedComposerCometMentionsBootloadDataSourceQuery",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: "CometComposerTypeaheadResultEntry",
                    kind: "LinkedField",
                    name: "comet_composer_typeahead_bootload",
                    plural: !0,
                    selections: [d, e, {
                        alias: null,
                        args: null,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "node",
                        plural: !1,
                        selections: [f, k, m, n, o, h, i, g, j, l],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "useFeedComposerCometMentionsBootloadDataSourceQuery",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: "CometComposerTypeaheadResultEntry",
                    kind: "LinkedField",
                    name: "comet_composer_typeahead_bootload",
                    plural: !0,
                    selections: [d, e, {
                        alias: null,
                        args: null,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "node",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "__typename",
                            storageKey: null
                        }, f, k, m, n, o, h, i, g, j, l],
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("useFeedComposerCometMentionsBootloadDataSourceQuery_facebookRelayOperation"),
                metadata: {},
                name: "useFeedComposerCometMentionsBootloadDataSourceQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useFeedComposerCometMentionsNetworkDataSourceQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "6629905233696681"
}), null);
__d("useFeedComposerCometMentionsNetworkDataSourceQuery.graphql", ["useFeedComposerCometMentionsNetworkDataSourceQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "count"
            },
            c = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "enable_type_selection"
            },
            d = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "include_viewer"
            },
            e = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "query"
            },
            f = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            },
            g = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "typeahead_context"
            },
            h = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "types"
            },
            i = [{
                kind: "Variable",
                name: "count",
                variableName: "count"
            }, {
                kind: "Variable",
                name: "enable_type_selection",
                variableName: "enable_type_selection"
            }, {
                kind: "Variable",
                name: "include_viewer",
                variableName: "include_viewer"
            }, {
                kind: "Variable",
                name: "query",
                variableName: "query"
            }, {
                kind: "Variable",
                name: "typeahead_context",
                variableName: "typeahead_context"
            }, {
                kind: "Variable",
                name: "types",
                variableName: "types"
            }],
            j = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "score",
                storageKey: null
            },
            l = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "icon_shape",
                storageKey: null
            },
            m = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            n = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            o = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mentions_subtext",
                storageKey: null
            },
            p = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_verified",
                storageKey: null
            },
            q = {
                alias: "photo",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 40
                }, {
                    kind: "Variable",
                    name: "scale",
                    variableName: "scale"
                }, {
                    kind: "Literal",
                    name: "width",
                    value: 40
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "uri",
                    storageKey: null
                }],
                storageKey: null
            },
            r = {
                alias: null,
                args: null,
                concreteType: "WorkForeignEntityInfo",
                kind: "LinkedField",
                name: "work_foreign_entity_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }],
                storageKey: null
            };
        r = {
            kind: "InlineFragment",
            selections: [n, o, p, q, {
                kind: "InlineFragment",
                selections: [{
                    kind: "InlineFragment",
                    selections: [r],
                    type: "User",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [r, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_multi_company_group",
                        storageKey: null
                    }],
                    type: "Group",
                    abstractKey: null
                }],
                type: "Entity",
                abstractKey: "__isEntity"
            }],
            type: "User",
            abstractKey: null
        };
        var s = [n, o, q],
            t = {
                kind: "InlineFragment",
                selections: s,
                type: "XFBWorkroomsBaseUser",
                abstractKey: "__isXFBWorkroomsBaseUser"
            },
            u = {
                kind: "InlineFragment",
                selections: s,
                type: "Group",
                abstractKey: null
            },
            v = {
                kind: "InlineFragment",
                selections: s,
                type: "Event",
                abstractKey: null
            };
        o = {
            kind: "InlineFragment",
            selections: [n, o, p, q],
            type: "Page",
            abstractKey: null
        };
        p = {
            kind: "InlineFragment",
            selections: [n, q],
            type: "ContextualProfile",
            abstractKey: "__isContextualProfile"
        };
        n = {
            kind: "InlineFragment",
            selections: s,
            type: "GroupRule",
            abstractKey: null
        };
        q = {
            kind: "InlineFragment",
            selections: s,
            type: "ProductItem",
            abstractKey: null
        };
        s = {
            kind: "InlineFragment",
            selections: s,
            type: "BatchMentions",
            abstractKey: null
        };
        var w = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "cache_id",
                storageKey: null
            },
            x = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "label",
                storageKey: null
            },
            y = {
                kind: "InlineFragment",
                selections: [w, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "types_to_show",
                    storageKey: null
                }, x, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "icon_name",
                    storageKey: null
                }],
                type: "XFBMentionsTypeSelectionEntry",
                abstractKey: null
            };
        w = {
            kind: "InlineFragment",
            selections: [w, x],
            type: "XFBMentionsTypeResetEntry",
            abstractKey: null
        };
        return {
            fragment: {
                argumentDefinitions: [a, c, d, e, f, g, h],
                kind: "Fragment",
                metadata: null,
                name: "useFeedComposerCometMentionsNetworkDataSourceQuery",
                selections: [{
                    alias: null,
                    args: i,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "comet_composer_typeahead_search",
                    plural: !0,
                    selections: [j, {
                        kind: "InlineFragment",
                        selections: [k, l, {
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "node",
                            plural: !1,
                            selections: [m, r, t, u, v, o, p, n, q, s],
                            storageKey: null
                        }],
                        type: "CometComposerTypeaheadResultEntry",
                        abstractKey: null
                    }, y, w],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [c, a, d, e, f, g, h],
                kind: "Operation",
                name: "useFeedComposerCometMentionsNetworkDataSourceQuery",
                selections: [{
                    alias: null,
                    args: i,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "comet_composer_typeahead_search",
                    plural: !0,
                    selections: [j, {
                        kind: "InlineFragment",
                        selections: [k, l, {
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "node",
                            plural: !1,
                            selections: [j, m, r, t, u, v, o, p, n, q, s],
                            storageKey: null
                        }],
                        type: "CometComposerTypeaheadResultEntry",
                        abstractKey: null
                    }, y, w],
                    storageKey: null
                }]
            },
            params: {
                id: b("useFeedComposerCometMentionsNetworkDataSourceQuery_facebookRelayOperation"),
                metadata: {},
                name: "useFeedComposerCometMentionsNetworkDataSourceQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("useFeedComposerCometMentionsNullstateDataSourceQuery_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5264758830314161"
}), null);
__d("useFeedComposerCometMentionsNullstateDataSourceQuery.graphql", ["useFeedComposerCometMentionsNullstateDataSourceQuery_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "count"
            }, {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            }],
            c = [{
                kind: "Variable",
                name: "count",
                variableName: "count"
            }, {
                kind: "Literal",
                name: "query",
                value: ""
            }, {
                kind: "Literal",
                name: "typeahead_context",
                value: "mentions"
            }],
            d = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "score",
                storageKey: null
            },
            e = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "icon_shape",
                storageKey: null
            },
            f = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            g = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "mentions_subtext",
                storageKey: null
            },
            i = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_verified",
                storageKey: null
            },
            j = {
                alias: "photo",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 40
                }, {
                    kind: "Variable",
                    name: "scale",
                    variableName: "scale"
                }, {
                    kind: "Literal",
                    name: "width",
                    value: 40
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "uri",
                    storageKey: null
                }],
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                concreteType: "WorkForeignEntityInfo",
                kind: "LinkedField",
                name: "work_foreign_entity_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "type",
                    storageKey: null
                }],
                storageKey: null
            };
        k = {
            kind: "InlineFragment",
            selections: [g, h, i, j, {
                kind: "InlineFragment",
                selections: [{
                    kind: "InlineFragment",
                    selections: [k],
                    type: "User",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [k, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_multi_company_group",
                        storageKey: null
                    }],
                    type: "Group",
                    abstractKey: null
                }],
                type: "Entity",
                abstractKey: "__isEntity"
            }],
            type: "User",
            abstractKey: null
        };
        var l = [g, h, j],
            m = {
                kind: "InlineFragment",
                selections: l,
                type: "XFBWorkroomsBaseUser",
                abstractKey: "__isXFBWorkroomsBaseUser"
            },
            n = {
                kind: "InlineFragment",
                selections: l,
                type: "Group",
                abstractKey: null
            },
            o = {
                kind: "InlineFragment",
                selections: l,
                type: "Event",
                abstractKey: null
            };
        h = {
            kind: "InlineFragment",
            selections: [g, h, i, j],
            type: "Page",
            abstractKey: null
        };
        i = {
            kind: "InlineFragment",
            selections: [g, j],
            type: "ContextualProfile",
            abstractKey: "__isContextualProfile"
        };
        g = {
            kind: "InlineFragment",
            selections: l,
            type: "GroupRule",
            abstractKey: null
        };
        j = {
            kind: "InlineFragment",
            selections: l,
            type: "ProductItem",
            abstractKey: null
        };
        l = {
            kind: "InlineFragment",
            selections: l,
            type: "BatchMentions",
            abstractKey: null
        };
        var p = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "__typename",
            storageKey: null
        };
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "useFeedComposerCometMentionsNullstateDataSourceQuery",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "comet_composer_typeahead_search",
                    plural: !0,
                    selections: [{
                        kind: "InlineFragment",
                        selections: [d, e, {
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "node",
                            plural: !1,
                            selections: [f, k, m, n, o, h, i, g, j, l],
                            storageKey: null
                        }],
                        type: "CometComposerTypeaheadResultEntry",
                        abstractKey: null
                    }],
                    storageKey: null
                }],
                type: "Query",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "useFeedComposerCometMentionsNullstateDataSourceQuery",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "comet_composer_typeahead_search",
                    plural: !0,
                    selections: [p, {
                        kind: "InlineFragment",
                        selections: [d, e, {
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "node",
                            plural: !1,
                            selections: [p, f, k, m, n, o, h, i, g, j, l],
                            storageKey: null
                        }],
                        type: "CometComposerTypeaheadResultEntry",
                        abstractKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("useFeedComposerCometMentionsNullstateDataSourceQuery_facebookRelayOperation"),
                metadata: {},
                name: "useFeedComposerCometMentionsNullstateDataSourceQuery",
                operationKind: "query",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("UFI2TypingIndicatorImpl_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [],
        kind: "Fragment",
        metadata: null,
        name: "UFI2TypingIndicatorImpl_feedback",
        selections: [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "id",
            storageKey: null
        }, {
            alias: null,
            args: null,
            concreteType: "FeedbackTypersConnection",
            kind: "LinkedField",
            name: "feedback_typers",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "other_count",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "subscription_target_id",
            storageKey: null
        }],
        type: "Feedback",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("UFI2TypingIndicator_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        argumentDefinitions: [{
            kind: "RootArgument",
            name: "feedbackSource"
        }],
        kind: "Fragment",
        metadata: null,
        name: "UFI2TypingIndicator_feedback",
        selections: [{
            alias: null,
            args: [{
                kind: "Variable",
                name: "feedback_source_integer",
                variableName: "feedbackSource"
            }],
            kind: "ScalarField",
            name: "is_eligible_for_real_time_updates",
            storageKey: null
        }, {
            args: null,
            kind: "FragmentSpread",
            name: "UFI2TypingIndicatorImpl_feedback"
        }],
        type: "Feedback",
        abstractKey: null
    };
    e.exports = a
}), null);
__d("UFI2BanActorMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5240442952714853"
}), null);
__d("UFI2BanActorMutation.graphql", ["UFI2BanActorMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "data",
                    variableName: "input"
                }],
                concreteType: "FeedbackPageBanResponsePayload",
                kind: "LinkedField",
                name: "feedback_page_ban",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "__typename",
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "UFI2BanActorMutation",
                selections: c,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "UFI2BanActorMutation",
                selections: c
            },
            params: {
                id: b("UFI2BanActorMutation_facebookRelayOperation"),
                metadata: {},
                name: "UFI2BanActorMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("UFI2BlockActorMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "7275841115819585"
}), null);
__d("UFI2BlockActorMutation.graphql", ["UFI2BlockActorMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "data",
                    variableName: "input"
                }],
                concreteType: "UserBlockResponsePayload",
                kind: "LinkedField",
                name: "user_block",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "BlockedUser",
                    kind: "LinkedField",
                    name: "user",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "id",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "UFI2BlockActorMutation",
                selections: c,
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "UFI2BlockActorMutation",
                selections: c
            },
            params: {
                id: b("UFI2BlockActorMutation_facebookRelayOperation"),
                metadata: {},
                name: "UFI2BlockActorMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("UFI2FeedbackReactMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5022982034416543"
}), null);
__d("UFI2FeedbackReactMutation.graphql", ["UFI2FeedbackReactMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            },
            c = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            },
            d = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "useDefaultActor"
            },
            e = [{
                kind: "Variable",
                name: "data",
                variableName: "input"
            }],
            f = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "detection_analytics_enabled",
                storageKey: null
            },
            g = [{
                kind: "Variable",
                name: "use_default_actor",
                variableName: "useDefaultActor"
            }],
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "key",
                storageKey: null
            },
            i = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            j = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            l = {
                alias: "i18n_reaction_count",
                args: null,
                kind: "ScalarField",
                name: "reaction_count_reduced",
                storageKey: null
            },
            m = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "count",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: [a, c, d],
                kind: "Fragment",
                metadata: null,
                name: "UFI2FeedbackReactMutation",
                selections: [{
                    alias: null,
                    args: e,
                    concreteType: "FeedbackReactResponsePayload",
                    kind: "LinkedField",
                    name: "feedback_react",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "Feedback",
                        kind: "LinkedField",
                        name: "feedback",
                        plural: !1,
                        selections: [{
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2ReactionActionLink_feedback"
                        }, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2ReactionsCount_feedback"
                        }, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2CommentTopReactions_feedback"
                        }, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2CommentTopReactionsWrapper_feedback"
                        }, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2TopReactions_feedback"
                        }, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2FeedbackReactMutation_feedback"
                        }],
                        storageKey: null
                    }, f],
                    storageKey: null
                }],
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [a, d, c],
                kind: "Operation",
                name: "UFI2FeedbackReactMutation",
                selections: [{
                    alias: null,
                    args: e,
                    concreteType: "FeedbackReactResponsePayload",
                    kind: "LinkedField",
                    name: "feedback_react",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "Feedback",
                        kind: "LinkedField",
                        name: "feedback",
                        plural: !1,
                        selections: [{
                            alias: null,
                            args: g,
                            kind: "ScalarField",
                            name: "can_viewer_react",
                            storageKey: null
                        }, {
                            alias: null,
                            args: g,
                            concreteType: "FeedbackReactionInfo",
                            kind: "LinkedField",
                            name: "viewer_feedback_reaction_info",
                            plural: !1,
                            selections: [h, i, j],
                            storageKey: null
                        }, i, {
                            alias: null,
                            args: g,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "viewer_actor",
                            plural: !1,
                            selections: [j, i, k],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "FeedbackReaction",
                            kind: "LinkedField",
                            name: "supported_reactions",
                            plural: !0,
                            selections: [h, i],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "Video",
                            kind: "LinkedField",
                            name: "associated_video",
                            plural: !1,
                            selections: [i],
                            storageKey: null
                        }, {
                            alias: null,
                            args: [{
                                kind: "Literal",
                                name: "orderby",
                                value: ["COUNT_DESC", "REACTION_TYPE"]
                            }],
                            concreteType: "TopReactionsConnection",
                            kind: "LinkedField",
                            name: "top_reactions",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: "TopReactionsEdge",
                                kind: "LinkedField",
                                name: "edges",
                                plural: !0,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "reaction_count",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    concreteType: "FeedbackReactionInfo",
                                    kind: "LinkedField",
                                    name: "node",
                                    plural: !1,
                                    selections: [h, i, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "reaction_type",
                                        storageKey: null
                                    }, {
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "localized_name",
                                        storageKey: null
                                    }],
                                    storageKey: null
                                }, l],
                                storageKey: null
                            }, m],
                            storageKey: 'top_reactions(orderby:["COUNT_DESC","REACTION_TYPE"])'
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "ReactorsOfContentConnection",
                            kind: "LinkedField",
                            name: "reactors",
                            plural: !1,
                            selections: [m, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "is_empty",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "count_reduced",
                                storageKey: null
                            }],
                            storageKey: null
                        }, l, {
                            alias: null,
                            args: [{
                                kind: "Literal",
                                name: "first",
                                value: 2
                            }],
                            concreteType: "ImportantReactorsConnection",
                            kind: "LinkedField",
                            name: "important_reactors",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "nodes",
                                plural: !0,
                                selections: [j, k, i],
                                storageKey: null
                            }],
                            storageKey: "important_reactors(first:2)"
                        }, {
                            alias: "reaction_count",
                            args: null,
                            concreteType: "ReactorsOfContentConnection",
                            kind: "LinkedField",
                            name: "reactors",
                            plural: !1,
                            selections: [m],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "ReactionDisplayConfig",
                            kind: "LinkedField",
                            name: "reaction_display_config",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "reaction_display_strategy",
                                storageKey: null
                            }],
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "should_show_top_reactions",
                            storageKey: null
                        }, {
                            alias: "can_see_top_custom_reactions_on_comment",
                            args: null,
                            concreteType: "Feedback",
                            kind: "LinkedField",
                            name: "if_viewer_can_render_group_custom_reactions",
                            plural: !1,
                            selections: [{
                                args: null,
                                documentName: "CometUFICommentTopReactions_feedback",
                                fragmentName: "CometUFICommentCustomTopReactions_feedback",
                                fragmentPropName: "feedback",
                                kind: "ModuleImport"
                            }, i],
                            storageKey: null
                        }, {
                            alias: "cannot_see_top_custom_reactions_on_comment",
                            args: null,
                            concreteType: "Feedback",
                            kind: "LinkedField",
                            name: "if_viewer_cannot_render_group_custom_reactions",
                            plural: !1,
                            selections: [{
                                args: null,
                                documentName: "CometUFICommentTopReactions_feedback__cannot_use_group_custom_reactions",
                                fragmentName: "CometUFIClassicCommentTopReactions_feedback",
                                fragmentPropName: "feedback",
                                kind: "ModuleImport"
                            }, i],
                            storageKey: null
                        }],
                        storageKey: null
                    }, f],
                    storageKey: null
                }]
            },
            params: {
                id: b("UFI2FeedbackReactMutation_facebookRelayOperation"),
                metadata: {},
                name: "UFI2FeedbackReactMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("UFI2FeedbackReactMutation_feedback.graphql", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "key",
            storageKey: null
        }];
        return {
            argumentDefinitions: [{
                kind: "RootArgument",
                name: "useDefaultActor"
            }],
            kind: "Fragment",
            metadata: {
                mask: !1
            },
            name: "UFI2FeedbackReactMutation_feedback",
            selections: [{
                alias: null,
                args: null,
                concreteType: "Video",
                kind: "LinkedField",
                name: "associated_video",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "orderby",
                    value: ["COUNT_DESC", "REACTION_TYPE"]
                }],
                concreteType: "TopReactionsConnection",
                kind: "LinkedField",
                name: "top_reactions",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "TopReactionsEdge",
                    kind: "LinkedField",
                    name: "edges",
                    plural: !0,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "reaction_count",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: "FeedbackReactionInfo",
                        kind: "LinkedField",
                        name: "node",
                        plural: !1,
                        selections: a,
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: 'top_reactions(orderby:["COUNT_DESC","REACTION_TYPE"])'
            }, {
                alias: null,
                args: null,
                concreteType: "ReactorsOfContentConnection",
                kind: "LinkedField",
                name: "reactors",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "count",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_empty",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: [{
                    kind: "Variable",
                    name: "use_default_actor",
                    variableName: "useDefaultActor"
                }],
                concreteType: "FeedbackReactionInfo",
                kind: "LinkedField",
                name: "viewer_feedback_reaction_info",
                plural: !1,
                selections: a,
                storageKey: null
            }],
            type: "Feedback",
            abstractKey: null
        }
    }();
    e.exports = a
}), null);
__d("UFI2UnhideCommentMutation_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5827891760567790"
}), null);
__d("UFI2UnhideCommentMutation.graphql", ["UFI2UnhideCommentMutation_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "feedLocation"
            },
            c = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            },
            d = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "isComet"
            },
            e = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "useDefaultActor"
            },
            f = [{
                kind: "Variable",
                name: "data",
                variableName: "input"
            }],
            g = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "spam_display_mode",
                storageKey: null
            },
            i = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_hidden_by_viewer",
                storageKey: null
            },
            j = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_hidden_by_content_owner",
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            l = [{
                kind: "Variable",
                name: "feed_location",
                variableName: "feedLocation"
            }],
            m = {
                alias: null,
                args: l,
                kind: "ScalarField",
                name: "comment_menu_tooltip",
                storageKey: null
            };
        return {
            fragment: {
                argumentDefinitions: [a, c, d, e],
                kind: "Fragment",
                metadata: null,
                name: "UFI2UnhideCommentMutation",
                selections: [{
                    alias: null,
                    args: f,
                    concreteType: "CommentUnhideResponsePayload",
                    kind: "LinkedField",
                    name: "comment_unhide",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "Comment",
                        kind: "LinkedField",
                        name: "comment",
                        plural: !1,
                        selections: [g, h, i, j, {
                            args: null,
                            kind: "FragmentSpread",
                            name: "UFI2CommentMenu_comment"
                        }, {
                            condition: "isComet",
                            kind: "Condition",
                            passingValue: !0,
                            selections: [{
                                args: null,
                                kind: "FragmentSpread",
                                name: "CometUFICommentMenu_comment"
                            }]
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "Mutation",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [c, d, a, e],
                kind: "Operation",
                name: "UFI2UnhideCommentMutation",
                selections: [{
                    alias: null,
                    args: f,
                    concreteType: "CommentUnhideResponsePayload",
                    kind: "LinkedField",
                    name: "comment_unhide",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "Comment",
                        kind: "LinkedField",
                        name: "comment",
                        plural: !1,
                        selections: [g, h, i, j, {
                            condition: "isComet",
                            kind: "Condition",
                            passingValue: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "legacy_fbid",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "author",
                                plural: !1,
                                selections: [k, g, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "name",
                                    storageKey: null
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                concreteType: "GroupCommentInfo",
                                kind: "LinkedField",
                                name: "group_comment_info",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "is_author_muted",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "group_id",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "can_viewer_report_comment_to_admin_with_tags",
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "can_viewer_block_author",
                                    storageKey: null
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "legacy_token",
                                storageKey: null
                            }, m, {
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "comment_menu_items",
                                plural: !0,
                                selections: [k, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        alias: null,
                                        args: null,
                                        kind: "ScalarField",
                                        name: "show_remove_content_options",
                                        storageKey: null
                                    }],
                                    type: "CommentMenuItemDeleteAndRemoveMember",
                                    abstractKey: null
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "is_author_banned_by_content_owner",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                concreteType: "Feedback",
                                kind: "LinkedField",
                                name: "parent_feedback",
                                plural: !1,
                                selections: [g, {
                                    alias: null,
                                    args: [{
                                        kind: "Variable",
                                        name: "use_default_actor",
                                        variableName: "useDefaultActor"
                                    }],
                                    concreteType: "Page",
                                    kind: "LinkedField",
                                    name: "viewer_acts_as_page",
                                    plural: !1,
                                    selections: [g],
                                    storageKey: null
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "create_detailed_report_uri",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "us_structured_reporting_enabled",
                                storageKey: null
                            }]
                        }, {
                            condition: "isComet",
                            kind: "Condition",
                            passingValue: !0,
                            selections: [m, {
                                alias: null,
                                args: l,
                                kind: "ScalarField",
                                name: "should_show_comment_menu",
                                storageKey: null
                            }, {
                                alias: "items",
                                args: l,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "comment_menu_items",
                                plural: !0,
                                selections: [k, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemMarkAsFavorite_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemMarkAsAuthorsFavorite",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemRemoveTag_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemRemoveTag",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemDelete_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemDelete",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemDeleteAndRemoveMember_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemDeleteAndRemoveMember",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemSetMemberContentControls_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemSetMemberContentControls",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemDivider_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemDivider",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemEdit_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemEdit",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemReportToAdmins_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemReportToAdmins",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemReply_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemReply",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemGiveFeedbackOrReport_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemGiveFeedbackOrReport",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemCreateDetailedReport_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemCreateDetailedReport",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemHide_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemHide",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemUnhide_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemUnhide",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemBanCommenter_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBanCommenter",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemMuteMember_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemMuteMember",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemRemoveWithFeedback_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemRemoveWithFeedback",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemPublishVidwallaOverlay_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemPublishVidwallaOverlay",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemVidwallaSaveGraphic_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemVidwallaSaveGraphic",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemBanCommenterFromLiveVideoStream_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBanCommenterFromLiveVideoStream",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemBanCommenterFromPage_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBanCommenterFromPage",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemMuteCommenterForFifteenMinutes_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemMuteCommenterForFifteenMinutes",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemMuteCommenterForThirtyMinutes_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemMuteCommenterForThirtyMinutes",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemMuteCommenterForSixtyMinutes_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemMuteCommenterForSixtyMinutes",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemBanFromPage_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBanCommenterFromPageWithCommunityRules",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemBanCommenterFromAllLiveVideoStreams_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBanCommenterFromAllLiveStreamsWithCommunityRules",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemDelete_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemGFIDelete",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemBanCommenterFromLiveVideoStream_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBanCommenterFromLiveVideoStreamWithCommunityRules",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemMuteCommenter_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemMuteCommenterWithCommunityRules",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemReportToModerator_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemReportToModerator",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemAddAsModerator_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemAddAsModerator",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GFICommentMenuItemPinComment_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemPinComment",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemAdminPinComment_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemAdminPinComment",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemAdminUnpinComment_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemAdminUnpinComment",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemBlockCommenter_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBlockCommenter",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemBulletinBlockCommenter_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemBulletinBlockCommenter",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemFishbowlInviteGuest_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemFishbowlInviteGuest",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemFishbowlRemoveGuest_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemFishbowlRemoveGuest",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemFishbowlLeaveConversation_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemFishbowlLeaveConversation",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemFishbowlSpotlightComment_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemFishbowlSpotlightComment",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemResolveInlineAnnotation_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemResolveInlineAnnotation",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemCreateDebugConflictAlert_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemCreateDebugConflictAlert",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemDisableReplies_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemDisableReplies",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemEnableReplies_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemEnableReplies",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemCopyLink_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemCopyLink",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemStoreInMemento_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemStoreInMemento",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "LiveVideoEngageQuestionMenuItemDelete_questionMenuItem",
                                        fragmentPropName: "questionMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "LiveVideoEngageQuestionMenuItemDelete",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "CometUFICommentMenuItemOpenDebugger_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemOpenDebugger",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [{
                                        args: null,
                                        documentName: "CometUFICommentMenu_comment",
                                        fragmentName: "GeminiUFICommentMenuItemEditWPAMACommentType_commentMenuItem",
                                        fragmentPropName: "commentMenuItem",
                                        kind: "ModuleImport"
                                    }],
                                    type: "CommentMenuItemWPEnhancedAMAEditBadge",
                                    abstractKey: null
                                }],
                                storageKey: null
                            }, {
                                kind: "ClientExtension",
                                selections: [{
                                    alias: null,
                                    args: null,
                                    kind: "ScalarField",
                                    name: "optimistic_action",
                                    storageKey: null
                                }]
                            }]
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("UFI2UnhideCommentMutation_facebookRelayOperation"),
                metadata: {},
                name: "UFI2UnhideCommentMutation",
                operationKind: "mutation",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("UFI2CreateCommentSubscription_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "8791040777580566"
}), null);
__d("UFI2CreateCommentSubscription.graphql", ["CometTextWithEntitiesRelay_textWithEntities$normalization.graphql", "UFI2CreateCommentSubscription_facebookRelayOperation"], (function(aa, ba, ca, da, ea, fa) {
    "use strict";
    aa = function() {
        var aa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "UFI2CommentsProvider_commentsKey"
            },
            ca = {
                defaultValue: !0,
                kind: "LocalArgument",
                name: "containerIsFeedStory"
            },
            da = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "containerIsLiveStory"
            },
            ea = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "containerIsTahoe"
            },
            fa = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "containerIsWorkplace"
            },
            ga = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextEnableComment"
            },
            ha = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextIsAdPreview"
            },
            ia = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextIsAggregatedShare"
            },
            ja = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsContextIsStorySet"
            },
            ka = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "displayCommentsFeedbackContext"
            },
            la = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "feedLocation"
            },
            ma = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "feedbackSource"
            },
            na = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "focusCommentID"
            },
            oa = {
                defaultValue: !1,
                kind: "LocalArgument",
                name: "includeNestedComments"
            },
            pa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            },
            qa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "isComet"
            },
            ra = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "scale"
            },
            sa = {
                defaultValue: null,
                kind: "LocalArgument",
                name: "useDefaultActor"
            },
            ta = [{
                kind: "Variable",
                name: "data",
                variableName: "input"
            }],
            a = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "id",
                storageKey: null
            },
            ua = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "count",
                storageKey: null
            },
            b = [ua],
            va = {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [a, {
                    alias: null,
                    args: null,
                    concreteType: "DisplayCommentsConnection",
                    kind: "LinkedField",
                    name: "display_comments",
                    plural: !1,
                    selections: b,
                    storageKey: null
                }],
                storageKey: null
            },
            wa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "cursor",
                storageKey: null
            },
            xa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "page_number",
                storageKey: null
            },
            ya = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "label",
                storageKey: null
            },
            c = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "name",
                storageKey: null
            },
            d = {
                kind: "Variable",
                name: "scale",
                variableName: "scale"
            },
            e = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "uri",
                storageKey: null
            },
            f = [e],
            za = {
                alias: "profile_picture_depth_0",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 32
                }, d, {
                    kind: "Literal",
                    name: "width",
                    value: 32
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: f,
                storageKey: null
            },
            Aa = [{
                kind: "Literal",
                name: "height",
                value: 24
            }, d, {
                kind: "Literal",
                name: "width",
                value: 24
            }],
            Ba = {
                alias: "profile_picture_depth_1",
                args: Aa,
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: f,
                storageKey: null
            },
            Ca = [{
                kind: "Variable",
                name: "includeNestedComments",
                variableName: "includeNestedComments"
            }],
            Da = {
                alias: "threading_depth",
                args: null,
                kind: "ScalarField",
                name: "depth",
                storageKey: null
            },
            g = [a],
            Ea = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "reply_parent_comment",
                plural: !1,
                selections: g,
                storageKey: null
            },
            Fa = {
                alias: null,
                args: null,
                concreteType: "XFBCommunityCommentSignalRenderer",
                kind: "LinkedField",
                name: "community_comment_signal_renderer",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometCommunityCommentSignalRenderer_comment",
                    fragmentName: "CometCommunityCommentSignalBubble_renderer",
                    fragmentPropName: "renderer",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            h = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "__typename",
                storageKey: null
            },
            Ga = {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "supported",
                    value: ["StoryAttachmentAnimatedImageShareStyleRenderer", "StoryAttachmentDonationStyleRenderer", "StoryAttachmentFallbackStyleRenderer", "StoryAttachmentPhotoStyleRenderer", "StoryAttachmentStickerStyleRenderer", "StoryAttachmentStickerAvatarStyleRenderer", "StoryAttachmentVideoAutoplayStyleRenderer", "StoryAttachmentVideoStyleRenderer", "StoryAttachmentTipJarPaymentStyleRenderer", "StoryAttachmentCommentPlaceInfoStyleRenderer", "StoryAttachmentChatCommandStyleRenderer", "StoryAttachmentPageInCommentStyleRenderer", "StoryAttachmentInstantGamesTournamentActivityStyleRenderer", "StoryAttachmentInstantGamesUpdateCommentStyleRenderer", "StoryAttachmentSubscriptionGiftStyleRenderer", "StoryAttachmentFactsInCommentsCommentStyleRenderer", "StoryAttachmentDataSnapshotStyleRenderer", "StoryAttachmentCommunityAwardStyleRenderer"]
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "style_type_renderer",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentAnimatedImageShareAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentAnimatedImageShareStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentDonationAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentDonationStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentFallbackAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentFallbackStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentImageAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentPhotoStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentStickerAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentStickerStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentStickerAvatarAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentStickerAvatarStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentVideoAutoplayAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentVideoAutoplayStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentVideoAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentVideoStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentTipJarPaymentAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentTipJarPaymentStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentPlaceInfoAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentCommentPlaceInfoStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentChatCommandAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentChatCommandStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentPageInCommentAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentPageInCommentStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentInstantGamesTournamentActivityAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentInstantGamesTournamentActivityStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentInstantGamesUpdateCommentAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentInstantGamesUpdateCommentStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFISubscriptionGiftingAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentSubscriptionGiftStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFIFactsInCommentsAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentFactsInCommentsCommentStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentDataSnapshotAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentDataSnapshotStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometFeedStoryUFICommentAttachment_attachment",
                        fragmentName: "CometUFICommentCommunityAwardAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentCommunityAwardStyleRenderer",
                    abstractKey: null
                }],
                storageKey: 'style_type_renderer(supported:["StoryAttachmentAnimatedImageShareStyleRenderer","StoryAttachmentDonationStyleRenderer","StoryAttachmentFallbackStyleRenderer","StoryAttachmentPhotoStyleRenderer","StoryAttachmentStickerStyleRenderer","StoryAttachmentStickerAvatarStyleRenderer","StoryAttachmentVideoAutoplayStyleRenderer","StoryAttachmentVideoStyleRenderer","StoryAttachmentTipJarPaymentStyleRenderer","StoryAttachmentCommentPlaceInfoStyleRenderer","StoryAttachmentChatCommandStyleRenderer","StoryAttachmentPageInCommentStyleRenderer","StoryAttachmentInstantGamesTournamentActivityStyleRenderer","StoryAttachmentInstantGamesUpdateCommentStyleRenderer","StoryAttachmentSubscriptionGiftStyleRenderer","StoryAttachmentFactsInCommentsCommentStyleRenderer","StoryAttachmentDataSnapshotStyleRenderer","StoryAttachmentCommunityAwardStyleRenderer"])'
            },
            Ha = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "style_list",
                storageKey: null
            },
            i = {
                kind: "Variable",
                name: "feed_location",
                variableName: "feedLocation"
            },
            j = [i],
            Ia = {
                alias: null,
                args: j,
                kind: "ScalarField",
                name: "comment_menu_tooltip",
                storageKey: null
            },
            Ja = {
                alias: null,
                args: j,
                kind: "ScalarField",
                name: "should_show_comment_menu",
                storageKey: null
            },
            k = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "url",
                storageKey: null
            },
            l = [k],
            Ka = {
                kind: "InlineFragment",
                selections: l,
                type: "Entity",
                abstractKey: "__isEntity"
            },
            La = {
                kind: "TypeDiscriminator",
                abstractKey: "__isActor"
            },
            Ma = {
                alias: null,
                args: null,
                concreteType: "WorkUserInfo",
                kind: "LinkedField",
                name: "work_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_active_account",
                    storageKey: null
                }],
                storageKey: null
            },
            Na = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_verified",
                storageKey: null
            },
            Oa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "short_name",
                storageKey: null
            },
            Pa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "subscribe_status",
                storageKey: null
            },
            Qa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "gender",
                storageKey: null
            },
            Ra = {
                kind: "ClientExtension",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "availability",
                    storageKey: null
                }]
            },
            m = {
                alias: "www_url",
                args: [{
                    kind: "Literal",
                    name: "site",
                    value: "www"
                }],
                kind: "ScalarField",
                name: "url",
                storageKey: 'url(site:"www")'
            },
            Sa = [{
                kind: "Literal",
                name: "height",
                value: 20
            }, d, {
                kind: "Literal",
                name: "width",
                value: 20
            }],
            Ta = {
                alias: "profile_picture_depth_1_legacy",
                args: Sa,
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: f,
                storageKey: null
            },
            n = [m],
            Ua = {
                kind: "InlineFragment",
                selections: n,
                type: "Application",
                abstractKey: null
            },
            Va = {
                kind: "InlineFragment",
                selections: n,
                type: "Event",
                abstractKey: null
            },
            Wa = {
                kind: "InlineFragment",
                selections: n,
                type: "Group",
                abstractKey: null
            },
            Xa = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_weak_reference",
                storageKey: null
            },
            Ya = {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "comment_action_links_renderer",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFICommentActionLinks_comment",
                        fragmentName: "CometUFICommentActionLinksExperimental_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "XFBCommentActionLinksRendererExperimental",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: [{
                            kind: "Literal",
                            name: "CometUFICommentActionLinksStable_renderer$translationType",
                            value: "ORIGINAL"
                        }],
                        documentName: "CometUFICommentActionLinks_comment",
                        fragmentName: "CometUFICommentActionLinksStable_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "XFBCommentActionLinksRendererStable",
                    abstractKey: null
                }],
                storageKey: null
            },
            Za = [{
                kind: "Literal",
                name: "translation_type",
                value: "ORIGINAL"
            }],
            $a = {
                args: null,
                fragment: ba("CometTextWithEntitiesRelay_textWithEntities$normalization.graphql"),
                kind: "FragmentSpread"
            },
            o = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "text",
                storageKey: null
            },
            p = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "length",
                storageKey: null
            },
            q = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "offset",
                storageKey: null
            },
            ab = {
                alias: null,
                args: null,
                concreteType: "DelightAtRange",
                kind: "LinkedField",
                name: "delight_ranges",
                plural: !0,
                selections: [h, {
                    alias: null,
                    args: null,
                    concreteType: "TextDelightCampaign",
                    kind: "LinkedField",
                    name: "campaign",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: [{
                            kind: "Literal",
                            name: "delight_surface",
                            value: "COMMENT"
                        }],
                        concreteType: "TextDelightStylePair",
                        kind: "LinkedField",
                        name: "delight_styles",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "style",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "value",
                            storageKey: null
                        }],
                        storageKey: 'delight_styles(delight_surface:"COMMENT")'
                    }, a],
                    storageKey: null
                }, p, q],
                storageKey: null
            },
            r = {
                kind: "InlineFragment",
                selections: g,
                type: "Node",
                abstractKey: "__isNode"
            },
            s = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "entity_is_weak_reference",
                storageKey: null
            },
            bb = {
                alias: null,
                args: null,
                concreteType: "EntityAtRange",
                kind: "LinkedField",
                name: "ranges",
                plural: !0,
                selections: [h, {
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "entity",
                    plural: !1,
                    selections: [h, {
                        condition: "isComet",
                        kind: "Condition",
                        passingValue: !0,
                        selections: [{
                            alias: null,
                            args: [{
                                kind: "Literal",
                                name: "site",
                                value: "comet"
                            }],
                            kind: "ScalarField",
                            name: "url",
                            storageKey: 'url(site:"comet")'
                        }]
                    }, {
                        condition: "isComet",
                        kind: "Condition",
                        passingValue: !1,
                        selections: n
                    }, r, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "can_skip_redirect",
                            storageKey: null
                        }],
                        type: "ExternalUrl",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: [{
                            alias: null,
                            args: null,
                            kind: "ScalarField",
                            name: "time_index",
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "Video",
                            kind: "LinkedField",
                            name: "video",
                            plural: !1,
                            selections: g,
                            storageKey: null
                        }],
                        type: "VideoTimeIndex",
                        abstractKey: null
                    }],
                    storageKey: null
                }, s, p, q],
                storageKey: null
            },
            cb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "translation_type",
                storageKey: null
            },
            db = {
                alias: "body_renderer",
                args: Za,
                concreteType: null,
                kind: "LinkedField",
                name: "preferred_body",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFICommentTextBodyRenderer_comment",
                        fragmentName: "CometUFICommentBodyTextWithEntities_textWithEntities",
                        fragmentPropName: "textWithEntities",
                        kind: "ModuleImport"
                    }],
                    type: "TextWithEntities",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFICommentTextBodyRenderer_comment",
                        fragmentName: "CometUFICommentBodyComposedTextWithEntities_composedTextWithEntities",
                        fragmentPropName: "composedTextWithEntities",
                        kind: "ModuleImport"
                    }],
                    type: "FBMarkdownCommentBody",
                    abstractKey: null
                }],
                storageKey: 'preferred_body(translation_type:"ORIGINAL")'
            },
            eb = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "comment_parent",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "author",
                    plural: !1,
                    selections: [h, c, {
                        kind: "InlineFragment",
                        selections: [Oa],
                        type: "User",
                        abstractKey: null
                    }, a],
                    storageKey: null
                }, a],
                storageKey: null
            },
            fb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_declined_by_group_admin_assistant",
                storageKey: null
            },
            gb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_gaming_video_comment",
                storageKey: null
            },
            hb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "timestamp_in_video",
                storageKey: null
            },
            ib = {
                alias: null,
                args: null,
                concreteType: "PostTranslatability",
                kind: "LinkedField",
                name: "translatability_for_viewer",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "source_dialect",
                    storageKey: null
                }],
                storageKey: null
            },
            jb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "written_while_video_was_live",
                storageKey: null
            },
            kb = {
                alias: null,
                args: null,
                concreteType: "GroupCommentInfo",
                kind: "LinkedField",
                name: "group_comment_info",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFICommentActorLink_comment_groups",
                    fragmentName: "CometUFIGroupCommentActorLink_groupCommentInfo",
                    fragmentPropName: "groupCommentInfo",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            lb = {
                alias: null,
                args: j,
                concreteType: "BizWebCommentInfo",
                kind: "LinkedField",
                name: "bizweb_comment_info",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFICommentActorLink_comment_bizweb",
                    fragmentName: "BizWebFBCommentAuthorLink_bizWebCommentInfo",
                    fragmentPropName: "bizWebCommentInfo",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            mb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_actor_viewable",
                storageKey: null
            },
            nb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_constituent_badge",
                storageKey: null
            },
            ob = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_see_subsribe_button",
                storageKey: null
            },
            pb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_see_constituent_badge_upsell",
                storageKey: null
            },
            qb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "legacy_token",
                storageKey: null
            },
            t = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "share_fbid",
                storageKey: null
            },
            u = {
                alias: null,
                args: null,
                concreteType: "PoliticalOffice",
                kind: "LinkedField",
                name: "political_office",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "generic_title",
                    storageKey: null
                }, a],
                storageKey: null
            },
            rb = {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "parent_feedback",
                plural: !1,
                selections: [a, t, {
                    alias: null,
                    args: null,
                    concreteType: "PoliticalFigureData",
                    kind: "LinkedField",
                    name: "political_figure_data",
                    plural: !1,
                    selections: [c, u, a],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "owning_profile",
                    plural: !1,
                    selections: [h, c, a],
                    storageKey: null
                }],
                storageKey: null
            },
            sb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "question_and_answer_type",
                storageKey: null
            },
            tb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_original_poster",
                storageKey: null
            },
            ub = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_viewer_comment_poster",
                storageKey: null
            },
            vb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_bot",
                storageKey: null
            },
            wb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_non_coworker",
                storageKey: null
            },
            xb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_subscribe_to_bulletin_creator",
                storageKey: null
            },
            yb = {
                alias: null,
                args: null,
                concreteType: "VoicesCreator",
                kind: "LinkedField",
                name: "bulletin_creator",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "VoicesPublication",
                    kind: "LinkedField",
                    name: "publication",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "publication_absolute_url",
                        storageKey: null
                    }, a, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "publication_name",
                        storageKey: null
                    }],
                    storageKey: null
                }, a],
                storageKey: null
            },
            zb = {
                alias: null,
                args: j,
                concreteType: null,
                kind: "LinkedField",
                name: "author_user_signals_renderer",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentActorUserSignalsRenderer_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentActorUserSignalsRenderer",
                    abstractKey: null
                }],
                storageKey: null
            },
            Ab = {
                alias: null,
                args: [i, {
                    kind: "Literal",
                    name: "supported",
                    value: ["CometUFICommentActorConstituentBadge", "CometUFICommentActorVerifiedBadge", "CometUFICommentActorUserSignalsRenderer", "CometUFICommentActorAMAQuestionAnswerBadge", "CometUFICommentInlineFollowCTARenderer", "GeminiUFICommentActorDeactivatedAccountBadge", "GeminiUFICommentActorBotBadge", "GeminiUFICommentActorNonCoworkerBadge", "CometUFICommentPostAuthorBadge", "GeminiUFICommentQAAnswerBadge", "GeminiUFICommentQASocialAnswerBadge", "GeminiUFICommentActorWPEnhancedAMAQuestionAnswerBadge", "CometUFICommentWorkplaceFileMarkerBadge", "CometUFICommentWorkKnowledgeEditorBadge"]
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "author_badge_renderers",
                plural: !0,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentActorConstituentBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentActorConstituentBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentActorVerifiedBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentActorVerifiedBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentActorUserSignalsRenderer_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentActorUserSignalsRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentActorAMAQuestionAnswerBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentActorAMAQuestionAnswerBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentInlineFollowCTARenderer_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentInlineFollowCTARenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "GeminiUFICommentActorDeactivatedAccountBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "GeminiUFICommentActorDeactivatedAccountBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "GeminiUFICommentActorBotBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "GeminiUFICommentActorBotBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "GeminiUFICommentActorNonCoworkerBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "GeminiUFICommentActorNonCoworkerBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentPostAuthorBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentPostAuthorBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "GeminiUFICommentQAAnswerBadge_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "GeminiUFICommentQAAnswerBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "GeminiUFICommentQASocialAnswerBadge_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "GeminiUFICommentQASocialAnswerBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "GeminiUFICommentActorEnhancedAMAQuestionAnswerBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "GeminiUFICommentActorWPEnhancedAMAQuestionAnswerBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentWorkplaceFileMarkerBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentWorkplaceFileMarkerBadge",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "useCometUFICommentActorLinkBadges_comment",
                        fragmentName: "CometUFICommentWorkKnowledgeEditorBadge3DWrapper_badge",
                        fragmentPropName: "badge",
                        kind: "ModuleImport"
                    }],
                    type: "CometUFICommentWorkKnowledgeEditorBadge",
                    abstractKey: null
                }],
                storageKey: null
            },
            v = {
                alias: "grey_badge_asset",
                args: null,
                kind: "ScalarField",
                name: "badge_asset",
                storageKey: null
            },
            w = {
                alias: "dark_mode_badge_asset",
                args: null,
                kind: "ScalarField",
                name: "information_asset_dark_mode_v2",
                storageKey: null
            },
            x = {
                alias: "light_mode_badge_asset",
                args: null,
                kind: "ScalarField",
                name: "information_asset_v2",
                storageKey: null
            },
            y = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_earned",
                storageKey: null
            },
            z = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "information_title",
                storageKey: null
            },
            A = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "information_description",
                storageKey: null
            },
            Bb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_enabled",
                storageKey: null
            },
            B = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_manageable",
                storageKey: null
            },
            C = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "serialized",
                storageKey: null
            },
            D = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "identity_badge_type",
                storageKey: null
            },
            E = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "information_button_enabled",
                storageKey: null
            },
            F = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "information_button_uri",
                storageKey: null
            },
            G = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "information_button_text",
                storageKey: null
            },
            H = {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "tier_info",
                plural: !1,
                selections: [h, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "tier_name",
                    storageKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "stars_sent_this_week",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "stars_threshold_for_next_tier",
                        storageKey: null
                    }],
                    type: "TipperBadgeTierInfo",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "supporter_age_for_progress_bar",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "supporter_threshold_for_next_tier",
                        storageKey: null
                    }],
                    type: "WoodhengeBadgeTierInfo",
                    abstractKey: null
                }],
                storageKey: null
            },
            Cb = {
                alias: null,
                args: j,
                concreteType: "IdentityBadge",
                kind: "LinkedField",
                name: "identity_badges_web",
                plural: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "badge_asset",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "multiple_badge_asset",
                    storageKey: null
                }, o, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "text_gradient",
                    storageKey: null
                }, v, w, x, y, z, A, Bb, B, C, D, E, F, G, H, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "gaming_video_image_uri",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "gaming_video_dark_mode_image_uri",
                    storageKey: null
                }],
                storageKey: null
            },
            Db = {
                alias: null,
                args: j,
                kind: "ScalarField",
                name: "can_show_multiple_identity_badges",
                storageKey: null
            };
        v = {
            alias: null,
            args: null,
            concreteType: "IdentityBadge",
            kind: "LinkedField",
            name: "discoverable_identity_badges_web",
            plural: !0,
            selections: [v, w, x, y, z, A, Bb, B, C, D, E, F, G, H],
            storageKey: null
        };
        w = {
            alias: null,
            args: null,
            concreteType: "User",
            kind: "LinkedField",
            name: "user",
            plural: !1,
            selections: [c, {
                alias: null,
                args: null,
                concreteType: "Image",
                kind: "LinkedField",
                name: "profile_picture",
                plural: !1,
                selections: f,
                storageKey: null
            }, a],
            storageKey: null
        };
        x = [{
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "video_channel_is_viewer_following",
            storageKey: null
        }];
        y = {
            kind: "InlineFragment",
            selections: g,
            type: "GenericAttachmentMedia",
            abstractKey: null
        };
        z = {
            kind: "InlineFragment",
            selections: g,
            type: "MontageImage",
            abstractKey: null
        };
        A = {
            kind: "InlineFragment",
            selections: g,
            type: "MontageVideo",
            abstractKey: null
        };
        Bb = {
            alias: null,
            args: null,
            concreteType: "StoryAttachment",
            kind: "LinkedField",
            name: "attachments",
            plural: !0,
            selections: [{
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "media",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [a, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "is_live_streaming",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "broadcast_duration",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "playable_duration",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        concreteType: null,
                        kind: "LinkedField",
                        name: "owner",
                        plural: !1,
                        selections: [h, {
                            kind: "InlineFragment",
                            selections: [{
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "actor_to_follow",
                                plural: !1,
                                selections: [h, a, {
                                    kind: "InlineFragment",
                                    selections: x,
                                    type: "Page",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: x,
                                    type: "User",
                                    abstractKey: null
                                }],
                                storageKey: null
                            }, c],
                            type: "VideoOwner",
                            abstractKey: "__isVideoOwner"
                        }, a],
                        storageKey: null
                    }],
                    type: "Video",
                    abstractKey: null
                }, r, y, z, A],
                storageKey: null
            }],
            storageKey: null
        };
        B = {
            alias: "comment_count",
            args: null,
            concreteType: "TopLevelCommentsConnection",
            kind: "LinkedField",
            name: "top_level_comments",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "total_count",
                storageKey: null
            }],
            storageKey: null
        };
        C = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "work_ama_answer_status",
            storageKey: null
        };
        D = {
            alias: null,
            args: null,
            concreteType: "WorkKnowledgeInlineAnnotationCommentBadgeRenderer",
            kind: "LinkedField",
            name: "work_knowledge_inline_annotation_comment_badge_renderer",
            plural: !1,
            selections: [{
                args: null,
                documentName: "CometUFICommentBody_comment_work_knowledge_inline_annotation_comment_badge_renderer",
                fragmentName: "CometUFICommentBodyInlineAnnotationBadgeWrapper_workKnowledgeInlineAnnotationCommentBadgeRenderer",
                fragmentPropName: "workKnowledgeInlineAnnotationCommentBadgeRenderer",
                kind: "ModuleImport"
            }],
            storageKey: null
        };
        E = {
            alias: null,
            args: null,
            concreteType: "XFBBusinessCommentAttribute",
            kind: "LinkedField",
            name: "business_comment_attributes",
            plural: !0,
            selections: [{
                args: null,
                documentName: "CometUFICommentBody_comment_business_comment_attributes",
                fragmentName: "BizWebBusinessCommentBadge_businessCommentAttributes",
                fragmentPropName: "businessCommentAttributes",
                kind: "ModuleImport"
            }, a],
            storageKey: null
        };
        F = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_live_video_comment",
            storageKey: null
        };
        G = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "created_time",
            storageKey: null
        };
        H = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "can_viewer_disable_preview",
            storageKey: null
        };
        x = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "translation_available_for_viewer",
            storageKey: null
        };
        var Eb = {
                args: null,
                documentName: "CometUFIComment_comment",
                fragmentName: "CometUFICommentQualitySurvey_inlineSurveyConfig",
                fragmentPropName: "inlineSurveyConfig",
                kind: "ModuleImport"
            },
            Fb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "legacy_fbid",
                storageKey: null
            },
            Gb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "spam_display_mode",
                storageKey: null
            },
            I = [h, a],
            Hb = {
                alias: null,
                args: null,
                concreteType: "Story",
                kind: "LinkedField",
                name: "attached_story",
                plural: !1,
                selections: I,
                storageKey: null
            },
            Ib = {
                kind: "InlineFragment",
                selections: [Qa],
                type: "User",
                abstractKey: null
            },
            Jb = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "comment_direct_parent",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "author",
                    plural: !1,
                    selections: [h, c, Ib, a],
                    storageKey: null
                }, a],
                storageKey: null
            },
            Kb = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "if_viewer_can_see_member_page_tooltip",
                plural: !1,
                selections: I,
                storageKey: null
            },
            Lb = {
                alias: null,
                args: null,
                concreteType: "ReactorsOfContentConnection",
                kind: "LinkedField",
                name: "reactors",
                plural: !1,
                selections: [ua, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "count_reduced",
                    storageKey: null
                }],
                storageKey: null
            },
            Mb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "should_show_top_reactions",
                storageKey: null
            },
            Nb = {
                alias: "can_see_top_custom_reactions_on_comment",
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "if_viewer_can_render_group_custom_reactions",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFICommentTopReactions_feedback",
                    fragmentName: "CometUFICommentCustomTopReactions_feedback",
                    fragmentPropName: "feedback",
                    kind: "ModuleImport"
                }, a],
                storageKey: null
            },
            Ob = {
                alias: "cannot_see_top_custom_reactions_on_comment",
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "if_viewer_cannot_render_group_custom_reactions",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFICommentTopReactions_feedback__cannot_use_group_custom_reactions",
                    fragmentName: "CometUFIClassicCommentTopReactions_feedback",
                    fragmentPropName: "feedback",
                    kind: "ModuleImport"
                }, a],
                storageKey: null
            },
            J = {
                kind: "Variable",
                name: "use_default_actor",
                variableName: "useDefaultActor"
            },
            K = [J],
            L = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "key",
                storageKey: null
            },
            M = [L, a],
            Pb = {
                alias: null,
                args: K,
                concreteType: "FeedbackReactionInfo",
                kind: "LinkedField",
                name: "viewer_feedback_reaction_info",
                plural: !1,
                selections: M,
                storageKey: null
            };
        L = {
            alias: null,
            args: [{
                kind: "Literal",
                name: "orderby",
                value: ["COUNT_DESC", "REACTION_TYPE"]
            }],
            concreteType: "TopReactionsConnection",
            kind: "LinkedField",
            name: "top_reactions",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                concreteType: "TopReactionsEdge",
                kind: "LinkedField",
                name: "edges",
                plural: !0,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "reaction_count",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "FeedbackReactionInfo",
                    kind: "LinkedField",
                    name: "node",
                    plural: !1,
                    selections: [L, a, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "reaction_type",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            }],
            storageKey: 'top_reactions(orderby:["COUNT_DESC","REACTION_TYPE"])'
        };
        n = {
            kind: "InlineFragment",
            selections: n,
            type: "Page",
            abstractKey: null
        };
        var Qb = {
            kind: "InlineFragment",
            selections: [m, Qa, Ra],
            type: "User",
            abstractKey: null
        };
        J = {
            alias: null,
            args: [{
                kind: "Variable",
                name: "location",
                variableName: "feedLocation"
            }, J],
            kind: "ScalarField",
            name: "can_viewer_comment",
            storageKey: null
        };
        var Rb = {
                alias: null,
                args: K,
                kind: "ScalarField",
                name: "comment_composer_placeholder",
                storageKey: null
            },
            Sb = {
                alias: "toplevel_comment_count",
                args: [{
                    kind: "Literal",
                    name: "orderby",
                    value: "toplevel"
                }],
                concreteType: "TopLevelCommentsConnection",
                kind: "LinkedField",
                name: "top_level_comments",
                plural: !1,
                selections: b,
                storageKey: 'top_level_comments(orderby:"toplevel")'
            },
            Tb = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "subscription_target_id",
                storageKey: null
            },
            Ub = {
                kind: "Variable",
                name: "feed_context_enable_comment",
                variableName: "displayCommentsContextEnableComment"
            },
            Vb = {
                kind: "Variable",
                name: "feed_context_fb_feed_location",
                variableName: "feedLocation"
            },
            Wb = {
                kind: "Variable",
                name: "feed_context_is_ad_preview",
                variableName: "displayCommentsContextIsAdPreview"
            },
            N = {
                kind: "Variable",
                name: "feed_context_is_aggregated_share",
                variableName: "displayCommentsContextIsAggregatedShare"
            },
            Xb = {
                kind: "Variable",
                name: "feed_context_is_story_set",
                variableName: "displayCommentsContextIsStorySet"
            },
            O = {
                kind: "Variable",
                name: "feedback_context",
                variableName: "displayCommentsFeedbackContext"
            },
            P = {
                kind: "Variable",
                name: "feedback_source",
                variableName: "feedbackSource"
            },
            Yb = {
                kind: "Variable",
                name: "focus_comment_id",
                variableName: "focusCommentID"
            },
            Zb = {
                kind: "Literal",
                name: "is_initial_fetch",
                value: !0
            },
            $b = [Ub, Vb, Wb, N, Xb, O, P, Yb, Zb, {
                kind: "Variable",
                name: "is_top_level",
                variableName: "includeNestedComments"
            }],
            ac = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "after_count",
                storageKey: null
            },
            bc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "before_count",
                storageKey: null
            },
            cc = [k, m];
        cc = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "author",
            plural: !1,
            selections: [h, a, c, {
                kind: "InlineFragment",
                selections: cc,
                type: "Event",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: cc,
                type: "Group",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [k, m, Na],
                type: "Page",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [k, m, Ma, Na, Oa, Pa, Qa, Ra],
                type: "User",
                abstractKey: null
            }, La, za, Ta, Ua, {
                kind: "InlineFragment",
                selections: [k, k],
                type: "Entity",
                abstractKey: "__isEntity"
            }, Ba],
            storageKey: null
        };
        var dc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_hidden_by_content_owner",
                storageKey: null
            },
            ec = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_author_banned_by_content_owner",
                storageKey: null
            },
            fc = {
                alias: null,
                args: null,
                concreteType: "StoryAttachment",
                kind: "LinkedField",
                name: "attachments",
                plural: !0,
                selections: [Ha, Ga],
                storageKey: null
            },
            gc = {
                alias: null,
                args: K,
                concreteType: null,
                kind: "LinkedField",
                name: "viewer_actor",
                plural: !1,
                selections: I,
                storageKey: null
            };
        Ub = [Ub, Vb, Wb, N, Xb, O, P, Yb, Zb, {
            kind: "Literal",
            name: "is_top_level",
            value: !1
        }];
        Vb = {
            alias: "sub_replies_count",
            args: null,
            kind: "ScalarField",
            name: "comment_count",
            storageKey: null
        };
        Wb = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_hide_transparency_enabled_for_actor",
            storageKey: null
        };
        N = {
            alias: null,
            args: null,
            concreteType: "GroupCommentInfo",
            kind: "LinkedField",
            name: "group_comment_info",
            plural: !1,
            selections: [{
                alias: "is_author_with_member_profile_legacy",
                args: [i, {
                    kind: "Variable",
                    name: "is_comet",
                    variableName: "isComet"
                }],
                kind: "ScalarField",
                name: "is_author_with_member_profile",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "group_id",
                storageKey: null
            }],
            storageKey: null
        };
        Xb = {
            alias: null,
            args: Za,
            concreteType: null,
            kind: "LinkedField",
            name: "preferred_body",
            plural: !1,
            selections: [h, cb, {
                kind: "InlineFragment",
                selections: [ab, bb, o, $a],
                type: "TextWithEntities",
                abstractKey: null
            }, $a],
            storageKey: 'preferred_body(translation_type:"ORIGINAL")'
        };
        O = {
            alias: "sub_reply_parent_above_comment_author_context",
            args: [{
                kind: "Literal",
                name: "type",
                value: "AUTHOR_CONTEXT_ABOVE_COMMENT"
            }],
            concreteType: null,
            kind: "LinkedField",
            name: "sub_reply_parent_context",
            plural: !1,
            selections: [h, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "UFI2CommentRow_comment",
                    fragmentName: "UFI2SubReplyParentAboveCommentAuthorContext_subReplyParentContext",
                    fragmentPropName: "subReplyParentContext",
                    kind: "ModuleImport"
                }],
                type: "CommentSubReplyParentAboveCommentAuthorContext",
                abstractKey: null
            }],
            storageKey: 'sub_reply_parent_context(type:"AUTHOR_CONTEXT_ABOVE_COMMENT")'
        };
        P = [{
            kind: "Literal",
            name: "type",
            value: "REPLY_PREVIEW_CONTEXT"
        }];
        Yb = {
            alias: "sub_reply_parent_preview_context",
            args: P,
            concreteType: null,
            kind: "LinkedField",
            name: "sub_reply_parent_context",
            plural: !1,
            selections: [h, {
                kind: "InlineFragment",
                selections: [{
                    args: null,
                    documentName: "UFI2CommentRow_comment__sub_reply_parent_preview_context",
                    fragmentName: "UFI2CommentReplyParentPreview_subReplyParentContext",
                    fragmentPropName: "subReplyParentContext",
                    kind: "ModuleImport"
                }],
                type: "CommentSubReplyParentPreviewContext",
                abstractKey: null
            }],
            storageKey: 'sub_reply_parent_context(type:"REPLY_PREVIEW_CONTEXT")'
        };
        Zb = {
            alias: null,
            args: null,
            concreteType: "WorkAMAUFIAnsweredEventCommentModuleRenderer",
            kind: "LinkedField",
            name: "work_answered_event_comment_renderer",
            plural: !1,
            selections: [{
                args: null,
                documentName: "UFI2Comment_comment_work_answered_event_comment_renderer",
                fragmentName: "CometUFIAMABroadcastAnswerEventRow_data",
                fragmentPropName: "data",
                kind: "ModuleImport"
            }],
            storageKey: null
        };
        i = {
            alias: null,
            args: null,
            concreteType: "TextWithEntities",
            kind: "LinkedField",
            name: "body",
            plural: !1,
            selections: [o, {
                alias: null,
                args: null,
                concreteType: "EntityAtRange",
                kind: "LinkedField",
                name: "ranges",
                plural: !0,
                selections: [h, {
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "entity",
                    plural: !1,
                    selections: [h, r],
                    storageKey: null
                }, s, p, q],
                storageKey: null
            }],
            storageKey: null
        };
        s = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_markdown_enabled",
            storageKey: null
        };
        var hc = {
                alias: "can_comment",
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [J, a],
                storageKey: null
            },
            Q = [d],
            R = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "height",
                storageKey: null
            },
            S = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "width",
                storageKey: null
            },
            ic = {
                alias: null,
                args: null,
                concreteType: "InlineSurveyStoryActionLink",
                kind: "LinkedField",
                name: "inline_survey_config",
                plural: !1,
                selections: [{
                    alias: null,
                    args: Q,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "favicon",
                    plural: !1,
                    selections: [R, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "scale",
                        storageKey: null
                    }, e, S],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "followup_choices",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "followup_question",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "main_choices",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "main_question",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "privacy_text",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "session_blob",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "thankyou_text",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "title",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "tessa_survey_config_id",
                    storageKey: null
                }, Eb],
                storageKey: null
            },
            jc = {
                alias: null,
                args: null,
                concreteType: "Story",
                kind: "LinkedField",
                name: "parent_post_story",
                plural: !1,
                selections: [Bb, a],
                storageKey: null
            },
            kc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_disabled",
                storageKey: null
            },
            lc = {
                alias: null,
                args: null,
                concreteType: "WorkAMAUFIAnsweredEventCommentModuleRenderer",
                kind: "LinkedField",
                name: "work_answered_event_comment_renderer",
                plural: !1,
                selections: [{
                    args: null,
                    documentName: "CometUFIComment_comment_work_answered_event_comment_renderer",
                    fragmentName: "CometUFIAMABroadcastAnswerEventRow_data",
                    fragmentPropName: "data",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            mc = {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "comment_upper_badge_renderer",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_upper_badge_renderer",
                        fragmentName: "GroupsCometCommentPinnedBadgeRenderer_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "GroupsCometCommentPinnedBadgeRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_upper_badge_renderer",
                        fragmentName: "GroupsCometCommentUnpinnedBadgeRenderer_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "GroupsCometCommentUnpinnedBadgeRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_upper_badge_renderer",
                        fragmentName: "GroupsCometCommentAuthorsFavoriteBadgeRenderer_renderer",
                        fragmentPropName: "renderer",
                        kind: "ModuleImport"
                    }],
                    type: "GroupsCometCommentAuthorsFavoriteBadgeRenderer",
                    abstractKey: null
                }],
                storageKey: null
            },
            nc = {
                alias: null,
                args: [{
                    kind: "Literal",
                    name: "supported",
                    value: ["AwardElevatedCommentData", "StarsElevatedCommentData", "SupporterElevatedCommentData", "SimpleElevatedCommentData", "ClipElevatedCommentData", "GroupPromotionElevatedCommentData"]
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "elevated_comment_data",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_elevated_comment_data",
                        fragmentName: "AwardElevatedCommentContent_awardElevatedCommentData",
                        fragmentPropName: "awardElevatedCommentData",
                        kind: "ModuleImport"
                    }],
                    type: "AwardElevatedCommentData",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_elevated_comment_data",
                        fragmentName: "GFIStarsElevatedCommentContent_starsElevatedCommentData",
                        fragmentPropName: "starsElevatedCommentData",
                        kind: "ModuleImport"
                    }],
                    type: "StarsElevatedCommentData",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_elevated_comment_data",
                        fragmentName: "GFIFubsElevatedCommentContent_fubsElevatedCommentData",
                        fragmentPropName: "fubsElevatedCommentData",
                        kind: "ModuleImport"
                    }],
                    type: "SupporterElevatedCommentData",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_elevated_comment_data",
                        fragmentName: "SimpleElevatedCommentContent_simpleElevatedCommentData",
                        fragmentPropName: "simpleElevatedCommentData",
                        kind: "ModuleImport"
                    }],
                    type: "SimpleElevatedCommentData",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_elevated_comment_data",
                        fragmentName: "GFIClipElevatedCommentContent_clipElevatedCommentData",
                        fragmentPropName: "clipElevatedCommentData",
                        kind: "ModuleImport"
                    }],
                    type: "ClipElevatedCommentData",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "CometUFIComment_comment_elevated_comment_data",
                        fragmentName: "GFIGroupPromotionElevatedCommentContent_groupPromotionElevatedCommentData",
                        fragmentPropName: "groupPromotionElevatedCommentData",
                        kind: "ModuleImport"
                    }],
                    type: "GroupPromotionElevatedCommentData",
                    abstractKey: null
                }],
                storageKey: 'elevated_comment_data(supported:["AwardElevatedCommentData","StarsElevatedCommentData","SupporterElevatedCommentData","SimpleElevatedCommentData","ClipElevatedCommentData","GroupPromotionElevatedCommentData"])'
            },
            oc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_subreply_parent_deleted",
                storageKey: null
            },
            pc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_created_from_subscription",
                storageKey: null
            },
            qc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_locally_composed",
                storageKey: null
            },
            rc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "optimistic_action",
                storageKey: null
            },
            sc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "optimistic_error_code",
                storageKey: null
            },
            tc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "client_id",
                storageKey: null
            },
            uc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "optimistic_error",
                storageKey: null
            },
            vc = {
                alias: null,
                args: null,
                concreteType: "FBGComponentRoot",
                kind: "LinkedField",
                name: "fbg_component_root",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "interactive_plugin_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "fbg_component_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "fbg_component_source",
                    storageKey: null
                }],
                storageKey: null
            },
            wc = {
                kind: "ClientExtension",
                selections: [pc, qc, rc, sc, tc, uc, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "reply_comment_parent_fbid",
                    storageKey: null
                }, vc]
            },
            T = [o],
            xc = {
                alias: null,
                args: null,
                concreteType: "TextWithEntities",
                kind: "LinkedField",
                name: "source",
                plural: !1,
                selections: T,
                storageKey: null
            },
            U = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "animated_image_attribution",
                storageKey: null
            },
            V = {
                alias: null,
                args: null,
                concreteType: "ObjectionableContentInfo",
                kind: "LinkedField",
                name: "objectionable_content_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "categories",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "ObjectionableContentWarningScreenText",
                    kind: "LinkedField",
                    name: "strings",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "blur_subtitle",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "blur_title",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "cover_media_link",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "learn_more_desc",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "learn_more_uri",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "show_media_desc",
                        storageKey: null
                    }, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "uncover_media_link",
                        storageKey: null
                    }],
                    storageKey: null
                }],
                storageKey: null
            },
            W = {
                kind: "Literal",
                name: "height",
                value: 396
            },
            X = {
                kind: "Literal",
                name: "width",
                value: 396
            },
            Y = [R, e, S];
        e = [e, S, R];
        U = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "media",
            plural: !1,
            selections: [h, {
                kind: "InlineFragment",
                selections: [a, U, {
                    condition: "isComet",
                    kind: "Condition",
                    passingValue: !0,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "playable_url",
                        storageKey: null
                    }]
                }, V, S, R, {
                    alias: null,
                    args: null,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: f,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "original_height",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "original_width",
                    storageKey: null
                }],
                type: "Video",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: [{
                    alias: "media_id",
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }, U, a],
                type: "GenericAttachmentMedia",
                abstractKey: null
            }, {
                alias: "gifAnimatedImage_396",
                args: [W, {
                    kind: "Literal",
                    name: "media_type",
                    value: "image/gif"
                }, d, X],
                concreteType: "Image",
                kind: "LinkedField",
                name: "animated_image",
                plural: !1,
                selections: Y,
                storageKey: null
            }, {
                alias: "image_396",
                args: [W, d, {
                    kind: "Literal",
                    name: "sizing",
                    value: "contain-fit"
                }, X],
                concreteType: "Image",
                kind: "LinkedField",
                name: "image",
                plural: !1,
                selections: Y,
                storageKey: null
            }, {
                alias: "webPAnimatedImage_396",
                args: [W, {
                    kind: "Literal",
                    name: "media_type",
                    value: "image/webp"
                }, d, X],
                concreteType: "Image",
                kind: "LinkedField",
                name: "animated_image",
                plural: !1,
                selections: Y,
                storageKey: null
            }, r, z, A, {
                alias: "fallback_image",
                args: [{
                    kind: "Literal",
                    name: "height",
                    value: 98
                }, d, {
                    kind: "Literal",
                    name: "width",
                    value: 98
                }],
                concreteType: "Image",
                kind: "LinkedField",
                name: "image",
                plural: !1,
                selections: Y,
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_playable",
                storageKey: null
            }, {
                kind: "InlineFragment",
                selections: [V, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "accessibility_caption",
                    storageKey: null
                }, {
                    alias: "massive_image",
                    args: Q,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: [S, R],
                    storageKey: null
                }, {
                    alias: null,
                    args: [{
                        kind: "Literal",
                        name: "height",
                        value: 210
                    }, d, {
                        kind: "Literal",
                        name: "width",
                        value: 260
                    }],
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: e,
                    storageKey: null
                }],
                type: "Photo",
                abstractKey: null
            }],
            storageKey: null
        };
        W = [{
            alias: null,
            args: null,
            concreteType: "StreetAddress",
            kind: "LinkedField",
            name: "address",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "single_line_full_address",
                storageKey: null
            }],
            storageKey: null
        }, a, c, {
            alias: null,
            args: null,
            concreteType: "Location",
            kind: "LinkedField",
            name: "location",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "latitude",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "longitude",
                storageKey: null
            }],
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "overall_rating",
            storageKey: null
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "price_range_description",
            storageKey: null
        }, {
            alias: null,
            args: [{
                kind: "Literal",
                name: "size__height",
                value: 60
            }, {
                kind: "Literal",
                name: "size__width",
                value: 60
            }],
            concreteType: "Image",
            kind: "LinkedField",
            name: "profile_picture",
            plural: !1,
            selections: f,
            storageKey: "profile_picture(size__height:60,size__width:60)"
        }, {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "top_category_name",
            storageKey: null
        }, k];
        X = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "target",
            plural: !1,
            selections: [h, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_add_to_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_remove_from_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_add_suggested_to_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_remove_suggested_from_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_curate_attachment",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "Page",
                    kind: "LinkedField",
                    name: "pending_places_for_attachment",
                    plural: !0,
                    selections: W,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "CommentPlaceInfoToPlaceListItemsConnection",
                    kind: "LinkedField",
                    name: "place_list_items",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "PlaceListItem",
                        kind: "LinkedField",
                        name: "nodes",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: "Page",
                            kind: "LinkedField",
                            name: "recommendation_page",
                            plural: !1,
                            selections: W,
                            storageKey: null
                        }, {
                            alias: null,
                            args: null,
                            concreteType: "PageCtaPayload",
                            kind: "LinkedField",
                            name: "page_cta",
                            plural: !1,
                            selections: [{
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "cta_label",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "cta_type",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "cta_icon",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "web_uri",
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                kind: "ScalarField",
                                name: "web_destination_type",
                                storageKey: null
                            }],
                            storageKey: null
                        }, a],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "CommentPlaceInfo",
                abstractKey: null
            }, a, {
                kind: "InlineFragment",
                selections: l,
                type: "ExternalUrl",
                abstractKey: null
            }],
            storageKey: null
        };
        Y = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "style_infos",
            plural: !0,
            selections: [h, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "TextWithEntities",
                    kind: "LinkedField",
                    name: "donation_comment_text",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        concreteType: "EntityAtRange",
                        kind: "LinkedField",
                        name: "ranges",
                        plural: !0,
                        selections: [{
                            alias: null,
                            args: null,
                            concreteType: null,
                            kind: "LinkedField",
                            name: "entity",
                            plural: !1,
                            selections: [h, k, r],
                            storageKey: null
                        }, p, q],
                        storageKey: null
                    }, o],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "use_donation_v2",
                    storageKey: null
                }],
                type: "FundraiserForStoryDonationAttachmentStyleInfo",
                abstractKey: null
            }, r, {
                kind: "InlineFragment",
                selections: g,
                type: "GamesInstantPlayStyleInfo",
                abstractKey: null
            }, {
                kind: "InlineFragment",
                selections: g,
                type: "XFBPluginStyleInfo",
                abstractKey: null
            }],
            storageKey: null
        };
        V = {
            alias: null,
            args: null,
            concreteType: "TextWithEntities",
            kind: "LinkedField",
            name: "title_with_entities",
            plural: !1,
            selections: T,
            storageKey: null
        };
        Q = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "action_links",
            plural: !0,
            selections: [h, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "object_id",
                    storageKey: null
                }],
                type: "ArticleContextActionLink",
                abstractKey: null
            }],
            storageKey: null
        };
        S = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "tracking",
            storageKey: null
        };
        R = [c, a];
        W = [{
            kind: "Literal",
            name: "height",
            value: 80
        }, d, {
            kind: "Literal",
            name: "width",
            value: 80
        }];
        l = {
            alias: "sticker",
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "media",
            plural: !1,
            selections: [h, {
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frame_count",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frame_rate",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frames_per_column",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "frames_per_row",
                    storageKey: null
                }, ya, {
                    alias: null,
                    args: null,
                    concreteType: "StickerPack",
                    kind: "LinkedField",
                    name: "pack",
                    plural: !1,
                    selections: R,
                    storageKey: null
                }, {
                    alias: null,
                    args: W,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "sprite_image",
                    plural: !1,
                    selections: f,
                    storageKey: null
                }, {
                    alias: "sticker_image",
                    args: W,
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: e,
                    storageKey: null
                }, {
                    alias: "larger_sticker_image",
                    args: [{
                        kind: "Literal",
                        name: "height",
                        value: 120
                    }, d, {
                        kind: "Literal",
                        name: "width",
                        value: 120
                    }],
                    concreteType: "Image",
                    kind: "LinkedField",
                    name: "image",
                    plural: !1,
                    selections: e,
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "sticker_type",
                    storageKey: null
                }],
                type: "Sticker",
                abstractKey: null
            }, r, y, z, A],
            storageKey: null
        };
        p = {
            alias: null,
            args: null,
            concreteType: "StoryAttachment",
            kind: "LinkedField",
            name: "attachments",
            plural: !0,
            selections: [k, xc, U, X, Y, V, Q, S, l, {
                alias: "style_type_renderer_blue",
                args: [{
                    kind: "Literal",
                    name: "supported",
                    value: ["StoryAttachmentTipJarPaymentStyleRenderer", "StoryAttachmentChatCommandStyleRenderer", "StoryAttachmentInstantGamesTournamentActivityStyleRenderer"]
                }],
                concreteType: null,
                kind: "LinkedField",
                name: "style_type_renderer",
                plural: !1,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentLazyLoadAttachmentContainer_attachment",
                        fragmentName: "UFI2CommentTipJarPaymentAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentTipJarPaymentStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentLazyLoadAttachmentContainer_attachment",
                        fragmentName: "UFI2CommentChatCommandAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentChatCommandStyleRenderer",
                    abstractKey: null
                }, {
                    kind: "InlineFragment",
                    selections: [{
                        args: null,
                        documentName: "UFI2CommentLazyLoadAttachmentContainer_attachment",
                        fragmentName: "UFI2CommentInstantGamesTournamentActivityAttachmentStyle_styleTypeRenderer",
                        fragmentPropName: "styleTypeRenderer",
                        kind: "ModuleImport"
                    }],
                    type: "StoryAttachmentInstantGamesTournamentActivityStyleRenderer",
                    abstractKey: null
                }],
                storageKey: 'style_type_renderer(supported:["StoryAttachmentTipJarPaymentStyleRenderer","StoryAttachmentChatCommandStyleRenderer","StoryAttachmentInstantGamesTournamentActivityStyleRenderer"])'
            }],
            storageKey: null
        };
        q = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "upvote_downvote_total",
            storageKey: null
        };
        T = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "viewer_comment_vote_state",
            storageKey: null
        };
        W = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "can_viewer_share",
            storageKey: null
        };
        d = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "can_viewer_upvote_downvote",
            storageKey: null
        };
        e = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "chat_to_buy",
            storageKey: null
        };
        r = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "ban_action",
            storageKey: null
        };
        y = {
            alias: null,
            args: null,
            concreteType: "EditHistoryConnection",
            kind: "LinkedField",
            name: "edit_history",
            plural: !1,
            selections: b,
            storageKey: null
        };
        z = {
            alias: null,
            args: null,
            concreteType: "FeedbackReaction",
            kind: "LinkedField",
            name: "supported_reactions",
            plural: !0,
            selections: M,
            storageKey: null
        };
        A = {
            alias: null,
            args: null,
            concreteType: "Video",
            kind: "LinkedField",
            name: "associated_video",
            plural: !1,
            selections: g,
            storageKey: null
        };
        b = {
            alias: null,
            args: null,
            concreteType: "ReactorsOfContentConnection",
            kind: "LinkedField",
            name: "reactors",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_empty",
                storageKey: null
            }],
            storageKey: null
        };
        M = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "status",
            storageKey: null
        };
        var yc = {
                alias: null,
                args: null,
                concreteType: "Page",
                kind: "LinkedField",
                name: "page",
                plural: !1,
                selections: g,
                storageKey: null
            },
            Z = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_reply_permission",
                storageKey: null
            },
            zc = {
                alias: null,
                args: null,
                concreteType: "PrivateReplyContext",
                kind: "LinkedField",
                name: "page_private_reply",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: "PageReplyableActivity",
                    kind: "LinkedField",
                    name: "activity",
                    plural: !1,
                    selections: [a, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "type",
                        storageKey: null
                    }],
                    storageKey: null
                }, M, yc, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "permalink",
                    storageKey: null
                }, Z, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "should_show_private_reply_nux",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "user_can_private_reply",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "prefilled_content",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "post_id",
                    storageKey: null
                }],
                storageKey: null
            },
            Ac = {
                alias: null,
                args: K,
                kind: "ScalarField",
                name: "can_viewer_react",
                storageKey: null
            },
            Bc = {
                alias: null,
                args: null,
                concreteType: "PublicConversationsExperimentContext",
                kind: "LinkedField",
                name: "public_conversations_context",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "comment_vote_ui_version",
                    storageKey: null
                }],
                storageKey: null
            },
            Cc = {
                alias: null,
                args: null,
                concreteType: "PageAdminActorInfo",
                kind: "LinkedField",
                name: "page_admin_actor_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "creator_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "creator_name",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "creator_type",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "label_type",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "page_id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "profile_uri",
                    storageKey: null
                }],
                storageKey: null
            },
            Dc = {
                alias: null,
                args: K,
                concreteType: "Page",
                kind: "LinkedField",
                name: "viewer_acts_as_page",
                plural: !1,
                selections: g,
                storageKey: null
            },
            Ec = {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "parent_feedback",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_ban_user",
                    storageKey: null
                }, Dc],
                storageKey: null
            };
        yc = {
            alias: null,
            args: null,
            concreteType: "PrivateReplyContext",
            kind: "LinkedField",
            name: "private_reply_context",
            plural: !1,
            selections: [yc, M, Z],
            storageKey: null
        };
        Z = {
            alias: null,
            args: null,
            concreteType: "PostTranslatability",
            kind: "LinkedField",
            name: "translatability_for_viewer",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "source_dialect_name",
                storageKey: null
            }],
            storageKey: null
        };
        var Fc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "badge_color",
                storageKey: null
            },
            Gc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "multiple_badge_asset_colored",
                storageKey: null
            },
            $ = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "badge_color_variant",
                storageKey: null
            },
            Hc = {
                alias: null,
                args: j,
                concreteType: "IdentityBadge",
                kind: "LinkedField",
                name: "identity_badges_web",
                plural: !0,
                selections: [Fc, Gc, $, {
                    args: null,
                    documentName: "FeedStoryUFICommentBody_comment",
                    fragmentName: "UFI2CommentIdentityBadges_identityBadge",
                    fragmentPropName: "identityBadge",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            Ic = [h];
        P = {
            alias: "sub_reply_parent_preview_context",
            args: P,
            concreteType: null,
            kind: "LinkedField",
            name: "sub_reply_parent_context",
            plural: !1,
            selections: Ic,
            storageKey: 'sub_reply_parent_context(type:"REPLY_PREVIEW_CONTEXT")'
        };
        var Jc = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_the_comment_on_work_knowledge",
            storageKey: null
        };
        M = {
            alias: null,
            args: null,
            concreteType: "InternQASyncedAnswerData",
            kind: "LinkedField",
            name: "synced_intern_qa_answer",
            plural: !1,
            selections: [M, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "activity_uri",
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "User",
                kind: "LinkedField",
                name: "last_editor",
                plural: !1,
                selections: R,
                storageKey: null
            }],
            storageKey: null
        };
        R = {
            condition: "containerIsWorkplace",
            kind: "Condition",
            passingValue: !0,
            selections: [Jc, M]
        };
        var Kc = {
                condition: "containerIsFeedStory",
                kind: "Condition",
                passingValue: !0,
                selections: [p, q, T, W, d, e, r, y, {
                    alias: null,
                    args: null,
                    concreteType: "Feedback",
                    kind: "LinkedField",
                    name: "feedback",
                    plural: !1,
                    selections: [z, A, b, zc, Ac, Bc, Tb],
                    storageKey: null
                }, Cc, Ec, yc, Z, k, Hc, P, R]
            },
            Lc = {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "author",
                plural: !1,
                selections: [{
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "first_name",
                        storageKey: null
                    }],
                    type: "User",
                    abstractKey: null
                }],
                storageKey: null
            },
            Mc = {
                alias: null,
                args: null,
                concreteType: "Comment",
                kind: "LinkedField",
                name: "comment_parent",
                plural: !1,
                selections: [Lc],
                storageKey: null
            },
            Nc = {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [z, A, b, Ac, Tb],
                storageKey: null
            },
            Oc = {
                alias: null,
                args: j,
                concreteType: "IdentityBadge",
                kind: "LinkedField",
                name: "identity_badges_web",
                plural: !0,
                selections: [Fc, Gc, $, {
                    args: null,
                    documentName: "LiveFeedStoryUFICommentBody_comment",
                    fragmentName: "UFI2CommentIdentityBadges_identityBadge",
                    fragmentPropName: "identityBadge",
                    kind: "ModuleImport"
                }],
                storageKey: null
            },
            Pc = {
                condition: "containerIsLiveStory",
                kind: "Condition",
                passingValue: !0,
                selections: [p, e, Mc, y, Nc, Cc, Ec, Z, k, Oc, R]
            };
        Lc = {
            alias: null,
            args: null,
            concreteType: "Comment",
            kind: "LinkedField",
            name: "comment_parent",
            plural: !1,
            selections: [Lc, {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: g,
                storageKey: null
            }],
            storageKey: null
        };
        j = {
            alias: null,
            args: j,
            concreteType: "IdentityBadge",
            kind: "LinkedField",
            name: "identity_badges_web",
            plural: !0,
            selections: [Fc, Gc, $, {
                args: null,
                documentName: "TahoeUFICommentBody_comment",
                fragmentName: "UFI2CommentIdentityBadges_identityBadge",
                fragmentPropName: "identityBadge",
                kind: "ModuleImport"
            }],
            storageKey: null
        };
        Fc = {
            condition: "containerIsTahoe",
            kind: "Condition",
            passingValue: !0,
            selections: [p, e, Lc, y, Nc, Cc, Ec, Z, k, j, R]
        };
        Gc = {
            alias: null,
            args: null,
            concreteType: "StoryAttachment",
            kind: "LinkedField",
            name: "attachments",
            plural: !0,
            selections: [k, xc, U, X, Y, V, Q, S, l],
            storageKey: null
        };
        $ = {
            alias: null,
            args: null,
            concreteType: "Feedback",
            kind: "LinkedField",
            name: "feedback",
            plural: !1,
            selections: [z, A, b, Ac],
            storageKey: null
        };
        Nc = {
            alias: null,
            args: Za,
            concreteType: null,
            kind: "LinkedField",
            name: "preferred_body",
            plural: !1,
            selections: [{
                kind: "InlineFragment",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "fb_workplace_commonmark_ast_serialized",
                    storageKey: null
                }],
                type: "FBMarkdownCommentBody",
                abstractKey: null
            }],
            storageKey: 'preferred_body(translation_type:"ORIGINAL")'
        };
        xc = {
            alias: null,
            args: null,
            concreteType: "WorkApprovalRequestInfoModuleRenderer",
            kind: "LinkedField",
            name: "work_approval_request_info",
            plural: !1,
            selections: [{
                args: null,
                documentName: "WorkplaceFeedStoryUFICommentActionLinks_comment",
                fragmentName: "WorkApprovalsUFICommentActions_data",
                fragmentPropName: "data",
                kind: "ModuleImport"
            }],
            storageKey: null
        };
        U = {
            alias: null,
            args: null,
            concreteType: "FileMarker",
            kind: "LinkedField",
            name: "file_marker",
            plural: !1,
            selections: [ya, xa, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "location_x",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "location_y",
                storageKey: null
            }],
            storageKey: null
        };
        X = {
            condition: "containerIsWorkplace",
            kind: "Condition",
            passingValue: !0,
            selections: [Gc, q, T, d, y, $, Nc, Z, k, xc, U, P, Jc, M]
        };
        Y = {
            condition: "isComet",
            kind: "Condition",
            passingValue: !1,
            selections: [{
                alias: null,
                args: null,
                concreteType: "GroupCommentInfo",
                kind: "LinkedField",
                name: "group_comment_info",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_author_muted",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_report_comment_to_admin_with_tags",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "can_viewer_block_author",
                    storageKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "comment_menu_items",
                plural: !0,
                selections: [h, {
                    kind: "InlineFragment",
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "show_remove_content_options",
                        storageKey: null
                    }],
                    type: "CommentMenuItemDeleteAndRemoveMember",
                    abstractKey: null
                }],
                storageKey: null
            }, {
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "parent_feedback",
                plural: !1,
                selections: [Dc],
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "create_detailed_report_uri",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "us_structured_reporting_enabled",
                storageKey: null
            }]
        };
        V = {
            alias: null,
            args: Sa,
            concreteType: "Image",
            kind: "LinkedField",
            name: "profile_picture",
            plural: !1,
            selections: f,
            storageKey: null
        };
        Q = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "is_initially_expanded",
            storageKey: null
        };
        S = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "page_size",
            storageKey: null
        };
        l = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "reply_comment_order",
            storageKey: null
        };
        Jc = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "should_render_composer_preemptively",
            storageKey: null
        };
        M = {
            alias: null,
            args: null,
            kind: "ScalarField",
            name: "comment_order",
            storageKey: null
        };
        Dc = {
            alias: null,
            args: null,
            concreteType: "PageInfo",
            kind: "LinkedField",
            name: "page_info",
            plural: !1,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "end_cursor",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_next_page",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "has_previous_page",
                storageKey: null
            }, {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "start_cursor",
                storageKey: null
            }],
            storageKey: null
        };
        Sa = {
            alias: null,
            args: null,
            concreteType: "Comment",
            kind: "LinkedField",
            name: "expanded_sub_reply_parents",
            plural: !0,
            selections: g,
            storageKey: null
        };
        var Qc = {
                kind: "ClientExtension",
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "ufi2_connection_generation",
                    storageKey: null
                }]
            },
            Rc = ["feedback_source", "focus_comment_id", "comment_order"],
            Sc = {
                kind: "Variable",
                name: "__dynamicKey",
                variableName: "UFI2CommentsProvider_commentsKey"
            },
            Tc = {
                alias: null,
                args: null,
                concreteType: "AskMeAnythingFeedbackMetadata",
                kind: "LinkedField",
                name: "ask_me_anything_feedback_metadata",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "is_viewer_host",
                    storageKey: null
                }],
                storageKey: null
            };
        Ic = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "threading_config",
            plural: !1,
            selections: Ic,
            storageKey: null
        };
        var Uc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_vc_acting_as_page_or_profile_plus",
                storageKey: null
            },
            Vc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "should_show_premium_award_giver_popover",
                storageKey: null
            },
            Wc = {
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "is_eligible_for_comment_api",
                storageKey: null
            };
        g = {
            alias: null,
            args: null,
            concreteType: "Group",
            kind: "LinkedField",
            name: "associated_group",
            plural: !1,
            selections: g,
            storageKey: null
        };
        t = [t, {
            alias: null,
            args: null,
            concreteType: "PoliticalFigureData",
            kind: "LinkedField",
            name: "political_figure_data",
            plural: !1,
            selections: [c, u, {
                alias: null,
                args: null,
                concreteType: null,
                kind: "LinkedField",
                name: "best_profile",
                plural: !1,
                selections: I,
                storageKey: null
            }, a],
            storageKey: null
        }];
        u = {
            condition: "containerIsFeedStory",
            kind: "Condition",
            passingValue: !0,
            selections: t
        };
        I = {
            condition: "containerIsLiveStory",
            kind: "Condition",
            passingValue: !0,
            selections: t
        };
        t = {
            condition: "containerIsTahoe",
            kind: "Condition",
            passingValue: !0,
            selections: t
        };
        var Xc = {
                condition: "containerIsFeedStory",
                kind: "Condition",
                passingValue: !0,
                selections: [{
                    alias: null,
                    args: null,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "comment_share_context",
                    plural: !1,
                    selections: [h, {
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "tooltip_nux_text",
                        storageKey: null
                    }],
                    storageKey: null
                }, g, u, I, t]
            },
            Yc = [A, g, u, I, t],
            Zc = {
                condition: "containerIsLiveStory",
                kind: "Condition",
                passingValue: !0,
                selections: Yc
            };
        g = {
            condition: "containerIsWorkplace",
            kind: "Condition",
            passingValue: !0,
            selections: [{
                alias: null,
                args: null,
                kind: "ScalarField",
                name: "can_viewer_comment_with_marker",
                storageKey: null
            }, g, u, I, t]
        };
        u = {
            condition: "containerIsTahoe",
            kind: "Condition",
            passingValue: !0,
            selections: Yc
        };
        I = {
            alias: null,
            args: null,
            concreteType: null,
            kind: "LinkedField",
            name: "author",
            plural: !1,
            selections: [Ka],
            storageKey: null
        };
        return {
            fragment: {
                argumentDefinitions: [aa, ca, da, ea, fa, ga, ha, ia, ja, ka, la, ma, na, oa, pa, qa, ra, sa],
                kind: "Fragment",
                metadata: null,
                name: "UFI2CreateCommentSubscription",
                selections: [{
                    alias: null,
                    args: ta,
                    concreteType: "CommentCreateResponsePayload",
                    kind: "LinkedField",
                    name: "comment_create_subscribe",
                    plural: !1,
                    selections: [va, {
                        alias: null,
                        args: null,
                        concreteType: "CommentsEdge",
                        kind: "LinkedField",
                        name: "feedback_comment_edge",
                        plural: !1,
                        selections: [wa, {
                            alias: null,
                            args: null,
                            concreteType: "Comment",
                            kind: "LinkedField",
                            name: "node",
                            plural: !1,
                            selections: [{
                                args: null,
                                kind: "FragmentSpread",
                                name: "CometUFIComment_comment"
                            }, {
                                args: null,
                                kind: "FragmentSpread",
                                name: "UFI2Comment_comment"
                            }, a, {
                                condition: "containerIsWorkplace",
                                kind: "Condition",
                                passingValue: !0,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    concreteType: "FileMarker",
                                    kind: "LinkedField",
                                    name: "file_marker",
                                    plural: !1,
                                    selections: [xa, ya],
                                    storageKey: null
                                }]
                            }, {
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "author",
                                plural: !1,
                                selections: [c, za, Ba],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                concreteType: "Feedback",
                                kind: "LinkedField",
                                name: "feedback",
                                plural: !1,
                                selections: [{
                                    args: Ca,
                                    kind: "FragmentSpread",
                                    name: "UFI2CommentsList_feedback"
                                }, {
                                    args: Ca,
                                    kind: "FragmentSpread",
                                    name: "CometUFICommentList_feedback"
                                }],
                                storageKey: null
                            }, {
                                alias: null,
                                args: null,
                                concreteType: "Story",
                                kind: "LinkedField",
                                name: "parent_post_story",
                                plural: !1,
                                selections: [{
                                    alias: null,
                                    args: null,
                                    concreteType: "Feedback",
                                    kind: "LinkedField",
                                    name: "feedback",
                                    plural: !1,
                                    selections: [{
                                        args: null,
                                        kind: "FragmentSpread",
                                        name: "UFI2CommentsCount_feedback"
                                    }, {
                                        args: null,
                                        kind: "FragmentSpread",
                                        name: "UFI2WorkAMAQuestionsCount_feedback"
                                    }],
                                    storageKey: null
                                }],
                                storageKey: null
                            }, Da, Ea],
                            storageKey: null
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }],
                type: "Subscription",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: [ka, ga, ha, ia, ja, la, ma, na, oa, pa, qa, ca, fa, da, ea, ra, sa, aa],
                kind: "Operation",
                name: "UFI2CreateCommentSubscription",
                selections: [{
                    alias: null,
                    args: ta,
                    concreteType: "CommentCreateResponsePayload",
                    kind: "LinkedField",
                    name: "comment_create_subscribe",
                    plural: !1,
                    selections: [va, {
                        alias: null,
                        args: null,
                        concreteType: "CommentsEdge",
                        kind: "LinkedField",
                        name: "feedback_comment_edge",
                        plural: !1,
                        selections: [wa, {
                            alias: null,
                            args: null,
                            concreteType: "Comment",
                            kind: "LinkedField",
                            name: "node",
                            plural: !1,
                            selections: [Fa, {
                                alias: null,
                                args: null,
                                concreteType: "StoryAttachment",
                                kind: "LinkedField",
                                name: "attachments",
                                plural: !0,
                                selections: [Ga, Ha],
                                storageKey: null
                            }, a, Ia, Ja, {
                                alias: null,
                                args: null,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "author",
                                plural: !1,
                                selections: [h, a, c, Ka, La, {
                                    kind: "InlineFragment",
                                    selections: [Ma, Na, Oa, Pa, Qa, Ra, m],
                                    type: "User",
                                    abstractKey: null
                                }, {
                                    kind: "InlineFragment",
                                    selections: [Na, m],
                                    type: "Page",
                                    abstractKey: null
                                }, za, Ba, Ta, Ua, Va, Wa],
                                storageKey: null
                            }, Xa, Ya, {
                                alias: null,
                                args: Za,
                                concreteType: null,
                                kind: "LinkedField",
                                name: "preferred_body",
                                plural: !1,
                                selections: [h, {
                                    kind: "InlineFragment",
                                    selections: [$a, o, ab, bb],
                                    type: "TextWithEntities",
                                    abstractKey: null
                                }, $a, cb],
                                storageKey: 'preferred_body(translation_type:"ORIGINAL")'
                            }, db, eb, fb, gb, hb, ib, jb, kb, lb, mb, nb, ob, pb, qb, rb, sb, tb, ub, vb, wb, xb, yb, zb, Ab, Cb, Db, v, w, {
                                alias: null,
                                args: null,
                                concreteType: "Story",
                                kind: "LinkedField",
                                name: "parent_post_story",
                                plural: !1,
                                selections: [Bb, a, {
                                    alias: null,
                                    args: null,
                                    concreteType: "Feedback",
                                    kind: "LinkedField",
                                    name: "feedback",
                                    plural: !1,
                                    selections: [a, B, {
                                        alias: "i18n_comment_count",
                                        args: null,
                                        kind: "ScalarField",
                                        name: "comment_count_reduced",
                                        storageKey: null
                                    }, k, {
                                        alias: null,
                                        args: null,
                                        concreteType: "TopLevelCommentsConnection",
                                        kind: "LinkedField",
                                        name: "top_level_comments",
                                        plural: !1,
                                        selections: [ua, {
                                            alias: null,
                                            args: null,
                                            kind: "ScalarField",
                                            name: "display_count",
                                            storageKey: null
                                        }],
                                        storageKey: null
                                    }],
                                    storageKey: null
                                }],
                                storageKey: null
                            }, C, D, E, F, G, H, x, {
                                alias: null,
                                args: null,
                                concreteType: "InlineSurveyStoryActionLink",
                                kind: "LinkedField",
                                name: "inline_survey_config",
                                plural: !1,
                                selections: [Eb],
                                storageKey: null
                            }, Fb, Gb, Hb, Jb, Kb, {
                                alias: null,
                                args: null,
                                concreteType: "Feedback",
                                kind: "LinkedField",
                                name: "feedback",
                                plural: !1,
                                selections: [a, Lb, Mb, Nb, Ob, Pb, L, {
                                    alias: null,
                                    args: K,
                                    concreteType: null,
                                    kind: "LinkedField",
                                    name: "viewer_actor",
                                    plural: !1,
                                    selections: [h, a, La, c, Ka, za, Ta, Ua, Va, Wa, n, Qb, Ba],
                                    storageKey: null
                                }, J, Rb, B, Sb, Tb, {
                                    alias: null,
                                    args: $b,
                                    concreteType: "DisplayCommentsConnection",
                                    kind: "LinkedField",
                                    name: "display_comments",
                                    plural: !1,
                                    selections: [ac, bc, ua, {
                                        alias: null,
                                        args: null,
                                        concreteType: "DisplayCommentsEdge",
                                        kind: "LinkedField",
                                        name: "edges",
                                        plural: !0,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            concreteType: "Comment",
                                            kind: "LinkedField",
                                            name: "node",
                                            plural: !1,
                                            selections: [G, a, Fb, cc, Xa, Gb, H, dc, ec, fc, Hb, {
                                                alias: null,
                                                args: null,
                                                concreteType: "Feedback",
                                                kind: "LinkedField",
                                                name: "feedback",
                                                plural: !1,
                                                selections: [a, Lb, Mb, Pb, L, gc, Nb, Ob, Rb, J, {
                                                    condition: "includeNestedComments",
                                                    kind: "Condition",
                                                    passingValue: !0,
                                                    selections: [B, {
                                                        alias: null,
                                                        args: K,
                                                        concreteType: null,
                                                        kind: "LinkedField",
                                                        name: "viewer_actor",
                                                        plural: !1,
                                                        selections: [La, c, za, Ta, Ba, Ka, Ua, Va, Wa, n, Qb],
                                                        storageKey: null
                                                    }, Sb, Tb, {
                                                        alias: null,
                                                        args: Ub,
                                                        concreteType: "DisplayCommentsConnection",
                                                        kind: "LinkedField",
                                                        name: "display_comments",
                                                        plural: !1,
                                                        selections: [ac, bc, ua, {
                                                            alias: null,
                                                            args: null,
                                                            concreteType: "DisplayCommentsEdge",
                                                            kind: "LinkedField",
                                                            name: "edges",
                                                            plural: !0,
                                                            selections: [{
                                                                alias: null,
                                                                args: null,
                                                                concreteType: "Comment",
                                                                kind: "LinkedField",
                                                                name: "node",
                                                                plural: !1,
                                                                selections: [G, a, Fb, cc, Xa, Gb, H, dc, ec, fc, Hb, {
                                                                    alias: null,
                                                                    args: null,
                                                                    concreteType: "Feedback",
                                                                    kind: "LinkedField",
                                                                    name: "feedback",
                                                                    plural: !1,
                                                                    selections: [a, Lb, Mb, Pb, L, gc, Nb, Ob, Rb, Vb, Wb, J],
                                                                    storageKey: null
                                                                }, N, Xb, O, Yb, Zb, i, s, hc, ic, Ea, Da, h, Fa, Ia, Ja, Ya, db, eb, fb, gb, hb, ib, jb, kb, lb, mb, nb, ob, pb, qb, rb, sb, tb, ub, vb, wb, xb, yb, zb, Ab, Cb, Db, v, w, jc, C, D, E, F, x, Jb, Kb, kc, lc, mc, nc, oc, wc, Kc, Pc, Fc, X, Y],
                                                                storageKey: null
                                                            }, wa],
                                                            storageKey: null
                                                        }, {
                                                            alias: null,
                                                            args: null,
                                                            concreteType: "Comment",
                                                            kind: "LinkedField",
                                                            name: "highlighted_comments",
                                                            plural: !0,
                                                            selections: [{
                                                                alias: null,
                                                                args: null,
                                                                concreteType: null,
                                                                kind: "LinkedField",
                                                                name: "author",
                                                                plural: !1,
                                                                selections: [h, c, V, {
                                                                    kind: "InlineFragment",
                                                                    selections: [Qa, Ra],
                                                                    type: "User",
                                                                    abstractKey: null
                                                                }, a, {
                                                                    alias: "profilePictureForReplyExpander",
                                                                    args: Aa,
                                                                    concreteType: "Image",
                                                                    kind: "LinkedField",
                                                                    name: "profile_picture",
                                                                    plural: !1,
                                                                    selections: f,
                                                                    storageKey: null
                                                                }],
                                                                storageKey: null
                                                            }, G, a],
                                                            storageKey: null
                                                        }, Q, S, l, Jc, M, Dc, Sa, Qc],
                                                        storageKey: null
                                                    }, {
                                                        alias: null,
                                                        args: Ub,
                                                        filters: Rc,
                                                        handle: "ufi2_comments",
                                                        key: "UFI2CommentsProvider_feedback_display_comments",
                                                        kind: "LinkedHandle",
                                                        name: "display_comments",
                                                        dynamicKey: Sc
                                                    }, Tc, Ic, Uc, Vc, Wc, Xc, Zc, g, u]
                                                }],
                                                storageKey: null
                                            }, N, Xb, O, Yb, Zb, i, s, hc, ic, Ea, Da, h, Fa, Ia, Ja, Ya, db, eb, fb, gb, hb, ib, jb, kb, lb, mb, nb, ob, pb, qb, rb, sb, tb, ub, vb, wb, xb, yb, zb, Ab, Cb, Db, v, w, jc, C, D, E, F, x, Jb, Kb, kc, lc, mc, nc, wc, Kc, Pc, Fc, X, Y, {
                                                condition: "includeNestedComments",
                                                kind: "Condition",
                                                passingValue: !1,
                                                selections: [{
                                                    alias: null,
                                                    args: null,
                                                    concreteType: "Feedback",
                                                    kind: "LinkedField",
                                                    name: "feedback",
                                                    plural: !1,
                                                    selections: [Vb, Wb],
                                                    storageKey: null
                                                }, oc]
                                            }],
                                            storageKey: null
                                        }, wa],
                                        storageKey: null
                                    }, Q, S, l, Jc, M, Dc, Sa, {
                                        condition: "includeNestedComments",
                                        kind: "Condition",
                                        passingValue: !1,
                                        selections: [{
                                            alias: null,
                                            args: null,
                                            concreteType: "Comment",
                                            kind: "LinkedField",
                                            name: "highlighted_comments",
                                            plural: !0,
                                            selections: [{
                                                alias: null,
                                                args: null,
                                                concreteType: null,
                                                kind: "LinkedField",
                                                name: "author",
                                                plural: !1,
                                                selections: [h, c, V, Ib, a],
                                                storageKey: null
                                            }, G, a],
                                            storageKey: null
                                        }]
                                    }, Qc],
                                    storageKey: null
                                }, {
                                    alias: null,
                                    args: $b,
                                    filters: Rc,
                                    handle: "ufi2_comments",
                                    key: "UFI2CommentsProvider_feedback_display_comments",
                                    kind: "LinkedHandle",
                                    name: "display_comments",
                                    dynamicKey: Sc
                                }, Tc, Ic, Uc, Vc, Wc, Xc, Zc, g, u],
                                storageKey: null
                            }, kc, lc, mc, nc, dc, ec, N, O, Yb, Zb, Da, Ea, {
                                kind: "ClientExtension",
                                selections: [rc, uc, tc, vc, sc, pc, qc]
                            }, {
                                condition: "containerIsFeedStory",
                                kind: "Condition",
                                passingValue: !0,
                                selections: [p, I, q, T, W, d, e, r, y, {
                                    alias: null,
                                    args: null,
                                    concreteType: "Feedback",
                                    kind: "LinkedField",
                                    name: "feedback",
                                    plural: !1,
                                    selections: [z, A, b, zc, Ac, Bc],
                                    storageKey: null
                                }, Cc, Ec, yc, Z, k, Hc, h, P, R]
                            }, {
                                condition: "containerIsLiveStory",
                                kind: "Condition",
                                passingValue: !0,
                                selections: [p, I, e, Mc, y, $, Cc, Ec, Z, k, Oc, h, R]
                            }, {
                                condition: "containerIsTahoe",
                                kind: "Condition",
                                passingValue: !0,
                                selections: [p, I, e, Lc, y, $, Cc, Ec, Z, k, j, h, R]
                            }, {
                                condition: "containerIsWorkplace",
                                kind: "Condition",
                                passingValue: !0,
                                selections: [Gc, I, q, T, d, y, $, Nc, Z, s, k, xc, h, U, P, R]
                            }, Y],
                            storageKey: null
                        }],
                        storageKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: ba("UFI2CreateCommentSubscription_facebookRelayOperation"),
                metadata: {
                    subscriptionName: "comment_create_subscribe"
                },
                name: "UFI2CreateCommentSubscription",
                operationKind: "subscription",
                text: null
            }
        }
    }();
    ea.exports = aa
}), null);
__d("UFI2TypingSubscription_facebookRelayOperation", [], (function(a, b, c, d, e, f) {
    e.exports = "5600593223301846"
}), null);
__d("UFI2TypingSubscription.graphql", ["UFI2TypingSubscription_facebookRelayOperation"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        var a = [{
                defaultValue: null,
                kind: "LocalArgument",
                name: "input"
            }],
            c = [{
                kind: "Variable",
                name: "data",
                variableName: "input"
            }],
            d = [{
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [{
                    args: null,
                    kind: "FragmentSpread",
                    name: "UFI2TypingIndicatorImpl_feedback"
                }],
                storageKey: null
            }],
            e = [{
                alias: null,
                args: null,
                concreteType: "Feedback",
                kind: "LinkedField",
                name: "feedback",
                plural: !1,
                selections: [{
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "id",
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    concreteType: "FeedbackTypersConnection",
                    kind: "LinkedField",
                    name: "feedback_typers",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "other_count",
                        storageKey: null
                    }],
                    storageKey: null
                }, {
                    alias: null,
                    args: null,
                    kind: "ScalarField",
                    name: "subscription_target_id",
                    storageKey: null
                }],
                storageKey: null
            }];
        return {
            fragment: {
                argumentDefinitions: a,
                kind: "Fragment",
                metadata: null,
                name: "UFI2TypingSubscription",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "feedback_typing_subscribe",
                    plural: !1,
                    selections: [{
                        kind: "InlineFragment",
                        selections: d,
                        type: "FeedbackStartTypingResponsePayload",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: d,
                        type: "FeedbackStopTypingResponsePayload",
                        abstractKey: null
                    }],
                    storageKey: null
                }],
                type: "Subscription",
                abstractKey: null
            },
            kind: "Request",
            operation: {
                argumentDefinitions: a,
                kind: "Operation",
                name: "UFI2TypingSubscription",
                selections: [{
                    alias: null,
                    args: c,
                    concreteType: null,
                    kind: "LinkedField",
                    name: "feedback_typing_subscribe",
                    plural: !1,
                    selections: [{
                        alias: null,
                        args: null,
                        kind: "ScalarField",
                        name: "__typename",
                        storageKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: e,
                        type: "FeedbackStartTypingResponsePayload",
                        abstractKey: null
                    }, {
                        kind: "InlineFragment",
                        selections: e,
                        type: "FeedbackStopTypingResponsePayload",
                        abstractKey: null
                    }],
                    storageKey: null
                }]
            },
            params: {
                id: b("UFI2TypingSubscription_facebookRelayOperation"),
                metadata: {
                    subscriptionName: "feedback_typing_subscribe"
                },
                name: "UFI2TypingSubscription",
                operationKind: "subscription",
                text: null
            }
        }
    }();
    e.exports = a
}), null);
__d("cometFeedComposerCometMentionsTypeSelectionPayloadDecorator", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a.entries,
            c = b.filter(function(a) {
                return g(a)
            });
        b = b.filter(function(a) {
            return !g(a)
        });
        return babelHelpers["extends"]({}, a, {
            entries: c.concat(b)
        })
    }

    function g(a) {
        return a.rawData.type === "MENTION_TYPE_SELECTION" || a.rawData.type === "MENTION_TYPE_RESET"
    }
    f["default"] = a
}), 66);
__d("createFeedCometMentionsDataEntry", ["createFeedCometMentionsDataEntryWithTagSuggestion_data.graphql", "createFeedCometMentionsDataEntryWithTag_data.graphql", "createFeedCometMentionsDataEntry_data.graphql", "createFeedCometMentionsDataEntry_profile.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k;
    h !== void 0 ? h : h = b("createFeedCometMentionsDataEntry_data.graphql");
    i !== void 0 ? i : i = b("createFeedCometMentionsDataEntryWithTag_data.graphql");
    j !== void 0 ? j : j = b("createFeedCometMentionsDataEntryWithTagSuggestion_data.graphql");
    k !== void 0 ? k : k = b("createFeedCometMentionsDataEntry_profile.graphql");

    function a(a) {
        var b;
        b = a.data.node;
        if (b == null) return null;
        b = b;
        var c = b.id,
            d = b.name;
        b = b.photo;
        b = b == null ? void 0 : b.uri;
        if (d == null || c == null || b == null) return null;
        if (a.type === "MENTION_SEARCH_RESULT") {
            var e, f = a.data.score;
            if (f == null) return null;
            e = Boolean((e = a.data.node) == null ? void 0 : e.is_verified);
            var g = "circle";
            switch (a.data.icon_shape) {
                case "square":
                    g = "square";
                    break;
                case "roundedRect":
                    g = "roundedRect";
                    break
            }
            return {
                key: c,
                label: d,
                rawData: {
                    iconShape: g,
                    isExternal: !1,
                    isVerified: e,
                    photoURI: b,
                    score: f,
                    subtext: (g = a.data.node) == null ? void 0 : g.mentions_subtext,
                    type: "MENTION_SEARCH_RESULT"
                },
                type: "entry"
            }
        }
        return {
            key: c,
            label: d,
            rawData: {
                photoURI: b,
                type: a.type
            },
            type: "entry"
        }
    }
    g["default"] = a
}), 98);
__d("BaseTypeaheadLocalStorageDataProviderStorageKey", ["$InternalEnum"], (function(a, b, c, d, e, f) {
    "use strict";
    a = "_SearchBootstrapCache_";
    c = b("$InternalEnum").Mirrored(["FeedComposerMentionsIntentfulMentionsBootstrap", "FeedComposerMentionsNonIntentfulMentionsBootstrap", "FeedComposerMentionsWithTagBootstrap", "GlobalTypeaheadBootstrapEntities", "GlobalTypeaheadBootstrapKeywords"]);
    f.StorageKeyPrefix = a;
    f.StorageKey = c
}), 66);
__d("BaseTypeaheadLocalStorageDataProvider", ["BaseTypeaheadDataProvider", "BaseTypeaheadLocalStorageDataProviderStorageKey", "Promise", "WebStorage", "recoverableViolation"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 1e3 * 60 * 60 * 24;
    a = function() {
        function a(a) {
            var b = a.storageKey,
                e = a.storageTimespan;
            e = e === void 0 ? h : e;
            a = babelHelpers.objectWithoutPropertiesLoose(a, ["storageKey", "storageTimespan"]);
            this.$1 = new(c("BaseTypeaheadDataProvider"))(a);
            this.$3 = b != null ? d("BaseTypeaheadLocalStorageDataProviderStorageKey").StorageKeyPrefix + b : null;
            this.$4 = e;
            b = a.queryVariablesBuilder;
            this.$2 = b
        }
        var e = a.prototype;
        e.fetch = function(a) {
            var c = this,
                d = this.$3 != null ? this.$5(a) : null;
            if (d != null) {
                var e = this.$2.build();
                e = e(a);
                return b("Promise").resolve({
                    requestQueryVariables: e,
                    response: d
                })
            }
            return this.$1.fetch(a).then(function(b) {
                var d = b.response;
                d != null && c.$3 != null && c.$6(a, d);
                return b
            })
        };
        e.clearLocalStorage = function() {
            var a = this.$3,
                b = c("WebStorage").getLocalStorage();
            if (b == null || a == null) return;
            b.removeItem(a)
        };
        e.$5 = function(a) {
            var b = this.$3,
                d = c("WebStorage").getLocalStorage();
            if (d == null || b == null) return null;
            var e = d.getItem(b);
            if (e == null) return null;
            var f;
            try {
                f = JSON.parse(e)
            } catch (a) {
                c("recoverableViolation")("Cannot deserialize bootstrap response from local storage due to error: " + a, "search")
            }
            if (f == null) return null;
            e = f;
            var g = e.queryVariables,
                h = e.response;
            e = e.timestamp;
            var i = this.$2.build();
            i = i(a);
            if (JSON.stringify(g) !== JSON.stringify(i)) {
                d.removeItem(b);
                return null
            }
            a = Date.now();
            if (e + Number(this.$4) >= a) return h;
            d.removeItem(b);
            return null
        };
        e.$6 = function(a, b) {
            var d = this.$3,
                e = c("WebStorage").getLocalStorage();
            if (e == null || d == null) return;
            var f = this.$2.build();
            f = f(a);
            try {
                a = Date.now();
                f = JSON.stringify({
                    queryVariables: f,
                    response: b,
                    timestamp: a
                });
                e.setItem(d, f)
            } catch (a) {
                c("recoverableViolation")("Cannot save bootstrap response to local storage due to error: " + a, "search")
            }
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("useCometTypeaheadCompositeBootstrapWithLocalStorageDataSource", ["BaseTypeaheadDataProviderQueryVariablesBuilder", "BaseTypeaheadLocalStorageDataProvider", "BaseTypeaheadPayloadDecoratorAddLimit", "CometRelay", "CometTypeaheadGraphQLBootstrapDataSource", "react", "useDeepEqualMemo"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;

    function a(a) {
        var b = a.fetchPolicy,
            e = a.gqlQuery,
            f = a.limit,
            g = a.matchStrategy,
            i = a.normalize,
            j = a.queryVariables,
            k = a.storageKey,
            l = h(function() {
                return c("BaseTypeaheadPayloadDecoratorAddLimit")(f)
            }, [f]),
            m = d("CometRelay").useRelayEnvironment();
        a = c("useDeepEqualMemo")(j);
        var n = h(function() {
            var a = new(c("BaseTypeaheadDataProviderQueryVariablesBuilder"))(function() {
                return function() {
                    return j
                }
            });
            a = new(c("BaseTypeaheadLocalStorageDataProvider"))({
                options: {
                    fetchPolicy: b
                },
                query: e,
                queryVariablesBuilder: a,
                relayEnvironment: m,
                storageKey: k
            });
            return new(c("CometTypeaheadGraphQLBootstrapDataSource"))({
                bootstrapDataProvider: a,
                matchStrategy: g,
                normalize: i
            })
        }, [a, m]);
        return h(function() {
            return {
                bootstrap: function() {
                    return n.bootstrap()
                },
                fetchCache: function(a) {
                    return l(n.fetchCache(a))
                }
            }
        }, [n, l])
    }
    g["default"] = a
}), 98);
__d("useFeedComposerCometMentionsBootloadDataSource", ["WebPixelRatio", "createFeedCometMentionsDataEntry", "qex", "useCometTypeaheadCompositeBootstrapWithLocalStorageDataSource", "useFeedComposerCometMentionsBootloadDataSourceQuery.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("useFeedComposerCometMentionsBootloadDataSourceQuery.graphql");

    function a(a) {
        var b = a.firstDegreeFinderOptions,
            e = a.includeViewer,
            f = a.limit,
            g = a.matchStrategy;
        g = g === void 0 ? "prefix" : g;
        var h = a.storageKey,
            k = a.typeaheadContext;
        a = a.types;
        return c("useCometTypeaheadCompositeBootstrapWithLocalStorageDataSource")({
            gqlQuery: i,
            limit: f,
            matchStrategy: g,
            normalize: j,
            queryVariables: {
                include_viewer: e,
                options: b,
                scale: d("WebPixelRatio").get(),
                typeahead_context: k,
                types: a
            },
            storageKey: h
        })
    }

    function j(a) {
        a = a == null ? void 0 : a.comet_composer_typeahead_bootload;
        if (!c("qex")._("1301")) return [];
        return a == null ? [] : a.map(function(a) {
            if (a == null) return;
            return c("createFeedCometMentionsDataEntry")({
                data: a,
                type: "MENTION_SEARCH_RESULT"
            })
        }).filter(Boolean)
    }
    g["default"] = a
}), 98);
__d("useFeedComposerCometMentionsNetworkDataSource", ["WebPixelRatio", "createFeedCometMentionsDataEntry", "useCometTypeaheadGraphQLDataSource", "useFeedComposerCometMentionsNetworkDataSourceQuery.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("useFeedComposerCometMentionsNetworkDataSourceQuery.graphql");

    function a(a) {
        var b = a.enableTypeSelection,
            e = b === void 0 ? !1 : b,
            f = a.includeViewer,
            g = a.limit,
            h = a.typeaheadContext,
            k = a.types;
        return c("useCometTypeaheadGraphQLDataSource")({
            gqlQuery: i,
            limit: g,
            normalize: j,
            queryVariablesBuilderFunction: function(a) {
                a = a.query;
                return {
                    count: g,
                    enable_type_selection: e,
                    include_viewer: f,
                    query: a,
                    scale: d("WebPixelRatio").get(),
                    typeahead_context: h,
                    types: k
                }
            }
        })
    }

    function j(a) {
        a = a == null ? void 0 : a.comet_composer_typeahead_search;
        return a == null ? [] : a.map(function(a) {
            var b;
            if (a == null) return;
            switch (a.__typename) {
                case "CometComposerTypeaheadResultEntry":
                    return c("createFeedCometMentionsDataEntry")({
                        data: a,
                        type: "MENTION_SEARCH_RESULT"
                    });
                case "XFBMentionsTypeSelectionEntry":
                    return a.cache_id == null || a.label == null ? null : {
                        key: a.cache_id,
                        label: a.label,
                        rawData: {
                            iconName: (b = a.icon_name) != null ? b : "",
                            type: "MENTION_TYPE_SELECTION",
                            typesToShow: a.types_to_show.map(function(a) {
                                return a
                            })
                        },
                        type: "entry"
                    };
                case "XFBMentionsTypeResetEntry":
                    return a.cache_id == null || a.label == null ? null : {
                        key: a.cache_id,
                        label: a.label,
                        rawData: {
                            type: "MENTION_TYPE_RESET"
                        },
                        type: "entry"
                    };
                default:
                    return null
            }
        }).filter(Boolean)
    }
    g["default"] = a
}), 98);
__d("useFeedComposerCometMentionsNullstateDataSource", ["WebPixelRatio", "createFeedCometMentionsDataEntry", "useCometTypeaheadGraphQLDataSource", "useFeedComposerCometMentionsNullstateDataSourceQuery.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("useFeedComposerCometMentionsNullstateDataSourceQuery.graphql");

    function a(a) {
        var b = a.limit;
        return c("useCometTypeaheadGraphQLDataSource")({
            gqlQuery: i,
            limit: b,
            normalize: j,
            queryVariablesBuilderFunction: function() {
                return {
                    count: b,
                    scale: d("WebPixelRatio").get()
                }
            }
        })
    }

    function j(a) {
        a = a == null ? void 0 : a.comet_composer_typeahead_search;
        return a == null ? [] : a.map(function(a) {
            if (a == null) return;
            return c("createFeedCometMentionsDataEntry")({
                data: a,
                type: "MENTION_SEARCH_RESULT"
            })
        }).filter(Boolean)
    }
    g["default"] = a
}), 98);
__d("useFeedComposerCometMentionsDataSourceResolverConfig", ["BaseTypeaheadLocalStorageDataProviderStorageKey", "MentionsCommonWordsBlocklist", "cometFeedComposerCometMentionsTypeSelectionPayloadDecorator", "cr:1916546", "createCometAtSignComposerMentionsMatchStrategy", "createCometMentionsNameMatchStrategy", "gkx", "qex", "react", "useCometMentionsDataSourceResolverConfig", "useCometTypeaheadCompositeDataSource", "useFeedComposerCometMentionsBootloadDataSource", "useFeedComposerCometMentionsNetworkDataSource"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo,
        i = c("qex")._("1302"),
        j = c("qex")._("1250"),
        k = c("gkx")("3923"),
        l = ["user", "workrooms_user", "group", "event", "page"];

    function a(a) {
        var b = a.enableTypeSelection;
        b = b === void 0 ? !1 : b;
        var e = a.limit,
            f = a.mentionTypes;
        f = f === void 0 ? l : f;
        a = a.shouldBootstrapOnLayoutEffect;
        var g = m({
                bootstrapOptions: {
                    includeViewer: !0,
                    typeaheadContext: "mentions",
                    types: ["USER", "WORKROOMS_USER", "GROUP", "EVENT", "PAGE"]
                },
                cacheKey_SEARCH_ONLY: {
                    enableTypeSelection: b,
                    mentionTypes: f,
                    type: "feed_mentions_intentful_datasource_cache_key"
                },
                enableTypeSelection: b,
                limit: e,
                networkOptions: {
                    includeViewer: !0,
                    typeaheadContext: "mentions",
                    types: f
                }
            }),
            n = c("useCometTypeaheadCompositeDataSource")({
                bootstrapDataSource: c("useFeedComposerCometMentionsBootloadDataSource")({
                    firstDegreeFinderOptions: ["FRIENDS_ONLY"],
                    includeViewer: !0,
                    limit: Math.floor(e / 2),
                    matchStrategy: "token",
                    storageKey: c("gkx")("1864085") ? d("BaseTypeaheadLocalStorageDataProviderStorageKey").StorageKey.FeedComposerMentionsNonIntentfulMentionsBootstrap : null,
                    typeaheadContext: "mentions",
                    types: ["USER", "WORKROOMS_USER"]
                }),
                cacheKey_SEARCH_ONLY: {
                    type: "feed_mentions_non_intentful_datasource_cache_key"
                },
                limit: e
            });
        b = h(function() {
            var a = [{
                dataSource: g,
                matchStrategy: c("createCometAtSignComposerMentionsMatchStrategy")({
                    minMatchLength: i === !0 ? 0 : 1
                })
            }];
            if (k) return a;
            a.push({
                dataSource: n,
                matchStrategy: c("createCometMentionsNameMatchStrategy")({
                    commonWordsBlocklist: c("MentionsCommonWordsBlocklist").wordList,
                    minMatchLength: 3,
                    nameCase: "capitalized"
                })
            });
            j === !0 && a.push({
                dataSource: n,
                matchStrategy: c("createCometMentionsNameMatchStrategy")({
                    commonWordsBlocklist: c("MentionsCommonWordsBlocklist").wordList,
                    minMatchLength: 4,
                    nameCase: "lower-case"
                })
            });
            return a
        }, [g, n]);
        return c("useCometMentionsDataSourceResolverConfig")(b, a)
    }

    function m(a) {
        var e = a.bootstrapOptions,
            f = a.cacheKey_SEARCH_ONLY,
            g = a.enableTypeSelection,
            i = a.limit;
        a = a.networkOptions;
        var j = b("cr:1916546")({
                limit: i
            }),
            k = h(function() {
                return g ? [c("cometFeedComposerCometMentionsTypeSelectionPayloadDecorator")] : []
            }, [g]);
        return c("useCometTypeaheadCompositeDataSource")({
            bootstrapDataSource: c("useFeedComposerCometMentionsBootloadDataSource")(babelHelpers["extends"]({
                limit: Math.floor(i / 2)
            }, e, {
                storageKey: c("gkx")("1864085") ? d("BaseTypeaheadLocalStorageDataProviderStorageKey").StorageKey.FeedComposerMentionsIntentfulMentionsBootstrap : null
            })),
            cacheKey_SEARCH_ONLY: f,
            limit: i,
            networkDataSource: c("useFeedComposerCometMentionsNetworkDataSource")(babelHelpers["extends"]({
                enableTypeSelection: g,
                limit: i
            }, a)),
            nullstateDataSource: j != null ? j : void 0,
            payloadDecorators: k
        })
    }
    g["default"] = a
}), 98);
__d("FeedComposerCometMentionsMentionTypeResetViewItem.react", ["ix", "CometListCellStrict.react", "CometSearchMentionsBaseViewItem.react", "TetraText.react", "fbicon", "react", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = {
            addOnIconVertical: {
                marginBottom: "xat24cr",
                marginTop: "xdj266r"
            },
            text: {
                minWidth: "x15huedd"
            }
        };

    function a(a) {
        var b = a.entry.label;
        return i.jsx(c("CometSearchMentionsBaseViewItem.react"), babelHelpers["extends"]({}, a, {
            children: i.jsx(c("CometListCellStrict.react"), {
                addOnStart: {
                    icon: d("fbicon")._(h("492485"), 16),
                    type: "icon"
                },
                addOnStartOverrideVerticalStyle: j.addOnIconVertical,
                addOnStartVerticalAlign: "center",
                contentHorizontalPadding: 0,
                headline: i.jsx("div", {
                    className: c("stylex")(j.text),
                    children: i.jsx(c("TetraText.react"), {
                        type: "headlineEmphasized4",
                        children: b
                    })
                }),
                level: 4,
                paddingHorizontal: 0
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("FeedComposerCometMentionsMentionTypeSelectionViewItem.react", ["ix", "CometListCellStrict.react", "CometSearchMentionsBaseViewItem.react", "TetraText.react", "fbicon", "react", "recoverableViolation", "stylex"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react"),
        j = {
            addOnIcon: {
                marginBottom: "xat24cr",
                marginTop: "xdj266r"
            },
            text: {
                minWidth: "xcqhk00"
            }
        };

    function a(a) {
        var b = a.entry,
            e = b.label;
        b = b.rawData;
        b = b.type === "MENTION_TYPE_SELECTION" ? b.iconName : null;
        if (b == null) {
            c("recoverableViolation")("No icon name found for mention type selection entry", "comet_composer");
            return null
        }
        var f = null;
        switch (b) {
            case "shops":
                f = d("fbicon")._(h("1664042"), 20);
                break;
            default:
                break
        }
        return i.jsx(c("CometSearchMentionsBaseViewItem.react"), babelHelpers["extends"]({}, a, {
            children: i.jsx(c("CometListCellStrict.react"), {
                addOnEnd: {
                    color: "secondary",
                    icon: d("fbicon")._(h("492533"), 16),
                    type: "icon"
                },
                addOnEndVerticalAlign: "center",
                addOnStart: f != null ? {
                    icon: f,
                    size: 40,
                    type: "contained-icon"
                } : null,
                addOnStartOverrideVerticalStyle: j.addOnIcon,
                addOnStartVerticalAlign: "center",
                contentHorizontalPadding: 0,
                headline: i.jsx("div", {
                    className: c("stylex")(j.text),
                    children: i.jsx(c("TetraText.react"), {
                        type: "headlineEmphasized4",
                        children: e
                    })
                }),
                level: 4,
                paddingHorizontal: 0
            })
        }))
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("FeedComposerCometMentionsViewItemResolver.react", ["FeedComposerCometMentionsMentionTypeResetViewItem.react", "FeedComposerCometMentionsMentionTypeSelectionViewItem.react", "FeedComposerCometMentionsViewItem.react", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");

    function a(a) {
        var b = a.entry;
        a = babelHelpers.objectWithoutPropertiesLoose(a, ["entry"]);
        var d = b.rawData;
        switch (d.type) {
            case "MENTION_TYPE_SELECTION":
                return h.jsx(c("FeedComposerCometMentionsMentionTypeSelectionViewItem.react"), babelHelpers["extends"]({
                    entry: b
                }, a));
            case "MENTION_TYPE_RESET":
                return h.jsx(c("FeedComposerCometMentionsMentionTypeResetViewItem.react"), babelHelpers["extends"]({
                    entry: b
                }, a));
            default:
                return h.jsx(c("FeedComposerCometMentionsViewItem.react"), babelHelpers["extends"]({
                    entry: b
                }, a))
        }
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("MercuryTypingAnimation_DEPRECATED.react", ["cx", "joinClasses", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            return i.jsx("div", {
                className: c("joinClasses")("_4a0v _1x3z", this.props.className),
                children: i.jsxs("div", {
                    className: "_4b0g",
                    children: [i.jsx("div", {
                        className: "_5pd7"
                    }), i.jsx("div", {
                        className: "_5pd7"
                    }), i.jsx("div", {
                        className: "_5pd7"
                    })]
                })
            })
        };
        return b
    }(i.PureComponent);
    g["default"] = a
}), 98);
__d("addFocusEvents", ["Deferred", "Event", "SubscriptionList", "promiseDone", "react"], (function(a, b, c, d, e, f, g) {
    var h = d("react"),
        i = h.Component,
        j;
    a = function(a) {
        var b = function(d) {
            babelHelpers.inheritsLoose(b, d);

            function b() {
                return d.apply(this, arguments) || this
            }
            var e = b.prototype;
            e.componentDidMount = function() {
                var a = this;
                if (!j) {
                    var b, d;
                    j = new(c("SubscriptionList"))(function() {
                        b = c("Event").listen(window, "blur", function() {
                            j && j.fireCallbacks(!0), d && d.remove(), d = c("Event").listen(document.documentElement, "focusin", function() {
                                j && j.fireCallbacks(!1), d && d.remove(), d = null
                            })
                        })
                    }, function() {
                        b && b.remove(), d && d.remove(), b = null, d = null, j = null
                    })
                }
                this.subscription = j.add(function(b) {
                    a.locked = b
                })
            };
            e.componentWillUnmount = function() {
                this.subscription && this.subscription.remove()
            };
            e.onClick = function(a) {
                this.props.onClick && this.props.onClick(a), this.deferred && this.deferred.resolve(this.props.onMouseFocus)
            };
            e.onFocus = function(a) {
                var b = this;
                this.deferred && (this.deferred.reject(), this.deferred = null);
                if (this.locked) return;
                this.deferred = new(c("Deferred"))();
                c("promiseDone")(this.deferred.getPromise(), function(c) {
                    c && c(a), b.deferred = null
                }, function() {})
            };
            e.onKeyUp = function(a) {
                this.props.onKeyUp && this.props.onKeyUp(a), this.deferred && this.deferred.resolve(this.props.onKeyboardFocus)
            };
            e.render = function() {
                var b = this.props,
                    c = b.forwardedRef;
                b.onKeyboardFocus;
                b.onMouseFocus;
                b = babelHelpers.objectWithoutPropertiesLoose(b, ["forwardedRef", "onKeyboardFocus", "onMouseFocus"]);
                return h.jsx(a, babelHelpers["extends"]({}, b, {
                    onClick: this.onClick.bind(this),
                    onFocus: this.onFocus.bind(this),
                    onKeyUp: this.onKeyUp.bind(this),
                    ref: c
                }))
            };
            return b
        }(i);
        return h.forwardRef(function(a, c) {
            return h.jsx(b, babelHelpers["extends"]({}, a, {
                forwardedRef: c
            }))
        })
    };
    b = a;
    g["default"] = b
}), 98);
__d("UFIReactionsDialogLayerImpl.react", ["csx", "cx", "invariant", "BrowserSupport", "CSS", "DOM", "DOMQuery", "DataStore", "Focus", "Layer", "Locale", "Parent", "RTLKeys", "ReactDOMComet", "ReactTransitionEvents", "Style", "SubscriptionsHandler", "TabbableElements", "Vector", "ViewportBounds", "cancelAnimationFrame", "clearTimeout", "ge", "getElementPosition", "getOverlayZIndex", "memoize", "react", "requestAnimationFrameAcrossTransitions", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g, h, i, j) {
    var k = d("react"),
        l = "_1oxh",
        m = "_2r6k",
        n = "_2r6j",
        o = d("BrowserSupport").hasCSSAnimations(),
        p = "_22uo",
        q = "_6fqy",
        r = 200,
        s = {},
        t = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a() {
                return b.apply(this, arguments) || this
            }
            var e = a.prototype;
            e.updatePosition = function() {
                var a = this.getInsertParent(),
                    b = this.getCausalElement();
                if (b == null) return !0;
                var e = c("Vector").getElementPosition(b),
                    f = c("Vector").getElementPosition(a);
                e = e.sub(f);
                f = c("Vector").getElementDimensions(a).x;
                d("Locale").isRTL() && (e.x = f - e.x);
                f = c("Vector").getViewportDimensions().x;
                var g = c("Vector").getElementDimensions(this.getContentRoot()).x;
                e.x = Math.min(e.x, f - g);
                d("Locale").isRTL() ? s.right = e.x + "px" : s.left = e.x + "px";
                s.top = e.y + "px";
                s.zIndex = this._getZIndex(b, a);
                f = this.getRoot();
                f != null || j(0, 4781);
                c("Style").apply(f, s);
                return !0
            };
            e._getZIndex = function(a, b) {
                a = c("getOverlayZIndex")(a, b);
                var e = d("Parent").byClass(b, "fbPhotoSnowliftContainer"),
                    f = e && d("DOMQuery").scry(e, ".stageWrapper")[0];
                f && (a = Math.max(a, c("getOverlayZIndex")(f, e)));
                f = c("ge")("pagelet_sidebar");
                if (f) {
                    e = d("DOMQuery").scry(f, ".fbChatSidebar")[0];
                    f = d("DOMQuery").scry(b, "._13pa")[0];
                    e && f == null && (a = Math.max(a, parseInt(c("Style").get(e, "z-index"), 10) + 1))
                }
                return a
            };
            e.getContentRoot = function() {
                return this.contentRoot
            };
            e._buildWrapper = function(a, b) {
                d("CSS").addClass(b, "_49v-");
                this.contentRoot = b;
                a = document.createElement("div");
                d("CSS").addClass(a, "_1oxj");
                a.appendChild(b);
                return a
            };
            return a
        }(c("Layer"));
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, e) {
            var f;
            f = a.call(this, b, e) || this;
            f.onTransitionHide = function() {
                d("ReactTransitionEvents").removeEndEventListener(f.layer.getContentRoot(), f.onTransitionHide), f.finishHide()
            };
            f.onTransitionShow = function() {
                var a = f.layer.getContentRoot();
                a != null || j(0, 4782);
                d("ReactTransitionEvents").removeEndEventListener(a, f.onTransitionShow);
                var b = c("requestAnimationFrameAcrossTransitions")(function() {
                    d("CSS").removeClass(a, n)
                });
                f.handler.addSubscriptions({
                    remove: function() {
                        c("cancelAnimationFrame")(b)
                    }
                })
            };
            f.onKeyDown = function(a) {
                var b = a.keyCode;
                if (!f.props.shouldRenderDialog && f.props.isScreenReader) return;
                if (b === c("RTLKeys").ESC || b === c("RTLKeys").RETURN || b === c("RTLKeys").SPACE || f.props.shouldRenderDialog !== !0 && b === c("RTLKeys").TAB) {
                    f.props.onLayerBlur && f.props.onLayerBlur(a);
                    if (f.props.shouldRenderDialog === !0) return;
                    var e = f.root.current,
                        g = d("TabbableElements").find(f.getContextualLayerParent()),
                        h = null,
                        i = [];
                    b = b === c("RTLKeys").TAB && a.shiftKey;
                    for (var j = 0; j < g.length; j++)
                        if (g[j].tabIndex > -1) {
                            if (e.compareDocumentPosition(g[j]) & 4) {
                                h = g[j];
                                break
                            }
                            b && i.push(g[j])
                        }
                    i.length && (h = i[i.length - 1]);
                    h && (d("Focus").set(h), a.preventDefault(), a.stopPropagation())
                }
            };
            f.getGlobalContainer = c("memoize")(function() {
                return c("ge")("globalContainer")
            });
            f.onParentLayerHide = f.finishHide.bind(babelHelpers.assertThisInitialized(f));
            f.root = k.createRef();
            return f
        }
        var e = b.prototype;
        e.componentDidMount = function() {
            var a = this.root.current;
            this.layer = new t({
                causalElement: a,
                insertParent: a
            }, document.createElement("div"));
            c("DOM").appendContent(a, this.layer.getRoot());
            this.handler = new(c("SubscriptionsHandler"))();
            this.props.onLayerBlur && this.handler.addSubscriptions(this.layer.subscribe("blur", this.props.onLayerBlur));
            this.handler.addSubscriptions(this.layer.subscribe("beforeshow", this.beforeShow.bind(this)), this.layer.subscribe("aftershow", this.afterShow.bind(this)), this.layer.subscribe("starthide", this.startHide.bind(this)));
            this.isInDocument() && this.forceUpdate()
        };
        e.componentDidUpdate = function() {
            this.layer && this.layer.conditionShow(this.props.shown), this.props.onLayerRender && this.props.onLayerRender()
        };
        e.componentWillUnmount = function() {
            if (this.layer) {
                var a = this.layer.getContentRoot();
                d("ReactTransitionEvents").removeEndEventListener(a, this.onTransitionHide);
                d("ReactTransitionEvents").removeEndEventListener(a, this.onTransitionShow);
                this.handler.release();
                this.handler = null;
                this.layer.destroy();
                this.layer = null
            }
        };
        e.isInDocument = function() {
            var a = this.root.current;
            return a && document.body.contains(a)
        };
        e.afterShow = function() {
            var a = this;
            this.root.current != null && d("CSS").removeClass(this.root.current, this.props.shouldRenderDialog === !0 ? "_8yj0" : "accessible_elem");
            var b = this.layer.getContentRoot();
            b != null || j(0, 4783);
            var e = c("getElementPosition")(b).y,
                f = c("ViewportBounds").getTop();
            d("CSS").conditionClass(b, l, !!(e && e < f));
            if (o) {
                d("ReactTransitionEvents").addEndEventListener(b, this.onTransitionShow);
                d("CSS").addClass(b, p);
                d("CSS").addClass(b, q);
                d("CSS").addClass(b, n);
                var g = c("setTimeoutAcrossTransitions")(function() {
                    a.props.setAnimatingDock(!1), d("CSS").removeClass(b, q)
                }, r);
                this.handler.addSubscriptions({
                    remove: function() {
                        c("clearTimeout")(g)
                    }
                })
            }
            if (this.props.shouldFocusOnShow()) {
                e = d("TabbableElements").find(b)[0];
                e && e.focus()
            }
        };
        e.beforeShow = function() {
            o && this.props.setAnimatingDock(!0);
            var a = this.getContextualLayerParent();
            !this.props.shouldRenderDialog && this.props.isScreenReader ? this.layer.setInsertParent(this.layer.getCausalElement()) : a !== this.layer.getInsertParent() && (this.layer.setInsertParent(a), this.setParentLayerSubscription(a))
        };
        e.setParentLayerSubscription = function(a) {
            if (a !== this.getGlobalContainer()) {
                this.parentLayerSubscription && this.parentLayerSubscription.unsubscribe();
                this.parentLayer = null;
                return
            }
            a = a;
            var b = null;
            while (a !== null) {
                b = d("DataStore").get(a, "layer");
                if (b) break;
                a = a.parentNode
            }
            if (b && b !== this.parentLayer) {
                this.parentLayerSubscription && this.parentLayerSubscription.unsubscribe();
                a = b.subscribe("hide", this.onParentLayerHide);
                this.handler.addSubscriptions(a);
                this.parentLayerSubscription = a;
                this.parentLayer = b
            }
        };
        e.startHide = function() {
            if (o && this.isInDocument()) {
                var a = this.layer.getContentRoot();
                a != null || j(0, 4784);
                d("ReactTransitionEvents").addEndEventListener(a, this.onTransitionHide);
                d("CSS").addClass(a, m)
            } else this.finishHide();
            return !1
        };
        e.finishHide = function() {
            this.root.current != null && d("CSS").addClass(this.root.current, this.props.shouldRenderDialog === !0 ? "_8yj0" : "accessible_elem");
            var a = this.layer.getContentRoot();
            a != null || j(0, 4785);
            o && (d("CSS").removeClass(a, l), d("CSS").removeClass(a, m), d("CSS").removeClass(a, p));
            this.layer.setInsertParent(this.layer.getCausalElement());
            this.layer.finishHide()
        };
        e.getContextualLayerParent = function() {
            var a = this.root.current;
            if (a instanceof Element) {
                a = d("Parent").byClass(a, "uiContextualLayerParent");
                if (a instanceof HTMLElement) return a
            }
            return document.body
        };
        e.renderLayer = function() {
            if (!this.layer) return null;
            var a = this.layer.getContentRoot();
            if (!a) return null;
            var b = this.props,
                c = b.isDarkBackground;
            b.isScreenReader;
            var e = b.noBackground;
            b.onLayerBlur;
            b.onLayerRender;
            var f = b.semiTransparentBackground;
            b.setAnimatingDock;
            b.shouldFocusOnShow;
            b.shouldRenderDialog;
            b.shown;
            b = babelHelpers.objectWithoutPropertiesLoose(b, ["isDarkBackground", "isScreenReader", "noBackground", "onLayerBlur", "onLayerRender", "semiTransparentBackground", "setAnimatingDock", "shouldFocusOnShow", "shouldRenderDialog", "shown"]);
            return d("ReactDOMComet").createPortal(k.jsxs("div", babelHelpers["extends"]({}, b, {
                className: "_1oxk always-enable-animations",
                onKeyDown: this.onKeyDown,
                children: [this.props.children, k.jsx("div", {
                    className: "_41nt" + (c ? " _3_jc" : "") + (f ? " _6la8" : "") + (e ? " hidden_elem" : ""),
                    style: {
                        height: this.props.height
                    }
                })]
            })), a)
        };
        e.render = function() {
            return k.jsx("div", {
                className: "_2r6l" + (this.props.shouldRenderDialog !== !0 ? " accessible_elem" : "") + (this.props.shouldRenderDialog === !0 ? " _8yj0" : ""),
                ref: this.root,
                children: this.renderLayer()
            })
        };
        return b
    }(k.Component);
    g["default"] = a
}), 98);
__d("UFIReactionsMenuImpl.react", ["cx", "fbt", "CometTrackingNodeProvider.react", "Event", "FocusRegion.react", "RTLKeys", "SubscriptionsHandler", "UFIReactionIcon.react", "UFIReactionTypes", "UFIReactionsDialogLayerImpl.react", "addFocusEvents", "focusScopeQueries", "gkx", "joinClasses", "react", "shallowCompare"], (function(a, b, c, d, e, f, g, h, i) {
    var j = d("react"),
        k = 8,
        l = 44,
        m = 39,
        n = i._("Reactions"),
        o = c("addFocusEvents")("span");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            var d;
            d = a.call(this) || this;
            d.selectedRef = j.createRef();
            d.$2 = function() {
                d.subscriptionsHandler != null && (d.subscriptionsHandler.release(), d.subscriptionsHandler = null)
            };
            d.focusSelected = function() {
                var a = d.selectedRef.current;
                a && a instanceof HTMLElement && a.focus()
            };
            d.onLayerRender = function() {
                d.props.shouldFocusOnShow() && d.focusSelected()
            };
            d.onKeyDown = function(a) {
                var b = a.keyCode;
                switch (b) {
                    case c("RTLKeys").RETURN:
                    case c("RTLKeys").SPACE:
                        a.preventDefault();
                        var e = d.state.supportedReactions[d.state.selectedIndex];
                        d.props.initialReaction === e && (e = c("UFIReactionTypes").NONE);
                        e != null && d.props.onReactionClick && d.props.onReactionClick(e, a);
                        break;
                    case c("RTLKeys").getLeft():
                    case c("RTLKeys").getRight():
                        if (d.props.shouldRenderDialog) break;
                        a.preventDefault();
                        d.setState(function(a) {
                            return {
                                selectedIndex: Math.max(0, Math.min(a.selectedIndex + (b === c("RTLKeys").getLeft() ? -1 : 1), a.supportedReactions.length - 1))
                            }
                        }, d.focusSelected);
                        break
                }
            };
            d.setAnimatingDock = function(a) {
                d.setState({
                    isAnimatingDock: a
                })
            };
            var e = b.supportedReactions.filter(function(a) {
                    return c("UFIReactionTypes").reactions[a] != null
                }),
                f = b.shouldFocusOnShow() ? Math.max(0, e.indexOf(b.initialReaction)) : -1;
            d.state = {
                isAnimatingDock: !1,
                prevPropsShown: b.shown,
                shouldRenderMenu: b.shown,
                selectedIndex: f,
                supportedReactions: e
            };
            d.hasAnimatedIcons = c("gkx")("991383");
            d.animatedIconsUsePackage = c("gkx")("991384");
            return d
        }
        b.getDerivedStateFromProps = function(a, b) {
            var d = a.supportedReactions.filter(function(a) {
                return c("UFIReactionTypes").reactions[a]
            });
            if ((!b.shouldRenderMenu || a.shouldRenderDialog && !b.prevPropsShown) && a.shown) {
                var e = a.shouldRenderDialog && a.shouldFocusOnShow() ? Math.max(0, d.indexOf(a.initialReaction)) : b.selectedIndex;
                return {
                    selectedIndex: e,
                    shouldRenderMenu: !0,
                    prevPropsShown: a.shown,
                    supportedReactions: d
                }
            }
            return !a.shown && b.prevPropsShown ? {
                selectedIndex: -1,
                prevPropsShown: a.shown,
                supportedReactions: d
            } : {
                supportedReactions: d,
                prevPropsShown: a.shown
            }
        };
        var e = b.prototype;
        e.componentDidMount = function() {
            this.props.shouldFocusOnShow() && this.focusSelected(), this.props.isLongPressing && this.$1()
        };
        e.componentWillUnmount = function() {
            this.$2()
        };
        e.componentDidUpdate = function(a) {
            this.props.shouldFocusOnShow() && !a.shouldFocusOnShow() && this.focusSelected(), this.props.isLongPressing && !a.isLongPressing ? this.$1() : !this.props.isLongPressing && a.isLongPressing && this.$2()
        };
        e.$1 = function() {
            var a = this,
                b;
            this.$2();
            this.subscriptionsHandler = new(c("SubscriptionsHandler"))();
            this.subscriptionsHandler.addSubscriptions(c("Event").listen(document.documentElement, "touchmove", function(c) {
                c.preventDefault();
                var d = c.touches[0];
                d = document.elementFromPoint(d.clientX, d.clientY);
                d && !d.getAttribute("data-reaction") && d.parentElement && (d = d.parentElement);
                d = d ? parseInt(d.getAttribute("data-reaction"), 10) || null : null;
                d !== b && (b && a.onReactionMouseLeave(b, c), d && a.onReactionMouseEnter(d, c), b = d)
            }), c("Event").listen(document.documentElement, "mousemove", function(c) {
                var d = document.elementFromPoint(c.clientX, c.clientY);
                if (d != null) {
                    !d.getAttribute("data-reaction") && d.parentElement && (d = d.parentElement);
                    d = parseInt(d.getAttribute("data-reaction"), 10) || null;
                    d !== b && (b && a.onReactionMouseLeave(b, c), d && a.onReactionMouseEnter(d, c), b = d)
                }
            }), c("Event").listen(document.documentElement, "touchcancel", this.$2), c("Event").listen(document.documentElement, "touchend", function(c) {
                a.$2(), b && a.onReactionClick(b, c)
            }), c("Event").listen(document.documentElement, "mouseup", function(c) {
                a.$2(), b && a.props.shown && a.onReactionClick(b, c)
            }))
        };
        e.shouldComponentUpdate = function(a, b) {
            return c("shallowCompare")(this, a, b)
        };
        e.onDragStart = function(a) {
            a.preventDefault()
        };
        e.onKeyboardFocus = function(a, b) {
            this.setState({
                selectedIndex: a
            }), this.props.onFocus && this.props.onFocus(b)
        };
        e.onReactionClick = function(a, b, c, d) {
            c === void 0 && (c = null), d === void 0 && (d = null), b.preventDefault(), !this.state.isAnimatingDock && this.props.onReactionClick != null && this.props.onReactionClick(a, b, c, d)
        };
        e.onReactionMouseEnter = function(a, b) {
            (!this.props.shouldRenderDialog || !this.props.shouldFocusOnShow()) && this.setState(function(b) {
                return {
                    selectedIndex: b.supportedReactions.indexOf(a)
                }
            }), this.props.onReactionMouseEnter && this.props.onReactionMouseEnter(a)
        };
        e.onReactionMouseLeave = function(a, b) {
            (!this.props.shouldRenderDialog || !this.props.shouldFocusOnShow()) && this.setState({
                selectedIndex: -1
            }), this.props.onReactionMouseLeave && this.props.onReactionMouseLeave(a)
        };
        e.onCloseFocus = function() {
            this.props.shouldRenderDialog && this.setState({
                selectedIndex: -1
            })
        };
        e.render = function() {
            var a = this,
                b = this.state.selectedIndex,
                e = this.state.supportedReactions.map(function(d, e) {
                    var f = c("UFIReactionTypes").reactions[d].display_name,
                        g = a.onReactionClick.bind(a, d),
                        h = Math.max(0, a.state.supportedReactions.indexOf(a.props.initialReaction)) === e,
                        i = a.props.icon,
                        k;
                    if (a.hasAnimatedIcons && i && i.supportsReaction(d)) {
                        var l = !!a.props.allowAnimationPlayback && a.props.shown;
                        k = !0;
                        i = j.jsx(i, {
                            animate: l,
                            className: "_1ef0",
                            selectedIndex: a.state.selectedIndex,
                            maxSize: m,
                            reactionID: d
                        })
                    } else k = !1, i = j.jsx(c("UFIReactionIcon.react"), {
                        reactionType: d,
                        size: 48
                    });
                    return j.jsx(c("CometTrackingNodeProvider.react"), {
                        trackingNode: 5,
                        children: j.jsx(o, {
                            "aria-pressed": a.props.initialReaction === d,
                            "aria-label": f,
                            className: "_iuw" + (b === e ? " _iuy" : ""),
                            "data-testid": void 0,
                            onClick: g,
                            onDragStart: a.onDragStart,
                            onKeyboardFocus: a.onKeyboardFocus.bind(a, e),
                            onMouseUp: a.props.onReactionMouseUp,
                            onMouseDown: a.props.onReactionMouseDown,
                            onMouseEnter: a.onReactionMouseEnter.bind(a, d),
                            onMouseLeave: a.onReactionMouseLeave.bind(a, d),
                            onTouchStart: a.onDragStart,
                            onTouchEnd: g,
                            ref: b === e ? a.selectedRef : null,
                            role: "button",
                            tabIndex: a.props.shouldRenderDialog || h && (!a.props.shown || b === -1 || b === e) ? 0 : -1,
                            children: j.jsx("div", {
                                className: "_39m" + (k ? " _1ef2" : ""),
                                "data-reaction": d,
                                children: j.jsxs("div", {
                                    className: "_39n",
                                    children: [i, j.jsx("div", {
                                        className: "_d6l",
                                        children: j.jsx("div", {
                                            className: "_4sm1",
                                            children: f
                                        })
                                    })]
                                })
                            })
                        })
                    }, "reaction_" + d)
                });
            if (!this.state.shouldRenderMenu) return null;
            e = j.jsxs("div", {
                className: c("joinClasses")("_iu-" + (this.props.shouldFocusOnShow() ? " _5wkt" : "") + " _628b", this.props.className),
                "data-testid": void 0,
                onKeyDown: this.onKeyDown,
                "aria-label": n,
                role: this.props.shouldRenderDialog ? "dialog" : "toolbar",
                children: [e, this.props.shouldRenderDialog ? j.jsx("div", {
                    className: "accessible_elem",
                    children: j.jsx("button", {
                        onClick: this.props.onBlur,
                        onFocus: this.onCloseFocus.bind(this),
                        type: "button",
                        children: i._("Close reactions")
                    })
                }) : null]
            });
            return this.props.shouldRenderInline === !0 ? e : j.jsx(d("FocusRegion.react").FocusRegion, {
                autoFocusQuery: this.props.shouldRenderDialog === !0 && this.props.shouldFocusOnShow() ? d("focusScopeQueries").focusableScopeQuery : null,
                autoRestoreFocus: this.props.shouldRenderDialog === !0,
                recoverFocusQuery: this.props.shouldRenderDialog === !0 ? d("focusScopeQueries").focusableScopeQuery : null,
                containFocusQuery: this.props.shouldRenderDialog === !0 && this.props.shouldFocusOnShow() ? d("focusScopeQueries").focusableScopeQuery : null,
                children: j.jsx(c("UFIReactionsDialogLayerImpl.react"), {
                    height: l + k,
                    setAnimatingDock: this.setAnimatingDock,
                    isDarkBackground: this.props.isDarkBackground,
                    isScreenReader: this.props.isScreenReader,
                    onLayerBlur: this.props.onBlur,
                    onLayerRender: this.onLayerRender,
                    onMouseEnter: this.props.onMouseEnter,
                    onMouseLeave: this.props.onMouseLeave,
                    noBackground: this.props.noBackground,
                    shouldFocusOnShow: this.props.shouldFocusOnShow,
                    shouldRenderDialog: this.props.shouldRenderDialog,
                    semiTransparentBackground: this.props.semiTransparentBackground,
                    shown: this.props.shown,
                    children: e
                })
            })
        };
        return b
    }(j.Component);
    g["default"] = a
}), 98);
__d("UFI2RichComposerInput.react", ["cx", "CometVisualCompletionAttributes", "DraftEditor.react", "Keys", "cr:2012305", "getDefaultKeyBinding", "getEditorStateFromUFI2ComposerState", "isSoftNewlineEvent", "joinClasses", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(d, a);

        function d() {
            var b, d;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = d = a.call.apply(a, [this].concat(f)) || this, d.$1 = function(a) {
                d.props.onComposerStateChange(function(b) {
                    return babelHelpers["extends"]({}, b, {
                        inputState: b.inputState.__type === "editor-state-based" ? babelHelpers["extends"]({}, b.inputState, {
                            editorState: a
                        }) : {
                            __type: "editor-state-based",
                            editorState: a
                        }
                    })
                })
            }, d.$2 = function(a, b) {
                return d.props.handleBeforeInput ? d.props.handleBeforeInput(a, b) : "not-handled"
            }, d.$3 = function(a, b) {
                if (d.props.handleKeyCommand && d.props.handleKeyCommand(a, b) === "handled") return "handled";
                if (a === "ufi-commit") {
                    d.props.onCommit();
                    return "handled"
                }
                return "not-handled"
            }, d.$4 = function(a) {
                if (d.props.keyBindingFn) {
                    var b = d.props.keyBindingFn(a);
                    if (b != null) return b
                }
                return a.keyCode === c("Keys").RETURN && !c("isSoftNewlineEvent")(a) ? "ufi-commit" : c("getDefaultKeyBinding")(a)
            }, b) || babelHelpers.assertThisInitialized(d)
        }
        var e = d.prototype;
        e.execCommand = function(a) {
            this.props.handleCommand && this.props.handleCommand(a)
        };
        e.componentWillUnmount = function() {
            var a = this.lastEditorRef;
            a && b("cr:2012305") && b("cr:2012305").unregisterTypingPerf(a)
        };
        e.render = function() {
            var a = this,
                d = this.props.composerState.ariaInputs__DRAFTJS_ONLY;
            return i.jsx("div", babelHelpers["extends"]({
                className: c("joinClasses")((this.props.composerState.isLocked ? "_3d2p" : "") + " _3d2q", this.props.className)
            }, c("CometVisualCompletionAttributes").IGNORE, {
                onClick: this.props.onClick,
                children: i.jsx(c("DraftEditor.react"), {
                    ariaActiveDescendantID: d ? d["aria-activedescendant"] : void 0,
                    ariaControls: d ? d["aria-controls"] : void 0,
                    ariaDescribedBy: this.props.ariaDescribedBy,
                    ariaLabel: String((d = this.props.ariaLabel) != null ? d : this.props.placeholder),
                    editorRef: function(c) {
                        var d = a.props.onInputRefUpdated;
                        d && d(c);
                        if (b("cr:2012305") === null) return;
                        d = a.lastEditorRef;
                        if (d === c || c === null) return;
                        c !== null && (b("cr:2012305").trackTypingPerf(c, "UFI2RichComposerInput", a.lastEditorRef, {
                            editor: "UFI2DraftEditor"
                        }), a.lastEditorRef = c)
                    },
                    editorState: c("getEditorStateFromUFI2ComposerState")(this.props.composerState),
                    handleBeforeInput: this.$2,
                    handleKeyCommand: this.$3,
                    handlePastedFiles: this.props.handlePastedFiles,
                    keyBindingFn: this.$4,
                    onBlur: this.props.onBlur,
                    onChange: this.$1,
                    onFocus: this.props.onFocus,
                    placeholder: String(this.props.placeholder),
                    placeholderClassName: this.props.placeholderClassName,
                    preventScroll: !0,
                    readOnly: this.props.composerState.isLocked,
                    spellCheck: !0,
                    stripPastedStyles: !0,
                    webDriverTestID: this.props.webDriverTestID
                })
            }))
        };
        return d
    }(i.Component);
    g["default"] = a
}), 98);
__d("upgradedUFI2MentionsComposerPluginCreatorWithTypeaheadViewForDraftjs", ["CometMentions.react", "CometMentionsLayoutStrategy.react", "FeedComposerCometMentionsViewItemResolver.react", "Keys", "MentionSpan.react", "WeakMentionSpan.react", "cometReplaceMentionedTextInEditorState", "createCometComposerMentionsEntity", "createUpgradedUFI2MentionsComposerPluginAnchorDecorator", "getCometComposerMentionsSearch", "getEntityMatcher", "installUFI2ComposerInputDecorators", "react", "recoverableViolation", "upgradedUFI2MentionsComposerPluginDraftUtils", "useCometMentionsLoggingProvider", "useCometTypeaheadViewListStrategy", "useFeedComposerCometMentionsDataSourceResolverConfig", "usePrevious", "useUpgradedUFI2MentionsComposerPluginInstaller"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react");
    b = d("react");
    var i = b.useCallback,
        j = b.useEffect,
        k = b.useImperativeHandle,
        l = b.useMemo,
        m = b.useRef,
        n = b.useState,
        o = {
            component: c("MentionSpan.react"),
            strategy: c("getEntityMatcher")(function(a) {
                return a.getType() === "MENTION"
            })
        },
        p = {
            component: c("WeakMentionSpan.react"),
            strategy: c("getEntityMatcher")(function(a) {
                return a.getType() === "MENTION" ? !!((a = a.getData()) == null ? void 0 : a.isWeak) : !1
            })
        };

    function a() {
        return function() {
            function a() {
                return h.forwardRef(function(a, b) {
                    var e = a.inputProps,
                        f = e.composerState,
                        g = e.onBlur,
                        r = e.onComposerStateChange,
                        s = e.onFocus;
                    e = a.onInstallContentBlockToTextWithEntitiesInputMessageMappers;
                    c("useUpgradedUFI2MentionsComposerPluginInstaller")(e);
                    a = n(!1);
                    e = a[0];
                    var t = a[1],
                        u = m(null),
                        v = m(!1);
                    a = n(null);
                    var w = a[0],
                        x = a[1];
                    a = c("useFeedComposerCometMentionsDataSourceResolverConfig")({
                        limit: 5,
                        shouldBootstrapOnLayoutEffect: !1
                    });
                    var y = a.bootstrap,
                        z = a.resolver,
                        A = d("upgradedUFI2MentionsComposerPluginDraftUtils").getMaybeEditorState(f),
                        B = c("usePrevious")(f);
                    a = c("useCometTypeaheadViewListStrategy")({
                        viewItemStrategyRenderer: c("FeedComposerCometMentionsViewItemResolver.react")
                    });
                    j(function() {
                        var a = f.inputState;
                        if (B == null) return;
                        var b = B.inputState;
                        if (a.__type === "editor-state-based" && (b.__type !== "editor-state-based" || b.__type === "editor-state-based" && b.editorState !== a.editorState)) {
                            b = c("getCometComposerMentionsSearch")(a.editorState);
                            x(b);
                            t(!1)
                        } else return
                    }, [f, B]);
                    var C = i(function(a) {
                            r(function(b) {
                                return babelHelpers["extends"]({}, b, {
                                    ariaInputs__DRAFTJS_ONLY: a
                                })
                            })
                        }, [r]),
                        D = i(function(a) {
                            g && g(a), C()
                        }, [g, C]),
                        E = i(function(a) {
                            y(), s && s(a)
                        }, [y, s]),
                        F = i(function(a, b) {
                            var d = u.current,
                                e = v.current;
                            if (a.keyCode === c("Keys").ESC && w != null) {
                                e && (a.preventDefault(), a.stopPropagation());
                                return "MentionsAutocomplete/cancel"
                            }
                            if (d != null && e) switch (a.keyCode) {
                                case c("Keys").DOWN:
                                    a.preventDefault();
                                    return "MentionsAutocomplete/next-mention";
                                case c("Keys").RETURN:
                                    if (d.hasSelection()) {
                                        a.preventDefault();
                                        return "MentionsAutocomplete/select-mention"
                                    }
                                    break;
                                case c("Keys").TAB:
                                    if (d.hasSelection()) {
                                        a.preventDefault();
                                        return "MentionsAutocomplete/select-mention"
                                    }
                                    break;
                                case c("Keys").UP:
                                    a.preventDefault();
                                    return "MentionsAutocomplete/previous-mention"
                            }
                            b && b(a)
                        }, [w]),
                        G = i(function(a) {
                            var b = u.current;
                            switch (a) {
                                case "MentionsAutocomplete/cancel":
                                    t(!0);
                                    break;
                                case "MentionsAutocomplete/select-mention":
                                    b && b.select();
                                    break;
                                case "MentionsAutocomplete/previous-mention":
                                    b && b.moveUp();
                                    break;
                                case "MentionsAutocomplete/next-mention":
                                    b && b.moveDown();
                                    break
                            }
                            return "not-handled"
                        }, []),
                        H = i(function(a) {
                            var b = f.inputState;
                            if (A == null || b.__type !== "editor-state-based") return;
                            b = c("getCometComposerMentionsSearch")(A);
                            if (b == null) {
                                c("recoverableViolation")("Race condition where the user selected a mention but theres no text in the editor", "search");
                                return
                            }
                            b = z(b);
                            b = b.searchResult;
                            if (b == null) {
                                c("recoverableViolation")("onPressEntry was called and no search result was found for the query", "CometComposer");
                                return
                            }
                            C();
                            var d = c("cometReplaceMentionedTextInEditorState")(a, A, b.replaceableString.length, function(a, b) {
                                return c("createCometComposerMentionsEntity")(b.key, !1, a)
                            }, function() {
                                return a.label
                            });
                            r(function(a) {
                                return q(a, d)
                            })
                        }, [f, z, C, A, r]),
                        I = m(null),
                        J = l(function() {
                            return c("createUpgradedUFI2MentionsComposerPluginAnchorDecorator")(z, I)
                        }, [z]);
                    k(b, function() {
                        return {
                            getUpgradedProps: function(a) {
                                var b = a.inputProps;
                                a = babelHelpers.objectWithoutPropertiesLoose(a, ["inputProps"]);
                                return babelHelpers["extends"]({}, a, {
                                    inputProps: babelHelpers["extends"]({}, b, {
                                        composerState: c("installUFI2ComposerInputDecorators")(b.composerState, J, p, o),
                                        handleKeyCommand: function(a) {
                                            return G(a)
                                        },
                                        keyBindingFn: function(a) {
                                            return F(a, b.keyBindingFn)
                                        },
                                        onBlur: D,
                                        onFocus: E
                                    })
                                })
                            }
                        }
                    });
                    b = i(function(a) {
                        v.current = a
                    }, []);
                    var K = i(function(a) {
                            if (a) return;
                            C()
                        }, [C]),
                        L = c("useCometMentionsLoggingProvider")({
                            context_id: null,
                            context_type: "undirected",
                            surface: "COMMENT",
                            typeahead_type: "ENTITY"
                        }),
                        M = i(function(a, b) {
                            (a == null || b == null) && C(), C({
                                "aria-activedescendant": a,
                                "aria-controls": b
                            })
                        }, [C]);
                    if (e) {
                        v.current = !1;
                        return null
                    }
                    e = I.current;
                    if (e == null) {
                        v.current = !1;
                        return null
                    }
                    var N = z(w),
                        O = N.dataSource;
                    N = N.searchResult;
                    if (N == null || O == null) {
                        v.current = !1;
                        return null
                    }
                    return h.jsx(c("CometMentions.react"), {
                        context: e,
                        dataSource: O,
                        editorHasFocus: !0,
                        layoutStrategyRenderer: c("CometMentionsLayoutStrategy.react"),
                        loggingProvider: L,
                        onAriaChange: M,
                        onBlur: D,
                        onEntriesUpdated: K,
                        onFocus: E,
                        onSelectedEntry: H,
                        onVisibilityChange: b,
                        position: "below",
                        queryString: N.matchingString,
                        ref: u,
                        viewStrategyRenderer: a
                    })
                })
            }
            return a
        }
    }

    function q(a, b) {
        var d = a.inputState;
        if (d.__type === "editor-state-based") return babelHelpers["extends"]({}, a, {
            inputState: babelHelpers["extends"]({}, d, {
                editorState: b
            })
        });
        c("recoverableViolation")("Unimplemented: tried to commit a searchable entity as a mention to a UFI2ComposerState " + ("with an inputState of type " + d.__type + ". ") + 'Only the "editor-state-based" type is supported at the moment', "search");
        return a
    }
    g["default"] = a
}), 98);
__d("createUpgradedUFI2MentionsComposerPluginForDraftjs", ["upgradedUFI2MentionsComposerPluginCreatorWithTypeaheadViewForDraftjs"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("upgradedUFI2MentionsComposerPluginCreatorWithTypeaheadViewForDraftjs")();
    g["default"] = a
}), 98);
__d("UFI2ReactionsMenu", ["cr:682215"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:682215")
}), 98);
__d("UFI2ActorPresenceProvider.react", ["Arbiter", "AvailableListConstants", "PresenceStatus", "SubscriptionsHandler", "react"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("react");
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.state = {
                isActive: !1
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var d = b.prototype;
        d.componentDidMount = function() {
            var a = this,
                b = this.props.actorID;
            this.$1 = new(c("SubscriptionsHandler"))();
            this.$1.addSubscriptions(c("Arbiter").subscribe(c("AvailableListConstants").ON_AVAILABILITY_CHANGED, function() {
                a.setState({
                    isActive: c("PresenceStatus").get(b) === c("AvailableListConstants").ACTIVE
                })
            }))
        };
        d.componentWillUnmount = function() {
            this.$1 && this.$1.release()
        };
        d.render = function() {
            return this.props.children(this.state.isActive)
        };
        return b
    }(a.PureComponent);
    g["default"] = b
}), 98);
__d("UFI2TypingIndicator.react", ["cx", "fbt", "MercuryTypingAnimation_DEPRECATED.react", "RelayHooks", "UFI2RealtimeContainer.react", "UFI2TypingIndicatorImpl_feedback.graphql", "UFI2TypingIndicator_feedback.graphql", "debounceAcrossTransitions", "gkx", "react", "requireDeferred", "useVisibilityObserver"], (function(a, b, c, d, e, f, g, h, i) {
    "use strict";
    var j, k, l = d("react");
    e = d("react");
    var m = e.useCallback,
        n = e.useEffect,
        o = e.useMemo,
        p = e.useState,
        q = c("requireDeferred")("UFI2TypingSubscription").__setRef("UFI2TypingIndicator.react"),
        r = 15 * 1e3;

    function s(a) {
        a = a.feedback_typers;
        return ((a = a == null ? void 0 : a.other_count) != null ? a : 0) > 0 ? i._("Someone is typing a comment...") : null
    }

    function t(a) {
        a = a.feedback;
        var e = p({
                isTyping: !1,
                isVisible: !1,
                label: null
            }),
            f = e[0],
            g = f.label,
            h = f.isVisible,
            i = f.isTyping,
            k = e[1],
            t = d("RelayHooks").useFragment(j !== void 0 ? j : j = b("UFI2TypingIndicatorImpl_feedback.graphql"), a),
            u = d("RelayHooks").useRelayEnvironment(),
            v = o(function() {
                return s(t)
            }, [t]);
        n(function() {
            k(function(a) {
                return babelHelpers["extends"]({}, a, {
                    isTyping: Boolean(v),
                    label: v != null ? v : a.label
                })
            })
        }, [v]);
        var w = o(function() {
            return c("debounceAcrossTransitions")(function() {
                return k(function(a) {
                    return babelHelpers["extends"]({}, a, {
                        isTyping: !1
                    })
                })
            }, r)
        }, []);
        n(function() {
            i === !0 && w();
            return function() {
                return w.reset()
            }
        }, [w, i]);
        f = m(function() {
            var a = t.id,
                b = t.subscription_target_id;
            if (a == null || b == null) return null;
            var c = !1,
                d = function() {};
            b = {
                dispose: function() {
                    c = !0, d(), w.reset()
                }
            };
            q.onReady(function(b) {
                if (!c) {
                    b = b.subscribe(u, a, {
                        onNext: function() {
                            w()
                        }
                    });
                    d = b.dispose
                }
            });
            return b
        }, [w, t, u]);
        e = m(function() {
            k(function(a) {
                return babelHelpers["extends"]({}, a, {
                    isVisible: !1
                })
            })
        }, []);
        a = m(function() {
            k(function(a) {
                return babelHelpers["extends"]({}, a, {
                    isVisible: !0
                })
            })
        }, []);
        e = c("useVisibilityObserver")({
            onHidden: e,
            onVisible: a
        });
        return l.jsx(c("UFI2RealtimeContainer.react"), {
            subscribe: f,
            children: l.jsx("div", {
                className: "_3bem",
                ref: e,
                children: l.jsxs("div", {
                    className: (h ? "_1kyy" : "") + " _3bep" + (i === !0 ? " __f9" : ""),
                    children: [l.jsx(c("MercuryTypingAnimation_DEPRECATED.react"), {
                        className: "__fa"
                    }), l.jsx("div", {
                        className: "__fb",
                        children: g
                    })]
                })
            })
        })
    }
    t.displayName = t.name + " [from " + f.id + "]";

    function a(a) {
        a = a.feedback;
        a = d("RelayHooks").useFragment(k !== void 0 ? k : k = b("UFI2TypingIndicator_feedback.graphql"), a);
        return a.is_eligible_for_real_time_updates === !1 || c("gkx")("1352841") ? null : l.jsx(t, {
            feedback: a
        })
    }
    a.displayName = a.name + " [from " + f.id + "]";
    g["default"] = a
}), 98);
__d("UFI2ViewOptionsSelectorImpl.react", ["cx", "PopoverMenu.react", "ReactXUIMenu", "joinClasses", "react"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = d("react");
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var d = b.prototype;
        d.render = function() {
            var a = this.props,
                b = a.onChange,
                d = a.alignh,
                e = a.menuClassName,
                f = a.selectorOptions,
                g = a.selectedOption,
                h = a.children;
            a = a.menuRef;
            e = i.jsx(c("ReactXUIMenu").SelectableMenu, {
                className: c("joinClasses")(e, "_21ii"),
                "data-testid": void 0,
                onItemClick: function(a, c) {
                    b(c.item.getValue())
                },
                children: f.map(function(a) {
                    return i.jsx(c("ReactXUIMenu").SelectableItem, {
                        label: a.title,
                        selected: g === a,
                        value: a.value,
                        children: i.jsxs("div", {
                            className: "_1ojq",
                            "data-ordering": a.value,
                            "data-testid": void 0,
                            children: [i.jsx("div", {
                                className: "_1ojr",
                                children: a.title
                            }), i.jsx("div", {
                                className: "_1ojv",
                                children: a.description
                            })]
                        })
                    }, a.value)
                })
            });
            return i.jsx(c("PopoverMenu.react"), {
                alignh: d,
                alignv: "baseline",
                className: "_21iq",
                menu: e,
                ref: a,
                children: h
            })
        };
        return b
    }(i.PureComponent);
    a.defaultProps = {
        alignh: "right"
    };
    g["default"] = a
}), 98);
__d("UFI2BanActorMutation", ["RelayModern", "UFI2BanActorMutation.graphql", "forEachUFI2DisplayCommentsConnection"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("UFI2BanActorMutation.graphql");
    a = function(a, b) {
        var e = b.actorId,
            f = b.feedbackId,
            g = b.pageId,
            h = b.targetUserId,
            j = b.undoBan;
        b.feedbackSource;
        b = function(a) {
            if (f == null) return;
            var b = a.get(f);
            if (!b) return;
            c("forEachUFI2DisplayCommentsConnection")(a, b, function(a) {
                a = a.getLinkedRecords("edges");
                if (!a) return;
                a.forEach(function(a) {
                    if (!a) return;
                    a = a.getLinkedRecord("node");
                    if (!a) return;
                    var b = a.getLinkedRecord("author");
                    if (!b) return;
                    if (b.getValue("id") === h) {
                        b = a.getValue("is_hidden_by_content_owner");
                        a.setValue(j && b !== !0 ? "none" : "spam", "spam_display_mode");
                        a.setValue(!j, "is_author_banned_by_content_owner")
                    }
                })
            })
        };
        return d("RelayModern").commitMutation(a, {
            mutation: i,
            optimisticResponse: {
                feedback_page_ban: {
                    __typename: "FeedbackPageBanResponsePayload"
                }
            },
            optimisticUpdater: b,
            updater: b,
            variables: {
                input: {
                    actor_id: e,
                    ban_action: j ? "UNDO_BAN" : "BAN",
                    page_id: g,
                    target_user_id: h
                }
            }
        })
    };
    g.commit = a
}), 98);
__d("UFI2BlockActorMutation", ["invariant", "RelayModern", "UFI2BlockActorMutation.graphql", "forEachUFI2DisplayCommentsConnection"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j = i !== void 0 ? i : i = b("UFI2BlockActorMutation.graphql");
    a = function(a, b) {
        var e = b.actorId,
            f = b.commentId,
            g = b.feedbackId,
            i = b.targetUserId;
        b = function(a) {
            if (g == null) return;
            var b = a.get(g);
            if (!b) return;
            c("forEachUFI2DisplayCommentsConnection")(a, b, function(a) {
                a = a.getLinkedRecords("edges");
                if (!a) return;
                a.forEach(function(a) {
                    if (!a) return;
                    a = a.getLinkedRecord("node");
                    if (!a) return;
                    var b = a.getLinkedRecord("author");
                    if (!b) return;
                    b.getValue("id") === i && (a.setValue("spam", "spam_display_mode"), a.setValue(!0, "is_author_banned_by_content_owner"))
                })
            })
        };
        return d("RelayModern").commitMutation(a, {
            mutation: j,
            onError: function(b) {
                d("RelayModern").commitLocalUpdate(a, function(a) {
                    a = a.get(f);
                    a || h(0, 30340, f);
                    a.setValue("BLOCK", "optimistic_action");
                    a.setValue(b.message, "optimistic_error")
                })
            },
            updater: b,
            variables: {
                input: {
                    actor_id: e,
                    blocksource: "COMMENT_MODERATION",
                    user_id: i
                }
            }
        })
    };
    g.commit = a
}), 98);
__d("UFI2FeedbackReactMutation", ["invariant", "ChannelClientID", "FBLogger", "FeedbackSourceType", "JSEnumValueToGraphQLKey", "RelayModern", "RelayRuntime", "UFI2FeedbackReactMutation.graphql", "UFI2FeedbackReactMutation_feedback.graphql", "UFIODSLogger", "UFIReactionTypes", "WebPixelRatio", "arrayStableSort", "cr:1088250", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i, j, k = 2,
        l = 3e3,
        m = c("JSEnumValueToGraphQLKey")(c("FeedbackSourceType"), 1);
    i !== void 0 ? i : i = b("UFI2FeedbackReactMutation_feedback.graphql");
    var n = j !== void 0 ? j : j = b("UFI2FeedbackReactMutation.graphql");

    function a(a) {
        var b = a.actorID,
            e = a.environment,
            f = a.input,
            g = a.useDefaultActor,
            i = f.feedback_source,
            j = f.feedback_reaction;
        b = {
            input: babelHelpers["extends"]({}, f, {
                actor_id: b,
                feedback_source: i != null ? c("JSEnumValueToGraphQLKey")(c("FeedbackSourceType"), i) : void 0,
                session_id: d("ChannelClientID").getID()
            }),
            scale: d("WebPixelRatio").get(),
            useDefaultActor: g
        };
        i = function(a) {
            var b = a.get(f.feedback_id);
            if (b == null) {
                c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", f.feedback_id).warn("UFI2FeedbackReactMutation: Could not find feedback in Relay store.");
                return
            }
            b.setValue(!0, "should_show_top_reactions");
            var d = p(a, f.feedback_id, b),
                e = b.getLinkedRecord("viewer_feedback_reaction_info", {
                    use_default_actor: g
                }),
                i = e ? e.getValue("key") || 0 : 0;
            typeof i === "number" || h(0, 3027);
            var k = b.getLinkedRecord("top_reactions", {
                orderby: ["COUNT_DESC", "REACTION_TYPE"]
            });
            if (!k) {
                var l = "client:top_reactions:" + f.feedback_id;
                k = a.create(l, "TopReactionsConnection")
            }
            r(a, k, j, i);
            var m;
            if (j === 0) {
                if (e !== null) {
                    l = d.getValue("count");
                    k = typeof l === "number" ? l : 1;
                    m = k - 1
                }
                b.setValue(null, "viewer_feedback_reaction_info", {
                    use_default_actor: g
                })
            } else {
                if (e === null) {
                    i = d.getValue("count");
                    l = typeof i === "number" ? i : 0;
                    m = l + 1
                }
                e = q(a, j);
                b.setLinkedRecord(e, "viewer_feedback_reaction_info", {
                    use_default_actor: g
                })
            }
            m != null && (d.setValue(m, "count"), d.setValue(m === 0, "is_empty"));
            k = d.getValue("count_reduced");
            if (parseInt(k, 10).toString() === k) {
                i = d.getValue("count");
                typeof i === "number" && d.setValue(i.toString(), "count_reduced")
            }
        };
        b = {
            mutation: n,
            optimisticUpdater: i,
            variables: b
        };
        return o(e, b, i, 0, f, a.onError)
    }

    function o(a, e, f, g, h, i) {
        var j = d("RelayModern").commitMutation(a, babelHelpers["extends"]({}, e, {
            onCompleted: function(a) {
                a = e == null ? void 0 : (a = e.variables) == null ? void 0 : (a = a.input) == null ? void 0 : a.feedback_source;
                var c = Math.min(g + 1, 3);
                c = "" + c + (g >= c ? "+" : "");
                a === m && d("UFIODSLogger").bump("reaction.newsfeed.mutation.attempt." + c, "relay");
                d("UFIODSLogger").bump("reaction.mutation.attempt." + c, "relay");
                b("cr:1088250") && b("cr:1088250")(h)
            },
            onError: function(b) {
                if (b.name === "GraphQLError") return i(b);
                j = c("RelayRuntime").applyOptimisticMutation(a, babelHelpers["extends"]({}, e, {
                    optimisticUpdater: f
                }));
                if (g >= k) return i(b);
                c("setTimeoutAcrossTransitions")(function() {
                    j && j.dispose(), j = o(a, e, f, g + 1, h, i)
                }, l)
            }
        }));
        return {
            dispose: function() {
                j && j.dispose(), j = null
            }
        }
    }

    function p(a, b, d) {
        var e = d.getLinkedRecord("reactors");
        if (!e) {
            c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", b).warn("Expected Feedback record proxy to have a reactors connection");
            b = "client:reactors:" + b;
            e = a.get(b) || a.create(b, "ReactorsOfContentConnection");
            e.setValue(0, "count");
            e.setValue("0", "count_reduced");
            e.setValue(!0, "is_empty");
            d.setLinkedRecord(e, "reactors")
        }
        return e
    }

    function q(a, b) {
        b !== 0 || h(0, 3028);
        var d = "client:reaction_info:" + b,
            e = a.get(d);
        if (!e) {
            e = a.create(d, "FeedbackReactionInfo");
            e.setValue(b, "key");
            a = c("UFIReactionTypes").reactions[b];
            a || h(0, 3029, b);
            e.setValue(a.display_name, "localized_name");
            e.setValue(a.name.toUpperCase(), "reaction_type")
        }
        return e
    }

    function r(a, b, d, e) {
        var f = (b.getLinkedRecords("edges") || []).map(function(a) {
            if (!a) return null;
            var b = a.getLinkedRecord("node"),
                c = a.getValue("reaction_count") || 0,
                d = b && b.getValue("key") || 0;
            typeof c === "number" && typeof d === "number" || h(0, 3027);
            return b && c !== 0 && d !== 0 ? {
                count: c,
                edge: a,
                key: d
            } : null
        }).filter(Boolean);
        if (e) {
            var g = f.find(function(a) {
                return a.key === e
            });
            g && g.count--
        }
        if (d) {
            g = f.find(function(a) {
                return a.key === d
            });
            if (!g) {
                var i = q(a, d);
                a = c("RelayRuntime").ConnectionHandler.createEdge(a, b, i, "TopReactionsEdge");
                g = {
                    count: 0,
                    edge: a,
                    key: d
                };
                f.push(g)
            }
            g.count++
        }
        i = c("arrayStableSort")(f, function(a, b) {
            return b.count - a.count || c("UFIReactionTypes").ordering.indexOf(a.key) - c("UFIReactionTypes").ordering.indexOf(b.key)
        }).filter(function(a) {
            return a.count !== 0
        }).map(function(a) {
            var b = a.edge;
            a = a.count;
            b.setValue(a, "reaction_count");
            b.setValue((a = b.getValue("reaction_count_reduced")) != null ? a : "", "reaction_count_reduced");
            return b
        });
        b.setLinkedRecords(i, "edges")
    }
    g.commit = a
}), 98);
__d("UFI2UnhideCommentMutation", ["FBLogger", "RelayModern", "UFI2UnhideCommentMutation.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("UFI2UnhideCommentMutation.graphql");

    function a(a, b) {
        return d("RelayModern").commitMutation(a, {
            mutation: i,
            optimisticUpdater: function(a) {
                a = a.get(b.commentId);
                if (a == null) {
                    c("FBLogger")("ufi2").mustfix("When trying to unhide a comment, the comment could not be found.");
                    return
                }
                a.setValue(!1, "is_hidden_by_content_owner");
                a.setValue(!1, "is_hidden_by_viewer");
                a.setValue("none", "spam_display_mode")
            },
            variables: {
                feedLocation: b.feedLocation,
                input: {
                    actor_id: b.actorId,
                    comment_id: b.commentId,
                    feedback_source: b.feedbackSource,
                    site: "www"
                },
                isComet: b.isComet,
                useDefaultActor: b.useDefaultActor
            }
        })
    }
    g.commit = a
}), 98);
__d("UFI2CreateCommentSubscription", ["FBLogger", "RelayModern", "RelayRuntime", "SiteData", "UFI2CreateCommentSubscription.graphql", "forEachUFI2DisplayCommentsConnection", "nodeIsInConnection"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("UFI2CreateCommentSubscription.graphql");

    function a(a) {
        var b = a.commentsKey,
            e = a.containerMapping,
            f = a.environment,
            g = a.feedbackSource,
            h = a.feedLocation,
            j = a.focusCommentID,
            k = a.isComet,
            l = a.onCompleted,
            m = a.onNext,
            n = a.topLevelFeedbackTargetID;
        a = a.useDefaultActor;

        function o(a) {
            c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", n || "UNKNOWN").warn(a)
        }
        return d("RelayModern").requestSubscription(f, {
            onCompleted: l,
            onNext: m,
            subscription: i,
            updater: function(a, b) {
                var d = a.getRootField("comment_create_subscribe");
                if (d == null) {
                    o("could not find comment create subscription payload");
                    return
                }
                var e = d.getLinkedRecord("feedback");
                if (e == null) {
                    o("could not find feedback target in payload");
                    return
                }
                var f = e.getDataID();
                if (f == null) {
                    o("could not get feedback target id");
                    return
                }
                f = a.get(f);
                if (f == null) {
                    o("could not find feedback record");
                    return
                }
                c("forEachUFI2DisplayCommentsConnection")(a, f, function(b) {
                    var f = d.getLinkedRecord("feedback_comment_edge");
                    if (f == null) {
                        o("could not find comment edge");
                        return
                    }
                    var g = f.getLinkedRecord("node");
                    if (g == null) {
                        o("could not find comment node");
                        return
                    }
                    if (c("nodeIsInConnection")(b, g, o)) return;
                    var h = b.getValue("before_count") || 0;
                    if (typeof h !== "number") {
                        o("expected `before_count` to be a number");
                        return
                    }
                    h = c("RelayRuntime").ConnectionHandler.createEdge(a, b, g, f.getType());
                    if (h == null) {
                        o("could not build comment edge");
                        return
                    }
                    c("RelayRuntime").ConnectionHandler.insertEdgeBefore(b, h);
                    g.setValue(!0, "is_created_from_subscription");
                    f = e.getLinkedRecord("display_comments");
                    if (f == null) {
                        o("could not get display_comments from payload");
                        return
                    }
                    h = f.getValue("count");
                    if (h == null) {
                        o("could not get display_comments count from payload");
                        return
                    }
                    b.setValue(h, "count")
                });
                f = [(f = b.comment_create_subscribe) == null ? void 0 : (f = f.feedback_comment_edge) == null ? void 0 : (f = f.node) == null ? void 0 : (f = f.author) == null ? void 0 : (f = f.profile_picture_depth_0) == null ? void 0 : f.uri, (f = b.comment_create_subscribe) == null ? void 0 : (f = f.feedback_comment_edge) == null ? void 0 : (f = f.node) == null ? void 0 : (f = f.author) == null ? void 0 : (f = f.profile_picture_depth_1) == null ? void 0 : f.uri];
                if (f[0] == null || f[1] == null) {
                    c("FBLogger")("ufi2").addMetadata("UFI", "FEEDBACK_TARGET_ID", n || "UNKNOWN").addMetadata("UFI", "COMMENT_ID", (b = (f = b.comment_create_subscribe) == null ? void 0 : (b = f.feedback_comment_edge) == null ? void 0 : (f = b.node) == null ? void 0 : f.id) != null ? b : "UNKNOWN").warn("Profile photo missing on live comment")
                }
            },
            variables: babelHelpers["extends"]({}, e, {
                UFI2CommentsProvider_commentsKey: b,
                feedbackSource: g,
                feedLocation: h,
                focusCommentID: j,
                input: {
                    top_level_feedback_id: n
                },
                isComet: k,
                scale: c("SiteData").pr,
                useDefaultActor: a
            })
        })
    }
    g.subscribe = a
}), 98);
__d("UFI2TypingSubscription", ["RelayModern", "UFI2TypingSubscription.graphql"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = h !== void 0 ? h : h = b("UFI2TypingSubscription.graphql");

    function a(a, b, c) {
        return d("RelayModern").requestSubscription(a, {
            onNext: c && c.onNext,
            subscription: i,
            variables: {
                input: {
                    feedback_id: b
                }
            }
        })
    }
    g.subscribe = a
}), 98);